const http = require('http');
const fs = require('fs');
const path = require('path');
const boardData = require('./data/board');
const pinsDb = require('./data/pins.json');

const PORT = process.env.PORT ? Number(process.env.PORT) : 8790;
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');

function send(res, code, body, type = 'text/plain; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(body);
}
function sendJson(res, code, obj) {
  send(res, code, JSON.stringify(obj, null, 2), 'application/json; charset=utf-8');
}

function serveStatic(reqPath, res) {
  let p = reqPath === '/' ? '/index.html' : reqPath;
  try { p = decodeURIComponent(p); } catch (_) {}
  const file = path.normalize(path.join(PUBLIC, p));
  if (!file.toLowerCase().startsWith(PUBLIC.toLowerCase())) return send(res, 403, 'Forbidden');
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) return send(res, 404, 'Not found');
  const ext = path.extname(file).toLowerCase();
  const types = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.svg': 'image/svg+xml',
    '.md': 'text/markdown; charset=utf-8',
    '.pdf': 'application/pdf'
  };
  res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer(async (req, res) => {
  let pathname = '/';
  try {
    const parsed = new URL(req.url, `http://${req.headers.host || '127.0.0.1'}`);
    pathname = parsed.pathname || '/';
  } catch (_) { pathname = req.url || '/'; }
  try {
    if (req.method === 'GET' && pathname === '/api/board') {
      return sendJson(res, 200, { ...boardData, pins: pinsDb });
    }
    if (req.method === 'GET' || req.method === 'HEAD') {
      return serveStatic(pathname, res);
    }
    send(res, 405, 'Method not allowed');
  } catch (err) {
    console.error(err);
    sendJson(res, 500, { ok: false, error: err && err.message ? err.message : String(err) });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`codegen-exynos running at http://127.0.0.1:${PORT}`);
  console.log('Target: Samsung Exynos 4412 (Odroid-X2 class)');
});