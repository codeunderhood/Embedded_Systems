# Exynos 4412 Clock Tree Reference

## Source
- Exynos 4412 TRM (Clock Management Unit)
- MangoBoard CM-C220 Hardware Manual: http://www.mangoboard.com/main/view.asp?idx=313

## OSC / RTC
- OSC (HSE): 24 MHz crystal
- RTC (LSE): 32.768 kHz

## PLLs
| PLL | Source | Output | Feeds |
|-----|--------|--------|-------|
| APLL | OSC 24 MHz | ARMCLK | Cortex-A9 x4, L1/L2, SCU, GIC, NEON |
| MPLL | OSC 24 MHz | MCLK / HCLK / PCLK | LPDDR2, bus matrix, peripherals |
| EPLL | OSC 24 MHz | AUDIOCLK | I2S, PCM, HDMI audio, audio codec |
| VPLL | OSC 24 MHz | VIDEOCLK | HDMI, MIPI DSI/CSI, LCD |
| BPLL | OSC 24 MHz | BUSCLK2 | Alternate bus domain, some DMA/peripherals |
| SPLL | OSC 24 MHz | SCLK | Special peripherals (MMC, USB, etc.) |

## Dividers
- ARMCLK = APLL / ARM_DIV (1, 2, 3)
- HCLK = MPLL / BUS_DIV (2, 3, 4)
- PCLK = HCLK / PERIPH_DIV (2, 4, 8)
- MCLK = MPLL / MEM_DIV (1, 2)
- BUSCLK2 = BPLL (direct)
- SCLK = SPLL (direct)

## Clock Domains
| Domain | Source | Frequency | Peripherals |
|--------|--------|-----------|-------------|
| ARMCLK (CPU) | APLL | 800-1400 MHz | Cortex-A9 x4, L1/L2 cache, SCU, GIC, NEON/VFP |
| HCLK (AXI/AHB) | MPLL | 200-400 MHz | Bus matrix, DMA (PDMA/MDMA), GPU, MFC |
| MCLK (Memory) | MPLL | 400-800 MHz | LPDDR2 controller, memory PHY |
| PCLK (APB) | MPLL | 100-200 MHz | UART0-3, I2C0-7, SPI0-2, GPIO, PWM, Timer, ADC, WDT |
| BUSCLK2 | BPLL | 400-800 MHz | Alternate bus domain, some DMA/peripherals |
| SCLK | SPLL | 100-200 MHz | MMC, USB, special peripherals |
| AUDIOCLK | EPLL | 49.152/96 MHz | I2S, PCM, HDMI audio, audio codec |
| VIDEOCLK | VPLL | 108/148.5 MHz | HDMI, MIPI DSI/CSI, LCD controller |
| RTC/WDT | OSC 24 MHz / 32.768 kHz | 32.768 kHz | RTC, watchdog, TSC |

## Clock Gating (CMU)
- CMU_CPU: gates CPU domain clocks
- CMU_CORE: gates core logic clocks
- CMU_TOP: gates top-level (bus, memory) clocks
- CMU_DMC: gates memory controller clocks
- Each IP has individual CLKGATE register bit

## DTS Clock Fragment Example
```dts
assigned-clocks = <&clock CLK_ARM>, <&clock CLK_BUS>;
assigned-clock-rates = <1400000000, 800000000>;

/* CPU OPP */
operating-points = <
    1400000 1250000
    1200000 1150000
    1000000 1075000
    800000  1000000
>;

/* Bus clocks */
/* HCLK = 400 MHz, PCLK = 200 MHz, MCLK = 800 MHz */
```

## Interactive Controls (in UI)
- APLL (ARM): 800/1000/1200/1400 MHz
- MPLL (BUS/MEM): 400/600/800 MHz
- EPLL (Audio): 49.152/96 MHz
- VPLL (Video): 108/148.5 MHz
- BPLL (Bus alt): 400/600/800 MHz
- SPLL (Special): 100/200 MHz
- ARM divider: /1, /2, /3
- BUS divider: /2, /3, /4
- PERIPH divider: /2, /4, /8
- MEM divider: /1, /2

## Board Reference
- MangoBoard CM-C220 (Exynos 4412 Quad Core Cortex-A9)
- Hardware manual: http://www.mangoboard.com/main/view.asp?idx=313
- Pin map: CM-C220-PINMAP.pdf (attached to the page)