# Exynos SoC Configurator (scaffold)

Dependency-free Node app (like the BeagleBone one) for Samsung Exynos 4412.

Run:
```
cd C:\Users\user\Desktop\study\ai_content\codegenExynos
node server.js
```
Open http://127.0.0.1:8790

Views: Pinout & Configuration, Clock Tree, SoC Layout, DTS & Fragments, Board View.