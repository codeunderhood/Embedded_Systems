module.exports = {
  board: {
    name: "Samsung Exynos 4412 (Odroid-X2 class)",
    soc: "Samsung Exynos 4412 (Cortex-A9 quad)",
    cpu: "ARM Cortex-A9 @ 1.4 GHz",
    ram: "2 GB LPDDR2",
    storage: "eMMC 4/8/16 GB, microSD",
    gpu: "Mali-400 MP4",
    usb: "USB 2.0 Host + OTG",
    hdmi: "HDMI 1.4",
    ethernet: "10/100 (USB LAN)"
  },
  clocks: {
    osc_mhz: { label: "Input crystal (OSC)", default: 24, options: [24] },
    arm_mhz: { label: "ARM (APLL)", default: 1400, options: [800, 1000, 1200, 1400] },
    bus_mhz: { label: "BUS (MPLL)", default: 800, options: [400, 600, 800] },
    mem_mhz: { label: "Memory (MPLL)", default: 800, options: [400, 800] }
  },
  boot: {
    modes: [
      { id: "sd", label: "microSD (MMC0)" },
      { id: "emmc", label: "eMMC (MMC1)" }
    ],
    console: { default: "ttySAC1,115200n8" }
  },
  peripherals: [
    { id: "uart0", label: "UART0", default: false, pins: ["GPA0_0/1"] },
    { id: "uart1", label: "UART1 (console)", default: true, fixed: true, pins: ["GPA0_4/5"] },
    { id: "uart2", label: "UART2", default: false, pins: ["GPA1_0/1"] },
    { id: "uart3", label: "UART3", default: false, pins: ["GPA1_4/5"] },
    { id: "i2c0", label: "I2C0", default: true, fixed: true, pins: ["GPB_0/1"] },
    { id: "i2c1", label: "I2C1", default: false, pins: ["GPB_2/3"] },
    { id: "i2c2", label: "I2C2", default: false, pins: ["GPB_4/5"] },
    { id: "i2c3", label: "I2C3", default: false, pins: ["GPC1_1/0"] },
    { id: "spi0", label: "SPI0", default: false, pins: ["GPC0_0..3"] },
    { id: "spi1", label: "SPI1", default: false, pins: ["GPC1_1..4"] },
    { id: "spi2", label: "SPI2", default: false, pins: ["GPD0_0..3"] },
    { id: "mmc0", label: "microSD (MMC0)", default: true, fixed: true },
    { id: "mmc1", label: "eMMC (MMC1)", default: true, fixed: true },
    { id: "mmc2", label: "SDIO (MMC2)", default: false },
    { id: "usb", label: "USB 2.0 Host/OTG", default: true },
    { id: "hdmi", label: "HDMI", default: true },
    { id: "gpio_leds", label: "User LEDs", default: true, fixed: true }
  ]
};