/* ============================================================
   DSA Visuals — authoring helpers
   Small utilities for writing step generators compactly.
   ============================================================ */
(function () {
  "use strict";

  /** Build a cells track: H.track(label, values, states, tags?)
      `states` may be an array of state names, one state name for every cell,
      or a function (index) => state name. */
  function track(label, values, states, tags) {
    return {
      label,
      cells: values.map((v, i) => ({
        v,
        state: typeof states === "function"
          ? states(i) || "idle"
          : typeof states === "string"
            ? states
            : (states && states[i]) || "idle",
        tag: tags ? tags[i] : undefined,
      })),
    };
  }

  /** Array of length n filled with one state */
  function fill(n, state) {
    return Array(n).fill(state);
  }

  /** Copy an array of states with overrides: H.paint(base, {2: "read"}) */
  function paint(base, overrides) {
    const out = base.slice();
    for (const k in overrides) out[k] = overrides[k];
    return out;
  }

  /** Counter shorthand */
  function count(label, value, total) {
    return total == null ? { label, value } : { label, value, total };
  }

  /** Make cells from a plain number list (all idle) */
  function nums(values) {
    return values.map((v) => ({ v }));
  }

  /** Build a binary tree from level-order values (null/undefined = gap).
      Returns root of {id, v, l, r} nodes with stable string ids. */
  function binaryTree(values) {
    if (!values || !values.length || values[0] == null) return null;
    const root = { id: "t0", v: values[0], l: null, r: null };
    const queue = [root];
    let i = 1, counter = 1;
    while (queue.length && i < values.length) {
      const node = queue.shift();
      if (i < values.length) {
        const lv = values[i++];
        if (lv != null) { node.l = { id: "t" + counter++, v: lv, l: null, r: null }; queue.push(node.l); }
      }
      if (i < values.length) {
        const rv = values[i++];
        if (rv != null) { node.r = { id: "t" + counter++, v: rv, l: null, r: null }; queue.push(node.r); }
      }
    }
    return root;
  }

  /** Collect all node ids of a H.binaryTree root (for nodeStates maps). */
  function treeIds(root) {
    const out = [];
    const walk = (n) => { if (!n) return; out.push(n.id); walk(n.l); walk(n.r); };
    walk(root);
    return out;
  }

  /** Flatten a matrix (array of rows) into grid cells, all idle, optionally
      transformed: H.grid(rows, cols, (r, c) => ({v, state})) */
  function grid(rows, cols, fn) {
    const cells = [];
    for (let r = 0; r < rows; r++)
      for (let c = 0; c < cols; c++) {
        const cd = fn ? fn(r, c) : {};
        cells.push({ r, c, ...cd });
      }
    return cells;
  }

  window.H = { track, fill, paint, count, nums, binaryTree, treeIds, grid };
})();
