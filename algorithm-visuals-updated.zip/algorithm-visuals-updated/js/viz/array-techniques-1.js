/* ============================================================
   DSA Visuals — Array Techniques I
   Index tricks: missing values, disappearing numbers, moving
   zeroes, rotation, merging, permutations and zeroed matrices.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "swap", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => `[${a.join(", ")}]`;

  /* ---------------------------------------------------------- */
  V.register({
    id: "missing-number",
    title: "Missing Number",
    category: "Array Techniques",
    difficulty: "Beginner",
    description:
      "One value from 0..n is missing; find it with the sum formula or with XOR.",
    input: { label: "The numbers", default: "3, 0, 1", parse: "ints" },
    approaches: [
      {
        name: "Compare Sums",
        complexity: "O(n) time, O(1) space",
        idea: [
          "The numbers should add up to n(n + 1) / 2. Adding the row and subtracting it from that total leaves exactly the missing value.",
          "One pass to add, one formula to compare — no sorting and no extra array.",
        ],
        problem: [
          "The total grows with the square of n, so very large rows overflow a fixed-width integer.",
        ],
        code: {
          c: `#include <stdio.h>

int missing_number(const int *a, int n) {
    long expected = (long)n * (n + 1) / 2;
    long actual = 0;
    for (int i = 0; i < n; i++) actual += a[i];
    return (int)(expected - actual);
}

int main(void) {
    int a[] = {3, 0, 1};
    printf("%d\\n", missing_number(a, 3)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <numeric>
using namespace std;

int missingNumber(const vector<int>& a) {
    long long n = a.size();
    long long expected = n * (n + 1) / 2;
    long long actual = accumulate(a.begin(), a.end(), 0LL);
    return (int)(expected - actual);
}

int main() {
    vector<int> a{3, 0, 1};
    cout << missingNumber(a) << '\\n'; // 2
}`,
        },
        steps(nums) {
          const n = nums.length;
          const expected = n * (n + 1) / 2;
          const steps = [];
          let sum = 0;
          steps.push({
            title: `${n} values should cover 0..${n}`,
            tracks: [track("numbers", nums, fill(n, "idle")), chips("expected total", [expected], "dim")],
            counters: [count("numbers read", 0, n), count("running total", 0)],
            legend: LEG,
            happened: `A complete set from 0 to ${n} adds up to ${expected}.`,
            why: "If exactly one value is missing, the shortfall in the total is that value.",
            codeLine: 4,
          });
          for (let i = 0; i < n; i++) {
            sum += nums[i];
            steps.push({
              title: `Add ${nums[i]} → total ${sum}`,
              tracks: [
                track("numbers", nums, paint(fill(n, "done"), { [i]: "read" })),
                chips("running total", [sum], "active"),
                chips("expected total", [expected], "dim"),
              ],
              counters: [count("numbers read", i + 1, n), count("running total", sum)],
              legend: LEG,
              happened: `The running total is ${sum} after reading ${nums[i]}.`,
              why: "Every value is added exactly once, so the pass is linear.",
              codeLine: 6,
            });
          }
          const miss = expected - sum;
          steps.push({
            title: `Answer: ${miss} is missing`,
            tracks: [
              track("numbers", nums, fill(n, "done")),
              chips("expected", [expected], "dim"),
              chips("actual", [sum], "compare"),
              chips("answer", [miss], "result"),
            ],
            counters: [count("numbers read", n, n), count("answer", miss)],
            legend: LEG,
            happened: `${expected} − ${sum} = ${miss}, so that is the value with no home.`,
            why: "The formula replaces a lookup table with one arithmetic comparison.",
            codeLine: 7,
          });
          return steps;
        },
      },
      {
        name: "XOR With Indices",
        complexity: "O(n) time, O(1) space",
        idea: [
          "XOR every index from 0 to n together with every value. Equal numbers cancel, leaving only the index that had no matching value.",
          "No arithmetic growth, so there is nothing to overflow.",
        ],
        problem: [
          "The trick depends on the values being exactly 0..n minus one; a different range breaks the cancellation.",
        ],
        code: {
          c: `#include <stdio.h>

int missing_number(const int *a, int n) {
    int x = 0;
    for (int i = 0; i <= n; i++) x ^= i;      /* indices */
    for (int i = 0; i < n; i++) x ^= a[i];    /* values  */
    return x;
}

int main(void) {
    int a[] = {3, 0, 1};
    printf("%d\\n", missing_number(a, 3)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int missingNumber(const vector<int>& a) {
    int x = 0;
    for (int i = 0; i <= (int)a.size(); i++) x ^= i;
    for (int v : a) x ^= v;
    return x;
}

int main() {
    vector<int> a{3, 0, 1};
    cout << missingNumber(a) << '\\n'; // 2
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          let x = 0;
          steps.push({
            title: "XOR of 0..n cancels against the values",
            tracks: [track("numbers", nums, fill(n, "idle")), chips("xor", [0], "dim")],
            counters: [count("numbers read", 0, n), count("xor", 0)],
            legend: LEG,
            happened: `Indices 0 to ${n} and the ${n} stored values will be folded together.`,
            why: "Pairs of equal numbers cancel, and the leftover index is the missing value.",
            codeLine: 3,
          });
          for (let i = 0; i <= n; i++) {
            x ^= i;
            steps.push({
              title: `XOR index ${i} → ${x}`,
              tracks: [
                track("numbers", nums, fill(n, "dim")),
                chips("indices folded", Array.from({ length: i + 1 }, (_, k) => k), "done"),
                chips("xor", [x], "active"),
              ],
              counters: [count("indices folded", i + 1, n + 1), count("xor", x)],
              legend: LEG,
              happened: `Folding index ${i} changes the accumulator to ${x}.`,
              why: "Doing all indices first gives the values something to cancel against.",
              codeLine: 4,
            });
          }
          for (let i = 0; i < n; i++) {
            x ^= nums[i];
            steps.push({
              title: `XOR value ${nums[i]} → ${x}`,
              tracks: [
                track("numbers", nums, paint(fill(n, "done"), { [i]: "read" })),
                chips("xor", [x], "result"),
              ],
              counters: [count("numbers read", i + 1, n), count("xor", x)],
              legend: LEG,
              happened: `${nums[i]} cancels its matching index, so the accumulator becomes ${x}.`,
              why: "Values that exist cancel; the missing index never finds a partner.",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Answer: ${x}`,
            tracks: [
              track("numbers", nums, fill(n, "done")),
              chips("answer", [x], "result"),
            ],
            counters: [count("numbers read", n, n), count("answer", x)],
            legend: LEG,
            happened: `Only ${x} survived the cancellation.`,
            why: "XOR gives the same answer as the sum method without any overflow risk.",
            codeLine: 6,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-all-numbers-disappeared-in-an-array",
    title: "Find All Numbers Disappeared in an Array",
    category: "Array Techniques",
    difficulty: "Intermediate",
    description:
      "Values sit in 1..n but some are duplicated, so list every value that never appears — in place.",
    input: { label: "The numbers", default: "4, 3, 2, 7, 8, 2, 3, 1", parse: "ints" },
    approaches: [
      {
        name: "Mark With the Sign",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "Treat the values as pointers to indices. For each value v, negate the entry at index v − 1 to record that v was seen.",
          "After the pass, any entry still positive marks an index whose value never appeared.",
        ],
        problem: [
          "The array is modified, which is only acceptable when the caller allows the input to be reused as scratch space.",
        ],
        code: {
          c: `#include <stdio.h>

/* values are 1..n; returns count, writes answers into out[] */
int disappeared(int *a, int n, int *out) {
    for (int i = 0; i < n; i++) {
        int idx = (a[i] < 0 ? -a[i] : a[i]) - 1;
        if (a[idx] > 0) a[idx] = -a[idx];
    }
    int m = 0;
    for (int i = 0; i < n; i++)
        if (a[i] > 0) out[m++] = i + 1;
    return m;
}

int main(void) {
    int a[] = {4, 3, 2, 7, 8, 2, 3, 1}, out[8];
    int m = disappeared(a, 8, out);
    for (int i = 0; i < m; i++) printf("%d ", out[i]); /* 5 6 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

vector<int> findDisappeared(vector<int> a) {
    int n = a.size();
    for (int i = 0; i < n; i++) {
        int idx = abs(a[i]) - 1;
        if (a[idx] > 0) a[idx] = -a[idx];
    }
    vector<int> out;
    for (int i = 0; i < n; i++)
        if (a[i] > 0) out.push_back(i + 1);
    return out;
}

int main() {
    for (int v : findDisappeared({4, 3, 2, 7, 8, 2, 3, 1}))
        cout << v << ' '; // 5 6
    cout << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          if (!n) {
            return [{
              title: "Give at least one value",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("values", 0)],
              legend: ["idle", "result"],
              happened: "An empty row has no positions to mark.",
              why: "Values outside 1..n cannot be marked in place, so keep them in range.",
            }];
          }
          const a = nums.slice();
          const steps = [];
          steps.push({
            title: `${n} values, each expected in 1..${n}`,
            tracks: [track("numbers", a, fill(n, "idle"))],
            counters: [count("values", n), count("marked", 0)],
            legend: LEG,
            happened: `The row is ${show(a)}; a value v will mark position v − 1.`,
            why: "Using the sign as a flag avoids allocating a separate seen array.",
            codeLine: 4,
          });
          for (let i = 0; i < n; i++) {
            const idx = Math.abs(a[i]) - 1;
            const inRange = idx >= 0 && idx < n;
            const wasPositive = inRange && a[idx] > 0;
            if (wasPositive) a[idx] = -a[idx];
            steps.push({
              title: inRange
                ? `Value ${Math.abs(nums[i])} marks position ${idx}${wasPositive ? "" : " (already marked)"}`
                : `Value ${a[i]} is outside 1..${n}, ignored`,
              tracks: [
                track("numbers", a.map(Math.abs), (k) => (k === i ? "read" : a[k] < 0 ? "done" : "idle")),
                chips("marked indices", a.map((v, k) => (v < 0 ? k + 1 : "·")), (k) => (k === idx ? "active" : "dim")),
              ],
              counters: [count("values", n), count("positions marked", a.filter((v) => v < 0).length)],
              legend: LEG,
              happened: inRange
                ? `Position ${idx} now holds ${a[idx]}, recording that ${Math.abs(nums[i])} exists.`
                : `The value ${a[i]} cannot point at a valid position.`,
              why: "A negative sign is a one-bit flag, so marking costs no extra memory.",
              codeLine: 6,
            });
          }
          const missing = a.map((v, i) => (v > 0 ? i + 1 : null)).filter((v) => v != null);
          steps.push({
            title: `Answer: ${missing.length ? missing.join(", ") : "nothing missing"}`,
            tracks: [
              track("numbers after marking", a, (k) => (a[k] > 0 ? "result" : "done")),
              chips("missing values", missing.length ? missing : ["none"], "result"),
            ],
            counters: [count("values", n), count("missing", missing.length)],
            legend: LEG,
            happened: missing.length
              ? `Positions ${missing.map((v) => v - 1).join(", ")} were never marked, so ${missing.join(", ")} never appeared.`
              : "Every position was marked, so no value is missing.",
            why: "Positive entries survive only where no value pointed at them.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "move-zeroes",
    title: "Move Zeroes",
    category: "Array Techniques",
    difficulty: "Beginner",
    description:
      "Push every zero to the end while keeping the other values in their original order.",
    input: { label: "The numbers", default: "0, 1, 0, 3, 12", parse: "ints" },
    approaches: [
      {
        name: "Write Index",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Keep a write pointer for the next non-zero slot. Scanning the row, copy each non-zero value to that slot and advance it.",
          "After the scan every slot from the write pointer onward is filled with zero, which finishes the job in place.",
        ],
        problem: [
          "Values that are already in place still get copied onto themselves, so there is a little wasted work when there are no zeroes.",
        ],
        code: {
          c: `#include <stdio.h>

void move_zeroes(int *a, int n) {
    int write = 0;
    for (int read = 0; read < n; read++)
        if (a[read] != 0) a[write++] = a[read];
    while (write < n) a[write++] = 0;
}

int main(void) {
    int a[] = {0, 1, 0, 3, 12};
    move_zeroes(a, 5);                  /* 1 3 12 0 0 */
    for (int i = 0; i < 5; i++) printf("%d ", a[i]);
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

void moveZeroes(vector<int>& a) {
    int write = 0;
    for (int v : a)
        if (v != 0) a[write++] = v;
    while (write < (int)a.size()) a[write++] = 0;
}

int main() {
    vector<int> a{0, 1, 0, 3, 12};
    moveZeroes(a);
    for (int v : a) cout << v << ' '; // 1 3 12 0 0
    cout << '\\n';
}`,
        },
        steps(nums) {
          const a = nums.slice();
          const n = a.length;
          const steps = [];
          let write = 0;
          steps.push({
            title: "Write pointer starts at index 0",
            tracks: [
              track("numbers", a, fill(n, "idle")),
              chips("write index", [write], "read"),
            ],
            counters: [count("values kept", 0), count("zeroes placed", 0)],
            legend: LEG,
            happened: `The row is ${show(a)} and nothing has been written yet.`,
            why: "The write pointer separates the compacted prefix from the unread suffix.",
            codeLine: 3,
          });
          for (let read = 0; read < n; read++) {
            const keep = a[read] !== 0;
            if (keep) { a[write] = a[read]; write++; }
            steps.push({
              title: keep ? `Keep ${a[Math.max(0, write - 1)]} at index ${write - 1}` : `Skip the zero at ${read}`,
              tracks: [
                track("numbers", a, (k) => (k === read ? "read" : k < write ? "done" : "idle")),
                chips("write index", [write], "active"),
              ],
              counters: [count("values kept", write), count("zeroes placed", read - write + (keep ? 0 : 1))],
              legend: LEG,
              happened: keep
                ? `The non-zero value moved into slot ${write - 1} and the write pointer advanced.`
                : `A zero is not copied; it will be filled in at the end.`,
              why: "Skipping zeroes keeps the relative order of the other values intact.",
              codeLine: keep ? 4 : 3,
            });
          }
          for (let k = write; k < n; k++) a[k] = 0;
          steps.push({
            title: `Fill slots ${write}..${n - 1} with zero`,
            tracks: [
              track("numbers", a, (k) => (k >= write ? "result" : "done")),
              chips("zeroes placed", [n - write], "result"),
            ],
            counters: [count("values kept", write), count("zeroes placed", n - write)],
            legend: LEG,
            happened: `Every slot from ${write} onward becomes 0, giving ${show(a)}.`,
            why: "The tail is exactly the number of zeroes skipped, so no counting was needed.",
            codeLine: 5,
          });
          steps.push({
            title: `Answer: ${show(a)}`,
            tracks: [
              track("numbers", a, fill(n, "done")),
              chips("answer", [show(a)], "result"),
            ],
            counters: [count("values kept", write), count("answer", show(a))],
            legend: LEG,
            happened: `All non-zero values stay in order at the front and the zeroes sit at the end.`,
            why: "One scan plus one fill is linear time and constant extra space.",
            codeLine: 6,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "rotate-array",
    title: "Rotate Array",
    category: "Array Techniques",
    difficulty: "Intermediate",
    description:
      "Shift every value k places to the right, in place and without a second array.",
    input: {
      label: "row 1 = numbers, row 2 = k",
      default: "1, 2, 3, 4, 5, 6, 7 | 3",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Reverse Three Times",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Reversing the whole row puts the last k values at the front but backwards. Reversing the first k and then the rest fixes both internal orders.",
          "Three reversals, each using two pointers, rotate in place with no temporary array.",
        ],
        problem: [
          "Three passes touch every element more than once, which is fine for time but is more work than a single copy when memory is available.",
        ],
        code: {
          c: `#include <stdio.h>

static void reverse(int *a, int lo, int hi) {
    while (lo < hi) {
        int t = a[lo];
        a[lo++] = a[hi];
        a[hi--] = t;
    }
}

void rotate(int *a, int n, int k) {
    k %= n;
    reverse(a, 0, n - 1);
    reverse(a, 0, k - 1);
    reverse(a, k, n - 1);
}

int main(void) {
    int a[] = {1, 2, 3, 4, 5, 6, 7};
    rotate(a, 7, 3);                    /* 5 6 7 1 2 3 4 */
    for (int i = 0; i < 7; i++) printf("%d ", a[i]);
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void rotateRight(vector<int>& a, int k) {
    int n = a.size();
    k %= n;
    reverse(a.begin(), a.end());
    reverse(a.begin(), a.begin() + k);
    reverse(a.begin() + k, a.end());
}

int main() {
    vector<int> a{1, 2, 3, 4, 5, 6, 7};
    rotateRight(a, 3);
    for (int v : a) cout << v << ' '; // 5 6 7 1 2 3 4
    cout << '\\n';
}`,
        },
        steps(rows) {
          const a = (rows[0] || []).slice();
          const n = a.length;
          const kRaw = (rows[1] || [])[0];
          if (!n) {
            return [{
              title: "Give a row and a rotation amount",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("length", 0)],
              legend: ["idle", "result"],
              happened: "Nothing to rotate.",
              why: "Rotation needs at least one value.",
            }];
          }
          const k = ((kRaw % n) + n) % n;
          const steps = [];
          const rev = (lo, hi) => {
            const before = a.slice();
            while (lo < hi) { const t = a[lo]; a[lo] = a[hi]; a[hi] = t; lo++; hi--; }
            return before;
          };
          steps.push({
            title: `Rotate ${show(a)} by ${k}`,
            tracks: [track("numbers", a, fill(n, "idle"))],
            counters: [count("length", n), count("k mod n", k)],
            legend: LEG,
            happened: `Moving three places right sends the last ${k} values to the front.`,
            why: "Taking k modulo n avoids pointless full turns.",
            codeLine: 10,
          });
          let before = rev(0, n - 1);
          steps.push({
            title: `Reverse everything: ${show(a)}`,
            tracks: [
              track("before", before, fill(n, "dim")),
              track("numbers", a, fill(n, "active")),
            ],
            pointers: [{ track: 1, index: 0, label: "L" }, { track: 1, index: n - 1, label: "R" }],
            counters: [count("passes", 1, 3), count("length", n)],
            legend: LEG,
            happened: `The whole row flipped, so the last ${k} values are now first — but each part is backwards.`,
            why: "The first reversal moves the correct block to the front.",
            codeLine: 11,
          });
          if (k > 0) {
            before = rev(0, k - 1);
            steps.push({
              title: `Reverse the first ${k}: ${show(a)}`,
              tracks: [track("before", before, fill(n, "dim")), track("numbers", a, (i) => (i < k ? "result" : "active"))],
              pointers: [{ track: 1, index: 0, label: "L" }, { track: 1, index: k - 1, label: "R" }],
              counters: [count("passes", 2, 3), count("length", n)],
              legend: LEG,
              happened: `The leading block is back in its original order.`,
              why: "Reversing a reversed block restores it.",
              codeLine: 12,
            });
          }
          before = rev(k, n - 1);
          steps.push({
            title: `Reverse the rest: ${show(a)}`,
            tracks: [track("before", before, fill(n, "dim")), track("numbers", a, a.map((_, i) => (i >= k ? "result" : "done")))],
            pointers: k < n - 1 ? [{ track: 1, index: k, label: "L" }, { track: 1, index: n - 1, label: "R" }] : [],
            counters: [count("passes", 3, 3), count("length", n)],
            legend: LEG,
            happened: `Both blocks are in order, giving the rotated row.`,
            why: "Three in-place reversals rotate without any extra storage.",
            codeLine: 13,
          });
          steps.push({
            title: `Answer: ${show(a)}`,
            tracks: [track("numbers", a, fill(n, "done")), chips("answer", [show(a)], "result")],
            counters: [count("passes", 3, 3), count("answer", show(a))],
            legend: LEG,
            happened: `The row has been rotated right by ${k}.`,
            why: "Each pass is linear, so the total stays linear.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "merge-sorted-arrays",
    title: "Merge Sorted Arrays",
    category: "Array Techniques",
    difficulty: "Beginner",
    description:
      "Combine two sorted rows into one sorted row with two pointers.",
    input: {
      label: "row 1 | row 2 (both sorted)",
      default: "1, 3, 5, 7 | 2, 4, 6, 8",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Two Pointers",
        complexity: "O(n + m) time, O(n + m) space",
        idea: [
          "Put one pointer at the start of each row. Repeatedly take the smaller front value and advance only that pointer.",
          "When one row runs out, the rest of the other row is already sorted, so it can be copied straight across.",
        ],
        problem: [
          "The merged output needs its own buffer; writing back into one of the inputs only works when there is spare room at the end.",
        ],
        code: {
          c: `#include <stdio.h>

void merge(const int *a, int n, const int *b, int m, int *out) {
    int i = 0, j = 0, k = 0;
    while (i < n && j < m)
        out[k++] = a[i] <= b[j] ? a[i++] : b[j++];
    while (i < n) out[k++] = a[i++];
    while (j < m) out[k++] = b[j++];
}

int main(void) {
    int a[] = {1, 3, 5, 7}, b[] = {2, 4, 6, 8}, out[8];
    merge(a, 4, b, 4, out);
    for (int i = 0; i < 8; i++) printf("%d ", out[i]);
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

vector<int> mergeSorted(const vector<int>& a, const vector<int>& b) {
    vector<int> out;
    size_t i = 0, j = 0;
    while (i < a.size() && j < b.size())
        out.push_back(a[i] <= b[j] ? a[i++] : b[j++]);
    while (i < a.size()) out.push_back(a[i++]);
    while (j < b.size()) out.push_back(b[j++]);
    return out;
}

int main() {
    for (int v : mergeSorted({1, 3, 5, 7}, {2, 4, 6, 8}))
        cout << v << ' ';
    cout << '\\n';
}`,
        },
        steps(rows) {
          const A = rows[0] || [];
          const B = rows[1] || [];
          const steps = [];
          const out = [];
          let i = 0, j = 0;
          steps.push({
            title: `Merge ${A.length} + ${B.length} sorted values`,
            tracks: [
              track("row A", A, A.map((_, k) => (k === 0 ? "read" : "idle"))),
              track("row B", B, B.map((_, k) => (k === 0 ? "read" : "idle"))),
              track("merged", [], "idle"),
            ],
            pointers: [
              ...(A.length ? [{ track: 0, index: 0, label: "i" }] : []),
              ...(B.length ? [{ track: 1, index: 0, label: "j" }] : []),
            ],
            counters: [count("taken from A", 0, A.length), count("taken from B", 0, B.length)],
            legend: LEG,
            happened: `A is ${show(A)} and B is ${show(B)}.`,
            why: "Because both front values are the smallest in their rows, comparing them is enough to pick the next output.",
            codeLine: 4,
          });
          while (i < A.length || j < B.length) {
            let take;
            if (i >= A.length) take = "B";
            else if (j >= B.length) take = "A";
            else take = A[i] <= B[j] ? "A" : "B";
            const v = take === "A" ? A[i] : B[j];
            out.push(v);
            if (take === "A") i++; else j++;
            steps.push({
              title: `Take ${v} from ${take}`,
              tracks: [
                track("row A", A, A.map((_, k) => (k < i ? "done" : k === i ? "read" : "idle"))),
                track("row B", B, B.map((_, k) => (k < j ? "done" : k === j ? "read" : "idle"))),
                track("merged", out, out.map((_, k) => (k === out.length - 1 ? "result" : "done"))),
              ],
              pointers: [
                ...(i < A.length ? [{ track: 0, index: i, label: "i" }] : []),
                ...(j < B.length ? [{ track: 1, index: j, label: "j" }] : []),
              ],
              counters: [count("taken from A", i, A.length), count("taken from B", j, B.length)],
              legend: LEG,
              happened: take === "A"
                ? `A's front ${v} is no larger than B's, so it goes next.`
                : `B's front ${v} is smaller, so it goes next.`,
              why: "Only one pointer moves, so each value is compared at most once.",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Answer: ${show(out)}`,
            tracks: [
              track("row A", A, fill(A.length, "done")),
              track("row B", B, fill(B.length, "done")),
              track("merged", out, fill(out.length, "result")),
            ],
            counters: [count("taken from A", A.length, A.length), count("taken from B", B.length, B.length)],
            legend: LEG,
            happened: `Both rows were consumed and the merged row is ${show(out)}.`,
            why: "Linear time follows from never revisiting a value.",
            codeLine: 8,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "next-permutation",
    title: "Next Permutation",
    category: "Array Techniques",
    difficulty: "Intermediate",
    description:
      "Rearrange the numbers into the next larger arrangement in dictionary order, in place.",
    input: { label: "The numbers", default: "1, 2, 3, 6, 5, 4", parse: "ints" },
    approaches: [
      {
        name: "Pivot, Swap, Reverse Suffix",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Scan from the right for the first value smaller than its neighbour. That pivot is the last place where the row can still grow.",
          "Swap it with the smallest larger value on its right, then reverse the suffix so it becomes the smallest possible tail.",
        ],
        problem: [
          "If the whole row is descending there is no pivot, and the only correct answer is the smallest arrangement — a full reversal.",
        ],
        code: {
          c: `#include <stdio.h>

static void reverse(int *a, int lo, int hi) {
    while (lo < hi) { int t = a[lo]; a[lo++] = a[hi]; a[hi--] = t; }
}

void next_permutation(int *a, int n) {
    int i = n - 2;
    while (i >= 0 && a[i] >= a[i + 1]) i--;
    if (i >= 0) {
        int j = n - 1;
        while (a[j] <= a[i]) j--;
        int t = a[i]; a[i] = a[j]; a[j] = t;
    }
    reverse(a, i + 1, n - 1);
}

int main(void) {
    int a[] = {1, 2, 3, 6, 5, 4};
    next_permutation(a, 6);              /* 1 2 4 3 5 6 */
    for (int i = 0; i < 6; i++) printf("%d ", a[i]);
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void nextPermutation(vector<int>& a) {
    int n = a.size(), i = n - 2;
    while (i >= 0 && a[i] >= a[i + 1]) i--;
    if (i >= 0) {
        int j = n - 1;
        while (a[j] <= a[i]) j--;
        swap(a[i], a[j]);
    }
    reverse(a.begin() + i + 1, a.end());
}

int main() {
    vector<int> a{1, 2, 3, 6, 5, 4};
    nextPermutation(a);
    for (int v : a) cout << v << ' '; // 1 2 4 3 5 6
    cout << '\\n';
}`,
        },
        steps(nums) {
          const a = nums.slice();
          const n = a.length;
          const steps = [];
          if (!n) {
            return [{
              title: "Give at least one value",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("length", 0)],
              legend: ["idle", "result"],
              happened: "An empty row has no permutations.",
              why: "The method scans for a pivot from the right.",
            }];
          }
          steps.push({
            title: `Look for a pivot from the right of ${show(a)}`,
            tracks: [track("numbers", a, fill(n, "idle"))],
            counters: [count("length", n), count("pivot", "?")],
            legend: LEG,
            happened: "The suffix is the part that can still be rearranged.",
            why: "A value larger than its right neighbour is the last place the row can grow.",
            codeLine: 7,
          });
          let i = n - 2;
          while (i >= 0 && a[i] >= a[i + 1]) {
            steps.push({
              title: `${a[i]} ≥ ${a[i + 1]} — suffix stays descending`,
              tracks: [track("numbers", a, (k) => (k > i ? "done" : k === i ? "read" : "idle"))],
              counters: [count("length", n), count("pivot", "not yet")],
              legend: LEG,
              happened: `${a[i]} cannot grow while ${a[i + 1]} is to its right, so the scan moves left.`,
              why: "Descending runs are already maximal and cannot be the pivot.",
              codeLine: 8,
            });
            i--;
          }
          if (i < 0) {
            a.reverse();
            steps.push({
              title: `No pivot: the row is descending, so reverse it`,
              tracks: [track("numbers", a, fill(n, "result"))],
              counters: [count("length", n), count("answer", "wrapped to smallest")],
              legend: LEG,
              happened: `The whole row was descending, so the next arrangement is the smallest one: ${show(a)}.`,
              why: "This is the wrap-around case after the last permutation.",
              codeLine: 14,
            });
            return steps;
          }
          steps.push({
            title: `Pivot found: ${a[i]} at index ${i}`,
            tracks: [track("numbers", a, (k) => (k === i ? "read" : k > i ? "done" : "idle"))],
            counters: [count("length", n), count("pivot", a[i])],
            legend: LEG,
            happened: `Everything after index ${i} is descending, so ${a[i]} is the value to bump.`,
            why: "Bumping the pivot is the smallest possible increase at this position.",
            codeLine: 9,
          });
          let j = n - 1;
          while (a[j] <= a[i]) {
            steps.push({
              title: `Skip ${a[j]}: not larger than ${a[i]}`,
              tracks: [track("numbers", a, (k) => (k === j ? "bad" : k === i ? "read" : "dim"))],
              counters: [count("length", n), count("scan from right", n - j)],
              legend: LEG,
              happened: `${a[j]} is too small to replace the pivot.`,
              why: "The suffix is descending, so the first larger-from-the-right is the smallest larger value.",
              codeLine: 12,
            });
            j--;
          }
          const t = a[i]; a[i] = a[j]; a[j] = t;
          steps.push({
            title: `Swap ${a[j]} with ${a[i]} → ${show(a)}`,
            tracks: [track("numbers", a, (k) => (k === i || k === j ? "swap" : k > i ? "done" : "idle"))],
            counters: [count("length", n), count("swapped", 1)],
            legend: LEG,
            happened: `The pivot becomes ${a[i]} and the old pivot takes the larger slot.`,
            why: "This is the smallest increase available at the pivot position.",
            codeLine: 13,
          });
          const tail = a.slice(i + 1).reverse();
          for (let k = 0; k < tail.length; k++) a[i + 1 + k] = tail[k];
          steps.push({
            title: `Reverse the suffix: ${show(a)}`,
            tracks: [track("numbers", a, (k) => (k > i ? "result" : "done"))],
            counters: [count("length", n), count("answer", show(a))],
            legend: LEG,
            happened: `The suffix is now ascending, which makes the whole row the next arrangement.`,
            why: "After the pivot the smallest possible tail is the sorted order, and reversing the descending suffix gives it.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "set-matrix-zeroes",
    title: "Set Matrix Zeroes",
    category: "Array Techniques",
    difficulty: "Intermediate",
    description:
      "If a cell is zero, blank its whole row and column — using the matrix itself as the marker board.",
    input: { label: "rows of numbers, comma separated", default: "1,1,1, 1,0,1, 1,1,1", parse: "ints" },
    approaches: [
      {
        name: "First Row and Column as Flags",
        complexity: "O(rows × cols) time, O(1) space",
        idea: [
          "Use the first row and first column to remember which lines must be cleared. A zero found in the body marks its row and column in those edges.",
          "Clear the body using those flags, then clear the edges last — their own flags have to survive until then.",
        ],
        problem: [
          "The first row and column need separate flags of their own, otherwise a zero there is indistinguishable from a marker.",
        ],
        code: {
          c: `#include <stdio.h>

void set_zeroes(int a[8][8], int rows, int cols) {
    int firstRow = 0, firstCol = 0;
    for (int c = 0; c < cols; c++) if (a[0][c] == 0) firstRow = 1;
    for (int r = 0; r < rows; r++) if (a[r][0] == 0) firstCol = 1;

    for (int r = 1; r < rows; r++)
        for (int c = 1; c < cols; c++)
            if (a[r][c] == 0) { a[r][0] = 0; a[0][c] = 0; }

    for (int r = 1; r < rows; r++)
        for (int c = 1; c < cols; c++)
            if (a[r][0] == 0 || a[0][c] == 0) a[r][c] = 0;

    if (firstRow) for (int c = 0; c < cols; c++) a[0][c] = 0;
    if (firstCol) for (int r = 0; r < rows; r++) a[r][0] = 0;
}

int main(void) {
    int a[3][3] = {{1,1,1},{1,0,1},{1,1,1}};
    set_zeroes(a, 3, 3);
    for (int r = 0; r < 3; r++) {
        for (int c = 0; c < 3; c++) printf("%d ", a[r][c]);
        printf("\\n");
    }
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

void setZeroes(vector<vector<int>>& a) {
    int rows = a.size(), cols = a[0].size();
    bool firstRow = false, firstCol = false;

    for (int c = 0; c < cols; c++) if (a[0][c] == 0) firstRow = true;
    for (int r = 0; r < rows; r++) if (a[r][0] == 0) firstCol = true;

    for (int r = 1; r < rows; r++)
        for (int c = 1; c < cols; c++)
            if (a[r][c] == 0) { a[r][0] = 0; a[0][c] = 0; }

    for (int r = 1; r < rows; r++)
        for (int c = 1; c < cols; c++)
            if (a[r][0] == 0 || a[0][c] == 0) a[r][c] = 0;

    if (firstRow) for (int c = 0; c < cols; c++) a[0][c] = 0;
    if (firstCol) for (int r = 0; r < rows; r++) a[r][0] = 0;
}

int main() {
    vector<vector<int>> a{{1,1,1},{1,0,1},{1,1,1}};
    setZeroes(a);
    for (auto& row : a) { for (int v : row) cout << v << ' '; cout << '\\n'; }
}`,
        },
        steps(nums) {
          const cols = 3;
          const rows = Math.ceil(nums.length / cols);
          const a = [];
          for (let r = 0; r < rows; r++) a.push(nums.slice(r * cols, r * cols + cols));
          const steps = [];
          const flat = () => grid(rows, cols, (r, c) => ({ v: a[r][c] == null ? "·" : a[r][c] }));
          const zeros = [];
          a.forEach((row, r) => row.forEach((v, c) => { if (v === 0) zeros.push([r, c]); }));
          steps.push({
            title: `${rows} × ${cols} matrix with ${zeros.length} zero${zeros.length === 1 ? "" : "s"}`,
            kind: "grid",
            rows, cols,
            cells: flat(),
            counters: [count("zeros found", zeros.length), count("cells", rows * cols)],
            legend: LEG,
            happened: zeros.length
              ? `Zeroes sit at ${zeros.map(([r, c]) => `(${r},${c})`).join(", ")}.`
              : "There are no zeroes, so nothing will change.",
            why: "Each zero forces its entire row and column to become zero.",
            codeLine: 4,
          });
          const rowsToClear = new Set(zeros.map(([r]) => r));
          const colsToClear = new Set(zeros.map(([, c]) => c));
          steps.push({
            title: `Rows ${[...rowsToClear].join(", ") || "none"} and columns ${[...colsToClear].join(", ") || "none"} must clear`,
            kind: "grid",
            rows, cols,
            cells: grid(rows, cols, (r, c) => ({
              v: a[r][c] == null ? "·" : a[r][c],
              state: zeros.some(([zr, zc]) => zr === r && zc === c) ? "bad" : rowsToClear.has(r) || colsToClear.has(c) ? "compare" : "idle",
            })),
            counters: [count("rows to clear", rowsToClear.size), count("columns to clear", colsToClear.size)],
            legend: LEG,
            happened: `The zeroes mark ${rowsToClear.size} row${rowsToClear.size === 1 ? "" : "s"} and ${colsToClear.size} column${colsToClear.size === 1 ? "" : "s"}.`,
            why: "Clearing rows and columns means their intersection is zero as well.",
            codeLine: 9,
          });
          for (const [r, c] of zeros) {
            steps.push({
              title: `Zero at (${r},${c}) flags row ${r} and column ${c}`,
              kind: "grid",
              rows, cols,
              rowHeads: Array.from({ length: rows }, (_, i) => `r${i}`),
              colHeads: Array.from({ length: cols }, (_, i) => `c${i}`),
              cells: grid(rows, cols, (rr, cc) => ({
                v: a[rr][cc] == null ? "·" : a[rr][cc],
                state: rr === r && cc === c ? "bad" : rr === r || cc === c ? "compare" : "idle",
              })),
              counters: [count("rows to clear", rowsToClear.size), count("columns to clear", colsToClear.size)],
              legend: LEG,
              happened: `This zero needs row ${r} and column ${c} blanked.`,
              why: "The first row and column store these flags so no extra arrays are needed.",
              codeLine: 10,
            });
          }
          const after = a.map((row, r) => row.map((v, c) => (rowsToClear.has(r) || colsToClear.has(c) ? 0 : v)));
          steps.push({
            title: `Answer: ${rowsToClear.size} row${rowsToClear.size === 1 ? "" : "s"} and ${colsToClear.size} column${colsToClear.size === 1 ? "" : "s"} zeroed`,
            kind: "grid",
            rows, cols,
            cells: grid(rows, cols, (r, c) => ({
              v: after[r][c] == null ? "·" : after[r][c],
              state: after[r][c] === 0 ? "result" : "done",
            })),
            counters: [count("cells zeroed", after.flat().filter((v) => v === 0).length), count("answer", "matrix updated")],
            legend: LEG,
            happened: `Every cell sharing a row or column with a zero is now 0.`,
            why: "Using the matrix's own edges keeps extra memory constant.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });
})();
