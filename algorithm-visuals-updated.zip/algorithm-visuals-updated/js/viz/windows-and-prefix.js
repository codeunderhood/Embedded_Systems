/* ============================================================
   DSA Visuals — Sliding Window & Prefix Sums
   Two windows and two difference arrays: both turn a range
   question into a running total.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const nums = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number);
  const show = (a) => `[${a.join(", ")}]`;
  const inWin = (i, lo, hi) => i >= lo && i < hi;

  /* ---------------------------------------------------------- */
  V.register({
    id: "minimum-size-subarray-sum",
    title: "Minimum Size Subarray Sum",
    category: "Sliding Window",
    difficulty: "Intermediate",
    description:
      "Find the shortest run of positive values whose sum reaches a target.",
    input: { label: "target | numbers", default: "7 | 2,3,1,2,4,3", parse: "string" },
    approaches: [
      {
        name: "Grow Right, Shrink Left",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Add values at the right edge until the running sum reaches the target.",
          "Then remove values from the left edge while the sum still reaches it, recording the shortest window seen.",
        ],
        problem: [
          "The shrinking step is only valid because values are positive; negatives would let the sum rise again after dropping.",
        ],
        code: {
          c: `#include <stdio.h>
#include <limits.h>

int min_subarray(int target, int *a, int n) {
    int left = 0, best = INT_MAX;
    long long sum = 0;

    for (int right = 0; right < n; right++) {
        sum += a[right];
        while (sum >= target) {
            int width = right - left + 1;
            if (width < best) best = width;
            sum -= a[left++];
        }
    }
    return best == INT_MAX ? 0 : best;
}

int main(void) {
    int a[] = {2, 3, 1, 2, 4, 3};
    printf("%d\\n", min_subarray(7, a, 6)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <climits>
using namespace std;

int minSubArrayLen(int target, const vector<int>& a) {
    int left = 0, best = INT_MAX;
    long long sum = 0;

    for (int right = 0; right < (int)a.size(); right++) {
        sum += a[right];
        while (sum >= target) {
            best = min(best, right - left + 1);
            sum -= a[left++];
        }
    }
    return best == INT_MAX ? 0 : best;
}

int main() {
    cout << minSubArrayLen(7, {2,3,1,2,4,3}) << '\\n'; // 2
}`,
        },
        steps(text) {
          const [tRaw, numsRaw] = parts(text);
          const target = parseInt(tRaw, 10) || 0;
          const a = nums(numsRaw);
          if (!a.length) {
            return [{
              title: "Give a target and positive values",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("target", target)],
              legend: ["idle", "result"],
              happened: "The window sum must reach the target.",
              why: "Positive values make the window sum monotone as it grows.",
            }];
          }
          const steps = [];
          let left = 0, sum = 0, best = Infinity, bestRange = null;
          steps.push({
            title: `Find the shortest run summing to at least ${target}`,
            tracks: [track("numbers", a, fill(a.length, "idle"))],
            counters: [count("sum", 0), count("best width", "∞")],
            legend: LEG,
            happened: "The right edge grows one value at a time.",
            why: "Once the sum is large enough, shrinking from the left is safe.",
            codeLine: 5,
          });
          for (let right = 0; right < a.length; right++) {
            sum += a[right];
            let shrank = false;
            while (sum >= target) {
              shrank = true;
              if (right - left + 1 < best) {
                best = right - left + 1;
                bestRange = [left, right];
              }
              sum -= a[left++];
            }
            steps.push({
              title: `Add ${a[right]} → sum ${sum}; window ${left}..${right}`,
              tracks: [
                track("numbers", a, a.map((_, i) => (i === right ? "read" : inWin(i, left, right + 1) ? "active" : i < left ? "dim" : "idle"))),
                chips("window", a.slice(left, right + 1), "active"),
              ],
              window: { from: left, to: right },
              counters: [count("sum", sum), count("best width", best === Infinity ? "∞" : best)],
              legend: LEG,
              happened: shrank
                ? `The sum reached the target, so the left edge advanced and the best width became ${best}.`
                : "The sum is still below the target, so the window keeps growing.",
              why: "The best width can only improve while the sum remains large enough.",
              codeLine: shrank ? 8 : 5,
            });
          }
          steps.push({
            title: best === Infinity ? "Answer: no subarray reaches the target" : `Answer: width ${best} at ${bestRange[0]}..${bestRange[1]}`,
            tracks: [
              track("numbers", a, a.map((_, i) => (bestRange && i >= bestRange[0] && i <= bestRange[1] ? "result" : "dim"))),
              chips("answer", [best === Infinity ? 0 : best], "result"),
            ],
            window: bestRange ? { from: bestRange[0], to: bestRange[1], label: "best window" } : null,
            counters: [count("best width", best === Infinity ? 0 : best), count("answer", best === Infinity ? 0 : best)],
            legend: LEG,
            happened: best === Infinity ? "Even the whole array is too small." : `The shortest qualifying run has ${best} value${best === 1 ? "" : "s"}.`,
            why: "Each index entered and left the window at most once.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-average-subarray",
    title: "Maximum Average Subarray",
    category: "Sliding Window",
    difficulty: "Beginner",
    description:
      "Find the fixed-width window with the largest average by updating a running sum.",
    input: { label: "numbers | k", default: "1,12,-5,-6,50,3 | 4", parse: "string" },
    approaches: [
      {
        name: "Fixed Window Running Sum",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Sum the first k values, then slide: add the entering value and subtract the leaving one.",
          "Because all windows have the same width, the largest average comes from the largest sum.",
        ],
        problem: [
          "Comparing floating point averages invites rounding error; compare the integer sums instead.",
        ],
        code: {
          c: `#include <stdio.h>

double max_average(int *a, int n, int k) {
    long long sum = 0;
    for (int i = 0; i < k; i++) sum += a[i];

    long long best = sum;
    for (int i = k; i < n; i++) {
        sum += a[i] - a[i - k];
        if (sum > best) best = sum;
    }
    return (double)best / k;
}

int main(void) {
    int a[] = {1, 12, -5, -6, 50, 3};
    printf("%.2f\\n", max_average(a, 6, 4)); /* 12.75 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <numeric>
using namespace std;

double findMaxAverage(const vector<int>& a, int k) {
    long long sum = 0;
    for (int i = 0; i < k; i++) sum += a[i];

    long long best = sum;
    for (int i = k; i < (int)a.size(); i++) {
        sum += a[i] - a[i - k];
        best = max(best, sum);
    }
    return (double)best / k;
}

int main() {
    cout << findMaxAverage({1,12,-5,-6,50,3}, 4) << '\\n'; // 12.75
}`,
        },
        steps(text) {
          const [numsRaw, kRaw] = parts(text);
          const a = nums(numsRaw);
          const k = Math.max(1, parseInt(kRaw, 10) || 1);
          if (!a.length || k > a.length) {
            return [{
              title: "Give numbers and a window width",
              tracks: [chips("numbers", a.length ? a : ["—"], "idle")],
              counters: [count("k", k), count("length", a.length)],
              legend: ["idle", "result"],
              happened: "The window width must not exceed the number of values.",
              why: "Every window contributes the same divisor k.",
            }];
          }
          const steps = [];
          let sum = 0;
          for (let i = 0; i < k; i++) sum += a[i];
          let best = sum, bestStart = 0;
          steps.push({
            title: `First window 0..${k - 1} sums to ${sum}`,
            tracks: [track("numbers", a, (i) => (i < k ? "active" : "idle")), chips("window sum", [sum], "result")],
            window: { from: 0, to: k - 1 },
            counters: [count("sum", sum), count("average", (sum / k).toFixed(2))],
            legend: LEG,
            happened: `The starting average is ${(sum / k).toFixed(2)}.`,
            why: "The first k values have to be summed directly.",
            codeLine: 3,
          });
          for (let start = 1; start + k <= a.length; start++) {
            sum += a[start + k - 1] - a[start - 1];
            const improved = sum > best;
            if (improved) { best = sum; bestStart = start; }
            steps.push({
              title: `Slide to ${start}..${start + k - 1}: add ${a[start + k - 1]}, remove ${a[start - 1]} → sum ${sum}`,
              tracks: [
                track("numbers", a, a.map((_, i) => (i === start - 1 ? "bad" : i === start + k - 1 ? "read" : inWin(i, start, start + k) ? "active" : "dim"))),
                chips("window", a.slice(start, start + k), "active"),
              ],
              window: { from: start, to: start + k - 1 },
              counters: [count("sum", sum), count("average", (sum / k).toFixed(2))],
              legend: LEG,
              happened: improved ? `A new best sum ${best} gives average ${(best / k).toFixed(2)}.` : `The sum ${sum} does not beat ${best}.`,
              why: "One addition and one subtraction update the whole window.",
              codeLine: 8,
            });
          }
          steps.push({
            title: `Answer: ${(best / k).toFixed(5)} (window ${bestStart}..${bestStart + k - 1})`,
            tracks: [
              track("numbers", a, a.map((_, i) => (inWin(i, bestStart, bestStart + k) ? "result" : "dim"))),
              chips("answer", [(best / k).toFixed(5)], "result"),
            ],
            window: { from: bestStart, to: bestStart + k - 1, label: "best window" },
            counters: [count("best sum", best), count("answer", (best / k).toFixed(5))],
            legend: LEG,
            happened: `The largest window sum is ${best}, so the largest average is ${(best / k).toFixed(5)}.`,
            why: "Equal widths mean the sum and the average peak at the same window.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "permutation-in-string",
    title: "Permutation in String",
    category: "Sliding Window",
    difficulty: "Intermediate",
    description:
      "Decide whether one text contains a permutation of another, using a fixed-size character window.",
    input: { label: "pattern | text", default: "ab | eidbaooo", parse: "string" },
    approaches: [
      {
        name: "Character Count Window",
        complexity: "O(n + m) time, O(alphabet) space",
        idea: [
          "A permutation has exactly the same character counts. Count the pattern, then slide a window of that width over the text.",
          "Maintain the window counts incrementally, or compare 26 counters, so each slide costs constant work.",
        ],
        problem: [
          "Comparing full count arrays per window still multiplies by the alphabet size; a running mismatch count removes that factor.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

int same_counts(int *a, int *b) {
    for (int i = 0; i < 26; i++) if (a[i] != b[i]) return 0;
    return 1;
}

int contains_permutation(const char *pat, const char *text) {
    int need[26] = {0}, window[26] = {0};
    int m = strlen(pat), n = strlen(text);
    if (m > n) return 0;
    for (int i = 0; i < m; i++) need[pat[i] - 'a']++;

    for (int i = 0; i < n; i++) {
        window[text[i] - 'a']++;
        if (i >= m) window[text[i - m] - 'a']--;
        if (i >= m - 1 && same_counts(need, window)) return 1;
    }
    return 0;
}

int main(void) {
    printf("%d\\n", contains_permutation("ab", "eidbaooo")); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
using namespace std;

bool checkInclusion(const string& pat, const string& text) {
    int m = pat.size(), n = text.size();
    if (m > n) return false;

    vector<int> need(26, 0), window(26, 0);
    for (char c : pat) need[c - 'a']++;

    for (int i = 0; i < n; i++) {
        window[text[i] - 'a']++;
        if (i >= m) window[text[i - m] - 'a']--;
        if (i >= m - 1 && window == need) return true;
    }
    return false;
}

int main() {
    cout << checkInclusion("ab", "eidbaooo") << '\\n'; // 1
}`,
        },
        steps(text) {
          const [patRaw, textRaw] = parts(text);
          const pat = Array.from(patRaw || "");
          const source = Array.from(textRaw || "");
          if (!pat.length || !source.length) {
            return [{
              title: "Give a pattern and a text",
              tracks: [chips("pattern", pat.length ? pat : ["—"], "idle"), chips("text", source.length ? source : ["—"], "idle")],
              counters: [count("pattern length", pat.length)],
              legend: ["idle", "result"],
              happened: "The pattern is the left field, the text the right.",
              why: "A permutation keeps exactly the pattern's letter counts.",
            }];
          }
          const need = new Map();
          for (const c of pat) need.set(c, (need.get(c) || 0) + 1);
          const countOf = (map) => [...map.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([c, n]) => `${c}×${n}`);
          const steps = [];
          const window = new Map();
          let found = null;
          steps.push({
            title: `Need counts ${countOf(need).join(", ")}; window width ${pat.length}`,
            tracks: [track("text", source, fill(source.length, "idle")), chips("need", countOf(need), "dim")],
            counters: [count("pattern length", pat.length), count("text length", source.length)],
            legend: LEG,
            happened: "Any window with these counts is a permutation.",
            why: "Order inside the window does not matter, only the counts.",
            codeLine: 6,
          });
          for (let i = 0; i < source.length; i++) {
            window.set(source[i], (window.get(source[i]) || 0) + 1);
            let leaving = null;
            if (i >= pat.length) {
              leaving = source[i - pat.length];
              window.set(leaving, window.get(leaving) - 1);
              if (window.get(leaving) === 0) window.delete(leaving);
            }
            let match = i >= pat.length - 1;
            if (match) {
              for (const [c, n] of need) if ((window.get(c) || 0) !== n) { match = false; break; }
              if (match && found == null) found = i - pat.length + 1;
            }
            steps.push({
              title: i >= pat.length - 1
                ? `Window ${i - pat.length + 1}..${i} counts ${countOf(window).join(", ")} → ${match ? "match" : "not yet"}`
                : `Window still filling: ${countOf(window).join(", ")}`,
              tracks: [
                track("text", source, source.map((_, j) => (j === i ? "read" : j === i - pat.length ? "bad" : inWin(j, Math.max(0, i - pat.length + 1), i + 1) ? "active" : j < i ? "dim" : "idle"))),
                chips("window counts", countOf(window), (k) => (match ? "good" : "active")),
                chips("need", countOf(need), "dim"),
              ],
              window: { from: Math.max(0, i - pat.length + 1), to: i, label: match ? "match" : "window" },
              counters: [count("position", i, source.length), count("matches", found != null ? 1 : 0)],
              legend: LEG,
              happened: leaving != null ? `${leaving} left the window as ${source[i]} entered.` : "The window is still growing to the pattern's width.",
              why: "Adding one character and removing one keeps every window count current.",
              codeLine: match ? 11 : 9,
            });
            if (match) break;
          }
          steps.push({
            title: found != null ? `Answer: yes, permutation at ${found}` : "Answer: no permutation",
            tracks: [
              track("text", source, source.map((_, i) => (found != null && inWin(i, found, found + pat.length) ? "result" : "dim"))),
              chips("answer", [found != null ? "yes" : "no"], "result"),
            ],
            window: found != null ? { from: found, to: found + pat.length - 1, label: "match" } : null,
            counters: [count("matches", found != null ? 1 : 0), count("answer", found != null ? found : -1)],
            legend: LEG,
            happened: found != null ? `Window ${found}..${found + pat.length - 1} is a permutation of the pattern.` : "No window had exactly the required counts.",
            why: "The window only moves forward, so the whole check is linear.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "sliding-window-maximum",
    title: "Sliding Window Maximum",
    category: "Sliding Window",
    difficulty: "Advanced",
    description:
      "Report the maximum of every window of width k using a decreasing deque of indices.",
    input: { label: "numbers | k", default: "1,3,-1,-3,5,3,6,7 | 3", parse: "string" },
    approaches: [
      {
        name: "Deque of Useful Indices",
        complexity: "O(n) time, O(k) space",
        idea: [
          "Keep indices in a deque whose values decrease from front to back. The front is always the current maximum.",
          "When a new value arrives, pop smaller values from the back because they can never be a future maximum; pop the front when it leaves the window.",
        ],
        problem: [
          "Storing values instead of indices makes it hard to know when the front has slid out of the window.",
        ],
        code: {
          c: `#include <stdio.h>

int deque[256];

void window_max(int *a, int n, int k) {
    int head = 0, tail = 0;

    for (int i = 0; i < n; i++) {
        while (tail > head && a[deque[tail - 1]] <= a[i]) tail--;
        deque[tail++] = i;

        if (deque[head] <= i - k) head++;
        if (i >= k - 1) printf("%d ", a[deque[head]]);
    }
    printf("\\n"); /* 3 3 5 5 6 7 */
}

int main(void) {
    int a[] = {1, 3, -1, -3, 5, 3, 6, 7};
    window_max(a, 8, 3);
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <deque>
using namespace std;

vector<int> maxSlidingWindow(const vector<int>& a, int k) {
    deque<int> dq;
    vector<int> out;

    for (int i = 0; i < (int)a.size(); i++) {
        while (!dq.empty() && a[dq.back()] <= a[i]) dq.pop_back();
        dq.push_back(i);
        if (dq.front() <= i - k) dq.pop_front();
        if (i >= k - 1) out.push_back(a[dq.front()]);
    }
    return out;
}

int main() {
    for (int v : maxSlidingWindow({1,3,-1,-3,5,3,6,7}, 3)) cout << v << ' '; // 3 3 5 5 6 7
    cout << '\\n';
}`,
        },
        steps(text) {
          const [numsRaw, kRaw] = parts(text);
          const a = nums(numsRaw);
          const k = Math.max(1, parseInt(kRaw, 10) || 1);
          if (!a.length) {
            return [{
              title: "Give numbers and a window width",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("k", k)],
              legend: ["idle", "result"],
              happened: "The deque holds indices, not values.",
              why: "Indices reveal when the front leaves the window.",
            }];
          }
          const steps = [];
          const dq = [];
          const out = [];
          steps.push({
            title: `Window width ${k}; deque values decrease from the front`,
            tracks: [track("numbers", a, fill(a.length, "idle")), chips("deque (indices)", ["—"], "dim")],
            counters: [count("k", k), count("maximums", 0)],
            legend: LEG,
            happened: "The front of the deque will always be the window maximum.",
            why: "Any value dominated by a later, larger value can never be the maximum while both are in the window.",
            codeLine: 4,
          });
          for (let i = 0; i < a.length; i++) {
            const popped = [];
            while (dq.length && a[dq[dq.length - 1]] <= a[i]) popped.push(dq.pop());
            dq.push(i);
            if (dq[0] <= i - k) dq.shift();
            const ready = i >= k - 1;
            if (ready) out.push(a[dq[0]]);
            steps.push({
              title: ready ? `Add ${a[i]}; window max is ${a[dq[0]]}` : `Add ${a[i]}; window still filling`,
              tracks: [
                track("numbers", a, a.map((_, j) => (j === i ? "read" : inWin(j, Math.max(0, i - k + 1), i + 1) ? "active" : j < i ? "dim" : "idle"))),
                chips("deque indices", dq.length ? dq : ["—"], (j) => (j === 0 ? "result" : "dim")),
                chips("deque values", dq.length ? dq.map((x) => a[x]) : ["—"], (j) => (j === 0 ? "result" : "dim")),
              ],
              window: ready ? { from: i - k + 1, to: i } : { from: 0, to: i },
              counters: [count("k", k), count("maximums", out.length)],
              legend: LEG,
              happened: popped.length
                ? `${popped.length} smaller index${popped.length === 1 ? " was" : "es were"} removed from the back.`
                : "The new value is not larger than the back, so the deque keeps its order.",
              why: "The deque stores only indices that could still become a maximum.",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Answer: ${show(out)}`,
            tracks: [chips("maximums", out, "result")],
            counters: [count("windows", out.length), count("answer", show(out))],
            legend: LEG,
            happened: `Each of the ${out.length} windows contributed its maximum.`,
            why: "Each index enters and leaves the deque at most once, so the total work is linear.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "range-sum-query",
    title: "Range Sum Query",
    category: "Prefix Sums",
    difficulty: "Beginner",
    description:
      "Answer many range-sum questions in constant time after building a prefix table.",
    input: { label: "numbers | left,right ; …", default: "-2,0,3,-5,2,-1 | 0,2 ; 2,5 ; 0,5", parse: "string" },
    approaches: [
      {
        name: "Prefix Sum Table",
        complexity: "O(n) build, O(1) per query",
        idea: [
          "Build prefix[i + 1] = prefix[i] + value at i, so prefix[i] is the sum of the first i values.",
          "The sum over left..right is prefix[right + 1] − prefix[left]. Two lookups replace a loop.",
        ],
        problem: [
          "The table must be rebuilt after any value changes; a mutable array needs a Fenwick tree instead.",
        ],
        code: {
          c: `#include <stdio.h>

int prefix[256];

void build(int *a, int n) {
    prefix[0] = 0;
    for (int i = 0; i < n; i++) prefix[i + 1] = prefix[i] + a[i];
}

int query(int left, int right) {
    return prefix[right + 1] - prefix[left];
}

int main(void) {
    int a[] = {-2, 0, 3, -5, 2, -1};
    build(a, 6);
    printf("%d %d\\n", query(0, 2), query(2, 5)); /* 1 -1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

class NumArray {
    vector<int> prefix;
public:
    explicit NumArray(const vector<int>& a) : prefix(a.size() + 1, 0) {
        for (int i = 0; i < (int)a.size(); i++) prefix[i + 1] = prefix[i] + a[i];
    }
    int sumRange(int left, int right) {
        return prefix[right + 1] - prefix[left];
    }
};

int main() {
    NumArray arr({-2,0,3,-5,2,-1});
    cout << arr.sumRange(0,2) << ' ' << arr.sumRange(2,5) << '\\n'; // 1 -1
}`,
        },
        steps(text) {
          const [numsRaw, queryRaw] = parts(text);
          const a = nums(numsRaw);
          const queries = String(queryRaw || "").split(";").map((q) => q.trim()).filter(Boolean).map((q) => q.split(",").map(Number));
          if (!a.length) {
            return [{
              title: "Give numbers and queries",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("queries", 0)],
              legend: ["idle", "result"],
              happened: "Queries are written as left,right pairs separated by semicolons.",
              why: "A prefix table makes every range sum two lookups.",
            }];
          }
          const steps = [];
          const prefix = [0];
          for (const v of a) prefix.push(prefix[prefix.length - 1] + v);
          steps.push({
            title: `Prefix sums: ${show(prefix)}`,
            tracks: [track("numbers", a, fill(a.length, "idle")), chips("prefix", prefix, "dim")],
            counters: [count("values", a.length), count("queries", queries.length)],
            legend: LEG,
            happened: "prefix[i] sums the first i values.",
            why: "Building the table is one accumulating pass.",
            codeLine: 3,
          });
          for (const [left, right] of queries) {
            if (Number.isNaN(left) || Number.isNaN(right)) continue;
            const sum = prefix[right + 1] - prefix[left];
            steps.push({
              title: `Query ${left}..${right}: ${prefix[right + 1]} − ${prefix[left]} = ${sum}`,
              tracks: [
                track("numbers", a, a.map((_, i) => (inWin(i, left, right + 1) ? "active" : "dim"))),
                chips("prefix", prefix, (i) => (i === left || i === right + 1 ? "result" : "dim")),
              ],
              counters: [count("sum", sum), count("queries done", queries.indexOf(queries.find((q) => q[0] === left && q[1] === right)) + 1, queries.length)],
              legend: LEG,
              happened: `The range contains the values ${a.slice(left, right + 1).join(", ")}.`,
              why: "Subtracting the prefix before the range removes everything outside it.",
              codeLine: 7,
            });
          }
          steps.push({
            title: `${queries.length} queries answered with two lookups each`,
            tracks: [chips("prefix", prefix, "result")],
            counters: [count("queries", queries.length), count("lookups per query", 2)],
            legend: LEG,
            happened: "No query needed to scan the values again.",
            why: "The prefix table turns range sums into a subtraction.",
            codeLine: 8,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "corporate-flight-bookings",
    title: "Corporate Flight Bookings",
    category: "Prefix Sums",
    difficulty: "Intermediate",
    description:
      "Apply many range reservations to a flight list with a difference array and one prefix pass.",
    input: { label: "first,last,seats ; … | flights", default: "1,2,10 ; 2,3,20 ; 2,5,25 | 5", parse: "string" },
    approaches: [
      {
        name: "Difference Array",
        complexity: "O(bookings + flights) time, O(flights) space",
        idea: [
          "A booking adds seats from first to last. Record +seats just before first and −seats just after last.",
          "A single prefix pass over those deltas reconstructs the seat count on every flight.",
        ],
        problem: [
          "The trick needs all bookings before the answer is read; interleaved queries would require a different structure.",
        ],
        code: {
          c: `#include <stdio.h>

int main(void) {
    int n = 5;
    int bookings[3][3] = {{1,2,10},{2,3,20},{2,5,25}};
    int diff[16] = {0};

    for (int i = 0; i < 3; i++) {
        int first = bookings[i][0] - 1, last = bookings[i][1] - 1, seats = bookings[i][2];
        diff[first] += seats;
        diff[last + 1] -= seats;
    }

    int running = 0;
    for (int i = 0; i < n; i++) {
        running += diff[i];
        printf("%d ", running);
    }
    printf("\\n"); /* 10 55 45 25 25 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

vector<int> corpFlightBookings(vector<vector<int>> bookings, int n) {
    vector<int> diff(n + 1, 0);

    for (auto& b : bookings) {
        diff[b[0] - 1] += b[2];
        diff[b[1]] -= b[2];
    }

    vector<int> seats(n);
    int running = 0;
    for (int i = 0; i < n; i++) {
        running += diff[i];
        seats[i] = running;
    }
    return seats;
}

int main() {
    for (int v : corpFlightBookings({{1,2,10},{2,3,20},{2,5,25}}, 5)) cout << v << ' '; // 10 55 45 25 25
    cout << '\\n';
}`,
        },
        steps(text) {
          const [bookRaw, nRaw] = parts(text);
          const n = Math.max(1, parseInt(nRaw, 10) || 1);
          const bookings = String(bookRaw || "").split(";").map((b) => b.trim()).filter(Boolean).map((b) => b.split(",").map(Number));
          const steps = [];
          const diff = Array(n + 1).fill(0);
          steps.push({
            title: `${bookings.length} bookings over ${n} flights`,
            tracks: [chips("bookings", bookings.map((b) => `${b[0]}–${b[1]}: +${b[2]}`), "dim"), chips("difference", diff, "idle")],
            counters: [count("flights", n), count("bookings", bookings.length)],
            legend: LEG,
            happened: "Each booking becomes two delta entries.",
            why: "A range addition becomes one start increase and one end decrease.",
            codeLine: 4,
          });
          for (const [first, last, seats] of bookings) {
            diff[first - 1] += seats;
            diff[last] -= seats;
            steps.push({
              title: `Booking ${first}–${last}: +${seats} at ${first - 1}, −${seats} at ${last}`,
              tracks: [
                chips("difference", diff, (i) => (i === first - 1 || i === last ? "active" : "dim")),
                chips("booking", [`${first}–${last}: +${seats}`], "read"),
              ],
              counters: [count("bookings applied", bookings.indexOf(bookings.find((b) => b[0] === first && b[1] === last && b[2] === seats)) + 1, bookings.length), count("deltas", diff.filter((v) => v !== 0).length)],
              legend: LEG,
              happened: `Only the two boundary slots change, not every flight in between.`,
              why: "The prefix pass will carry the increase across the whole range.",
              codeLine: 5,
            });
          }
          const seats = [];
          let running = 0;
          for (let i = 0; i < n; i++) {
            running += diff[i];
            seats.push(running);
            steps.push({
              title: `Flight ${i + 1}: running ${running}`,
              tracks: [
                chips("difference", diff, (i2) => (i2 === i ? "read" : "dim")),
                chips("seats", seats, "result"),
              ],
              counters: [count("flight", i + 1, n), count("seats", running)],
              legend: LEG,
              happened: `The accumulated delta is the seat count on flight ${i + 1}.`,
              why: "The prefix pass replays every boundary change in order.",
              codeLine: 12,
            });
          }
          steps.push({
            title: `Answer: ${show(seats)}`,
            tracks: [chips("seats", seats, "result")],
            counters: [count("flights", n), count("answer", show(seats))],
            legend: LEG,
            happened: `All ${bookings.length} bookings were applied in one pass.`,
            why: "Range additions cost constant time each, and the rebuild costs one pass.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "car-pooling",
    title: "Car Pooling",
    category: "Prefix Sums",
    difficulty: "Intermediate",
    description:
      "Check whether every ride fits in the car by tracking passenger changes at each stop.",
    input: { label: "passengers,from,to ; … | capacity", default: "2,1,5 ; 3,3,7 | 4", parse: "string" },
    approaches: [
      {
        name: "Difference Array Over Stops",
        complexity: "O(trips + stops) time, O(stops) space",
        idea: [
          "Passengers board at from and leave at to, so record +passengers at from and −passengers at to.",
          "A prefix pass gives the load at every stop; if any load exceeds capacity, the plan is impossible.",
        ],
        problem: [
          "Coordinates must be bounded to size an array; sparse or huge stops need sorting or a map instead.",
        ],
        code: {
          c: `#include <stdio.h>

int feasible(int trips[][3], int t, int capacity, int stops) {
    int diff[1024] = {0};

    for (int i = 0; i < t; i++) {
        diff[trips[i][1]] += trips[i][0];
        diff[trips[i][2]] -= trips[i][0];
    }

    int load = 0;
    for (int s = 0; s < stops; s++) {
        load += diff[s];
        if (load > capacity) return 0;
    }
    return 1;
}

int main(void) {
    int trips[2][3] = {{2,1,5},{3,3,7}};
    printf("%d\\n", feasible(trips, 2, 4, 8)); /* 0 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

bool carPooling(vector<vector<int>> trips, int capacity) {
    vector<int> diff(1001, 0);
    for (auto& t : trips) {
        diff[t[1]] += t[0];
        diff[t[2]] -= t[0];
    }

    int load = 0;
    for (int stops = 0; stops <= 1000; stops++) {
        load += diff[stops];
        if (load > capacity) return false;
    }
    return true;
}

int main() {
    cout << carPooling({{2,1,5},{3,3,7}}, 4) << '\\n'; // 0
}`,
        },
        steps(text) {
          const [tripRaw, capRaw] = parts(text);
          const capacity = Math.max(0, parseInt(capRaw, 10) || 0);
          const trips = String(tripRaw || "").split(";").map((t) => t.trim()).filter(Boolean).map((t) => t.split(",").map(Number));
          const lastStop = Math.max(1, ...trips.map((t) => t[2] || 0));
          const diff = Array(lastStop + 1).fill(0);
          const steps = [];
          steps.push({
            title: `${trips.length} trips, capacity ${capacity}`,
            tracks: [chips("trips", trips.map((t) => `${t[0]}p ${t[1]}→${t[2]}`), "dim"), chips("delta", diff, "idle")],
            counters: [count("capacity", capacity), count("stops", lastStop)],
            legend: LEG,
            happened: "Passengers change only at the endpoints of each trip.",
            why: "The load between stops is constant, so endpoints are enough.",
            codeLine: 4,
          });
          for (const [people, from, to] of trips) {
            diff[from] += people;
            diff[to] -= people;
            steps.push({
              title: `Trip ${from}→${to}: +${people} at ${from}, −${people} at ${to}`,
              tracks: [chips("delta", diff, (i) => (i === from || i === to ? "active" : "dim")), chips("load", ["—"], "idle")],
              counters: [count("capacity", capacity), count("deltas", diff.filter((v) => v !== 0).length)],
              legend: LEG,
              happened: `The two boundary positions record the boarding and leaving.`,
              why: "No intermediate stop needs to know about this trip.",
              codeLine: 5,
            });
          }
          let load = 0, over = -1;
          const loads = [];
          for (let s = 0; s <= lastStop; s++) {
            load += diff[s];
            loads.push(load);
            if (load > capacity && over < 0) over = s;
            steps.push({
              title: `Stop ${s}: load ${load}${load > capacity ? " — over capacity" : ""}`,
              tracks: [
                chips("delta", diff, (i) => (i === s ? "read" : "dim")),
                chips("load", loads, (i) => (loads[i] > capacity ? "bad" : "good")),
              ],
              counters: [count("load", load), count("capacity", capacity)],
              legend: LEG,
              happened: load > capacity ? "The car would carry more passengers than it has seats." : "The load stays within capacity.",
              why: "The prefix of the deltas is the actual number of passengers in the car.",
              codeLine: 10,
            });
          }
          steps.push({
            title: over < 0 ? "Answer: feasible" : `Answer: not feasible at stop ${over}`,
            tracks: [chips("loads", loads, (i) => (loads[i] > capacity ? "bad" : "result"))],
            counters: [count("peak load", Math.max(...loads, 0)), count("answer", over < 0 ? "yes" : "no")],
            legend: LEG,
            happened: over < 0 ? "Every stop stayed at or below capacity." : `Stop ${over} required ${loads[over]} seats.`,
            why: "One pass over the endpoints settles every stop at once.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "employee-free-time",
    title: "Employee Free Time",
    category: "Prefix Sums",
    difficulty: "Advanced",
    description:
      "Find the common gaps in everyone's schedule by merging all busy intervals.",
    input: { label: "employee intervals (start,end) separated by |", default: "1,2 5,6 | 1,3 | 4,10", parse: "string" },
    approaches: [
      {
        name: "Merge All Busy Intervals",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Free time for everyone is the complement of the union of all busy intervals, so merge every interval into disjoint blocks.",
          "Every gap between consecutive merged blocks is shared free time.",
        ],
        problem: [
          "Employee identity no longer matters after merging, which is fine for common free time but not for per-person availability.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int start, end; } Interval;
static int by_start(const void *a, const void *b) {
    return ((const Interval *)a)->start - ((const Interval *)b)->start;
}

int main(void) {
    Interval all[] = {{1,2},{5,6},{1,3},{4,10}};
    int n = 4;
    qsort(all, n, sizeof(Interval), by_start);

    int curStart = all[0].start, curEnd = all[0].end;
    for (int i = 1; i < n; i++) {
        if (all[i].start > curEnd) {
            printf("[%d,%d] ", curEnd, all[i].start);   /* gap */
            curStart = all[i].start;
            curEnd = all[i].end;
        } else if (all[i].end > curEnd) {
            curEnd = all[i].end;
        }
    }
    printf("\\n"); /* [3,4] */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

vector<vector<int>> employeeFreeTime(vector<vector<vector<int>>> schedules) {
    vector<vector<int>> all;
    for (auto& person : schedules)
        for (auto& iv : person) all.push_back(iv);

    sort(all.begin(), all.end());
    vector<vector<int>> freeTime;

    int end = all[0][1];
    for (int i = 1; i < (int)all.size(); i++) {
        if (all[i][0] > end) freeTime.push_back({end, all[i][0]});
        end = max(end, all[i][1]);
    }
    return freeTime;
}

int main() {
    auto gaps = employeeFreeTime({{{1,2},{5,6}},{{1,3}},{{4,10}}});
    for (auto& g : gaps) cout << '[' << g[0] << ',' << g[1] << "] "; // [3,4]
    cout << '\\n';
}`,
        },
        steps(text) {
          const groups = parts(text).map((g) => String(g || "").split(/\s+/).filter(Boolean).map((p) => p.split(",").map(Number))).filter((g) => g.length);
          const all = [];
          groups.forEach((g, employee) => g.forEach(([start, end]) => all.push({ start, end, employee })));
          if (!all.length) {
            return [{
              title: "Give busy intervals for each employee",
              tracks: [chips("intervals", ["—"], "idle")],
              counters: [count("intervals", 0)],
              legend: ["idle", "result"],
              happened: "Employees are separated by | and intervals by spaces.",
              why: "Common free time is the complement of all busy time.",
            }];
          }
          all.sort((a, b) => a.start - b.start || a.end - b.end);
          const steps = [];
          steps.push({
            title: `Merge ${all.length} busy intervals from ${groups.length} employee${groups.length === 1 ? "" : "s"}`,
            tracks: [chips("intervals", all.map((iv) => `${iv.start}–${iv.end}(e${iv.employee + 1})`), "dim")],
            counters: [count("intervals", all.length), count("merged", 0)],
            legend: LEG,
            happened: `Sorted by start: ${all.map((iv) => `${iv.start}–${iv.end}`).join(", ")}.`,
            why: "Any overlap joins one busy block, so gaps only appear between blocks.",
            codeLine: 9,
          });
          const merged = [];
          const gaps = [];
          let cur = { ...all[0] };
          for (let i = 1; i < all.length; i++) {
            const iv = all[i];
            if (iv.start > cur.end) {
              merged.push(cur);
              gaps.push([cur.end, iv.start]);
              steps.push({
                title: `Gap ${cur.end}–${iv.start}: nobody is busy`,
                tracks: [
                  chips("merged busy", merged.map((m) => `${m.start}–${m.end}`), "done"),
                  chips("gap", [`${cur.end}–${iv.start}`], "result"),
                  chips("next", [`${iv.start}–${iv.end}`], "read"),
                ],
                counters: [count("merged", merged.length), count("gaps", gaps.length)],
                legend: LEG,
                happened: `The previous block ended at ${cur.end} and the next begins at ${iv.start}.`,
                why: "A strict gap between merged blocks is time when every employee is free.",
                codeLine: 12,
              });
              cur = { ...iv };
            } else {
              if (iv.end > cur.end) cur.end = iv.end;
              steps.push({
                title: `${iv.start}–${iv.end} overlaps; extend the block to ${cur.start}–${cur.end}`,
                tracks: [chips("merged busy", merged.concat([cur]).map((m) => `${m.start}–${m.end}`), (j) => (j === merged.length ? "active" : "done"))],
                counters: [count("merged", merged.length + 1), count("gaps", gaps.length)],
                legend: LEG,
                happened: "Overlapping intervals melt into the current block.",
                why: "Busy time cannot contain free time for anyone.",
                codeLine: 15,
              });
            }
          }
          merged.push(cur);
          steps.push({
            title: gaps.length ? `Answer: ${gaps.map((g) => `[${g[0]}, ${g[1]}]`).join(" ")}` : "Answer: no common free time",
            tracks: [
              chips("busy blocks", merged.map((m) => `${m.start}–${m.end}`), "dim"),
              chips("free gaps", gaps.length ? gaps.map((g) => `${g[0]}–${g[1]}`) : ["none"], "result"),
            ],
            counters: [count("busy blocks", merged.length), count("gaps", gaps.length)],
            legend: LEG,
            happened: gaps.length ? `There are ${gaps.length} shared gap${gaps.length === 1 ? "" : "s"}.` : "The busy blocks touch or overlap everywhere.",
            why: "Only gaps between merged blocks are free for every employee.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });
})();
