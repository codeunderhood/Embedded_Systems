/* ============================================================
   DSA Visuals - extra two-pointer problems (outside NeetCode 250)
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, states) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof states === "function" ? states(i) : states || "idle",
    })),
  });
  const frame = (title, tracks, counters, happened, why, codeLine, extra) =>
    Object.assign({ title, tracks, counters, happened, why, legend: LEG, codeLine }, extra || {});
  const ptr = (index, label, t) => ({ track: t || 0, index, label });

  /* ---------------------------------------------------------- */
  V.register({
    id: "squares-of-a-sorted-array",
    title: "Squares of a Sorted Array",
    category: "Two Pointers",
    difficulty: "Beginner",
    description: "Square a sorted list and return the squares in sorted order.",
    input: { label: "numbers", default: "-4, -1, 0, 3, 10", parse: "ints" },
    approaches: [
      {
        name: "Largest Magnitude First",
        complexity: "O(n) time, O(n) space",
        idea: [
          "In a sorted list, the largest squares come from the two ends because those values have the greatest magnitudes.",
          "Compare the end squares, write the larger one into the last free slot, and move that pointer inward.",
        ],
        problem: [
          "The result must be a new array: squaring a negative value can change the order, so overwriting the input would destroy values still needed.",
        ],
        code: {
          c: `#include <stdlib.h>

int* sortedSquares(int* nums, int n, int* returnSize) {
    int* ans = malloc(n * sizeof(int));
    int left = 0, right = n - 1, k = n - 1;
    while (left <= right) {
        int l = nums[left] * nums[left];
        int r = nums[right] * nums[right];
        if (l > r) ans[k--] = l, left++;
        else ans[k--] = r, right--;
    }
    *returnSize = n;
    return ans;
}`,
          cpp: `#include <vector>
using namespace std;

vector<int> sortedSquares(vector<int>& nums) {
    int n = (int)nums.size();
    vector<int> ans(n);
    int left = 0, right = n - 1, k = n - 1;
    while (left <= right) {
        int l = nums[left] * nums[left];
        int r = nums[right] * nums[right];
        if (l > r) ans[k--] = l, left++;
        else ans[k--] = r, right--;
    }
    return ans;
}`,
        },
        steps(nums) {
          const n = nums.length;
          const ans = new Array(n).fill("-");
          const out = [];
          let left = 0, right = n - 1, k = n - 1;
          out.push(frame(
            "Fill the answer from the back",
            [track("input", nums, nums.map((_, i) => (i === 0 || i === n - 1 ? "compare" : "idle"))), track("answer", ans, fill(n, "idle"))],
            [count("left", left), count("right", right), count("write slot", k)],
            `The end values are ${nums[0]} and ${nums[n - 1]}; their squares compete for the last slot.`,
            "Extreme magnitudes give the largest squares, so the answer is built from right to left.",
            5,
            { pointers: [ptr(0, "L"), ptr(n - 1, "R")] }
          ));
          while (left <= right) {
            const l = nums[left] * nums[left];
            const r = nums[right] * nums[right];
            const fromLeft = l > r;
            const chosen = fromLeft ? left : right;
            ans[k] = fromLeft ? l : r;
            const states = nums.map((_, i) =>
              i === chosen ? "good" : i === (fromLeft ? right : left) ? "compare" : i < left || i > right ? "done" : "idle"
            );
            out.push(frame(
              `Write ${ans[k]} into slot ${k}`,
              [track("input", nums, states), track("answer", ans, ans.map((_, i) => (i === k ? "result" : i > k ? "done" : "idle")))],
              [count("left", left), count("right", right), count("write slot", k), count("filled", n - k, n)],
              `${l} versus ${r}: the square of ${nums[chosen]} is larger, so it goes to index ${k}.`,
              "Placing the largest remaining square first keeps the answer sorted without a second sort.",
              fromLeft ? 8 : 9,
              { pointers: left < right ? [ptr(left, "L"), ptr(right, "R")] : [ptr(left, "L")] }
            ));
            if (fromLeft) left++; else right--;
            k--;
          }
          out.push(frame(
            `Squares: ${ans.join(", ")}`,
            [track("input", nums, fill(n, "done")), track("answer", ans, fill(n, "result"))],
            [count("filled", n, n), count("answer", ans.join(","))],
            `The completed answer is ${ans.join(", ")}.`,
            "Every input value contributed exactly one square in nondecreasing order.",
            12
          ));
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "remove-duplicates-from-sorted-array-ii",
    title: "Remove Duplicates from Sorted Array II",
    category: "Two Pointers",
    difficulty: "Intermediate",
    description: "Compact a sorted array in place so no value appears more than twice.",
    input: { label: "numbers", default: "1, 1, 1, 2, 2, 3", parse: "ints" },
    approaches: [
      {
        name: "Two Back Compare",
        complexity: "O(n) time, O(1) space",
        idea: [
          "A slow write pointer marks the next free slot of the kept prefix. A fast read pointer inspects every original value once.",
          "A value is kept only when it differs from the element two slots before the write pointer; that element is the last one that would make a third copy.",
        ],
        problem: [
          "Only the prefix up to the write pointer is valid; the unused tail keeps stale values and is ignored by the caller.",
        ],
        code: {
          c: `#include <stdio.h>

int removeDuplicates(int* nums, int n) {
    int write = n < 2 ? n : 2;
    for (int read = 2; read < n; read++) {
        if (nums[read] != nums[write - 2]) {
            nums[write++] = nums[read];
        }
    }
    return write;
}`,
          cpp: `#include <vector>
using namespace std;

int removeDuplicates(vector<int>& nums) {
    int write = nums.size() < 2 ? (int)nums.size() : 2;
    for (int read = 2; read < (int)nums.size(); read++) {
        if (nums[read] != nums[write - 2]) {
            nums[write++] = nums[read];
        }
    }
    return write;
}`,
        },
        steps(nums) {
          const n = nums.length;
          const a = nums.slice();
          const out = [];
          let write = n < 2 ? n : 2;
          let rejected = 0;
          out.push(frame(
            "Allow at most two copies",
            [track("numbers", a, a.map((_, i) => (i < write ? "good" : "idle"))), chips("kept prefix", a.slice(0, write), "result")],
            [count("write", write), count("read", 2, n)],
            `The first ${write} values start in the kept prefix; a third equal value must be rejected.`,
            "Comparing with the value two kept slots back tells us whether two copies are already present.",
            3
          ));
          for (let read = 2; read < n; read++) {
            const prev = a[write - 2];
            out.push(frame(
              `Compare ${a[read]} with ${prev}`,
              [track("numbers", a, a.map((_, i) => (i === read || i === write - 2 ? "compare" : i < write ? "done" : "idle"))), chips("kept prefix", a.slice(0, write), "done")],
              [count("read", read, n), count("write", write), count("two slots back", prev)],
              `Index ${read} holds ${a[read]}; two kept slots back holds ${prev}.`,
              "A new value may be written only when it differs from the element two positions earlier in the kept prefix.",
              5,
              { pointers: [ptr(read, "read"), ptr(write - 2, "keep")] }
            ));
            if (a[read] !== prev) {
              a[write] = a[read];
              out.push(frame(
                `Keep ${a[write]} at index ${write}`,
                [track("numbers", a, a.map((_, i) => (i === write ? "good" : i === read ? "read" : i < write ? "done" : "idle"))), chips("kept prefix", a.slice(0, write + 1), "good")],
                [count("read", read, n), count("write", write + 1), count("kept", write + 1, n)],
                `${a[read]} is different enough, so it is copied into the kept prefix.`,
                "Writing at the slow pointer and advancing it closes every gap left by rejected values.",
                6
              ));
              write++;
            } else {
              rejected++;
              out.push(frame(
                `Reject the extra ${a[read]}`,
                [track("numbers", a, a.map((_, i) => (i === read ? "bad" : i < write ? "done" : "idle"))), chips("kept prefix", a.slice(0, write), "good")],
                [count("read", read, n), count("write", write), count("rejected", rejected)],
                `${a[read]} already appears twice in the kept prefix, so this copy is skipped.`,
                "Writing a third copy would break the at-most-two rule.",
                5
              ));
            }
          }
          out.push(frame(
            `New length ${write}`,
            [track("numbers", a, a.map((_, i) => (i < write ? "result" : "dim"))), chips("kept prefix", a.slice(0, write), "result")],
            [count("new length", write, n), count("removed", n - write)],
            `The valid prefix is ${a.slice(0, write).join(", ")}.`,
            "Only the first write positions belong to the answer; the tail is ignored.",
            9
          ));
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "intersection-of-two-arrays-ii",
    title: "Intersection of Two Arrays II",
    category: "Two Pointers",
    difficulty: "Beginner",
    description: "Return the shared values of two lists, counting every duplicate occurrence.",
    input: { label: "A | B", default: "1, 2, 2, 1 | 2, 2, 3, 1", parse: "tworows" },
    approaches: [
      {
        name: "Sort Then Walk",
        complexity: "O(n log n + m log m) time, O(min(n, m)) space",
        idea: [
          "Sort both lists, then keep one pointer in each. Equal values form one entry of the answer and consume both pointers.",
          "When the values differ, only the smaller pointer can advance: a larger value cannot match anything earlier in the other sorted list.",
        ],
        problem: [
          "The input arrays are reordered, which is fine because the answer is a multiset rather than a sequence.",
        ],
        code: {
          c: `#include <stdlib.h>

int cmp(const void* a, const void* b) {
    int x = *(const int*)a, y = *(const int*)b;
    return (x > y) - (x < y);
}

int* intersect(int* a, int n, int* b, int m, int* returnSize) {
    qsort(a, n, sizeof(int), cmp);
    qsort(b, m, sizeof(int), cmp);
    int* ans = malloc((n < m ? n : m) * sizeof(int));
    int i = 0, j = 0, k = 0;
    while (i < n && j < m) {
        if (a[i] < b[j]) i++;
        else if (a[i] > b[j]) j++;
        else { ans[k++] = a[i]; i++; j++; }
    }
    *returnSize = k;
    return ans;
}`,
          cpp: `#include <algorithm>
#include <vector>
using namespace std;

vector<int> intersect(vector<int>& a, vector<int>& b) {
    sort(a.begin(), a.end());
    sort(b.begin(), b.end());
    vector<int> ans;
    int i = 0, j = 0;
    while (i < (int)a.size() && j < (int)b.size()) {
        if (a[i] < b[j]) i++;
        else if (a[i] > b[j]) j++;
        else { ans.push_back(a[i]); i++; j++; }
    }
    return ans;
}`,
        },
        steps(parsed) {
          const A = (parsed[0] || []).slice().sort((x, y) => x - y);
          const B = (parsed[1] || []).slice().sort((x, y) => x - y);
          const ans = [];
          const out = [];
          let i = 0, j = 0;
          out.push(frame(
            "Sort both lists first",
            [track("A sorted", A, A.map((_, k) => (k === 0 ? "read" : "idle"))), track("B sorted", B, B.map((_, k) => (k === 0 ? "read" : "idle"))), chips("common", [], "idle")],
            [count("A pointer", i, A.length), count("B pointer", j, B.length)],
            `After sorting: A = ${A.join(", ")}, B = ${B.join(", ")}.`,
            "Sorting turns duplicate matching into a single left-to-right walk of both lists.",
            9,
            { pointers: [ptr(0, "i"), ptr(0, "j", 1)] }
          ));
          while (i < A.length && j < B.length) {
            out.push(frame(
              `Compare ${A[i]} and ${B[j]}`,
              [track("A sorted", A, A.map((_, k) => (k === i ? "compare" : k < i ? "done" : "idle"))), track("B sorted", B, B.map((_, k) => (k === j ? "compare" : k < j ? "done" : "idle"))), chips("common", ans, "done")],
              [count("A pointer", i, A.length), count("B pointer", j, B.length), count("matches", ans.length)],
              `The current values are ${A[i]} in A and ${B[j]} in B.`,
              "The smaller value cannot match any later value in the other sorted list.",
              9,
              { pointers: [ptr(i, "i"), ptr(j, "j", 1)] }
            ));
            if (A[i] < B[j]) {
              out.push(frame(
                `Skip ${A[i]} in A`,
                [track("A sorted", A, A.map((_, k) => (k === i ? "bad" : k < i ? "done" : "idle"))), track("B sorted", B, B.map((_, k) => (k === j ? "read" : "idle"))), chips("common", ans, "done")],
                [count("A pointer", i + 1, A.length), count("B pointer", j, B.length), count("matches", ans.length)],
                `${A[i]} is smaller than ${B[j]}, so A's pointer advances.`,
                "Every remaining B value is at least B[j], so this A value has no partner.",
                10,
                { pointers: [ptr(i, "i"), ptr(j, "j", 1)] }
              ));
              i++;
            } else if (A[i] > B[j]) {
              out.push(frame(
                `Skip ${B[j]} in B`,
                [track("A sorted", A, A.map((_, k) => (k === i ? "read" : "idle"))), track("B sorted", B, B.map((_, k) => (k === j ? "bad" : k < j ? "done" : "idle"))), chips("common", ans, "done")],
                [count("A pointer", i, A.length), count("B pointer", j + 1, B.length), count("matches", ans.length)],
                `${B[j]} is smaller than ${A[i]}, so B's pointer advances.`,
                "Every remaining A value is at least A[i], so this B value has no partner.",
                11,
                { pointers: [ptr(i, "i"), ptr(j, "j", 1)] }
              ));
              j++;
            } else {
              ans.push(A[i]);
              out.push(frame(
                `Match ${A[i]}`,
                [track("A sorted", A, A.map((_, k) => (k === i ? "good" : k < i ? "done" : "idle"))), track("B sorted", B, B.map((_, k) => (k === j ? "good" : k < j ? "done" : "idle"))), chips("common", ans, "result")],
                [count("A pointer", i + 1, A.length), count("B pointer", j + 1, B.length), count("matches", ans.length)],
                `Both lists hold ${A[i]}, so one occurrence joins the answer.`,
                "Consuming one item from each list lets repeated values be reported as many times as they appear in both.",
                12,
                { pointers: [ptr(i, "i"), ptr(j, "j", 1)] }
              ));
              i++;
              j++;
            }
          }
          out.push(frame(
            `Intersection: ${ans.join(", ")}`,
            [track("A sorted", A, fill(A.length, "done")), track("B sorted", B, fill(B.length, "done")), chips("common", ans, "result")],
            [count("matches", ans.length), count("smaller input", Math.min(A.length, B.length))],
            `The shared values, with multiplicity, are ${ans.join(", ")}.`,
            "Each equal pair contributed exactly one output value, so no duplicate was lost or invented.",
            13
          ));
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "sort-array-by-parity",
    title: "Sort Array by Parity",
    category: "Two Pointers",
    difficulty: "Beginner",
    description: "Group every even value before every odd value, in any order.",
    input: { label: "numbers", default: "3, 1, 2, 4", parse: "ints" },
    approaches: [
      {
        name: "Swap Misplaced Ends",
        complexity: "O(n) time, O(1) space",
        idea: [
          "The left pointer searches for an odd value and the right pointer searches for an even value.",
          "When both are found, swapping them fixes two wrong positions at once; values already on the correct side are skipped.",
        ],
        problem: [
          "The relative order inside the even group and inside the odd group is not preserved, which this problem allows.",
        ],
        code: {
          c: `#include <stdio.h>

void sortArrayByParity(int* nums, int n) {
    int left = 0, right = n - 1;
    while (left < right) {
        while (left < right && nums[left] % 2 == 0) left++;
        while (left < right && nums[right] % 2 == 1) right--;
        if (left < right) {
            int t = nums[left];
            nums[left] = nums[right];
            nums[right] = t;
            left++;
            right--;
        }
    }
}`,
          cpp: `#include <vector>
using namespace std;

vector<int> sortArrayByParity(vector<int>& nums) {
    int left = 0, right = (int)nums.size() - 1;
    while (left < right) {
        while (left < right && nums[left] % 2 == 0) left++;
        while (left < right && nums[right] % 2 == 1) right--;
        if (left < right) {
            int t = nums[left];
            nums[left] = nums[right];
            nums[right] = t;
            left++;
            right--;
        }
    }
    return nums;
}`,
        },
        steps(nums) {
          const a = nums.slice(), n = a.length, out = [];
          let left = 0, right = n - 1, scan = 0;
          const ends = () => chips("ends", [a[left] % 2 ? "odd" : "even", a[right] % 2 ? "odd" : "even"], "compare");
          out.push(frame(
            "Work inward from both ends",
            [track("numbers", a, a.map((_, i) => (i === left || i === right ? "compare" : "idle"))), ends()],
            [count("left", left), count("right", right), count("moves", scan)],
            `The ends hold ${a[left]} and ${a[right]}; evens belong on the left, odds on the right.`,
            "A misplaced value can only be fixed by exchanging it with a misplaced value from the other end.",
            4,
            { pointers: [ptr(left, "L"), ptr(right, "R")] }
          ));
          while (left < right) {
            while (left < right && a[left] % 2 === 0) {
              scan++;
              out.push(frame(
                `Index ${left} already holds an even value`,
                [track("numbers", a, a.map((_, i) => (i === left ? "done" : i < left ? "good" : "idle"))), ends()],
                [count("left", left + 1), count("right", right), count("moves", scan)],
                `${a[left]} is even and already sits on the even side.`,
                "Skipping settled values keeps the search focused on misplaced ones.",
                6,
                { pointers: [ptr(left, "L"), ptr(right, "R")] }
              ));
              left++;
            }
            while (left < right && a[right] % 2 === 1) {
              scan++;
              out.push(frame(
                `Index ${right} already holds an odd value`,
                [track("numbers", a, a.map((_, i) => (i === right ? "done" : i > right ? "good" : "idle"))), ends()],
                [count("left", left), count("right", right - 1), count("moves", scan)],
                `${a[right]} is odd and already sits on the odd side.`,
                "The right pointer can ignore values that are already correct.",
                7,
                { pointers: [ptr(left, "L"), ptr(right, "R")] }
              ));
              right--;
            }
            if (left < right) {
              scan++;
              out.push(frame(
                "Both ends are misplaced",
                [track("numbers", a, a.map((_, i) => (i === left || i === right ? "compare" : i < left || i > right ? "good" : "idle"))), ends()],
                [count("left", left), count("right", right), count("moves", scan)],
                `An odd value sits at ${left} and an even value sits at ${right}.`,
                "These two values need to exchange sides.",
                8,
                { pointers: [ptr(left, "L"), ptr(right, "R")] }
              ));
              const l = a[left], r = a[right];
              a[left] = r;
              a[right] = l;
              out.push(frame(
                `Swap ${l} and ${r}`,
                [track("numbers", a, a.map((_, i) => (i === left || i === right ? "good" : i < left || i > right ? "done" : "idle"))), ends()],
                [count("left", left), count("right", right), count("moves", scan)],
                `${l} moves right and ${r} moves left.`,
                "One swap places both values on the correct side of the partition.",
                10,
                { pointers: [ptr(left, "L"), ptr(right, "R")] }
              ));
              left++;
              right--;
              scan++;
              out.push(frame(
                `Pointers close in to ${left} and ${right}`,
                [track("numbers", a, a.map((_, i) => (i < left || i > right ? "good" : "idle"))), chips("ends", [a[Math.min(left, n - 1)] % 2 ? "odd" : "even", a[Math.max(right, 0)] % 2 ? "odd" : "even"], "compare")],
                [count("left", left), count("right", right), count("moves", scan)],
                `The settled prefix and suffix now have the right parity; ${left} and ${right} remain to check.`,
                "Only the middle still needs attention once both pointers move inward.",
                12,
                left < right ? { pointers: [ptr(left, "L"), ptr(right, "R")] } : undefined
              ));
            }
          }
          out.push(frame(
            `Parity sorted: ${a.join(", ")}`,
            [track("numbers", a, fill(n, "result")), chips("groups", [a.filter((x) => x % 2 === 0).join(","), a.filter((x) => x % 2 === 1).join(",")], "result")],
            [count("evens", a.filter((x) => x % 2 === 0).length), count("odds", a.filter((x) => x % 2 === 1).length)],
            `Every even value now precedes every odd value in ${a.join(", ")}.`,
            "The pointers met after each misplaced pair had been exchanged once.",
            15
          ));
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "sort-array-by-parity-ii",
    title: "Sort Array by Parity II",
    category: "Two Pointers",
    difficulty: "Beginner",
    description: "Place even values at even indices and odd values at odd indices.",
    input: { label: "numbers", default: "4, 2, 5, 7, 0, 1", parse: "ints" },
    approaches: [
      {
        name: "Two Parity Lanes",
        complexity: "O(n) time, O(1) space",
        idea: [
          "One pointer walks even indices and the other walks odd indices, each in steps of two.",
          "If the even pointer finds an odd value and the odd pointer finds an even value, swap them; otherwise advance the pointer that is already correct.",
        ],
        problem: [
          "The input is guaranteed to contain equal numbers of even and odd values, so a mismatched pair always exists when both pointers are wrong.",
        ],
        code: {
          c: `#include <stdio.h>

void sortArrayByParityII(int* nums, int n) {
    int even = 0, odd = 1;
    while (even < n && odd < n) {
        if (nums[even] % 2 == 0) even += 2;
        else if (nums[odd] % 2 == 1) odd += 2;
        else {
            int t = nums[even];
            nums[even] = nums[odd];
            nums[odd] = t;
            even += 2;
            odd += 2;
        }
    }
}`,
          cpp: `#include <vector>
using namespace std;

vector<int> sortArrayByParityII(vector<int>& nums) {
    int even = 0, odd = 1;
    while (even < (int)nums.size() && odd < (int)nums.size()) {
        if (nums[even] % 2 == 0) even += 2;
        else if (nums[odd] % 2 == 1) odd += 2;
        else {
            int t = nums[even];
            nums[even] = nums[odd];
            nums[odd] = t;
            even += 2;
            odd += 2;
        }
    }
    return nums;
}`,
        },
        steps(nums) {
          const a = nums.slice(), n = a.length, out = [];
          let even = 0, odd = 1, moves = 0;
          out.push(frame(
            "Walk two parity lanes",
            [track("numbers", a, a.map((_, i) => (i === even || i === odd ? "compare" : "idle"))), chips("lanes", ["E:" + even, "O:" + odd], "compare")],
            [count("even index", even), count("odd index", odd), count("moves", moves)],
            `Even index ${even} holds ${a[even]}; odd index ${odd} holds ${a[odd]}.`,
            "Each lane only visits indices of its own parity, so every settled slot stays correct.",
            4,
            { pointers: [ptr(even, "E"), ptr(odd, "O")] }
          ));
          while (even < n && odd < n) {
            if (a[even] % 2 === 0) {
              moves++;
              out.push(frame(
                `Index ${even} already holds an even value`,
                [track("numbers", a, a.map((_, i) => (i === even ? "done" : "idle"))), chips("lanes", ["E:" + (even + 2), "O:" + odd], "compare")],
                [count("even index", even + 2), count("odd index", odd), count("moves", moves)],
                `${a[even]} is even at an even index, so the E pointer jumps to ${even + 2}.`,
                "No swap is needed on this lane; stepping by two keeps the parity of the index.",
                5,
                { pointers: [ptr(even, "E"), ptr(odd, "O")] }
              ));
              even += 2;
            } else if (a[odd] % 2 === 1) {
              moves++;
              out.push(frame(
                `Index ${odd} already holds an odd value`,
                [track("numbers", a, a.map((_, i) => (i === odd ? "done" : "idle"))), chips("lanes", ["E:" + even, "O:" + (odd + 2)], "compare")],
                [count("even index", even), count("odd index", odd + 2), count("moves", moves)],
                `${a[odd]} is odd at an odd index, so the O pointer jumps to ${odd + 2}.`,
                "Advancing by two preserves the lane while skipping a correct slot.",
                6,
                { pointers: [ptr(even, "E"), ptr(odd, "O")] }
              ));
              odd += 2;
            } else {
              moves++;
              out.push(frame(
                `${a[even]} and ${a[odd]} are both misplaced`,
                [track("numbers", a, a.map((_, i) => (i === even || i === odd ? "compare" : "idle"))), chips("lanes", ["E:" + even, "O:" + odd], "compare")],
                [count("even index", even), count("odd index", odd), count("moves", moves)],
                `An odd value sits at even index ${even}, and an even value sits at odd index ${odd}.`,
                "Exchanging them fixes both slots because their parities are opposite.",
                7,
                { pointers: [ptr(even, "E"), ptr(odd, "O")] }
              ));
              const ev = a[even], od = a[odd];
              a[even] = od;
              a[odd] = ev;
              moves++;
              out.push(frame(
                `Swap ${ev} and ${od}`,
                [track("numbers", a, a.map((_, i) => (i === even || i === odd ? "good" : "idle"))), chips("lanes", ["E:" + (even + 2), "O:" + (odd + 2)], "compare")],
                [count("even index", even + 2), count("odd index", odd + 2), count("moves", moves)],
                `${od} now sits at even index ${even}, and ${ev} at odd index ${odd}.`,
                "Both pointers can then advance to the next unchecked slots in their lanes.",
                11,
                { pointers: [ptr(even, "E"), ptr(odd, "O")] }
              ));
              even += 2;
              odd += 2;
            }
          }
          out.push(frame(
            `Parity II done: ${a.join(", ")}`,
            [track("numbers", a, a.map((_, i) => (i % 2 === 0 ? (a[i] % 2 === 0 ? "good" : "bad") : a[i] % 2 === 1 ? "good" : "bad")))],
            [count("even slots", Math.ceil(n / 2)), count("odd slots", Math.floor(n / 2)), count("moves", moves)],
            `Every even value is at an even index and every odd value at an odd index in ${a.join(", ")}.`,
            "All slots were either already correct or repaired by a swap, so both lanes can stop.",
            15
          ));
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "valid-subsequence",
    title: "Valid Subsequence",
    category: "Two Pointers",
    difficulty: "Beginner",
    description: "Check whether one string appears inside another in the same order.",
    input: { label: "subsequence | string", default: "abc | ahbgdc", parse: "string" },
    approaches: [
      {
        name: "Walk Both Strings",
        complexity: "O(s + t) time, O(s + t) space for the shown characters",
        idea: [
          "Pointer i tracks the next character needed from the subsequence, and pointer j scans the longer string from left to right.",
          "A match advances both pointers; a mismatch only advances j, because the needed character may appear later in the longer string.",
        ],
        problem: [
          "The input uses a | separator because the engine has no two-string parser; steps() splits that single string into the two operands.",
        ],
        code: {
          c: `#include <stdbool.h>
#include <string.h>

bool isSubsequence(char* s, char* t) {
    int i = 0, j = 0;
    while (s[i] && t[j]) {
        if (s[i] == t[j]) i++;
        j++;
    }
    return s[i] == '\\0';
}`,
          cpp: `#include <string>
using namespace std;

bool isSubsequence(string s, string t) {
    int i = 0, j = 0;
    while (i < (int)s.size() && j < (int)t.size()) {
        if (s[i] == t[j]) i++;
        j++;
    }
    return i == (int)s.size();
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|");
          const s = [...(parts.length > 1 ? parts[0].trim() : String(text || "").trim())];
          const t = [...(parts.length > 1 ? parts[1].trim() : "")];
          const matched = [];
          const out = [];
          let i = 0, j = 0;
          const ptrs = (a, b) => [
            ...(a < s.length ? [ptr(a, "i")] : []),
            ...(b < t.length ? [ptr(b, "j", 1)] : []),
          ];
          out.push(frame(
            "Start at the front of both strings",
            [track("subsequence", s, s.map((_, k) => (k === 0 ? "read" : "idle"))), track("string", t, t.map((_, k) => (k === 0 ? "read" : "idle"))), chips("matched", [], "idle")],
            [count("needed i", i, s.length), count("scan j", j, t.length)],
            `Looking for "${s.join("")}" inside "${t.join("")}".`,
            "A single scan of the longer string is enough if we remember which subsequence character is needed next.",
            4,
            { pointers: ptrs(i, j) }
          ));
          while (i < s.length && j < t.length) {
            const hit = s[i] === t[j];
            if (hit) matched.push(s[i]);
            out.push(frame(
              hit ? `Match '${s[i]}'` : `Skip '${t[j]}'`,
              [track("subsequence", s, s.map((_, k) => (k === i ? (hit ? "good" : "compare") : k < i ? "done" : "idle"))), track("string", t, t.map((_, k) => (k === j ? (hit ? "good" : "bad") : k < j ? "done" : "idle"))), chips("matched", matched, "result")],
              [count("needed i", hit ? i + 1 : i, s.length), count("scan j", j + 1, t.length), count("matched", matched.length, s.length)],
              hit ? `The needed '${s[i]}' appears at position ${j} of the string.` : `Position ${j} holds '${t[j]}', not the needed '${s[i]}'.`,
              hit ? "Both pointers move forward because this character is now accounted for." : "Only the scan pointer moves; the needed character could still appear later.",
              hit ? 6 : 7,
              { pointers: ptrs(i, j) }
            ));
            if (hit) i++;
            j++;
          }
          const ok = i === s.length;
          out.push(frame(
            ok ? "Subsequence found" : "Not a subsequence",
            [track("subsequence", s, fill(s.length, ok ? "result" : "dim")), track("string", t, fill(t.length, "done")), chips("matched", matched, ok ? "result" : "done")],
            [count("answer", ok ? "true" : "false"), count("matched", matched.length, s.length)],
            ok ? `All ${s.length} characters were matched in order.` : `Only ${matched.length} of ${s.length} characters were matched.`,
            "The walk succeeds exactly when every subsequence character was consumed before the longer string ran out.",
            9
          ));
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "sum-of-square-numbers",
    title: "Sum of Square Numbers",
    category: "Two Pointers",
    difficulty: "Intermediate",
    description: "Decide whether a target is the sum of two integer squares.",
    input: { label: "c", default: "5", parse: "ints" },
    approaches: [
      {
        name: "Squeeze the Pair",
        complexity: "O(sqrt(c)) time, O(1) space",
        idea: [
          "Start with a = 0 and b = c: their square sum is certainly too large for any positive target.",
          "If the sum exceeds c, lower b; if it falls short, raise a. The pointers squeeze toward a matching pair or cross without one.",
        ],
        problem: [
          "The search uses 64-bit integers so squaring b does not overflow when c is large.",
        ],
        code: {
          c: `#include <stdbool.h>

bool judgeSquareSum(int c) {
    long left = 0, right = c;
    while (left <= right) {
        long sum = left * left + right * right;
        if (sum == c) return true;
        if (sum < c) left++;
        else right--;
    }
    return false;
}`,
          cpp: `#include <cmath>
using namespace std;

bool judgeSquareSum(int c) {
    long long left = 0, right = c;
    while (left <= right) {
        long long sum = left * left + right * right;
        if (sum == c) return true;
        if (sum < c) left++;
        else right--;
    }
    return false;
}`,
        },
        steps(parsed) {
          const c = parsed[0] || 0;
          const out = [];
          let left = 0, right = c;
          out.push(frame(
            `Search for a^2 + b^2 = ${c}`,
            [chips("pair (a, b)", [left, right], "compare"), chips("target", [c], "result")],
            [count("a", left), count("b", right), count("tries", 0)],
            `Start with the widest possible pair: ${left} and ${right}.`,
            "A large b makes the sum too big, so shrinking b is the natural first move.",
            3,
            { pointers: [ptr(0, "a"), ptr(1, "b")] }
          ));
          let tries = 0;
          while (left <= right) {
            tries++;
            const sum = left * left + right * right;
            const equal = sum === c, small = sum < c;
            out.push(frame(
              `${left}^2 + ${right}^2 = ${sum}`,
              [chips("pair (a, b)", [left, right], (k) => (equal ? "good" : k === (small ? 0 : 1) ? "bad" : "compare")), chips("sum", [sum], equal ? "good" : "compare"), chips("target", [c], "result")],
              [count("a", left), count("b", right), count("sum", sum), count("tries", tries)],
              equal ? `${sum} equals the target ${c}.` : small ? `${sum} is below ${c}, so a must grow.` : `${sum} is above ${c}, so b must shrink.`,
              equal ? "A matching pair proves the target is a sum of two squares." : small ? "Increasing a is the only way to raise the sum while b stays fixed." : "Decreasing b is the only way to lower the sum while a stays fixed.",
              equal ? 6 : small ? 7 : 8,
              { pointers: [ptr(0, "a"), ptr(1, "b")] }
            ));
            if (equal) {
              out.push(frame(
                `Found ${left}^2 + ${right}^2 = ${c}`,
                [chips("pair (a, b)", [left, right], "result"), chips("sum", [sum], "result"), chips("target", [c], "good")],
                [count("answer", "true"), count("a", left), count("b", right), count("tries", tries)],
                `The pair ${left} and ${right} satisfies the equation.`,
                "The pointers stopped on an exact match, so the answer is true.",
                6
              ));
              return out;
            }
            if (small) left++; else right--;
          }
          out.push(frame(
            `No pair sums to ${c}`,
            [chips("pair (a, b)", [left, right], "dim"), chips("target", [c], "bad")],
            [count("answer", "false"), count("tries", tries)],
            `The pointers crossed after ${tries} comparisons without an exact sum.`,
            "Once a exceeds b every possible pair has been checked, so the answer is false.",
            10
          ));
          return out;
        },
      },
    ],
  });
})();
