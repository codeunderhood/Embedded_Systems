/* ============================================================
   DSA Visuals — Array Techniques II
   Matrices and two-pointer scans: rotation, spirals, Pascal's
   triangle, in-place hashing, trapped water and containers.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "swap", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => `[${a.join(", ")}]`;
  const square = (nums) => {
    const size = Math.max(1, Math.round(Math.sqrt(nums.length)) || 1);
    const m = [];
    for (let r = 0; r < size; r++) {
      const row = nums.slice(r * size, r * size + size);
      while (row.length < size) row.push(0);
      m.push(row);
    }
    return m;
  };

  /* ---------------------------------------------------------- */
  V.register({
    id: "rotate-image",
    title: "Rotate Image",
    category: "Array Techniques",
    difficulty: "Intermediate",
    description:
      "Rotate a square matrix 90° clockwise in place, using a transpose and a row reversal.",
    input: { label: "square matrix, row by row", default: "1,2,3, 4,5,6, 7,8,9", parse: "ints" },
    approaches: [
      {
        name: "Transpose, Then Flip Rows",
        complexity: "O(n²) time, O(1) space",
        idea: [
          "A 90° clockwise turn sends the cell at (row, col) to (col, n − 1 − row). Doing that directly would overwrite cells before they were read.",
          "Splitting the move into a transpose — swap (r, c) with (c, r) — and then reversing every row reaches the same place without any temporary matrix.",
        ],
        problem: [
          "Only square matrices rotate this way; a rectangular grid would need a different output shape entirely.",
        ],
        code: {
          c: `#include <stdio.h>

#define N 3

void rotate(int a[N][N]) {
    for (int r = 0; r < N; r++)          /* transpose */
        for (int c = r + 1; c < N; c++) {
            int t = a[r][c];
            a[r][c] = a[c][r];
            a[c][r] = t;
        }
    for (int r = 0; r < N; r++)          /* flip each row */
        for (int c = 0; c < N / 2; c++) {
            int t = a[r][c];
            a[r][c] = a[r][N - 1 - c];
            a[r][N - 1 - c] = t;
        }
}

int main(void) {
    int a[N][N] = {{1,2,3},{4,5,6},{7,8,9}};
    rotate(a);
    for (int r = 0; r < N; r++) {
        for (int c = 0; c < N; c++) printf("%d ", a[r][c]);
        printf("\\n");
    }
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void rotate(vector<vector<int>>& a) {
    int n = a.size();
    for (int r = 0; r < n; r++)
        for (int c = r + 1; c < n; c++)
            swap(a[r][c], a[c][r]);
    for (auto& row : a) reverse(row.begin(), row.end());
}

int main() {
    vector<vector<int>> a{{1,2,3},{4,5,6},{7,8,9}};
    rotate(a);
    for (auto& row : a) { for (int v : row) cout << v << ' '; cout << '\\n'; }
}`,
        },
        steps(nums) {
          const m = square(nums);
          const n = m.length;
          const steps = [];
          const snapshot = (stateFn) => grid(n, n, (r, c) => ({
            v: m[r][c],
            state: stateFn ? stateFn(r, c) : "idle",
          }));
          steps.push({
            title: `${n} × ${n} matrix, rotate clockwise`,
            kind: "grid",
            rows: n,
            cols: n,
            cells: snapshot(),
            counters: [count("cells", n * n), count("pairs swapped", 0, Math.floor(n * n / 2))],
            legend: LEG,
            happened: `The matrix starts as ${m.map((row) => `[${row.join(",")}]`).join(" ")}.`,
            why: "A clockwise turn moves the top row to the right column, so each cell needs a new home.",
            codeLine: 5,
          });
          let swaps = 0;
          for (let r = 0; r < n; r++) {
            for (let c = r + 1; c < n; c++) {
              const t = m[r][c];
              m[r][c] = m[c][r];
              m[c][r] = t;
              swaps++;
              steps.push({
                title: `Swap (${r},${c}) ↔ (${c},${r}): ${m[r][c]} and ${m[c][r]}`,
                kind: "grid",
                rows: n,
                cols: n,
                cells: snapshot((rr, cc) =>
                  (rr === r && cc === c) || (rr === c && cc === r) ? "swap"
                    : rr === c || cc === r ? "done" : "idle"),
                counters: [count("pairs swapped", swaps, n * (n - 1) / 2), count("cells", n * n)],
                legend: LEG,
                happened: `The symmetric pair changed places, which mirrors the matrix across its diagonal.`,
                why: "Transposing fixes the column-to-row relationship but reverses the direction within each row.",
                codeLine: 6,
              });
            }
          }
          steps.push({
            title: "Transpose done — each row is still reversed",
            kind: "grid",
            rows: n,
            cols: n,
            cells: snapshot(() => "active"),
            counters: [count("pairs swapped", swaps, n * (n - 1) / 2), count("phase", 1, 2)],
            legend: LEG,
            happened: `The transpose is ${m.map((row) => `[${row.join(",")}]`).join(" ")}.`,
            why: "Reversing each row now turns the mirrored layout into the clockwise rotation.",
            codeLine: 10,
          });
          for (let r = 0; r < n; r++) {
            m[r].reverse();
            steps.push({
              title: `Reverse row ${r} → [${m[r].join(", ")}]`,
              kind: "grid",
              rows: n,
              cols: n,
              cells: snapshot((rr, cc) => (rr === r ? "result" : rr < r ? "done" : "active")),
              counters: [count("rows reversed", r + 1, n), count("cells", n * n)],
              legend: LEG,
              happened: `Row ${r} now reads ${show(m[r])}.`,
              why: "The flip moves each value to the column it should occupy after the rotation.",
              codeLine: 10,
            });
          }
          steps.push({
            title: `Answer: ${m.map((row) => `[${row.join(",")}]`).join(" ")}`,
            kind: "grid",
            rows: n,
            cols: n,
            cells: snapshot(() => "result"),
            counters: [count("rows reversed", n, n), count("answer", "rotated")],
            legend: LEG,
            happened: "Every cell moved to its clockwise position without allocating a second matrix.",
            why: "Two in-place passes are enough because transpose and row reversal compose into the rotation.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "spiral-matrix",
    title: "Spiral Matrix",
    category: "Array Techniques",
    difficulty: "Intermediate",
    description:
      "Read a matrix in spiral order by shrinking four boundaries after each side is consumed.",
    input: { label: "matrix, row by row", default: "1,2,3, 4,5,6, 7,8,9", parse: "ints" },
    approaches: [
      {
        name: "Four Shrinking Boundaries",
        complexity: "O(rows × cols) time, O(1) space",
        idea: [
          "Keep top, bottom, left and right boundaries. Walk the top row, then the right column, then the bottom row backwards, then the left column upwards.",
          "After each side, move that boundary inward. The loop ends when the boundaries cross.",
        ],
        problem: [
          "Rectangular grids need the boundary checks to be re-tested after every side, or a thin layer gets read twice.",
        ],
        code: {
          c: `#include <stdio.h>

void spiral(int a[3][3], int rows, int cols) {
    int top = 0, bottom = rows - 1, left = 0, right = cols - 1;
    while (top <= bottom && left <= right) {
        for (int c = left; c <= right; c++) printf("%d ", a[top][c]);
        top++;
        for (int r = top; r <= bottom; r++) printf("%d ", a[r][right]);
        right--;
        if (top <= bottom) {
            for (int c = right; c >= left; c--) printf("%d ", a[bottom][c]);
            bottom--;
        }
        if (left <= right) {
            for (int r = bottom; r >= top; r--) printf("%d ", a[r][left]);
            left++;
        }
    }
    printf("\\n");
}

int main(void) {
    int a[3][3] = {{1,2,3},{4,5,6},{7,8,9}};
    spiral(a, 3, 3);   /* 1 2 3 6 9 8 7 4 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

vector<int> spiralOrder(const vector<vector<int>>& a) {
    vector<int> out;
    int top = 0, bottom = a.size() - 1;
    int left = 0, right = a[0].size() - 1;

    while (top <= bottom && left <= right) {
        for (int c = left; c <= right; c++) out.push_back(a[top][c]);
        top++;
        for (int r = top; r <= bottom; r++) out.push_back(a[r][right]);
        right--;
        if (top <= bottom) {
            for (int c = right; c >= left; c--) out.push_back(a[bottom][c]);
            bottom--;
        }
        if (left <= right) {
            for (int r = bottom; r >= top; r--) out.push_back(a[r][left]);
            left++;
        }
    }
    return out;
}

int main() {
    vector<vector<int>> a{{1,2,3},{4,5,6},{7,8,9}};
    for (int v : spiralOrder(a)) cout << v << ' '; // 1 2 3 6 9 8 7 4 5
    cout << '\\n';
}`,
        },
        steps(nums) {
          const m = square(nums);
          const rows = m.length, cols = m[0].length;
          const steps = [];
          const seen = new Set();
          let top = 0, bottom = rows - 1, left = 0, right = cols - 1;
          const out = [];
          const paintGrid = () => grid(rows, cols, (r, c) => ({
            v: m[r][c],
            state: seen.has(r + "," + c) ? "done" : "idle",
          }));
          steps.push({
            title: `${rows} × ${cols} matrix, read clockwise from the outside`,
            kind: "grid",
            rows,
            cols,
            cells: paintGrid(),
            counters: [count("cells read", 0, rows * cols), count("layers", 0)],
            legend: LEG,
            happened: `The boundaries start at top ${top}, bottom ${bottom}, left ${left}, right ${right}.`,
            why: "Each side of the spiral is a straight run along one boundary.",
            codeLine: 4,
          });
          while (top <= bottom && left <= right && out.length < rows * cols) {
            const layer = [];
            for (let c = left; c <= right; c++) { out.push(m[top][c]); seen.add(top + "," + c); layer.push(`(${top},${c})`); }
            steps.push({
              title: `Top row ${top}: ${m[top].slice(left, right + 1).join(", ")}`,
              kind: "grid",
              rows, cols,
              cells: grid(rows, cols, (r, c) => ({
                v: m[r][c],
                state: r === top && c >= left && c <= right ? "read" : seen.has(r + "," + c) ? "done" : "idle",
              })),
              counters: [count("cells read", out.length, rows * cols), count("top", top)],
              legend: LEG,
              happened: `The top boundary was read left to right; it now moves down to ${top + 1}.`,
              why: "After this pass no cell in that row is unvisited.",
              codeLine: 6,
            });
            top++;
            for (let r = top; r <= bottom; r++) { out.push(m[r][right]); seen.add(r + "," + right); }
            steps.push({
              title: `Right column ${right}: ${Array.from({ length: Math.max(0, bottom - top + 1) }, (_, i) => m[top + i][right]).join(", ") || "empty"}`,
              kind: "grid",
              rows, cols,
              cells: grid(rows, cols, (r, c) => ({
                v: m[r][c],
                state: c === right && r >= top && r <= bottom ? "read" : seen.has(r + "," + c) ? "done" : "idle",
              })),
              counters: [count("cells read", out.length, rows * cols), count("right", right)],
              legend: LEG,
              happened: `The right boundary was read downwards; it now moves left to ${right - 1}.`,
              why: "Moving the boundary prevents the next side from rereading this column.",
              codeLine: 9,
            });
            right--;
            if (top <= bottom) {
              const vals = [];
              for (let c = right; c >= left; c--) { out.push(m[bottom][c]); seen.add(bottom + "," + c); vals.push(m[bottom][c]); }
              steps.push({
                title: `Bottom row ${bottom}, right to left: ${vals.join(", ") || "empty"}`,
                kind: "grid",
                rows, cols,
                cells: grid(rows, cols, (r, c) => ({
                  v: m[r][c],
                  state: r === bottom && c >= left && c <= right ? "read" : seen.has(r + "," + c) ? "done" : "idle",
                })),
                counters: [count("cells read", out.length, rows * cols), count("bottom", bottom)],
                legend: LEG,
                happened: `The bottom edge was consumed backwards; the boundary rises to ${bottom - 1}.`,
                why: "Reading backwards keeps the spiral direction clockwise.",
                codeLine: 12,
              });
              bottom--;
            }
            if (left <= right) {
              const vals = [];
              for (let r = bottom; r >= top; r--) { out.push(m[r][left]); seen.add(r + "," + left); vals.push(m[r][left]); }
              steps.push({
                title: `Left column ${left}, upwards: ${vals.join(", ") || "empty"}`,
                kind: "grid",
                rows, cols,
                cells: grid(rows, cols, (r, c) => ({
                  v: m[r][c],
                  state: c === left && r >= top && r <= bottom ? "read" : seen.has(r + "," + c) ? "done" : "idle",
                })),
                counters: [count("cells read", out.length, rows * cols), count("left", left)],
                legend: LEG,
                happened: `The left edge closed this layer; the boundary moves right to ${left + 1}.`,
                why: "Four boundary moves complete one full turn of the spiral.",
                codeLine: 16,
              });
              left++;
            }
          }
          steps.push({
            title: `Answer: ${show(out)}`,
            kind: "grid",
            rows, cols,
            cells: grid(rows, cols, (r, c) => ({ v: m[r][c], state: "done" })),
            counters: [count("cells read", out.length, rows * cols), count("answer", show(out))],
            legend: LEG,
            happened: `All ${rows * cols} cells were visited exactly once.`,
            why: "Shrinking boundaries turns the spiral walk into four simple loops.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "pascals-triangle",
    title: "Pascals Triangle",
    category: "Array Techniques",
    difficulty: "Beginner",
    description:
      "Build the triangle where every entry is the sum of the two values above it.",
    input: { label: "number of rows", default: "6", parse: "int" },
    approaches: [
      {
        name: "Add the Two Parents",
        complexity: "O(rows²) time, O(rows²) space",
        idea: [
          "Row 0 is just 1. Every later row starts and ends with 1, and each interior entry is the sum of the two entries above it.",
          "The result is the table of binomial coefficients: entry k of row n counts the ways to choose k items from n.",
        ],
        problem: [
          "Storing every row keeps the whole triangle, though each row only needs the previous one to be generated.",
        ],
        code: {
          c: `#include <stdio.h>

int main(void) {
    int rows = 6;
    int tri[8][8] = {0};

    for (int r = 0; r < rows; r++) {
        tri[r][0] = 1;
        tri[r][r] = 1;
        for (int c = 1; c < r; c++)
            tri[r][c] = tri[r - 1][c - 1] + tri[r - 1][c];
    }

    for (int r = 0; r < rows; r++) {
        for (int c = 0; c <= r; c++) printf("%d ", tri[r][c]);
        printf("\\n");
    }
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

vector<vector<int>> generate(int rows) {
    vector<vector<int>> tri;
    for (int r = 0; r < rows; r++) {
        vector<int> row(r + 1, 1);
        for (int c = 1; c < r; c++)
            row[c] = tri[r - 1][c - 1] + tri[r - 1][c];
        tri.push_back(row);
    }
    return tri;
}

int main() {
    for (auto& row : generate(6)) {
        for (int v : row) cout << v << ' ';
        cout << '\\n';
    }
}`,
        },
        steps(n) {
          const rows = Math.max(1, Math.min(9, n | 0));
          const tri = [];
          const steps = [];
          const width = rows;
          const cellsFor = (stateFn) => {
            const cells = [];
            for (let r = 0; r < rows; r++) {
              for (let c = 0; c < width; c++) {
                const v = tri[r] && c <= r ? tri[r][c] : "";
                const state = v === "" ? "idle" : stateFn ? stateFn(r, c) : "done";
                cells.push({ r, c, v, state });
              }
            }
            return cells;
          };
          steps.push({
            title: `${rows} rows of Pascal's triangle`,
            kind: "grid",
            rows,
            cols: width,
            cells: cellsFor(() => "idle"),
            counters: [count("rows built", 0, rows), count("entries", 0)],
            legend: LEG,
            happened: "Row 0 is a single 1; every row after it depends only on the row above.",
            why: "The recurrence is local, so the table can be filled row by row.",
            codeLine: 5,
          });
          for (let r = 0; r < rows; r++) {
            tri[r] = [];
            for (let c = 0; c <= r; c++) {
              if (c === 0 || c === r) {
                tri[r][c] = 1;
                steps.push({
                  title: `Row ${r}: edge entry is 1`,
                  kind: "grid",
                  rows,
                  cols: width,
                  cells: cellsFor((rr, cc) => (rr === r && cc === c ? "read" : rr < r ? "done" : "idle")),
                  counters: [count("rows built", r, rows), count("entries", tri.flat().filter((v) => v != null).length)],
                  legend: LEG,
                  happened: `Every row starts and ends with 1, so (${r},${c}) is fixed.`,
                  why: "The edges correspond to choosing none or all of the items, which has one way each.",
                  codeLine: 7,
                });
              } else {
                tri[r][c] = tri[r - 1][c - 1] + tri[r - 1][c];
                steps.push({
                  title: `Row ${r}, entry ${c}: ${tri[r - 1][c - 1]} + ${tri[r - 1][c]} = ${tri[r][c]}`,
                  kind: "grid",
                  rows,
                  cols: width,
                  cells: cellsFor((rr, cc) => {
                    if (rr === r && cc === c) return "result";
                    if (rr === r - 1 && (cc === c - 1 || cc === c)) return "compare";
                    if (rr < r) return "done";
                    return "idle";
                  }),
                  counters: [count("rows built", r, rows), count("entries", tri.flat().filter((v) => v != null).length)],
                  legend: LEG,
                  happened: `The two parents above add to ${tri[r][c]}.`,
                  why: "This is Pascal's rule: each entry counts paths through the row above.",
                  codeLine: 9,
                });
              }
            }
          }
          steps.push({
            title: `Answer: ${rows} rows, last row ${show(tri[rows - 1])}`,
            kind: "grid",
            rows,
            cols: width,
            cells: cellsFor((rr) => (rr === rows - 1 ? "result" : "done")),
            counters: [count("rows built", rows, rows), count("entries", tri.flat().filter((v) => v != null).length)],
            legend: LEG,
            happened: `The bottom row is ${show(tri[rows - 1])}.`,
            why: "Every earlier row was needed exactly once, which gives the quadratic number of entries.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "first-missing-positive",
    title: "First Missing Positive",
    category: "Array Techniques",
    difficulty: "Advanced",
    description:
      "Find the smallest positive integer that is absent, in linear time and constant extra space.",
    input: { label: "The numbers", default: "3, 4, -1, 1", parse: "ints" },
    approaches: [
      {
        name: "Put Every Value in Its Slot",
        complexity: "O(n) time, O(1) space",
        idea: [
          "The answer is always between 1 and n + 1. For each value that belongs in range, swap it into the slot it names: value v goes to index v − 1.",
          "After the swaps, the first slot holding the wrong value names the answer. If every slot is correct, the answer is n + 1.",
        ],
        problem: [
          "The swap loop must be written carefully: a value already in place, or a duplicate, can otherwise cycle forever.",
        ],
        code: {
          c: `#include <stdio.h>

int first_missing_positive(int *a, int n) {
    for (int i = 0; i < n; i++) {
        while (a[i] > 0 && a[i] <= n && a[a[i] - 1] != a[i]) {
            int j = a[i] - 1;
            int t = a[i]; a[i] = a[j]; a[j] = t;
        }
    }
    for (int i = 0; i < n; i++)
        if (a[i] != i + 1) return i + 1;
    return n + 1;
}

int main(void) {
    int a[] = {3, 4, -1, 1};
    printf("%d\\n", first_missing_positive(a, 4)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int firstMissingPositive(vector<int> a) {
    int n = a.size();
    for (int i = 0; i < n; i++)
        while (a[i] > 0 && a[i] <= n && a[a[i] - 1] != a[i])
            swap(a[i], a[a[i] - 1]);
    for (int i = 0; i < n; i++)
        if (a[i] != i + 1) return i + 1;
    return n + 1;
}

int main() {
    cout << firstMissingPositive({3, 4, -1, 1}) << '\\n'; // 2
}`,
        },
        steps(nums) {
          const a = nums.slice();
          const n = a.length;
          const steps = [];
          if (!n) {
            return [{
              title: "Give at least one value",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("length", 0)],
              legend: ["idle", "result"],
              happened: "An empty array has no slots, so the answer is 1.",
              why: "The answer always lies between 1 and n + 1.",
            }];
          }
          steps.push({
            title: `${n} values: the answer lies in 1..${n + 1}`,
            tracks: [track("numbers", a, fill(n, "idle"))],
            counters: [count("values in range", a.filter((v) => v > 0 && v <= n).length), count("length", n)],
            legend: LEG,
            happened: `Only values from 1 to ${n} can occupy a slot; everything else is ignored during placement.`,
            why: "There are only n slots, so the smallest missing positive cannot exceed n + 1.",
            codeLine: 3,
          });
          for (let i = 0; i < n; i++) {
            while (a[i] > 0 && a[i] <= n && a[a[i] - 1] !== a[i]) {
              const j = a[i] - 1;
              const t = a[i]; a[i] = a[j]; a[j] = t;
              steps.push({
                title: `Value ${a[j]} belongs at index ${j} — swap into ${a[i]}`,
                tracks: [
                  track("numbers", a, (k) => (k === i || k === j ? "swap" : a[k] === k + 1 ? "done" : "idle")),
                  chips("slot check", [`index ${j} should hold ${j + 1}`], "read"),
                ],
                counters: [count("slots correct", a.filter((v, k) => v === k + 1).length, n), count("swaps", 1)],
                legend: LEG,
                happened: `Slot ${j} now holds ${a[j]}.`,
                why: "A value that names its own slot should live there, or later scans cannot trust the positions.",
                codeLine: 4,
              });
            }
          }
          let answer = n + 1;
          let at = -1;
          for (let i = 0; i < n; i++) {
            if (a[i] !== i + 1) { answer = i + 1; at = i; break; }
          }
          steps.push({
            title: at >= 0 ? `Answer: slot ${at} holds ${a[at]}, so ${answer} is missing` : `Answer: all slots correct, so ${answer}`,
            tracks: [
              track("numbers", a, (k) => (at >= 0 && k === at ? "bad" : a[k] === k + 1 ? "done" : "dim")),
              chips("answer", [answer], "result"),
            ],
            counters: [count("slots correct", a.filter((v, k) => v === k + 1).length, n), count("answer", answer)],
            legend: LEG,
            happened: at >= 0
              ? `The first mismatch is at index ${at}, which should have held ${at + 1}.`
              : `Every index k holds k + 1, so all values 1..${n} exist.`,
            why: "One linear scan after placement finishes the job, keeping both time and space linear in n.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "trapping-rain-water",
    title: "Trapping Rain Water",
    category: "Array Techniques",
    difficulty: "Advanced",
    description:
      "Compute how much water sits between bars, using the smaller of the two running maximums.",
    input: { label: "bar heights", default: "0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1", parse: "ints" },
    approaches: [
      {
        name: "Two Pointers",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Water above a bar is limited by the shorter of the highest bars on its left and right. Move the pointer on the shorter side, because that side already decides the water level.",
          "Track the maximum height seen on each side and add the gap between the maximum and the current bar whenever the current bar is lower.",
        ],
        problem: [
          "The argument depends on moving the smaller side: moving the taller side would add water using a bound that is not yet final.",
        ],
        code: {
          c: `#include <stdio.h>

int trap(const int *h, int n) {
    int lo = 0, hi = n - 1;
    int leftMax = 0, rightMax = 0, water = 0;

    while (lo < hi) {
        if (h[lo] < h[hi]) {
            if (h[lo] >= leftMax) leftMax = h[lo];
            else water += leftMax - h[lo];
            lo++;
        } else {
            if (h[hi] >= rightMax) rightMax = h[hi];
            else water += rightMax - h[hi];
            hi--;
        }
    }
    return water;
}

int main(void) {
    int h[] = {0,1,0,2,1,0,1,3,2,1,2,1};
    printf("%d\\n", trap(h, 12)); /* 6 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int trap(const vector<int>& h) {
    int lo = 0, hi = (int)h.size() - 1;
    int leftMax = 0, rightMax = 0, water = 0;
    while (lo < hi) {
        if (h[lo] < h[hi]) {
            leftMax = max(leftMax, h[lo]);
            water += leftMax - h[lo];
            lo++;
        } else {
            rightMax = max(rightMax, h[hi]);
            water += rightMax - h[hi];
            hi--;
        }
    }
    return water;
}

int main() {
    vector<int> h{0,1,0,2,1,0,1,3,2,1,2,1};
    cout << trap(h) << '\\n'; // 6
}`,
        },
        steps(nums) {
          const h = nums.slice();
          const n = h.length;
          if (!n) {
            return [{
              title: "Give some bar heights",
              tracks: [chips("heights", ["—"], "idle")],
              counters: [count("water", 0)],
              legend: ["idle", "result"],
              happened: "With no bars there is no water.",
              why: "Water needs at least one bar on each side.",
            }];
          }
          const steps = [];
          let lo = 0, hi = n - 1, leftMax = 0, rightMax = 0, water = 0;
          steps.push({
            title: `${n} bars, pointers at both ends`,
            tracks: [
              track("heights", h, h.map((_, i) => (i === 0 || i === n - 1 ? "read" : "idle"))),
              chips("left max", [0], "dim"),
              chips("right max", [0], "dim"),
              chips("water", [0], "result"),
            ],
            pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }],
            counters: [count("water", 0), count("bars settled", 0, n)],
            legend: LEG,
            happened: `The tallest bars on either side will decide the water level for each position.`,
            why: "No bar can hold more water than the shorter of its two surrounding maximums.",
            codeLine: 4,
          });
          while (lo < hi) {
            const fromLeft = h[lo] < h[hi];
            if (fromLeft) {
              leftMax = Math.max(leftMax, h[lo]);
              const add = leftMax - h[lo];
              water += add;
              steps.push({
                title: h[lo] >= leftMax ? `Bar ${lo} raises the left max to ${leftMax}` : `Bar ${lo} traps ${add}`,
                tracks: [
                  track("heights", h, h.map((v, i) => (i === lo ? (add ? "active" : "read") : i === hi ? "read" : i < lo || i > hi ? "dim" : "idle"))),
                  chips("left max", [leftMax], "done"),
                  chips("right max", [rightMax], "dim"),
                  chips("water", [water], "result"),
                ],
                pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }],
                counters: [count("water", water), count("bars settled", lo + (n - 1 - hi) + 1, n)],
                legend: LEG,
                happened: add
                  ? `The left maximum ${leftMax} is above this bar, so ${add} unit${add === 1 ? "" : "s"} fit on top.`
                  : `This bar is the new left maximum, so it holds no water itself.`,
                why: "The shorter side is safe to settle because the other side is already at least as tall.",
                codeLine: 8,
              });
              lo++;
            } else {
              rightMax = Math.max(rightMax, h[hi]);
              const add = rightMax - h[hi];
              water += add;
              steps.push({
                title: h[hi] >= rightMax ? `Bar ${hi} raises the right max to ${rightMax}` : `Bar ${hi} traps ${add}`,
                tracks: [
                  track("heights", h, h.map((v, i) => (i === hi ? (add ? "active" : "read") : i === lo ? "read" : i < lo || i > hi ? "dim" : "idle"))),
                  chips("left max", [leftMax], "dim"),
                  chips("right max", [rightMax], "done"),
                  chips("water", [water], "result"),
                ],
                pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }],
                counters: [count("water", water), count("bars settled", lo + (n - 1 - hi) + 1, n)],
                legend: LEG,
                happened: add
                  ? `The right maximum ${rightMax} is above this bar, so ${add} unit${add === 1 ? "" : "s"} fit on top.`
                  : `This bar is the new right maximum, so it holds no water itself.`,
                why: "Both sides have now been bounded, so the addition is final.",
                codeLine: 13,
              });
              hi--;
            }
          }
          steps.push({
            title: `Answer: ${water} unit${water === 1 ? "" : "s"} of water`,
            tracks: [
              track("heights", h, fill(n, "done")),
              chips("left max", [leftMax], "dim"),
              chips("right max", [rightMax], "dim"),
              chips("answer", [water], "result"),
            ],
            counters: [count("water", water), count("bars settled", n, n)],
            legend: LEG,
            happened: `The two pointers met and the trapped total is ${water}.`,
            why: "Each bar was settled exactly once, so the scan is linear.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "container-with-most-water",
    title: "Container with Most Water",
    category: "Array Techniques",
    difficulty: "Intermediate",
    description:
      "Pick two bars that hold the most water: the area is the shorter bar times the gap between them.",
    input: { label: "bar heights", default: "1, 8, 6, 2, 5, 4, 8, 3, 7", parse: "ints" },
    approaches: [
      {
        name: "Move the Shorter Side",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Start with the widest possible pair. Its area is limited by the shorter bar.",
          "Any pair using that shorter bar with a smaller width is worse, so discard it by moving its pointer inward. Keep the best area seen.",
        ],
        problem: [
          "Only the width and the shorter height matter, so the method does not generalise to irregular containers without extra reasoning.",
        ],
        code: {
          c: `#include <stdio.h>

int max_area(const int *h, int n) {
    int lo = 0, hi = n - 1, best = 0;
    while (lo < hi) {
        int height = h[lo] < h[hi] ? h[lo] : h[hi];
        int area = height * (hi - lo);
        if (area > best) best = area;
        if (h[lo] < h[hi]) lo++;
        else hi--;
    }
    return best;
}

int main(void) {
    int h[] = {1,8,6,2,5,4,8,3,7};
    printf("%d\\n", max_area(h, 9)); /* 49 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int maxArea(const vector<int>& h) {
    int lo = 0, hi = (int)h.size() - 1, best = 0;
    while (lo < hi) {
        int area = min(h[lo], h[hi]) * (hi - lo);
        best = max(best, area);
        if (h[lo] < h[hi]) lo++;
        else hi--;
    }
    return best;
}

int main() {
    vector<int> h{1,8,6,2,5,4,8,3,7};
    cout << maxArea(h) << '\\n'; // 49
}`,
        },
        steps(nums) {
          const h = nums.slice();
          const n = h.length;
          if (n < 2) {
            return [{
              title: "Two bars are needed",
              tracks: [chips("heights", h.length ? h : ["—"], "idle")],
              counters: [count("area", 0)],
              legend: ["idle", "result"],
              happened: "A container needs a wall on each side.",
              why: "The area formula multiplies a height by a width, so zero width gives zero.",
            }];
          }
          const steps = [];
          let lo = 0, hi = n - 1, best = 0, bestPair = [lo, hi];
          steps.push({
            title: `Widest pair: bars ${lo} and ${hi}`,
            tracks: [
              track("heights", h, h.map((_, i) => (i === lo || i === hi ? "read" : "dim"))),
              chips("area", [0], "dim"),
            ],
            pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }],
            counters: [count("width", hi - lo), count("best area", 0)],
            legend: LEG,
            happened: `Bars ${h[lo]} and ${h[hi]} are ${hi - lo} apart.`,
            why: "Starting at maximum width means any better answer must come from taller bars.",
            codeLine: 3,
          });
          while (lo < hi) {
            const height = Math.min(h[lo], h[hi]);
            const area = height * (hi - lo);
            const better = area > best;
            if (better) { best = area; bestPair = [lo, hi]; }
            steps.push({
              title: `Bars ${lo}–${hi}: ${height} × ${hi - lo} = ${area}${better ? " ✓ new best" : ""}`,
              tracks: [
                track("heights", h, h.map((_, i) => (i === lo || i === hi ? (better ? "result" : "read") : i < lo || i > hi ? "dim" : "idle"))),
                chips("shorter bar", [height], "compare"),
                chips("area", [area], better ? "result" : "active"),
                chips("best area", [best], "result"),
              ],
              pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }],
              counters: [count("width", hi - lo), count("best area", best)],
              legend: LEG,
              happened: `The water reaches height ${height}, so the area is ${area}.`,
              why: "The shorter wall caps the container; extra height on the other side does not help.",
              codeLine: 6,
            });
            if (h[lo] < h[hi]) lo++;
            else hi--;
          }
          steps.push({
            title: `Answer: ${best} between bars ${bestPair[0]} and ${bestPair[1]}`,
            tracks: [
              track("heights", h, h.map((_, i) => (i === bestPair[0] || i === bestPair[1] ? "good" : "dim"))),
              chips("answer", [`${best} units`], "result"),
            ],
            pointers: [{ index: bestPair[0], label: "L" }, { index: bestPair[1], label: "R" }],
            counters: [count("width", bestPair[1] - bestPair[0]), count("best area", best)],
            legend: LEG,
            happened: `The best container uses heights ${h[bestPair[0]]} and ${h[bestPair[1]]}.`,
            why: "Every discarded bar was the shorter wall of a pair no wider pair could rescue, so no candidate was skipped.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });
})();
