/* ============================================================
   DSA Visuals — Strings & Text I
   Character mapping and sliding windows. The stage shows the
   text as character cells so window boundaries are visible.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const charTrack = (label, text, states) => track(label, Array.from(text), states);
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const isWindow = (i, lo, hi) => i >= lo && i < hi;

  /* ---------------------------------------------------------- */
  V.register({
    id: "isomorphic-strings",
    title: "Isomorphic Strings",
    category: "Strings & Text",
    difficulty: "Beginner",
    description:
      "Check whether two texts have the same shape, where each letter maps to exactly one letter of the other.",
    input: { label: "text A | text B", default: "egg | add", parse: "string" },
    approaches: [
      {
        name: "Two-Way Letter Mapping",
        complexity: "O(n) time, O(alphabet) space",
        idea: [
          "Walk both texts together and record the letter each character maps to. A conflict on either side means the shapes differ.",
          "Both directions are needed: without the reverse map, two different letters in A could map to the same letter in B.",
        ],
        problem: [
          "The maps must be cleared or scoped per test, otherwise a previous pair of strings leaks into the next comparison.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint isomorphic(const char *a, const char *b) {\n    if (strlen(a) != strlen(b)) return 0;\n    int forward[256], backward[256];\n    for (int i = 0; i < 256; i++) { forward[i] = -1; backward[i] = -1; }\n\n    for (int i = 0; a[i]; i++) {\n        unsigned char x = a[i], y = b[i];\n        if (forward[x] == -1 && backward[y] == -1) {\n            forward[x] = y;\n            backward[y] = x;\n        } else if (forward[x] != y || backward[y] != x) {\n            return 0;\n        }\n    }\n    return 1;\n}\n\nint main(void) {\n    printf(\"%d\\\\n\", isomorphic(\"egg\", \"add\")); /* 1 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\n#include <unordered_map>\nusing namespace std;\n\nbool isIsomorphic(const string& a, const string& b) {\n    if (a.size() != b.size()) return false;\n    unordered_map<char, char> forward, backward;\n    for (size_t i = 0; i < a.size(); i++) {\n        char x = a[i], y = b[i];\n        if (!forward.count(x) && !backward.count(y)) {\n            forward[x] = y;\n            backward[y] = x;\n        } else if (forward[x] != y || backward[y] != x) {\n            return false;\n        }\n    }\n    return true;\n}\n\nint main() {\n    cout << isIsomorphic(\"egg\", \"add\") << '\\\\n'; // 1\n}`,
        },
        steps(text) {
          const [a, b] = parts(text);
          const A = Array.from(a || "");
          const B = Array.from(b || "");
          if (A.length !== B.length) {
            return [{
              title: "The texts have different lengths",
              tracks: [charTrack("text A", a || "—", fill(Math.max(1, A.length), "bad")), charTrack("text B", b || "—", fill(Math.max(1, B.length), "bad"))],
              counters: [count("length A", A.length), count("length B", B.length)],
              legend: LEG,
              happened: `A has ${A.length} characters and B has ${B.length}, so no one-to-one mapping can exist.`,
              why: "Isomorphism preserves length and the position of every repeat.",
            }];
          }
          const forward = new Map();
          const backward = new Map();
          const steps = [];
          steps.push({
            title: `${A.length} characters to compare`,
            tracks: [charTrack("text A", a, fill(A.length, "idle")), charTrack("text B", b, fill(B.length, "idle"))],
            counters: [count("mapped", 0, A.length), count("conflicts", 0)],
            legend: LEG,
            happened: `Build the letter mapping by walking both texts together.`,
            why: "Each repeated letter must repeat in the same place on the other side.",
            codeLine: 8,
          });
          let conflict = null;
          for (let i = 0; i < A.length; i++) {
            const x = A[i], y = B[i];
            const hasF = forward.has(x), hasB = backward.has(y);
            if (!hasF && !hasB) {
              forward.set(x, y);
              backward.set(y, x);
              steps.push({
                title: `Map ${x} → ${y}`,
                tracks: [charTrack("text A", a, (k) => (k === i ? "read" : k < i ? "done" : "idle")), charTrack("text B", b, (k) => (k === i ? "read" : k < i ? "done" : "idle"))],
                counters: [count("mapped", forward.size, A.length), count("conflicts", 0)],
                legend: LEG,
                happened: `${x} and ${y} had no mapping yet, so they are paired in both directions.`,
                why: "Recording both directions blocks a later letter from stealing an existing partner.",
                codeLine: 12,
              });
            } else if (forward.get(x) !== y || backward.get(y) !== x) {
              conflict = i;
              steps.push({
                title: `Conflict at ${i}: ${x}→${forward.get(x) ?? "?"}, ${y}→${backward.get(y) ?? "?"}`,
                tracks: [charTrack("text A", a, (k) => (k === i ? "bad" : k < i ? "done" : "idle")), charTrack("text B", b, (k) => (k === i ? "bad" : k < i ? "done" : "idle"))],
                counters: [count("mapped", forward.size, A.length), count("conflicts", 1)],
                legend: LEG,
                happened: `${x} and ${y} disagree with an earlier mapping, so the shapes differ.`,
                why: "Either direction failing is enough to reject the pair.",
                codeLine: 15,
              });
              break;
            } else {
              steps.push({
                title: `${x} → ${y} matches the earlier mapping`,
                tracks: [charTrack("text A", a, (k) => (k === i ? "done" : k < i ? "done" : "idle")), charTrack("text B", b, (k) => (k === i ? "done" : k < i ? "done" : "idle"))],
                counters: [count("mapped", forward.size, A.length), count("conflicts", 0)],
                legend: LEG,
                happened: `The pair agrees with the map, so the scan continues.`,
                why: "Consistent repeats are exactly what isomorphism requires.",
                codeLine: 14,
              });
            }
          }
          steps.push({
            title: conflict == null ? "Answer: the texts are isomorphic" : `Answer: not isomorphic at position ${conflict}`,
            tracks: [
              charTrack("text A", a, (k) => (conflict != null && k === conflict ? "bad" : "done")),
              charTrack("text B", b, (k) => (conflict != null && k === conflict ? "bad" : "done")),
              chips("answer", [conflict == null ? "yes" : "no"], "result"),
            ],
            counters: [count("mapped", forward.size, A.length), count("answer", conflict == null ? "yes" : "no")],
            legend: LEG,
            happened: conflict == null ? "Every letter pairing stayed consistent." : `Position ${conflict} broke the mapping.`,
            why: "One pass with two maps decides the question in linear time.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "word-pattern",
    title: "Word Pattern",
    category: "Strings & Text",
    difficulty: "Beginner",
    description:
      "Check whether a pattern of letters matches a sentence word for word, with a two-way mapping.",
    input: { label: "pattern | sentence", default: "abba | dog cat cat dog", parse: "string" },
    approaches: [
      {
        name: "Map Letters to Words",
        complexity: "O(words) time, O(words) space",
        idea: [
          "Split the sentence into words. Then each pattern letter must map to exactly one word, and each word back to exactly one letter.",
          "The reverse map matters: pattern \"ab\" against \"dog dog\" would otherwise pass.",
        ],
        problem: [
          "Splitting on whitespace hides multiple spaces or punctuation; the real input format has to be fixed first.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\n/* words are whitespace separated; pattern has no spaces */\nint word_pattern(const char *pattern, char *sentence) {\n    char *words[64];\n    int n = 0;\n    char *w = strtok(sentence, " ");\n    while (w) { words[n++] = w; w = strtok(NULL, " "); }\n\n    int plen = (int)strlen(pattern);\n    if (plen != n) return 0;\n\n    for (int i = 0; i < plen; i++)\n        for (int j = 0; j < i; j++) {\n            int sameLetter = pattern[i] == pattern[j];\n            int sameWord = strcmp(words[i], words[j]) == 0;\n            if (sameLetter != sameWord) return 0;\n        }\n    return 1;\n}\n\nint main(void) {\n    char s[] = "dog cat cat dog";\n    printf(\"%d\\\\n\", word_pattern("abba", s)); /* 1 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\n#include <sstream>\n#include <vector>\n#include <unordered_map>\nusing namespace std;\n\nbool wordPattern(const string& pattern, const string& sentence) {\n    vector<string> words;\n    istringstream in(sentence);\n    string w;\n    while (in >> w) words.push_back(w);\n    if (pattern.size() != words.size()) return false;\n\n    unordered_map<char, string> toWord;\n    unordered_map<string, char> toLetter;\n    for (size_t i = 0; i < words.size(); i++) {\n        char c = pattern[i];\n        if (!toWord.count(c) && !toLetter.count(words[i])) {\n            toWord[c] = words[i];\n            toLetter[words[i]] = c;\n        } else if (toWord[c] != words[i] || toLetter[words[i]] != c) {\n            return false;\n        }\n    }\n    return true;\n}\n\nint main() {\n    cout << wordPattern("abba", "dog cat cat dog") << '\\\\n'; // 1\n}`,
        },
        steps(text) {
          const [pattern, sentence] = parts(text);
          const P = Array.from(pattern || "");
          const W = String(sentence || "").split(/\s+/).filter(Boolean);
          if (!P.length || !W.length) {
            return [{
              title: "Give a pattern and a sentence",
              tracks: [chips("pattern", P.length ? P : ["—"], "idle"), chips("words", W.length ? W : ["—"], "idle")],
              counters: [count("letters", P.length), count("words", W.length)],
              legend: ["idle", "bad", "result"],
              happened: "The left side of the bar is the pattern, the right side the sentence.",
              why: "A word pattern pairs one letter with one whole word.",
            }];
          }
          if (P.length !== W.length) {
            return [{
              title: "Different counts",
              tracks: [chips("pattern", P, "bad"), chips("words", W, "bad")],
              counters: [count("letters", P.length), count("words", W.length)],
              legend: LEG,
              happened: `${P.length} letters cannot match ${W.length} words.`,
              why: "The pattern is positional, so the counts must agree.",
            }];
          }
          const toWord = new Map();
          const toLetter = new Map();
          const steps = [];
          steps.push({
            title: `${P.length} positions, ${new Set(W).size} distinct word${new Set(W).size === 1 ? "" : "s"}`,
            tracks: [chips("pattern", P, "idle"), chips("words", W, "idle")],
            counters: [count("positions", 0, P.length), count("mapped", 0)],
            legend: LEG,
            happened: `Pattern ${P.join("")} against "${W.join(" ")}".`,
            why: "Both directions of the mapping must agree at every position.",
            codeLine: 11,
          });
          let bad = -1;
          for (let i = 0; i < P.length; i++) {
            const c = P[i], w = W[i];
            const hasC = toWord.has(c), hasW = toLetter.has(w);
            if (!hasC && !hasW) {
              toWord.set(c, w);
              toLetter.set(w, c);
              steps.push({
                title: `Map ${c} → "${w}"`,
                tracks: [chips("pattern", P, (k) => (k === i ? "read" : k < i ? "done" : "idle")), chips("words", W, (k) => (k === i ? "read" : k < i ? "done" : "idle"))],
                counters: [count("positions", i + 1, P.length), count("mapped", toWord.size)],
                legend: LEG,
                happened: `Neither ${c} nor "${w}" was used before, so they are paired.`,
                why: "Recording both sides keeps the relationship one-to-one.",
                codeLine: 15,
              });
            } else if (toWord.get(c) !== w || toLetter.get(w) !== c) {
              bad = i;
              steps.push({
                title: `Mismatch at ${i}: ${c} ↔ "${w}"`,
                tracks: [chips("pattern", P, (k) => (k === i ? "bad" : k < i ? "done" : "idle")), chips("words", W, (k) => (k === i ? "bad" : k < i ? "done" : "idle"))],
                counters: [count("positions", i + 1, P.length), count("mismatches", 1)],
                legend: LEG,
                happened: `${c} was already paired with "${toWord.get(c) ?? "?"}" and "${w}" with ${toLetter.get(w) ?? "?"}.`,
                why: "A letter cannot change words and a word cannot change letters.",
                codeLine: 18,
              });
              break;
            } else {
              steps.push({
                title: `${c} ↔ "${w}" repeats correctly`,
                tracks: [chips("pattern", P, (k) => (k === i ? "done" : k < i ? "done" : "idle")), chips("words", W, (k) => (k === i ? "done" : k < i ? "done" : "idle"))],
                counters: [count("positions", i + 1, P.length), count("mapped", toWord.size)],
                legend: LEG,
                happened: `The repeated pairing matches the map.`,
                why: "Repeated letters must correspond to repeated words.",
                codeLine: 17,
              });
            }
          }
          steps.push({
            title: bad >= 0 ? `Answer: no, position ${bad} breaks the pattern` : "Answer: yes, the pattern matches",
            tracks: [
              chips("pattern", P, (k) => (bad >= 0 && k === bad ? "bad" : "done")),
              chips("words", W, (k) => (bad >= 0 && k === bad ? "bad" : "done")),
              chips("answer", [bad >= 0 ? "no" : "yes"], "result"),
            ],
            counters: [count("positions checked", bad >= 0 ? bad + 1 : P.length, P.length), count("answer", bad >= 0 ? "no" : "yes")],
            legend: LEG,
            happened: bad >= 0 ? "The sentence does not follow the pattern." : "Every position agrees with the two maps.",
            why: "Both maps together give a complete, reversible pairing.",
            codeLine: 22,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "longest-substring-without-repeating-characters",
    title: "Longest Substring Without Repeating Characters",
    category: "Strings & Text",
    difficulty: "Intermediate",
    description:
      "Slide a window right, shrinking it whenever a character would repeat, and record the widest window.",
    input: { label: "text", default: "abcabcbb", parse: "chars" },
    approaches: [
      {
        name: "Sliding Window With Last Positions",
        complexity: "O(n) time, O(alphabet) space",
        idea: [
          "Keep a window that never contains a duplicate. When the new character was last seen inside the window, jump the left edge just past that earlier copy.",
          "Every position enters and leaves once, so the scan is linear even though the window moves in two directions.",
        ],
        problem: [
          "The jump must not move the left edge backwards; an old occurrence outside the window has to be ignored.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint longest_unique(const char *s) {\n    int last[256];\n    for (int i = 0; i < 256; i++) last[i] = -1;\n    int best = 0, lo = 0;\n\n    for (int hi = 0; s[hi]; hi++) {\n        unsigned char c = s[hi];\n        if (last[c] >= lo) lo = last[c] + 1;   /* repeat inside window */\n        last[c] = hi;\n        if (hi - lo + 1 > best) best = hi - lo + 1;\n    }\n    return best;\n}\n\nint main(void) {\n    printf(\"%d\\\\n\", longest_unique("abcabcbb")); /* 3 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\n#include <vector>\nusing namespace std;\n\nint lengthOfLongestSubstring(const string& s) {\n    vector<int> last(256, -1);\n    int best = 0, lo = 0;\n    for (int hi = 0; hi < (int)s.size(); hi++) {\n        unsigned char c = s[hi];\n        if (last[c] >= lo) lo = last[c] + 1;\n        last[c] = hi;\n        best = max(best, hi - lo + 1);\n    }\n    return best;\n}\n\nint main() {\n    cout << lengthOfLongestSubstring("abcabcbb") << '\\\\n'; // 3\n}`,
        },
        steps(text) {
          const s = Array.from(String(text || ""));
          if (!s.length) {
            return [{
              title: "Give some text",
              tracks: [chips("text", ["—"], "idle")],
              counters: [count("length", 0)],
              legend: ["idle", "result"],
              happened: "An empty text has no substring.",
              why: "The window starts empty and grows one character at a time.",
            }];
          }
          const steps = [];
          const last = new Map();
          let lo = 0, best = 0, bestRange = [0, 0];
          steps.push({
            title: `Window starts empty at the left of "${s.join("")}"`,
            tracks: [track("text", s, fill(s.length, "idle"))],
            counters: [count("window", 0, s.length), count("best", 0)],
            legend: LEG,
            happened: "The window will hold only unique characters.",
            why: "Growing the right edge is safe until a duplicate appears.",
            codeLine: 6,
          });
          for (let hi = 0; hi < s.length; hi++) {
            const c = s[hi];
            const prev = last.get(c);
            const jumped = prev != null && prev >= lo;
            if (jumped) lo = prev + 1;
            last.set(c, hi);
            const width = hi - lo + 1;
            if (width > best) { best = width; bestRange = [lo, hi]; }
            steps.push({
              title: jumped ? `${c} repeats; move left edge to ${lo}` : `Add ${c}; window is now ${width} wide`,
              tracks: [track("text", s, s.map((_, i) => (i === hi ? (jumped ? "bad" : "read") : isWindow(i, lo, hi + 1) ? "done" : "dim")))],
              window: { from: lo, to: hi },
              counters: [count("window", `${lo}..${hi}`), count("best", best)],
              legend: LEG,
              happened: jumped
                ? `${c} was last at ${prev}, so positions up to ${prev} must leave the window.`
                : `No duplicate inside the window, so it grows by one.`,
              why: "Jumping the left edge directly skips all the shrinking steps that could not help.",
              codeLine: jumped ? 9 : 10,
            });
          }
          steps.push({
            title: `Answer: "${s.slice(bestRange[0], bestRange[1] + 1).join("")}" (${best} characters)`,
            tracks: [
              track("text", s, s.map((_, i) => (isWindow(i, bestRange[0], bestRange[1] + 1) ? "result" : "dim"))),
              chips("answer", [`${best}`], "result"),
            ],
            window: { from: bestRange[0], to: bestRange[1], label: "best window" },
            counters: [count("window", `${bestRange[0]}..${bestRange[1]}`), count("best", best)],
            legend: LEG,
            happened: `The widest duplicate-free window has ${best} characters.`,
            why: "One pass with last positions gives linear time and alphabet-sized memory.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "longest-repeating-character-replacement",
    title: "Longest Repeating Character Replacement",
    category: "Strings & Text",
    difficulty: "Advanced",
    description:
      "With at most k replacements, find the longest window that can become one repeated character.",
    input: { label: "text | k", default: "AABABBA | 1", parse: "string" },
    approaches: [
      {
        name: "Window Kept by the Majority Count",
        complexity: "O(n) time, O(1) space",
        idea: [
          "A window can be made uniform with at most k changes when its length minus its most frequent character count is at most k.",
          "Grow the right edge always; shrink the left only while the window becomes illegal. The largest legal width is the answer.",
        ],
        problem: [
          "The most frequent count is not recomputed downwards in the usual optimisation, which is subtle but still correct because the answer only grows.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint character_replacement(const char *s, int k) {\n    int count[26] = {0};\n    int lo = 0, best = 0, maxCount = 0;\n\n    for (int hi = 0; s[hi]; hi++) {\n        int c = s[hi] - 'A';\n        if (++count[c] > maxCount) maxCount = count[c];\n\n        while (hi - lo + 1 - maxCount > k) {\n            count[s[lo] - 'A']--;\n            lo++;\n        }\n        if (hi - lo + 1 > best) best = hi - lo + 1;\n    }\n    return best;\n}\n\nint main(void) {\n    printf(\"%d\\\\n\", character_replacement("AABABBA", 1)); /* 4 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\n#include <vector>\nusing namespace std;\n\nint characterReplacement(const string& s, int k) {\n    vector<int> count(26, 0);\n    int lo = 0, best = 0, maxCount = 0;\n    for (int hi = 0; hi < (int)s.size(); hi++) {\n        maxCount = max(maxCount, ++count[s[hi] - 'A']);\n        while (hi - lo + 1 - maxCount > k) count[s[lo++] - 'A']--;\n        best = max(best, hi - lo + 1);\n    }\n    return best;\n}\n\nint main() {\n    cout << characterReplacement("AABABBA", 1) << '\\\\n'; // 4\n}`,
        },
        steps(text) {
          const [sRaw, kRaw] = parts(text);
          const s = Array.from(sRaw || "");
          const k = Math.max(0, parseInt(kRaw, 10) || 0);
          if (!s.length) {
            return [{
              title: "Give text and a replacement budget",
              tracks: [chips("text", ["—"], "idle")],
              counters: [count("k", k)],
              legend: ["idle", "result"],
              happened: "The left side of the bar is the text, the right side is k.",
              why: "A window is valid when its minority characters fit inside k.",
            }];
          }
          const steps = [];
          let lo = 0, best = 0, maxCount = 0, bestRange = null;
          const counts = new Map();
          const countText = () => [...counts.entries()].sort((a, b) => b[1] - a[1]).map(([c, n]) => `${c}:${n}`);
          steps.push({
            title: `Text "${s.join("")}", up to ${k} replacement${k === 1 ? "" : "s"}`,
            tracks: [track("text", s, fill(s.length, "idle"))],
            counters: [count("window", "empty"), count("best", 0)],
            legend: LEG,
            happened: "A window is legal when length − most frequent count ≤ k.",
            why: "All other characters in the window are the ones needing replacement.",
            codeLine: 5,
          });
          for (let hi = 0; hi < s.length; hi++) {
            const c = s[hi];
            counts.set(c, (counts.get(c) || 0) + 1);
            maxCount = Math.max(maxCount, counts.get(c));
            let shrunk = 0;
            while (hi - lo + 1 - maxCount > k) {
              counts.set(s[lo], counts.get(s[lo]) - 1);
              lo++;
              shrunk++;
            }
            const width = hi - lo + 1;
            if (width > best) { best = width; bestRange = [lo, hi]; }
            steps.push({
              title: `Add ${c}: window ${lo}..${hi}${shrunk ? `, shrink ${shrunk}` : ""} → ${width}`,
              tracks: [
                track("text", s, s.map((_, i) => (i === hi ? "read" : isWindow(i, lo, hi + 1) ? (s[i] === c ? "done" : "compare") : "dim"))),
                chips("window counts", countText(), "dim"),
              ],
              window: { from: lo, to: hi },
              counters: [count("window", `${lo}..${hi}`), count("replacements used", width - maxCount, k), count("best", best)],
              legend: LEG,
              happened: shrunk
                ? `The window needed more than ${k} changes, so the left edge advanced ${shrunk} place${shrunk === 1 ? "" : "s"}.`
                : `The non-majority characters fit in the ${k} allowed replacements.`,
              why: "The most frequent character is the one to repeat; everything else must be changed.",
              codeLine: shrunk ? 12 : 13,
            });
          }
          steps.push({
            title: `Answer: ${best} characters can be made equal`,
            tracks: [
              track("text", s, fill(s.length, "dim")),
              chips("answer", [`${best}`], "result"),
            ],
            window: bestRange ? { from: bestRange[0], to: bestRange[1], label: "best window" } : null,
            counters: [count("window", "final"), count("best", best)],
            legend: LEG,
            happened: `The widest valid window has ${best} characters.`,
            why: "The window never needs to shrink below the best width already found.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "minimum-window-substring",
    title: "Minimum Window Substring",
    category: "Strings & Text",
    difficulty: "Advanced",
    description:
      "Find the shortest piece of the text that contains every character of a target, counting duplicates.",
    input: { label: "text | target", default: "ADOBECODEBANC | ABC", parse: "string" },
    approaches: [
      {
        name: "Remaining Counts Window",
        complexity: "O(n + m) time, O(alphabet) space",
        idea: [
          "Count the target's characters. Expand the right edge, decrementing counts and tracking how many target characters are still missing.",
          "When nothing is missing, record the window and shrink from the left. Shrinking stops mattering as soon as a required character leaves.",
        ],
        problem: [
          "Duplicate characters in the target make the missing count essential; a boolean presence test answers the wrong question.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n#include <limits.h>\n\n/* returns start index and writes length; -1 if impossible */\nint min_window(const char *s, const char *t, int *outLen) {\n    int need[256] = {0}, total = 0;\n    for (int i = 0; t[i]; i++) { if (need[(unsigned char)t[i]]++ == 0) total++; }\n\n    int have[256] = {0}, formed = 0;\n    int lo = 0, bestLen = INT_MAX, bestStart = -1;\n\n    for (int hi = 0; s[hi]; hi++) {\n        unsigned char c = s[hi];\n        have[c]++;\n        if (need[c] && have[c] == need[c]) formed++;\n\n        while (formed == total) {\n            if (hi - lo + 1 < bestLen) { bestLen = hi - lo + 1; bestStart = lo; }\n            unsigned char left = s[lo++];\n            if (need[left] && have[left]-- == need[left]) formed--;\n        }\n    }\n    *outLen = bestLen == INT_MAX ? 0 : bestLen;\n    return bestStart;\n}\n\nint main(void) {\n    int len;\n    int at = min_window("ADOBECODEBANC", "ABC", &len);\n    printf("%d %d\\\\n", at, len); /* 9 4 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\n#include <unordered_map>\n#include <climits>\nusing namespace std;\n\nstring minWindow(const string& s, const string& t) {\n    unordered_map<char, int> need, have;\n    for (char c : t) need[c]++;\n    int required = need.size(), formed = 0;\n    int lo = 0, bestLen = INT_MAX, bestStart = 0;\n\n    for (int hi = 0; hi < (int)s.size(); hi++) {\n        char c = s[hi];\n        if (need.count(c)) {\n            if (++have[c] == need[c]) formed++;\n        }\n        while (formed == required) {\n            if (hi - lo + 1 < bestLen) { bestLen = hi - lo + 1; bestStart = lo; }\n            char left = s[lo++];\n            if (need.count(left) && have[left]-- == need[left]) formed--;\n        }\n    }\n    return bestLen == INT_MAX ? "" : s.substr(bestStart, bestLen);\n}\n\nint main() {\n    cout << minWindow("ADOBECODEBANC", "ABC") << '\\\\n'; // BANC\n}`,
        },
        steps(text) {
          const [sRaw, tRaw] = parts(text);
          const s = Array.from(sRaw || "");
          const t = Array.from(tRaw || "");
          if (!s.length || !t.length) {
            return [{
              title: "Give a text and a target",
              tracks: [chips("text", s.length ? s : ["—"], "idle"), chips("target", t.length ? t : ["—"], "idle")],
              counters: [count("target characters", t.length)],
              legend: ["idle", "result"],
              happened: "The left side is the text to search, the right side the required characters.",
              why: "The window must contain every target character with the right multiplicity.",
            }];
          }
          const need = new Map();
          for (const c of t) need.set(c, (need.get(c) || 0) + 1);
          const required = need.size;
          const have = new Map();
          let formed = 0, lo = 0, bestLen = Infinity, bestRange = null;
          const steps = [];
          const statusText = () => [...need.entries()].map(([c, n]) => `${c}:${Math.min(have.get(c) || 0, n)}/${n}`).join(" ");
          steps.push({
            title: `Need ${t.join("")}; ${required} distinct character${required === 1 ? "" : "s"}`,
            tracks: [track("text", s, fill(s.length, "idle")), chips("target counts", statusText().split(" "), "dim")],
            counters: [count("formed groups", 0, required), count("best length", "∞")],
            legend: LEG,
            happened: `The target counts are ${[...need.entries()].map(([c, n]) => `${c}×${n}`).join(", ")}.`,
            why: "Each required count must be met before the window is complete.",
            codeLine: 6,
          });
          for (let hi = 0; hi < s.length; hi++) {
            const c = s[hi];
            have.set(c, (have.get(c) || 0) + 1);
            if (need.has(c) && have.get(c) === need.get(c)) formed++;
            let shrank = 0;
            while (formed === required) {
              if (hi - lo + 1 < bestLen) { bestLen = hi - lo + 1; bestRange = [lo, hi]; }
              const left = s[lo];
              if (need.has(left) && have.get(left) === need.get(left)) formed--;
              have.set(left, have.get(left) - 1);
              lo++;
              shrank++;
            }
            steps.push({
              title: formed === required ? `Complete window ${lo}..${hi} (shrink ${shrank})` : `Missing ${required - formed} group${required - formed === 1 ? "" : "s"}`,
              tracks: [
                track("text", s, s.map((_, i) => (i === hi ? "read" : isWindow(i, lo, hi + 1) ? "active" : "dim"))),
                chips("counts", statusText().split(" "), (i) => ([...need.keys()][i] === c ? "result" : "dim")),
              ],
              window: { from: lo, to: hi },
              counters: [count("formed groups", formed, required), count("best length", bestLen === Infinity ? "∞" : bestLen)],
              legend: LEG,
              happened: formed === required
                ? `The window covers the target; shrinking removed ${shrank} character${shrank === 1 ? "" : "s"} while trying to improve it.`
                : `The window still misses ${required - formed} group${required - formed === 1 ? "" : "s"} of required counts.`,
              why: "Only a complete window can be a candidate; shrinking keeps the shortest one.",
              codeLine: formed === required ? 17 : 13,
            });
          }
          steps.push({
            title: bestRange ? `Answer: "${s.slice(bestRange[0], bestRange[1] + 1).join("")}" (${bestLen} characters)` : "Answer: no window contains the target",
            tracks: [
              track("text", s, s.map((_, i) => (bestRange && isWindow(i, bestRange[0], bestRange[1] + 1) ? "result" : "dim"))),
              chips("answer", bestRange ? [s.slice(bestRange[0], bestRange[1] + 1).join("")] : ["none"], "result"),
            ],
            window: bestRange ? { from: bestRange[0], to: bestRange[1], label: "best window" } : null,
            counters: [count("formed groups", formed, required), count("best length", bestRange ? bestLen : 0)],
            legend: LEG,
            happened: bestRange ? `The shortest complete window spans ${bestRange[0]}..${bestRange[1]}.` : "The scan finished without covering every required count.",
            why: "Each character enters and leaves the window once, giving linear time.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-all-anagrams-in-a-string",
    title: "Find All Anagrams in a String",
    category: "Strings & Text",
    difficulty: "Intermediate",
    description:
      "Find every start index where a fixed-length window is an anagram of the pattern.",
    input: { label: "text | pattern", default: "cbaebabacd | abc", parse: "string" },
    approaches: [
      {
        name: "Fixed-Size Window Counts",
        complexity: "O(n + m) time, O(alphabet) space",
        idea: [
          "Every anagram of the pattern has the same length and the same character counts. Slide a window of exactly that length across the text.",
          "Update the counts by removing the leaving character and adding the entering one, then compare the two count tables.",
        ],
        problem: [
          "Comparing full count tables at every step multiplies the cost by the alphabet size unless a match counter is maintained instead.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint main(void) {\n    const char *s = "cbaebabacd";\n    const char *p = "abc";\n    int need[26] = {0}, win[26] = {0};\n    int m = strlen(p), n = strlen(s);\n\n    for (int i = 0; i < m; i++) need[p[i] - 'a']++;\n\n    for (int i = 0; i < n; i++) {\n        win[s[i] - 'a']++;                 /* add entering char */\n        if (i >= m) win[s[i - m] - 'a']--; /* remove leaving char */\n\n        if (i >= m - 1) {\n            int same = 1;\n            for (int c = 0; c < 26; c++)\n                if (win[c] != need[c]) { same = 0; break; }\n            if (same) printf("%d ", i - m + 1);\n        }\n    }\n    printf("\\\\n"); /* 0 6 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\n#include <vector>\nusing namespace std;\n\nvector<int> findAnagrams(const string& s, const string& p) {\n    vector<int> need(26, 0), win(26, 0), out;\n    int m = p.size(), n = s.size();\n    if (m > n) return out;\n    for (char c : p) need[c - 'a']++;\n\n    for (int i = 0; i < n; i++) {\n        win[s[i] - 'a']++;\n        if (i >= m) win[s[i - m] - 'a']--;\n        if (i >= m - 1) {\n            if (win == need) out.push_back(i - m + 1);\n        }\n    }\n    return out;\n}\n\nint main() {\n    for (int i : findAnagrams("cbaebabacd", "abc")) cout << i << ' '; // 0 6\n    cout << '\\\\n';\n}`,
        },
        steps(text) {
          const [sRaw, pRaw] = parts(text);
          const s = Array.from(sRaw || "");
          const p = Array.from(pRaw || "");
          if (!s.length || !p.length || p.length > s.length) {
            return [{
              title: "Give a text and a pattern no longer than it",
              tracks: [chips("text", s.length ? s : ["—"], "idle"), chips("pattern", p.length ? p : ["—"], "idle")],
              counters: [count("window length", p.length), count("text length", s.length)],
              legend: ["idle", "result"],
              happened: "An anagram window must have the same length as the pattern.",
              why: "Counting characters makes the order inside the window irrelevant.",
            }];
          }
          const need = new Map();
          for (const c of p) need.set(c, (need.get(c) || 0) + 1);
          const steps = [];
          const win = new Map();
          const found = [];
          const countsText = () => [...need.keys()].map((c) => `${c}:${win.get(c) || 0}/${need.get(c)}`).join(" ");
          steps.push({
            title: `Slide a ${p.length}-character window; pattern ${p.join("")}`,
            tracks: [track("text", s, fill(s.length, "idle")), chips("pattern counts", [...need.entries()].map(([c, n]) => `${c}×${n}`), "dim")],
            counters: [count("windows checked", 0), count("matches", 0)],
            legend: LEG,
            happened: `An anagram must contain ${[...need.entries()].map(([c, n]) => `${n}×${c}`).join(", ")}.`,
            why: "A fixed window plus character counts checks an anagram without sorting.",
            codeLine: 7,
          });
          for (let i = 0; i < s.length; i++) {
            win.set(s[i], (win.get(s[i]) || 0) + 1);
            if (i >= p.length) {
              const left = s[i - p.length];
              win.set(left, win.get(left) - 1);
            }
            if (i >= p.length - 1) {
              const start = i - p.length + 1;
              const ok = [...need.entries()].every(([c, n]) => (win.get(c) || 0) === n);
              if (ok) found.push(start);
              steps.push({
                title: `Window ${start}..${i}: ${s.slice(start, i + 1).join("")}${ok ? " ✓ anagram" : ""}`,
                tracks: [
                  track("text", s, s.map((_, k) => (k === i ? "read" : isWindow(k, start, i + 1) ? (ok ? "good" : "active") : "dim"))),
                  chips("window counts", countsText().split(" "), ok ? "good" : "dim"),
                ],
                window: { from: start, to: i, label: ok ? "anagram" : "window" },
                counters: [count("windows checked", start + 1), count("matches", found.length)],
                legend: LEG,
                happened: ok
                  ? `The counts match the pattern exactly, so ${start} is an anagram start.`
                  : `At least one count differs, so this window is not an anagram.`,
                why: "Only the characters are compared, never their order.",
                codeLine: 14,
              });
            }
          }
          steps.push({
            title: `Answer: starts ${found.length ? found.join(", ") : "none"}`,
            tracks: [
              track("text", s, s.map((_, i) => (found.some((f) => isWindow(i, f, f + p.length)) ? "result" : "dim"))),
              chips("starts", found.length ? found : ["none"], "result"),
            ],
            windows: found.map((f) => ({ from: f, to: f + p.length - 1, label: "match" })),
            counters: [count("windows checked", s.length - p.length + 1), count("matches", found.length)],
            legend: LEG,
            happened: found.length ? `Anagrams begin at ${found.join(", ")}.` : "No window matched the pattern counts.",
            why: "The sliding update is constant time, so the scan is linear.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "longest-palindromic-substring",
    title: "Longest Palindromic Substring",
    category: "Strings & Text",
    difficulty: "Intermediate",
    description:
      "Expand around every centre to find the longest piece that reads the same in both directions.",
    input: { label: "text", default: "babad", parse: "chars" },
    approaches: [
      {
        name: "Expand Around Centre",
        complexity: "O(n²) time, O(1) space",
        idea: [
          "A palindrome is symmetric around a centre, which is either one character or the gap between two characters.",
          "Try every centre once and expand while the characters match. The longest expansion is the answer.",
        ],
        problem: [
          "Quadratic time is acceptable for short texts but too slow for very long ones, where hashing or Manacher's method is needed.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nvoid expand(const char *s, int lo, int hi, int *bestStart, int *bestLen) {\n    while (lo >= 0 && s[hi] && s[lo] == s[hi]) { lo--; hi++; }\n    int len = hi - lo - 1;\n    if (len > *bestLen) { *bestLen = len; *bestStart = lo + 1; }\n}\n\nint main(void) {\n    const char *s = "babad";\n    int start = 0, best = 0;\n    for (int i = 0; s[i]; i++) {\n        expand(s, i, i, &start, &best);       /* odd centre */\n        expand(s, i, i + 1, &start, &best);   /* even centre */\n    }\n    printf(\"%.*s\\\\n\", best, s + start); /* bab */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\nusing namespace std;\n\nvoid expand(const string& s, int lo, int hi, int& bestStart, int& bestLen) {\n    while (lo >= 0 && hi < (int)s.size() && s[lo] == s[hi]) { lo--; hi++; }\n    int len = hi - lo - 1;\n    if (len > bestLen) { bestLen = len; bestStart = lo + 1; }\n}\n\nstring longestPalindrome(const string& s) {\n    int bestStart = 0, bestLen = 0;\n    for (int i = 0; i < (int)s.size(); i++) {\n        expand(s, i, i, bestStart, bestLen);\n        expand(s, i, i + 1, bestStart, bestLen);\n    }\n    return s.substr(bestStart, bestLen);\n}\n\nint main() {\n    cout << longestPalindrome("babad") << '\\\\n'; // bab\n}`,
        },
        steps(text) {
          const s = Array.from(String(text || ""));
          if (!s.length) {
            return [{
              title: "Give some text",
              tracks: [chips("text", ["—"], "idle")],
              counters: [count("length", 0)],
              legend: ["idle", "result"],
              happened: "An empty text has no palindrome.",
              why: "Expansion needs at least one centre character.",
            }];
          }
          const steps = [];
          let bestStart = 0, bestLen = 0;
          const expand = (lo, hi, label) => {
            const startLo = lo, startHi = hi;
            while (lo >= 0 && hi < s.length && s[lo] === s[hi]) { lo--; hi++; }
            const len = hi - lo - 1;
            const improved = len > bestLen;
            if (improved) { bestLen = len; bestStart = lo + 1; }
            steps.push({
              title: improved
                ? `${label} at ${startLo}${startHi !== startLo ? `,${startHi}` : ""} expands to "${s.slice(lo + 1, hi).join("")}" (${len})`
                : `${label} at ${startLo}${startHi !== startLo ? `,${startHi}` : ""} reaches ${len}, no better`,
              tracks: [
                track("text", s, s.map((_, i) => (i >= lo + 1 && i < hi ? (improved ? "good" : "compare") : i === startLo || i === startHi ? "read" : "dim"))),
                chips("best so far", bestLen ? [`"${s.slice(bestStart, bestStart + bestLen).join("")}"`] : ["—"], "result"),
              ],
              counters: [count("centre", `${startLo}${startHi !== startLo ? `,${startHi}` : ""}`), count("best length", bestLen)],
              legend: LEG,
              happened: improved
                ? `The expansion around this centre is longer than any seen before.`
                : `Matching stopped, and this palindrome is not the longest.`,
              why: "Each centre gives one maximal palindrome, so checking all centres covers the answer.",
              codeLine: label === "odd" ? 8 : 9,
            });
          };
          steps.push({
            title: `${s.length} characters → ${2 * s.length - 1} centres`,
            tracks: [track("text", s, fill(s.length, "idle"))],
            counters: [count("centres left", 2 * s.length - 1), count("best length", 0)],
            legend: LEG,
            happened: `The text is "${s.join("")}"; odd centres sit on characters, even centres between them.`,
            why: "Every palindrome has exactly one centre, so trying them all cannot miss it.",
            codeLine: 6,
          });
          for (let i = 0; i < s.length; i++) {
            expand(i, i, "odd");
            if (i + 1 < s.length) expand(i, i + 1, "even");
          }
          steps.push({
            title: `Answer: "${s.slice(bestStart, bestStart + bestLen).join("")}" (${bestLen} characters)`,
            tracks: [
              track("text", s, s.map((_, i) => (isWindow(i, bestStart, bestStart + bestLen) ? "result" : "dim"))),
              chips("answer", [s.slice(bestStart, bestStart + bestLen).join("")], "result"),
            ],
            counters: [count("centres checked", 2 * s.length - 1), count("answer length", bestLen)],
            legend: LEG,
            happened: `The best centre expands to the substring at ${bestStart}..${bestStart + bestLen - 1}.`,
            why: "Expanding while characters match gives the maximal palindrome for that centre.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });
})();
