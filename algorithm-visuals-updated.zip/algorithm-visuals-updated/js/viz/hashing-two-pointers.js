/* ============================================================
   DSA Visuals — Hashing & Two Pointers
   Nine visualisations about remembering values (sets and maps)
   and about walking a row from both ends or at two speeds.
   Contract (see SPEC.md):
     { id, title, category, difficulty, description,
       input: { label, default, parse },
       approaches: [ { name, complexity, idea, problem,
                       code: { c, cpp }, steps(parsed) } ] }
   Each step: { title, tracks, counters, happened, why,
                legend?, codeLine? }   (kind defaults to "cells")
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  /* ----------------------------------------------------------
     small shared helpers
     ---------------------------------------------------------- */

  /** every state idle, or one repeated state, for a row of n cells */
  const blank = (n, s) => fill(n, s || "idle");

  /** "a, b, c" for short lists, "—" when there is nothing to show */
  const fmt = (list) => (list && list.length ? list.join(", ") : "—");

  /** digits of |n| with the sum of their squares — the happy-number move */
  function squareStep(n) {
    const digits = String(Math.abs(n)).split("").map(Number);
    let sum = 0;
    const parts = [];
    for (const d of digits) {
      sum += d * d;
      parts.push(d + "²");
    }
    return { digits, sum, parts, text: parts.join(" + ") };
  }

  /** true when the row never decreases */
  function sortedAsc(a) {
    for (let i = 1; i < a.length; i++) if (a[i - 1] > a[i]) return false;
    return true;
  }

  /** split tokens into a numeric list plus an optional name=<number> target.
      Tokens that are neither counted as "bad" and left out. */
  function splitPrefixed(tokens, name) {
    const re = new RegExp("^" + name + "=(-?\\d+(?:\\.\\d+)?)$", "i");
    let target = null, bad = 0;
    const values = [];
    for (const raw of tokens) {
      const t = String(raw);
      const m = re.exec(t);
      if (m) { target = Number(m[1]); continue; }
      const v = Number(t);
      if (t !== "" && Number.isFinite(v)) values.push(v);
      else bad++;
    }
    return { target, values, bad };
  }

  /** how many pair comparisons a brute-force walk will show at most */
  const BRUTE_CAP = 120;

  /* ----------------------------------------------------------
     registration helper
     A step's legend should show every state it actually paints.
     Rather than repeat that list by hand for all eighteen
     approaches, this helper reads the cells of each finished step
     and fills the legend in (keeping any order already given).
     ---------------------------------------------------------- */
  const LEGEND_ORDER = ["read", "compare", "swap", "active", "result", "good", "bad", "done", "dim", "idle"];

  function legendFor(step) {
    const used = [];
    const add = (k) => { if (k && used.indexOf(k) === -1) used.push(k); };
    (step.tracks || []).forEach((t) => (t.cells || []).forEach((c) => add(c.state)));
    (step.nodes || []).forEach((n) => add(n.state));
    (step.cells || []).forEach((c) => add(c.state));
    const declared = Array.isArray(step.legend) ? step.legend.slice() : [];
    if (!used.length && !declared.length) return ["read", "done", "result", "idle"];
    const out = declared.slice();
    LEGEND_ORDER.forEach((k) => {
      if (used.indexOf(k) !== -1 && out.indexOf(k) === -1) out.push(k);
    });
    return out;
  }

  function register(def) {
    (def.approaches || []).forEach((a) => {
      if (typeof a.steps !== "function") return;
      const raw = a.steps;
      a.steps = function (parsed) {
        const steps = raw.call(this, parsed) || [];
        steps.forEach((s) => { s.legend = legendFor(s); });
        return steps;
      };
    });
    return V.register(def);
  }

  /* ==========================================================
     1. contains-duplicate
     ========================================================== */
  register({
    id: "contains-duplicate",
    title: "Contains Duplicate",
    category: "Hashing & Two Pointers",
    difficulty: "Beginner",
    description: "Decide whether any value in a row appears at least twice.",
    input: { label: "The numbers", default: "5, 3, 8, 3, 9, 2", parse: "ints" },
    approaches: [
      {
        name: "Compare Every Pair",
        complexity: "O(n²) time, O(1) space",
        idea: [
          "Take the first number and hold it up against every number to its right, then move to the second number and repeat.",
          "The first time two positions hold the same value the answer is yes, and the walk can stop right there.",
        ],
        problem: [
          "n numbers create about n²/2 pairs, so this is slow on big rows. It uses no extra memory at all, which is its only real advantage.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* two equal values anywhere in the row? */
bool has_duplicate(const int *a, int n) {
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
            if (a[i] == a[j])
                return true;
    return false;
}

int main(void) {
    int a[] = {5, 3, 8, 3, 9, 2};
    printf("%s\\n", has_duplicate(a, 6) ? "yes" : "no"); /* yes */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// compare every unordered pair (i, j) with j > i
bool hasDuplicate(const std::vector<int>& a) {
    for (size_t i = 0; i < a.size(); ++i)
        for (size_t j = i + 1; j < a.size(); ++j)
            if (a[i] == a[j])
                return true;
    return false;
}

int main() {
    std::vector<int> a{5, 3, 8, 3, 9, 2};
    std::cout << (hasDuplicate(a) ? "yes" : "no") << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const totalPairs = (n * (n - 1)) / 2;

          // find the true answer first (cheap) so the last step is honest
          let pair = null;
          for (let i = 0; i < n && !pair; i++)
            for (let j = i + 1; j < n; j++)
              if (nums[i] === nums[j]) { pair = [i, j]; break; }

          steps.push({
            title: n < 2 ? "Fewer than two numbers — no pair exists" : `${n} numbers make ${totalPairs} pairs to test`,
            tracks: [track("the numbers", nums, blank(n, "idle"))],
            counters: [count("pairs checked", 0, totalPairs), count("found a repeat?", "not yet")],
            legend: ["compare", "read", "bad", "good", "idle"],
            happened: n < 2
              ? `Only ${n} number${n === 1 ? "" : "s"} arrived, so there is nothing to pair up.`
              : `Every unordered pair of positions is a chance to spot a repeat.`,
            why: "Listing all pairs is the brute-force way of being sure nothing was skipped.",
            codeLine: 4,
          });

          let shown = 0, truncated = false;
          for (let i = 0; i < n; i++) {
            let stop = false;
            for (let j = i + 1; j < n; j++) {
              if (shown >= BRUTE_CAP) { truncated = true; stop = true; break; }
              shown++;
              const hit = nums[i] === nums[j];
              const st = blank(n, "idle");
              for (let k = 0; k < i; k++) st[k] = "done";
              st[i] = "compare";
              st[j] = hit ? "bad" : "read";
              steps.push({
                title: hit
                  ? `${nums[i]} at index ${i} matches ${nums[j]} at index ${j} → repeat`
                  : `${nums[i]} (index ${i}) vs ${nums[j]} (index ${j}) — different`,
                tracks: [track("the numbers", nums, st)],
                counters: [count("pairs checked", shown, totalPairs), count("found a repeat?", hit ? "yes" : "not yet")],
                happened: hit
                  ? `Index ${i} and index ${j} both hold ${nums[i]} — a repeat is confirmed.`
                  : `${nums[i]} and ${nums[j]} differ, so this pair is cleared.`,
                why: hit
                  ? "One matching pair is proof enough; nothing later can undo it."
                  : "Each cleared pair removes one possibility without having to remember anything.",
                codeLine: hit ? 7 : 6,
              });
              if (hit) {
                steps.push({
                  title: `Answer: duplicate ${nums[i]}`,
                  tracks: [track("the numbers", nums, nums.map((v, k) => (k === i || k === j ? "bad" : "dim")))],
                  counters: [count("pairs checked", shown, totalPairs), count("answer", "yes")],
                  happened: `${nums[i]} sits at index ${i} and again at index ${j}, so the row is not all distinct.`,
                  why: "The walk quit the moment the pair matched — the remaining pairs were never needed.",
                  codeLine: 8,
                });
                return steps;
              }
            }
            if (stop) break;
          }

          if (truncated) {
            steps.push({
              title: `Animation stops after ${shown} pairs — the rest look the same`,
              tracks: [track("the numbers", nums, blank(n, "done"))],
              counters: [count("pairs checked", shown, totalPairs)],
              happened: `Showing all ${totalPairs} comparisons would be a very long film; the remaining ones are ordinary mismatches.`,
              why: "A picture only needs enough comparisons to make the pattern obvious.",
              codeLine: 5,
            });
          }

          steps.push({
            title: n < 2 ? "Answer: no duplicate (nothing to repeat)" : `Answer: no duplicate — all ${totalPairs} pairs differ`,
            tracks: [track("the numbers", nums, blank(n, "good"))],
            counters: [count("pairs checked", totalPairs, totalPairs), count("answer", "no")],
            happened: n < 2
              ? "A single value cannot be a duplicate of anything."
              : `No pair held equal values, so every number in the row is unique.`,
            why: "Every pair was tested, so no hidden repeat can exist anywhere in the row.",
            codeLine: 9,
          });
          return steps;
        },
      },
      {
        name: "Remember Values in a Set",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Walk the row once, keeping a set of the values already met. For each new number, ask the set whether it has seen this value before.",
          "A 'yes' means a repeat; a 'no' means the value joins the set and the walk continues.",
        ],
        problem: [
          "The set costs memory proportional to the number of distinct values. That extra memory is exactly what buys the single pass.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* values here are small and non-negative, so a plain table acts as a set */
bool has_duplicate(const int *a, int n) {
    bool seen[1000] = {false};
    for (int i = 0; i < n; i++) {
        if (seen[a[i]]) return true;   /* met this value before */
        seen[a[i]] = true;
    }
    return false;
}

int main(void) {
    int a[] = {5, 3, 8, 3, 9, 2};
    printf("%s\\n", has_duplicate(a, 6) ? "yes" : "no"); /* yes */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_set>

// one pass with a set of everything already seen
bool hasDuplicate(const std::vector<int>& a) {
    std::unordered_set<int> seen;
    for (int x : a)
        if (!seen.insert(x).second)   // insert failed -> x was already there
            return true;
    return false;
}

int main() {
    std::vector<int> a{5, 3, 8, 3, 9, 2};
    std::cout << (hasDuplicate(a) ? "yes" : "no") << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const seen = new Set();
          const seenTrack = (fresh) => ({
            label: "values remembered",
            cells: seen.size
              ? [...seen].map((v) => ({ v, state: v === fresh ? "result" : "done" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          steps.push({
            title: n < 2 ? "One number can never repeat itself" : "One pass, one set of remembered values",
            tracks: [
              track("the numbers", nums, blank(n, "idle")),
              seenTrack(null),
            ],
            counters: [count("numbers read", 0, n), count("values remembered", 0)],
            legend: ["read", "result", "bad", "good", "done"],
            happened: n < 2
              ? `With ${n} number${n === 1 ? "" : "s"} there is nothing that could clash with it.`
              : "The set starts empty; it will grow as new values appear.",
            why: "A set answers 'have I met this value?' in one step, no matter how many values are stored.",
            codeLine: 4,
          });

          for (let i = 0; i < n; i++) {
            const x = nums[i];
            const hit = seen.has(x);
            const before = seen.size;
            if (!hit) seen.add(x);
            const st = blank(n, hit ? "bad" : "done");
            st[i] = hit ? "bad" : "read";
            steps.push({
              title: hit ? `${x} is already remembered → repeat found` : `${x} is new → remember it`,
              tracks: [
                track("the numbers", nums, st),
                seenTrack(hit ? null : x),
              ],
              counters: [
                count("numbers read", i + 1, n),
                count("values remembered", seen.size),
                count("found a repeat?", hit ? "yes" : "not yet"),
              ],
              happened: hit
                ? `${x} was placed in the set earlier, so the second copy proves a repeat.`
                : `${x} was not in the set, so it is added${before === 0 ? " as the first entry" : ""}.`,
              why: hit
                ? "The set lookup took one step instead of rescanning the numbers already passed."
                : "Recording each value once is what makes the next clash obvious.",
              codeLine: hit ? 6 : 7,
            });
            if (hit) {
              steps.push({
                title: `Answer: duplicate ${x}`,
                tracks: [
                  track("the numbers", nums, nums.map((v, k) => (v === x ? "bad" : "dim"))),
                  { label: "answer", cells: [{ v: x, state: "result", tag: "seen twice" }] },
                ],
                counters: [count("numbers read", i + 1, n), count("answer", "yes")],
                happened: `${x} appeared at index ${nums.indexOf(x)} and again at index ${i}.`,
                why: "The first repeat settles the question, so the rest of the row is left unread.",
                codeLine: 6,
              });
              return steps;
            }
          }

          steps.push({
            title: n < 2 ? "Answer: no duplicate" : `Answer: no duplicate — ${n} distinct values`,
            tracks: [
              track("the numbers", nums, blank(n, "good")),
              seenTrack(null),
            ],
            counters: [count("numbers read", n, n), count("answer", "no")],
            happened: n < 2
              ? "Nothing to compare against, so there is no repeat."
              : `The walk finished with ${seen.size} remembered values and no clash.`,
            why: "One pass was enough because every value was checked against the set as it arrived.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     2. intersection-of-two-arrays
     ========================================================== */
  register({
    id: "intersection-of-two-arrays",
    title: "Intersection of Two Arrays",
    category: "Hashing & Two Pointers",
    difficulty: "Beginner",
    description: "List the distinct values that appear in both of two rows.",
    input: { label: "arr1 | arr2", default: "1, 3, 5, 3 | 3, 1, 5", parse: "tworows" },
    approaches: [
      {
        name: "Check Every Pair",
        complexity: "O(n·m) time, O(1) extra space",
        idea: [
          "Take each value of the first row and look for it anywhere in the second row.",
          "If it is found and has not already been added, it belongs in the result; repeated copies in the first row are skipped.",
        ],
        problem: [
          "The same scan is repeated for every value, which is slow when both rows are long, and it needs a check against the result to avoid listing a value twice.",
        ],
        code: {
          c: `#include <stdio.h>

/* distinct values present in both rows, written into out[] */
int intersection(const int *a, int na, const int *b, int nb, int *out) {
    int m = 0;
    for (int i = 0; i < na; i++) {
        int already = 0;
        for (int t = 0; t < m; t++)
            if (out[t] == a[i]) { already = 1; break; }
        if (already) continue;                  /* value already listed */
        for (int j = 0; j < nb; j++)
            if (a[i] == b[j]) { out[m++] = a[i]; break; }
    }
    return m;
}

int main(void) {
    int a[] = {1, 3, 5, 3}, b[] = {3, 1, 5}, out[8];
    int m = intersection(a, 4, b, 3, out);
    for (int i = 0; i < m; i++) printf("%d ", out[i]); /* 1 3 5 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// a value of a[] joins the result the first time b[] contains it
std::vector<int> intersection(const std::vector<int>& a,
                              const std::vector<int>& b) {
    std::vector<int> out;
    for (int x : a) {
        bool inB = false;
        for (int y : b)
            if (y == x) { inB = true; break; }
        bool fresh = true;
        for (int v : out)
            if (v == x) { fresh = false; break; }
        if (inB && fresh) out.push_back(x);
    }
    return out;
}

int main() {
    for (int v : intersection({1, 3, 5, 3}, {3, 1, 5}))
        std::cout << v << ' ';   // 1 3 5
}`,
        },
        steps(rows) {
          const A = rows[0] || [];
          const B = rows[1] || [];
          const nA = A.length;
          const out = [];
          const steps = [];
          const resultTrack = (hot) => ({
            label: "result",
            cells: out.length
              ? out.map((v) => ({ v, state: v === hot ? "result" : "good" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          steps.push({
            title: "Two rows — keep only the values they share",
            tracks: [
              track("arr1", A, blank(nA, "idle")),
              track("arr2", B, blank(B.length, "idle")),
              resultTrack(null),
            ],
            counters: [count("values in arr1", nA), count("values in arr2", B.length), count("shared so far", 0)],
            legend: ["compare", "read", "good", "bad", "done"],
            happened: `arr1 holds ${fmt(A)} and arr2 holds ${fmt(B)}.`,
            why: "A value can only enter the result after it has been found in both rows, and only once.",
            codeLine: 4,
          });

          let shown = 0;
          for (let i = 0; i < nA; i++) {
            const v = A[i];
            if (out.indexOf(v) !== -1) {
              steps.push({
                title: `${v} is already in the result — the repeat is ignored`,
                tracks: [
                  track("arr1", A, paint(blank(nA, "done"), { [i]: "bad" })),
                  track("arr2", B, blank(B.length, "done")),
                  resultTrack(null),
                ],
                counters: [count("values checked", i + 1, nA), count("shared so far", out.length)],
                happened: `arr1 contains ${v} more than once, but the result should hold each shared value a single time.`,
                why: "The 'already added' check is what keeps the output a set rather than a bag.",
                codeLine: 7,
              });
              continue;
            }
            let found = -1;
            for (let j = 0; j < B.length; j++) {
              if (shown >= BRUTE_CAP) break;
              shown++;
              const hit = v === B[j];
              if (hit) found = j;
              const stA = blank(nA, "done"); stA[i] = "compare";
              const stB = blank(B.length, "idle");
              for (let k = 0; k < j; k++) stB[k] = "bad";
              stB[j] = hit ? "good" : "read";
              steps.push({
                title: hit ? `${v} found in arr2 at position ${j}` : `${v} vs arr2[${j}] = ${B[j]} — no match`,
                tracks: [
                  track("arr1", A, stA),
                  track("arr2", B, stB),
                  resultTrack(null),
                ],
                counters: [count("values checked", i + 1, nA), count("pair tests", shown), count("shared so far", out.length)],
                happened: hit
                  ? `${v} from arr1 equals ${B[j]} in arr2, so it belongs to the answer.`
                  : `${v} and ${B[j]} differ, so this position of arr2 is ruled out.`,
                why: hit
                  ? "The inner scan can stop at the first match — one hit is all the proof needed."
                  : "Every position of arr2 has to be compared before giving up on a value.",
                codeLine: hit ? 10 : 9,
              });
              if (hit) break;
            }
            if (found >= 0) {
              out.push(v);
              steps.push({
                title: `${v} joins the result`,
                tracks: [
                  track("arr1", A, paint(blank(nA, "done"), { [i]: "good" })),
                  track("arr2", B, blank(B.length, "done")),
                  resultTrack(v),
                ],
                counters: [count("values checked", i + 1, nA), count("shared so far", out.length)],
                happened: `${v} is present in both rows, so it is written into the result.`,
                why: "Values are added in the order they appear in arr1, which gives a stable, predictable answer.",
                codeLine: 10,
              });
            } else {
              steps.push({
                title: `No copy of ${v} in arr2 — dropped`,
                tracks: [
                  track("arr1", A, paint(blank(nA, "done"), { [i]: "bad" })),
                  track("arr2", B, blank(B.length, "bad")),
                  resultTrack(null),
                ],
                counters: [count("values checked", i + 1, nA), count("shared so far", out.length)],
                happened: `arr2 never showed ${v}, so this value cannot be shared.`,
                why: "A value missing from either row is eliminated; no further work is needed for it.",
                codeLine: 10,
              });
            }
          }

          steps.push({
            title: `Answer: ${fmt(out)} (${out.length} shared value${out.length === 1 ? "" : "s"})`,
            tracks: [
              track("arr1", A, A.map((v) => (out.indexOf(v) !== -1 ? "good" : "dim"))),
              track("arr2", B, B.map((v) => (out.indexOf(v) !== -1 ? "good" : "dim"))),
              resultTrack(null),
            ],
            counters: [count("values checked", nA, nA), count("answer", out.length)],
            happened: out.length
              ? `The values ${fmt(out)} appear in both rows and are listed once each.`
              : "No value of arr1 was found in arr2, so the intersection is empty.",
            why: "Every value of arr1 was tested against arr2, so nothing shared could have been missed.",
            codeLine: 12,
          });
          return steps;
        },
      },
      {
        name: "Set of arr2, Then Sweep arr1",
        complexity: "O(n + m) time, O(m) space",
        idea: [
          "First pour arr2 into a set, which removes its duplicates and makes lookups instant.",
          "Then walk arr1 once: a value enters the result the first time it is found in the set.",
        ],
        problem: [
          "The set holds every distinct value of arr2, so it costs extra memory. In exchange each arr1 value is tested in one step instead of a whole scan.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* values 0..999: mark arr2, then sweep arr1 once */
int intersection(const int *a, int na, const int *b, int nb, int *out) {
    bool inB[1000] = {false}, used[1000] = {false};
    for (int j = 0; j < nb; j++) inB[b[j]] = true;
    int m = 0;
    for (int i = 0; i < na; i++) {
        int v = a[i];
        if (inB[v] && !used[v]) {
            used[v] = true;          /* first copy only */
            out[m++] = v;
        }
    }
    return m;
}

int main(void) {
    int a[] = {1, 3, 5, 3}, b[] = {3, 1, 5}, out[8];
    int m = intersection(a, 4, b, 3, out);
    for (int i = 0; i < m; i++) printf("%d ", out[i]); /* 1 3 5 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_set>

// arr2 becomes a set; arr1 is swept once, each hit added once
std::vector<int> intersection(const std::vector<int>& a,
                              const std::vector<int>& b) {
    std::unordered_set<int> inB(b.begin(), b.end());
    std::unordered_set<int> added;
    std::vector<int> out;
    for (int x : a) {
        if (inB.count(x) && added.insert(x).second)
            out.push_back(x);
    }
    return out;
}

int main() {
    for (int v : intersection({1, 3, 5, 3}, {3, 1, 5}))
        std::cout << v << ' ';   // 1 3 5
}`,
        },
        steps(rows) {
          const A = rows[0] || [];
          const B = rows[1] || [];
          const setB = [...new Set(B)];
          const out = [];
          const steps = [];
          const setTrack = (hot) => ({
            label: "set built from arr2",
            cells: setB.length
              ? setB.map((v) => ({ v, state: v === hot ? "result" : "done" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });
          const resultTrack = (hot) => ({
            label: "result",
            cells: out.length
              ? out.map((v) => ({ v, state: v === hot ? "result" : "good" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          steps.push({
            title: "Plan: turn arr2 into a set, then sweep arr1 once",
            tracks: [
              track("arr1", A, blank(A.length, "idle")),
              track("arr2", B, blank(B.length, "idle")),
              setTrack(null),
              resultTrack(null),
            ],
            counters: [count("values in arr1", A.length), count("values in arr2", B.length)],
            legend: ["read", "good", "bad", "result", "done"],
            happened: `arr2 holds ${fmt(B)}; its distinct values will be remembered in a set.`,
            why: "A set gives an instant yes/no for membership, so arr1 never has to be rescanned.",
            codeLine: 4,
          });

          steps.push({
            title: `Set of arr2 holds ${fmt(setB)}`,
            tracks: [
              track("arr1", A, blank(A.length, "idle")),
              track("arr2", B, blank(B.length, "done")),
              setTrack(null),
              resultTrack(null),
            ],
            counters: [count("distinct in arr2", setB.length)],
            happened: `The ${B.length} entries of arr2 collapsed to ${setB.length} distinct value${setB.length === 1 ? "" : "s"}.`,
            why: "Duplicates in arr2 do not matter for membership, so the set quietly drops them.",
            codeLine: 5,
          });

          for (let i = 0; i < A.length; i++) {
            const v = A[i];
            const inSet = setB.indexOf(v) !== -1;
            const fresh = out.indexOf(v) === -1;
            const add = inSet && fresh;
            if (add) out.push(v);
            const stA = blank(A.length, "done");
            stA[i] = add ? "good" : inSet ? "bad" : "read";
            steps.push({
              title: add
                ? `${v} is in the set and new → added to the result`
                : inSet
                  ? `${v} is in the set but already listed → skip`
                  : `${v} is not in the set → skip`,
              tracks: [
                track("arr1", A, stA),
                track("arr2", B, blank(B.length, "done")),
                setTrack(add || inSet ? v : null),
                resultTrack(add ? v : null),
              ],
              counters: [
                count("values of arr1 swept", i + 1, A.length),
                count("shared so far", out.length),
              ],
              happened: add
                ? `${v} lives in the set and has not been listed yet, so it joins the result.`
                : inSet
                  ? `${v} is in the set, but an earlier copy of it already reached the result.`
                  : `${v} is absent from the set, so it cannot be shared.`,
              why: add
                ? "Membership was a single set lookup instead of a scan through arr2."
                : "The set turns each value of arr1 into one cheap yes/no question.",
              codeLine: add ? 9 : 8,
            });
          }

          steps.push({
            title: `Answer: ${fmt(out)} (${out.length} value${out.length === 1 ? "" : "s"})`,
            tracks: [
              track("arr1", A, A.map((v) => (out.indexOf(v) !== -1 ? "good" : "dim"))),
              track("arr2", B, B.map((v) => (out.indexOf(v) !== -1 ? "good" : "dim"))),
              setTrack(null),
              resultTrack(null),
            ],
            counters: [count("values of arr1 swept", A.length, A.length), count("answer", out.length)],
            happened: out.length
              ? `Sweeping arr1 against the set produced ${fmt(out)}.`
              : "Nothing in arr1 was present in the set, so the intersection is empty.",
            why: "One build and one sweep replaced all the repeated scanning of the previous approach.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     3. happy-number
     ========================================================== */
  register({
    id: "happy-number",
    title: "Happy Number",
    category: "Hashing & Two Pointers",
    difficulty: "Intermediate",
    description: "Repeatedly square-and-add the digits; does the chain reach 1 or loop forever?",
    input: { label: "One whole number", default: "19", parse: "int" },
    approaches: [
      {
        name: "Follow the Chain, Remember Where You've Been",
        complexity: "O(chain length) time, O(chain length) space",
        idea: [
          "Replace the number by the sum of the squares of its digits, over and over. For 19 the chain is 19 → 82 → 68 → 100 → 1.",
          "A set records every number seen. Reaching 1 means happy; meeting a number twice means the chain has entered a loop and can never reach 1.",
        ],
        problem: [
          "The set grows with the chain, and the loop test only fires after a repeat actually appears — you cannot see the cycle coming in advance.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* sum of the squares of the decimal digits of n */
int digit_square_sum(int n) {
    int total = 0;
    while (n > 0) {
        int d = n % 10;
        total += d * d;
        n /= 10;
    }
    return total;
}

/* happy when the chain of square-sums reaches 1 before it repeats */
bool is_happy(int n) {
    bool seen[1000] = {false};
    while (n != 1 && !seen[n]) {
        seen[n] = true;
        n = digit_square_sum(n);
    }
    return n == 1;
}

int main(void) {
    printf("%s\\n", is_happy(19) ? "happy" : "not happy"); /* happy */
    return 0;
}`,
          cpp: `#include <iostream>
#include <unordered_set>

int digitSquareSum(int n) {
    int total = 0;
    while (n > 0) { int d = n % 10; total += d * d; n /= 10; }
    return total;
}

// a repeat means a loop, and a loop can never reach 1
bool isHappy(int n) {
    std::unordered_set<int> seen;
    while (n != 1 && seen.insert(n).second)
        n = digitSquareSum(n);
    return n == 1;
}

int main() {
    std::cout << (isHappy(19) ? "happy" : "not happy") << '\\n'; // happy
}`,
        },
        steps(value) {
          const n0 = Math.floor(Number(value));
          const steps = [];

          if (!Number.isFinite(n0) || n0 < 0) {
            steps.push({
              title: "This game is only defined for whole numbers from 0 upwards",
              tracks: [track("the number", [n0], ["bad"])],
              counters: [count("meaningful chains", 0)],
              legend: ["read", "result", "bad", "dim"],
              happened: `The input ${value} is negative, so the digit-square rule has no natural meaning here.`,
              why: "Rather than invent a rule, the walk stops and reports that no answer applies.",
              codeLine: 5,
            });
            steps.push({
              title: "Answer: no answer for a negative starting point",
              tracks: [track("the number", [n0], ["dim"])],
              counters: [count("answer", "n/a")],
              happened: "Happy numbers are asked about non-negative integers; this input is outside that range.",
              why: "An honest 'not applicable' beats a made-up chain of numbers.",
              codeLine: 5,
            });
            return steps;
          }

          const seen = new Set();
          const chain = [n0];
          let n = n0;
          let looped = false;
          let capped = false;
          let guard = 0;

          steps.push({
            title: `Start with ${n0}; the set is empty`,
            tracks: [
              track("the chain", chain, ["read"]),
              track("numbers remembered", [], []),
              { label: "next move", cells: [{ v: "square each digit, then add", state: "active", tag: "the rule" }] },
            ],
            counters: [count("chain length", 1), count("numbers remembered", 0)],
            legend: ["read", "result", "bad", "done"],
            happened: `${n0} opens the chain. The rule is: replace a number by the sum of the squares of its digits.`,
            why: "With the starting value in hand the only question is whether the chain reaches 1 or starts repeating.",
            codeLine: 4,
          });

          while (n !== 1 && !seen.has(n) && guard++ < 60) {
            seen.add(n);
            const sq = squareStep(n);
            const next = sq.sum;
            chain.push(next);
            const repeated = seen.has(next) || next === 0;
            steps.push({
              title: `${n} → ${sq.text} = ${next}`,
              tracks: [
                track("the chain", chain, chain.map((v, i) => (i === chain.length - 1 ? "result" : i === chain.length - 2 ? "read" : "done"))),
                track("numbers remembered", [...seen], [...seen].map((v) => (v === n ? "active" : "done"))),
                { label: "digits", cells: sq.digits.map((d) => ({ v: d + "²=" + d * d, state: "active" })) },
              ],
              counters: [count("chain length", chain.length), count("numbers remembered", seen.size)],
              happened: `The digits of ${n} are squared and added to give ${next}.`,
              why: "Each step keeps only the running number; the individual digits are used once and thrown away.",
              codeLine: 7,
            });
            n = next;
            if (repeated) { looped = true; }
          }
          if (guard >= 60) capped = true;

          const happy = n === 1;
          const finalChain = chain.concat(happy || looped ? [] : [n]);
          if (happy) {
            steps.push({
              title: "Answer: happy — the chain reached 1",
              tracks: [
                track("the chain", chain, chain.map((v, i) => (i === chain.length - 1 ? "result" : "done"))),
                { label: "answer", cells: [{ v: "happy", state: "result", tag: "reached 1" }] },
              ],
              counters: [count("chain length", chain.length), count("answer", "happy")],
              happened: `${n0} squares down to 1 after ${chain.length - 1} move${chain.length - 1 === 1 ? "" : "s"}, so it is a happy number.`,
              why: "Once 1 appears the rule keeps it there forever, so the chain can never loop.",
              codeLine: 14,
            });
          } else {
            steps.push({
              title: looped && !capped
                ? `Answer: not happy — the chain loops`
                : `Answer: not happy (walk stopped early)`,
              tracks: [
                track("the chain", finalChain, finalChain.map((v, i) => (i === finalChain.length - 1 ? "bad" : "done"))),
                { label: "answer", cells: [{ v: "not happy", state: "bad", tag: "stuck in a loop" }] },
              ],
              counters: [count("chain length", finalChain.length), count("answer", "not happy")],
              happened: looped && !capped
                ? `The chain returned to a value it had already used, so it can never reach 1.`
                : "The walk was cut short after 60 moves and never reached 1, which is what every non-happy chain does.",
              why: "A repeat is a permanent loop: the same numbers will be produced again and again, so 1 will never appear.",
              codeLine: 15,
            });
          }
          return steps;
        },
      },
      {
        name: "Two Runners at Different Speeds",
        complexity: "O(chain length) time, O(1) space",
        idea: [
          "Put one runner on the chain moving one step at a time and a second moving two steps at a time.",
          "If the chain loops, the fast runner laps the slow one and they stand on the same number. If the chain reaches 1, the runners meet at 1 instead.",
        ],
        problem: [
          "The trick answers 'does it loop?' but not where the loop starts, and it still has to walk the whole chain — it only saves the memory a set would use.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

int digit_square_sum(int n) {
    int total = 0;
    while (n > 0) { int d = n % 10; total += d * d; n /= 10; }
    return total;
}

/* slow one step, fast two; on a loop they must collide */
bool is_happy(int n) {
    int slow = digit_square_sum(n);
    int fast = digit_square_sum(digit_square_sum(n));
    while (slow != fast) {
        slow = digit_square_sum(slow);
        fast = digit_square_sum(digit_square_sum(fast));
    }
    return slow == 1;
}

int main(void) {
    printf("%s\\n", is_happy(19) ? "happy" : "not happy"); /* happy */
    return 0;
}`,
          cpp: `#include <iostream>

int digitSquareSum(int n) {
    int total = 0;
    while (n > 0) { int d = n % 10; total += d * d; n /= 10; }
    return total;
}

// Floyd's two runners: no set, just two speeds
bool isHappy(int n) {
    int slow = digitSquareSum(n);
    int fast = digitSquareSum(digitSquareSum(n));
    while (slow != fast) {
        slow = digitSquareSum(slow);
        fast = digitSquareSum(digitSquareSum(fast));
    }
    return slow == 1;
}

int main() {
    std::cout << (isHappy(19) ? "happy" : "not happy") << '\\n'; // happy
}`,
        },
        steps(value) {
          const n0 = Math.floor(Number(value));
          const steps = [];
          if (!Number.isFinite(n0) || n0 < 0) {
            steps.push({
              title: "The runners need a whole, non-negative start",
              tracks: [{ label: "start", cells: [{ v: n0, state: "bad", tag: "negative" }] }],
              counters: [count("runners", 0)],
              legend: ["read", "bad", "dim"],
              happened: `The input ${value} is negative, which the digit-square rule does not cover.`,
              why: "Rather than guess, the walk reports that no chain can be built.",
              codeLine: 11,
            });
            steps.push({
              title: "Answer: no answer for a negative starting point",
              tracks: [{ label: "start", cells: [{ v: n0, state: "dim" }] }],
              counters: [count("answer", "n/a")],
              happened: "This game is only played with non-negative whole numbers.",
              why: "An honest refusal is better than an invented answer.",
              codeLine: 11,
            });
            return steps;
          }

          let slow = squareStep(n0).sum;
          let fast = squareStep(squareStep(n0).sum).sum;

          steps.push({
            title: `Slow runner at ${slow}, fast runner at ${fast}`,
            tracks: [
              { label: "slow", cells: [{ v: slow, state: "read", tag: "1 step" }] },
              { label: "fast", cells: [{ v: fast, state: "active", tag: "2 steps" }] },
            ],
            counters: [count("rounds", 0)],
            legend: ["read", "active", "result", "bad", "dim"],
            happened: `Starting from ${n0}: the slow runner made one move to ${slow}, the fast runner made two moves to ${fast}.`,
            why: "Two different speeds on the same chain are guaranteed to meet whenever the chain loops.",
            codeLine: 12,
          });

          let rounds = 0;
          let met = slow === fast;
          while (!met && rounds < 60) {
            rounds++;
            slow = squareStep(slow).sum;
            fast = squareStep(squareStep(fast).sum).sum;
            met = slow === fast;
            steps.push({
              title: met
                ? `Both runners land on ${slow} — they have met`
                : `Slow moves to ${slow}, fast moves twice to ${fast}`,
              tracks: [
                { label: "slow", cells: [{ v: slow, state: met ? "result" : "read", tag: "1 step" }] },
                { label: "fast", cells: [{ v: fast, state: met ? "result" : "active", tag: "2 steps" }] },
              ],
              counters: [count("rounds", rounds), count("same number?", met ? "yes" : "no")],
              happened: met
                  ? `The faster runner caught the slower one, so the chain must be a loop (or both sit on 1).`
                  : `Another round: the fast runner stays ahead by covering twice the distance.`,
              why: met
                ? "Meeting is the signal to stop: the chain can never escape the loop it is in."
                : "While the two numbers differ the chain is still exploring fresh ground.",
              codeLine: met ? 16 : 15,
            });
          }
          if (rounds >= 60) {
            steps.push({
              title: "The runners are still apart — the walk is cut short",
              tracks: [
                { label: "slow", cells: [{ v: slow, state: "read" }] },
                { label: "fast", cells: [{ v: fast, state: "active" }] },
              ],
              counters: [count("rounds", rounds)],
              happened: "After 60 rounds the two numbers still differ, which the animation stops illustrating.",
              why: "Real chains of this kind converge quickly; the cut is only to keep the picture short.",
              codeLine: 15,
            });
          }

          const happy = slow === 1;
          steps.push({
            title: happy ? "Answer: happy — the meeting point is 1" : `Answer: not happy — the meeting point is ${slow}`,
            tracks: [
              { label: "meeting point", cells: [{ v: slow, state: happy ? "result" : "bad", tag: happy ? "reached 1" : "inside a loop" }] },
            ],
            counters: [count("rounds", rounds), count("answer", happy ? "happy" : "not happy")],
            happened: happy
              ? `The runners met at 1, and 1 squares back to itself — a happy number.`
              : `The runners met at ${slow}, which is inside a loop, so 1 is never reached.`,
            why: "Two runners and no memory: the meeting point alone decides the answer.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     4. longest-consecutive-sequence
     ========================================================== */
  register({
    id: "longest-consecutive-sequence",
    title: "Longest Consecutive Sequence",
    category: "Hashing & Two Pointers",
    difficulty: "Intermediate",
    description: "Find the longest run of values like 1, 2, 3, 4 that live anywhere in the row.",
    input: { label: "The numbers", default: "100, 4, 200, 1, 3, 2", parse: "ints" },
    approaches: [
      {
        name: "Sort, Then Measure Each Run",
        complexity: "O(n log n) time, O(1) extra space (in place)",
        idea: [
          "Sort the row. Once it is ordered, consecutive values sit next to each other, so a single left-to-right walk can measure every run.",
          "Equal neighbours are ignored, a neighbour exactly one larger extends the current run, and any other step starts a fresh run of length 1.",
        ],
        problem: [
          "Sorting costs O(n log n) and rearranges the input. It also solves a harder problem than asked: it runs the values in order rather than just counting them.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

static int cmp(const void *x, const void *y) {
    int a = *(const int *)x, b = *(const int *)y;
    return (a > b) - (a < b);
}

/* sort, then measure every rising-by-one run */
int longest_consecutive(int *a, int n) {
    if (n == 0) return 0;
    qsort(a, n, sizeof(int), cmp);
    int best = 1, run = 1;
    for (int i = 1; i < n; i++) {
        if (a[i] == a[i - 1]) continue;        /* duplicate: no change */
        if (a[i] == a[i - 1] + 1) run++;       /* extends the run */
        else run = 1;                          /* a gap starts over */
        if (run > best) best = run;
    }
    return best;
}

int main(void) {
    int a[] = {100, 4, 200, 1, 3, 2};
    printf("%d\\n", longest_consecutive(a, 6)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int longestConsecutive(std::vector<int> a) {
    if (a.empty()) return 0;
    std::sort(a.begin(), a.end());
    int best = 1, run = 1;
    for (size_t i = 1; i < a.size(); ++i) {
        if (a[i] == a[i - 1]) continue;            // duplicate
        run = (a[i] == a[i - 1] + 1) ? run + 1 : 1;
        best = std::max(best, run);
    }
    return best;
}

int main() {
    std::cout << longestConsecutive({100, 4, 200, 1, 3, 2}) << '\\n'; // 4
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const sorted = nums.slice().sort((x, y) => x - y);
          const runs = [];
          let best = 0, bestRun = [];

          steps.push({
            title: `${n} numbers arrive in no particular order`,
            tracks: [
              track("the numbers", nums, blank(n, "idle")),
              { label: "longest run", cells: [{ v: "—", state: "idle", empty: true }] },
            ],
            counters: [count("rows measured", 0), count("longest run", 0)],
            legend: ["compare", "read", "result", "done", "bad"],
            happened: `Values such as 4, 1 and 3 look unrelated while they sit in their original order.`,
            why: "Consecutive values are far apart here, which is why the row is sorted first.",
            codeLine: 9,
          });

          steps.push({
            title: `Sorted: ${fmt(sorted)}`,
            tracks: [
              track("the numbers", nums, blank(n, "dim")),
              track("sorted copy", sorted, blank(n, "done")),
            ],
            counters: [count("rows measured", 0), count("longest run", 0)],
            happened: `After sorting, values that sit one apart are neighbours in the row.`,
            why: "On an ordered row, a run of consecutive values is simply a stretch that climbs by exactly one each step.",
            codeLine: 10,
          });

          let run = 1;
          let runStart = 0;
          for (let i = 1; i < n; i++) {
            const same = sorted[i] === sorted[i - 1];
            const next = sorted[i] === sorted[i - 1] + 1;
            if (same) {
              steps.push({
                title: `${sorted[i]} repeats — ignored, the run stays ${run}`,
                tracks: [
                  track("sorted copy", sorted, paint(blank(n, "done"), { [i - 1]: "compare", [i]: "bad" })),
                  { label: "current run", cells: [{ v: `${run} long`, state: "active", tag: `${sorted[runStart]} … ${sorted[i - 1]}` }] },
                ],
                counters: [count("pairs checked", i, Math.max(1, n - 1)), count("current run", run), count("longest run", best)],
                happened: `${sorted[i]} is the same as its left neighbour, so the run neither grows nor breaks.`,
                why: "Duplicates do not break a run; they simply are not new members of it.",
                codeLine: 13,
              });
            } else if (next) {
              run++;
              steps.push({
                title: `${sorted[i]} continues the run → now ${run} long`,
                tracks: [
                  track("sorted copy", sorted, paint(blank(n, "done"), { [i - 1]: "done", [i]: "read" })),
                  { label: "current run", cells: [{ v: `${run} long`, state: "active", tag: `${sorted[runStart]} … ${sorted[i]}` }] },
                ],
                counters: [count("pairs checked", i, Math.max(1, n - 1)), count("current run", run), count("longest run", Math.max(best, run))],
                happened: `${sorted[i - 1]} + 1 = ${sorted[i]}, so the neighbours belong to the same stretch.`,
                why: "A step of exactly one upward is the definition of 'still consecutive'.",
                codeLine: 14,
              });
            } else {
              runs.push([runStart, i - 1]);
              if (run > best) { best = run; bestRun = [runStart, i - 1]; }
              runStart = i;
              run = 1;
              steps.push({
                title: `${sorted[i - 1]} → ${sorted[i]} jumps by more than 1 — a new run starts`,
                tracks: [
                  track("sorted copy", sorted, paint(blank(n, "done"), { [i - 1]: "bad", [i]: "read" })),
                  { label: "current run", cells: [{ v: `${run} long`, state: "active", tag: `starts at ${sorted[i]}` }] },
                ],
                counters: [count("pairs checked", i, Math.max(1, n - 1)), count("current run", run), count("longest run", best)],
                happened: `There is a gap between ${sorted[i - 1]} and ${sorted[i]}, so the earlier run ends at length ${runs[runs.length - 1][1] - runs[runs.length - 1][0] + 1}.`,
                why: "A gap is the only thing that can end a run of consecutive values.",
                codeLine: 15,
              });
            }
          }
          runs.push([runStart, n - 1]);
          if (run > best) { best = run; bestRun = [runStart, n - 1]; }

          steps.push({
            title: `Answer: the longest run is ${best}`,
            tracks: [
              track("sorted copy", sorted, sorted.map((v, i) => (i >= bestRun[0] && i <= bestRun[1] ? "result" : "dim"))),
              { label: "longest run", cells: [{ v: `${best} long`, state: "result", tag: sorted.length ? `${sorted[bestRun[0]]} … ${sorted[bestRun[1]]}` : "no values" }] },
            ],
            counters: [count("pairs checked", Math.max(1, n - 1), Math.max(1, n - 1)), count("answer", best)],
            happened: sorted.length
              ? `The values ${sorted.slice(bestRun[0], bestRun[1] + 1).join(", ")} form the longest consecutive stretch.`
              : "There were no numbers to measure.",
            why: "Sorting made consecutive values neighbours, so one linear sweep measured every run exactly once.",
            codeLine: 17,
          });
          return steps;
        },
      },
      {
        name: "Set of Values, Count Only From Run Starts",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Drop every value into a set. A value is the beginning of a run exactly when the set does not contain value − 1.",
          "From each start, keep adding one and counting while the set still holds the next value; the longest count wins.",
        ],
        problem: [
          "The set costs memory equal to the number of distinct values. In return the work becomes linear, because each value is only ever stepped onto from a run start.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* values 0..999; a real solution would use a hash set */
int longest_consecutive(const int *a, int n) {
    bool has[1000] = {false};
    for (int i = 0; i < n; i++) has[a[i]] = true;
    int best = 0;
    for (int i = 0; i < n; i++) {
        if (has[a[i] - 1]) continue;        /* not the start of a run */
        int v = a[i], len = 1;
        while (v + 1 < 1000 && has[v + 1]) { v++; len++; }
        if (len > best) best = len;
    }
    return best;
}

int main(void) {
    int a[] = {100, 4, 200, 1, 3, 2};
    printf("%d\\n", longest_consecutive(a, 6)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_set>

// only grow from values whose predecessor is missing
int longestConsecutive(const std::vector<int>& a) {
    std::unordered_set<int> has(a.begin(), a.end());
    int best = 0;
    for (int x : a) {
        if (has.count(x - 1)) continue;      // x is inside a run, not its start
        int len = 1;
        while (has.count(x + len)) len++;
        best = std::max(best, len);
    }
    return best;
}

int main() {
    std::cout << longestConsecutive({100, 4, 200, 1, 3, 2}) << '\\n'; // 4
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const values = [...new Set(nums)];
          const set = new Set(values);
          let best = 0, bestStart = null;

          steps.push({
            title: "Rule: a run starts where the value before it is missing",
            tracks: [
              track("the numbers", nums, blank(n, "idle")),
              { label: "values in the set", cells: values.length ? values.map((v) => ({ v, state: "idle" })) : [{ v: "∅", state: "idle", empty: true }] },
              { label: "longest run", cells: [{ v: "—", state: "idle", empty: true }] },
            ],
            counters: [count("numbers read", 0, n), count("longest run", 0)],
            legend: ["read", "result", "active", "done", "dim"],
            happened: `${n} numbers, of which ${values.length} are distinct.`,
            why: "If value − 1 is present then value is in the middle of a run and starting there would only recount it.",
            codeLine: 5,
          });

          steps.push({
            title: `Set holds ${fmt(values)}`,
            tracks: [
              track("the numbers", nums, blank(n, "done")),
              { label: "values in the set", cells: values.map((v) => ({ v, state: "done" })) },
              { label: "longest run", cells: [{ v: "—", state: "idle", empty: true }] },
            ],
            counters: [count("numbers read", n, n), count("distinct values", values.length)],
            happened: "Duplicates disappeared into the set, so each value is examined once.",
            why: "Membership checks are what let the walk jump straight to the next value of a run.",
            codeLine: 4,
          });

          for (let i = 0; i < values.length; i++) {
            const v = values[i];
            const isStart = !set.has(v - 1);
            if (!isStart) {
              steps.push({
                title: `${v} has ${v - 1} beside it — not a run start`,
                tracks: [
                  track("the numbers", nums, nums.map((x) => (x === v ? "dim" : "done"))),
                  { label: "values in the set", cells: values.map((x) => ({ v: x, state: x === v ? "dim" : x === v - 1 ? "active" : "done" })) },
                  { label: "longest run", cells: [{ v: best ? best + " long" : "—", state: best ? "result" : "idle", tag: bestStart != null ? `starts at ${bestStart}` : undefined }] },
                ],
                counters: [count("values examined", i + 1, values.length), count("longest run", best)],
                happened: `The set contains ${v - 1}, so ${v} is somewhere in the middle of a run.`,
                why: "Skipping interior values is exactly what keeps the whole approach linear.",
                codeLine: 8,
              });
              continue;
            }
            let len = 1;
            let cur = v;
            steps.push({
              title: `${v} is a run start — count upwards`,
              tracks: [
                track("the numbers", nums, nums.map((x) => (x === v ? "read" : "done"))),
                { label: "values in the set", cells: values.map((x) => ({ v: x, state: x === v ? "read" : "done" })) },
                { label: "current run", cells: [{ v: `1 long`, state: "active", tag: `starts at ${v}` }] },
              ],
              counters: [count("values examined", i + 1, values.length), count("current run", 1), count("longest run", best)],
              happened: `${v - 1} is absent, so nothing can come before ${v} in a run.`,
              why: "Counting from a known start visits each value of the run exactly once.",
              codeLine: 9,
            });
            while (set.has(cur + 1)) {
              cur++;
              len++;
              steps.push({
                title: `${cur} is in the set → run grows to ${len}`,
                tracks: [
                  track("the numbers", nums, nums.map((x) => (x === cur ? "read" : x === v ? "active" : "done"))),
                  { label: "values in the set", cells: values.map((x) => ({ v: x, state: x === cur ? "read" : x >= v && x <= cur ? "active" : "done" })) },
                  { label: "current run", cells: [{ v: `${len} long`, state: "active", tag: `${v} … ${cur}` }] },
                ],
                counters: [count("values examined", i + 1, values.length), count("current run", len), count("longest run", Math.max(best, len))],
                happened: `${cur} continues the run that began at ${v}.`,
                why: "Every upward step is a single set lookup, which is why the cost does not grow with the run length.",
                codeLine: 11,
              });
            }
            if (len > best) { best = len; bestStart = v; }
            steps.push({
              title: `Run from ${v} ends at ${cur} — length ${len}`,
              tracks: [
                track("the numbers", nums, nums.map((x) => (x >= v && x <= cur ? "active" : "done"))),
                { label: "values in the set", cells: values.map((x) => ({ v: x, state: x >= v && x <= cur ? "active" : "done" })) },
                { label: "longest run", cells: [{ v: `${best} long`, state: "result", tag: `starts at ${bestStart}` }] },
              ],
              counters: [count("values examined", i + 1, values.length), count("current run", len), count("longest run", best)],
              happened: `${cur + 1} is not in the set, so the run stops after ${len} value${len === 1 ? "" : "s"}.`,
              why: "A missing next value is the only thing that ends a run.",
              codeLine: 11,
            });
          }

          steps.push({
            title: best ? `Answer: the longest run is ${best}` : "Answer: no numbers, so no run",
            tracks: [
              track("the numbers", nums, nums.map((x) => (bestStart != null && x >= bestStart && x <= bestStart + best - 1 ? "result" : "dim"))),
              { label: "values in the set", cells: values.map((x) => ({ v: x, state: bestStart != null && x >= bestStart && x <= bestStart + best - 1 ? "result" : "dim" })) },
              { label: "longest run", cells: [{ v: `${best} long`, state: "result", tag: bestStart != null ? `${bestStart} … ${bestStart + best - 1}` : undefined }] },
            ],
            counters: [count("values examined", values.length, values.length), count("answer", best)],
            happened: bestStart != null
              ? `The values ${bestStart} through ${bestStart + best - 1} form the longest consecutive stretch.`
              : "The row was empty.",
            why: "Looking only at run starts means each value of the row was touched a constant number of times.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     5. subarray-sum-equals-k
     ========================================================== */
  register({
    id: "subarray-sum-equals-k",
    title: "Subarray Sum Equals K",
    category: "Hashing & Two Pointers",
    difficulty: "Intermediate",
    description: "Count the stretches of the row whose values add up to a target k.",
    input: { label: "Numbers… k=<target>", default: "1, 1, 2, 3 k=3", parse: "tokens" },
    approaches: [
      {
        name: "Try Every Start and End",
        complexity: "O(n²) time, O(1) space",
        idea: [
          "For each starting position, extend the end one step at a time and keep a running sum of the stretch.",
          "Whenever that running sum equals k, one more sub-array has been found, and the count ticks up.",
        ],
        problem: [
          "n starting points each run over up to n ends, so the work grows with n². Nothing is remembered between different starts, which is why it stays slow.",
        ],
        code: {
          c: `#include <stdio.h>

/* count the stretches whose values add up to k */
int subarray_sum(const int *a, int n, int k) {
    int count = 0;
    for (int i = 0; i < n; i++) {
        int sum = 0;
        for (int j = i; j < n; j++) {
            sum += a[j];
            if (sum == k) count++;
        }
    }
    return count;
}

int main(void) {
    int a[] = {1, 1, 2, 3};
    printf("%d\\n", subarray_sum(a, 4, 3)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

int subarraySum(const std::vector<int>& a, int k) {
    int count = 0;
    for (size_t i = 0; i < a.size(); ++i) {
        int sum = 0;
        for (size_t j = i; j < a.size(); ++j) {
            sum += a[j];          // stretch i..j
            if (sum == k) ++count;
        }
    }
    return count;
}

int main() {
    std::cout << subarraySum({1, 1, 2, 3}, 3) << '\\n'; // 2
}`,
        },
        steps(tokens) {
          const { target, values, bad } = splitPrefixed(tokens, "k");
          const nums = values;
          const n = nums.length;
          const k = target == null ? nums.reduce((a, b) => a + b, 0) : target;
          const steps = [];

          // full answer, computed cheaply, so the closing step is always right
          let realCount = 0;
          for (let i = 0; i < n; i++) {
            let s = 0;
            for (let j = i; j < n; j++) { s += nums[j]; if (s === k) realCount++; }
          }

          if (target == null) {
            steps.push({
              title: `No k=<target> in the input — using k = ${k}, the total of the numbers`,
              tracks: [track("the numbers", nums, blank(n, "idle"))],
              counters: [count("target k", k)],
              legend: ["read", "result", "active", "done", "dim"],
              happened: "The input carried no k= token, so the sum of the whole row was taken as the target.",
              why: "The walk still needs a number to look for; the row total always gives a meaningful run.",
              codeLine: 3,
            });
          }

          steps.push({
            title: n
              ? `Count stretches of ${fmt(nums)} that sum to ${k}`
              : "No numbers arrived — the count must be zero",
            tracks: [track("the numbers", nums, blank(n, "idle"))],
            counters: [
              count("target k", k),
              count("sub-arrays found", 0),
              count("stretches possible", (n * (n + 1)) / 2),
            ],
            legend: ["read", "result", "active", "done", "dim"],
            happened: bad
              ? `${n} numbers are usable; ${bad} token${bad === 1 ? "" : "s"} could not be read as numbers and ${bad === 1 ? "was" : "were"} ignored.`
              : `${n} numbers and a target of ${k}.`,
            why: "Each start position will be paired with every possible end position to be exhaustive.",
            codeLine: 3,
          });

          let shown = 0, truncated = false;
          for (let i = 0; i < n; i++) {
            let sum = 0;
            let stop = false;
            for (let j = i; j < n; j++) {
              if (shown >= BRUTE_CAP) { truncated = true; stop = true; break; }
              shown++;
              sum += nums[j];
              const hit = sum === k;
              const st = blank(n, "idle");
              for (let p = i; p <= j; p++) st[p] = hit ? "result" : "active";
              if (hit) st[j] = "result";
              steps.push({
                title: hit
                  ? `Stretch ${i}…${j} sums to ${sum} = k → found one`
                  : `Stretch ${i}…${j} sums to ${sum}`,
                tracks: [track("the numbers", nums, st)],
                counters: [count("stretches tried", shown), count("running sum", sum), count("target k", k)],
                happened: hit
                  ? `Adding ${nums[j]} brought the stretch starting at ${i} up to exactly ${k}.`
                  : `The stretch starting at ${i} has grown to ${sum} after taking in ${nums[j]}.`,
                why: hit
                  ? "A running sum that lands on k is a completed sub-array; the count rises without any extra work."
                  : "Extending the end by one position is all it takes to test the next stretch.",
                codeLine: hit ? 8 : 7,
              });
            }
            if (stop) break;
          }
          if (truncated) {
            steps.push({
              title: `Animation stops after ${shown} stretches — the rest follow the same pattern`,
              tracks: [track("the numbers", nums, blank(n, "done"))],
              counters: [count("stretches tried", shown)],
              happened: "Every start position behaves the same way: the sum creeps up and is compared with k.",
              why: "The picture needs only enough stretches to make the idea clear.",
              codeLine: 5,
            });
          }

          steps.push({
            title: n ? `Answer: ${realCount} sub-array${realCount === 1 ? "" : "s"} sum to ${k}` : "Answer: 0 (no numbers)",
            tracks: [track("the numbers", nums, blank(n, "dim"))],
            counters: [count("target k", k), count("answer", realCount)],
            happened: realCount
              ? `${realCount} stretch${realCount === 1 ? "" : "es"} of the row add up to ${k}.`
              : `No stretch of the row adds up to ${k}.`,
            why: "Every start–end pair was tried, so the count is complete.",
            codeLine: 8,
          });
          return steps;
        },
      },
      {
        name: "Prefix Sums With a Map",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Keep a running total of everything read so far. A stretch from just after position i to here sums to k exactly when an earlier running total equal to (current − k) was seen.",
          "A map remembers how many times each earlier running total occurred, so the number of matching stretches can be added in one lookup.",
        ],
        problem: [
          "The map can hold up to n different prefix totals, so it costs extra memory. It also takes a moment to believe: the answer comes from counting older prefixes, not from the current numbers.",
        ],
        code: {
          c: `#include <stdio.h>

/* running total plus a small list of earlier totals and their counts */
int subarray_sum(const int *a, int n, int k) {
    int key[64], val[64], m = 0;      /* key -> how often it was seen */
    key[m] = 0; val[m++] = 1;         /* the empty prefix, seen once */
    int count = 0, sum = 0;
    for (int i = 0; i < n; i++) {
        sum += a[i];
        for (int t = 0; t < m; t++)
            if (key[t] == sum - k) count += val[t];
        int t = 0;
        while (t < m && key[t] != sum) t++;
        if (t < m) val[t]++;
        else { key[m] = sum; val[m++] = 1; }
    }
    return count;
}

int main(void) {
    int a[] = {1, 1, 2, 3};
    printf("%d\\n", subarray_sum(a, 4, 3)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_map>

// count subarrays summing to k using prefix sums
int subarraySum(const std::vector<int>& a, int k) {
    std::unordered_map<int, int> seen;
    seen[0] = 1;                  // the empty prefix
    int count = 0, sum = 0;
    for (int x : a) {
        sum += x;
        count += seen[sum - k];   // earlier prefixes that close the gap
        ++seen[sum];
    }
    return count;
}

int main() {
    std::cout << subarraySum({1, 1, 2, 3}, 3) << '\\n'; // 2
}`,
        },
        steps(tokens) {
          const { target, values, bad } = splitPrefixed(tokens, "k");
          const nums = values;
          const n = nums.length;
          const k = target == null ? nums.reduce((a, b) => a + b, 0) : target;
          const steps = [];
          const map = new Map([[0, 1]]);
          let sum = 0, cnt = 0;

          const mapTrack = (hotKey) => ({
            label: "prefix totals seen",
            cells: [...map].map(([key, c]) => ({ v: `${key} × ${c}`, state: key === hotKey ? "result" : "done" })),
          });

          if (target == null) {
            steps.push({
              title: `No k=<target> in the input — using k = ${k}, the total of the numbers`,
              tracks: [track("the numbers", nums, blank(n, "idle"))],
              counters: [count("target k", k)],
              legend: ["read", "result", "active", "done", "dim"],
              happened: "Without a k= token the row's total was adopted as the target.",
              why: "The prefix-sum method needs a target value; the row total is a sensible stand-in.",
              codeLine: 6,
            });
          }

          steps.push({
            title: `Map starts with the empty prefix: total 0 seen once`,
            tracks: [
              track("the numbers", nums, blank(n, "idle")),
              mapTrack(0),
              { label: "running total", cells: [{ v: 0, state: "active", tag: "nothing read yet" }] },
            ],
            counters: [count("numbers read", 0, n), count("running total", 0), count("target k", k), count("sub-arrays found", 0)],
            legend: ["read", "result", "active", "done", "dim"],
            happened: "The empty prefix (total 0) is recorded once before any number is read.",
            why: "Seeding the map with 0 lets a stretch that starts at the very first position be counted.",
            codeLine: 4,
          });

          for (let i = 0; i < n; i++) {
            sum += nums[i];
            const need = sum - k;
            const hits = map.get(need) || 0;
            cnt += hits;
            const known = map.has(sum);
            map.set(sum, (map.get(sum) || 0) + 1);
            steps.push({
              title: hits
                ? `Running total ${sum}; need ${need}, seen ${hits}× → count becomes ${cnt}`
                : `Running total ${sum}; need ${need}, not seen → count stays ${cnt}`,
              tracks: [
                track("the numbers", nums, paint(blank(n, "done"), { [i]: "read" })),
                mapTrack(sum),
                { label: "running total", cells: [{ v: sum, state: "active", tag: `after ${i + 1} number${i === 0 ? "" : "s"}` }] },
              ],
              counters: [
                count("numbers read", i + 1, n),
                count("running total", sum),
                count("target k", k),
                count("sub-arrays found", cnt),
              ],
              happened: hits
                ? `${hits} earlier prefix total${hits === 1 ? "" : "s"} of ${need} make${hits === 1 ? "s" : ""} the stretch end here and add up to ${k}.`
                : `No earlier prefix total of ${need} exists, so no stretch ending here sums to ${k}.`,
              why: hits
                ? "A prefix ending at (running total − k) marks where the stretch must begin."
                : "Each prefix total is remembered once, and later positions reuse it for free.",
              codeLine: 9,
            });
          }

          steps.push({
            title: n ? `Answer: ${cnt} sub-array${cnt === 1 ? "" : "s"} sum to ${k}` : "Answer: 0 (no numbers)",
            tracks: [
              track("the numbers", nums, blank(n, "dim")),
              mapTrack(null),
            ],
            counters: [count("numbers read", n, n), count("answer", cnt)],
            happened: cnt
              ? `The map of earlier totals produced ${cnt} matching stretch${cnt === 1 ? "" : "es"}.`
              : `No prefix pair was ${k} apart, so no stretch sums to ${k}.`,
            why: "One pass built the map and answered every end position in a single lookup each.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     6. two-sum-ii
     ========================================================== */
  register({
    id: "two-sum-ii",
    title: "Two Sum II",
    category: "Hashing & Two Pointers",
    difficulty: "Beginner",
    description: "In a sorted row, find the two values that add up to a target.",
    input: { label: "Sorted numbers… target=<n>", default: "2 7 11 15 target=9", parse: "tokens" },
    approaches: [
      {
        name: "Two Pointers From the Ends",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Because the row is sorted, one pointer can start at the smallest value and one at the largest.",
          "If their values add up to more than the target the bigger value is too big, so the right pointer steps left; if the sum is too small the left pointer steps right.",
        ],
        problem: [
          "It relies completely on the row already being sorted. On an unsorted row the pointers can walk straight past the only correct pair.",
        ],
        code: {
          c: `#include <stdio.h>

/* sorted a[]: move lo up or hi down until the sum matches.
   Fills 1-based positions and returns 1, or returns 0 for no pair. */
int two_sum(const int *a, int n, int target, int *p1, int *p2) {
    int lo = 0, hi = n - 1;
    while (lo < hi) {
        int sum = a[lo] + a[hi];
        if (sum == target) { *p1 = lo + 1; *p2 = hi + 1; return 1; }
        if (sum < target) lo++;      /* need something bigger on the left */
        else hi--;                   /* need something smaller on the right */
    }
    return 0;
}

int main(void) {
    int a[] = {2, 7, 11, 15}, p1, p2;
    if (two_sum(a, 4, 9, &p1, &p2)) printf("%d %d\\n", p1, p2); /* 1 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

std::pair<int, int> twoSum(const std::vector<int>& a, int target) {
    int lo = 0, hi = (int)a.size() - 1;
    while (lo < hi) {
        int sum = a[lo] + a[hi];
        if (sum == target) return {lo, hi};
        if (sum < target) ++lo;   // too small: raise the left value
        else --hi;                // too big: lower the right value
    }
    return {-1, -1};              // no pair
}

int main() {
    auto [i, j] = twoSum({2, 7, 11, 15}, 9);
    std::cout << i << ' ' << j << '\\n'; // 0 1
}`,
        },
        steps(tokens) {
          const { target, values, bad } = splitPrefixed(tokens, "target");
          const nums = values;
          const n = nums.length;
          const adjusted = target == null;
          const goal = adjusted ? (n >= 2 ? nums[0] + nums[n - 1] : 0) : target;
          const steps = [];
          const isSorted = sortedAsc(nums);

          steps.push({
            title: adjusted
              ? `No target=<n> given — using ${goal}, the sum of the two ends`
              : `Looking for two values adding to ${goal}`,
            tracks: [track("the numbers", nums, nums.map((_, i) => (i === 0 || i === n - 1 ? "read" : "idle")))],
            pointers: n > 1
              ? [{ index: 0, label: "L" }, { index: n - 1, label: "R" }]
              : n ? [{ index: 0, label: "L" }] : [],
            counters: [count("numbers", n), count("target", goal), count("row sorted?", isSorted ? "yes" : "no")],
            legend: ["compare", "read", "result", "bad", "done", "dim"],
            happened: adjusted
              ? `The input had no target= token, so ${n >= 2 ? `${nums[0]} + ${nums[n - 1]}` : "0"} was used as the target.`
              : `${n} sorted values and a target of ${goal}; two different positions must supply it.`,
            why: "Small at one end and large at the other is exactly what makes the sorted order useful.",
            codeLine: 4,
          });

          if (!isSorted) {
            steps.push({
              title: "Careful: this row is not sorted",
              tracks: [track("the numbers", nums, blank(n, "bad"))],
              counters: [count("numbers", n), count("target", goal)],
              happened: "The two-pointer walk assumes values climb from left to right, and this row does not.",
              why: "The walk still runs, but on unsorted data its answer cannot be trusted.",
              codeLine: 4,
            });
          }

          let lo = 0, hi = n - 1;
          let found = null;
          let guard = 0;
          while (lo < hi && guard++ < 200) {
            const sum = nums[lo] + nums[hi];
            const hit = sum === goal;
            const st = blank(n, "dim");
            st[lo] = "compare";
            st[hi] = hit ? "result" : "compare";
            steps.push({
              title: hit
                ? `${nums[lo]} + ${nums[hi]} = ${sum} = target → found`
                : `${nums[lo]} + ${nums[hi]} = ${sum} — ${sum < goal ? "too small, move left pointer up" : "too big, move right pointer down"}`,
              tracks: [track("the numbers", nums, st)],
              pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }],
              counters: [count("left pointer", lo), count("right pointer", hi), count("pairs tested", guard), count("target", goal)],
              happened: hit
                ? `The values at positions ${lo} and ${hi} add up to exactly ${goal}.`
                : `The pair is ${sum === goal ? "" : sum < goal ? "short of" : "past"} the target, so exactly one pointer must move.`,
              why: hit
                ? "One matching pair completes the search."
                : sum < goal
                  ? "To grow the sum, the smaller value on the left has to be replaced by something larger."
                  : "To shrink the sum, the larger value on the right has to be replaced by something smaller.",
              codeLine: hit ? 7 : sum < goal ? 8 : 9,
            });
            if (hit) { found = [lo, hi]; break; }
            if (sum < goal) lo++; else hi--;
          }
          if (!found && guard >= 200) {
            steps.push({
              title: "The walk hit its safety limit",
              tracks: [track("the numbers", nums, blank(n, "dim"))],
              counters: [count("pairs tested", guard)],
              happened: "Two pointers always meet after at most n moves, so this only triggers on unusual input.",
              why: "A guard keeps the animation responsive without changing the answer.",
              codeLine: 6,
            });
          }

          steps.push({
            title: found
              ? `Answer: positions ${found[0] + 1} and ${found[1] + 1} (values ${nums[found[0]]} and ${nums[found[1]]})`
              : `Answer: no pair adds up to ${goal}`,
            tracks: [
              found
                ? track("the numbers", nums, nums.map((v, i) => (i === found[0] || i === found[1] ? "result" : "dim")))
                : track("the numbers", nums, nums.map(() => (isSorted ? "done" : "bad"))),
            ],
            counters: [
              count("pairs tested", guard),
              count("answer", found ? `${nums[found[0]]} + ${nums[found[1]]} = ${goal}` : "none"),
            ],
            happened: found
              ? `${nums[found[0]]} at position ${found[0] + 1} and ${nums[found[1]]} at position ${found[1] + 1} are the pair.`
              : "The pointers met without ever hitting the target, so no such pair exists.",
            why: found
              ? "Each move discarded one impossible value, so nothing correct was skipped."
              : "When the pointers meet, every pair consistent with the sorted order has been considered.",
            codeLine: found ? 7 : 10,
          });
          return steps;
        },
      },
      {
        name: "Remember Values in a Map",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Walk the row once. Before storing the current value, ask the map whether the value needed to complete the pair has already been seen.",
          "The first yes gives the answer, and the map has cost only one entry per value.",
        ],
        problem: [
          "It ignores the sorted order and spends memory on the map. Two Sum II is really a practice problem for the cheaper two-pointer trick.",
        ],
        code: {
          c: `#include <stdio.h>

/* values 0..999 here; a real solution would keep a hash map */
int two_sum(const int *a, int n, int target, int *p1, int *p2) {
    int pos[1000];
    for (int v = 0; v < 1000; v++) pos[v] = -1;
    for (int i = 0; i < n; i++) {
        int need = target - a[i];
        if (need >= 0 && need < 1000 && pos[need] != -1) {
            *p1 = pos[need]; *p2 = i;   /* 0-based positions */
            return 1;
        }
        if (a[i] >= 0 && a[i] < 1000) pos[a[i]] = i;
    }
    return 0;
}

int main(void) {
    int a[] = {2, 7, 11, 15}, p1, p2;
    if (two_sum(a, 4, 9, &p1, &p2)) printf("%d %d\\n", p1, p2); /* 0 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_map>

std::pair<int, int> twoSum(const std::vector<int>& a, int target) {
    std::unordered_map<int, int> where;   // value -> position
    for (int i = 0; i < (int)a.size(); ++i) {
        auto it = where.find(target - a[i]);
        if (it != where.end()) return {it->second, i};
        where[a[i]] = i;
    }
    return {-1, -1};
}

int main() {
    auto [i, j] = twoSum({2, 7, 11, 15}, 9);
    std::cout << i << ' ' << j << '\\n'; // 0 1
}`,
        },
        steps(tokens) {
          const { target, values, bad } = splitPrefixed(tokens, "target");
          const nums = values;
          const n = nums.length;
          const adjusted = target == null;
          const goal = adjusted ? (n >= 2 ? nums[0] + nums[n - 1] : 0) : target;
          const steps = [];
          const where = new Map();

          const mapTrack = (hot) => ({
            label: "value → position",
            cells: where.size
              ? [...where].map(([v, i]) => ({ v: `${v}@${i}`, state: v === hot ? "result" : "done" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          steps.push({
            title: adjusted
              ? `No target=<n> given — using ${goal}, the sum of the two ends`
              : `Walk once, remembering where each value sat`,
            tracks: [
              track("the numbers", nums, blank(n, "idle")),
              mapTrack(null),
            ],
            counters: [count("numbers read", 0, n), count("target", goal)],
            legend: ["read", "result", "bad", "done", "dim"],
            happened: adjusted
              ? `Without a target= token the sum of the first and last values, ${goal}, was chosen.`
              : `For each value ${goal} minus it is the partner we need; the map says if that partner has been seen.`,
            why: "Sorting is not needed at all — the map replaces the sorted-order trick with memory.",
            codeLine: 5,
          });

          let found = null;
          for (let i = 0; i < n; i++) {
            const v = nums[i];
            const need = goal - v;
            const hit = where.has(need);
            const stCheck = blank(n, "done");
            stCheck[i] = "read";
            steps.push({
              title: hit
                ? `Ask for ${need} — it is already stored at position ${where.get(need)}`
                : `Ask for ${need} — nothing stored under it yet`,
              tracks: [
                track("the numbers", nums, stCheck),
                mapTrack(hit ? need : null),
              ],
              counters: [count("numbers read", i + 1, n), count("target", goal), count("values stored", where.size)],
              happened: hit
                ? `The partner ${need} was recorded earlier, so the pair with ${v} is complete.`
                : `${need} has never been met, so no stretch ending here can finish the pair.`,
              why: hit
                ? "The map turned 'is the partner here?' into one lookup instead of a scan."
                : "Asking before storing is what stops a value from being paired with itself.",
              codeLine: hit ? 7 : 6,
            });
            if (hit) { found = [where.get(need), i]; break; }
            where.set(v, i);
            const stStore = blank(n, "done");
            stStore[i] = "active";
            steps.push({
              title: `Remember ${v} at position ${i}`,
              tracks: [
                track("the numbers", nums, stStore),
                mapTrack(v),
              ],
              counters: [count("numbers read", i + 1, n), count("target", goal), count("values stored", where.size)],
              happened: `${v} joins the map, ready for any later value that needs exactly ${v} to reach the target.`,
              why: "Only where each value sat is kept; everything about it is dropped afterwards.",
              codeLine: 8,
            });
          }

          steps.push({
            title: found
              ? `Answer: positions ${found[0] + 1} and ${found[1] + 1} (values ${nums[found[0]]} and ${nums[found[1]]})`
              : `Answer: no pair adds up to ${goal}`,
            tracks: [
              found
                ? track("the numbers", nums, nums.map((v, i) => (i === found[0] || i === found[1] ? "result" : "dim")))
                : track("the numbers", nums, blank(n, "done")),
              mapTrack(null),
            ],
            counters: [count("numbers read", found ? found[1] + 1 : n, n), count("answer", found ? `${nums[found[0]]} + ${nums[found[1]]} = ${goal}` : "none")],
            happened: found
              ? `${nums[found[0]]} and ${nums[found[1]]} together make ${goal}.`
              : `No value's partner ever appeared, so no pair sums to ${goal}.`,
            why: found
              ? "The pair was caught as soon as its second member arrived, with only one pass."
              : "Every value was offered as a partner to all later positions and none matched.",
            codeLine: found ? 7 : 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     7. three-sum
     ========================================================== */
  register({
    id: "three-sum",
    title: "Three Sum",
    category: "Hashing & Two Pointers",
    difficulty: "Intermediate",
    description: "List the distinct triples of values that add up to zero.",
    input: { label: "The numbers", default: "-1, 0, 1, 2, -1, -4", parse: "ints" },
    approaches: [
      {
        name: "Check Every Triple",
        complexity: "O(n³) time, O(1) extra space",
        idea: [
          "Pick three different positions and add their values. If the total is zero the triple is part of the answer.",
          "Because different choices can give the same three values, each finished triple is compared with the ones already kept before it is stored.",
        ],
        problem: [
          "n values give about n³/6 triples, which becomes unmanageable quickly. The duplicate filter also rescans everything collected so far.",
        ],
        code: {
          c: `#include <stdio.h>

/* collect distinct triples that sum to zero, each stored in sorted order */
static int seen_before(const int *out, int m, int x, int y, int z) {
    for (int t = 0; t < m; t++)
        if (out[t * 3] == x && out[t * 3 + 1] == y && out[t * 3 + 2] == z)
            return 1;
    return 0;
}

int three_sum(const int *a, int n, int *out) {
    int m = 0;
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
            for (int k = j + 1; k < n; k++) {
                int x = a[i], y = a[j], z = a[k];
                if (x + y + z != 0) continue;
                if (x > y) { int t = x; x = y; y = t; }
                if (y > z) { int t = y; y = z; z = t; }
                if (x > y) { int t = x; x = y; y = t; }
                if (!seen_before(out, m, x, y, z)) {
                    out[m * 3] = x; out[m * 3 + 1] = y; out[m * 3 + 2] = z; m++;
                }
            }
    return m;
}

int main(void) {
    int a[] = {-1, 0, 1, 2, -1, -4}, out[64];
    int m = three_sum(a, 6, out);
    for (int t = 0; t < m; t++)
        printf("%d %d %d\\n", out[t * 3], out[t * 3 + 1], out[t * 3 + 2]);
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <set>
#include <algorithm>

// brute force, then let a set remove repeated triples
std::vector<std::vector<int>> threeSum(const std::vector<int>& a) {
    std::set<std::vector<int>> found;
    int n = (int)a.size();
    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j)
            for (int k = j + 1; k < n; ++k)
                if (a[i] + a[j] + a[k] == 0) {
                    std::vector<int> t{a[i], a[j], a[k]};
                    std::sort(t.begin(), t.end());
                    found.insert(t);          // duplicates collapse here
                }
    return {found.begin(), found.end()};
}

int main() {
    for (auto& t : threeSum({-1, 0, 1, 2, -1, -4}))
        std::cout << t[0] << ' ' << t[1] << ' ' << t[2] << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const norm = (t) => t.slice().sort((a, b) => a - b);
          const keyOf = (t) => t.join(",");
          const tmp = [], tmpKeys = new Set();
          for (let i = 0; i < n; i++)
            for (let j = i + 1; j < n; j++)
              for (let k = j + 1; k < n; k++)
                if (nums[i] + nums[j] + nums[k] === 0) {
                  const t = norm([nums[i], nums[j], nums[k]]);
                  if (!tmpKeys.has(keyOf(t))) { tmpKeys.add(keyOf(t)); tmp.push(t); }
                }
          tmp.sort((a, b) => a[0] - b[0] || a[1] - b[1] || a[2] - b[2]);
          const full = tmp;

          const foundTrack = (hot) => ({
            label: "triples kept",
            cells: found.length
              ? found.map((t) => ({ v: `[${t.join(", ")}]`, state: hot && keyOf(t) === hot ? "result" : "good" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });
          const found = [];
          const foundKeys = new Set();

          steps.push({
            title: n < 3
              ? `Only ${n} number${n === 1 ? "" : "s"} — a triple needs three`
              : `${n} numbers give ${(n * (n - 1) * (n - 2)) / 6} triples to test`,
            tracks: [
              track("the numbers", nums, blank(n, "idle")),
              foundTrack(null),
            ],
            counters: [count("numbers", n), count("triples possible", (n * (n - 1) * (n - 2)) / 6), count("triples kept", 0)],
            legend: ["read", "result", "good", "done", "dim"],
            happened: `Three different positions are chosen at a time, and their values are added.`,
            why: "Testing every choice of three positions is the surest way to miss nothing, at the cost of many additions.",
            codeLine: 11,
          });

          let shown = 0, truncated = false;
          for (let i = 0; i < n; i++) {
            let stop = false;
            for (let j = i + 1; j < n; j++) {
              for (let k = j + 1; k < n; k++) {
                if (shown >= 90) { truncated = true; stop = true; break; }
                shown++;
                const sum = nums[i] + nums[j] + nums[k];
                const hit = sum === 0;
                let fresh = false;
                if (hit) {
                  const t = norm([nums[i], nums[j], nums[k]]);
                  fresh = !foundKeys.has(keyOf(t));
                  if (fresh) { foundKeys.add(keyOf(t)); found.push(t); }
                }
                const st = blank(n, "idle");
                st[i] = "compare"; st[j] = "compare";
                st[k] = hit ? "result" : "read";
                steps.push({
                  title: hit
                    ? `${nums[i]} + ${nums[j]} + ${nums[k]} = 0 → ${fresh ? "new triple kept" : "triple already kept"}`
                    : `${nums[i]} + ${nums[j]} + ${nums[k]} = ${sum} — not zero`,
                  tracks: [track("the numbers", nums, st), foundTrack(hit && fresh ? keyOf(norm([nums[i], nums[j], nums[k]])) : null)],
                  counters: [count("triples tested", shown), count("running sum", sum), count("triples kept", found.length)],
                  happened: hit
                    ? `Positions ${i}, ${j} and ${k} cancel out exactly.`
                    : `The three values add to ${sum}, so this choice of positions is not a solution.`,
                  why: hit
                    ? "A zero total is the whole condition; keeping the triple in sorted form makes repeats easy to spot."
                    : "Each tested triple removes one possibility, which is the price of checking everything.",
                  codeLine: hit ? 15 : 16,
                });
                if (stop) break;
              }
              if (stop) break;
            }
            if (stop) break;
          }
          if (truncated) {
            steps.push({
              title: `Animation stops after ${shown} triples — the rest are more of the same`,
              tracks: [track("the numbers", nums, blank(n, "done")), foundTrack(null)],
              counters: [count("triples tested", shown)],
              happened: "The remaining triples are ordinary additions that do not reach zero.",
              why: "A short excerpt shows the shape of the work without an endless timeline.",
              codeLine: 11,
            });
          }

          steps.push({
            title: full.length
              ? `Answer: ${full.length} distinct triple${full.length === 1 ? "" : "s"} — ${full.map((t) => `[${t.join(", ")}]`).join(" ")}`
              : "Answer: no triple sums to zero",
            tracks: [
              track("the numbers", nums, blank(n, "dim")),
              { label: "answer", cells: full.length ? full.map((t) => ({ v: `[${t.join(", ")}]`, state: "result" })) : [{ v: "∅", state: "idle", empty: true }] },
            ],
            counters: [count("triples tested", shown), count("answer", full.length)],
            happened: full.length
              ? `The distinct triples ${full.map((t) => `(${t.join(", ")})`).join(", ")} all add up to zero.`
              : "No choice of three positions added up to zero.",
            why: "Because every triple was tested, the list is complete, and the duplicate filter removed the repeats.",
            codeLine: 19,
          });
          return steps;
        },
      },
      {
        name: "Sort, Fix One, Sweep Two",
        complexity: "O(n²) time, O(1) extra space (plus the sort)",
        idea: [
          "Sort the row first. Then pin one value as the smallest member of the triple, and use two pointers on the part to its right.",
          "If the three values are too small, the left pointer moves up; too large, the right pointer moves down. Pins that repeat an earlier value are skipped outright.",
        ],
        problem: [
          "It still costs about n² pointer steps, and it depends on the row being sorted, so the input order is destroyed unless you copy it first.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

static int cmp(const void *x, const void *y) {
    int a = *(const int *)x, b = *(const int *)y;
    return (a > b) - (a < b);
}

/* sort, pin one value, close the gap with two pointers */
int three_sum(int *a, int n, int *out) {
    qsort(a, n, sizeof(int), cmp);
    int m = 0;
    for (int i = 0; i + 2 < n; i++) {
        if (i > 0 && a[i] == a[i - 1]) continue;   /* same pin, same answers */
        int lo = i + 1, hi = n - 1;
        while (lo < hi) {
            int sum = a[i] + a[lo] + a[hi];
            if (sum == 0) {
                out[m * 3] = a[i]; out[m * 3 + 1] = a[lo]; out[m * 3 + 2] = a[hi]; m++;
                while (lo < hi && a[lo] == a[lo + 1]) lo++;   /* equal lo's */
                while (lo < hi && a[hi] == a[hi - 1]) hi--;   /* equal hi's */
                lo++; hi--;
            } else if (sum < 0) {
                lo++;                       /* need a larger middle value */
            } else {
                hi--;                       /* need a smaller last value */
            }
        }
    }
    return m;
}

int main(void) {
    int a[] = {-1, 0, 1, 2, -1, -4}, out[64];
    int m = three_sum(a, 6, out);
    for (int t = 0; t < m; t++)
        printf("%d %d %d\\n", out[t * 3], out[t * 3 + 1], out[t * 3 + 2]);
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

std::vector<std::vector<int>> threeSum(std::vector<int> a) {
    std::sort(a.begin(), a.end());
    std::vector<std::vector<int>> out;
    int n = (int)a.size();
    for (int i = 0; i + 2 < n; ++i) {
        if (i > 0 && a[i] == a[i - 1]) continue;      // skip repeated pins
        int lo = i + 1, hi = n - 1;
        while (lo < hi) {
            int sum = a[i] + a[lo] + a[hi];
            if (sum == 0) {
                out.push_back({a[i], a[lo], a[hi]});
                while (lo < hi && a[lo] == a[lo + 1]) ++lo;
                while (lo < hi && a[hi] == a[hi - 1]) --hi;
                ++lo; --hi;
            } else if (sum < 0) ++lo;
            else --hi;
        }
    }
    return out;
}

int main() {
    for (auto& t : threeSum({-1, 0, 1, 2, -1, -4}))
        std::cout << t[0] << ' ' << t[1] << ' ' << t[2] << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const a = nums.slice().sort((x, y) => x - y);
          const full = [];
          const fullKeys = new Set();
          for (let i = 0; i + 2 < n; i++) {
            if (i > 0 && a[i] === a[i - 1]) continue;
            let lo = i + 1, hi = n - 1;
            while (lo < hi) {
              const s = a[i] + a[lo] + a[hi];
              if (s === 0) {
                const key = `${a[i]},${a[lo]},${a[hi]}`;
                if (!fullKeys.has(key)) { fullKeys.add(key); full.push([a[i], a[lo], a[hi]]); }
                while (lo < hi && a[lo] === a[lo + 1]) lo++;
                while (lo < hi && a[hi] === a[hi - 1]) hi--;
                lo++; hi--;
              } else if (s < 0) lo++; else hi--;
            }
          }

          steps.push({
            title: n < 3 ? `Only ${n} number${n === 1 ? "" : "s"} — no triple is possible` : "Sorting is the key move",
            tracks: [
              track("the numbers", nums, blank(n, "idle")),
              track("sorted", a, blank(n, "idle")),
            ],
            counters: [count("numbers", n), count("target sum", 0)],
            legend: ["read", "compare", "result", "good", "done", "dim"],
            happened: `The row ${fmt(nums)} is about to be put in order.`,
            why: "Once the values climb from small to large, the two pointers can decide which direction to move.",
            codeLine: 10,
          });

          steps.push({
            title: `Sorted: ${fmt(a)}`,
            tracks: [
              track("the numbers", nums, blank(n, "dim")),
              track("sorted", a, blank(n, "done")),
            ],
            counters: [count("numbers", n), count("target sum", 0)],
            happened: "Equal values now sit together, which makes repeated pins easy to skip later.",
            why: "Sorted order is what turns an O(n³) search into an O(n²) one.",
            codeLine: 10,
          });

          const keptTrack = (hot) => ({
            label: "triples kept",
            cells: full.length
              ? full.map((t) => ({ v: `[${t.join(", ")}]`, state: hot && t.join(",") === hot ? "result" : "good" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          for (let i = 0; i + 2 < n; i++) {
            if (i > 0 && a[i] === a[i - 1]) {
              steps.push({
                title: `Pin ${a[i]} is the same as the last pin — skipped`,
                tracks: [
                  track("sorted", a, paint(blank(n, "done"), { [i - 1]: "dim", [i]: "bad" })),
                  keptTrack(null),
                ],
                counters: [count("pin index", i), count("triples kept", full.length)],
                happened: `Pin ${a[i - 1]} was already tried as the smallest member, so this pin can only repeat old answers.`,
                why: "Skipping duplicate pins is what keeps the output free of repeated triples.",
                codeLine: 12,
              });
              continue;
            }
            let lo = i + 1, hi = n - 1;
            steps.push({
              title: `Pin ${a[i]}; sweep the rest from both ends`,
              tracks: [
                track("sorted", a, paint(blank(n, "done"), { [i]: "compare", [lo]: "read", [hi]: "read" })),
                keptTrack(null),
              ],
              pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }],
              counters: [count("pin value", a[i]), count("left", a[lo]), count("right", a[hi]), count("triples kept", full.length)],
              happened: `With ${a[i]} fixed, ${a[lo]} and ${a[hi]} are the two candidates for the other positions.`,
              why: "Fixing the smallest value leaves a two-value problem, which the pointers solve in one sweep.",
              codeLine: 14,
            });
            while (lo < hi) {
              const s = a[i] + a[lo] + a[hi];
              const hit = s === 0;
              if (hit) {
                const key = `${a[i]},${a[lo]},${a[hi]}`;
                steps.push({
                  title: `${a[i]} + ${a[lo]} + ${a[hi]} = 0 → keep [${a[i]}, ${a[lo]}, ${a[hi]}]`,
                  tracks: [
                    track("sorted", a, paint(blank(n, "done"), { [i]: "compare", [lo]: "result", [hi]: "result" })),
                    keptTrack(key),
                  ],
                  pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }],
                  counters: [count("running sum", s), count("triples kept", fullKeys.size)],
                  happened: `The pin and the two pointers cancel out exactly; the triple is recorded.`,
                  why: "After a hit, both pointers step inward, and equal values are skipped so the same triple is not stored twice.",
                  codeLine: 17,
                });
                while (lo < hi && a[lo] === a[lo + 1]) lo++;
                while (lo < hi && a[hi] === a[hi - 1]) hi--;
                lo++; hi--;
              } else {
                steps.push({
                  title: `${a[i]} + ${a[lo]} + ${a[hi]} = ${s} — ${s < 0 ? "too small, move left up" : "too big, move right down"}`,
                  tracks: [
                    track("sorted", a, paint(blank(n, "done"), { [i]: "compare", [lo]: "read", [hi]: "read" })),
                    keptTrack(null),
                  ],
                  pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }],
                  counters: [count("running sum", s), count("triples kept", fullKeys.size)],
                  happened: `The three values add to ${s}, so this pair of pointers cannot work.`,
                  why: s < 0
                    ? "A negative total means the middle value is too small, and only the left pointer can raise it."
                    : "A positive total means the last value is too large, and only the right pointer can lower it.",
                  codeLine: s < 0 ? 20 : 22,
                });
                if (s < 0) lo++; else hi--;
              }
            }
          }

          steps.push({
            title: full.length
              ? `Answer: ${full.length} distinct triple${full.length === 1 ? "" : "s"} — ${full.map((t) => `[${t.join(", ")}]`).join(" ")}`
              : "Answer: no triple sums to zero",
            tracks: [
              track("sorted", a, blank(n, "dim")),
              { label: "answer", cells: full.length ? full.map((t) => ({ v: `[${t.join(", ")}]`, state: "result" })) : [{ v: "∅", state: "idle", empty: true }] },
            ],
            counters: [count("triples kept", full.length), count("answer", full.length)],
            happened: full.length
              ? `Sorting and a single sweep per pin found ${full.map((t) => `(${t.join(", ")})`).join(", ")}.`
              : "No three values in the row add up to zero.",
            why: "Every pin met a two-pointer sweep once, so the work is roughly n² instead of n³.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     8. four-sum
     ========================================================== */
  register({
    id: "four-sum",
    title: "Four Sum",
    category: "Hashing & Two Pointers",
    difficulty: "Intermediate",
    description: "List the distinct quadruples of values that add up to zero.",
    input: { label: "The numbers (target = 0)", default: "1, 0, -1, 0, -2, 2", parse: "ints" },
    approaches: [
      {
        name: "Check Every Quadruple",
        complexity: "O(n⁴) time, O(1) extra space",
        idea: [
          "Choose four different positions, add their values, and keep the choice when the total is zero.",
          "Each accepted quadruple is sorted, and the sorted form is compared with what has already been kept so that the same four values are not listed twice.",
        ],
        problem: [
          "Four nested loops grow as n⁴/24, which is hopeless beyond a handful of numbers. The duplicate filter makes it slower still.",
        ],
        code: {
          c: `#include <stdio.h>

static int same(const int *o, int m, const int *q) {
    for (int t = 0; t < m; t++) {
        int ok = 1;
        for (int p = 0; p < 4; p++)
            if (o[t * 4 + p] != q[p]) { ok = 0; break; }
        if (ok) return 1;
    }
    return 0;
}

/* every distinct quadruple summing to target, each stored sorted */
int four_sum(const int *a, int n, int target, int *out) {
    int m = 0;
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
            for (int k = j + 1; k < n; k++)
                for (int l = k + 1; l < n; l++) {
                    if (a[i] + a[j] + a[k] + a[l] != target) continue;
                    int q[4] = {a[i], a[j], a[k], a[l]};
                    for (int p = 0; p < 4; p++)
                        for (int r = p + 1; r < 4; r++)
                            if (q[p] > q[r]) { int t = q[p]; q[p] = q[r]; q[r] = t; }
                    if (!same(out, m, q)) {
                        for (int p = 0; p < 4; p++) out[m * 4 + p] = q[p];
                        m++;
                    }
                }
    return m;
}

int main(void) {
    int a[] = {1, 0, -1, 0, -2, 2}, out[64];
    printf("%d\\n", four_sum(a, 6, 0, out)); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <set>
#include <algorithm>

// all quadruples, with a set removing repeats
std::vector<std::vector<int>> fourSum(const std::vector<int>& a, int target) {
    std::set<std::vector<int>> found;
    int n = (int)a.size();
    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j)
            for (int k = j + 1; k < n; ++k)
                for (int l = k + 1; l < n; ++l)
                    if (a[i] + a[j] + a[k] + a[l] == target) {
                        std::vector<int> q{a[i], a[j], a[k], a[l]};
                        std::sort(q.begin(), q.end());
                        found.insert(q);
                    }
    return {found.begin(), found.end()};
}

int main() {
    for (auto& q : fourSum({1, 0, -1, 0, -2, 2}, 0))
        std::cout << q[0] << ' ' << q[1] << ' ' << q[2] << ' ' << q[3] << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const target = 0;
          const norm = (q) => q.slice().sort((a, b) => a - b);
          const keyOf = (q) => q.join(",");
          const full = [], fullKeys = new Set();
          for (let i = 0; i < n; i++)
            for (let j = i + 1; j < n; j++)
              for (let k = j + 1; k < n; k++)
                for (let l = k + 1; l < n; l++)
                  if (nums[i] + nums[j] + nums[k] + nums[l] === target) {
                    const q = norm([nums[i], nums[j], nums[k], nums[l]]);
                    if (!fullKeys.has(keyOf(q))) { fullKeys.add(keyOf(q)); full.push(q); }
                  }
          full.sort((a, b) => a[0] - b[0] || a[1] - b[1] || a[2] - b[2] || a[3] - b[3]);

          const kept = [], keptKeys = new Set();
          const keptTrack = (hot) => ({
            label: "quadruples kept",
            cells: kept.length
              ? kept.map((q) => ({ v: `[${q.join(", ")}]`, state: hot && keyOf(q) === hot ? "result" : "good" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          steps.push({
            title: n < 4
              ? `Only ${n} number${n === 1 ? "" : "s"} — a quadruple needs four`
              : `${n} numbers give ${(n * (n - 1) * (n - 2) * (n - 3)) / 24} quadruples to test`,
            tracks: [
              track("the numbers", nums, blank(n, "idle")),
              keptTrack(null),
            ],
            counters: [count("numbers", n), count("target", target), count("quadruples possible", (n * (n - 1) * (n - 2) * (n - 3)) / 24)],
            legend: ["read", "result", "good", "done", "dim"],
            happened: `The target is fixed at ${target}; four different positions must supply it.`,
            why: "Trying every set of four positions is exhaustive but expensive, which the step counts will show.",
            codeLine: 13,
          });

          let shown = 0, truncated = false;
          for (let i = 0; i < n; i++) {
            let stop = false;
            for (let j = i + 1; j < n; j++) {
              for (let k = j + 1; k < n; k++) {
                for (let l = k + 1; l < n; l++) {
                  if (shown >= 90) { truncated = true; stop = true; break; }
                  shown++;
                  const sum = nums[i] + nums[j] + nums[k] + nums[l];
                  const hit = sum === target;
                  let fresh = false;
                  if (hit) {
                    const q = norm([nums[i], nums[j], nums[k], nums[l]]);
                    fresh = !keptKeys.has(keyOf(q));
                    if (fresh) { keptKeys.add(keyOf(q)); kept.push(q); }
                  }
                  const st = blank(n, "idle");
                  st[i] = "compare"; st[j] = "compare";
                  st[k] = "compare"; st[l] = hit ? "result" : "read";
                  steps.push({
                    title: hit
                      ? `${nums[i]} + ${nums[j]} + ${nums[k]} + ${nums[l]} = 0 → ${fresh ? "new quadruple kept" : "already kept"}`
                      : `${nums[i]} + ${nums[j]} + ${nums[k]} + ${nums[l]} = ${sum} — not zero`,
                    tracks: [track("the numbers", nums, st), keptTrack(hit && fresh ? keyOf(norm([nums[i], nums[j], nums[k], nums[l]])) : null)],
                    counters: [count("quadruples tested", shown), count("running sum", sum), count("kept", kept.length)],
                    happened: hit
                      ? `Positions ${i}, ${j}, ${k} and ${l} add up to ${target}.`
                      : `This choice of four positions adds up to ${sum}, so it is discarded.`,
                    why: hit
                      ? "The sorted form of the four values is what gets stored, so order of choice does not matter."
                      : "Every tested quadruple is one possibility removed from the search.",
                    codeLine: hit ? 18 : 17,
                  });
                  if (stop) break;
                }
                if (stop) break;
              }
              if (stop) break;
            }
            if (stop) break;
          }
          if (truncated) {
            steps.push({
              title: `Animation stops after ${shown} quadruples — the rest are more of the same`,
              tracks: [track("the numbers", nums, blank(n, "done")), keptTrack(null)],
              counters: [count("quadruples tested", shown)],
              happened: "Four nested loops produce a huge number of ordinary additions.",
              why: "A short excerpt conveys the cost without an unusable timeline.",
              codeLine: 14,
            });
          }

          steps.push({
            title: full.length
              ? `Answer: ${full.length} distinct quadruple${full.length === 1 ? "" : "s"} — ${full.map((q) => `[${q.join(", ")}]`).join(" ")}`
              : "Answer: no quadruple sums to zero",
            tracks: [
              track("the numbers", nums, blank(n, "dim")),
              { label: "answer", cells: full.length ? full.map((q) => ({ v: `[${q.join(", ")}]`, state: "result" })) : [{ v: "∅", state: "idle", empty: true }] },
            ],
            counters: [count("quadruples tested", shown), count("answer", full.length)],
            happened: full.length
              ? `The distinct quadruples ${full.map((q) => `(${q.join(", ")})`).join(", ")} each add up to zero.`
              : "No four values in the row add up to zero.",
            why: "Every quadruple was tested, so the list is complete.",
            codeLine: 22,
          });
          return steps;
        },
      },
      {
        name: "Sort, Fix Two, Sweep the Rest",
        complexity: "O(n³) time, O(1) extra space (plus the sort)",
        idea: [
          "Sort the row. Then choose two positions to pin, and let two pointers close the remaining gap from the ends.",
          "Equal values are skipped at every level, so each distinct quadruple is produced exactly once.",
        ],
        problem: [
          "Even after the improvement the cost is about n³. It also needs the sorted order and careful skipping, which is where it is easy to slip up.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

static int cmp(const void *x, const void *y) {
    int a = *(const int *)x, b = *(const int *)y;
    return (a > b) - (a < b);
}

/* sort, pin two values, then sweep the last two with lo/hi */
int four_sum(int *a, int n, int target, int *out) {
    qsort(a, n, sizeof(int), cmp);
    int m = 0;
    for (int i = 0; i + 3 < n; i++) {
        if (i > 0 && a[i] == a[i - 1]) continue;
        for (int j = i + 1; j + 2 < n; j++) {
            if (j > i + 1 && a[j] == a[j - 1]) continue;
            int lo = j + 1, hi = n - 1;
            while (lo < hi) {
                long sum = (long)a[i] + a[j] + a[lo] + a[hi];
                if (sum == target) {
                    out[m * 4] = a[i]; out[m * 4 + 1] = a[j];
                    out[m * 4 + 2] = a[lo]; out[m * 4 + 3] = a[hi]; m++;
                    while (lo < hi && a[lo] == a[lo + 1]) lo++;
                    while (lo < hi && a[hi] == a[hi - 1]) hi--;
                    lo++; hi--;
                } else if (sum < target) {
                    lo++;
                } else {
                    hi--;
                }
            }
        }
    }
    return m;
}

int main(void) {
    int a[] = {1, 0, -1, 0, -2, 2}, out[64];
    printf("%d\\n", four_sum(a, 6, 0, out)); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

std::vector<std::vector<int>> fourSum(std::vector<int> a, int target) {
    std::sort(a.begin(), a.end());
    std::vector<std::vector<int>> out;
    int n = (int)a.size();
    for (int i = 0; i + 3 < n; ++i) {
        if (i > 0 && a[i] == a[i - 1]) continue;
        for (int j = i + 1; j + 2 < n; ++j) {
            if (j > i + 1 && a[j] == a[j - 1]) continue;
            int lo = j + 1, hi = n - 1;
            while (lo < hi) {
                long long sum = (long long)a[i] + a[j] + a[lo] + a[hi];
                if (sum == target) {
                    out.push_back({a[i], a[j], a[lo], a[hi]});
                    while (lo < hi && a[lo] == a[lo + 1]) ++lo;
                    while (lo < hi && a[hi] == a[hi - 1]) --hi;
                    ++lo; --hi;
                } else if (sum < target) ++lo;
                else --hi;
            }
        }
    }
    return out;
}

int main() {
    for (auto& q : fourSum({1, 0, -1, 0, -2, 2}, 0))
        std::cout << q[0] << ' ' << q[1] << ' ' << q[2] << ' ' << q[3] << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const target = 0;
          const a = nums.slice().sort((x, y) => x - y);
          const full = [], fullKeys = new Set();
          for (let i = 0; i + 3 < n; i++) {
            if (i > 0 && a[i] === a[i - 1]) continue;
            for (let j = i + 1; j + 2 < n; j++) {
              if (j > i + 1 && a[j] === a[j - 1]) continue;
              let lo = j + 1, hi = n - 1;
              while (lo < hi) {
                const s = a[i] + a[j] + a[lo] + a[hi];
                if (s === target) {
                  const key = `${a[i]},${a[j]},${a[lo]},${a[hi]}`;
                  if (!fullKeys.has(key)) { fullKeys.add(key); full.push([a[i], a[j], a[lo], a[hi]]); }
                  while (lo < hi && a[lo] === a[lo + 1]) lo++;
                  while (lo < hi && a[hi] === a[hi - 1]) hi--;
                  lo++; hi--;
                } else if (s < target) lo++; else hi--;
              }
            }
          }

          steps.push({
            title: n < 4 ? `Only ${n} number${n === 1 ? "" : "s"} — no quadruple is possible` : "Sort first, then pin two values",
            tracks: [
              track("the numbers", nums, blank(n, "idle")),
              track("sorted", a, blank(n, "idle")),
            ],
            counters: [count("numbers", n), count("target", target)],
            legend: ["read", "compare", "result", "good", "done", "dim"],
            happened: `The row ${fmt(nums)} will be ordered so the last two values can be found with two pointers.`,
            why: "Pinning two values leaves a two-value problem, and two pointers solve that in a single sweep.",
            codeLine: 12,
          });

          steps.push({
            title: `Sorted: ${fmt(a)}`,
            tracks: [
              track("the numbers", nums, blank(n, "dim")),
              track("sorted", a, blank(n, "done")),
            ],
            counters: [count("numbers", n), count("target", target)],
            happened: "Duplicates are now neighbours, ready to be skipped at every level.",
            why: "Skipping equal values turns n⁴ work into roughly n³ without losing any distinct answer.",
            codeLine: 12,
          });

          const keptTrack = (hot) => ({
            label: "quadruples kept",
            cells: full.length
              ? full.map((q) => ({ v: `[${q.join(", ")}]`, state: hot && q.join(",") === hot ? "result" : "good" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          for (let i = 0; i + 3 < n; i++) {
            if (i > 0 && a[i] === a[i - 1]) continue;
            for (let j = i + 1; j + 2 < n; j++) {
              if (j > i + 1 && a[j] === a[j - 1]) {
                steps.push({
                  title: `Second pin ${a[j]} repeats the previous one — skipped`,
                  tracks: [
                    track("sorted", a, paint(blank(n, "done"), { [i]: "compare", [j - 1]: "dim", [j]: "bad" })),
                    keptTrack(null),
                  ],
                  counters: [count("first pin", a[i]), count("second pin", a[j]), count("kept", full.length)],
                  happened: `With ${a[i]} pinned first, ${a[j]} as second pin can only repeat answers already found.`,
                  why: "Skipping repeated pins is how the sorted method avoids duplicate quadruples.",
                  codeLine: 15,
                });
                continue;
              }
              let lo = j + 1, hi = n - 1;
              steps.push({
                title: `Pins ${a[i]} and ${a[j]}; sweep the rest from both ends`,
                tracks: [
                  track("sorted", a, paint(blank(n, "done"), { [i]: "compare", [j]: "compare", [lo]: "read", [hi]: "read" })),
                  keptTrack(null),
                ],
                pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }],
                counters: [count("pins", `${a[i]} + ${a[j]}`), count("left", a[lo]), count("right", a[hi]), count("kept", full.length)],
                happened: `The two pinned values are ${a[i]} and ${a[j]}; ${a[lo]} and ${a[hi]} are the remaining candidates.`,
                why: "Everything else is a two-value search, which swings inwards predictably.",
                codeLine: 16,
              });
              while (lo < hi) {
                const s = a[i] + a[j] + a[lo] + a[hi];
                const hit = s === target;
                if (hit) {
                  const key = `${a[i]},${a[j]},${a[lo]},${a[hi]}`;
                  steps.push({
                    title: `${a[i]} + ${a[j]} + ${a[lo]} + ${a[hi]} = 0 → keep [${a[i]}, ${a[j]}, ${a[lo]}, ${a[hi]}]`,
                    tracks: [
                      track("sorted", a, paint(blank(n, "done"), { [i]: "compare", [j]: "compare", [lo]: "result", [hi]: "result" })),
                      keptTrack(key),
                    ],
                    pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }],
                    counters: [count("running sum", s), count("kept", fullKeys.size)],
                    happened: "Four values cancel exactly, so this quadruple is recorded.",
                    why: "After a hit both pointers step inward, and equal values are skipped to avoid repeats.",
                    codeLine: 20,
                  });
                  while (lo < hi && a[lo] === a[lo + 1]) lo++;
                  while (lo < hi && a[hi] === a[hi - 1]) hi--;
                  lo++; hi--;
                } else {
                  steps.push({
                    title: `${a[i]} + ${a[j]} + ${a[lo]} + ${a[hi]} = ${s} — ${s < 0 ? "too small, move left up" : "too big, move right down"}`,
                    tracks: [
                      track("sorted", a, paint(blank(n, "done"), { [i]: "compare", [j]: "compare", [lo]: "read", [hi]: "read" })),
                      keptTrack(null),
                    ],
                    pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }],
                    counters: [count("running sum", s), count("kept", fullKeys.size)],
                    happened: `The four values add to ${s}, so this pair of pointers cannot be right.`,
                    why: s < 0
                      ? "The total is short of the target, so the left pointer must supply something larger."
                      : "The total overshoots the target, so the right pointer must supply something smaller.",
                    codeLine: s < 0 ? 26 : 27,
                  });
                  if (s < target) lo++; else hi--;
                }
              }
            }
          }

          steps.push({
            title: full.length
              ? `Answer: ${full.length} distinct quadruple${full.length === 1 ? "" : "s"} — ${full.map((q) => `[${q.join(", ")}]`).join(" ")}`
              : "Answer: no quadruple sums to zero",
            tracks: [
              track("sorted", a, blank(n, "dim")),
              { label: "answer", cells: full.length ? full.map((q) => ({ v: `[${q.join(", ")}]`, state: "result" })) : [{ v: "∅", state: "idle", empty: true }] },
            ],
            counters: [count("kept", full.length), count("answer", full.length)],
            happened: full.length
              ? `The pinned-pair sweeps found ${full.map((q) => `(${q.join(", ")})`).join(", ")}.`
              : "No four values in the row add up to zero.",
            why: "Two pins plus two pointers covered every distinct quadruple in roughly n³ steps.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     9. remove-duplicates-from-sorted-array
     ========================================================== */
  register({
    id: "remove-duplicates-from-sorted-array",
    title: "Remove Duplicates from Sorted Array",
    category: "Hashing & Two Pointers",
    difficulty: "Beginner",
    description: "Compact a sorted row in place so each value appears once.",
    input: { label: "Sorted numbers", default: "1, 1, 2, 3, 3, 4, 4, 5", parse: "ints" },
    approaches: [
      {
        name: "Slow Write, Fast Read",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "A slow pointer marks the last position that holds a kept value; a fast pointer reads ahead through the row.",
          "Whenever the fast value differs from the last kept value it is copied to the position just after the slow pointer, which then advances. Equal values are simply stepped over.",
        ],
        problem: [
          "It only removes values that sit next to each other, so on an unsorted row copies far apart would survive. It also overwrites the input.",
        ],
        code: {
          c: `#include <stdio.h>

/* keep the first copy of each value at the front; returns the new length */
int remove_duplicates(int *a, int n) {
    if (n == 0) return 0;
    int slow = 0;                        /* last kept position */
    for (int fast = 1; fast < n; fast++)
        if (a[fast] != a[slow])          /* a value we have not kept yet */
            a[++slow] = a[fast];         /* write it after the kept block */
    return slow + 1;
}

int main(void) {
    int a[] = {1, 1, 2, 3, 3, 4, 4, 5};
    int n = remove_duplicates(a, 8);
    for (int i = 0; i < n; i++) printf("%d ", a[i]); /* 1 2 3 4 5 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// both pointers walk the same vector; slow marks the kept block
int removeDuplicates(std::vector<int>& a) {
    if (a.empty()) return 0;
    int slow = 0;
    for (int fast = 1; fast < (int)a.size(); ++fast)
        if (a[fast] != a[slow])
            a[++slow] = a[fast];
    return slow + 1;
}

int main() {
    std::vector<int> a{1, 1, 2, 3, 3, 4, 4, 5};
    int n = removeDuplicates(a);
    for (int i = 0; i < n; ++i) std::cout << a[i] << ' '; // 1 2 3 4 5
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const arr = nums.slice();
          let slow = 0;
          const isSorted = sortedAsc(nums);

          const rowTrack = (slowAt, fastAt, justWrote) =>
            track("the array", arr, arr.map((_, i) => {
              if (justWrote && i === slowAt) return "result";
              if (i === slowAt) return "compare";
              if (i === fastAt) return "read";
              if (i < slowAt) return "good";
              return "idle";
            }));

          steps.push({
            title: n < 1 ? "No values to compact" : `Slow pointer at 0, fast pointer ready at 1`,
            tracks: [rowTrack(0, n > 1 ? 1 : 0, false)],
            pointers: n > 1 ? [{ index: 0, label: "slow" }, { index: 1, label: "fast" }] : [{ index: 0, label: "slow" }],
            counters: [count("kept", 1), count("fast pointer", n > 1 ? 1 : 0), count("writes so far", 0)],
            legend: ["compare", "read", "result", "good", "bad", "idle"],
            happened: n < 1
              ? "The row is empty, so the new length is zero."
              : `${nums[0]} is kept at position 0; the fast pointer starts just after it.`,
            why: "The slow pointer marks where the kept block ends, so nothing already kept will be touched.",
            codeLine: 5,
          });

          if (!isSorted) {
            steps.push({
              title: "Careful: this row is not sorted",
              tracks: [rowTrack(0, n > 1 ? 1 : 0, false)],
              pointers: n > 1 ? [{ index: 0, label: "slow" }, { index: 1, label: "fast" }] : [{ index: 0, label: "slow" }],
              counters: [count("row sorted?", "no")],
              happened: "Values that sit next to each other can still be equal, but equal copies far apart will be missed.",
              why: "The walk only compares neighbours, so sorting the row first is part of the promise being made.",
              codeLine: 7,
            });
          }

          let writes = 0;
          for (let fast = 1; fast < n; fast++) {
            const isNew = arr[fast] !== arr[slow];
            if (isNew) {
              slow++;
              arr[slow] = nums[fast];
              writes++;
            }
            steps.push({
              title: isNew
                ? `${nums[fast]} is new → copied to position ${slow}`
                : `${nums[fast]} matches ${arr[slow]} → skipped`,
              tracks: [rowTrack(slow, fast, isNew)],
              pointers: [{ index: slow, label: "slow" }, { index: fast, label: "fast" }],
              counters: [count("kept", slow + 1), count("fast pointer", fast), count("writes so far", writes)],
              happened: isNew
                ? `${nums[fast]} differs from the last kept value, so it moves into the next free slot at index ${slow}.`
                : `${nums[fast]} equals the last kept value ${arr[slow]}, so it is left behind.`,
              why: isNew
                ? "Writing just after the kept block keeps all survivors packed at the front of the same row."
                : "Skipping a copy costs nothing: the fast pointer simply moves on.",
              codeLine: isNew ? 7 : 6,
            });
          }

          steps.push({
            title: n < 1 ? "Answer: empty array, length 0" : `Answer: length ${slow + 1} — ${arr.slice(0, slow + 1).join(", ")}`,
            tracks: [
              track("the array", arr, arr.map((_, i) => (i <= slow ? "result" : "dim"))),
              { label: "new length", cells: [{ v: slow + 1, state: "result", tag: "first " + (slow + 1) + " slots" }] },
            ],
            counters: [count("kept", slow + 1), count("writes so far", writes), count("answer", slow + 1)],
            happened: n < 1
              ? "There was nothing to keep, so the new length is 0."
              : `The first ${slow + 1} positions now hold the distinct values in order: ${arr.slice(0, slow + 1).join(", ")}.`,
            why: "Only one pass with two pointers and no extra array was needed to compact the row in place.",
            codeLine: 8,
          });
          return steps;
        },
      },
      {
        name: "Fresh Output with a Set",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Walk the row once and copy a value into a new output row only when it has never been seen before.",
          "A set of the values already copied makes that question instant, and the first occurrence of each value wins.",
        ],
        problem: [
          "It needs a second row and a set, so the memory grows with the number of values. It does work on unsorted data as well, which the in-place method cannot.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* values 0..999: copy a value only the first time it appears */
int remove_duplicates(const int *a, int n, int *out) {
    bool seen[1000] = {false};
    int m = 0;
    for (int i = 0; i < n; i++)
        if (!seen[a[i]]) {
            seen[a[i]] = true;
            out[m++] = a[i];
        }
    return m;
}

int main(void) {
    int a[] = {1, 1, 2, 3, 3, 4, 4, 5}, out[8];
    int m = remove_duplicates(a, 8, out);
    for (int i = 0; i < m; i++) printf("%d ", out[i]); /* 1 2 3 4 5 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_set>

std::vector<int> removeDuplicates(const std::vector<int>& a) {
    std::unordered_set<int> seen;
    std::vector<int> out;
    for (int x : a)
        if (seen.insert(x).second)   // only the first copy passes
            out.push_back(x);
    return out;
}

int main() {
    for (int v : removeDuplicates({1, 1, 2, 3, 3, 4, 4, 5}))
        std::cout << v << ' ';       // 1 2 3 4 5
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const seen = new Set();
          const out = [];
          const outTrack = (hot) => ({
            label: "output",
            cells: out.length
              ? out.map((v) => ({ v, state: v === hot ? "result" : "good" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          steps.push({
            title: "Empty output, empty set",
            tracks: [
              track("the numbers", nums, blank(n, "idle")),
              outTrack(null),
            ],
            counters: [count("read", 0, n), count("written", 0)],
            legend: ["read", "result", "good", "bad", "done"],
            happened: "Nothing has been copied yet; the set has no memory of any value.",
            why: "Keeping the first occurrence of each value preserves the original order while dropping repeats.",
            codeLine: 4,
          });

          for (let i = 0; i < n; i++) {
            const v = nums[i];
            const dup = seen.has(v);
            if (!dup) { seen.add(v); out.push(v); }
            steps.push({
              title: dup ? `${v} already copied → skipped` : `${v} is new → written to the output`,
              tracks: [
                track("the numbers", nums, paint(blank(n, dup ? "bad" : "done"), { [i]: dup ? "bad" : "read" })),
                outTrack(dup ? null : v),
              ],
              counters: [count("read", i + 1, n), count("written", out.length)],
              happened: dup
                ? `${v} is already in the set, so this later copy is not written out.`
                : `${v} was never seen before, so it joins both the output and the set.`,
              why: dup
                ? "One set lookup answered 'have I copied this?' without re-reading the output."
                : "Copying first occurrences only is exactly what 'keep one of each' means.",
              codeLine: dup ? 8 : 9,
            });
          }

          steps.push({
            title: n < 1 ? "Answer: empty output" : `Answer: ${out.length} value${out.length === 1 ? "" : "s"} — ${out.join(", ")}`,
            tracks: [
              track("the numbers", nums, nums.map((v) => (out.indexOf(v) !== -1 ? "good" : "bad"))),
              outTrack(null),
            ],
            counters: [count("read", n, n), count("answer", out.length)],
            happened: n < 1
              ? "There was nothing to copy."
              : `${n - out.length} repeated cop${n - out.length === 1 ? "y was" : "ies were"} left behind, leaving ${out.join(", ")}.`,
            why: "A single pass with a set removed every repeat, though it needed a second row to hold the result.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });
})();
