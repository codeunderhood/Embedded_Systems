/* ============================================================
   DSA Visuals — Strings & Text Basics
   Original authoring module (see SPEC.md). Six visualisations:
   anagram checks and grouping, palindromes, common prefixes,
   word-order reversal and run-length compression.
   Every step: { title, tracks, counters, happened, why,
                 legend?, codeLine? }   (kind defaults to "cells")
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  /* small local helpers used by several visualisations */
  const toArr = (s) => Array.from(String(s == null ? "" : s));
  const isAlnum = (ch) => /[a-z0-9]/i.test(ch);
  const lower = (ch) => ch.toLowerCase();
  const byLetter = (a, b) => (lower(a) < lower(b) ? -1 : lower(a) > lower(b) ? 1 : 0);
  const normalise = (arr) => arr.join("");

  /* ---------------------------------------------------------- */
  V.register({
    id: "valid-anagram",
    title: "Valid Anagram",
    category: "Strings & Text",
    difficulty: "Beginner",
    description: "Two words built from exactly the same letters, checked two ways.",
    input: { label: "Two words", default: "anagram nagaram", parse: "tokens" },
    approaches: [
      {
        name: "Tally Letters, Then Cancel",
        complexity: "O(n) time, O(1) extra space (fixed alphabet)",
        idea: [
          "Walk the first word and count how often each letter shows up. Then walk the second word and subtract one for every letter you meet.",
          "If the words really use the same letters, every bucket lands back on zero. A bucket that goes negative means the second word used a letter the first one never had.",
          "Letters are compared without regard to case, so \"Listen\" and \"Silent\" are treated as the same word.",
        ],
        problem: [
          "The tally is only as cheap as the alphabet is small: a fixed array is fine for letters, but arbitrary characters would need a hash map.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>
#include <ctype.h>

/* Case-insensitive; every byte is counted as a letter. */
int is_anagram(const char *a, const char *b) {
    if (strlen(a) != strlen(b)) return 0;
    int count[256] = {0};
    for (int i = 0; a[i]; i++) count[(unsigned char)tolower(a[i])]++;
    for (int i = 0; b[i]; i++) count[(unsigned char)tolower(b[i])]--;
    for (int k = 0; k < 256; k++)
        if (count[k] != 0) return 0;
    return 1;
}

int main(void) {
    printf("%d\\n", is_anagram("anagram", "nagaram")); /* 1 */
    printf("%d\\n", is_anagram("rat", "car"));         /* 0 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
#include <cctype>

// Count the letters of a, cancel them with b, then check nothing is left.
bool isAnagram(const std::string& a, const std::string& b) {
    if (a.size() != b.size()) return false;
    std::vector<int> count(256, 0);
    for (unsigned char c : a) count[std::tolower(c)]++;
    for (unsigned char c : b) count[std::tolower(c)]--;
    for (int c : count) if (c != 0) return false;
    return true;
}

int main() {
    std::cout << isAnagram("anagram", "nagaram") << '\\n'; // 1
    std::cout << isAnagram("rat", "car") << '\\n';         // 0
}`,
        },
        steps(tokens) {
          const list = Array.isArray(tokens) ? tokens : [];
          if (list.length < 2) {
            const shown = list.length ? toArr(list[0]) : ["—"];
            return [{
              title: "Two words are needed for an anagram check",
              tracks: [
                track("word A", shown, fill(shown.length, "idle")),
                track("word B", ["—"], ["idle"]),
              ],
              counters: [count("words given", list.length)],
              legend: ["read", "done", "result", "bad", "idle"],
              happened: list.length
                ? `Only one token was given ("${list[0]}"), so there is no second word to compare it with.`
                : "No words were given at all, so there is nothing to compare.",
              why: "Type two words separated by a space, for example anagram nagaram, and press Run.",
            }];
          }

          const A = toArr(list[0]);
          const B = toArr(list[1]);
          const extra = list.length > 2
            ? ` The other ${list.length - 2} token${list.length - 2 === 1 ? "" : "s"} will be ignored.`
            : "";
          const tally = new Map();
          const steps = [];
          const tallyTrack = (hotKey) => ({
            label: "letter tally",
            cells: tally.size
              ? [...tally.keys()].sort().map((k) => ({
                  v: `${k}×${tally.get(k)}`,
                  state: k === hotKey ? (tally.get(k) < 0 ? "bad" : "read") : (tally.get(k) === 0 ? "done" : "result"),
                }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          steps.push({
            title: `Two words: "${list[0]}" and "${list[1]}"`,
            tracks: [
              track("word A", A, fill(A.length, "idle")),
              track("word B", B, fill(B.length, "idle")),
              tallyTrack(),
            ],
            counters: [count("letters in A", A.length), count("letters in B", B.length)],
            legend: ["read", "done", "result", "bad", "idle"],
            happened: `Word A has ${A.length} letter${A.length === 1 ? "" : "s"}, word B has ${B.length}.${extra}`,
            why: "Before counting anything we agree on the rule: same letters, same amounts, order irrelevant.",
            codeLine: 5,
          });

          steps.push({
            title: `Lengths ${A.length} vs ${B.length}`,
            tracks: [
              track("word A", A, fill(A.length, "read")),
              track("word B", B, fill(B.length, "read")),
              tallyTrack(),
            ],
            counters: [count("letters in A", A.length), count("letters in B", B.length)],
            legend: ["read", "done", "result", "bad", "idle"],
            happened: A.length === B.length
              ? `Both words are ${A.length} letters long — a good first sign.`
              : `A is ${A.length} letters but B is ${B.length}; no rearrangement can fix that.`,
            why: "Anagrams must contain the same total number of letters, so mismatched lengths settle the question at once.",
            codeLine: 6,
          });
          if (A.length !== B.length) {
            steps.push({
              title: "Answer: not an anagram",
              tracks: [
                track("word A", A, fill(A.length, "bad")),
                track("word B", B, fill(B.length, "bad")),
                tallyTrack(),
                { label: "answer", cells: [{ v: "no", state: "result" }] },
              ],
              counters: [count("letters in A", A.length), count("letters in B", B.length), count("answer", "no")],
              legend: ["bad", "result", "idle"],
              happened: `The lengths differ (${A.length} versus ${B.length}), so the two words cannot be made of the same letters.`,
              why: "The cheapest possible test already gives the final answer — no tallying is needed.",
              codeLine: 6,
            });
            return steps;
          }

          for (let i = 0; i < A.length; i++) {
            const k = lower(A[i]);
            tally.set(k, (tally.get(k) || 0) + 1);
            steps.push({
              title: `Count '${A[i]}' → ${k}×${tally.get(k)}`,
              tracks: [
                track("word A", A, paint(fill(A.length, "done"), { [i]: "read" })),
                track("word B", B, fill(B.length, "idle")),
                tallyTrack(k),
              ],
              counters: [count("letters read from A", i + 1, A.length), count("distinct letters", tally.size)],
              happened: i === 0
                ? `The first letter '${A[i]}' opens its own bucket with a count of 1.`
                : `'${A[i]}' adds one more to the bucket, now at ${tally.get(k)}.`,
              why: "A tally turns \"how many of this letter?\" into a single lookup instead of re-scanning the word.",
              codeLine: 8,
            });
          }

          steps.push({
            title: "Tally of A complete",
            tracks: [
              track("word A", A, fill(A.length, "done")),
              track("word B", B, fill(B.length, "idle")),
              tallyTrack(),
            ],
            counters: [count("letters read from A", A.length, A.length), count("distinct letters", tally.size)],
            happened: `A's letters are counted: ${[...tally].map(([k, v]) => `${k}×${v}`).join(", ")}.`,
            why: "Now every letter of B can be cancelled against this table in one pass.",
            codeLine: 8,
          });

          let mismatch = null;
          for (let i = 0; i < B.length; i++) {
            const k = lower(B[i]);
            tally.set(k, (tally.get(k) || 0) - 1);
            if (tally.get(k) < 0 && mismatch === null) mismatch = k;
            steps.push({
              title: tally.get(k) < 0
                ? `'${B[i]}' has no partner in A → ${k}×${tally.get(k)}`
                : `Cancel '${B[i]}' → ${k}×${tally.get(k)}`,
              tracks: [
                track("word A", A, fill(A.length, "done")),
                track("word B", B, paint(fill(B.length, "done"), { [i]: "read" })),
                tallyTrack(k),
              ],
              counters: [count("letters cancelled from B", i + 1, B.length), count("buckets off zero", [...tally.values()].filter((v) => v !== 0).length)],
              happened: tally.get(k) < 0
                ? `B uses the letter '${B[i]}' more often than A did, so its bucket drops below zero.`
                : `One use of '${B[i]}' is struck off A's tally, leaving ${tally.get(k)}.`,
              why: tally.get(k) < 0
                ? "A negative bucket is proof the words differ, because that letter simply is not available in A."
                : "Cancelling pairs up the two words letter by letter; unused letters will remain when we finish.",
              codeLine: 9,
            });
          }

          const healthy = [...tally.values()].every((v) => v === 0);
          steps.push({
            title: healthy ? "Answer: yes, they are anagrams" : "Answer: no, they are not",
            tracks: [
              track("word A", A, fill(A.length, healthy ? "good" : "bad")),
              track("word B", B, fill(B.length, healthy ? "good" : "bad")),
              tallyTrack(),
              { label: "answer", cells: [{ v: healthy ? "yes" : "no", state: "result" }] },
            ],
            counters: [count("letters cancelled from B", B.length, B.length), count("answer", healthy ? "yes" : "no")],
            legend: ["good", "bad", "done", "result", "idle"],
            happened: healthy
              ? "Every bucket came back to zero, so each letter was used exactly the same number of times."
              : `At least one bucket is not zero (first offender: '${mismatch}'), so the two words use different letters.`,
            why: "A tally that ends all-zero is exactly the definition of two anagrams.",
            codeLine: 11,
          });
          return steps;
        },
      },
      {
        name: "Sort Both Words, Then Compare",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Two words are anagrams exactly when their letters, sorted, spell the same string.",
          "Sort the letters of each word into alphabetical order, then compare position by position from left to right.",
          "Case is ignored again, so 'Nagaram' and 'anagram' sort to the same order of letters.",
        ],
        problem: [
          "Sorting costs O(n log n), more than the single counting pass of the tally approach. It is shorter to write, though, and reuses whatever sort the language already has.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

static int cmp_char(const void *x, const void *y) {
    return tolower(*(const unsigned char *)x) - tolower(*(const unsigned char *)y);
}

int is_anagram_sorted(char *a, char *b) {
    if (strlen(a) != strlen(b)) return 0;
    qsort(a, strlen(a), 1, cmp_char);
    qsort(b, strlen(b), 1, cmp_char);
    return strcmp(a, b) == 0;
}

int main(void) {
    char a[] = "anagram", b[] = "nagaram";
    printf("%d\\n", is_anagram_sorted(a, b)); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <algorithm>
#include <cctype>

// Lower-case both, sort the letters, then compare the two results.
bool isAnagramSorted(std::string a, std::string b) {
    if (a.size() != b.size()) return false;
    for (char& c : a) c = (char)std::tolower(c);
    for (char& c : b) c = (char)std::tolower(c);
    std::sort(a.begin(), a.end());
    std::sort(b.begin(), b.end());
    return a == b;
}

int main() {
    std::cout << isAnagramSorted("anagram", "nagaram") << '\\n'; // 1
    std::cout << isAnagramSorted("rat", "car") << '\\n';         // 0
}`,
        },
        steps(tokens) {
          const list = Array.isArray(tokens) ? tokens : [];
          if (list.length < 2) {
            const shown = list.length ? toArr(list[0]) : ["—"];
            return [{
              title: "Two words are needed for an anagram check",
              tracks: [
                track("word A", shown, fill(shown.length, "idle")),
                track("word B", ["—"], ["idle"]),
              ],
              counters: [count("words given", list.length)],
              legend: ["read", "done", "result", "bad", "idle"],
              happened: list.length
                ? `Only one token was given ("${list[0]}"), so there is nothing to compare it with.`
                : "No words were given at all.",
              why: "Type two words separated by a space and press Run.",
            }];
          }

          const A = toArr(list[0]);
          const B = toArr(list[1]);
          const sortedA = A.slice().sort(byLetter);
          const sortedB = B.slice().sort(byLetter);
          const steps = [];

          steps.push({
            title: `Two words: "${list[0]}" and "${list[1]}"`,
            tracks: [
              track("word A", A, fill(A.length, "idle")),
              track("word B", B, fill(B.length, "idle")),
            ],
            counters: [count("letters in A", A.length), count("letters in B", B.length)],
            legend: ["read", "good", "bad", "idle"],
            happened: `Sorting leaves the letters in a fixed order, so two words with the same letters become identical.${list.length > 2 ? ` The other ${list.length - 2} token(s) are ignored.` : ""}`,
            why: "If two multisets of letters are equal, their sorted copies must look the same — that is the whole test.",
            codeLine: 9,
          });

          steps.push({
            title: "Sort A's letters",
            tracks: [
              track("word A", A, fill(A.length, "idle")),
              track("A sorted", sortedA, fill(sortedA.length, "result")),
            ],
            counters: [count("letters sorted", A.length)],
            happened: `"${list[0]}" rearranges into "${sortedA.join("")}".`,
            why: "Putting A in alphabetical order gives a canonical shape for comparison.",
            codeLine: 11,
          });

          steps.push({
            title: "Sort B's letters",
            tracks: [
              track("word B", B, fill(B.length, "idle")),
              track("B sorted", sortedB, fill(sortedB.length, "result")),
            ],
            counters: [count("letters sorted", B.length)],
            happened: `"${list[1]}" rearranges into "${sortedB.join("")}".`,
            why: "Both words are now written in the same order, so one left-to-right comparison can decide.",
            codeLine: 12,
          });

          if (A.length !== B.length) {
            steps.push({
              title: "Answer: not an anagram",
              tracks: [
                track("A sorted", sortedA, fill(sortedA.length, "bad")),
                track("B sorted", sortedB, fill(sortedB.length, "bad")),
                { label: "answer", cells: [{ v: "no", state: "result" }] },
              ],
              counters: [count("answer", "no")],
              legend: ["bad", "result", "idle"],
              happened: `The sorted words have different lengths (${A.length} versus ${B.length}), so they can never be equal.`,
              why: "Length alone rules it out before a single letter is compared.",
              codeLine: 10,
            });
            return steps;
          }

          for (let i = 0; i < sortedA.length; i++) {
            const same = lower(sortedA[i]) === lower(sortedB[i]);
            steps.push({
              title: same
                ? `position ${i}: '${sortedA[i]}' = '${sortedB[i]}' ✓`
                : `position ${i}: '${sortedA[i]}' ≠ '${sortedB[i]}' ✗`,
              tracks: [
                track("A sorted", sortedA, sortedA.map((_, k) => (k < i ? "good" : k === i ? (same ? "good" : "bad") : "idle"))),
                track("B sorted", sortedB, sortedB.map((_, k) => (k < i ? "good" : k === i ? (same ? "good" : "bad") : "idle"))),
              ],
              counters: [count("positions compared", i + 1, sortedA.length)],
              happened: same
                ? `Both sorted words carry '${sortedA[i]}' at position ${i}.`
                : `A has '${sortedA[i]}' where B has '${sortedB[i]}' — the sorted words differ.`,
              why: same
                ? "A matching position means that letter is accounted for in both words."
                : "One differing position is enough: the sorted strings are not identical, so the words are not anagrams.",
              codeLine: 13,
            });
            if (!same) {
              steps.push({
                title: "Answer: not an anagram",
                tracks: [
                  track("A sorted", sortedA, fill(sortedA.length, "bad")),
                  track("B sorted", sortedB, fill(sortedB.length, "bad")),
                  { label: "answer", cells: [{ v: "no", state: "result" }] },
                ],
                counters: [count("positions compared", i + 1, sortedA.length), count("answer", "no")],
                legend: ["bad", "result", "idle"],
                happened: `The comparison stopped at position ${i}: the sorted words disagree there.`,
                why: "Different sorted letters mean the two words hold different letters in different amounts.",
                codeLine: 13,
              });
              return steps;
            }
          }

          steps.push({
            title: "Answer: yes, they are anagrams",
            tracks: [
              track("A sorted", sortedA, fill(sortedA.length, "good")),
              track("B sorted", sortedB, fill(sortedB.length, "good")),
              { label: "answer", cells: [{ v: "yes", state: "result" }] },
            ],
            counters: [count("positions compared", sortedA.length, sortedA.length), count("answer", "yes")],
            legend: ["good", "result", "idle"],
            happened: `Every position matched, so both words sort to the same string "${sortedA.join("")}".`,
            why: "Identical sorted letters is exactly what it means for two words to be rearrangements of each other.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "group-anagrams",
    title: "Group Anagrams",
    category: "Strings & Text",
    difficulty: "Intermediate",
    description: "Bucket words so that every bucket holds rearrangements of one word.",
    input: { label: "Words", default: "eat tea tan ate nat bat", parse: "words" },
    approaches: [
      {
        name: "Sort Each Word Into a Key",
        complexity: "O(n · k log k) time, O(n · k) space",
        idea: [
          "Give every word a key: its letters sorted into alphabetical order. \"eat\", \"tea\" and \"ate\" all share the key \"aet\".",
          "Walk the words once. If a word's key matches an existing bucket, join it; otherwise open a new bucket with that key.",
          "Words that end up together are exactly the ones that can be rearranged into each other.",
        ],
        problem: [
          "Sorting every word costs k log k per word. When the words are long this dominates the work, even though the comparison itself is trivial.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXW 64
#define MAXL 64

static int cmp_char(const void *x, const void *y) {
    return *(const unsigned char *)x - *(const unsigned char *)y;
}

/* key = the letters of w sorted, e.g. "eat" -> "aet" */
static void make_key(const char *w, char *key) {
    strcpy(key, w);
    qsort(key, strlen(key), 1, cmp_char);
}

int main(void) {
    const char *words[] = {"eat", "tea", "tan", "ate", "nat", "bat"};
    int n = 6, used[MAXW] = {0};
    char keys[MAXW][MAXL];
    for (int i = 0; i < n; i++) make_key(words[i], keys[i]);
    for (int i = 0; i < n; i++) {
        if (used[i]) continue;
        printf("%s", words[i]);
        used[i] = 1;
        for (int j = i + 1; j < n; j++)
            if (!used[j] && strcmp(keys[i], keys[j]) == 0) {
                printf(" %s", words[j]);
                used[j] = 1;
            }
        printf("\\n");
    }
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <unordered_map>

// Words sharing a sorted-letter key belong together.
std::vector<std::vector<std::string>> groupAnagrams(std::vector<std::string> words) {
    std::unordered_map<std::string, std::vector<std::string>> byKey;
    for (const std::string& w : words) {
        std::string key = w;
        std::sort(key.begin(), key.end());
        byKey[key].push_back(w);
    }
    std::vector<std::vector<std::string>> groups;
    for (auto& [key, g] : byKey) groups.push_back(g);
    return groups;
}

int main() {
    for (auto& g : groupAnagrams({"eat", "tea", "tan", "ate", "nat", "bat"})) {
        for (auto& w : g) std::cout << w << ' ';
        std::cout << '\\n';
    }
}`,
        },
        steps(words) {
          const W = Array.isArray(words) ? words.map(String) : [];
          if (!W.length) {
            return [{
              title: "No words to group",
              tracks: [track("words", ["—"], ["idle"])],
              counters: [count("words", 0)],
              legend: ["read", "done", "result", "idle"],
              happened: "The input held no words.",
              why: "Type a few words separated by spaces and press Run.",
            }];
          }

          const keyOfWord = (w) => toArr(w).sort(byLetter).join("");
          const keys = W.map(keyOfWord);
          const groups = [];
          const steps = [];

          const groupTracks = (active, baseState) =>
            groups.length
              ? groups.map((g, gi) => ({
                  label: `group ${gi + 1}: ${g.key}`,
                  cells: g.words.map((w, wi) => ({
                    v: w,
                    state: (gi === active && wi === g.words.length - 1) ? "read" : (baseState || "done"),
                  })),
                }))
              : [{ label: "anagram groups", cells: [{ v: "∅", state: "idle", empty: true }] }];

          steps.push({
            title: `${W.length} word${W.length === 1 ? "" : "s"} to sort into anagram groups`,
            tracks: [track("words", W, fill(W.length, "idle")), ...groupTracks(-1)],
            counters: [count("words", W.length), count("groups", 0)],
            legend: ["read", "done", "result", "idle"],
            happened: `The words are ${W.join(", ")}. Nothing has been grouped yet.`,
            why: "Anagrams are words that share the same letters; we need a way to make that sameness checkable and quick.",
            codeLine: 12,
          });

          steps.push({
            title: "Sort each word's letters to build its key",
            tracks: [track("words", W, fill(W.length, "idle"), keys.map((k) => `key ${k}`)), ...groupTracks(-1)],
            counters: [count("keys built", W.length, W.length)],
            happened: `The keys are ${keys.join(", ")}. Words with the same key will land in the same group.`,
            why: "Two words are anagrams exactly when their letters sort to the same string, so the key is a reliable fingerprint.",
            codeLine: 22,
          });

          for (let i = 0; i < W.length; i++) {
            const k = keys[i];
            let g = groups.find((gr) => gr.key === k);
            if (!g) { g = { key: k, words: [] }; groups.push(g); }
            g.words.push(W[i]);
            const gi = groups.indexOf(g);
            const states = W.map((_, wi) => (wi < i ? "done" : wi === i ? "read" : "idle"));
            steps.push({
              title: `"${W[i]}" → key "${k}" → group ${gi + 1}`,
              tracks: [track("words", W, states), ...groupTracks(gi)],
              counters: [count("words placed", i + 1, W.length), count("groups", groups.length)],
              happened: g.words.length === 1
                ? `Key "${k}" is new, so a fresh group ${gi + 1} is opened with "${W[i]}" inside.`
                : `Key "${k}" already matches group ${gi + 1}, so "${W[i]}" joins ${g.words.slice(0, -1).join(", ")}.`,
              why: "Looking the key up in a map makes the join-or-create decision a single step per word.",
              codeLine: 28,
            });
          }

          steps.push({
            title: "Check: every group shares one key",
            tracks: [track("words", W, fill(W.length, "done")), ...groupTracks(-1, "good")],
            counters: [count("groups", groups.length), count("words grouped", W.length)],
            happened: groups.map((g, gi) => `group ${gi + 1} (${g.key}): ${g.words.join(", ")}`).join("  ·  "),
            why: "Because every word was filed under its sorted letters, words inside a group are guaranteed to be rearrangements.",
            codeLine: 28,
          });

          steps.push({
            title: `Answer: ${groups.length} group${groups.length === 1 ? "" : "s"}`,
            tracks: [track("words", W, fill(W.length, "dim")), ...groupTracks(-1, "result")],
            counters: [count("groups", groups.length), count("answer", groups.length)],
            happened: `The words fall into ${groups.length} group${groups.length === 1 ? "" : "s"}: ${groups.map((g) => `[${g.words.join(", ")}]`).join(" ")}.`,
            why: "One pass with a per-word key arranged the whole list without ever comparing words pair by pair.",
            codeLine: 27,
          });
          return steps;
        },
      },
      {
        name: "Letter-Count Signature",
        complexity: "O(n · k) time, O(n · k) space",
        idea: [
          "Instead of sorting, describe each word by how many times it uses each letter. \"eat\" becomes the signature \"a1e1t1\".",
          "Two words share a signature exactly when they are anagrams, so the signature can act as the bucket key.",
          "Counting takes one pass per word and never reorders anything.",
        ],
        problem: [
          "The signature must list every letter that appears, so it can get long for large alphabets; sorting, by contrast, always produces a key of the same length as the word.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

#define MAXW 64
#define MAXS 256

/* signature: one count per letter present, e.g. "eat" -> "a1e1t1" */
static void signature(const char *w, char *out) {
    int count[26] = {0};
    for (int i = 0; w[i]; i++)
        if (w[i] >= 'a' && w[i] <= 'z') count[w[i] - 'a']++;
    out[0] = '\\0';
    for (int c = 0; c < 26; c++)
        if (count[c]) {
            char piece[8];
            sprintf(piece, "%c%d", 'a' + c, count[c]);
            strcat(out, piece);
        }
}

int main(void) {
    const char *words[] = {"eat", "tea", "tan", "ate", "nat", "bat"};
    int n = 6, used[MAXW] = {0};
    char sigs[MAXW][MAXS];
    for (int i = 0; i < n; i++) signature(words[i], sigs[i]);
    for (int i = 0; i < n; i++) {
        if (used[i]) continue;
        printf("%s", words[i]);
        used[i] = 1;
        for (int j = i + 1; j < n; j++)
            if (!used[j] && strcmp(sigs[i], sigs[j]) == 0) {
                printf(" %s", words[j]);
                used[j] = 1;
            }
        printf("\\n");
    }
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <string>
#include <array>
#include <map>

// Signature = the letter counts glued together, e.g. eat -> a1e1t1.
std::string signature(const std::string& w) {
    std::array<int, 26> count{};
    for (unsigned char c : w)
        if (c >= 'a' && c <= 'z') count[c - 'a']++;
    std::string sig;
    for (int c = 0; c < 26; c++)
        if (count[c]) sig += std::string(1, 'a' + c) + std::to_string(count[c]);
    return sig;
}

std::vector<std::vector<std::string>> groupAnagrams(const std::vector<std::string>& words) {
    std::map<std::string, std::vector<std::string>> bySig;
    for (const auto& w : words) bySig[signature(w)].push_back(w);
    std::vector<std::vector<std::string>> out;
    for (auto& [sig, g] : bySig) out.push_back(g);
    return out;
}

int main() {
    for (auto& g : groupAnagrams({"eat", "tea", "tan", "ate", "nat", "bat"})) {
        for (auto& w : g) std::cout << w << ' ';
        std::cout << '\\n';
    }
}`,
        },
        steps(words) {
          const W = Array.isArray(words) ? words.map(String) : [];
          if (!W.length) {
            return [{
              title: "No words to group",
              tracks: [track("words", ["—"], ["idle"])],
              counters: [count("words", 0)],
              legend: ["read", "done", "result", "idle"],
              happened: "The input held no words.",
              why: "Type a few words separated by spaces and press Run.",
            }];
          }

          const sigOf = (w) => {
            const counts = {};
            for (const ch of toArr(w)) {
              const c = lower(ch);
              counts[c] = (counts[c] || 0) + 1;
            }
            return Object.keys(counts).sort().map((c) => `${c}${counts[c]}`).join("");
          };
          const sigs = W.map(sigOf);
          const groups = [];
          const steps = [];

          const groupTracks = (active, baseState) =>
            groups.length
              ? groups.map((g, gi) => ({
                  label: `group ${gi + 1}: ${g.key}`,
                  cells: g.words.map((w, wi) => ({
                    v: w,
                    state: (gi === active && wi === g.words.length - 1) ? "read" : (baseState || "done"),
                  })),
                }))
              : [{ label: "anagram groups", cells: [{ v: "∅", state: "idle", empty: true }] }];

          steps.push({
            title: `${W.length} word${W.length === 1 ? "" : "s"} to describe by letter counts`,
            tracks: [track("words", W, fill(W.length, "idle")), ...groupTracks(-1)],
            counters: [count("words", W.length), count("groups", 0)],
            legend: ["read", "done", "result", "idle"],
            happened: `The words are ${W.join(", ")}. Each one will be summarised by how many of each letter it contains.`,
            why: "A count summary says everything about a multiset of letters, and counts are cheaper to build than a sort.",
            codeLine: 7,
          });

          steps.push({
            title: "Build a signature for every word",
            tracks: [track("words", W, fill(W.length, "idle"), sigs.map((s) => `sig ${s}`)), ...groupTracks(-1)],
            counters: [count("signatures built", W.length, W.length)],
            happened: `The signatures are ${sigs.join(", ")}.`,
            why: "Two words are anagrams exactly when these count summaries are identical, letter for letter.",
            codeLine: 24,
          });

          for (let i = 0; i < W.length; i++) {
            const k = sigs[i];
            let g = groups.find((gr) => gr.key === k);
            if (!g) { g = { key: k, words: [] }; groups.push(g); }
            g.words.push(W[i]);
            const gi = groups.indexOf(g);
            const states = W.map((_, wi) => (wi < i ? "done" : wi === i ? "read" : "idle"));
            steps.push({
              title: `"${W[i]}" → signature "${k}" → group ${gi + 1}`,
              tracks: [track("words", W, states), ...groupTracks(gi)],
              counters: [count("words placed", i + 1, W.length), count("groups", groups.length)],
              happened: g.words.length === 1
                ? `Signature "${k}" was unseen, so group ${gi + 1} starts with "${W[i]}".`
                : `Signature "${k}" matches group ${gi + 1}, so "${W[i]}" joins ${g.words.slice(0, -1).join(", ")}.`,
              why: "The signature is a hashable fingerprint, so placing a word is one map lookup.",
              codeLine: 30,
            });
          }

          steps.push({
            title: "Check: each group has one signature",
            tracks: [track("words", W, fill(W.length, "done")), ...groupTracks(-1, "good")],
            counters: [count("groups", groups.length), count("words grouped", W.length)],
            happened: groups.map((g, gi) => `group ${gi + 1} (${g.key}): ${g.words.join(", ")}`).join("  ·  "),
            why: "Matching count signatures mean matching letters, which is precisely the anagram condition.",
            codeLine: 30,
          });

          steps.push({
            title: `Answer: ${groups.length} group${groups.length === 1 ? "" : "s"}`,
            tracks: [track("words", W, fill(W.length, "dim")), ...groupTracks(-1, "result")],
            counters: [count("groups", groups.length), count("answer", groups.length)],
            happened: `The words fall into ${groups.length} group${groups.length === 1 ? "" : "s"}: ${groups.map((g) => `[${g.words.join(", ")}]`).join(" ")}.`,
            why: "Counting the letters once per word grouped the list in linear work per word, with no sorting at all.",
            codeLine: 29,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "valid-palindrome",
    title: "Valid Palindrome",
    category: "Strings & Text",
    difficulty: "Beginner",
    description: "Read a text from both ends to see whether it mirrors itself.",
    input: { label: "The text", default: "A man, a plan, a canal: Panama", parse: "string" },
    approaches: [
      {
        name: "Two Pointers, Skipping Noise",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "Put a pointer at each end of the text. Compare the two characters they point at, then step both inwards.",
          "Before comparing, skip over anything that is not a letter or a digit, so spaces, commas and punctuation are ignored. Letters are compared without regard to case.",
          "If no pair ever disagrees, the text is a palindrome. If a pair disagrees, it is not — and we can stop immediately.",
        ],
        problem: [
          "The skip rule makes the code a little fiddly: both pointers can run over stretches of punctuation, and progress must be guaranteed so the loop never spins in place.",
        ],
        code: {
          c: `#include <stdio.h>
#include <ctype.h>
#include <string.h>

int is_palindrome(const char *s) {
    int lo = 0, hi = (int)strlen(s) - 1;
    while (lo < hi) {
        if (!isalnum((unsigned char)s[lo])) { lo++; continue; }
        if (!isalnum((unsigned char)s[hi])) { hi--; continue; }
        if (tolower((unsigned char)s[lo]) != tolower((unsigned char)s[hi]))
            return 0;
        lo++; hi--;
    }
    return 1;
}

int main(void) {
    printf("%d\\n", is_palindrome("A man, a plan, a canal: Panama")); /* 1 */
    printf("%d\\n", is_palindrome("race a car"));                     /* 0 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <cctype>

// Skip anything that is not a letter or digit; compare case-insensitively.
bool isPalindrome(const std::string& s) {
    int lo = 0, hi = (int)s.size() - 1;
    while (lo < hi) {
        if (!std::isalnum((unsigned char)s[lo])) { lo++; continue; }
        if (!std::isalnum((unsigned char)s[hi])) { hi--; continue; }
        if (std::tolower((unsigned char)s[lo]) != std::tolower((unsigned char)s[hi]))
            return false;
        lo++; hi--;
    }
    return true;
}

int main() {
    std::cout << isPalindrome("A man, a plan, a canal: Panama") << '\\n'; // 1
    std::cout << isPalindrome("race a car") << '\\n';                     // 0
}`,
        },
        steps(str) {
          const chars = toArr(String(str));
          const n = chars.length;
          const steps = [];

          steps.push({
            title: "Rule: keep letters and digits, ignore everything else",
            tracks: [track("the text", chars, chars.map((_, i) => (i === 0 || i === n - 1 ? "read" : "idle")))],
            pointers: n > 1 ? [{ index: 0, label: "L" }, { index: n - 1, label: "R" }] : [{ index: 0, label: "L" }],
            counters: [count("characters", n), count("compared", 0)],
            legend: ["read", "good", "bad", "dim"],
            happened: `The text has ${n} character${n === 1 ? "" : "s"}. Spaces, commas and punctuation will be stepped over, and upper and lower case count as the same.`,
            why: "Filtering the comparison this way matches how a phrase palindrome is normally meant, for example \"A man, a plan, a canal: Panama\".",
            codeLine: 4,
          });

          const view = (override, markEnds = true) => {
            const st = chars.map((_, i) => (i < lo || i > hi ? "dim" : "idle"));
            if (markEnds) {
              if (lo < hi) { st[lo] = "read"; st[hi] = "read"; }
              else if (lo === hi && lo >= 0 && lo < n) st[lo] = "read";
            }
            Object.assign(st, override || {});
            return st;
          };

          let lo = 0, hi = n - 1, compared = 0, skipped = 0;
          while (lo < hi) {
            if (!isAlnum(chars[lo])) {
              skipped++;
              const at = lo;
              lo++;
              steps.push({
                title: `Skip '${chars[at]}' at the left`,
                tracks: [track("the text", chars, view({ [at]: "dim" }))],
                pointers: lo < hi ? [{ index: lo, label: "L" }, { index: hi, label: "R" }] : [{ index: hi, label: "R" }],
                counters: [count("compared", compared), count("skipped", skipped)],
                happened: `'${chars[at]}' is not a letter or digit, so the left pointer simply walks past it to index ${lo}.`,
                why: "Punctuation carries no meaning for a phrase palindrome, so it must not take part in a comparison.",
                codeLine: 7,
              });
              continue;
            }
            if (!isAlnum(chars[hi])) {
              skipped++;
              const at = hi;
              hi--;
              steps.push({
                title: `Skip '${chars[at]}' at the right`,
                tracks: [track("the text", chars, view({ [at]: "dim" }))],
                pointers: lo < hi ? [{ index: lo, label: "L" }, { index: hi, label: "R" }] : [{ index: lo, label: "L" }],
                counters: [count("compared", compared), count("skipped", skipped)],
                happened: `'${chars[at]}' is not a letter or digit, so the right pointer steps back to index ${hi}.`,
                why: "The same skip rule applies at both ends, keeping the pointers on meaningful characters.",
                codeLine: 8,
              });
              continue;
            }
            compared++;
            const same = lower(chars[lo]) === lower(chars[hi]);
            const l = lo, r = hi;
            lo++; hi--;
            steps.push({
              title: same
                ? `'${chars[l]}' matches '${chars[r]}' ✓`
                : `'${chars[l]}' ≠ '${chars[r]}' ✗`,
              tracks: [track("the text", chars, view({ [l]: same ? "good" : "bad", [r]: same ? "good" : "bad" }, false))],
              pointers: [{ index: l, label: "L" }, { index: r, label: "R" }],
              counters: [count("compared", compared), count("skipped", skipped)],
              happened: same
                ? `Both ends show the same letter (${lower(chars[l])}) once case is ignored, so the pointers move inwards.`
                : `The left end shows '${chars[l]}' but the right end shows '${chars[r]}' — the text does not mirror.`,
              why: same
                ? "Each matching pair peels one layer off both ends; the untouched middle is the only part left to check."
                : "A single mismatched pair is conclusive, so the walk can stop right here.",
              codeLine: same ? 9 : 10,
            });
            if (!same) {
              steps.push({
                title: "Answer: not a palindrome",
                tracks: [
                  track("the text", chars, chars.map((_, i) => (i === l || i === r ? "bad" : "dim"))),
                  { label: "answer", cells: [{ v: "no", state: "result" }] },
                ],
                pointers: [{ index: l, label: "L" }, { index: r, label: "R" }],
                counters: [count("compared", compared), count("skipped", skipped), count("answer", "no")],
                legend: ["bad", "dim", "result"],
                happened: `The pointers disagreed at indexes ${l} and ${r}, so the text reads differently from the two ends.`,
                why: "No amount of skipping or lower-casing can repair a real character mismatch.",
                codeLine: 10,
              });
              return steps;
            }
          }

          steps.push({
            title: "Answer: it is a palindrome",
            tracks: [
              track("the text", chars, chars.map((_, i) => (isAlnum(chars[i]) ? "good" : "dim"))),
              { label: "answer", cells: [{ v: "yes", state: "result" }] },
            ],
            counters: [count("compared", compared), count("skipped", skipped), count("answer", "yes")],
            legend: ["good", "dim", "result"],
            happened: compared
              ? `The pointers met after ${compared} matching pair${compared === 1 ? "" : "s"} and ${skipped} skipped character${skipped === 1 ? "" : "s"}.`
              : "Every character was punctuation or a space, so the meaningful text is empty — an empty text counts as a palindrome.",
            why: "Two pointers from the ends visit each character at most once, using no extra memory at all.",
            codeLine: 13,
          });
          return steps;
        },
      },
      {
        name: "Clean First, Then Compare",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Build a fresh copy of the text containing only letters and digits, all turned to lower case.",
          "Then compare the cleaned copy with itself from both ends: position i against position n-1-i.",
          "This separates the two jobs — filtering and comparing — so each part is simple to follow.",
        ],
        problem: [
          "The cleaned copy costs extra memory proportional to the text, where the two-pointer version needed none. It is easier to write and to debug, though.",
        ],
        code: {
          c: `#include <stdio.h>
#include <ctype.h>

int is_palindrome_clean(const char *s) {
    char clean[256];
    int n = 0;
    for (int i = 0; s[i]; i++)
        if (isalnum((unsigned char)s[i]))
            clean[n++] = (char)tolower((unsigned char)s[i]);
    for (int i = 0; i < n / 2; i++)
        if (clean[i] != clean[n - 1 - i]) return 0;
    return 1;
}

int main(void) {
    printf("%d\\n", is_palindrome_clean("A man, a plan, a canal: Panama")); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <cctype>

// Build a cleaned, lower-cased copy, then compare its two ends.
bool isPalindromeClean(const std::string& s) {
    std::string clean;
    for (unsigned char c : s)
        if (std::isalnum(c)) clean += (char)std::tolower(c);
    int n = (int)clean.size();
    for (int i = 0; i < n / 2; i++)
        if (clean[i] != clean[n - 1 - i]) return false;
    return true;
}

int main() {
    std::cout << isPalindromeClean("A man, a plan, a canal: Panama") << '\\n'; // 1
    std::cout << isPalindromeClean("hello") << '\\n';                          // 0
}`,
        },
        steps(str) {
          const chars = toArr(String(str));
          const n = chars.length;
          const clean = [];
          const steps = [];

          steps.push({
            title: "Plan: clean the text, then check its ends",
            tracks: [track("the text", chars, fill(n, "idle"))],
            counters: [count("characters", n), count("kept", 0)],
            legend: ["read", "done", "result", "good", "bad", "dim"],
            happened: `The text has ${n} character${n === 1 ? "" : "s"}. We will keep only letters and digits, in lower case.`,
            why: "Once the noise is gone, checking a palindrome is just comparing the first character with the last, the second with the second-last, and so on.",
            codeLine: 3,
          });

          for (let i = 0; i < n; i++) {
            const keep = isAlnum(chars[i]);
            if (keep) clean.push(lower(chars[i]));
            const states = chars.map((_, k) => (k < i ? "done" : k === i ? (keep ? "read" : "dim") : "idle"));
            steps.push({
              title: keep ? `Keep '${chars[i]}' → '${lower(chars[i])}'` : `Drop '${chars[i]}'`,
              tracks: [
                track("the text", chars, states),
                clean.length
                  ? track("cleaned copy", clean, fill(clean.length, keep ? "result" : "done"))
                  : [{ label: "cleaned copy", cells: [{ v: "∅", state: "idle", empty: true }] }],
              ],
              counters: [count("characters read", i + 1, n), count("kept", clean.length)],
              happened: keep
                ? `'${chars[i]}' is a letter or digit, so a lower-cased copy joins the cleaned text.`
                : `'${chars[i]}' is not a letter or digit, so it is left out of the cleaned text.`,
              why: keep
                ? "Only meaningful characters decide whether the text mirrors itself."
                : "Dropping the noise now means the comparison step needs no skip tests at all.",
              codeLine: keep ? 7 : 6,
            });
          }

          const m = clean.length;
          steps.push({
            title: m ? `Cleaned text: "${clean.join("")}"` : "Cleaned text is empty",
            tracks: [track("cleaned copy", clean, fill(m, "idle"))],
            counters: [count("kept", m), count("pairs to check", Math.floor(m / 2))],
            happened: m
              ? `Filtering left ${m} character${m === 1 ? "" : "s"}: "${clean.join("")}".`
              : "Nothing survived the filter, so the meaningful text is empty.",
            why: "An empty or single-character cleaned text mirrors trivially and is a palindrome.",
            codeLine: 6,
          });

          for (let i = 0; i < Math.floor(m / 2); i++) {
            const j = m - 1 - i;
            const same = clean[i] === clean[j];
            steps.push({
              title: same
                ? `'${clean[i]}' = '${clean[j]}' (positions ${i} and ${j}) ✓`
                : `'${clean[i]}' ≠ '${clean[j]}' (positions ${i} and ${j}) ✗`,
              tracks: [track("cleaned copy", clean, clean.map((_, k) => (k < i || k > j ? "done" : (k === i || k === j) ? (same ? "good" : "bad") : "idle")))],
              pointers: [{ index: i, label: "L" }, { index: j, label: "R" }],
              counters: [count("pairs checked", i + 1, Math.floor(m / 2))],
              happened: same
                ? `Position ${i} and its mirror position ${j} hold the same character.`
                : `Position ${i} holds '${clean[i]}' but its mirror position ${j} holds '${clean[j]}'.`,
              why: same
                ? "Matching mirror pairs keep the palindrome promise alive; only the middle remains."
                : "A mirror pair that differs proves the cleaned text is not symmetric.",
              codeLine: same ? 9 : 10,
            });
            if (!same) {
              steps.push({
                title: "Answer: not a palindrome",
                tracks: [
                  track("cleaned copy", clean, clean.map((_, k) => (k === i || k === j ? "bad" : "dim"))),
                  { label: "answer", cells: [{ v: "no", state: "result" }] },
                ],
                pointers: [{ index: i, label: "L" }, { index: j, label: "R" }],
                counters: [count("pairs checked", i + 1, Math.floor(m / 2)), count("answer", "no")],
                legend: ["bad", "dim", "result"],
                happened: `The cleaned text fails at mirror positions ${i} and ${j}.`,
                why: "Because the cleaned text keeps only meaningful characters, a mismatch here is final.",
                codeLine: 10,
              });
              return steps;
            }
          }

          steps.push({
            title: "Answer: it is a palindrome",
            tracks: [
              track("cleaned copy", clean, fill(m, "good")),
              { label: "answer", cells: [{ v: "yes", state: "result" }] },
            ],
            counters: [count("pairs checked", Math.floor(m / 2), Math.floor(m / 2)), count("answer", "yes")],
            legend: ["good", "result", "idle"],
            happened: m
              ? `All ${Math.floor(m / 2)} mirror pair${Math.floor(m / 2) === 1 ? "" : "s"} of "${clean.join("")}" matched.`
              : "The cleaned text was empty, which reads the same in both directions.",
            why: "Filtering first made the symmetry test a plain loop over mirrored indexes.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "longest-common-prefix",
    title: "Longest Common Prefix",
    category: "Strings & Text",
    difficulty: "Beginner",
    description: "Find the longest starting run of letters that every word shares.",
    input: { label: "Words", default: "flower flow flight", parse: "words" },
    approaches: [
      {
        name: "Shrink the First Word",
        complexity: "O(n · k) time, O(1) extra space",
        idea: [
          "Borrow the first word as a guess at the answer. Compare it with the second word; while it is not a prefix of that word, chop off its last letter.",
          "Repeat with every remaining word. The guess only ever gets shorter, so once it survives all the words it is the longest common prefix.",
          "If it is ever chopped to nothing, then no letter is shared by all of the words.",
        ],
        problem: [
          "Each chop rechecks the guess from the start, so a word that disagrees late can force several wasted comparisons.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

/* Trim the first word down until it fits every other word. */
char *common_prefix(char **words, int n, char *buf) {
    strcpy(buf, words[0]);
    for (int i = 1; i < n; i++) {
        while (strlen(buf) && strncmp(buf, words[i], strlen(buf)) != 0)
            buf[strlen(buf) - 1] = '\\0';   /* drop the last letter */
    }
    return buf;
}

int main(void) {
    char *words[] = {"flower", "flow", "flight"};
    char buf[64];
    printf("[%s]\\n", common_prefix(words, 3, buf)); /* [fl] */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <string>

// Trim the running prefix until it matches the start of every word.
std::string longestCommonPrefix(std::vector<std::string> words) {
    if (words.empty()) return "";
    std::string prefix = words[0];
    for (size_t i = 1; i < words.size(); i++)
        while (!prefix.empty() && words[i].compare(0, prefix.size(), prefix) != 0)
            prefix.pop_back();
    return prefix;
}

int main() {
    std::cout << '[' << longestCommonPrefix({"flower", "flow", "flight"}) << "]\\n"; // [fl]
}`,
        },
        steps(words) {
          const W = Array.isArray(words) ? words.map(String) : [];
          if (!W.length) {
            return [{
              title: "No words to compare",
              tracks: [track("words", ["—"], ["idle"])],
              counters: [count("words", 0)],
              legend: ["read", "done", "good", "idle"],
              happened: "The input held no words.",
              why: "Type a few words separated by spaces and press Run.",
            }];
          }

          const steps = [];
          let prefix = W[0];
          const wordStates = (active) => W.map((_, k) => (k < active ? "done" : k === active ? "read" : "idle"));
          const prefixTrack = () => prefix.length
            ? [{ label: "current prefix", cells: toArr(prefix).map((c) => ({ v: c, state: "result" })) }]
            : [{ label: "current prefix", cells: [{ v: "∅", state: "idle", empty: true }] }];

          steps.push({
            title: `Start the guess with the first word "${W[0]}"`,
            tracks: [track("words", W, W.map((_, k) => (k === 0 ? "read" : "idle"))), ...prefixTrack()],
            counters: [count("words", W.length), count("guess length", prefix.length)],
            legend: ["read", "done", "good", "idle"],
            happened: `There are ${W.length} word${W.length === 1 ? "" : "s"}. The guess begins as the whole first word, "${prefix}".`,
            why: "A common prefix can never be longer than the first word, so starting from it is a safe upper bound.",
            codeLine: 5,
          });

          if (W.length === 1) {
            steps.push({
              title: `Answer: the prefix is "${prefix}"`,
              tracks: [
                track("words", W, fill(1, "good")),
                ...prefixTrack(),
                { label: "answer", cells: [{ v: prefix || "(none)", state: "result" }] },
              ],
              counters: [count("words", 1), count("answer", prefix)],
              legend: ["good", "result", "idle"],
              happened: `With only one word, the whole word "${prefix}" is trivially common to every word.`,
              why: "There are no other words that could disagree, so the guess survives untouched.",
              codeLine: 5,
            });
            return steps;
          }

          for (let i = 1; i < W.length; i++) {
            const w = W[i];
            let m = 0;
            while (m < prefix.length && m < w.length && lower(prefix[m]) === lower(w[m])) m++;
            steps.push({
              title: `Compare guess "${prefix}" with "${w}"`,
              tracks: [
                track("words", W, wordStates(i)),
                { label: "current prefix", cells: toArr(prefix).map((c, ci) => ({ v: c, state: ci < m ? "good" : "idle" })) },
              ],
              counters: [count("words compared", i, W.length - 1), count("guess length", prefix.length)],
              happened: m === prefix.length
                ? `"${w}" begins with the whole guess "${prefix}", so nothing has to change.`
                : `Only the first ${m} letter${m === 1 ? "" : "s"} of the guess match "${w}" — the guess is too long.`,
              why: "A prefix is only valid if every word starts with it, so the first word that disagrees forces a shorter guess.",
              codeLine: 7,
            });
            while (prefix.length > m) {
              const dropped = prefix[prefix.length - 1];
              prefix = prefix.slice(0, -1);
              steps.push({
                title: prefix
                  ? `Drop '${dropped}' → guess is now "${prefix}"`
                  : `Drop '${dropped}' → the guess is empty`,
                tracks: [
                  track("words", W, wordStates(i)),
                  ...prefixTrack(),
                ],
                counters: [count("words compared", i, W.length - 1), count("guess length", prefix.length)],
                happened: prefix
                  ? `The last letter '${dropped}' is removed because "${w}" does not have it at that position.`
                  : `Removing '${dropped}' leaves nothing, so no letter is common to all of the words.`,
                why: "Chopping one letter at a time keeps the guess as long as possible while still fitting the word we just checked.",
                codeLine: 8,
              });
            }
          }

          steps.push({
            title: prefix ? `Answer: the common prefix is "${prefix}"` : "Answer: no common prefix",
            tracks: [
              track("words", W, fill(W.length, "done")),
              prefix.length
                ? { label: "common prefix", cells: toArr(prefix).map((c) => ({ v: c, state: "result" })) }
                : [{ label: "common prefix", cells: [{ v: "∅", state: "idle", empty: true }] }],
              { label: "answer", cells: [{ v: prefix || "(none)", state: "result" }] },
            ],
            counters: [count("words compared", W.length - 1), count("answer", prefix || "(none)")],
            legend: ["done", "result", "idle"],
            happened: prefix
              ? `After checking every word, the guess "${prefix}" still matches the start of all of them.`
              : "The guess was reduced to nothing, so the words share no starting letter.",
            why: "Because the guess only shrank when a word forced it, what remains is the longest shared beginning.",
            codeLine: 5,
          });
          return steps;
        },
      },
      {
        name: "Scan Down the Columns",
        complexity: "O(n · k) time, O(1) extra space",
        idea: [
          "Line the words up and look at one column of letters at a time: position 0 of every word, then position 1, and so on.",
          "A column survives only if every word shows the same letter there. The prefix grows by one letter for each surviving column.",
          "The first column that disagrees, or the first word that runs out of letters, ends the prefix. Whatever was collected so far is the answer.",
        ],
        problem: [
          "The scan must stop at the shortest word, otherwise it would look past the end of a word; checking each column against every word costs the same O(n · k) as shrinking, just from a different direction.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

/* Read down column after column until one column disagrees. */
int common_prefix_len(char **words, int n) {
    for (int col = 0; ; col++) {
        char c = words[0][col];
        if (c == '\\0') return col;
        for (int i = 1; i < n; i++)
            if (col >= (int)strlen(words[i]) || words[i][col] != c)
                return col;
    }
}

int main(void) {
    char *words[] = {"flower", "flow", "flight"};
    int len = common_prefix_len(words, 3);
    printf("[%.*s]\\n", len, words[0]); /* [fl] */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <string>

// Scan down columns; stop at the first column where the words disagree.
std::string longestCommonPrefix(const std::vector<std::string>& words) {
    if (words.empty() || words[0].empty()) return "";
    for (size_t col = 0; col < words[0].size(); col++) {
        char c = words[0][col];
        for (size_t i = 1; i < words.size(); i++)
            if (col >= words[i].size() || words[i][col] != c)
                return words[0].substr(0, col);
    }
    return words[0];
}

int main() {
    std::cout << '[' << longestCommonPrefix({"flower", "flow", "flight"}) << "]\\n"; // [fl]
}`,
        },
        steps(words) {
          const W = Array.isArray(words) ? words.map(String) : [];
          if (!W.length) {
            return [{
              title: "No words to compare",
              tracks: [track("words", ["—"], ["idle"])],
              counters: [count("words", 0)],
              legend: ["read", "good", "bad", "idle"],
              happened: "The input held no words.",
              why: "Type a few words separated by spaces and press Run.",
            }];
          }

          const minLen = Math.min(...W.map((w) => w.length));
          const steps = [];
          let col = 0;
          let stopped = false;

          steps.push({
            title: "Read the words column by column",
            tracks: [track("words", W, fill(W.length, "idle"))],
            counters: [count("words", W.length), count("columns to check", minLen)],
            legend: ["read", "good", "bad", "done"],
            happened: `The words are ${W.join(", ")}. The shortest has ${minLen} letter${minLen === 1 ? "" : "s"}, so there are at most ${minLen} columns to examine.`,
            why: "Common letters must appear at the same position in every word, so reading straight down each column is a natural test.",
            codeLine: 5,
          });

          for (col = 0; col < minLen; col++) {
            const c = W[0][col];
            let broke = false;
            for (let j = 1; j < W.length; j++) {
              const cj = W[j][col];
              const match = lower(cj) === lower(c);
              steps.push({
                title: match
                  ? `column ${col}: '${cj}' matches '${c}' ✓`
                  : `column ${col}: '${cj}' ≠ '${c}' ✗`,
                tracks: [track("words", W, W.map((w, jj) => {
                  if (jj > j) return "idle";
                  const same = lower(w[col]) === lower(c);
                  return same ? "good" : "bad";
                }))],
                counters: [count("column", col), count("words checked", j + 1, W.length)],
                happened: match
                  ? `Word ${j + 1} "${W[j]}" shows '${cj}' in column ${col}, the same as the reference '${c}'.`
                  : `Word ${j + 1} "${W[j]}" shows '${cj}' in column ${col}, which differs from the reference '${c}'.`,
                why: match
                  ? "A column only becomes part of the prefix if every word agrees at that position."
                  : "One disagreeing word breaks the column, so no longer prefix can start here.",
                codeLine: 9,
              });
              if (!match) { broke = true; stopped = true; break; }
            }
            if (broke) break;
            steps.push({
              title: `column ${col} agrees everywhere — keep '${c}'`,
              tracks: [track("words", W, W.map((w) => (lower(w[col]) === lower(c) ? "good" : "bad")))],
              counters: [count("columns kept", col + 1), count("prefix length", col + 1)],
              happened: `All ${W.length} words carry '${c}' at position ${col}, so it joins the prefix.`,
              why: "Keeping one agreed column extends the answer by exactly one letter.",
              codeLine: 6,
            });
          }

          const prefix = W[0].slice(0, col);
          steps.push({
            title: prefix ? `Answer: the common prefix is "${prefix}"` : "Answer: no common prefix",
            tracks: [
              track("words", W, fill(W.length, "done")),
              prefix.length
                ? { label: "common prefix", cells: toArr(prefix).map((ch) => ({ v: ch, state: "result" })) }
                : [{ label: "common prefix", cells: [{ v: "∅", state: "idle", empty: true }] }],
              { label: "answer", cells: [{ v: prefix || "(none)", state: "result" }] },
            ],
            counters: [count("columns kept", col), count("answer", prefix || "(none)")],
            legend: ["done", "result", "idle"],
            happened: prefix
              ? `The scan ${stopped ? "stopped" : "ran out of words"} after ${col} agreed column${col === 1 ? "" : "s"}, giving "${prefix}".`
              : "The very first column already disagreed, or a word was empty, so there is no shared starting letter.",
            why: "Each agreed column adds one letter, and the first disagreement caps the answer, so this is exactly the longest prefix.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "reverse-words-in-a-string",
    title: "Reverse Words in a String",
    category: "Strings & Text",
    difficulty: "Beginner",
    description: "Flip the order of the words while keeping each word itself readable.",
    input: { label: "The sentence", default: "the sky is blue", parse: "string" },
    approaches: [
      {
        name: "Split, Reverse, Rejoin",
        complexity: "O(n) time, O(n) extra space",
        idea: [
          "Cut the text on whitespace into a list of words. Any number of spaces counts as one separator, and empty pieces are thrown away.",
          "Read the word list from the end into a fresh output list — that is the reversal, done for free by the order we append in.",
          "Join the output with single spaces to get the answer.",
        ],
        problem: [
          "The split and the output list each need their own storage, so this uses memory proportional to the text. The in-place approach avoids that but is harder to follow.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

/* Split on spaces, then print the words back to front. */
int main(void) {
    char text[] = "the sky is blue";
    char *words[64];
    int n = 0;
    for (char *tok = strtok(text, " "); tok; tok = strtok(NULL, " "))
        words[n++] = tok;
    for (int i = n - 1; i >= 0; i--)
        printf("%s%s", words[i], i ? " " : "\\n"); /* blue is sky the */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <sstream>
#include <vector>

// Split on whitespace, then read the words back in reverse.
std::string reverseWords(const std::string& s) {
    std::istringstream in(s);
    std::vector<std::string> words;
    std::string w;
    while (in >> w) words.push_back(w);
    std::string out;
    for (int i = (int)words.size() - 1; i >= 0; i--) {
        if (!out.empty()) out += ' ';
        out += words[i];
    }
    return out;
}

int main() {
    std::cout << '[' << reverseWords("the sky is blue") << "]\\n"; // [blue is sky the]
}`,
        },
        steps(str) {
          const raw = String(str);
          const words = raw.split(/\s+/).filter(Boolean);
          const steps = [];

          if (!words.length) {
            const blank = toArr(raw);
            return [{
              title: "Nothing but spaces — nothing to reverse",
              tracks: [track("the text", blank.length ? blank : ["—"], fill(blank.length || 1, "idle"))],
              counters: [count("words found", 0)],
              legend: ["read", "done", "result", "idle"],
              happened: `The text is only whitespace, so splitting finds no words at all.`,
              why: "Word-splitting first means empty input becomes an empty answer instead of a crash.",
            }];
          }

          steps.push({
            title: `The text: "${raw}"`,
            tracks: [track("words in order", words, fill(words.length, "idle"))],
            counters: [count("words found", words.length)],
            legend: ["read", "done", "result", "dim"],
            happened: `Splitting on spaces finds ${words.length} word${words.length === 1 ? "" : "s"}: ${words.join(", ")}. Runs of spaces collapse into one separator.`,
            why: "Words, not characters, are the things that change places here, so the text becomes a list of words first.",
            codeLine: 6,
          });

          const out = [];
          for (let i = 0; i < words.length; i++) {
            const taken = words[words.length - 1 - i];
            out.push(taken);
            steps.push({
              title: `Take "${taken}" → position ${i}`,
              tracks: [
                track("words in order", words, words.map((_, k) => (k >= words.length - out.length ? "dim" : "idle"))),
                track("reversed order", out, out.map((_, k) => (k === i ? "read" : "done"))),
              ],
              counters: [count("words moved", i + 1, words.length), count("words left", words.length - out.length)],
              happened: `"${taken}" is picked from the end of the remaining words and lands at output position ${i}.`,
              why: "Reading the list from the back while writing forwards reverses it in a single sweep.",
              codeLine: 9,
            });
          }

          steps.push({
            title: `Answer: "${out.join(" ")}"`,
            tracks: [
              track("words in order", words, fill(words.length, "dim")),
              track("reversed order", out, fill(out.length, "result")),
            ],
            counters: [count("words moved", out.length, words.length), count("answer", out.join(" "))],
            happened: `Joined with single spaces, the words read ${out.join(" ")}.`,
            why: "The words kept their spelling — only their order was flipped, and the extra spaces were removed by the join.",
            codeLine: 9,
          });
          return steps;
        },
      },
      {
        name: "Reverse All, Then Each Word",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "Normalise the spaces first, so words are separated by exactly one space. Then treat the text as a plain array of characters.",
          "Reverse the whole array once. Every letter ends up in its mirror position, which also puts the words in reverse order — but each word is spelled backwards.",
          "Reverse each word in place. That restores the spelling while the word order stays flipped.",
        ],
        problem: [
          "Two passes of character swapping are needed, and the routine assumes single spaces between words, so a cleanup pass must run beforehand.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

static void reverse_range(char *s, int lo, int hi) {
    while (lo < hi) {
        char t = s[lo]; s[lo++] = s[hi]; s[hi--] = t;
    }
}

/* Reverse the whole string, then reverse every word back. */
void reverse_words(char *s) {
    int n = (int)strlen(s);
    reverse_range(s, 0, n - 1);
    for (int i = 0; i < n; ) {
        int j = i;
        while (j < n && s[j] != ' ') j++;
        reverse_range(s, i, j - 1);
        i = j + 1;
    }
}

int main(void) {
    char s[] = "the sky is blue";
    reverse_words(s);
    printf("[%s]\\n", s); /* [blue is sky the] */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <algorithm>

// Phase 1: flip the whole string. Phase 2: flip every word back.
void reverseWords(std::string& s) {
    std::reverse(s.begin(), s.end());
    size_t i = 0;
    while (i < s.size()) {
        size_t j = i;
        while (j < s.size() && s[j] != ' ') j++;
        std::reverse(s.begin() + i, s.begin() + j);
        i = j + 1;
    }
}

int main() {
    std::string s = "the sky is blue";
    reverseWords(s);
    std::cout << '[' << s << "]\\n"; // [blue is sky the]
}`,
        },
        steps(str) {
          const normalised = String(str).trim().replace(/\s+/g, " ");
          const arr = toArr(normalised);
          const n = arr.length;
          const steps = [];

          if (!n) {
            return [{
              title: "Nothing but spaces — nothing to reverse",
              tracks: [track("characters", ["—"], ["idle"])],
              counters: [count("characters", 0)],
              legend: ["swap", "done", "result", "idle"],
              happened: "After trimming and collapsing spaces, the text is empty.",
              why: "The cleanup pass runs before any swapping, so blank input simply produces an empty answer.",
            }];
          }

          steps.push({
            title: `Work on ${n} characters with single spaces`,
            tracks: [track("characters", arr, fill(n, "idle"))],
            counters: [count("characters", n)],
            legend: ["swap", "done", "result", "idle"],
            happened: `The text normalises to "${normalised}". Extra spaces have been collapsed so words are cleanly separated.`,
            why: "The in-place method relies on a single space being the only separator; cleaning first makes that safe.",
            codeLine: 11,
          });

          let lo = 0, hi = n - 1, swaps = 0;
          while (lo < hi) {
            const a = arr[lo], b = arr[hi];
            swaps++;
            steps.push({
              title: `Swap '${a}' ⇄ '${b}'`,
              tracks: [track("characters", arr, arr.map((_, i) => (i === lo || i === hi ? "swap" : (i < lo || i > hi ? "done" : "idle"))))],
              counters: [count("left pointer", lo), count("right pointer", hi), count("swaps", swaps, Math.floor(n / 2))],
              happened: `Characters ${lo} and ${hi} trade places, so the string creeps towards its mirror image.`,
              why: "Each outer pair is swapped once and never visited again; the untouched middle shrinks by two every round.",
              codeLine: 5,
            });
            [arr[lo], arr[hi]] = [arr[hi], arr[lo]];
            lo++; hi--;
          }

          steps.push({
            title: "Whole string reversed",
            tracks: [track("characters", arr, fill(n, "done"))],
            counters: [count("swaps", swaps, Math.floor(n / 2)), count("characters", n)],
            happened: `The string now reads "${arr.join("")}" — every word is backwards and the words themselves are in reverse order.`,
            why: "One global reversal quietly does both jobs at once, but leaves each word spelled wrongly.",
            codeLine: 11,
          });

          let i = 0, wordNo = 0;
          while (i < n) {
            let j = i;
            while (j < n && arr[j] !== " ") j++;
            let a = i, b = j - 1;
            while (a < b) {
              [arr[a], arr[b]] = [arr[b], arr[a]];
              a++; b--;
            }
            wordNo++;
            const word = arr.slice(i, j).join("");
            steps.push({
              title: `Reverse word ${wordNo} → "${word}"`,
              tracks: [track("characters", arr, arr.map((_, k) => (k >= i && k < j ? "result" : "done")))],
              counters: [count("words fixed", wordNo), count("characters", n)],
              happened: `The letters between ${i} and ${j - 1} are flipped back, spelling "${word}" the right way round.`,
              why: "Fixing each word inside the already-reversed string keeps the new word order while restoring normal spelling.",
              codeLine: 16,
            });
            i = j + 1;
          }

          steps.push({
            title: `Answer: "${arr.join("")}"`,
            tracks: [track("characters", arr, fill(n, "result"))],
            counters: [count("swaps", swaps), count("words fixed", wordNo), count("answer", arr.join(""))],
            happened: `After one whole-string reversal and ${wordNo} word reversal${wordNo === 1 ? "" : "s"}, the text reads ${arr.join("")}.`,
            why: "Everything happened in place — no word list or output buffer was ever allocated.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "string-compression",
    title: "String Compression",
    category: "Strings & Text",
    difficulty: "Intermediate",
    description: "Replace runs of repeated characters with the character and its count.",
    input: { label: "The text", default: "aaabbbcccd", parse: "string" },
    approaches: [
      {
        name: "Flush When the Run Ends",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "Walk the characters once, keeping a counter for the current run. As long as the next character equals the current one, the counter grows.",
          "The moment the next character differs — or the text runs out — the run is finished: write the letter, then write the counter if it is greater than 1.",
          "A run of one is written as just the letter, so \"aab\" compresses to \"a2b\" rather than \"a2b1\".",
        ],
        problem: [
          "The rule writes counts as decimal digits, so a run of twelve copies adds two characters to the output. Short runs of length 10 or 11 can actually make the result longer than the input.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

/* Run-length form: "aaabbbcccd" -> "a3b3c3d". */
int compress(const char *s, char *out) {
    int n = (int)strlen(s), k = 0, run = 0;
    for (int i = 0; i < n; i++) {
        run++;
        if (i + 1 == n || s[i] != s[i + 1]) {  /* the run just ended */
            out[k++] = s[i];
            if (run > 1) k += sprintf(out + k, "%d", run);
            run = 0;
        }
    }
    out[k] = '\\0';
    return k;
}

int main(void) {
    char out[256];
    compress("aaabbbcccd", out);
    printf("[%s]\\n", out); /* [a3b3c3d] */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>

// One pass: count the current run and flush it when the letter changes.
std::string compress(const std::string& s) {
    std::string out;
    int run = 0;
    for (size_t i = 0; i < s.size(); i++) {
        run++;
        if (i + 1 == s.size() || s[i] != s[i + 1]) {
            out += s[i];
            if (run > 1) out += std::to_string(run);
            run = 0;
        }
    }
    return out;
}

int main() {
    std::cout << '[' << compress("aaabbbcccd") << "]\\n"; // [a3b3c3d]
}`,
        },
        steps(str) {
          const chars = toArr(String(str));
          const n = chars.length;
          const out = [];
          const steps = [];
          const outTrack = () => ({
            label: "compressed output",
            cells: out.length
              ? out.map((o, idx) => ({
                  v: o.ch,
                  state: idx === out.length - 1 ? "result" : "done",
                  tag: o.run > 1 ? `×${o.run}` : undefined,
                }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          steps.push({
            title: `${n} character${n === 1 ? "" : "s"} to compress`,
            tracks: [track("the text", chars, fill(n, "idle")), outTrack()],
            counters: [count("characters read", 0, n), count("runs written", 0)],
            legend: ["read", "done", "result", "idle"],
            happened: `The text is "${normalise(chars)}". Runs of the same character will be replaced by the letter plus its length.`,
            why: "Repetition is what the output exploits, so the walk only has to notice where one run stops and the next starts.",
            codeLine: 4,
          });

          let run = 0;
          for (let i = 0; i < n; i++) {
            run++;
            const ends = i + 1 === n || chars[i] !== chars[i + 1];
            const states = chars.map((_, k) => (k < i ? "done" : k === i ? "read" : "idle"));
            if (!ends) {
              steps.push({
                title: `'${chars[i]}' repeats — run grows to ${run}`,
                tracks: [track("the text", chars, states), outTrack()],
                counters: [count("characters read", i + 1, n), count("runs written", out.length)],
                happened: `Character ${i} is the same as the one before it, so the current run of '${chars[i]}' now covers ${run} copies.`,
                why: "While the next letter matches, nothing can be written yet — the count is still growing.",
                codeLine: 6,
              });
            } else {
              out.push({ ch: chars[i], run });
              run = 0;
              steps.push({
                title: `Run ends → write '${out[out.length - 1].ch}'${out[out.length - 1].run > 1 ? out[out.length - 1].run : ""}`,
                tracks: [track("the text", chars, states), outTrack()],
                counters: [count("characters read", i + 1, n), count("runs written", out.length)],
                happened: out[out.length - 1].run > 1
                  ? `The next character differs (or the text ended), so the run of ${out[out.length - 1].run} '${out[out.length - 1].ch}' is written as '${out[out.length - 1].ch}${out[out.length - 1].run}'.`
                  : `A single '${out[out.length - 1].ch}' has no repetition to report, so just the letter is written.`,
                why: "Flushing at every change is what keeps the output one compact pass behind the input.",
                codeLine: 7,
              });
            }
          }

          const compressed = out.map((o) => o.ch + (o.run > 1 ? o.run : "")).join("");
          steps.push({
            title: `Answer: "${compressed}"`,
            tracks: [
              track("the text", chars, fill(n, "dim")),
              { label: "compressed output", cells: toArr(compressed).map((ch) => ({ v: ch, state: "result" })) },
            ],
            counters: [count("characters read", n, n), count("runs written", out.length), count("answer", compressed)],
            happened: `The ${out.length} run${out.length === 1 ? "" : "s"} of the input compress to "${compressed}"${compressed.length < n ? `, saving ${n - compressed.length} character${n - compressed.length === 1 ? "" : "s"}` : `, which is no shorter than the original ${n} characters`}.`,
            why: "One pass over the input produced the whole encoding, and only the current run count was ever held in memory.",
            codeLine: 9,
          });
          return steps;
        },
      },
      {
        name: "Hop a Pointer to the End of Each Run",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "Keep two pointers. The first marks the start of a run; the second scans forward for as long as it sees the same character.",
          "When the second pointer finally stops, the distance between the two is the run length: write the letter, write the length if it is above 1, then jump the first pointer to the second and start again.",
          "The jump means each run costs one step rather than one step per character.",
        ],
        problem: [
          "Same output rule as before, so very short runs of length 10 or 11 can still bloat the result; the pointer juggling also makes the loop boundaries easy to get subtly wrong.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

/* Hop a read pointer to the end of each run. */
int compress_hop(const char *s, char *out) {
    int n = (int)strlen(s), k = 0, i = 0;
    while (i < n) {
        int j = i;
        while (j < n && s[j] == s[i]) j++;  /* j stops at the next new letter */
        out[k++] = s[i];
        if (j - i > 1) k += sprintf(out + k, "%d", j - i);
        i = j;
    }
    out[k] = '\\0';
    return k;
}

int main(void) {
    char out[256];
    compress_hop("aaabbbcccd", out);
    printf("[%s]\\n", out); /* [a3b3c3d] */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>

// Hop a read pointer to the end of each run, then emit letter + length.
std::string compressHop(const std::string& s) {
    std::string out;
    size_t i = 0;
    while (i < s.size()) {
        size_t j = i;
        while (j < s.size() && s[j] == s[i]) j++;
        out += s[i];
        if (j - i > 1) out += std::to_string(j - i);
        i = j;
    }
    return out;
}

int main() {
    std::cout << '[' << compressHop("aaabbbcccd") << "]\\n"; // [a3b3c3d]
}`,
        },
        steps(str) {
          const chars = toArr(String(str));
          const n = chars.length;
          const out = [];
          const steps = [];
          const outTrack = () => ({
            label: "compressed output",
            cells: out.length
              ? out.map((o, idx) => ({
                  v: o.ch,
                  state: idx === out.length - 1 ? "result" : "done",
                  tag: o.run > 1 ? `×${o.run}` : undefined,
                }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          steps.push({
            title: "Two pointers: one at the run start, one scanning ahead",
            tracks: [track("the text", chars, chars.map((_, i) => (i === 0 ? "read" : "idle"))), outTrack()],
            counters: [count("characters read", 0, n), count("runs written", 0)],
            legend: ["read", "done", "result", "idle"],
            happened: `The text is "${normalise(chars)}". The first pointer sits at index 0, ready to hunt for a run of the same letter.`,
            why: "Scanning ahead lets a whole run be measured in one sweep instead of tracking a counter across iterations.",
            codeLine: 4,
          });

          let i = 0;
          while (i < n) {
            const ch = chars[i];
            let j = i + 1;
            while (j < n && chars[j] === ch) {
              steps.push({
                title: `char ${j} is '${ch}' too — run so far is ${j - i + 1}`,
                tracks: [track("the text", chars, chars.map((_, k) => (k < i ? "done" : k <= j ? "read" : "idle"))), outTrack()],
                counters: [count("characters read", j + 1, n), count("runs written", out.length)],
                happened: `The scanning pointer lands on another '${ch}', so the run keeps growing.`,
                why: "As long as the scan finds the same letter, the run's length is still unknown and nothing can be written.",
                codeLine: 7,
              });
              j++;
            }
            const len = j - i;
            out.push({ ch, run: len });
            steps.push({
              title: len > 1
                ? `Run of ${len} '${ch}' → write '${ch}${len}'`
                : `Single '${ch}' → write '${ch}'`,
              tracks: [track("the text", chars, chars.map((_, k) => (k >= i && k < j ? "result" : "done"))), outTrack()],
              counters: [count("characters read", Math.max(j, i + 1), n), count("runs written", out.length)],
              happened: len > 1
                ? `The scan stopped at index ${j}, so ${len} copies of '${ch}' collapse into '${ch}${len}'.`
                : `The very next character is different, so '${ch}' stands alone and needs no count.`,
              why: "The distance between the two pointers is the run length, and the first pointer then jumps straight to the second.",
              codeLine: 9,
            });
            i = j;
          }

          const compressed = out.map((o) => o.ch + (o.run > 1 ? o.run : "")).join("");
          steps.push({
            title: `Answer: "${compressed}"`,
            tracks: [
              track("the text", chars, fill(n, "dim")),
              { label: "compressed output", cells: toArr(compressed).map((ch) => ({ v: ch, state: "result" })) },
            ],
            counters: [count("characters read", n, n), count("runs written", out.length), count("answer", compressed)],
            happened: `${out.length} run${out.length === 1 ? "" : "s"} became "${compressed}", ${compressed.length < n ? `a saving of ${n - compressed.length} character${n - compressed.length === 1 ? "" : "s"}.` : `which is no shorter than the original ${n} characters.`}`,
            why: "Both pointers only ever move forward, so every character is examined exactly once and the encoding is linear.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

})();
