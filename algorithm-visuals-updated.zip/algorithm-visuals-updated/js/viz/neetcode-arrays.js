/* ============================================================
   DSA Visuals - NeetCode 250 additions, arrays and strings
   Original walkthroughs written for this local collection.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => "[" + a.join(", ") + "]";
  const numbersFrom = (text) => String(text || "").split(/[\s,;]+/).filter(Boolean).map(Number).filter(Number.isFinite);
  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];

  /* ---------------------------------------------------------- */
  V.register({
    id: "concatenation-of-array",
    title: "Concatenation of Array",
    category: "Arrays & Hashing",
    difficulty: "Beginner",
    description: "Build an array made of the input followed by the input again.",
    input: { label: "The numbers", default: "1, 2, 1", parse: "ints" },
    approaches: [
      {
        name: "Copy Twice",
        complexity: "O(n) time, O(n) space",
        idea: [
          "The answer has exactly twice as many slots as the input. The first half is filled while walking left to right; the second half repeats the same values at an offset of n.",
          "A single index i can write to both ans[i] and ans[i + n], so no second pass over the source is needed beyond the loop itself.",
        ],
        problem: ["The output is a new array, so the extra O(n) space is unavoidable for this problem."],
        code: {
          c: `#include <stdlib.h>

int* getConcatenation(int* nums, int n, int* returnSize) {
    *returnSize = 2 * n;
    int* ans = malloc((2 * n) * sizeof(int));
    for (int i = 0; i < n; i++) {
        ans[i] = nums[i];
        ans[i + n] = nums[i];
    }
    return ans;
}`,
          cpp: `#include <vector>
using namespace std;

vector<int> getConcatenation(vector<int>& nums) {
    int n = (int)nums.size();
    vector<int> ans(2 * n);
    for (int i = 0; i < n; i++) {
        ans[i] = nums[i];
        ans[i + n] = nums[i];
    }
    return ans;
}`,
        },
        steps(nums) {
          const n = nums.length;
          const ans = new Array(2 * n).fill("-");
          const out = [];
          out.push({
            title: `Start with ${n} values`,
            tracks: [track("input", nums, fill(n, "read")), track("answer", ans, fill(2 * n, "idle"))],
            counters: [count("filled", 0, 2 * n), count("copy offset", n)],
            happened: "The answer needs two copies of the input, so it is twice as long.",
            why: "Knowing the destination size up front lets us write both copies in one pass.",
            legend: LEG,
            codeLine: 4,
          });
          for (let i = 0; i < n; i++) {
            ans[i] = nums[i];
            ans[i + n] = nums[i];
            const aState = fill(2 * n, "idle");
            aState[i] = "read";
            aState[i + n] = "read";
            out.push({
              title: `Copy ${nums[i]} into slots ${i} and ${i + n}`,
              tracks: [track("input", nums, nums.map((x, j) => (j === i ? "read" : j < i ? "done" : "idle"))), track("answer", ans, aState)],
              counters: [count("filled", 2 * (i + 1), 2 * n), count("source index", i)],
              happened: `The value ${nums[i]} is placed at position ${i} and again at position ${i + n}.`,
              why: "The offset n keeps the second copy directly after the first copy.",
              legend: LEG,
              codeLine: 6,
            });
          }
          out.push({
            title: "Both halves are complete",
            tracks: [track("input", nums, fill(n, "done")), track("answer", ans, fill(2 * n, "result"))],
            counters: [count("filled", 2 * n, 2 * n), count("answer length", 2 * n)],
            happened: `The final answer is ${show(ans)}.`,
            why: "Every input position contributed exactly twice, so the result is the requested concatenation.",
            legend: LEG,
            codeLine: 9,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "remove-element",
    title: "Remove Element",
    category: "Arrays & Hashing",
    difficulty: "Beginner",
    description: "Delete every copy of a value in place and return the new usable length.",
    input: { label: "numbers | value to remove", default: "3, 2, 2, 3 | 3", parse: "tworows" },
    approaches: [
      {
        name: "Write Pointer",
        complexity: "O(n) time, O(1) space",
        idea: [
          "A slow write pointer marks the next place for a kept value. A fast read pointer examines every value once.",
          "When the read value is not the target, it is copied to the write position and the write pointer moves. Target values are simply skipped.",
        ],
        problem: ["The kept values are compacted into the front of the same array; the unused tail is ignored rather than cleared."],
        code: {
          c: `#include <stddef.h>

int removeElement(int* nums, int n, int val) {
    int write = 0;
    for (int read = 0; read < n; read++) {
        if (nums[read] != val) {
            nums[write] = nums[read];
            write++;
        }
    }
    return write;
}`,
          cpp: `#include <vector>
using namespace std;

int removeElement(vector<int>& nums, int val) {
    int write = 0;
    for (int read = 0; read < (int)nums.size(); read++) {
        if (nums[read] != val) nums[write++] = nums[read];
    }
    return write;
}`,
        },
        steps(parsed) {
          const nums = (parsed[0] || []).slice();
          const val = (parsed[1] || [])[0];
          if (!nums.length) return [{ title: "Nothing to remove", tracks: [track("numbers", ["-"], ["idle"])], counters: [count("kept", 0)], happened: "The list is empty.", why: "An empty list already has the required result.", legend: LEG }];
          const kept = nums.slice();
          let write = 0;
          const out = [];
          out.push({
            title: `Remove every ${val}`,
            tracks: [track("numbers", nums, fill(nums.length, "idle")), chips("kept prefix", [], "idle")],
            counters: [count("write position", 0), count("kept", 0, nums.length)],
            happened: `The target value is ${val}; the write pointer starts at index 0.`,
            why: "Only values different from the target should survive in the compacted prefix.",
            legend: LEG,
            codeLine: 3,
          });
          for (let read = 0; read < nums.length; read++) {
            if (nums[read] !== val) {
              kept[write] = nums[read];
              const states = nums.map((x, j) => (j < read ? (nums[j] === val ? "bad" : "done") : j === read ? "read" : "idle"));
              out.push({
                title: `Keep ${nums[read]} at slot ${write}`,
                tracks: [track("numbers", nums, states), chips("kept prefix", kept.slice(0, write + 1), "good")],
                counters: [count("write position", write + 1), count("kept", write + 1, nums.length)],
                happened: `${nums[read]} is not ${val}, so it moves to index ${write}.`,
                why: "Writing only kept values closes the gaps left by removed values.",
                legend: LEG,
                codeLine: 6,
              });
            } else {
              const states = nums.map((x, j) => (j === read ? "bad" : j < read ? (nums[j] === val ? "bad" : "done") : "idle"));
              out.push({
                title: `Skip the removed ${val}`,
                tracks: [track("numbers", nums, states), chips("kept prefix", kept.slice(0, write), "good")],
                counters: [count("write position", write), count("kept", write, nums.length)],
                happened: `Index ${read} holds ${val}, so the write pointer does not move.`,
                why: "Skipping a target value leaves the next kept value free to use this slot.",
                legend: LEG,
                codeLine: 4,
              });
            }
            write += nums[read] !== val ? 1 : 0;
          }
          out.push({
            title: `The usable length is ${write}`,
            tracks: [track("numbers", kept, kept.map((x, i) => (i < write ? "result" : "dim"))), chips("kept prefix", kept.slice(0, write), "result")],
            counters: [count("kept", write, nums.length), count("answer length", write)],
            happened: `The front ${write} cells are ${show(kept.slice(0, write))}; the rest is ignored.`,
            why: "The returned length tells the caller how much of the array is valid.",
            legend: LEG,
            codeLine: 8,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "string-encode-and-decode",
    title: "Encode and Decode Strings",
    category: "Arrays & Hashing",
    difficulty: "Intermediate",
    description: "Pack a list of words into one string and recover the exact list.",
    input: { label: "Words", default: "neet code love", parse: "words" },
    approaches: [
      {
        name: "Length Prefixes",
        complexity: "O(total characters) time, O(total characters) space",
        idea: [
          "Write each word as its length, a separator, and the word. For example, 4#neet4#code. The decoder reads a number until #, then copies exactly that many characters.",
          "Lengths remove any need to search for a word boundary, so a word containing punctuation or even # is still safe.",
        ],
        problem: ["Numbers and the separator consume a little extra space, and the format must stay consistent between encoder and decoder."],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* encode(char** words, int n) {
    int size = 1;
    for (int i = 0; i < n; i++) size += 12 + strlen(words[i]);
    char* out = malloc(size);
    out[0] = '\\0';
    for (int i = 0; i < n; i++) {
        char head[16];
        sprintf(head, "%d#", (int)strlen(words[i]));
        strcat(out, head);
        strcat(out, words[i]);
    }
    return out;
}`,
          cpp: `#include <string>
#include <vector>
using namespace std;

string encode(vector<string>& words) {
    string out;
    for (const string& w : words) {
        out += to_string(w.size());
        out += '#';
        out += w;
    }
    return out;
}

vector<string> decode(const string& s) {
    vector<string> out;
    int i = 0;
    while (i < (int)s.size()) {
        int j = i;
        while (s[j] != '#') j++;
        int len = stoi(s.substr(i, j - i));
        out.push_back(s.substr(j + 1, len));
        i = j + 1 + len;
    }
    return out;
}`,
        },
        steps(words) {
          const list = words.slice();
          const encoded = [];
          const out = [];
          out.push({
            title: "Write a length before every word",
            tracks: [chips("words", list, "idle"), chips("encoded pieces", [], "idle")],
            counters: [count("words packed", 0, list.length)],
            happened: "Each word will become length + # + word.",
            why: "A length tells the decoder exactly where the next word stops.",
            legend: LEG,
            codeLine: 6,
          });
          for (let i = 0; i < list.length; i++) {
            encoded.push(list[i].length + "#" + list[i]);
            out.push({
              title: `Pack "${list[i]}" as ${list[i].length}#${list[i]}`,
              tracks: [chips("words", list, (k) => (k === i ? "read" : k < i ? "done" : "idle")), chips("encoded pieces", encoded, "done")],
              counters: [count("words packed", i + 1, list.length), count("characters", encoded.join("").length)],
              happened: `The prefix ${list[i].length} records how many characters belong to this word.`,
              why: "The decoder can skip the guesswork and copy exactly the recorded number of characters.",
              legend: LEG,
              codeLine: 7,
            });
          }
          const joined = encoded.join("");
          out.push({
            title: "One encoded string is ready",
            tracks: [chips("encoded string", [joined], "result")],
            counters: [count("words packed", list.length, list.length), count("encoded length", joined.length)],
            happened: `The packed value is "${joined}".`,
            why: "All original word boundaries are represented by numeric prefixes.",
            legend: LEG,
            codeLine: 9,
          });
          let pos = 0;
          const decoded = [];
          while (pos < joined.length) {
            let hash = pos;
            while (hash < joined.length && joined[hash] !== "#") hash++;
            const len = parseInt(joined.slice(pos, hash), 10);
            const word = joined.slice(hash + 1, hash + 1 + len);
            decoded.push(word);
            pos = hash + 1 + len;
            out.push({
              title: `Decode "${word}" using length ${len}`,
              tracks: [chips("encoded string", [joined], "done"), chips("decoded words", decoded, (k) => (k === decoded.length - 1 ? "result" : "good"))],
              counters: [count("words decoded", decoded.length, list.length), count("read position", pos)],
              happened: `The prefix ${len} says to take the next ${len} characters.`,
              why: "Advancing by exactly the recorded length lands on the next prefix.",
              legend: LEG,
              codeLine: 16,
            });
          }
          out.push({
            title: `Recovered ${decoded.length} words`,
            tracks: [chips("decoded words", decoded, "result")],
            counters: [count("words decoded", decoded.length, list.length)],
            happened: `The list is ${show(decoded)}.`,
            why: "Because every boundary came from a stored length, the original list is restored exactly.",
            legend: LEG,
            codeLine: 19,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "range-sum-query-2d-immutable",
    title: "Range Sum Query 2D Immutable",
    category: "Arrays & Hashing",
    difficulty: "Intermediate",
    description: "Answer rectangle-sum queries quickly with a 2D prefix table.",
    input: { label: "matrix values | r1,c1,r2,c2", default: "3,0,1,4,2,5 | 0,0,1,2", parse: "tworows" },
    approaches: [
      {
        name: "2D Prefix Sums",
        complexity: "O(rows * cols) build, O(1) per query",
        idea: [
          "Let P[r][c] be the sum of every matrix cell above and to the left of (r, c). It is built from the cell plus the prefix above plus the prefix to the left, subtracting the overlap counted twice.",
          "A rectangle sum then uses four prefix corners: bottom-right minus the area above it minus the area to its left, adding back the doubly removed top-left area.",
        ],
        problem: ["The table costs O(rows * cols) memory, and it is only worthwhile when many queries arrive."],
        code: {
          c: `#include <stdlib.h>

typedef struct { int rows, cols; int** p; } NumMatrix;

NumMatrix* create(int** a, int rows, int cols) {
    NumMatrix* m = malloc(sizeof(NumMatrix));
    m->rows = rows; m->cols = cols;
    m->p = malloc((rows + 1) * sizeof(int*));
    for (int r = 0; r <= rows; r++) m->p[r] = calloc(cols + 1, sizeof(int));
    for (int r = 1; r <= rows; r++)
        for (int c = 1; c <= cols; c++)
            m->p[r][c] = a[r-1][c-1] + m->p[r-1][c] + m->p[r][c-1] - m->p[r-1][c-1];
    return m;
}

int sumRegion(NumMatrix* m, int r1, int c1, int r2, int c2) {
    return m->p[r2+1][c2+1] - m->p[r1][c2+1] - m->p[r2+1][c1] + m->p[r1][c1];
}`,
          cpp: `#include <vector>
using namespace std;

class NumMatrix {
    vector<vector<int>> p;
public:
    NumMatrix(vector<vector<int>>& a) {
        int rows = a.size(), cols = a[0].size();
        p.assign(rows + 1, vector<int>(cols + 1, 0));
        for (int r = 1; r <= rows; r++)
            for (int c = 1; c <= cols; c++)
                p[r][c] = a[r-1][c-1] + p[r-1][c] + p[r][c-1] - p[r-1][c-1];
    }
    int sumRegion(int r1, int c1, int r2, int c2) {
        return p[r2+1][c2+1] - p[r1][c2+1] - p[r2+1][c1] + p[r1][c1];
    }
};`,
        },
        steps(parsed) {
          const flat = (parsed[0] || []).slice();
          const q = parsed[1] || [0, 0, 0, 0];
          const cols = flat.length % 2 === 0 ? 2 : 1;
          const rows = Math.max(1, Math.ceil(flat.length / cols));
          const matrix = Array.from({ length: rows }, (_, r) => Array.from({ length: cols }, (_, c) => flat[r * cols + c] ?? 0));
          const r1 = Math.min(Math.max(q[0] || 0, 0), rows - 1);
          const c1 = Math.min(Math.max(q[1] || 0, 0), cols - 1);
          const r2 = Math.min(Math.max(q[2] || 0, r1), rows - 1);
          const c2 = Math.min(Math.max(q[3] || 0, c1), cols - 1);
          const P = Array.from({ length: rows + 1 }, () => new Array(cols + 1).fill(0));
          const cell = (r, c, v, state) => ({ r, c, v, state });
          const gridFrom = (arr, highlight) =>
            window.H.grid(rows + 1, cols + 1, (r, c) => ({
              v: arr[r][c],
              state: highlight ? highlight(r, c) : "idle",
            }));
          const out = [];
          out.push({
            title: "Make room for a border of zeroes",
            tracks: [chips("matrix", matrix.map((r) => r.join(",")), "idle")],
            counters: [count("rows", rows), count("cols", cols)],
            happened: `The query asks for rows ${r1}..${r2} and columns ${c1}..${c2}.`,
            why: "A zero border lets the four-corner formula work without special cases at the edges.",
            legend: LEG,
            codeLine: 5,
          });
          for (let r = 1; r <= rows; r++) {
            for (let c = 1; c <= cols; c++) {
              P[r][c] = matrix[r - 1][c - 1] + P[r - 1][c] + P[r][c - 1] - P[r - 1][c - 1];
            }
            out.push({
              title: `Build prefix row ${r}`,
              tracks: [gridFrom(P, (rr, cc) => (rr === r && cc >= 1 ? "read" : rr < r && rr > 0 ? "done" : "idle"))],
              counters: [count("rows built", r, rows)],
              happened: `Row ${r} now stores cumulative sums for its cells.`,
              why: "Each prefix value reuses the prefix above and to the left, subtracting the overlap once.",
              legend: LEG,
              codeLine: 9,
            });
          }
          const corners = [
            { r: r2 + 1, c: c2 + 1, label: "whole corner" },
            { r: r1, c: c2 + 1, label: "subtract above" },
            { r: r2 + 1, c: c1, label: "subtract left" },
            { r: r1, c: c1, label: "add back overlap" },
          ];
          const answer = P[r2 + 1][c2 + 1] - P[r1][c2 + 1] - P[r2 + 1][c1] + P[r1][c1];
          out.push({
            title: "Use four prefix corners",
            tracks: [gridFrom(P, (rr, cc) => {
              const hit = corners.find((x) => x.r === rr && x.c === cc);
              return hit ? "compare" : "idle";
            })],
            counters: [count("whole", P[r2 + 1][c2 + 1]), count("above", P[r1][c2 + 1]), count("left", P[r2 + 1][c1]), count("overlap", P[r1][c1])],
            happened: "The four stored values describe the target rectangle and the regions outside it.",
            why: "Subtracting the above and left parts removes too much, so the top-left overlap is added back.",
            legend: LEG,
            codeLine: 16,
          });
          out.push({
            title: `Rectangle sum is ${answer}`,
            tracks: [gridFrom(P, (rr, cc) => (rr === r2 + 1 && cc === c2 + 1 ? "result" : "dim"))],
            counters: [count("answer", answer)],
            happened: `The query returns ${answer}.`,
            why: "The inclusion-exclusion formula gives the answer in constant time after the table is built.",
            legend: LEG,
            codeLine: 17,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "valid-sudoku",
    title: "Valid Sudoku",
    category: "Arrays & Hashing",
    difficulty: "Intermediate",
    description: "Check rows, columns and 3x3 boxes for duplicate digits.",
    input: { label: "Nine rows (use . for blanks)", default: "53..7.... 6..195... .98....6. 8...6...3 4..8.3..1 7...2...6 .6....28. ...419..5 ....8..79", parse: "tokens" },
    approaches: [
      {
        name: "Three Sets at Once",
        complexity: "O(81) time, O(81) space",
        idea: [
          "Every filled cell belongs to exactly one row, one column and one 3x3 box. While scanning the board, record the digit in all three sets for that cell.",
          "If a digit already appears in its row, column or box, the board is invalid. Empty cells are skipped.",
        ],
        problem: ["The sets can be replaced by bit masks, but the idea is the same: remember what each region has already seen."],
        code: {
          c: `#include <stdbool.h>

bool isValidSudoku(char board[9][9]) {
    bool row[9][9] = {0}, col[9][9] = {0}, box[9][9] = {0};
    for (int r = 0; r < 9; r++) {
        for (int c = 0; c < 9; c++) {
            if (board[r][c] == '.') continue;
            int d = board[r][c] - '1';
            int b = (r / 3) * 3 + c / 3;
            if (row[r][d] || col[c][d] || box[b][d]) return false;
            row[r][d] = col[c][d] = box[b][d] = true;
        }
    }
    return true;
}`,
          cpp: `#include <vector>
using namespace std;

bool isValidSudoku(vector<vector<char>>& board) {
    bool row[9][9] = {}, col[9][9] = {}, box[9][9] = {};
    for (int r = 0; r < 9; r++) {
        for (int c = 0; c < 9; c++) {
            if (board[r][c] == '.') continue;
            int d = board[r][c] - '1';
            int b = (r / 3) * 3 + c / 3;
            if (row[r][d] || col[c][d] || box[b][d]) return false;
            row[r][d] = col[c][d] = box[b][d] = true;
        }
    }
    return true;
}`,
        },
        steps(tokens) {
          const rows = tokens.slice(0, 9).map((s) => String(s).padEnd(9, ".").slice(0, 9));
          while (rows.length < 9) rows.push(".........");
          const board = rows.map((r) => r.split(""));
          const seenRows = Array.from({ length: 9 }, () => new Set());
          const seenCols = Array.from({ length: 9 }, () => new Set());
          const seenBoxes = Array.from({ length: 9 }, () => new Set());
          const cellStates = {};
          const makeGrid = (extra) =>
            window.H.grid(9, 9, (r, c) => ({
              v: board[r][c] === "." ? "" : board[r][c],
              state: extra && extra[r + "," + c] ? extra[r + "," + c] : cellStates[r + "," + c] || "idle",
            }));
          const out = [];
          out.push({
            title: "Three regions per digit",
            tracks: [makeGrid()],
            counters: [count("cells checked", 0, 81)],
            happened: "Rows, columns and 3x3 boxes each need their own memory of seen digits.",
            why: "A valid Sudoku has no repeated digit in any of those three kinds of region.",
            legend: LEG,
            codeLine: 4,
          });
          let checked = 0;
          let bad = null;
          for (let r = 0; r < 9 && !bad; r++) {
            for (let c = 0; c < 9 && !bad; c++) {
              const ch = board[r][c];
              if (ch === ".") continue;
              checked++;
              const b = Math.floor(r / 3) * 3 + Math.floor(c / 3);
              const clash = seenRows[r].has(ch) || seenCols[c].has(ch) || seenBoxes[b].has(ch);
              cellStates[r + "," + c] = clash ? "bad" : "read";
              if (clash) {
                bad = { r, c, ch };
                out.push({
                  title: `Duplicate ${ch} at row ${r + 1}, column ${c + 1}`,
                  tracks: [makeGrid({ [r + "," + c]: "bad" })],
                  counters: [count("cells checked", checked), count("conflicts", 1)],
                  happened: `The digit ${ch} already appeared in the same row, column or box.`,
                  why: "One repeated digit is enough to make the whole board invalid.",
                  legend: LEG,
                  codeLine: 9,
                });
                break;
              }
              seenRows[r].add(ch);
              seenCols[c].add(ch);
              seenBoxes[b].add(ch);
              if (checked <= 7 || checked % 12 === 0) {
                out.push({
                  title: `Record ${ch} in row ${r + 1}, column ${c + 1}`,
                  tracks: [makeGrid({ [r + "," + c]: "read" })],
                  counters: [count("cells checked", checked), count("digits recorded", checked)],
                  happened: `${ch} is new for this row, column and box.`,
                  why: "Adding it to all three sets prevents a later duplicate from slipping through.",
                  legend: LEG,
                  codeLine: 9,
                });
              }
            }
          }
          if (bad) {
            out.push({
              title: "The board is not valid",
              tracks: [makeGrid({ [bad.r + "," + bad.c]: "bad" })],
              counters: [count("conflicts", 1), count("answer", "false")],
              happened: `The repeated ${bad.ch} proves the board cannot be a valid Sudoku.`,
              why: "Stopping at the first conflict is safe; the answer is already determined.",
              legend: LEG,
              codeLine: 9,
            });
          } else {
            out.push({
              title: "No region contains a duplicate",
              tracks: [window.H.grid(9, 9, (r, c) => ({ v: board[r][c] === "." ? "" : board[r][c], state: board[r][c] === "." ? "idle" : "result" }))],
              counters: [count("cells checked", checked, 81), count("conflicts", 0)],
              happened: "Every filled digit was unique inside each row, column and box.",
              why: "That is exactly the condition for a valid Sudoku board.",
              legend: LEG,
              codeLine: 12,
            });
          }
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "best-time-to-buy-and-sell-stock-ii",
    title: "Best Time to Buy and Sell Stock II",
    category: "Arrays & Hashing",
    difficulty: "Intermediate",
    description: "Collect every upward price movement with unlimited transactions.",
    input: { label: "Daily prices", default: "7, 1, 5, 3, 6, 4", parse: "ints" },
    approaches: [
      {
        name: "Add Every Rise",
        complexity: "O(n) time, O(1) space",
        idea: [
          "With unlimited transactions, every increase from one day to the next can be captured by buying before the rise and selling after it.",
          "The total profit is therefore the sum of all positive differences price[i] - price[i-1].",
        ],
        problem: ["Real trading has fees and settlement delays, but this version deliberately ignores them."],
        code: {
          c: `int maxProfit(int* prices, int n) {
    int profit = 0;
    for (int i = 1; i < n; i++)
        if (prices[i] > prices[i - 1])
            profit += prices[i] - prices[i - 1];
    return profit;
}`,
          cpp: `#include <vector>
using namespace std;

int maxProfit(vector<int>& prices) {
    int profit = 0;
    for (int i = 1; i < (int)prices.size(); i++)
        if (prices[i] > prices[i - 1])
            profit += prices[i] - prices[i - 1];
    return profit;
}`,
        },
        steps(prices) {
          const out = [];
          let profit = 0;
          out.push({
            title: "Look for every daily rise",
            tracks: [track("prices", prices, fill(prices.length, "idle")), chips("profit", [0], "idle")],
            counters: [count("profit", 0), count("day", 1, prices.length)],
            happened: "The first price is only a reference; trading starts by comparing day 1 with day 0.",
            why: "Each positive day-to-day change can be collected independently.",
            legend: LEG,
            codeLine: 2,
          });
          for (let i = 1; i < prices.length; i++) {
            const rise = prices[i] - prices[i - 1];
            if (rise > 0) profit += rise;
            const states = prices.map((x, j) => (j === i - 1 || j === i ? "compare" : "idle"));
            out.push({
              title: rise > 0 ? `Capture +${rise} from day ${i - 1} to ${i}` : `Ignore the drop of ${-rise}`,
              tracks: [track("prices", prices, states), chips("profit", [profit], "result")],
              counters: [count("profit", profit), count("day", i + 1, prices.length)],
              happened: rise > 0 ? `Price rose from ${prices[i - 1]} to ${prices[i]}, so add ${rise}.` : `Price fell, so this pair contributes nothing.`,
              why: "Only rises add value; declines would lose money if forced into a transaction.",
              legend: LEG,
              codeLine: 3,
            });
          }
          out.push({
            title: `Maximum profit is ${profit}`,
            tracks: [track("prices", prices, fill(prices.length, "done")), chips("profit", [profit], "result")],
            counters: [count("profit", profit), count("transactions", prices.filter((x, i) => i && x > prices[i - 1]).length)],
            happened: `Adding all positive changes gives ${profit}.`,
            why: "Many small trades produce the same total as holding through the whole climb.",
            legend: LEG,
            codeLine: 4,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "majority-element-ii",
    title: "Majority Element II",
    category: "Arrays & Hashing",
    difficulty: "Intermediate",
    description: "Find every value that appears more than n/3 times.",
    input: { label: "The numbers", default: "1, 1, 1, 3, 3, 2, 2, 2", parse: "ints" },
    approaches: [
      {
        name: "Two Candidate Vote",
        complexity: "O(n) time, O(1) space",
        idea: [
          "At most two values can occur more than n/3 times. Keep two candidates and two vote counts while scanning.",
          "A new value joins an empty candidate slot, matches increase a count, and non-matches cancel both counts. A final verification pass removes candidates that were only noise.",
        ],
        problem: ["The voting phase can leave candidates that are not actually frequent, so the second count pass is required."],
        code: {
          c: `#include <stdlib.h>

int* majorityElement(int* nums, int n, int* returnSize) {
    int c1 = 0, c2 = 1, v1 = 0, v2 = 0;
    for (int i = 0; i < n; i++) {
        if (nums[i] == c1) v1++;
        else if (nums[i] == c2) v2++;
        else if (v1 == 0) { c1 = nums[i]; v1 = 1; }
        else if (v2 == 0) { c2 = nums[i]; v2 = 1; }
        else { v1--; v2--; }
    }
    int n1 = 0, n2 = 0;
    for (int i = 0; i < n; i++) {
        if (nums[i] == c1) n1++;
        else if (nums[i] == c2) n2++;
    }
    int* ans = malloc(2 * sizeof(int));
    *returnSize = 0;
    if (n1 > n / 3) ans[(*returnSize)++] = c1;
    if (n2 > n / 3) ans[(*returnSize)++] = c2;
    return ans;
}`,
          cpp: `#include <vector>
using namespace std;

vector<int> majorityElement(vector<int>& nums) {
    int c1 = 0, c2 = 1, v1 = 0, v2 = 0;
    for (int x : nums) {
        if (x == c1) v1++;
        else if (x == c2) v2++;
        else if (v1 == 0) { c1 = x; v1 = 1; }
        else if (v2 == 0) { c2 = x; v2 = 1; }
        else { v1--; v2--; }
    }
    int n1 = 0, n2 = 0;
    for (int x : nums) {
        if (x == c1) n1++;
        else if (x == c2) n2++;
    }
    vector<int> ans;
    if (n1 > (int)nums.size() / 3) ans.push_back(c1);
    if (n2 > (int)nums.size() / 3) ans.push_back(c2);
    return ans;
}`,
        },
        steps(nums) {
          const out = [];
          let c1 = 0, c2 = 1, v1 = 0, v2 = 0;
          out.push({
            title: "Two slots are enough",
            tracks: [track("numbers", nums, fill(nums.length, "idle")), chips("candidates", ["-", "-"], "idle")],
            counters: [count("candidate 1 votes", 0), count("candidate 2 votes", 0)],
            happened: "At most two numbers can occur more than n/3 times.",
            why: "Three values each above n/3 would require more than n total positions.",
            legend: LEG,
            codeLine: 4,
          });
          for (let i = 0; i < nums.length; i++) {
            const x = nums[i];
            if (x === c1) v1++;
            else if (x === c2) v2++;
            else if (v1 === 0) { c1 = x; v1 = 1; }
            else if (v2 === 0) { c2 = x; v2 = 1; }
            else { v1--; v2--; }
            out.push({
              title: `Read ${x}`,
              tracks: [track("numbers", nums, nums.map((n, j) => (j === i ? "read" : j < i ? "done" : "idle"))), chips("candidates", [c1 + " (" + v1 + ")", c2 + " (" + v2 + ")"], "active")],
              counters: [count("candidate 1 votes", v1), count("candidate 2 votes", v2)],
              happened: `The two candidate vote counts are now ${v1} and ${v2}.`,
              why: "Canceled pairs of different values cannot be the majority, so they are safely removed from consideration.",
              legend: LEG,
              codeLine: 6,
            });
          }
          let n1 = 0, n2 = 0;
          for (const x of nums) {
            if (x === c1) n1++;
            else if (x === c2) n2++;
          }
          const answer = [];
          if (n1 > Math.floor(nums.length / 3)) answer.push(c1);
          if (n2 > Math.floor(nums.length / 3)) answer.push(c2);
          out.push({
            title: `Verify candidates ${c1} and ${c2}`,
            tracks: [track("numbers", nums, fill(nums.length, "done")), chips("candidates", [c1 + ": " + n1, c2 + ": " + n2], "compare")],
            counters: [count("needed count", Math.floor(nums.length / 3) + 1), count("verified", answer.length)],
            happened: `The final counts are ${n1} and ${n2}; the threshold is more than ${Math.floor(nums.length / 3)}.`,
            why: "Voting only nominates candidates; actual frequency decides whether they stay.",
            legend: LEG,
            codeLine: 12,
          });
          out.push({
            title: answer.length ? `Answer: ${show(answer)}` : "No value exceeds n/3",
            tracks: [track("numbers", nums, fill(nums.length, "result"))],
            counters: [count("answer", answer.length), count("threshold", Math.floor(nums.length / 3) + 1)],
            happened: answer.length ? `The frequent values are ${show(answer)}.` : "Every value stayed at or below the threshold.",
            why: "The two-pass method reports exactly the values that occur more than n/3 times.",
            legend: LEG,
            codeLine: 16,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "reverse-string",
    title: "Reverse String",
    category: "Two Pointers",
    difficulty: "Beginner",
    description: "Reverse a character array in place with two pointers.",
    input: { label: "Text", default: "hello", parse: "chars" },
    approaches: [
      {
        name: "Swap from Both Ends",
        complexity: "O(n) time, O(1) space",
        idea: [
          "One pointer starts at the first character and one at the last. Swap those characters, then move both pointers inward.",
          "The middle character, if any, is already in the right place when the pointers meet.",
        ],
        problem: ["The input is modified in place, so callers must not expect the original order to remain available."],
        code: {
          c: `void reverseString(char* s, int n) {
    int left = 0, right = n - 1;
    while (left < right) {
        char t = s[left];
        s[left] = s[right];
        s[right] = t;
        left++;
        right--;
    }
}`,
          cpp: `#include <vector>
using namespace std;

void reverseString(vector<char>& s) {
    int left = 0, right = (int)s.size() - 1;
    while (left < right) {
        swap(s[left], s[right]);
        left++;
        right--;
    }
}`,
        },
        steps(chars) {
          const a = chars.slice();
          const out = [];
          let left = 0, right = a.length - 1;
          out.push({
            title: "Point at both ends",
            tracks: [track("characters", a, a.map((x, i) => (i === 0 || i === a.length - 1 ? "compare" : "idle")))],
            pointers: [{ index: 0, label: "L" }, { index: a.length - 1, label: "R" }],
            counters: [count("left", left), count("right", right)],
            happened: `The outer characters are '${a[0]}' and '${a[a.length - 1]}'.`,
            why: "Swapping symmetric positions reverses the sequence without extra memory.",
            legend: LEG,
            codeLine: 2,
          });
          while (left < right) {
            const l = a[left], r = a[right];
            a[left] = r;
            a[right] = l;
            const states = a.map((x, i) => (i === left || i === right ? "swap" : i < left || i > right ? "done" : "idle"));
            out.push({
              title: `Swap '${l}' and '${r}'`,
              tracks: [track("characters", a, states)],
              pointers: [{ index: left, label: "L" }, { index: right, label: "R" }],
              counters: [count("left", left), count("right", right)],
              happened: `Positions ${left} and ${right} exchanged values.`,
              why: "Now both of those positions hold their final reversed characters.",
              legend: LEG,
              codeLine: 5,
            });
            left++;
            right--;
          }
          out.push({
            title: `Reversed: ${a.join("")}`,
            tracks: [track("characters", a, fill(a.length, "result"))],
            counters: [count("pairs swapped", Math.floor(chars.length / 2)), count("answer", a.join(""))],
            happened: `The characters now read "${a.join("")}".`,
            why: "Every symmetric pair was exchanged once; the middle character needed no move.",
            legend: LEG,
            codeLine: 7,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "valid-palindrome-ii",
    title: "Valid Palindrome II",
    category: "Two Pointers",
    difficulty: "Beginner",
    description: "Decide whether deleting at most one character can make a palindrome.",
    input: { label: "Text", default: "abca", parse: "string" },
    approaches: [
      {
        name: "One Skip Allowed",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Compare characters from the outside in. As long as they match, keep moving inward.",
          "At the first mismatch, the only possible fixes are to skip the left character or skip the right character. Test both remaining substrings.",
        ],
        problem: ["A second mismatch inside either test means no single deletion can repair the string."],
        code: {
          c: `#include <stdbool.h>
#include <string.h>

bool pal(const char* s, int i, int j) {
    while (i < j) if (s[i++] != s[j--]) return false;
    return true;
}

bool validPalindrome(char* s) {
    int i = 0, j = (int)strlen(s) - 1;
    while (i < j && s[i] == s[j]) { i++; j--; }
    if (i >= j) return true;
    return pal(s, i + 1, j) || pal(s, i, j - 1);
}`,
          cpp: `#include <string>
using namespace std;

bool pal(const string& s, int i, int j) {
    while (i < j) if (s[i++] != s[j--]) return false;
    return true;
}

bool validPalindrome(string s) {
    int i = 0, j = (int)s.size() - 1;
    while (i < j && s[i] == s[j]) { i++; j--; }
    if (i >= j) return true;
    return pal(s, i + 1, j) || pal(s, i, j - 1);
}`,
        },
        steps(text) {
          const chars = [...String(text || "")];
          const out = [];
          let i = 0, j = chars.length - 1;
          while (i < j && chars[i] === chars[j]) {
            out.push({
              title: `'${chars[i]}' matches '${chars[j]}'`,
              tracks: [track("text", chars, chars.map((x, k) => (k === i || k === j ? "good" : "idle")))],
              pointers: [{ index: i, label: "L" }, { index: j, label: "R" }],
              counters: [count("left", i), count("right", j)],
              happened: `Characters at ${i} and ${j} agree.`,
              why: "Matching outer characters can stay; the decision is pushed inward.",
              legend: LEG,
              codeLine: 7,
            });
            i++;
            j--;
          }
          if (i >= j) {
            out.push({
              title: "Already a palindrome",
              tracks: [track("text", chars, fill(chars.length, "result"))],
              counters: [count("answer", "true")],
              happened: "The pointers met without finding any mismatch.",
              why: "No deletion is needed when the original text is already symmetric.",
              legend: LEG,
              codeLine: 7,
            });
            return out;
          }
          out.push({
            title: `Mismatch: '${chars[i]}' vs '${chars[j]}'`,
            tracks: [track("text", chars, chars.map((x, k) => (k === i || k === j ? "bad" : "idle")))],
            pointers: [{ index: i, label: "L" }, { index: j, label: "R" }],
            counters: [count("left", i), count("right", j), count("skips left", 0)],
            happened: `The only ways forward are to drop '${chars[i]}' or drop '${chars[j]}'.`,
            why: "Deleting an inner character would not fix this outer mismatch.",
            legend: LEG,
            codeLine: 9,
          });
          const test = (start, end, skipped) => {
            const local = chars.slice();
            while (start < end && local[start] === local[end]) { start++; end--; }
            const ok = start >= end;
            out.push({
              title: ok ? `Skipping '${skipped}' works` : `Skipping '${skipped}' still fails`,
              tracks: [track("text", local, local.map((x, k) => (k === skipped ? "dim" : k >= start && k <= end ? (ok ? "good" : "bad") : "done")))],
              counters: [count("test", skipped), count("allowed skips", 1)],
              happened: ok ? "The remaining characters are symmetric." : "Another mismatch remains after this single skip.",
              why: "Only one deletion is allowed, so a second mismatch rejects this branch.",
              legend: LEG,
              codeLine: 10,
            });
            return ok;
          };
          const skipLeft = test(i + 1, j, i);
          const skipRight = test(i, j - 1, j);
          const possible = skipLeft || skipRight;
          out.push({
            title: possible ? "One deletion is enough" : "More than one deletion is needed",
            tracks: [track("text", chars, fill(chars.length, possible ? "result" : "dim"))],
            counters: [count("answer", possible ? "true" : "false")],
            happened: possible ? "At least one skip leaves a palindrome." : "Neither skip repairs the text.",
            why: "If either branch becomes a palindrome, the original can be repaired with one deletion.",
            legend: LEG,
            codeLine: 10,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "merge-strings-alternately",
    title: "Merge Strings Alternately",
    category: "Two Pointers",
    difficulty: "Beginner",
    description: "Interleave two words and append whatever remains when one runs out.",
    input: { label: "Two words", default: "abc pq", parse: "words" },
    approaches: [
      {
        name: "Walk Both Words",
        complexity: "O(a + b) time, O(a + b) space",
        idea: [
          "Keep one index in each word. On every round, take a character from the first word if it still has one, then a character from the second word if it still has one.",
          "After one word is exhausted, copying the rest of the other word finishes the merge.",
        ],
        problem: ["The result needs room for every character from both inputs, so the extra space is proportional to their combined length."],
        code: {
          c: `#include <stdlib.h>
#include <string.h>

char* mergeAlternately(char* a, char* b) {
    int n = strlen(a), m = strlen(b), k = 0;
    char* out = malloc(n + m + 1);
    for (int i = 0; i < n || i < m; i++) {
        if (i < n) out[k++] = a[i];
        if (i < m) out[k++] = b[i];
    }
    out[k] = '\\0';
    return out;
}`,
          cpp: `#include <string>
using namespace std;

string mergeAlternately(string a, string b) {
    string out;
    int i = 0, j = 0;
    while (i < (int)a.size() || j < (int)b.size()) {
        if (i < (int)a.size()) out += a[i++];
        if (j < (int)b.size()) out += b[j++];
    }
    return out;
}`,
        },
        steps(words) {
          const a = [...(words[0] || "")];
          const b = [...(words[1] || "")];
          const outChars = [];
          const out = [];
          let i = 0, j = 0;
          out.push({
            title: "Start one pointer in each word",
            tracks: [track("word A", a, a.map((_, k) => (k === 0 ? "read" : "idle"))), track("word B", b, b.map((_, k) => (k === 0 ? "read" : "idle"))), chips("result", [], "idle")],
            pointers: [
              ...(a.length ? [{ track: 0, index: 0, label: "i" }] : []),
              ...(b.length ? [{ track: 1, index: 0, label: "j" }] : []),
            ],
            counters: [count("A used", 0, a.length), count("B used", 0, b.length)],
            happened: `The words are "${a.join("")}" and "${b.join("")}".`,
            why: "Alternating means taking from A, then B, then repeating.",
            legend: LEG,
            codeLine: 5,
          });
          while (i < a.length || j < b.length) {
            if (i < a.length) {
              outChars.push(a[i]);
              out.push({
                title: `Take '${a[i]}' from word A`,
                tracks: [track("word A", a, a.map((x, k) => (k === i ? "read" : k < i ? "done" : "idle"))), track("word B", b, b.map((x, k) => (k === j ? "read" : k < j ? "done" : "idle"))), chips("result", outChars, "done")],
                pointers: [
                  ...(i < a.length ? [{ track: 0, index: i, label: "i" }] : []),
                  ...(j < b.length ? [{ track: 1, index: j, label: "j" }] : []),
                ],
                counters: [count("A used", i + 1, a.length), count("B used", j, b.length)],
                happened: `'${a[i]}' is appended.`,
                why: "Each word contributes at most one character per round.",
                legend: LEG,
                codeLine: 6,
              });
              i++;
            }
            if (j < b.length) {
              outChars.push(b[j]);
              out.push({
                title: `Take '${b[j]}' from word B`,
                tracks: [track("word A", a, a.map((x, k) => (k === i ? "read" : k < i ? "done" : "idle"))), track("word B", b, b.map((x, k) => (k === j ? "read" : k < j ? "done" : "idle"))), chips("result", outChars, "done")],
                pointers: [
                  ...(i < a.length ? [{ track: 0, index: i, label: "i" }] : []),
                  ...(j < b.length ? [{ track: 1, index: j, label: "j" }] : []),
                ],
                counters: [count("A used", i, a.length), count("B used", j + 1, b.length)],
                happened: `'${b[j]}' is appended after the character from A.`,
                why: "This produces the alternating A-B order.",
                legend: LEG,
                codeLine: 7,
              });
              j++;
            }
          }
          out.push({
            title: `Merged: ${outChars.join("")}`,
            tracks: [chips("result", outChars, "result")],
            counters: [count("characters", outChars.length, a.length + b.length)],
            happened: `The merged string is "${outChars.join("")}".`,
            why: "Both words were consumed exactly once.",
            legend: LEG,
            codeLine: 9,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "boats-to-save-people",
    title: "Boats to Save People",
    category: "Two Pointers",
    difficulty: "Intermediate",
    description: "Use the fewest boats when each boat carries at most two people.",
    input: { label: "People | boat limit", default: "1, 2, 2, 3 | 3", parse: "tworows" },
    approaches: [
      {
        name: "Pair Lightest with Heaviest",
        complexity: "O(n log n) time, O(1) extra space",
        idea: [
          "Sort the weights. The heaviest remaining person must take a boat now; if the lightest person can share it, pair them.",
          "If the lightest person does not fit with the heaviest, the heaviest travels alone. Either way the right pointer moves inward, and a pair also moves the left pointer.",
        ],
        problem: ["Sorting changes the original order, which is fine because only weights matter here."],
        code: {
          c: `#include <stdlib.h>

int cmp(const void* a, const void* b) {
    return *(const int*)a - *(const int*)b;
}

int numRescueBoats(int* people, int n, int limit) {
    qsort(people, n, sizeof(int), cmp);
    int left = 0, right = n - 1, boats = 0;
    while (left <= right) {
        if (people[left] + people[right] <= limit) left++;
        right--;
        boats++;
    }
    return boats;
}`,
          cpp: `#include <algorithm>
#include <vector>
using namespace std;

int numRescueBoats(vector<int>& people, int limit) {
    sort(people.begin(), people.end());
    int left = 0, right = (int)people.size() - 1, boats = 0;
    while (left <= right) {
        if (people[left] + people[right] <= limit) left++;
        right--;
        boats++;
    }
    return boats;
}`,
        },
        steps(parsed) {
          const people = (parsed[0] || []).slice().sort((a, b) => a - b);
          const limit = (parsed[1] || [0])[0];
          const out = [];
          let left = 0, right = people.length - 1, boats = 0;
          out.push({
            title: `Sort the weights; limit is ${limit}`,
            tracks: [track("sorted people", people, people.map((_, i) => (i === 0 || i === people.length - 1 ? "read" : "idle"))), chips("boats", [], "idle")],
            pointers: [{ index: 0, label: "L" }, { index: people.length - 1, label: "R" }],
            counters: [count("boats", 0), count("remaining", people.length)],
            happened: `The lightest person is ${people[0]} and the heaviest is ${people[people.length - 1]}.`,
            why: "The heaviest person cannot wait for a later, smaller boat, so decisions can be made from the outside in.",
            legend: LEG,
            codeLine: 7,
          });
          while (left <= right) {
            const heaviest = people[right];
            const canPair = left < right && people[left] + heaviest <= limit;
            const passenger = canPair ? people[left] : null;
            boats++;
            const used = [];
            if (canPair) used.push(left, right);
            else used.push(right);
            out.push({
              title: canPair ? `Pair ${people[left]} + ${heaviest}` : `Send ${heaviest} alone`,
              tracks: [track("sorted people", people, people.map((x, i) => (used.includes(i) ? "result" : i === left || i === right ? "read" : i < left || i > right ? "done" : "idle"))), chips("boats", [boats], "result")],
              pointers: left < right ? [{ index: left, label: "L" }, { index: right, label: "R" }] : [{ index: right, label: "R" }],
              counters: [count("boats", boats), count("remaining", right - left + 1)],
              happened: canPair ? `Their sum ${people[left] + heaviest} fits in the limit.` : `The lightest person cannot share with ${heaviest}.`,
              why: canPair ? "Using the available seat saves a boat." : "Sending the heaviest alone is unavoidable because nobody lighter fits with it.",
              legend: LEG,
              codeLine: 9,
            });
            if (canPair) left++;
            right--;
          }
          out.push({
            title: `Need ${boats} boats`,
            tracks: [track("sorted people", people, fill(people.length, "done")), chips("boats", [boats], "result")],
            counters: [count("boats", boats), count("people", people.length)],
            happened: `Every person was assigned using ${boats} boats.`,
            why: "Pairing the lightest possible partner with each heaviest person leaves the fewest boats.",
            legend: LEG,
            codeLine: 12,
          });
          return out;
        },
      },
    ],
  });

  /* ------------------------------------------------------------
     Open-addressing table used by the two Contains Duplicate II
     walkthroughs.  One slot is one cell, so a lookup becomes a visible
     walk from the home bucket through the probe chain instead of a
     mysterious "last index" list.  A tombstone makes deletion possible
     for the bounded sliding-window version.
     ------------------------------------------------------------ */
  function makeHashTable(minCap) {
    let cap = 8;
    while (cap < (minCap || 0)) cap <<= 1;
    const slots = Array(cap).fill(null); // null | {key, pos} | {key:null, tomb:true}

    const hashOf = (key) => (Math.imul(key | 0, 2654435761) >>> 0) & (cap - 1);

    const find = (key) => {
      const home = hashOf(key);
      const path = [];
      let s = home, firstTomb = -1;
      for (let n = 0; n < cap; n++) {
        path.push(s);
        const e = slots[s];
        if (!e) return { home, slot: firstTomb >= 0 ? firstTomb : s, entry: null, found: false, path };
        if (e.tomb) {
          if (firstTomb < 0) firstTomb = s;
        } else if (e.key === key) {
          return { home, slot: s, entry: e, found: true, path };
        }
        s = (s + 1) & (cap - 1);
      }
      return { home, slot: firstTomb >= 0 ? firstTomb : home, entry: null, found: false, path };
    };

    const put = (key, pos) => {
      const r = find(key);
      slots[r.slot] = { key, pos };
      return r;
    };
    const erase = (key) => {
      const r = find(key);
      if (r.found) slots[r.slot] = { key: null, pos: -1, tomb: true };
      return r;
    };
    return { cap, slots, hashOf, find, put, erase };
  }

  const TABLE_LEGEND = {
    read: "current number", active: "home slot", compare: "probed slot",
    result: "stored entry", good: "valid pair", bad: "evicted / too far",
    dim: "outside window", done: "stored value", idle: "empty slot",
  };

  function hashSlotsTrack(table, opts) {
    const o = opts || {};
    const visited = o.visited || [];
    return {
      label: o.label || "hash slots",
      cells: table.slots.map((e, s) => {
        let state = !e ? "idle" : e.tomb ? "bad" : "done";
        if (o.home === s) state = "active";
        if (visited.indexOf(s) >= 0) state = "compare";
        if (o.markSlot === s) state = o.markState || "result";
        return {
          v: !e ? "·" : e.tomb ? "×" : e.key + "@" + e.pos,
          state,
        };
      }),
    };
  }

  /* ---------------------------------------------------------- */
  V.register({
    id: "contains-duplicate-ii",
    title: "Contains Duplicate II",
    category: "Sliding Window",
    difficulty: "Beginner",
    description: "Find equal values whose positions are at most k apart.",
    input: { label: "numbers | k", default: "1, 2, 3, 4, 2 | 3", parse: "tworows" },
    approaches: [
      {
        name: "Last Index in a Hash Table",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Hash each value into an open-addressed slot and keep the newest index where that value appeared.",
          "When the same key probes back to its slot, compare the stored index with i. A gap of at most k answers the question.",
          "The animation splits one loop iteration into hash, probe, compare and update frames, and frames the last k positions of the array.",
        ],
        problem: ["Stale entries are never removed, so the table can grow to n distinct keys and use O(n) memory."],
        code: {
          c: `#include <stdbool.h>
#include <stdlib.h>

typedef struct { int key, pos, used; } Slot;

bool containsNearbyDuplicate(int* nums, int n, int k) {
    int cap = 1;
    while (cap < 2 * n) cap <<= 1;
    Slot* table = calloc(cap, sizeof(Slot));
    for (int i = 0; i < n; i++) {
        int h = ((unsigned)nums[i] * 2654435761u) & (cap - 1);
        while (table[h].used && table[h].key != nums[i]) h = (h + 1) & (cap - 1);
        if (table[h].used && i - table[h].pos <= k) return true;
        table[h].used = 1;
        table[h].key = nums[i];
        table[h].pos = i;
    }
    free(table);
    return false;
}`,
          cpp: `#include <unordered_map>
#include <vector>
using namespace std;

bool containsNearbyDuplicate(vector<int>& nums, int k) {
    unordered_map<int, int> last;
    for (int i = 0; i < (int)nums.size(); i++) {
        auto it = last.find(nums[i]);
        if (it != last.end() && i - it->second <= k) return true;
        last[nums[i]] = i;
    }
    return false;
}`,
        },
        steps(parsed) {
          const nums = (parsed[0] || []).slice();
          const k = Math.max(0, (parsed[1] || [0])[0] | 0);
          const table = makeHashTable(Math.max(8, 2 * nums.length));
          const out = [];

          const win = (i) => ({ from: Math.max(0, i - k), to: i, label: `window ${Math.max(0, i - k)}..${i}`, edges: false });
          const numStates = (i, pair) => nums.map((_, j) => {
            if (pair && (j === pair.a || j === pair.b)) return "good";
            if (j === i) return "read";
            if (j > i) return "idle";
            return j >= i - k ? "done" : "dim";
          });

          out.push({
            title: `Empty hash table, ${table.cap} slots`,
            tracks: [track("numbers", nums, fill(nums.length, "idle")), hashSlotsTrack(table)],
            counters: [count("k", k), count("slots", table.cap), count("entries", 0)],
            happened: `Every value will be hashed into a slot with mask ${table.cap - 1} and will remember its latest index.`,
            why: "A power-of-two capacity turns the hash into a bit mask; a load near one half keeps probe chains short.",
            legend: LEG, legendLabels: TABLE_LEGEND,
            codeLine: 9,
          });

          let found = null;
          for (let i = 0; i < nums.length; i++) {
            const x = nums[i];
            const r = table.find(x);

            out.push({
              title: `Hash ${x} → slot ${r.home}${r.path.length > 1 ? `, probe ${r.path.slice(1).join(" → ")}` : ""}`,
              tracks: [
                track("numbers", nums, numStates(i)),
                hashSlotsTrack(table, {
                  home: r.home,
                  visited: r.path.slice(1),
                  label: `slots: ${x} & ${table.cap - 1} = ${r.home}`,
                }),
              ],
              pointers: [{ index: i, label: "i" }],
              window: win(i),
              counters: [count("hash", r.home), count("probes", r.path.length - 1)],
              happened: r.entry
                ? `Slot ${r.slot} holds ${r.entry.key}@${r.entry.pos}, the last place ${x} was seen.`
                : `Slot ${r.slot} is empty${r.path.length > 1 ? " after " + (r.path.length - 1) + " probe(s)" : ""}, so ${x} has not been stored yet.`,
              why: "The home slot comes from the hash. Linear probing walks forward one slot at a time until the key or an empty slot appears.",
              legend: LEG, legendLabels: TABLE_LEGEND,
              codeLine: 11,
            });

            if (r.entry && i - r.entry.pos <= k) {
              found = { x, i, j: r.entry.pos, slot: r.slot };
              out.push({
                title: `Match ${x}@${r.entry.pos} ↔ ${x}@${i}`,
                tracks: [
                  track("numbers", nums, numStates(i, { a: i, b: r.entry.pos })),
                  hashSlotsTrack(table, { home: r.home, visited: r.path.slice(1), markSlot: r.slot, markState: "good" }),
                ],
                pointers: [{ index: i, label: "i" }, { index: r.entry.pos, label: "j" }],
                window: win(i),
                counters: [count("distance", i - r.entry.pos), count("limit", k)],
                happened: `${i} − ${r.entry.pos} = ${i - r.entry.pos}, which is at most ${k}. Both cells hold ${x}.`,
                why: "Only the newest equal index needs checking: any older copy of x would be even farther away.",
                legend: LEG, legendLabels: TABLE_LEGEND,
                codeLine: 13,
              });
              break;
            }

            const oldPos = r.entry ? r.entry.pos : null;
            table.put(x, i);
            out.push({
              title: oldPos == null ? `Store ${x}@${i} in slot ${r.slot}` : `Refresh ${x}: ${oldPos} → ${i}`,
              tracks: [
                track("numbers", nums, numStates(i)),
                hashSlotsTrack(table, {
                  home: r.home,
                  visited: r.path.slice(1),
                  markSlot: r.slot,
                  markState: oldPos == null ? "result" : "swap",
                }),
              ],
              pointers: [{ index: i, label: "i" }],
              window: win(i),
              counters: [count("read", i + 1, nums.length), count("entries", table.slots.filter(Boolean).length)],
              happened: oldPos == null
                ? `Slot ${r.slot} was empty, so ${x} now remembers index ${i}.`
                : `${x}@${oldPos} was more than ${k} behind, so the slot now keeps the newer index ${i}.`,
              why: "Replacing a stale index is safe: a future equal value only cares about the closest previous one.",
              legend: LEG, legendLabels: TABLE_LEGEND,
              codeLine: oldPos == null ? 15 : 16,
            });
          }

          out.push({
            title: found ? `true — ${found.x} at ${found.j} and ${found.i}` : "false — no close duplicate",
            tracks: [
              track("numbers", nums, nums.map((_, j) => (found && (j === found.j || j === found.i) ? "good" : "done"))),
              hashSlotsTrack(table, found ? { markSlot: found.slot, markState: "good" } : {}),
            ],
            counters: [count("answer", found ? "true" : "false"), count("entries", table.slots.filter(Boolean).length)],
            happened: found
              ? `The pair ${found.x}@${found.j} and ${found.x}@${found.i} sits inside the window of ${k}.`
              : `After ${nums.length} insertions no slot ever produced a distance within ${k}.`,
            why: "One lookup per element checks every pair that could possibly be close enough.",
            legend: LEG, legendLabels: TABLE_LEGEND,
            codeLine: 19,
          });
          return out;
        },
      },
      {
        name: "Bounded Sliding-Window Set",
        complexity: "O(n) time, O(k) space",
        idea: [
          "Keep a hash set of only the values whose indices are in i−k … i−1.",
          "Before each lookup, erase nums[i−k−1]; then any value found in the set is automatically within k positions.",
          "The animation shows the eviction (a tombstone slot), the probe to the matching key, and the insertion that advances the window.",
        ],
        problem: ["Tombstones and a fixed capacity need occasional rebuilding in a real hash set; for a single scan the table of k+1 keys is enough."],
        code: {
          c: `#include <stdbool.h>
#include <stdlib.h>

typedef struct { int key, state; } Slot; /* 0 empty, 1 full, 2 deleted */

static int hashKey(int key, int cap) {
    return ((unsigned)key * 2654435761u) & (cap - 1);
}

static void setPut(Slot* t, int cap, int key) {
    int h = hashKey(key, cap), tomb = -1;
    for (int n = 0; n < cap; n++, h = (h + 1) & (cap - 1)) {
        if (t[h].state == 0) { t[tomb >= 0 ? tomb : h] = (Slot){ key, 1 }; return; }
        if (t[h].state == 2 && tomb < 0) tomb = h;
        if (t[h].state == 1 && t[h].key == key) return;
    }
    if (tomb >= 0) t[tomb] = (Slot){ key, 1 };
}

static bool setHas(Slot* t, int cap, int key) {
    int h = hashKey(key, cap);
    for (int n = 0; n < cap; n++, h = (h + 1) & (cap - 1)) {
        if (t[h].state == 0) return false;
        if (t[h].state == 1 && t[h].key == key) return true;
    }
    return false;
}

static void setErase(Slot* t, int cap, int key) {
    int h = hashKey(key, cap);
    for (int n = 0; n < cap; n++, h = (h + 1) & (cap - 1)) {
        if (t[h].state == 0) return;
        if (t[h].state == 1 && t[h].key == key) { t[h].state = 2; return; }
    }
}

bool containsNearbyDuplicate(int* nums, int n, int k) {
    int cap = 8;
    while (cap < 2 * k + 2) cap <<= 1;
    Slot* t = calloc(cap, sizeof(Slot));
    for (int i = 0; i < n; i++) {
        if (i - k - 1 >= 0) setErase(t, cap, nums[i - k - 1]);
        if (setHas(t, cap, nums[i])) { free(t); return true; }
        setPut(t, cap, nums[i]);
    }
    free(t);
    return false;
}`,
          cpp: `#include <unordered_set>
#include <vector>
using namespace std;

bool containsNearbyDuplicate(vector<int>& nums, int k) {
    unordered_set<int> window;
    for (int i = 0; i < (int)nums.size(); i++) {
        if (i - k - 1 >= 0) window.erase(nums[i - k - 1]);
        if (window.count(nums[i])) return true;
        window.insert(nums[i]);
    }
    return false;
}`,
        },
        steps(parsed) {
          const nums = (parsed[0] || []).slice();
          const k = Math.max(0, (parsed[1] || [0])[0] | 0);
          const table = makeHashTable(Math.max(8, 2 * (k + 1)));
          const out = [];
          let removals = 0;

          const limit = k + 1;
          const win = (i) => ({ from: Math.max(0, i - k), to: i, label: `keep ${Math.max(0, i - k)}..${i}`, edges: false });
          const numStates = (i, opts) => {
            const o = opts || {};
            return nums.map((_, j) => {
              if (j === o.evict) return "bad";
              if (o.pair && (j === o.pair.a || j === o.pair.b)) return "good";
              if (j === i) return "read";
              if (j > i) return "idle";
              return j >= i - k ? "done" : "dim";
            });
          };

          out.push({
            title: `Empty set, at most ${limit} values`,
            tracks: [track("numbers", nums, fill(nums.length, "idle")), hashSlotsTrack(table)],
            counters: [count("k", k), count("slots", table.cap), count("set size", 0, limit)],
            happened: `The set will hold only indices i−${k} … i−1, so a match found inside it is close enough by definition.`,
            why: "Bounding the hash table to k+1 values drops the extra space from O(n) to O(k).",
            legend: LEG, legendLabels: TABLE_LEGEND,
            codeLine: 6,
          });

          let found = null;
          for (let i = 0; i < nums.length; i++) {
            const x = nums[i];
            const drop = i - k - 1;
            if (drop >= 0) {
              const r = table.erase(nums[drop]);
              removals++;
              out.push({
                title: `Slide window: drop ${nums[drop]}@${drop}`,
                tracks: [
                  track("numbers", nums, numStates(i, { evict: drop })),
                  hashSlotsTrack(table, { markSlot: r.found ? r.slot : -1, markState: "bad", label: "set slots" }),
                ],
                pointers: [{ index: drop, label: "out" }, { index: i, label: "i" }],
                window: win(i),
                counters: [count("set size", Math.min(i, limit), limit), count("evicted", removals)],
                happened: r.found
                  ? `Index ${drop} is now too far away, so ${nums[drop]} leaves slot ${r.slot}. The slot becomes a tombstone (×).`
                  : `${nums[drop]} had already left the set, so this slide only moves the frame.`,
                why: "Eviction must happen before the lookup; otherwise a key that is k+1 positions away could be mistaken for a close duplicate.",
                legend: LEG, legendLabels: TABLE_LEGEND,
                codeLine: 8,
              });
            }

            const r = table.find(x);
            out.push({
              title: `Look up ${x}: slot ${r.home}${r.path.length > 1 ? ` → ${r.path.slice(1).join(" → ")}` : ""}`,
              tracks: [
                track("numbers", nums, numStates(i)),
                hashSlotsTrack(table, { home: r.home, visited: r.path.slice(1), label: `set: ${x} & ${table.cap - 1} = ${r.home}` }),
              ],
              pointers: [{ index: i, label: "i" }],
              window: win(i),
              counters: [count("hash", r.home), count("probes", r.path.length - 1)],
              happened: r.found
                ? `${x} is in the window at slot ${r.slot}, so its index is at least ${i - k}.`
                : `${x} is not in the window${r.path.length > 1 ? " after " + (r.path.length - 1) + " probe(s)" : ""}; the probe stops at an empty slot.`,
              why: "Every live entry belongs to the last k positions, so any hit here already satisfies the distance limit.",
              legend: LEG, legendLabels: TABLE_LEGEND,
              codeLine: 9,
            });

            if (r.found) {
              found = { x, i, j: r.entry.pos, slot: r.slot };
              out.push({
                title: `Match ${x}@${r.entry.pos} ↔ ${x}@${i}`,
                tracks: [
                  track("numbers", nums, numStates(i, { pair: { a: i, b: r.entry.pos } })),
                  hashSlotsTrack(table, { home: r.home, visited: r.path.slice(1), markSlot: r.slot, markState: "good" }),
                ],
                pointers: [{ index: i, label: "i" }, { index: r.entry.pos, label: "j" }],
                window: win(i),
                counters: [count("distance", i - r.entry.pos), count("limit", k)],
                happened: `${i} − ${r.entry.pos} = ${i - r.entry.pos} ≤ ${k}; both cells hold ${x}.`,
                why: "The window invariant removes the need to store indices at all — only membership matters.",
                legend: LEG, legendLabels: TABLE_LEGEND,
                codeLine: 9,
              });
              break;
            }

            table.put(x, i);
            out.push({
              title: `Insert ${x}@${i} in slot ${r.slot}`,
              tracks: [
                track("numbers", nums, numStates(i)),
                hashSlotsTrack(table, { home: r.home, visited: r.path.slice(1), markSlot: r.slot, markState: "result" }),
              ],
              pointers: [{ index: i, label: "i" }],
              window: win(i),
              counters: [count("set size", Math.min(i + 1, limit), limit), count("read", i + 1, nums.length)],
              happened: `${x} joins slot ${r.slot}. The window now covers indices ${Math.max(0, i - k)} … ${i}.`,
              why: "Insert the current value after the check so it can only match a strictly earlier index.",
              legend: LEG, legendLabels: TABLE_LEGEND,
              codeLine: 10,
            });
          }

          out.push({
            title: found ? `true — ${found.x} at ${found.j} and ${found.i}` : "false — no close duplicate",
            tracks: [
              track("numbers", nums, nums.map((_, j) => (found && (j === found.j || j === found.i) ? "good" : "done"))),
              hashSlotsTrack(table, found && found.slot >= 0 ? { markSlot: found.slot, markState: "good" } : {}),
            ],
            counters: [count("answer", found ? "true" : "false"), count("max set size", limit)],
            happened: found
              ? `${found.x} appeared at ${found.j} and ${found.i}, both inside a window of ${k}.`
              : `The window never held a repeated value within ${k} positions.`,
            why: "Only k+1 values are ever live, so the table stays small even for a very long array.",
            legend: LEG, legendLabels: TABLE_LEGEND,
            codeLine: 12,
          });
          return out;
        },
      },
    ],
  });
})();
