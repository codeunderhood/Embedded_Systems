/* ============================================================
   DSA Visuals — Extra Queues & Deques
   Six further LeetCode problems that are not part of NeetCode 250:
   a moving average, recent calls, ticket lines, lunch preferences,
   a shortest subarray via a monotonic deque and a front-middle-back
   queue built from two deques.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const frame = (title, tracks, counters, happened, why, codeLine, extra) =>
    Object.assign({ title, tracks, counters, happened, why, legend: LEG, codeLine }, extra || {});
  const row = (p, i) => (Array.isArray(p) && Array.isArray(p[i]) ? p[i] : []);
  const ops = (text) => String(text || "").split(";").map((s) => s.trim()).filter(Boolean);
  const show = (a) => "[" + a.join(", ") + "]";

  /* ---------------------------------------------------------- */
  V.register({
    id: "moving-average-from-data-stream",
    title: "Moving Average from Data Stream",
    category: "Queue / Deque",
    difficulty: "Beginner",
    description:
      "Keep the last size values in a queue and report their average as each new value arrives.",
    input: { label: "values | size", default: "1, 10, 3, 5 | 3", parse: "tworows" },
    approaches: [
      {
        name: "Queue Plus Running Sum",
        complexity: "O(1) per value, O(size) space",
        idea: [
          "Append every arriving value to a queue and add it to a running sum.",
          "When the queue is longer than size, remove the front value and subtract it; once the length equals size, divide the sum by size.",
        ],
        problem: [
          "Adding up the whole window on every arrival costs O(size). Keeping the sum beside the queue makes each answer constant time.",
        ],
        code: {
          c: `#include <stdio.h>


int main(void) {
    int a[] = {1, 10, 3, 5};
    int size = 3, q[64], head = 0, tail = 0, sum = 0;

    for (int i = 0; i < 4; i++) {
        q[tail++] = a[i];
        sum += a[i];
        if (tail - head > size)
            sum -= q[head++];
        if (tail - head == size)
            printf("%.2f ", (double)sum / size);
    }
    return 0;
}`,
          cpp: `#include <iostream>
#include <queue>

int main() {
    int a[] = {1, 10, 3, 5};
    int size = 3, sum = 0; queue<int> q;

    for (int x : a) {
        q.push(x);
        sum += x;
        if ((int)q.size() > size)
            { sum -= q.front(); q.pop(); }
        if ((int)q.size() == size)
            cout << (double)sum / size << ' ';
    }
}`,
        },
        steps(parsed) {
          const a = row(parsed, 0);
          const size = Math.max(1, row(parsed, 1)[0] || 1);
          const steps = [];
          const q = [];
          const out = [];
          let sum = 0;
          const fmt = (v) => (Number.isInteger(v) ? String(v) : v.toFixed(2));
          const qTrack = (states) =>
            track("queue (front → back)", q.length ? q : ["—"], states || fill(q.length, "idle"),
              q.length ? q.map((_, j) => (j === 0 ? "front" : j === q.length - 1 ? "back" : "")) : [""]);

          steps.push(frame(
            "Window size " + size + ": queue empty, sum 0",
            [track("values", a, fill(a.length, "idle")), qTrack()],
            [count("values", 0, a.length), count("sum", 0), count("averages", 0)],
            "Each value joins the back of the queue and the running sum.",
            "The queue alone cannot give the sum quickly, so both are kept together.",
            5
          ));
          for (let i = 0; i < a.length; i++) {
            q.push(a[i]);
            sum += a[i];
            steps.push(frame(
              "Value " + a[i] + " joins the queue; sum " + sum,
              [track("values", a, a.map((_, j) => (j === i ? "read" : j < i ? "done" : "idle"))), qTrack(fill(q.length, "active"))],
              [count("values", i + 1, a.length), count("sum", sum), count("queue size", q.length, size)],
              a[i] + " was appended at the back and added to the running sum.",
              "The queue remembers exactly which values have arrived so far.",
              8,
              { pointers: [{ index: i, label: "i" }], window: { from: Math.max(0, i - size + 1), to: i, track: 0, label: "window" } }
            ));
            if (q.length > size) {
              const gone = q.shift();
              sum -= gone;
              steps.push(frame(
                "Queue too long: drop front value " + gone,
                [track("values", a, a.map((_, j) => (j <= i - size ? "dim" : j === i ? "read" : "done"))), qTrack(fill(q.length, "compare"))],
                [count("values", i + 1, a.length), count("sum", sum), count("queue size", q.length, size)],
                gone + " left the front of the window and was subtracted from the sum.",
                "The value that arrived size steps ago is the only one that can expire.",
                11
              ));
            }
            if (q.length === size) {
              out.push(fmt(sum / size));
              steps.push(frame(
                "Full window: average " + out[out.length - 1],
                [track("values", a, a.map((_, j) => (j > i - size && j <= i ? "active" : "done"))), qTrack(fill(q.length, "result")), track("averages", out, fill(out.length, "result"))],
                [count("values", i + 1, a.length), count("sum", sum), count("averages", out.length)],
                "The sum " + sum + " divided by " + size + " gives " + out[out.length - 1] + ".",
                "Dividing the running sum is constant work because the queue already limits the window.",
                13,
                { window: { from: i - size + 1, to: i, track: 0, label: "current window" } }
              ));
            }
          }
          steps.push(frame(
            "Answer: averages " + show(out),
            [track("values", a, fill(a.length, "done")), track("averages", out.length ? out : ["—"], "result")],
            [count("values", a.length, a.length), count("averages", out.length)],
            out.length + " window" + (out.length === 1 ? "" : "s") + " were averaged.",
            "Each value entered and left the queue exactly once.",
            13
          ));
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "number-of-recent-calls",
    title: "Number of Recent Calls",
    category: "Queue / Deque",
    difficulty: "Beginner",
    description:
      "Count ping calls whose timestamp falls within the last 3000 milliseconds.",
    input: { label: "timestamps", default: "1, 2, 3, 1001, 1002", parse: "ints" },
    approaches: [
      {
        name: "Queue Of Call Times",
        complexity: "O(1) amortized per ping, O(k) space",
        idea: [
          "Store each call time in a queue from oldest to newest.",
          "Before answering, remove every time at or before now − 3000; the queue length is the recent-call count.",
        ],
        problem: [
          "Timestamps arrive in non-decreasing order, so only calls at the front of the queue can ever expire.",
        ],
        code: {
          c: `#include <stdio.h>


int main(void) {
    int t[] = {1, 2, 3, 1001, 1002};
    int q[64], head = 0, tail = 0;

    for (int i = 0; i < 5; i++) {
        q[tail++] = t[i];
        while (head < tail && q[head] <= t[i] - 3000)
            head++;
        printf("%d ", tail - head);
    }
    return 0;
}`,
          cpp: `#include <iostream>
#include <queue>

int main() {
    int t[] = {1, 2, 3, 1001, 1002};
    queue<int> q;

    for (int x : t) {
        q.push(x);
        while (!q.empty() && q.front() <= x - 3000)
            q.pop();
        cout << q.size() << ' ';
    }
}`,
        },
        steps(values) {
          const a = Array.isArray(values) ? values : [];
          const q = [];
          const out = [];
          const steps = [];
          const qTrack = (states) =>
            track("calls (oldest → newest)", q.length ? q : ["—"], states || fill(q.length, "idle"),
              q.length ? q.map((_, j) => (j === 0 ? "oldest" : j === q.length - 1 ? "newest" : "")) : [""]);

          steps.push(frame(
            "Empty call log; the window covers 3000 ms",
            [track("timestamps", a, fill(a.length, "idle")), qTrack(), track("window edges", ["—"], "dim")],
            [count("calls read", 0, a.length), count("recent", 0)],
            "Every ping appends a timestamp and then discards times older than the window.",
            "A queue keeps the calls in arrival order, so expired calls are always at the front.",
            5
          ));
          for (let i = 0; i < a.length; i++) {
            const t = a[i];
            q.push(t);
            steps.push(frame(
              "ping(" + t + ") appended to the queue",
              [track("timestamps", a, a.map((_, j) => (j === i ? "read" : j < i ? "done" : "idle"))), qTrack(fill(q.length, "active")), track("window edges", [t - 3000, t], "compare", ["oldest allowed", "now"])],
              [count("calls read", i + 1, a.length), count("recent", q.length)],
              "The new call was placed at the back of the log.",
              "It cannot expire until a later call is more than 3000 ms ahead of it.",
              8,
              { pointers: [{ index: i, label: "t" }] }
            ));
            let dropped = 0;
            while (q.length && q[0] <= t - 3000) {
              q.shift();
              dropped++;
            }
            if (dropped) {
              steps.push(frame(
                dropped + " call" + (dropped === 1 ? "" : "s") + " fell outside the window",
                [track("timestamps", a, a.map((_, j) => (j <= i ? "done" : "idle"))), qTrack(fill(q.length, "compare")), track("window edges", [t - 3000, t], "bad", ["oldest allowed", "now"])],
                [count("calls read", i + 1, a.length), count("recent", q.length), count("dropped", dropped)],
                "Calls with time at or before " + (t - 3000) + " were removed from the front.",
                "Once a call expires it can never become recent again.",
                10
              ));
            }
            out.push(q.length);
            steps.push(frame(
              "ping(" + t + ") → " + q.length + " recent calls",
              [track("timestamps", a, a.map((_, j) => (j === i ? "read" : j < i ? "done" : "idle"))), qTrack(fill(q.length, "result")), track("window edges", [t - 3000, t], "result", ["oldest allowed", "now"])],
              [count("calls read", i + 1, a.length), count("recent", q.length), count("answers", out.length)],
              "There are " + q.length + " timestamps still inside the 3000 ms window.",
              "The queue length is the answer; nothing needs to be counted from scratch.",
              11
            ));
          }
          steps.push(frame(
            "Answer: recent counts " + show(out),
            [track("timestamps", a, fill(a.length, "done")), track("counts", out, "result")],
            [count("calls read", a.length, a.length), count("answers", out.length)],
            out.length + " pings were answered in arrival order.",
            "Each call enters once and leaves at most once.",
            11
          ));
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "time-needed-to-buy-tickets",
    title: "Time Needed to Buy Tickets",
    category: "Queue / Deque",
    difficulty: "Beginner",
    description:
      "Simulate a ticket line and find the second at which the person at index k finishes buying.",
    input: { label: "tickets | k", default: "2, 3, 2 | 1", parse: "tworows" },
    approaches: [
      {
        name: "Queue Of People Indices",
        complexity: "O(total tickets) time, O(n) space",
        idea: [
          "Put every person's index into a queue. Each second the front person buys one ticket.",
          "If they still need tickets they rejoin the back; otherwise they leave. Stop when the target index leaves.",
        ],
        problem: [
          "Carrying indices, not just ticket counts, is what lets the simulation notice when the particular person k is done.",
        ],
        code: {
          c: `#include <stdio.h>


int main(void) {
    int tickets[] = {2, 3, 2};
    int k = 1, q[64], head = 0, tail = 0, time = 0;

    for (int i = 0; i < 3; i++) q[tail++] = i;

    while (head < tail) {
        int p = q[head++];
        tickets[p]--;
        time++;
        if (tickets[p] == 0) {
            if (p == k) break;
        } else {
            q[tail++] = p;
        }
    }
    printf("%d ", time);
    return 0;
}`,
          cpp: `#include <iostream>
#include <queue>

int main() {
    int tickets[] = {2, 3, 2};
    int k = 1, time = 0; queue<int> q;

    for (int i = 0; i < 3; i++) q.push(i);

    while (!q.empty()) {
        int p = q.front(); q.pop();
        tickets[p]--;
        time++;
        if (tickets[p] == 0) {
            if (p == k) break;
        } else {
            q.push(p);
        }
    }
    cout << time << ' ';
}`,
        },
        steps(parsed) {
          const tickets = row(parsed, 0).slice();
          const k = Math.max(0, Math.floor(row(parsed, 1)[0] || 0));
          const q = tickets.map((_, i) => i);
          const steps = [];
          let time = 0;
          const qTrack = (frontState, target) =>
            track("line (front → back)", q.length ? q.map((i) => "p" + i + ":" + tickets[i]) : ["—"],
              q.length ? q.map((_, j) => (j === 0 ? frontState || "active" : "done")) : "dim",
              q.length ? q.map((i, j) => (j === 0 ? "front" : i === k ? "target" : "")) : [""]);
          const tTrack = (p, state) =>
            track("tickets left", tickets.length ? tickets : ["—"],
              tickets.length ? tickets.map((v, i) => (i === p ? state || "compare" : v === 0 ? "done" : "idle")) : "dim");

          steps.push(frame(
            "Line starts in index order; person " + k + " is the target",
            [tTrack(-1, "idle"), qTrack("result", k)],
            [count("second", 0), count("tickets left", tickets.reduce((s, v) => s + v, 0)), count("in line", q.length)],
            "Nobody has bought a ticket yet; the queue holds indices 0 … n−1.",
            "A first-in-first-out queue is exactly the order in which people buy.",
            7
          ));
          let guard = 0;
          while (q.length && guard++ < 100000) {
            const p = q.shift();
            tickets[p]--;
            time++;
            const needed = tickets[p] > 0;
            steps.push(frame(
              "Second " + time + ": person " + p + " buys one ticket" + (needed ? "" : " and finishes"),
              [tTrack(p, needed ? "active" : "good"), qTrack("active", k), track("events", ["t=" + time, "p" + p + " bought"], fill(2, "read"))],
              [count("second", time), count("tickets left", tickets.reduce((s, v) => s + v, 0)), count("in line", q.length)],
              needed
                ? "Person " + p + " still needs " + tickets[p] + " more ticket" + (tickets[p] === 1 ? "" : "s") + "."
                : "Person " + p + " has no tickets left and leaves the line.",
              "One second buys exactly one ticket, so the time counter and the simulation advance together.",
              needed ? 11 : 13
            ));
            if (!needed) {
              if (p === k) break;
            } else {
              q.push(p);
              steps.push(frame(
                "Person " + p + " rejoins the back of the line",
                [tTrack(p, "done"), qTrack("compare", k), track("events", ["t=" + time, "p" + p + " requeued"], ["done", "active"])],
                [count("second", time), count("tickets left", tickets.reduce((s, v) => s + v, 0)), count("in line", q.length)],
                "The front person moved to the back with " + tickets[p] + " ticket" + (tickets[p] === 1 ? "" : "s") + " remaining.",
                "Requeuing preserves the cyclic order of a real ticket line.",
                16
              ));
            }
          }
          steps.push(frame(
            "Answer: " + time + " seconds",
            [tTrack(-1, "idle"), qTrack("result", k), track("answer", [time], "result")],
            [count("second", time), count("target", k), count("finished", "yes")],
            "Person " + k + " left the line at second " + time + ".",
            "Stopping at the target avoids simulating seconds that cannot change the answer.",
            19
          ));
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "students-unable-to-eat-lunch",
    title: "Students Unable to Eat Lunch",
    category: "Queue / Deque",
    difficulty: "Beginner",
    description:
      "Rotate students who dislike the front lunch until somebody eats; 0 means circular and 1 means square.",
    input: { label: "students | preferences", default: "1, 1, 0, 0 | 0, 1, 0, 1", parse: "tworows" },
    approaches: [
      {
        name: "Student Queue Plus Lunch Queue",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Keep student indices in a queue and the lunch types in a second queue. Compare the front student with the front lunch.",
          "A match eats both. A mismatch sends the student to the back and raises a skip counter; when skips equals the queue length nobody can eat.",
        ],
        problem: [
          "Without the skip counter a full cycle of mismatches would repeat forever, even though no remaining student wants the front lunch.",
        ],
        code: {
          c: `#include <stdio.h>


int main(void) {
    int want[] = {1, 1, 0, 0};
    int lunch[] = {0, 1, 0, 1};
    int sq[64], lq[64], sh = 0, st = 0, lh = 0, lt = 0;

    for (int i = 0; i < 4; i++) { sq[st++] = i; lq[lt++] = lunch[i]; }

    int skips = 0;
    while (sh < st && skips < st - sh) {
        int s = sq[sh];
        if (want[s] == lq[lh]) {
            sh++; lh++; skips = 0;
        } else {
            sq[st++] = s; sh++; skips++;
        }
    }
    printf("%d ", st - sh);
    return 0;
}`,
          cpp: `#include <iostream>
#include <queue>

int main() {
    int want[] = {1, 1, 0, 0};
    int lunch[] = {0, 1, 0, 1};
    queue<int> sq, lq;

    for (int i = 0; i < 4; i++) { sq.push(i); lq.push(lunch[i]); }

    int skips = 0;
    while (!sq.empty() && skips < (int)sq.size()) {
        int s = sq.front(); sq.pop();
        if (want[s] == lq.front()) {
            lq.pop(); skips = 0;
        } else {
            sq.push(s); skips++;
        }
    }
    cout << sq.size() << ' ';
}`,
        },
        steps(parsed) {
          const want = row(parsed, 0);
          const lunch = row(parsed, 1).slice();
          const n = Math.min(want.length, lunch.length);
          const q = Array.from({ length: n }, (_, i) => i);
          const steps = [];
          const sym = (v) => (v === 1 ? "sq" : "ci");
          let skips = 0;
          let eaten = 0;
          let guard = 0;
          const qTrack = (state) =>
            track("students (front → back)", q.length ? q.map((i) => "s" + i + ":" + sym(want[i])) : ["—"],
              q.length ? q.map((_, j) => (j === 0 ? state || "compare" : "done")) : "dim",
              q.length ? q.map((_, j) => (j === 0 ? "front" : j === q.length - 1 ? "back" : "")) : [""]);
          const lTrack = (state) =>
            track("lunch tray (front → back)", lunch.length ? lunch.map(sym) : ["—"],
              lunch.length ? lunch.map((_, j) => (j === 0 ? state || "compare" : "idle")) : "dim",
              lunch.length ? lunch.map((_, j) => (j === 0 ? "front" : "")) : [""]);

          steps.push(frame(
            "Two queues: students by index, lunches by type",
            [qTrack("result"), lTrack("idle"), track("code", ["0=ci", "1=sq"], "dim")],
            [count("students", q.length, n), count("lunches", lunch.length, n), count("eaten", 0)],
            "The first row gives each student's preference; the second row is the lunch tray in order.",
            "Only the two front entries can be compared; everyone else waits.",
            8
          ));
          while (q.length && lunch.length && skips < q.length && guard++ < 100000) {
            const s = q[0];
            const match = want[s] === lunch[0];
            if (match) {
              q.shift();
              lunch.shift();
              skips = 0;
              eaten++;
              steps.push(frame(
                "Student " + s + " wants " + sym(want[s]) + " and eats it",
                [qTrack("result"), lTrack("good"), track("last match", ["s" + s + " ↔ " + sym(want[s])], "good")],
                [count("students", q.length, n), count("lunches", lunch.length, n), count("eaten", eaten, n)],
                "Both front entries matched, so the student and that lunch leave their queues.",
                "Skips reset to zero because a real meal has just been served.",
                14
              ));
            } else {
              q.push(q.shift());
              skips++;
              steps.push(frame(
                "Student " + s + " wants " + sym(want[s]) + " but the tray has " + sym(lunch[0]) + " → rotate",
                [qTrack("compare"), lTrack("bad"), track("skips", [skips + "/" + q.length], "active")],
                [count("students", q.length, n), count("lunches", lunch.length, n), count("skips", skips, q.length)],
                "The front student moved to the back without eating.",
                "A full round of skips with no meal proves the remaining students cannot eat.",
                16
              ));
            }
          }
          steps.push(frame(
            "Answer: " + q.length + " student" + (q.length === 1 ? "" : "s") + " cannot eat",
            [qTrack("bad"), lTrack("dim"), track("answer", [q.length], "result")],
            [count("eaten", eaten, n), count("left", q.length, n), count("stalled", "yes")],
            skips >= q.length && q.length
              ? "A whole cycle passed with no match, so the process stops."
              : "The trays or the line ran out; " + eaten + " students ate.",
            "The skip counter turns an endless cycle into a finite, correct simulation.",
            19
          ));
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "shortest-subarray-with-sum-at-least-k",
    title: "Shortest Subarray with Sum at Least K",
    category: "Queue / Deque",
    difficulty: "Advanced",
    description:
      "Find the shortest subarray whose sum is at least k using a deque of increasing prefix-sum indices.",
    input: { label: "numbers | k", default: "2, -1, 2, 1, 3 | 5", parse: "tworows" },
    approaches: [
      {
        name: "Monotonic Deque Of Prefix Indices",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Build prefix sums and store their indices in a deque whose prefix values strictly increase.",
          "From the front, close the oldest valid subarray; from the back, discard indices whose prefix is at least the current prefix, since they can never start a better answer.",
        ],
        problem: [
          "Negative numbers break the sliding-window trick. The increasing-prefix deque handles them because each index is dropped at most once.",
        ],
        code: {
          c: `#include <stdio.h>


int main(void) {
    int a[] = {2, -1, 2, 1, 3};
    int n = 5, k = 5, prefix[64], dq[64], head = 0, tail = 0;
    prefix[0] = 0; dq[tail++] = 0;
    int best = n + 1;

    for (int i = 1; i <= n; i++) {
        prefix[i] = prefix[i - 1] + a[i - 1];
        while (head < tail && prefix[i] - prefix[dq[head]] >= k) {
            int len = i - dq[head++];
            if (len < best) best = len;
        }
        while (head < tail && prefix[dq[tail - 1]] >= prefix[i]) tail--;
        dq[tail++] = i;
    }
    printf("%d ", best <= n ? best : -1);
    return 0;
}`,
          cpp: `#include <iostream>
#include <deque>

int main() {
    int a[] = {2, -1, 2, 1, 3};
    int n = 5, k = 5, prefix[64] = {0}; deque<int> dq(1, 0);
    int best = n + 1;

    for (int i = 1; i <= n; i++) {
        prefix[i] = prefix[i - 1] + a[i - 1];
        while (!dq.empty() && prefix[i] - prefix[dq.front()] >= k) {
            int len = i - dq.front(); dq.pop_front();
            if (len < best) best = len;
        }
        while (!dq.empty() && prefix[dq.back()] >= prefix[i]) dq.pop_back();
        dq.push_back(i);
    }
    cout << (best <= n ? best : -1) << ' ';
}`,
        },
        steps(parsed) {
          const a = row(parsed, 0);
          const k = Math.floor(row(parsed, 1)[0] || 0);
          const n = a.length;
          const prefix = [0].concat(Array(n).fill(null));
          const dq = [0];
          const steps = [];
          let best = n + 1;
          let range = null;
          const pVals = () => prefix.map((v) => (v == null ? "—" : v));
          const pStates = (i) => prefix.map((_, j) => (j === i ? "read" : j <= i ? "done" : "idle"));
          const dqTrack = (states, tags) =>
            track("deque: prefix indices", dq.length ? dq.map((i) => "i" + i + ":P" + prefix[i]) : ["—"],
              states || fill(dq.length, "idle"),
              tags || (dq.length ? dq.map((_, j) => (j === 0 ? "front" : j === dq.length - 1 ? "back" : "")) : [""]));
          const nStates = (i, lo, hi) =>
            a.map((_, j) => (j === i - 1 ? "read" : lo != null && j >= lo && j <= hi ? "result" : j < i - 1 ? "done" : "idle"));

          steps.push(frame(
            "Seed prefix[0] = 0 and deque [i0]",
            [track("numbers", a, fill(a.length, "idle")), track("prefix sums", pVals(), fill(n + 1, "idle")), dqTrack(fill(dq.length, "result"))],
            [count("prefix index", 0, n), count("best length", "∞"), count("k", k)],
            "Index 0 is the start of a subarray beginning at the first element.",
            "Every candidate subarray is prefix[i] − prefix[start].",
            6
          ));
          for (let i = 1; i <= n; i++) {
            prefix[i] = prefix[i - 1] + a[i - 1];
            steps.push(frame(
              "Prefix at i" + i + " is " + prefix[i],
              [track("numbers", a, nStates(i, null, null)), track("prefix sums", pVals(), pStates(i)), dqTrack()],
              [count("prefix index", i, n), count("prefix sum", prefix[i]), count("best length", best <= n ? best : "∞")],
              "Adding a[" + (i - 1) + "] = " + a[i - 1] + " to prefix " + prefix[i - 1] + " gives " + prefix[i] + ".",
              "The prefix value at i will be compared with the deque's front and back.",
              10,
              { pointers: [{ index: i, label: "P" }] }
            ));
            while (dq.length && prefix[i] - prefix[dq[0]] >= k) {
              const start = dq.shift();
              const diff = prefix[i] - prefix[start];
              const len = i - start;
              if (len < best) {
                best = len;
                range = [start, i - 1];
              }
              steps.push(frame(
                "Subarray " + start + ".." + (i - 1) + " sums " + diff + " ≥ " + k + ", length " + len,
                [track("numbers", a, nStates(i, start, i - 1)), track("prefix sums", pVals(), pStates(i)), dqTrack(fill(dq.length, "done")), track("candidate", ["i" + start + " → i" + i, "sum " + diff, "len " + len], "result")],
                [count("prefix index", i, n), count("best length", best <= n ? best : "∞"), count("candidates", (range ? 1 : 0))],
                "P" + i + " − P" + start + " = " + diff + " reaches k, so indices " + start + ".." + (i - 1) + " qualify.",
                "Once a start produces a valid subarray it can be discarded: later ends only make it longer.",
                12,
                { window: { from: start, to: i - 1, track: 0, label: "candidate" }, pointers: [{ index: i, label: "P" }] }
              ));
            }
            while (dq.length && prefix[dq[dq.length - 1]] >= prefix[i]) {
              const removed = dq.pop();
              steps.push(frame(
                "Pop back index " + removed + ": prefix " + prefix[removed] + " ≥ " + prefix[i],
                [track("numbers", a, nStates(i, null, null)), track("prefix sums", pVals(), pStates(i)), dqTrack(fill(dq.length, "done")), track("removed from back", ["i" + removed + ":P" + prefix[removed]], "bad")],
                [count("prefix index", i, n), count("best length", best <= n ? best : "∞"), count("deque size", dq.length)],
                "That back index offers a larger-or-equal prefix at a later position, so it is useless.",
                "Keeping prefixes strictly increasing makes the front the best possible start.",
                15
              ));
            }
            dq.push(i);
            steps.push(frame(
              "Push index " + i + " onto the deque",
              [track("numbers", a, nStates(i, null, null)), track("prefix sums", pVals(), pStates(i)), dqTrack(fill(dq.length, "result"))],
              [count("prefix index", i, n), count("best length", best <= n ? best : "∞"), count("deque size", dq.length)],
              "Index " + i + " joins the back with prefix " + prefix[i] + ".",
              "Each index is pushed once and removed at most once, so the total work is linear.",
              16
            ));
          }
          steps.push(frame(
            "Answer: " + (best <= n ? best : -1),
            [track("numbers", a, a.map((_, j) => (range && j >= range[0] && j <= range[1] ? "result" : "dim"))), track("prefix sums", pVals(), fill(n + 1, "done")), dqTrack(fill(dq.length, "done")), track("answer", [best <= n ? best : -1], "result")],
            [count("best length", best <= n ? best : -1), count("range", range ? range.join("..") : "none")],
            range ? "The shortest qualifying subarray is " + range[0] + ".." + range[1] + "." : "No subarray reached k.",
            "The monotonic deque considered every possible start without a quadratic scan.",
            18,
            range ? { window: { from: range[0], to: range[1], track: 0, label: "answer" } } : null
          ));
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "design-front-middle-back-queue",
    title: "Design Front Middle Back Queue",
    category: "Queue / Deque",
    difficulty: "Intermediate",
    description:
      "Support pushes and pops at the front, middle and back with two deques that keep the halves balanced.",
    input: {
      label: "operations",
      default: "pushFront 1 ; pushBack 2 ; pushMiddle 3 ; popFront ; popMiddle ; popBack",
      parse: "string",
    },
    approaches: [
      {
        name: "Two Balanced Deques",
        complexity: "O(1) per operation, O(n) space",
        idea: [
          "Deque A holds the first half and deque B the second half, with |A| equal to |B| or one larger.",
          "pushMiddle moves A's back to B's front before appending; popMiddle takes from A when it is larger, otherwise from B. Rebalance after every change.",
        ],
        problem: [
          "The middle is at A's back, so an unbalanced A would make middle operations target the wrong element; the size invariant is what keeps them constant time.",
        ],
        code: {
          c: `#include <stdio.h>


int A[64], B[64], ah = 32, at = 32, bh = 32, bt = 32;

void rebalance(void) {
    while (at - ah < bt - bh) A[at++] = B[bh++];
    while (at - ah > bt - bh + 1) B[--bh] = A[--at];
}

int main(void) {
    int v = 0;
    A[--ah] = 1; rebalance();
    B[bt++] = 2; rebalance();
    if (at - ah > bt - bh) B[--bh] = A[--at];
    A[at++] = 3;
    v = A[ah++]; rebalance();
    if (at - ah > bt - bh) v = A[--at];
    else v = B[bh++]; rebalance();
    if (bh == bt) B[--bh] = A[--at];
    v = B[--bt]; rebalance();
    printf("%d ", v);
    return 0;
}`,
          cpp: `#include <iostream>
#include <deque>
using std::deque;
// A holds the front half, B the back half

void rebalance(deque<int>& a, deque<int>& b) {
    while (a.size() < b.size()) { a.push_back(b.front()); b.pop_front(); }
    while (a.size() > b.size() + 1) { b.push_front(a.back()); a.pop_back(); }
}

int main() {
    deque<int> A, B;
    A.push_front(1); rebalance(A, B);
    B.push_back(2); rebalance(A, B);
    if (A.size() > B.size()) { B.push_front(A.back()); A.pop_back(); }
    A.push_back(3);
    int v = A.front(); A.pop_front(); rebalance(A, B);
    if (A.size() > B.size()) v = A.back(), A.pop_back();
    else v = B.front(), B.pop_front(); rebalance(A, B);
    if (B.empty()) { B.push_front(A.back()); A.pop_back(); }
    v = B.back(); B.pop_back(); rebalance(A, B);
    cout << v << ' ';
}`,
        },
        steps(text) {
          const list = ops(text);
          const A = [];
          const B = [];
          const popped = [];
          const steps = [];
          const rebalance = () => {
            while (A.length < B.length) A.push(B.shift());
            while (A.length > B.length + 1) B.unshift(A.pop());
          };
          const tracks = (mark) => [
            track("first half A", A.length ? A : ["—"],
              A.length ? A.map((_, j) => (mark && mark.side === "A" && mark.index === j ? mark.state : "idle")) : "dim",
              A.length ? A.map((_, j) => (j === 0 ? "front" : j === A.length - 1 ? "mid" : "")) : [""]),
            track("second half B", B.length ? B : ["—"],
              B.length ? B.map((_, j) => (mark && mark.side === "B" && mark.index === j ? mark.state : "idle")) : "dim",
              B.length ? B.map((_, j) => (j === B.length - 1 ? "back" : "")) : [""]),
            track("full queue", A.concat(B).length ? A.concat(B) : ["—"], "done",
              A.concat(B).length ? A.concat(B).map((_, j, all) => (j === 0 ? "front" : j === all.length - 1 ? "back" : "")) : [""]),
            track("popped", popped.length ? popped : ["—"], popped.length ? "result" : "dim"),
          ];
          const counters = (i) => [count("operations", i, list.length), count("size", A.length + B.length), count("A / B", A.length + " / " + B.length)];
          const add = (title, happened, why, codeLine, mark, i) =>
            steps.push(frame(title, tracks(mark), counters(i), happened, why, codeLine));

          add("Two empty deques; A holds at most one extra value",
            "The full queue is read as A followed by B.",
            "Keeping the halves within one of each other puts the middle at A's back.", 5, null, 0);

          for (let i = 0; i < list.length; i++) {
            const words = list[i].split(/\s+/);
            const name = words[0].toLowerCase();
            const value = parseInt(words[1], 10);
            const valid = Number.isFinite(value);
            if (name === "pushfront") {
              if (valid) {
                A.unshift(value);
                rebalance();
                add(list[i] + " → front is " + value,
                  value + " joined the front of A and the halves were rebalanced.",
                  "Pushing at the front of A keeps it the first half of the logical queue.", 12, { side: "A", index: 0, state: "good" }, i + 1);
              } else {
                add(list[i] + " → ignored", "No whole value followed pushFront.", "A malformed instruction is reported instead of guessed.", 12, null, i + 1);
              }
            } else if (name === "pushback") {
              if (valid) {
                B.push(value);
                rebalance();
                add(list[i] + " → back is " + value,
                  value + " joined the back of B; rebalancing may move its front into A.",
                  "The logical back is always the back of B.", 13, { side: "B", index: B.length - 1, state: "good" }, i + 1);
              } else {
                add(list[i] + " → ignored", "No whole value followed pushBack.", "A malformed instruction is reported instead of guessed.", 13, null, i + 1);
              }
            } else if (name === "pushmiddle") {
              if (valid) {
                let moved = null;
                if (A.length > B.length) {
                  moved = A.pop();
                  B.unshift(moved);
                }
                A.push(value);
                add(list[i] + " → middle is " + value,
                  moved != null ? "A was one longer, so " + moved + " moved to B's front before " + value + " entered A." : value + " entered A at the middle position.",
                  "A's back is the middle slot once the sizes differ by at most one.", 14, { side: "A", index: A.length - 1, state: "good" }, i + 1);
              } else {
                add(list[i] + " → ignored", "No whole value followed pushMiddle.", "A malformed instruction is reported instead of guessed.", 14, null, i + 1);
              }
            } else if (name === "popfront") {
              if (!A.length && B.length) rebalance();
              if (!A.length) {
                add(list[i] + " → empty", "There is no front value to remove.", "Empty is a legal state for this structure.", 16, null, i + 1);
              } else {
                const v = A.shift();
                popped.push(v);
                rebalance();
                add(list[i] + " → " + v,
                  "The front of A was removed, then the halves were rebalanced.",
                  "Rebalancing restores |A| = |B| or |A| = |B| + 1.", 16, { side: "A", index: 0, state: "bad" }, i + 1);
              }
            } else if (name === "popmiddle") {
              if (!A.length && !B.length) {
                add(list[i] + " → empty", "Both halves are empty, so there is no middle.", "Nothing can be popped from an empty structure.", 17, null, i + 1);
              } else {
                let v;
                let side;
                if (A.length > B.length) {
                  v = A.pop(); side = "A";
                } else {
                  v = B.shift(); side = "B";
                }
                popped.push(v);
                rebalance();
                add(list[i] + " → " + v,
                  "The middle value came from the " + (side === "A" ? "back of A" : "front of B") + ".",
                  "Which half owns the middle depends only on the size invariant.", 17, { side, index: 0, state: "bad" }, i + 1);
              }
            } else if (name === "popback") {
              if (!A.length && !B.length) {
                add(list[i] + " → empty", "Both halves are empty, so there is no back.", "Nothing can be popped from an empty structure.", 19, null, i + 1);
              } else {
                if (!B.length && A.length) B.unshift(A.pop());
                const v = B.pop();
                popped.push(v);
                rebalance();
                add(list[i] + " → " + v,
                  "The back of B was removed and the halves were rebalanced.",
                  "The logical back lives at the back of B after rebalancing.", 19, { side: "B", index: 0, state: "bad" }, i + 1);
              }
            } else {
              add(list[i] + " → ignored", "The operation name is not recognised.", "Unknown instructions are announced without changing the structure.", 12, null, i + 1);
            }
          }
          steps.push(frame(
            "Final queue: " + (A.concat(B).length ? show(A.concat(B)) : "empty"),
            tracks(null),
            [count("operations", list.length, list.length), count("size", A.length + B.length), count("popped", popped.length)],
            "All " + list.length + " operations were applied in order.",
            "Two deques give constant-time access to both ends and the middle.",
            21,
            { pointers: A.concat(B).length ? [{ index: 0, label: "front", track: 2 }, { index: A.concat(B).length - 1, label: "back", track: 2 }] : null }
          ));
          return steps;
        },
      },
    ],
  });
})();
