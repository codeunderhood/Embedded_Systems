/* ============================================================
   DSA Visuals — Heaps & Top-K II
   Scheduling, upgrading and windowed medians: each one keeps a
   priority structure at the centre of the decision.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const chars = (text) => Array.from(String(text || ""));
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const list = (text) => String(text || "").split(/[\s,]+/).filter(Boolean);
  const nums = (text) => list(text).map(Number);
  const show = (a) => `[${a.join(", ")}]`;
  const median = (sorted) => {
    const n = sorted.length;
    return n % 2 ? sorted[(n - 1) / 2] : (sorted[n / 2 - 1] + sorted[n / 2]) / 2;
  };

  /* ---------------------------------------------------------- */
  V.register({
    id: "reorganize-string",
    title: "Reorganize String",
    category: "Heaps & Top-K",
    difficulty: "Intermediate",
    description:
      "Rearrange characters so no two neighbours are equal, using the two most frequent characters at each step.",
    input: { label: "text", default: "aab", parse: "chars" },
    approaches: [
      {
        name: "Always Take the Two Most Frequent",
        complexity: "O(n log alphabet) time, O(alphabet) space",
        idea: [
          "If any character appears more than half the text, it will inevitably touch itself, so the task is impossible.",
          "Otherwise pick the two most frequent characters, append them in either order, and repeat. Separating them keeps the last two different.",
        ],
        problem: [
          "Choosing the same pair order every time is not required for correctness, but choosing one character twice in a row is.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

void reorganize(const char *s) {
    int freq[26] = {0}, n = strlen(s);
    for (int i = 0; i < n; i++) freq[s[i] - 'a']++;

    for (int i = 0; i < 26; i++)
        if (freq[i] > (n + 1) / 2) { printf("impossible\\n"); return; }

    char out[256];
    int k = 0;
    for (int step = 0; step < n; step++) {
        int first = -1, second = -1;
        for (int i = 0; i < 26; i++) {
            if (freq[i] == 0) continue;
            if (first < 0 || freq[i] > freq[first]) { second = first; first = i; }
            else if (second < 0 || freq[i] > freq[second]) second = i;
        }
        if (first < 0) break;
        out[k++] = (char)('a' + first);
        freq[first]--;
        if (second >= 0 && k < n) { out[k++] = (char)('a' + second); freq[second]--; step++; }
    }
    out[k] = 0;
    printf("%s\\n", out); /* aba */
}

int main(void) { reorganize("aab"); return 0; }`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
#include <queue>
using namespace std;

string reorganizeString(string s) {
    vector<int> freq(26, 0);
    for (char c : s) freq[c - 'a']++;

    priority_queue<pair<int, char>> heap;
    for (int i = 0; i < 26; i++) {
        if (freq[i] > (int)(s.size() + 1) / 2) return "";
        if (freq[i]) heap.push({freq[i], char('a' + i)});
    }

    string out;
    while (heap.size() >= 2) {
        auto [f1, c1] = heap.top(); heap.pop();
        auto [f2, c2] = heap.top(); heap.pop();
        out += c1; out += c2;
        if (--f1) heap.push({f1, c1});
        if (--f2) heap.push({f2, c2});
    }
    if (!heap.empty()) {
        auto [f, c] = heap.top();
        if (f > 1) return "";
        out += c;
    }
    return out;
}

int main() { cout << reorganizeString("aab") << '\\n'; }`,
        },
        steps(text) {
          const s = chars(text);
          if (!s.length) {
            return [{
              title: "Give some text",
              tracks: [chips("text", ["—"], "idle")],
              counters: [count("characters", 0)],
              legend: ["idle", "result"],
              happened: "Nothing to rearrange.",
              why: "The impossibility rule needs at least one character.",
            }];
          }
          const freq = new Map();
          for (const c of s) freq.set(c, (freq.get(c) || 0) + 1);
          const limit = Math.floor((s.length + 1) / 2);
          const top = [...freq.entries()].sort((a, b) => b[1] - a[1])[0];
          const steps = [];
          steps.push({
            title: `Check ${top[0]}×${top[1]} against the limit ${limit}`,
            tracks: [track("text", s, fill(s.length, "idle")), chips("counts", [...freq.entries()].map(([c, n]) => `${c}×${n}`), "dim")],
            counters: [count("characters", s.length), count("limit", limit)],
            legend: LEG,
            happened: `The most frequent character appears ${top[1]} time${top[1] === 1 ? "" : "s"}.`,
            why: "More than half the positions cannot be separated by other characters.",
            codeLine: 4,
          });
          if (top[1] > limit) {
            steps.push({
              title: `Answer: impossible — ${top[0]} appears ${top[1]} times`,
              tracks: [track("text", s, fill(s.length, "bad")), chips("answer", ["impossible"], "result")],
              counters: [count("characters", s.length), count("answer", "impossible")],
              legend: LEG,
              happened: `There are only ${s.length - top[1]} other characters, fewer than the ${top[1] - 1} gaps needed.`,
              why: "The failure condition is checked before any arrangement is attempted.",
              codeLine: 5,
            });
            return steps;
          }
          const counts = new Map(freq);
          const out = [];
          while (out.length < s.length) {
            const ordered = [...counts.entries()].filter(([, n]) => n > 0).sort((a, b) => b[1] - a[1]);
            if (!ordered.length) break;
            out.push(ordered[0][0]);
            counts.set(ordered[0][0], counts.get(ordered[0][0]) - 1);
            let second = "—";
            if (out.length < s.length && ordered.length > 1) {
              second = ordered[1][0];
              out.push(second);
              counts.set(second, counts.get(second) - 1);
            }
            steps.push({
              title: `Take ${ordered[0][0]} then ${second}`,
              tracks: [
                chips("counts", [...counts.entries()].map(([c, n]) => `${c}×${n}`), (i) => ([...counts.keys()][i] === ordered[0][0] ? "read" : "dim")),
                chips("built", out, "result"),
              ],
              counters: [count("placed", out.length, s.length), count("last pair", `${ordered[0][0]}${second}`)],
              legend: LEG,
              happened: `The two largest counts were used, so the newest character differs from the previous one.`,
              why: "Taking the two busiest characters prevents any single character from building a run.",
              codeLine: 17,
            });
          }
          steps.push({
            title: `Answer: ${out.join("")}`,
            tracks: [chips("answer", [out.join("")], "result"), chips("arrangement", out, "result")],
            counters: [count("placed", out.length, s.length), count("answer", out.join(""))],
            legend: LEG,
            happened: `No two adjacent characters are equal in ${out.join("")}.`,
            why: "The frequency check guaranteed that the pairing would never run dry.",
            codeLine: 21,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "furthest-building-you-can-reach",
    title: "Furthest Building You Can Reach",
    category: "Heaps & Top-K",
    difficulty: "Advanced",
    description:
      "Spend ladders on the biggest climbs and bricks on the rest, stopping at the first gap that cannot be covered.",
    input: { label: "heights | bricks | ladders", default: "4,2,7,6,9,14,12 | 5 | 1", parse: "string" },
    approaches: [
      {
        name: "Ladders on the Largest Climbs",
        complexity: "O(n log ladders) time, O(ladders) space",
        idea: [
          "A ladder ignores a climb completely, so it is always best used on the largest climb seen so far.",
          "Keep the climbs in a min-heap. Whenever there are more climbs than ladders, pay bricks for the smallest one. If bricks run out, stop.",
        ],
        problem: [
          "Descending buildings need no resources, so only upward gaps enter the heap.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

static int cmp(const void *a, const void *b) {
    return *(const int *)a - *(const int *)b;
}

int furthest(const int *h, int n, int bricks, int ladders) {
    int climbs[256], m = 0;

    for (int i = 1; i < n; i++) {
        int gap = h[i] - h[i - 1];
        if (gap <= 0) continue;
        climbs[m++] = gap;

        if (m > ladders) {
            /* pay for the smallest climb so far */
            qsort(climbs, m, sizeof(int), cmp);
            bricks -= climbs[0];
            for (int j = 1; j < m; j++) climbs[j - 1] = climbs[j];
            m--;
            if (bricks < 0) return i - 1;
        }
    }
    return n - 1;
}

int main(void) {
    int h[] = {4, 2, 7, 6, 9, 14, 12};
    printf("%d\\n", furthest(h, 7, 5, 1)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
using namespace std;

int furthestBuilding(const vector<int>& h, int bricks, int ladders) {
    priority_queue<int, vector<int>, greater<int>> climbs;   // largest climbs kept

    for (int i = 1; i < (int)h.size(); i++) {
        int gap = h[i] - h[i - 1];
        if (gap <= 0) continue;
        climbs.push(gap);
        if ((int)climbs.size() > ladders) {
            bricks -= climbs.top();
            climbs.pop();
            if (bricks < 0) return i - 1;
        }
    }
    return h.size() - 1;
}

int main() {
    cout << furthestBuilding({4,2,7,6,9,14,12}, 5, 1) << '\\n'; // 4
}`,
        },
        steps(text) {
          const [hRaw, bRaw, lRaw] = parts(text);
          const h = nums(hRaw);
          let bricks = parseInt(bRaw, 10) || 0;
          const ladders = Math.max(0, parseInt(lRaw, 10) || 0);
          if (!h.length) {
            return [{
              title: "Give building heights, bricks and ladders",
              tracks: [chips("heights", ["—"], "idle")],
              counters: [count("bricks", bricks), count("ladders", ladders)],
              legend: ["idle", "result"],
              happened: "The three fields are heights, bricks and ladders.",
              why: "Only upward gaps consume resources.",
            }];
          }
          const steps = [];
          const climbs = [];
          let reach = 0, failed = false;
          steps.push({
            title: `Start on building 0; ${bricks} bricks and ${ladders} ladder${ladders === 1 ? "" : "s"}`,
            tracks: [track("heights", h, h.map((_, i) => (i === 0 ? "read" : "idle"))), chips("biggest climbs", ["—"], "dim")],
            counters: [count("bricks", bricks), count("ladders", ladders)],
            legend: LEG,
            happened: `The walk begins at height ${h[0]}.`,
            why: "Each upward gap must be paid with either bricks or one ladder.",
            codeLine: 4,
          });
          for (let i = 1; i < h.length; i++) {
            const gap = h[i] - h[i - 1];
            if (gap > 0) {
              climbs.push(gap);
              climbs.sort((a, b) => a - b);
              let paid = null;
              if (climbs.length > ladders) {
                paid = climbs.shift();
                bricks -= paid;
                if (bricks < 0) failed = true;
              }
              steps.push({
                title: `Gap ${gap} at building ${i}: ${climbs.length > ladders || paid != null ? `bricks pay ${paid}` : "hold a ladder"}`,
                tracks: [
                  track("heights", h, h.map((_, k) => (k === i ? (failed ? "bad" : "read") : k < i ? "done" : "idle"))),
                  chips("climbs with ladders", climbs.length ? climbs : ["—"], "active"),
                  chips("bricks", [bricks], bricks < 0 ? "bad" : "dim"),
                ],
                counters: [count("bricks", bricks), count("ladders held", climbs.length, ladders)],
                legend: LEG,
                happened: failed
                  ? `Bricks ran out while paying ${paid}.`
                  : paid != null
                    ? `The smallest climb ${paid} is cheaper to pay with bricks, keeping ladders for bigger gaps.`
                    : "The climb joins the ladder set, which is still within the ladder count.",
                why: "Ladders should cover the largest climbs, so bricks always pay for the smallest one.",
                codeLine: paid != null ? 14 : 11,
              });
            } else {
              steps.push({
                title: `Building ${i} is not higher — no cost`,
                tracks: [track("heights", h, h.map((_, k) => (k === i ? "read" : k < i ? "done" : "idle"))), chips("biggest climbs", climbs.length ? climbs : ["—"], "dim")],
                counters: [count("bricks", bricks), count("ladders held", climbs.length, ladders)],
                legend: LEG,
                happened: `Dropping from ${h[i - 1]} to ${h[i]} is free.`,
                why: "Only upward differences need resources.",
                codeLine: 6,
              });
            }
            if (failed) break;
            reach = i;
          }
          steps.push({
            title: failed ? `Answer: reach building ${reach}` : `Answer: reach building ${h.length - 1}`,
            tracks: [
              track("heights", h, h.map((_, i) => (i <= reach ? "result" : "dim"))),
              chips("answer", [reach], "result"),
            ],
            counters: [count("reached", reach), count("answer", reach)],
            legend: LEG,
            happened: `Building ${reach} is the furthest the resources allow.`,
            why: "The first gap that cannot be paid ends the journey.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "ipo",
    title: "IPO",
    category: "Heaps & Top-K",
    difficulty: "Advanced",
    description:
      "Choose at most k projects to maximise capital, unlocking projects as the budget grows.",
    input: {
      label: "k | capital available | profits | capitals",
      default: "2 | 0 | 1,2,3 | 0,1,1",
      parse: "string",
    },
    approaches: [
      {
        name: "Unlock, Then Take the Best",
        complexity: "O(n log n + k log n) time, O(n) space",
        idea: [
          "Sort projects by the capital they require. A project becomes available when the current capital reaches its requirement.",
          "Push every newly available profit into a max-heap and take the largest. Repeat k times or until nothing is affordable.",
        ],
        problem: [
          "Taking the largest immediate profit is optimal only because projects do not consume capital; a cost model would break the greedy choice.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int profit, capital; } Project;
static int by_capital(const void *a, const void *b) {
    return ((const Project *)a)->capital - ((const Project *)b)->capital;
}

int ipo(Project *p, int n, int k, int capital) {
    qsort(p, n, sizeof(Project), by_capital);

    for (int round = 0; round < k; round++) {
        int best = -1;
        for (int i = 0; i < n; i++)
            if (p[i].capital <= capital && p[i].profit >= 0)
                if (best < 0 || p[i].profit > p[best].profit) best = i;
        if (best < 0) break;
        capital += p[best].profit;
        p[best].profit = -1;             /* mark as taken */
    }
    return capital;
}

int main(void) {
    Project p[] = {{1,0},{2,1},{3,1}};
    printf("%d\\n", ipo(p, 3, 2, 0)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int findMaximizedCapital(int k, int w, vector<int> profit, vector<int> capital) {
    vector<int> order(profit.size());
    for (int i = 0; i < (int)order.size(); i++) order[i] = i;
    sort(order.begin(), order.end(), [&](int a, int b) { return capital[a] < capital[b]; });

    priority_queue<int> available;
    int next = 0;
    while (k--) {
        while (next < (int)order.size() && capital[order[next]] <= w)
            available.push(profit[order[next++]]);
        if (available.empty()) break;
        w += available.top();
        available.pop();
    }
    return w;
}

int main() {
    cout << findMaximizedCapital(2, 0, {1,2,3}, {0,1,1}) << '\\n'; // 4
}`,
        },
        steps(text) {
          const [kRaw, wRaw, pRaw, cRaw] = parts(text);
          const k = Math.max(0, parseInt(kRaw, 10) || 0);
          let w = parseInt(wRaw, 10) || 0;
          const profits = nums(pRaw);
          const capitals = nums(cRaw);
          const projects = profits.map((profit, i) => ({ profit, capital: capitals[i] ?? 0, i }));
          if (!projects.length) {
            return [{
              title: "Give projects and starting capital",
              tracks: [chips("projects", ["—"], "idle")],
              counters: [count("capital", w), count("rounds left", k)],
              legend: ["idle", "result"],
              happened: "Fields are k, starting capital, profits and required capitals.",
              why: "A project can only run when its capital requirement is met.",
            }];
          }
          const steps = [];
          const sorted = projects.slice().sort((a, b) => a.capital - b.capital);
          const available = [];
          let next = 0, rounds = 0;
          steps.push({
            title: `${projects.length} projects; ${k} round${k === 1 ? "" : "s"} with capital ${w}`,
            tracks: [
              chips("projects (capital → profit)", sorted.map((p) => `${p.capital}→${p.profit}`), "dim"),
              chips("available", ["—"], "idle"),
            ],
            counters: [count("capital", w), count("rounds left", k)],
            legend: LEG,
            happened: `Cheapest requirement is ${sorted[0].capital}.`,
            why: "Sorting by requirement lets the affordable prefix grow as capital grows.",
            codeLine: 6,
          });
          while (rounds < k) {
            while (next < sorted.length && sorted[next].capital <= w) {
              available.push(sorted[next]);
              next++;
            }
            available.sort((a, b) => b.profit - a.profit);
            if (!available.length) break;
            const chosen = available.shift();
            const before = w;
            w += chosen.profit;
            rounds++;
            steps.push({
              title: `Round ${rounds}: take profit ${chosen.profit}; capital ${before} → ${w}`,
              tracks: [
                chips("projects", sorted.map((p) => `${p.capital}→${p.profit}`), (i) => (sorted[i] === chosen ? "result" : sorted[i].capital <= before ? "dim" : "idle")),
                chips("available", available.length ? available.map((p) => p.profit) : ["—"], "active"),
                chips("capital", [w], "result"),
              ],
              counters: [count("capital", w), count("rounds left", k - rounds)],
              legend: LEG,
              happened: `The largest unlocked profit was ${chosen.profit}, so capital grew to ${w}.`,
              why: "Choosing the largest profit can only help unlock more projects.",
              codeLine: 14,
            });
          }
          steps.push({
            title: `Answer: capital ${w}`,
            tracks: [chips("answer", [w], "result")],
            counters: [count("rounds used", rounds, k), count("answer", w)],
            legend: LEG,
            happened: `After ${rounds} round${rounds === 1 ? "" : "s"} the capital is ${w}.`,
            why: "The loop stops early when no remaining project is affordable.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "sliding-window-median",
    title: "Sliding Window Median",
    category: "Heaps & Top-K",
    difficulty: "Advanced",
    description:
      "Report the median of each window of size k as it slides across the row.",
    input: { label: "numbers | k", default: "1,3,-1,-3,5,3,6,7 | 3", parse: "string" },
    approaches: [
      {
        name: "Two Balanced Heaps",
        complexity: "O(n log k) time, O(k) space",
        idea: [
          "Split the window into a lower half kept in a max-heap and an upper half kept in a min-heap, with sizes differing by at most one.",
          "After adding and removing one value per slide, rebalance so the median is either the top of the larger half or the average of both tops.",
        ],
        problem: [
          "Standard heaps cannot delete an arbitrary leaving value, so a lazy-deletion map or an ordered multiset is needed for real inputs.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

static int cmp(const void *a, const void *b) {
    return *(const int *)a - *(const int *)b;
}

void window_medians(const int *a, int n, int k) {
    int buf[256];
    for (int i = 0; i + k <= n; i++) {
        for (int j = 0; j < k; j++) buf[j] = a[i + j];
        qsort(buf, k, sizeof(int), cmp);
        if (k % 2) printf("%.1f ", (double)buf[k / 2]);
        else printf("%.1f ", (buf[k / 2 - 1] + buf[k / 2]) / 2.0);
    }
    printf("\\n");
}

int main(void) {
    int a[] = {1,3,-1,-3,5,3,6,7};
    window_medians(a, 8, 3); /* 1 3 -1 -3 3 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <set>
using namespace std;

vector<double> medianSlidingWindow(const vector<int>& a, int k) {
    multiset<int> low, high;   // low holds the smaller half
    vector<double> out;
    for (int i = 0; i < (int)a.size(); i++) {
        low.insert(a[i]);
        high.insert(*low.rbegin());
        low.erase(prev(low.end()));

        if ((int)high.size() > (int)low.size()) {
            low.insert(*high.begin());
            high.erase(high.begin());
        }

        if (i >= k - 1) {
            out.push_back(k % 2 ? *low.rbegin() : ((double)*low.rbegin() + *high.begin()) / 2);
            // remove the value leaving the window
            auto it = low.find(a[i - k + 1]);
            if (it != low.end()) low.erase(it);
            else high.erase(high.find(a[i - k + 1]));
            if ((int)low.size() < (int)high.size()) { low.insert(*high.begin()); high.erase(high.begin()); }
            else if (low.size() > high.size() + 1) { high.insert(*low.rbegin()); low.erase(prev(low.end())); }
        }
    }
    return out;
}

int main() {
    for (double m : medianSlidingWindow({1,3,-1,-3,5,3,6,7}, 3)) cout << m << ' '; // 1 3 -1 -3 3 3
    cout << '\\n';
}`,
        },
        steps(text) {
          const [numsRaw, kRaw] = parts(text);
          const a = nums(numsRaw);
          const k = Math.max(1, parseInt(kRaw, 10) || 1);
          if (!a.length || k > a.length) {
            return [{
              title: "Give numbers and a window no wider than them",
              tracks: [chips("numbers", a.length ? a : ["—"], "idle")],
              counters: [count("k", k), count("length", a.length)],
              legend: ["idle", "result"],
              happened: "The left side holds the numbers, the right side the window width.",
              why: "A window of size k reports one median per position.",
            }];
          }
          const steps = [];
          const out = [];
          steps.push({
            title: `Window width ${k} → ${a.length - k + 1} medians`,
            tracks: [track("numbers", a, fill(a.length, "idle")), chips("medians", ["—"], "dim")],
            counters: [count("windows", 0, a.length - k + 1), count("k", k)],
            legend: LEG,
            happened: `Each window keeps its lower half and upper half balanced.`,
            why: "The median depends only on the two middle values of the sorted window.",
            codeLine: 5,
          });
          for (let start = 0; start + k <= a.length; start++) {
            const window = a.slice(start, start + k).sort((x, y) => x - y);
            const m = median(window);
            out.push(m);
            const mid = Math.floor((k - 1) / 2);
            steps.push({
              title: `Window ${start}..${start + k - 1} sorted ${show(window)} → median ${m}`,
              tracks: [
                track("numbers", a, a.map((_, i) => (i >= start && i < start + k ? "active" : "dim"))),
                track("sorted window", window, (i) => (i === mid || (k % 2 === 0 && i === mid + 1) ? "result" : "done")),
                chips("medians", out, "result"),
              ],
              window: { from: start, to: start + k - 1 },
              counters: [count("windows", start + 1, a.length - k + 1), count("median", m)],
              legend: LEG,
              happened: k % 2
                ? `The middle value of the window is ${m}.`
                : `The two middle values average to ${m}.`,
              why: "Rebalancing the halves after each slide keeps the middle reachable in constant time.",
              codeLine: 14,
            });
          }
          steps.push({
            title: `Answer: ${show(out)}`,
            tracks: [chips("ans", out, "result")],
            counters: [count("medians", out.length), count("answer", show(out))],
            legend: LEG,
            happened: `Every window of width ${k} contributed one median.`,
            why: "The array of medians is the complete answer.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-performance-of-a-team",
    title: "Maximum Performance of a Team",
    category: "Heaps & Top-K",
    difficulty: "Advanced",
    description:
      "Pick at most k engineers so that the sum of speeds times the minimum efficiency is maximised.",
    input: {
      label: "n | speeds | efficiencies | k",
      default: "6 | 2,10,3,1,5,8 | 5,4,3,9,7,2 | 2",
      parse: "string",
    },
    approaches: [
      {
        name: "Sort by Efficiency, Keep k Fastest",
        complexity: "O(n log n) time, O(k) space",
        idea: [
          "Sort engineers by efficiency descending. When a team is anchored at the current engineer, that efficiency is the team minimum.",
          "Keep the k largest speeds seen so far in a min-heap. The best team at this anchor is the heap sum times the current efficiency.",
        ],
        problem: [
          "The heap only contains k speeds, so when a faster engineer arrives the slowest must be evicted before the sum is used.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int speed, efficiency; } Eng;
static int by_eff(const void *a, const void *b) {
    return ((const Eng *)b)->efficiency - ((const Eng *)a)->efficiency;
}

int max_performance(Eng *e, int n, int k) {
    qsort(e, n, sizeof(Eng), by_eff);
    long long speedSum = 0, best = 0;
    int kept[256], m = 0;

    for (int i = 0; i < n; i++) {
        speedSum += e[i].speed;
        kept[m++] = e[i].speed;

        if (m > k) {                     /* drop the slowest */
            int slow = 0;
            for (int j = 1; j < m; j++) if (kept[j] < kept[slow]) slow = j;
            speedSum -= kept[slow];
            for (int j = slow + 1; j < m; j++) kept[j - 1] = kept[j];
            m--;
        }
        long long perf = speedSum * e[i].efficiency;
        if (perf > best) best = perf;
    }
    return (int)(best % 1000000007);
}

int main(void) {
    Eng e[] = {{2,5},{10,4},{3,3},{1,9},{5,7},{8,2}};
    printf("%d\\n", max_performance(e, 6, 2)); /* 60 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int maxPerformance(int n, vector<int> speed, vector<int> efficiency, int k) {
    vector<int> order(n);
    for (int i = 0; i < n; i++) order[i] = i;
    sort(order.begin(), order.end(), [&](int a, int b) { return efficiency[a] > efficiency[b]; });

    priority_queue<int, vector<int>, greater<int>> chosen;
    long long speedSum = 0, best = 0;
    for (int i : order) {
        chosen.push(speed[i]);
        speedSum += speed[i];
        if ((int)chosen.size() > k) {
            speedSum -= chosen.top();
            chosen.pop();
        }
        best = max(best, speedSum * efficiency[i]);
    }
    return best % 1000000007;
}

int main() {
    cout << maxPerformance(6, {2,10,3,1,5,8}, {5,4,3,9,7,2}, 2) << '\\n'; // 60
}`,
        },
        steps(text) {
          const [nRaw, sRaw, eRaw, kRaw] = parts(text);
          const speeds = nums(sRaw);
          const effs = nums(eRaw);
          const n = Math.min(parseInt(nRaw, 10) || speeds.length, speeds.length);
          const k = Math.max(1, parseInt(kRaw, 10) || 1);
          const engineers = speeds.slice(0, n).map((speed, i) => ({ speed, efficiency: effs[i] ?? 0, i }));
          if (!engineers.length) {
            return [{
              title: "Give engineers and k",
              tracks: [chips("engineers", ["—"], "idle")],
              counters: [count("k", k)],
              legend: ["idle", "result"],
              happened: "Fields are n, speeds, efficiencies and k.",
              why: "The team performance is speed sum times the minimum efficiency.",
            }];
          }
          const sorted = engineers.slice().sort((a, b) => b.efficiency - a.efficiency);
          const steps = [];
          const heap = [];
          let speedSum = 0, best = 0, bestTeam = [];
          steps.push({
            title: `Sort by efficiency: ${sorted.map((e) => `${e.speed}@${e.efficiency}`).join(", ")}`,
            tracks: [chips("engineers", sorted.map((e) => `${e.speed}@${e.efficiency}`), "dim")],
            counters: [count("speed sum", 0), count("best", 0)],
            legend: LEG,
            happened: "The first engineer sets the team's minimum efficiency.",
            why: "Sorting descending means later engineers cannot raise the minimum.",
            codeLine: 6,
          });
          for (const e of sorted) {
            heap.push(e.speed);
            heap.sort((a, b) => a - b);
            speedSum += e.speed;
            let evicted = null;
            if (heap.length > k) {
              evicted = heap.shift();
              speedSum -= evicted;
            }
            const perf = speedSum * e.efficiency;
            const improved = perf > best;
            if (improved) { best = perf; bestTeam = heap.slice(); }
            steps.push({
              title: `Anchor efficiency ${e.efficiency}: speeds ${show(heap)} → ${perf}${improved ? " ✓ best" : ""}`,
              tracks: [
                chips("engineers", sorted.map((x) => `${x.speed}@${x.efficiency}`), (i) => (sorted[i] === e ? "read" : sorted[i].efficiency >= e.efficiency ? "done" : "dim")),
                chips("chosen speeds", heap, "active"),
                chips("evicted", evicted != null ? [evicted] : ["—"], evicted != null ? "bad" : "dim"),
              ],
              counters: [count("speed sum", speedSum), count("best", best)],
              legend: LEG,
              happened: evicted != null
                ? `The slowest chosen speed ${evicted} left to keep at most ${k} engineers.`
                : `The team is still within the size limit of ${k}.`,
              why: "Keeping only the fastest speeds maximises the sum for this anchor efficiency.",
              codeLine: evicted != null ? 14 : 12,
            });
          }
          steps.push({
            title: `Answer: ${best}`,
            tracks: [chips("best speeds", bestTeam, "result"), chips("answer", [best], "result")],
            counters: [count("best", best), count("answer", best)],
            legend: LEG,
            happened: `The best product of speed sum and minimum efficiency is ${best}.`,
            why: "Every engineer was used as the efficiency anchor exactly once.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "seat-reservation-manager",
    title: "Seat Reservation Manager",
    category: "Heaps & Top-K",
    difficulty: "Intermediate",
    description:
      "Serve the smallest available seat number, returning seats to a min-heap when they are released.",
    input: {
      label: "seat count | operations",
      default: "5 | reserve,reserve,unreserve,reserve,reserve,reserve",
      parse: "string",
    },
    approaches: [
      {
        name: "Min-Heap of Free Seats",
        complexity: "O(log n) per operation, O(n) space",
        idea: [
          "Put every seat number into a min-heap once. A reservation pops the smallest seat; a release pushes the number back in.",
          "The heap always returns the smallest available number, which is exactly the required rule.",
        ],
        problem: [
          "Filling the heap takes linear time and memory up front, which is wasteful when only a few seats are ever used.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

int main(void) {
    int n = 5;
    int freeSeat[16], m = 0;
    for (int i = 1; i <= n; i++) freeSeat[m++] = i;

    const char *ops[] = {"reserve","reserve","unreserve","reserve","reserve","reserve"};
    int released = 2;

    for (int i = 0; i < 6; i++) {
        if (strcmp(ops[i], "reserve") == 0) {
            int best = 0;
            for (int j = 1; j < m; j++) if (freeSeat[j] < freeSeat[best]) best = j;
            printf("%d ", freeSeat[best]);
            for (int j = best + 1; j < m; j++) freeSeat[j - 1] = freeSeat[j];
            m--;
        } else {
            freeSeat[m++] = released;
        }
    }
    printf("\\n"); /* 1 2 2 3 4 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
#include <string>
using namespace std;

class SeatManager {
    priority_queue<int, vector<int>, greater<int>> freeSeats;
public:
    explicit SeatManager(int n) {
        for (int i = 1; i <= n; i++) freeSeats.push(i);
    }
    int reserve() {
        int seat = freeSeats.top();
        freeSeats.pop();
        return seat;
    }
    void unreserve(int seat) {
        freeSeats.push(seat);
    }
};

int main() {
    SeatManager m(5);
    cout << m.reserve() << ' ' << m.reserve() << ' ';
    m.unreserve(2);
    cout << m.reserve() << ' ' << m.reserve() << ' ' << m.reserve() << '\\n'; // 1 2 2 3 4
}`,
        },
        steps(text) {
          const [nRaw, opsRaw] = parts(text);
          const n = Math.max(1, parseInt(nRaw, 10) || 1);
          const ops = list(opsRaw).map((x) => x.toLowerCase());
          const steps = [];
          const heap = Array.from({ length: n }, (_, i) => i + 1);
          const served = [];
          let toRelease = null;
          steps.push({
            title: `${n} seats, all free`,
            tracks: [chips("free seats", heap, "dim"), chips("served", ["—"], "idle")],
            counters: [count("free", heap.length), count("reservations", 0)],
            legend: LEG,
            happened: `The heap starts as ${show(heap)}.`,
            why: "A min-heap makes the smallest free seat available at the top.",
            codeLine: 4,
          });
          for (const op of ops) {
            if (op.startsWith("reserve")) {
              const seat = heap.shift();
              if (seat == null) {
                steps.push({
                  title: "No seats left to reserve",
                  tracks: [chips("free seats", ["—"], "bad"), chips("served", served.length ? served : ["—"], "dim")],
                  counters: [count("free", 0), count("reservations", served.length)],
                  legend: LEG,
                  happened: "Every seat is already taken.",
                  why: "A reservation without a free seat cannot return a number.",
                  codeLine: 9,
                });
                continue;
              }
              served.push(seat);
              toRelease = seat;
              steps.push({
                title: `Reserve → seat ${seat}`,
                tracks: [chips("free seats", heap.length ? heap : ["—"], (i) => (i === 0 ? "active" : "dim")), chips("served", served, "result")],
                counters: [count("free", heap.length), count("reservations", served.length)],
                legend: LEG,
                happened: `Seat ${seat} was the smallest free number.`,
                why: "The pop returns the heap minimum, so the rule is satisfied automatically.",
                codeLine: 9,
              });
            } else if (op.startsWith("unreserve") || op.startsWith("release")) {
              const seat = toRelease != null ? toRelease : 1;
              heap.push(seat);
              heap.sort((a, b) => a - b);
              steps.push({
                title: `Release seat ${seat}`,
                tracks: [chips("free seats", heap, (i) => (heap[i] === seat ? "good" : "dim")), chips("served", served.length ? served : ["—"], "dim")],
                counters: [count("free", heap.length), count("reservations", served.length)],
                legend: LEG,
                happened: `Seat ${seat} is free again and rejoins the heap.`,
                why: "Pushing the number back restores it to the correct sorted place.",
                codeLine: 14,
              });
            }
          }
          steps.push({
            title: `Answer: served ${served.length ? show(served) : "no seats"}`,
            tracks: [chips("served order", served.length ? served : ["—"], "result"), chips("free now", heap.length ? heap : ["none"], "dim")],
            counters: [count("reservations", served.length), count("free", heap.length)],
            legend: LEG,
            happened: `${served.length} reservation${served.length === 1 ? "" : "s"} were served.`,
            why: "Each operation touched the heap once, so the total cost is logarithmic per step.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });
})();
