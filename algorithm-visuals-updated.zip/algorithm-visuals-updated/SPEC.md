# DSA Visuals — Authoring Spec

You are writing **original** algorithm visualisation modules for a local HTML/JS app.
Everything you write (text, step sequences, C/C++ code) must be **original work** written
by you from your own understanding of the algorithm. Do **not** copy text or code from
any website, and do not attempt to fetch site content.

## Files

* Each batch owns exactly one file: `js/viz/<batch>.js` (the filename is assigned to you).
* Do NOT modify `index.html`, `css/styles.css`, `js/engine.js`, `js/catalog-data.js`,
  `js/helpers.js`, or any other `js/viz/*.js` file. Your script tag is already in
  `index.html`.
* The file is a plain IIFE (no modules, no imports, no build step — it must work from
  `file://` too).

## Module skeleton

```js
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  V.register({
    id: "binary-search",            // EXACT slug, must match assigned list
    title: "Binary Search",         // EXACT assigned title
    category: "Binary Search",      // EXACT assigned category string
    difficulty: "Beginner" | "Intermediate" | "Advanced",
    description: "One sentence on what it does.",
    input: { label: "Sorted numbers", default: "2, 5, 8, 12, 16, 23, 38", parse: "ints" },
    approaches: [
      {
        name: "Iterative Halving",
        complexity: "O(log n) time, O(1) space",
        idea: ["Paragraph 1 …", "Paragraph 2 …"],     // what the approach IS
        problem: ["What's awkward / costly about it …"], // honest trade-off
        code: { c: `…`, cpp: `…` },                   // BOTH required, original
        steps(parsed) {
          return [
            { title: "…", tracks: [...], counters: [count("read", 0, n)],
              happened: "…", why: "…", legend: ["read", "done", "result", "idle"],
              codeLine: 3 },   // codeLine optional (0-based line in the C code)
          ];
        },
      },
    ],
  });
})();
```

## Input parsers (`input.parse`)

| name     | accepts                       | default example                 |
|----------|-------------------------------|---------------------------------|
| `ints`   | comma/space separated ints    | `"4, 8, 15, 16"`                |
| `int`    | single int                    | `"12"`                          |
| `string` | free text                     | `"banana"`                      |
| `chars`  | text → array of characters    | `"banana"`                      |
| `tokens` | words/tokens                  | `"car boat bus"`                |
| `words`  | space-separated words         | `"the cat sat"`                 |
| `pairs`  | `a,b` pairs space or `\|` separated | `"1,3 2,6 5,8"`           |
| `tworows`| two int rows: `1,2,3 \| 4,5,6`| `"1, 3, 5 \| 3, 1, 5"`          |

Engine limits (it throws a friendly message, that's fine): ≤40 ints, ≤60 chars,
≤16 pairs. **Your `steps()` must handle EVERY input the parser accepts** — n = 0/1/2,
negatives, duplicates, unsorted (where the algorithm allows it), already-solved cases.
Never assume the default input. If an algorithm needs a precondition (e.g. sorted),
pick a default that satisfies it and note it in `description`/`idea`; still don't crash
on violation — showing "not found / already sorted" style outcomes is fine.

## Step model

Every step: `{ title, counters[], happened, why, legend?, codeLine?, kind?, window?, pointers? }`.

* `title` — short, concrete: `` `Add 15 → total becomes 27` `` not `"Step 4"`.
* `counters` — `[count("numbers read", 3, 7), count("answer", 42)]`; total optional.
* `happened` — one or two plain sentences: what just happened on screen.
* `why` — one or two sentences: why that move matters for the algorithm.
* `legend` — array of state keys shown under the stage (default is
  `["read","done","result","idle"]`). Include every state you actually use,
  in a sensible order. Labels are automatic.
* `codeLine` — 0-based index into the **C** code of the current line to highlight.
  Optional but encouraged once the code is shown.
* First step should set the scene; last step should carry the answer
  (`result` state + `answer` counter).

### Kinds of stages (`kind` field)

**`"cells"` (default)** — array/list-like rows:

```js
tracks: [
  track("the numbers", [4, 8, 15], ["read", "done", "idle"]),   // states per index
  { label: "running total", cells: [{ v: 27, state: "result", tag: "4+8+15" }] },
]
```
`track(label, values, states, tags?)` builds cells; `states` may be an array of
state names, one state name for every cell, or a function `(index) => state`.
Each cell may have `{ v, state, tag, idx, wide, empty }`. Set `showIdx: false`
on the step to hide index numbers.

Two optional step fields mark the active region on cell stages:

```js
// Sliding window: one rounded frame around an inclusive run of cells.
{ window: { from: left, to: right, label: "window", track: 0 } }

// Two pointers: a coloured badge above each cell, plus an outline on the cell.
{ pointers: [{ index: lo, label: "L" }, { index: hi, label: "R" }] }
```

* `window` (or `windows: [...]`) uses inclusive indices. `track` defaults to `0`
  and `label` defaults to `"window"`; pass `label: false` to hide the caption.
  A track may also carry `window`/`windows` to target itself.
* A window automatically badges both edges with `i` and `j` (a one-cell window
  shows `i,j`), so the moving indices stay visible next to the frame. Override
  with `edgeLabels: ["lo", "hi"]`, `fromLabel`/`toLabel`, or `edges: false`; set
  `showWindowEdges: false` on the step to disable all automatic edge badges.
* `pointers` entries are `{ index, label, track?, tone? }`. `track` defaults to
  `0`; `tone` defaults from the label (`L`/`lo`/`slow`/`i` → blue,
  `R`/`hi`/`fast`/`j` → violet). A track may also carry `pointers`.
* Keep a pointer on a cell that is also visibly active (`read`, `compare`,
  `swap`, `good`, `bad`, `result`, ...). Do not advance the state highlight past
  the pointer; badges and cell highlights should describe the same step.
* Off-stage indices are ignored, so it is safe to skip pointers for an exhausted
  row instead of clamping them.

**`"list"`** — linked lists:
```js
{ kind: "list", label: "linked list", nodes: [{ v: 1, state: "read" }, { v: 2, state: "done" }], nil: true }
```

**`"tree"`** — binary trees (level-order build):
```js
const root = window.H.binaryTree([3, 9, 20, null, null, 15, 7]);
// in a step:
{ kind: "tree", tree: root, nodeStates: { t0: "read", t2: "done", t5: "result" }, label: "in-order walk" }
```
Ids come from `H.binaryTree` (`t0`, `t1`, …, in level order) or your own `{id, v, l, r}`
objects. States: same palette as cells.

**`"graph"`** — coordinates are yours (units ≈ 0–60, engine scales):
```js
{ kind: "graph",
  nodes: [{ id: "A", label: "A", x: 10, y: 10, state: "read" }, { id: "B", x: 30, y: 10, state: "done" }],
  edges: [{ a: "A", b: "B", state: "good", directed: true }] }
```

**`"grid"`** — matrices / DP tables:
```js
{ kind: "grid", rows: 3, cols: 3,
  rowHeads: ["", "a", "b"], colHeads: ["", "a", "b"],
  cells: [{ r: 1, c: 1, v: 1, state: "read" }] }   // cells not listed render as idle-empty
```
(Use `window.H.grid(rows, cols, (r, c) => …)` to build them.)

**`"html"`** — escape `<` `>` `&`; you may use classes `cell`, `st-read`, `st-done`,
`st-result`, `st-good`, `st-bad`, `st-dim`, `block-label`. Prefer the typed kinds.

### State palette (use these exact keys)

| state     | meaning                       |
|-----------|-------------------------------|
| `idle`    | not looked at yet (dashed)    |
| `read`    | current focus (green, lifted) |
| `done`    | handled so far                |
| `active`  | in progress (blue)            |
| `compare` | one of two being compared (violet) |
| `result`  | answer / accumulated result (amber) |
| `good`    | confirmed correct             |
| `bad`     | rejected / mismatch           |
| `swap`    | mid-swap (amber, lifted)      |
| `dim`     | out of play (faded)           |

## Steps requirements

* **≥5 steps per approach** for simple algorithms, **≥8** for non-trivial ones
  (final answer step included). A setup step first, answer step last.
* If the algorithm naturally has two well-known approaches (iterative/recursive,
  brute-force/optimal, etc.), include **both** as two `approaches`; otherwise one is fine.
* Steps must tell a story a beginner can follow — no jargon without context.

## Code requirements

* **Original** C and C++ solutions, written by you. Correct and idiomatic.
* C: `#include` what you use, compile-safe. C++: `<vector>`, `<string>`, etc. as needed.
* Both files should solve the same problem the approach describes.
* Keep them short (10–30 lines); demo `main()` welcome.
* Comments in English, lowercase-ish, brief.

## Testing (do this before you finish)

A server is already running at `http://localhost:8321/` serving the app folder
(`C:\Users\user\Documents\Default Project\algorithm-visuals`). If it isn't reachable,
start your own: `python -m http.server 8322 --directory "C:\Users\user\Documents\Default Project\algorithm-visuals"`
and use port 8322.

1. Open `http://localhost:8321/?agent=<yourbatch>#/p=<slug>` in a browser tab
   (use YOUR OWN tab; other agents work concurrently; append `?agent=<yourbatch>`
   so cache is fresh).
2. Run in the page console (or via your evaluate tool):
   ```js
   (() => { const v = __validateViz();
     return v.problems.filter(p => /your-slug-1|your-slug-2/.test(p)); })()
   ```
   Filter problems to **your** slugs only — ignore other batches' problems.
3. Fix until your filter returns `[]`.
4. Also click through the first approach manually (Next ×6) and check the browser
   console for errors (`Uncaught`, `steps() failed`). Fix those too.
5. Spot-check a non-default input (change the input box, press Run) — no crash.

## Style

* Plain, friendly, factual English. Match the tone of `js/viz/array-foundations.js`
  (read that file first — it is the reference for structure, tone and quality).
* Titles: sentence case with concrete values. Descriptions: one line.
