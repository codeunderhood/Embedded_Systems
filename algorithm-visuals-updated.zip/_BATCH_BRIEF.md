# Batch authoring brief (for one agent = one file)

Project: `C:\Users\user\Desktop\study\algorithm-visuals` — a local, dependency-free
DSA visualisation app (open `index.html`, no build step, must work from `file://`).

Read these first, in this order:

1. `SPEC.md` — the authoring contract. Follow it exactly.
2. `js/helpers.js` — the helpers you may use (`track`, `fill`, `paint`, `count`,
   `nums`, `binaryTree`, `treeIds`, `grid`).
3. `js/viz/array-foundations.js` — reference for structure and tone.
4. `js/viz/bit-tricks-1.js` — a recently finished module in this same style.
5. Your item list: `_batches/<file>.json` — each item has `slug`, `title`, `category`.
6. Optional per-kind references: `js/viz/graphs-basics.js` (graph), `js/viz/trees-basics.js`
   (tree), `js/viz/dp-basics.js` (grid), `js/viz/linked-lists.js` (list).

## What to produce

Create **exactly one** new file: `js/viz/<file>.js` (the `<file>` from your prompt).
Do not touch `index.html`, `css/`, `js/engine.js`, `js/catalog-data.js`, `js/helpers.js`,
`SPEC.md`, or any other `js/viz/*.js` file. The orchestrator adds your script tag.

The file is a plain IIFE:

```js
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  /* local helpers shared by this file */

  V.register({ ... });
  // ...one V.register per item
})();
```

## Per visualisation (hard requirements)

- `id`: the exact slug from your item list.
- `title`: the exact title from your item list.
- `category`: the exact category from your item list.
- `difficulty`: `"Beginner" | "Intermediate" | "Advanced"`.
- `description`: one sentence, concrete.
- `input: { label, default, parse }` where `parse` is one of
  `ints | int | string | chars | tokens | words | pairs | tworows`.
- `approaches`: 1–2 approaches. Use 2 when the problem genuinely has two classic
  strategies (brute force vs optimal, iterative vs recursive, DP vs greedy, BFS vs DFS).
- Per approach: `name`, `complexity`, `idea` (1–3 short paragraphs), `problem`
  (1–2 honest trade-off sentences), `code: { c, cpp }`, `steps(parsed)`.

### Steps

- At least 8 steps for non-trivial algorithms, at least 5 for trivial ones, on the
  **default input**. First step sets the scene; the last step carries the answer with a
  `result` state plus an `answer` counter. Every step: `title` (concrete, with real
  values), `counters`, `happened` (1–2 plain sentences), `why` (1–2 sentences),
  plus the stage payload.
- Include `codeLine` (0-based line index into the **C** code) on steps where a
  specific line is doing the work. Keep the C code's line numbering stable
  (no reflow after you pick indices).
- Use only these state keys: `idle`, `read`, `done`, `active`, `compare`, `result`,
  `good`, `bad`, `swap`, `dim`. Provide a `legend` array listing every state used.
- Narrate for a beginner: name the actual numbers/characters on screen
  (`Add 15 → total becomes 27`), not `"Step 4"`.

### Stage kinds — pick what fits, do not force everything into rows

- default (`kind: "cells"`): `tracks: [ track("label", values, states, tags), ... ]`
  plus optional `{ label, cells: [{ v, state, tag }] }` tracks for scalars/answers.
  Add `showIdx: false` when index numbers would be noise.
- `kind: "list"`: `{ nodes: [{ v, state }], nil: true, label }` for linked lists.
- `kind: "tree"`: `tree: window.H.binaryTree([...])`, `nodeStates: { t0: "read" }`.
- `kind: "grid"`: `rows`, `cols`, optional `rowHeads` / `colHeads`, and `cells`
  built with `window.H.grid(rows, cols, (r, c) => ({ v, state }))`.
- `kind: "graph"`: `nodes: [{id, label, x, y, state}]`, `edges: [{a, b, state, directed}]`
  (coordinates roughly 0–60).
- Keep it readable: at most ~12 columns of cells per row; for longer inputs show a
  sliding window or a summary row rather than 40 tiny cells.

### Robustness (must not throw)

`steps()` must never throw for any input the parser accepts, including: tiny inputs,
empty strings where the parser allows them, `0`, `1`, negatives, duplicates, already-solved
cases, and unsorted inputs where the algorithm still allows them. If a precondition is
needed (sorted, non-empty, positive), pick a default that satisfies it, say so in
`description`/`idea`, and still show a graceful `bad`/`result` outcome on violation.
Engine limits: ≤40 array items, ≤60 chars, ≤16 pairs, ≤160 characters.

### Code

- Original C and C++ solutions, written by you, correct and compile-safe, 10–30 lines,
  with brief lowercase-ish English comments. C: include what you use. C++: use
  `<vector>`, `<string>`, `<queue>`, etc. Both files solve the same approach.
- Do not copy text or code from any website, book, or another file in this repo.

## Before you finish

1. `node --check js/viz/<file>.js` — must pass.
2. Re-read your file and confirm: every item present with exact id/title/category;
   every approach has both code strings; default input parses; default step count target met.
3. Run a quick numeric sanity check of your `steps()` logic for the default input
   (by hand or a throwaway Node harness that stubs `window`), especially for
   DP tables, binary-search bounds, and graph traversals.
4. Delete any throwaway harness files you created.

Report back: file path, the number of `V.register` calls, and a one-line note on any
item whose default input differs from the obvious choice.
