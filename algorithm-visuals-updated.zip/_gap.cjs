﻿const fs=require("fs"),path=require("path");
const dir="js/viz";
const ids=[];
for(const f of fs.readdirSync(dir)){
  const t=fs.readFileSync(path.join(dir,f),"utf8");
  for(const m of t.matchAll(/^\s*id:\s*"([^"]+)"/gm)) ids.push(m[1]);
}
const cat=fs.readFileSync("js/catalog-data.js","utf8");
const slurp=cat.slice(cat.indexOf("const SLUGS = ["), cat.indexOf("];",cat.indexOf("const SLUGS = [")));
const slugs=[...slurp.matchAll(/"([a-z0-9-]+)"/g)].map(m=>m[1]);
const set=new Set(ids);
const remaining=slugs.filter(s=>!set.has(s));
const extra=ids.filter(i=>!slugs.includes(i));
fs.writeFileSync("_gap.json",JSON.stringify({built:ids.length, catalog:slugs.length, remaining},null,1));
console.log("built",ids.length,"catalog",slugs.length,"remaining",remaining.length,"extra",extra);
console.log(remaining.join("\n"));
