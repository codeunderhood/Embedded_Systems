﻿const fs=require("fs");
const gap=JSON.parse(fs.readFileSync("_gap.json","utf8")).remaining;
const cat=fs.readFileSync("js/catalog-data.js","utf8");
const body=cat.slice(cat.indexOf("const SLUGS = ["), cat.indexOf("window.VIZ_CATALOG"));
// duplicates from juicy
function evalInSandbox(){}
const vm=require("vm");
const ctx={window:{}};
vm.createContext(ctx);
let src=cat.replace("window.VIZ_CATALOG","window.VIZ_CATALOG").replace("window.VIZ_SLUGS","window.VIZ_SLUGS");
vm.runInContext(src,ctx);
const catalog=ctx.window.VIZ_CATALOG;
const map=new Map(catalog.map(e=>[e.slug,e]));
const rows=gap.map(s=>({slug:s,title:(map.get(s)||{}).title,category:(map.get(s)||{}).category}));
fs.writeFileSync("_remaining.json",JSON.stringify(rows,null,1));
const byCat={};
for(const r of rows){ (byCat[r.category] ||= []).push(r); }
for(const k of Object.keys(byCat)) console.log(k, byCat[k].length);
