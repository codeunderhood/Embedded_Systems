﻿const fs=require("fs");
const p="js/viz/advanced-structures-2.js";
const t=fs.readFileSync(p,"utf8");
const marker="  /* ---------------------------------------------------------- */\n  V.register({\n    id: \"persistent-kth-order-statistic-range\"";
const i=t.indexOf(marker);
if(i<0) throw new Error("marker not found");
const end=t.lastIndexOf("})();");
fs.writeFileSync(p, t.slice(0,i)+t.slice(end));
console.log("trimmed", t.length, "->", fs.statSync(p).size);
