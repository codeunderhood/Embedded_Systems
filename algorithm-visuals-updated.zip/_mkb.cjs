﻿const fs=require("fs");
const plan=JSON.parse(fs.readFileSync("_batches.json","utf8"));
fs.mkdirSync("_batches",{recursive:true});
for(const b of plan){
  fs.writeFileSync("_batches/"+b.file.replace(/\.js$/,".json"), JSON.stringify(b.items,null,1));
}
console.log("wrote", plan.length);
