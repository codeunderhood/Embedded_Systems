/* ============================================================
   DSA Visuals — engine
   A step-player: each visualisation declares approaches; each
   approach turns an input into an array of steps. The engine
   renders the current step and animates state changes with CSS.
   ============================================================ */
(function () {
  "use strict";

  /* ---------------- Registry ---------------- */
  const registry = new Map();

  const VIZ = {
    register(def) {
      if (!def || !def.id) throw new Error("viz: missing id");
      if (registry.has(def.id)) console.warn("viz: duplicate id", def.id);
      registry.set(def.id, def);
      return def;
    },
    get: (id) => registry.get(id),
    all: () => [...registry.values()],
  };
  window.VIZ = VIZ;

  /* ---------------- Helpers ---------------- */
  const $ = (sel) => document.querySelector(sel);
  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  };
  const SPEEDS = { slow: 1500, normal: 850, fast: 420, instant: 90 };
  const STATE_LABELS = {
    idle: "Not looked at yet", read: "Current focus", done: "Handled so far",
    active: "In progress", compare: "Comparing two", result: "Result / answer",
    good: "Confirmed", bad: "Rejected / mismatch", swap: "Swapping", dim: "Out of play",
  };
  const DEFAULT_LEGEND = ["read", "done", "result", "idle"];

  /* input parsers: each viz.input declares parse: "ints"|"int"|"string"|"tokens"|"pairs"|"chars" */
  const PARSERS = {
    ints: (s) => {
      const nums = s.split(/[\s,;]+/).filter(Boolean).map(Number);
      if (!nums.length || nums.some((n) => !Number.isFinite(n))) throw new Error("Give a list of whole numbers, e.g. 4, 8, 15, 16");
      return nums;
    },
    int: (s) => {
      const n = parseInt(s.trim(), 10);
      if (!Number.isFinite(n)) throw new Error("Give a single whole number.");
      return n;
    },
    string: (s) => {
      if (!s.length) throw new Error("Give some text.");
      return s;
    },
    chars: (s) => {
      if (!s.length) throw new Error("Give some text.");
      return [...s];
    },
    tokens: (s) => {
      const t = s.split(/[\s,]+/).filter(Boolean);
      if (!t.length) throw new Error("Give a list of tokens.");
      return t;
    },
    pairs: (s) => {
      const t = s.split(/\s*\|\s*|\s+/).filter(Boolean).map(p => {
        const [a, b] = p.split(",").map(Number);
        if (!Number.isFinite(a) || !Number.isFinite(b)) throw new Error("Use pairs like 1,3 2,6 5,8");
        return [a, b];
      });
      if (!t.length) throw new Error("Use pairs like 1,3 2,6 5,8");
      return t;
    },
    words: (s) => {
      const t = s.split(/\s+/).filter(Boolean);
      if (!t.length) throw new Error("Give a list of words.");
      return t;
    },
    tworows: (s) => {
      const parts = s.split("|");
      if (parts.length !== 2) throw new Error("Give two rows separated by |, e.g. 1, 3, 5 | 3, 1, 5");
      return parts.map((p) => {
        const nums = p.split(/[\s,;]+/).filter(Boolean).map(Number);
        if (!nums.length || nums.some((n) => !Number.isFinite(n)))
          throw new Error("Each row needs whole numbers, e.g. 1, 3, 5 | 3, 1, 5");
        return nums;
      });
    },
  };

  /* ---------------- State ---------------- */
  const state = {
    vizId: null,
    approachIdx: 0,
    inputRaw: "",
    steps: [],
    stepIdx: 0,
    playing: false,
    timer: null,
    lang: "c",
    detailTab: "idea",
    parsed: null,
    error: null,
  };

  /* ---------------- Routing ---------------- */
  function currentRoute() {
    const h = location.hash.replace(/^#\/?/, "");
    if (!h) return { id: null };
    const m = h.match(/^p=([a-z0-9-]+)/);
    if (m) return { id: m[1] };
    if (registry.has(h)) return { id: h };
    return { id: null };
  }
  function goto(id) {
    location.hash = id ? "#/p=" + id : "#/";
  }

  /* ---------------- Catalog sidebar ---------------- */
  function matches(e, q) {
    if (!q) return true;
    return (
      e.title.toLowerCase().includes(q) ||
      e.slug.includes(q) ||
      (e.category || "").toLowerCase().includes(q) ||
      (e.level || "").toLowerCase().includes(q) ||
      (e.ncName || "").toLowerCase().includes(q)
    );
  }

  function addNcTag(parent, text) {
    const tag = el("span", "nc-tag", text || "NC250");
    tag.title = "Part of the NeetCode 250 study list";
    parent.appendChild(tag);
  }

  function navItem(e, impl) {
    const a = el("a", "nav-item" + (e.slug === state.vizId ? " active" : ""));
    a.href = "#/p=" + e.slug;
    a.appendChild(el("span", "nav-label", impl.title || e.title));
    if (e.nc) addNcTag(a);
    if (e.ncName) a.title = e.ncName + " · NeetCode 250";
    return a;
  }

  function buildSidebar() {
    const nav = $("#nav");
    nav.innerHTML = "";
    const q = ($("#search").value || "").toLowerCase().trim();
    const catalog = window.VIZ_CATALOG || [];
    const has = new Map(VIZ.all().map((d) => [d.id, d]));

    const total = catalog.length || VIZ.all().length;
    const ready = VIZ.all().length;
    $("#viz-count").textContent = ready + " of " + total + " ready";
    $("#foot-count").textContent = ready + " of " + total + " visualisations ready";

    if (catalog.length) {
      let lastTopic = null;
      let lastLevel = null;
      let group = null;
      const topicCounts = {};
      for (const x of catalog) topicCounts[x.category] = (topicCounts[x.category] || 0) + 1;
      for (const e of catalog.filter((x) => matches(x, q))) {
        if (e.category !== lastTopic) {
          group = el("div", "nav-group");
          const gt = el("div", "nav-group-title", e.category);
          gt.appendChild(el("span", "nav-group-count", topicCounts[e.category] + " ques"));
          group.appendChild(gt);
          nav.appendChild(group);
          lastTopic = e.category;
          lastLevel = null;
        }
        if (e.level !== lastLevel) {
          group.appendChild(el("div", "nav-level", e.level || "Other"));
          lastLevel = e.level;
        }
        const impl = has.get(e.slug);
        if (impl) {
          group.appendChild(navItem(e, impl));
        } else {
          const s = el("span", "nav-item pending");
          s.appendChild(el("span", "nav-label", e.title));
          if (e.nc) addNcTag(s);
          s.title = "Coming soon — not written yet";
          group.appendChild(s);
        }
      }
      if (!nav.children.length) nav.appendChild(el("div", "nav-group-title", "No matches"));
      // registered ids that somehow aren't in the catalog: still show them
      for (const d of VIZ.all()) {
        if (!catalog.some((e) => e.slug === d.id)) {
          if ("__extra" !== lastTopic) {
            group = el("div", "nav-group");
            group.appendChild(el("div", "nav-group-title", "Other visualisations"));
            nav.appendChild(group);
            lastTopic = "__extra";
          }
          const a = el("a", "nav-item" + (d.id === state.vizId ? " active" : ""), d.title);
          a.href = "#/p=" + d.id;
          group.appendChild(a);
        }
      }
      return;
    }

    // Fallback: no catalog file — just list whatever is registered
    const defs = VIZ.all().filter(
      (d) => !q || d.title.toLowerCase().includes(q) || d.id.includes(q) || (d.category || "").toLowerCase().includes(q),
    );
    if (!defs.length) {
      nav.appendChild(el("div", "nav-group-title", "No matches"));
      return;
    }
    let lastCat2 = null;
    let group2 = null;
    for (const d of defs) {
      const cat = d.category || "Other";
      if (cat !== lastCat2) {
        group2 = el("div", "nav-group");
        group2.appendChild(el("div", "nav-group-title", cat));
        nav.appendChild(group2);
        lastCat2 = cat;
      }
      const a = el("a", "nav-item" + (d.id === state.vizId ? " active" : ""), d.title);
      a.href = "#/p=" + d.id;
      group2.appendChild(a);
    }
  }

  /* ---------------- Home ---------------- */
  function renderHome() {
    const main = $("#main");
    main.classList.add("home");
    $("#approaches").innerHTML = "";
    $("#controlbar").style.display = "none";
    $("#counters").innerHTML = "";
    $("#stage").style.display = "none";
    $("#legend").innerHTML = "";
    $("#timeline-wrap").style.display = "none";
    $("#narratives").style.display = "none";
    $("#detail").style.display = "none";
    $("#viz-title").textContent = "DSA Visuals";
    $("#viz-difficulty").textContent = "";
    if ($("#viz-source")) $("#viz-source").textContent = "";
    $("#viz-desc").textContent = "Step-by-step algorithm animations — pick one from the list.";

    let hero = $("#home-hero");
    if (!hero) {
      hero = el("div", "home-hero");
      hero.id = "home-hero";
      hero.innerHTML = "<h2>Pick a visualisation</h2><p>Each one walks through the algorithm step by step with playback controls, a timeline, and C / C++ solutions.</p><div class='home-grid' id='home-grid'></div>";
      main.insertBefore(hero, $("#footer"));
    }
    hero.style.display = "";
    const grid = hero.querySelector("#home-grid");
    grid.innerHTML = "";
    const q = ($("#search").value || "").toLowerCase().trim();
    const catalog = window.VIZ_CATALOG || [];
    const has = new Map(VIZ.all().map((d) => [d.id, d]));
    const entries = catalog.length
      ? catalog.filter((e) => matches(e, q))
      : VIZ.all()
          .filter((d) => !q || d.title.toLowerCase().includes(q) || (d.category || "").toLowerCase().includes(q))
          .map((d) => ({ slug: d.id, title: d.title, category: d.category || "Other", level: d.difficulty || "Intermediate" }));
    const ready = VIZ.all().length;
    const note = hero.querySelector("p");
    if (note) note.textContent = `${ready} of ${catalog.length || entries.length} visualisations ready — grouped by topic and level. Every lesson has playback, a timeline, and C / C++ solutions.`;
    for (const e of entries) {
      const impl = has.get(e.slug);
      const card = el("a", "home-card" + (impl ? "" : " pending"));
      if (impl) card.href = "#/p=" + e.slug;
      else card.setAttribute("aria-disabled", "true");
      const h = el("h3");
      h.appendChild(el("span", "home-card-title", (impl && impl.title) || e.title));
      if (e.nc) addNcTag(h);
      const p = el("p", null, (impl ? "" : "coming soon · ") + (e.category || "") + (e.level ? " · " + e.level : ""));
      card.appendChild(h);
      card.appendChild(p);
      if (e.ncName) card.title = e.ncName + " · NeetCode 250";
      grid.appendChild(card);
    }
  }

  function hideHome() {
    const hero = $("#home-hero");
    if (hero) hero.style.display = "none";
    $("#main").classList.remove("home");
    $("#controlbar").style.display = "";
    $("#stage").style.display = "";
    $("#timeline-wrap").style.display = "";
    $("#narratives").style.display = "";
    $("#detail").style.display = "";
  }

  /* ---------------- Load a visualisation ---------------- */
  function loadViz(id, keepInput) {
    const def = VIZ.get(id);
    if (!def) { goto(null); return; }
    stop();
    state.vizId = id;
    state.approachIdx = 0;
    if (!keepInput || state.inputRaw == null) {
      state.inputRaw = def.input && def.input.default != null ? String(def.input.default) : "";
    }
    hideHome();

    const entry = (window.VIZ_CATALOG || []).find((e) => e.slug === id);
    $("#viz-title").textContent = def.title;
    $("#viz-difficulty").textContent = (entry && entry.level) || def.difficulty || "";
    const source = $("#viz-source");
    if (source) {
      source.textContent = entry && entry.nc ? "NeetCode 250" + (entry.ncDifficulty ? " · " + entry.ncDifficulty : "") : "";
      source.title = entry && entry.ncName ? entry.ncName : "";
    }
    $("#viz-desc").textContent = def.description || "";

    // approach tabs
    const row = $("#approaches");
    row.innerHTML = "";
    (def.approaches || []).forEach((a, i) => {
      const b = el("button", "tab-btn" + (i === state.approachIdx ? " active" : ""));
      b.setAttribute("role", "tab");
      b.appendChild(el("span", "num", String(i + 1)));
      b.appendChild(el("span", null, a.name));
      if (a.complexity) b.appendChild(el("span", "cx", a.complexity));
      b.addEventListener("click", () => selectApproach(i));
      row.appendChild(b);
    });

    // input
    $("#input-label").textContent = (def.input && def.input.label) || "Input";
    $("#viz-input").value = state.inputRaw;

    rebuild(true);
    buildSidebar();
  }

  function selectApproach(i) {
    state.approachIdx = i;
    [...$("#approaches").children].forEach((b, k) => b.classList.toggle("active", k === i));
    stop();
    rebuild(true);
  }

  /* ---------------- Build steps from input ---------------- */
  function rebuild(resetStep) {
    const def = VIZ.get(state.vizId);
    if (!def) return;
    const approach = (def.approaches || [])[state.approachIdx];
    if (!approach) return;

    const parser = PARSERS[(def.input && def.input.parse) || "ints"];
    let parsed;
    try {
      parsed = parser(state.inputRaw);
      if (Array.isArray(parsed) && parsed.length > 40) throw new Error("Keep inputs to 40 items so steps stay readable.");
      if (typeof parsed === "string" && parsed.length > 160) throw new Error("Keep inputs to 160 characters so steps stay readable.");
      if (Array.isArray(parsed) && Array.isArray(parsed[0]) && parsed.length > 16) throw new Error("Keep it to 16 pairs or fewer.");
      state.parsed = parsed;
      state.error = null;
    } catch (e) {
      state.error = e.message;
      state.steps = [];
      renderError(e.message);
      return;
    }

    let steps;
    try {
      steps = approach.steps(state.parsed) || [];
    } catch (e) {
      console.error("steps() failed for", def.id, e);
      state.error = "This visualisation failed on that input.";
      renderError(state.error);
      return;
    }
    state.steps = steps;
    state.stepIdx = resetStep ? 0 : Math.min(state.stepIdx, steps.length - 1);
    renderTimeline();
    renderStep();
    renderDetail();
  }

  function renderError(msg) {
    $("#stage").innerHTML = "";
    const box = el("div", "narrative");
    box.appendChild(el("div", "narrative-head", "Input problem"));
    box.appendChild(el("p", null, msg));
    $("#stage").appendChild(box);
    $("#timeline").innerHTML = "";
    $("#counters").innerHTML = "";
    $("#legend").innerHTML = "";
    $("#narr-happened").textContent = "";
    $("#narr-why").textContent = "";
    $("#step-now").textContent = "0";
    $("#step-total").textContent = "0";
    syncTransport();
  }

  /* ---------------- Renderers ---------------- */
  function cellNode(c, showIdx) {
    const n = el("div", "cell");
    n.classList.add(c.state ? "st-" + c.state : "st-idle");
    if (c.wide) n.classList.add("wide");
    if (c.empty) n.classList.add("empty");
    if (showIdx && c.idx != null) n.appendChild(el("span", "idx", String(c.idx)));
    n.appendChild(document.createTextNode(c.v == null ? (c.empty ? (c.emptyText || "—") : "?") : String(c.v)));
    if (c.tag) n.appendChild(el("span", "tag", c.tag));
    return n;
  }

  function renderCells(step) {
    const stage = $("#stage");
    stage.innerHTML = "";
    const tracks = step.tracks || [];
    const showIdx = step.showIdx !== false;
    tracks.forEach((t) => {
      const row = el("div", "track" + (t.dir === "col" ? " col" : ""));
      row.appendChild(el("div", "track-label", t.label || ""));
      const cells = el("div", "cells");
      (t.cells || []).forEach((c, i) => {
        if (t.arrows && i > 0) {
          const a = el("span", "arrow", "→");
          if (c.state === "read") a.classList.add("st-read");
          cells.appendChild(a);
        }
        cells.appendChild(cellNode({ idx: showIdx ? i : null, ...c }, true));
      });
      row.appendChild(cells);
      stage.appendChild(row);
    });
  }

  function renderList(step) {
    // step: {kind:"list", nodes:[{v,state,tag?}], showIdx}
    const stage = $("#stage");
    stage.innerHTML = "";
    const row = el("div", "track");
    row.appendChild(el("div", "track-label", step.label || "linked list"));
    const cells = el("div", "cells");
    (step.nodes || []).forEach((nd, i) => {
      if (i > 0) {
        const a = el("span", "arrow", "→");
        if (nd.state === "read") a.classList.add("st-read");
        cells.appendChild(a);
      }
      cells.appendChild(cellNode(nd, step.showIdx !== false));
    });
    if (step.nil !== false) {
      if ((step.nodes || []).length) cells.appendChild(el("span", "arrow", "→"));
      const nil = el("div", "cell st-idle empty", "null");
      cells.appendChild(nil);
    }
    row.appendChild(cells);
    stage.appendChild(row);
    if (step.extraLabel) stage.appendChild(el("div", "block-label", step.extraLabel));
  }

  function renderGrid(step) {
    const stage = $("#stage");
    stage.innerHTML = "";
    const wrap = el("div", "grid-wrap");
    const rowHeads = step.rowHeads || null;
    const colHeads = step.colHeads || null;
    const rows = step.rows || 0, cols = step.cols || 0;
    const cellAt = (r, c) => (step.cells || []).find((x) => x.r === r && x.c === c) || null;

    if (colHeads) {
      const hr = el("div", "grid-row");
      hr.appendChild(el("div", "grid-head", rowHeads ? "" : ""));
      colHeads.forEach((h) => hr.appendChild(el("div", "grid-head", String(h))));
      wrap.appendChild(hr);
    }
    for (let r = 0; r < rows; r++) {
      const rowEl = el("div", "grid-row");
      if (rowHeads) rowEl.appendChild(el("div", "grid-head", String(rowHeads[r])));
      for (let c = 0; c < cols; c++) {
        const cd = cellAt(r, c) || {};
        const n = el("div", "grid-cell " + (cd.state ? "st-" + cd.state : "st-idle"));
        n.textContent = cd.v == null ? "" : String(cd.v);
        rowEl.appendChild(n);
      }
      wrap.appendChild(rowEl);
    }
    stage.appendChild(wrap);
    if (step.label) stage.appendChild(el("div", "block-label", step.label));
  }

  function layoutTree(root, isLeaf, val, left, right) {
    // returns {nodes:[{id,x,y}], edges:[{a,b}]} in a 100-unit coordinate space
    const nodes = [], edges = [];
    let leafX = 0;
    function walk(n, depth) {
      if (n == null) return null;
      if (isLeaf(n)) {
        const x = leafX * 10 + 5;
        leafX++;
        const node = { id: idOf(n), x, y: depth * 16 + 8, raw: n };
        nodes.push(node);
        return node;
      }
      const l = walk(left(n), depth + 1);
      const r = walk(right(n), depth + 1);
      const x = l && r ? (l.x + r.x) / 2 : l ? l.x + 5 : r ? r.x - 5 : leafX++ * 10 + 5;
      const node = { id: idOf(n), x, y: depth * 16 + 8, raw: n };
      nodes.push(node);
      if (l) edges.push({ a: node.id, b: l.id });
      if (r) edges.push({ a: node.id, b: r.id });
      return node;
    }
    function idOf(n) { return typeof n === "object" && n !== null && n.id != null ? n.id : String(val(n)); }
    walk(root, 0);
    const maxX = Math.max(10, ...nodes.map((n) => n.x));
    const maxY = Math.max(8, ...nodes.map((n) => n.y));
    return { nodes, edges, w: maxX + 5, h: maxY + 10 };
  }

  function renderTree(step) {
    const stage = $("#stage");
    stage.innerHTML = "";
    const root = step.tree;
    const val = step.value || ((n) => (typeof n === "object" ? n.v : n));
    const left = step.left || ((n) => (typeof n === "object" ? n.l : null));
    const right = step.right || ((n) => (typeof n === "object" ? n.r : null));
    const isLeaf = (n) => left(n) == null && right(n) == null;
    const { nodes, edges, w, h } = layoutTree(root, isLeaf, val, left, right);
    const states = step.nodeStates || {};
    const scale = Math.min(11, Math.max(6, w / Math.max(6, nodes.length)));

    const svgNS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(svgNS, "svg");
    svg.setAttribute("viewBox", `0 0 ${w} ${h}`);
    svg.setAttribute("width", String(Math.min(980, w * 16)));
    svg.setAttribute("height", String(Math.max(150, h * 13)));
    const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));

    edges.forEach((e) => {
      const a = byId[e.a], b = byId[e.b];
      if (!a || !b) return;
      const line = document.createElementNS(svgNS, "line");
      line.setAttribute("x1", a.x); line.setAttribute("y1", a.y + 2.4);
      line.setAttribute("x2", b.x); line.setAttribute("y2", b.y - 2.4);
      line.setAttribute("class", "edge-line" + (e.state ? " e-st-" + e.state : ""));
      svg.appendChild(line);
    });
    nodes.forEach((n) => {
      const st = states[n.id] != null ? states[n.id] : (typeof n.raw === "object" && n.raw.state) || "idle";
      const g = document.createElementNS(svgNS, "g");
      g.setAttribute("class", "n-st-" + st);
      const rect = document.createElementNS(svgNS, "rect");
      const rw = Math.min(9, Math.max(5.5, String(val(n.raw)).length * 2.2 + 3));
      rect.setAttribute("x", n.x - rw / 2); rect.setAttribute("y", n.y - 2.6);
      rect.setAttribute("width", rw); rect.setAttribute("height", 5.2);
      rect.setAttribute("rx", 1.3); rect.setAttribute("class", "node-rect");
      const txt = document.createElementNS(svgNS, "text");
      txt.setAttribute("x", n.x); txt.setAttribute("y", n.y + 0.2);
      txt.setAttribute("class", "node-text");
      txt.setAttribute("style", "font-size:2.6px");
      txt.textContent = String(val(n.raw));
      g.appendChild(rect); g.appendChild(txt);
      svg.appendChild(g);
    });
    stage.appendChild(svg);
    if (step.label) stage.appendChild(el("div", "block-label", step.label));
  }

  function renderGraph(step) {
    const stage = $("#stage");
    stage.innerHTML = "";
    const svgNS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(svgNS, "svg");
    const xs = (step.nodes || []).map((n) => n.x), ys = (step.nodes || []).map((n) => n.y);
    const w = Math.max(10, ...xs) + 8, h = Math.max(8, ...ys) + 8;
    svg.setAttribute("viewBox", `0 0 ${w} ${h}`);
    svg.setAttribute("width", String(Math.min(920, w * 20)));
    svg.setAttribute("height", String(Math.max(170, h * 20)));
    const byId = Object.fromEntries((step.nodes || []).map((n) => [n.id, n]));

    (step.edges || []).forEach((e) => {
      const a = byId[e.a], b = byId[e.b];
      if (!a || !b) return;
      const line = document.createElementNS(svgNS, "line");
      line.setAttribute("x1", a.x); line.setAttribute("y1", a.y);
      line.setAttribute("x2", b.x); line.setAttribute("y2", b.y);
      line.setAttribute("class", "edge-line" + (e.state ? " e-st-" + e.state : ""));
      svg.appendChild(line);
      if (e.directed) {
        const ang = Math.atan2(b.y - a.y, b.x - a.x);
        const hx = b.x - Math.cos(ang) * 3.2, hy = b.y - Math.sin(ang) * 3.2;
        const head = document.createElementNS(svgNS, "path");
        const p1 = [hx, hy];
        const p2 = [hx - Math.cos(ang - 0.45) * 2.2, hy - Math.sin(ang - 0.45) * 2.2];
        const p3 = [hx - Math.cos(ang + 0.45) * 2.2, hy - Math.sin(ang + 0.45) * 2.2];
        head.setAttribute("d", `M${p1} L${p2} L${p3} Z`);
        head.setAttribute("fill", e.state === "read" ? "var(--brand)" : "var(--edge-2)");
        svg.appendChild(head);
      }
    });
    (step.nodes || []).forEach((n) => {
      const g = document.createElementNS(svgNS, "g");
      g.setAttribute("class", "n-st-" + (n.state || "idle"));
      const c = document.createElementNS(svgNS, "circle");
      c.setAttribute("cx", n.x); c.setAttribute("cy", n.y); c.setAttribute("r", 3.1);
      c.setAttribute("class", "node-rect");
      const t = document.createElementNS(svgNS, "text");
      t.setAttribute("x", n.x); t.setAttribute("y", n.y + 0.15);
      t.setAttribute("class", "node-text"); t.setAttribute("style", "font-size:2.4px");
      t.textContent = String(n.label != null ? n.label : n.id);
      g.appendChild(c); g.appendChild(t);
      svg.appendChild(g);
    });
    stage.appendChild(svg);
    if (step.label) stage.appendChild(el("div", "block-label", step.label));
  }

  function renderCustom(step) {
    const stage = $("#stage");
    stage.innerHTML = "";
    if (step.label) stage.appendChild(el("div", "block-label", step.label));
    const holder = el("div");
    holder.innerHTML = step.html || "";
    stage.appendChild(holder);
  }

  const KIND_RENDERERS = {
    cells: renderCells, list: renderList, grid: renderGrid,
    tree: renderTree, graph: renderGraph, html: renderCustom,
  };

  /* ---------------- Step rendering ---------------- */
  function renderStep() {
    const step = state.steps[state.stepIdx];
    if (!step) return;
    const kind = step.kind || "cells";
    (KIND_RENDERERS[kind] || renderCells)(step);

    // counters
    const cw = $("#counters");
    cw.innerHTML = "";
    (step.counters || []).forEach((c) => {
      const box = el("div", "counter");
      box.appendChild(el("div", "counter-label", c.label));
      const v = el("div", "counter-value", String(c.value));
      if (c.total != null) {
        const t = el("span", "tot", " / " + c.total);
        v.appendChild(t);
      }
      box.appendChild(v);
      cw.appendChild(box);
    });

    // legend
    const lw = $("#legend");
    lw.innerHTML = "";
    const keys = step.legend || DEFAULT_LEGEND;
    keys.forEach((k) => {
      const item = el("div", "legend-item");
      item.appendChild(el("span", "legend-swatch st-" + k));
      item.appendChild(el("span", null, step.legendLabels && step.legendLabels[k] ? step.legendLabels[k] : STATE_LABELS[k] || k));
      lw.appendChild(item);
    });

    // narratives
    $("#narr-happened").textContent = step.happened || "";
    $("#narr-why").textContent = step.why || "";

    // timeline active state
    [...$("#timeline").children].forEach((chip, i) => {
      chip.classList.toggle("active", i === state.stepIdx);
      chip.classList.toggle("done", i < state.stepIdx);
      if (i === state.stepIdx) {
        const r = chip.getBoundingClientRect();
        if (r.left < 60 || r.right > window.innerWidth - 60) chip.scrollIntoView({ block: "nearest", inline: "center" });
      }
    });

    $("#step-now").textContent = String(state.stepIdx + 1);
    $("#step-total").textContent = String(state.steps.length);
    syncTransport();

    // code line highlight
    if (step.codeLine != null) applyCodeLine(step.codeLine);
  }

  function renderTimeline() {
    const tl = $("#timeline");
    tl.innerHTML = "";
    state.steps.forEach((s, i) => {
      const chip = el("button", "step-chip" + (i === state.steps.length - 1 ? " final" : ""));
      chip.textContent = (i + 1) + ". " + (s.title || "Step " + (i + 1));
      chip.addEventListener("click", () => { stop(); state.stepIdx = i; renderStep(); });
      tl.appendChild(chip);
    });
  }

  function syncTransport() {
    const last = state.steps.length - 1;
    $("#btn-first").disabled = state.stepIdx <= 0;
    $("#btn-prev").disabled = state.stepIdx <= 0;
    $("#btn-next").disabled = state.stepIdx >= last;
    $("#btn-last").disabled = state.stepIdx >= last;
    $("#btn-reset").disabled = state.stepIdx <= 0 && !state.playing;
    $("#btn-play").textContent = state.playing ? "Pause" : "Play";
    $("#btn-play").setAttribute("aria-label", state.playing ? "Pause" : "Play");
    $("#btn-play").disabled = state.steps.length <= 1;
  }

  /* ---------------- Playback ---------------- */
  function tick() {
    if (state.stepIdx >= state.steps.length - 1) { stop(); return; }
    state.stepIdx++;
    renderStep();
    schedule();
  }
  function schedule() {
    clearTimeout(state.timer);
    if (!state.playing) return;
    const ms = SPEEDS[$("#speed").value] || SPEEDS.normal;
    state.timer = setTimeout(tick, ms);
  }
  function play() {
    if (state.steps.length <= 1) return;
    if (state.stepIdx >= state.steps.length - 1) state.stepIdx = 0;
    state.playing = true;
    renderStep();
    schedule();
  }
  function stop() {
    state.playing = false;
    clearTimeout(state.timer);
    syncTransport();
  }
  const togglePlay = () => (state.playing ? stop() : play());

  function move(delta) {
    stop();
    state.stepIdx = Math.max(0, Math.min(state.steps.length - 1, state.stepIdx + delta));
    renderStep();
  }

  /* ---------------- Detail tabs ---------------- */
  function currentApproach() {
    const def = VIZ.get(state.vizId);
    return def ? (def.approaches || [])[state.approachIdx] : null;
  }

  function highlight(code, lang) {
    // minimal C/C++ highlighter: comments, strings, numbers, keywords
    let out = "";
    const kw = "int long char void double float short unsigned signed const static struct enum union typedef return if else for while do switch case break continue sizeof goto default extern inline restrict bool size_t ssize_t NULL true false nullptr class public private protected namespace template typename using new delete this try catch throw auto override virtual const_cast nullptr using std std::vector std::string std::cout std::endl std::printf include define ifdef ifndef endif pragma";
    const kwSet = new Set(kw.split(/\s+/));
    const re = /(\/\/[^\n]*|\/\*[\s\S]*?\*\/)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')|\b(\d+(?:\.\d+)?)\b|\b([A-Za-z_]\w*)\b/g;
    let last = 0, m;
    while ((m = re.exec(code))) {
      out += esc(code.slice(last, m.index));
      if (m[1]) out += "<span class='cm'>" + esc(m[1]) + "</span>";
      else if (m[2]) out += "<span class='str'>" + esc(m[2]) + "</span>";
      else if (m[3]) out += "<span class='num'>" + esc(m[3]) + "</span>";
      else if (m[4]) {
        const w = m[4];
        const after = code.slice(re.lastIndex).match(/^\s*\(/);
        if (kwSet.has(w)) out += "<span class='kw'>" + esc(w) + "</span>";
        else if (after) out += "<span class='fn'>" + esc(w) + "</span>";
        else out += esc(w);
      }
      last = re.lastIndex;
    }
    out += esc(code.slice(last));
    return out;
  }
  function esc(s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

  function applyCodeLine(line) {
    const code = $("#code-body");
    const lines = code.querySelectorAll(".ln-hl");
    lines.forEach((l) => l.classList.remove("ln-hl"));
    const spans = code.querySelectorAll("span[lang-line]");
    // fallback: we store raw lines when building
    if (state.codeLineNodes && state.codeLineNodes[line]) {
      state.codeLineNodes[line].classList.add("ln-hl");
    }
  }

  function renderDetail() {
    const a = currentApproach();
    const def = VIZ.get(state.vizId);
    if (!a) return;

    const ideaEl = $("#tab-idea");
    ideaEl.innerHTML = "";
    (Array.isArray(a.idea) ? a.idea : [a.idea]).filter(Boolean).forEach((p) => ideaEl.appendChild(el("p", null, p)));

    const probEl = $("#tab-problem");
    probEl.innerHTML = "";
    const prob = a.problem || (def && def.problem) || null;
    (Array.isArray(prob) ? prob : [prob]).filter(Boolean).forEach((p) => probEl.appendChild(el("p", null, p)));
    if (!prob) probEl.appendChild(el("p", null, "—"));

    renderCode();
  }

  function renderCode() {
    const a = currentApproach();
    const body = $("#code-body");
    state.codeLineNodes = [];
    if (!a || !a.code) { body.textContent = "No code for this approach."; return; }
    const code = state.lang === "c" ? a.code.c : a.code.cpp;
    if (!code) { body.textContent = "No " + (state.lang === "c" ? "C" : "C++") + " version for this approach."; return; }
    body.innerHTML = "";
    const lines = code.replace(/\r/g, "").split("\n");
    lines.forEach((ln, i) => {
      const span = document.createElement("span");
      span.innerHTML = (highlight(ln, state.lang) || "&nbsp;");
      span.style.display = "block";
      body.appendChild(span);
      state.codeLineNodes[i] = span;
    });
    const step = state.steps[state.stepIdx];
    if (step && step.codeLine != null) applyCodeLine(step.codeLine);
  }

  /* ---------------- Events ---------------- */
  function bind() {
    $("#btn-play").addEventListener("click", togglePlay);
    $("#btn-next").addEventListener("click", () => move(1));
    $("#btn-prev").addEventListener("click", () => move(-1));
    $("#btn-first").addEventListener("click", () => { stop(); state.stepIdx = 0; renderStep(); });
    $("#btn-last").addEventListener("click", () => { stop(); state.stepIdx = state.steps.length - 1; renderStep(); });
    $("#btn-reset").addEventListener("click", () => { stop(); state.stepIdx = 0; renderStep(); });
    $("#speed").addEventListener("change", () => { if (state.playing) schedule(); });
    $("#run-btn").addEventListener("click", () => { stop(); state.inputRaw = $("#viz-input").value; rebuild(true); });
    $("#viz-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter") { stop(); state.inputRaw = $("#viz-input").value; rebuild(true); }
    });
    $("#search").addEventListener("input", () => {
      if ($("#main").classList.contains("home")) renderHome(); else buildSidebar();
    });

    document.querySelectorAll(".detail-tab").forEach((b) => {
      b.addEventListener("click", () => {
        document.querySelectorAll(".detail-tab").forEach((x) => x.classList.remove("active"));
        document.querySelectorAll(".tab-pane").forEach((x) => x.classList.remove("active"));
        b.classList.add("active");
        $("#tab-" + b.dataset.tab).classList.add("active");
        state.detailTab = b.dataset.tab;
        if (b.dataset.tab === "code") renderCode();
      });
    });
    document.querySelectorAll(".lang-btn").forEach((b) => {
      b.addEventListener("click", () => {
        document.querySelectorAll(".lang-btn").forEach((x) => x.classList.remove("active"));
        b.classList.add("active");
        state.lang = b.dataset.lang;
        renderCode();
      });
    });

    $("#sidebar-open").addEventListener("click", () => $("#sidebar").classList.add("open"));
    $("#sidebar-close").addEventListener("click", () => $("#sidebar").classList.remove("open"));

    window.addEventListener("hashchange", route);

    document.addEventListener("keydown", (e) => {
      if (e.target.matches("input, textarea, select")) return;
      if (e.key === "ArrowRight") { e.preventDefault(); move(1); }
      else if (e.key === "ArrowLeft") { e.preventDefault(); move(-1); }
      else if (e.key === " ") { e.preventDefault(); togglePlay(); }
      else if (e.key === "Home") { stop(); state.stepIdx = 0; renderStep(); }
      else if (e.key === "End") { stop(); state.stepIdx = state.steps.length - 1; renderStep(); }
    });
  }

  /* ---------------- Route ---------------- */
  function route() {
    const r = currentRoute();
    if (!r.id) {
      stop();
      state.vizId = null;
      buildSidebar();
      renderHome();
    } else if (r.id !== state.vizId) {
      loadViz(r.id);
    }
  }

  /* ---------------- Validation helper (used by QA) ---------------- */
  window.__validateViz = function () {
    const problems = [];
    for (const def of VIZ.all()) {
      if (!def.title) problems.push(def.id + ": missing title");
      if (!def.approaches || !def.approaches.length) { problems.push(def.id + ": no approaches"); continue; }
      if (!def.input || !def.input.parse) problems.push(def.id + ": missing input.parse");
      def.approaches.forEach((a, ai) => {
        if (!a.name) problems.push(def.id + ": approach " + ai + " missing name");
        if (!a.code || !a.code.c || !a.code.cpp) problems.push(def.id + " [" + a.name + "]: missing c/cpp code");
        if (!a.steps) { problems.push(def.id + " [" + a.name + "]: missing steps()"); return; }
        if (!def.input) return;
        let parsed;
        try { parsed = PARSERS[def.input.parse](String(def.input.default)); }
        catch (e) { problems.push(def.id + ": default input does not parse: " + e.message); return; }
        let steps;
        try { steps = a.steps(parsed); }
        catch (e) { problems.push(def.id + " [" + a.name + "]: steps() threw: " + e.message); return; }
        if (!Array.isArray(steps) || !steps.length) { problems.push(def.id + " [" + a.name + "]: steps not a non-empty array"); return; }
        steps.forEach((s, si) => {
          if (!s.title) problems.push(def.id + " step " + si + ": missing title");
          if (!s.happened) problems.push(def.id + " step " + si + ": missing happened");
          const kind = s.kind || "cells";
          if (kind === "cells" && !Array.isArray(s.tracks)) problems.push(def.id + " step " + si + ": cells kind needs tracks[]");
          if (kind === "grid" && !Array.isArray(s.cells)) problems.push(def.id + " step " + si + ": grid kind needs cells[]");
          if (kind === "tree" && s.tree == null) problems.push(def.id + " step " + si + ": tree kind needs tree");
          if (kind === "graph" && !Array.isArray(s.nodes)) problems.push(def.id + " step " + si + ": graph kind needs nodes[]");
          if (kind === "list" && !Array.isArray(s.nodes)) problems.push(def.id + " step " + si + ": list kind needs nodes[]");
        });
      });
    }
    return { total: VIZ.all().length, ok: problems.length === 0, problems };
  };

  /* ---------------- Boot ---------------- */
  function boot() {
    buildSidebar();
    bind();
    route();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
