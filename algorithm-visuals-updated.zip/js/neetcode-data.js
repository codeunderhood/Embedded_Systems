/* ============================================================
   NeetCode 250 metadata
   The list was read from the public NeetCode 250 practice page
   (18 topic groups, 60 Easy / 155 Medium / 35 Hard).
   "target" points at the local visualisation slug.  When a local
   visual already covers the same problem, target is that existing
   slug; otherwise target is the new NeetCode slug itself.
   ============================================================ */
(function () {
  "use strict";
  const problems = [
  {
    "slug": "concatenation-of-array",
    "name": "Concatenation of Array",
    "topic": "Arrays & Hashing",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "concatenation-of-array",
    "existing": false
  },
  {
    "slug": "duplicate-integer",
    "name": "Contains Duplicate",
    "topic": "Arrays & Hashing",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "contains-duplicate",
    "existing": true
  },
  {
    "slug": "is-anagram",
    "name": "Valid Anagram",
    "topic": "Arrays & Hashing",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "valid-anagram",
    "existing": true
  },
  {
    "slug": "two-integer-sum",
    "name": "Two Sum",
    "topic": "Arrays & Hashing",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "two-sum",
    "existing": true
  },
  {
    "slug": "longest-common-prefix",
    "name": "Longest Common Prefix",
    "topic": "Arrays & Hashing",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "longest-common-prefix",
    "existing": true
  },
  {
    "slug": "anagram-groups",
    "name": "Group Anagrams",
    "topic": "Arrays & Hashing",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "group-anagrams",
    "existing": true
  },
  {
    "slug": "remove-element",
    "name": "Remove Element",
    "topic": "Arrays & Hashing",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "remove-element",
    "existing": false
  },
  {
    "slug": "majority-element",
    "name": "Majority Element",
    "topic": "Arrays & Hashing",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "majority-element",
    "existing": true
  },
  {
    "slug": "design-hashset",
    "name": "Design HashSet",
    "topic": "Arrays & Hashing",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "design-hashset",
    "existing": true
  },
  {
    "slug": "design-hashmap",
    "name": "Design HashMap",
    "topic": "Arrays & Hashing",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "design-hashmap",
    "existing": true
  },
  {
    "slug": "sort-an-array",
    "name": "Sort an Array",
    "topic": "Arrays & Hashing",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "merge-sort",
    "existing": true
  },
  {
    "slug": "sort-colors",
    "name": "Sort Colors",
    "topic": "Arrays & Hashing",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "sort-colors",
    "existing": true
  },
  {
    "slug": "top-k-elements-in-list",
    "name": "Top K Frequent Elements",
    "topic": "Arrays & Hashing",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "top-k-frequent-elements",
    "existing": true
  },
  {
    "slug": "string-encode-and-decode",
    "name": "Encode and Decode Strings",
    "topic": "Arrays & Hashing",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "string-encode-and-decode",
    "existing": false
  },
  {
    "slug": "range-sum-query-2d-immutable",
    "name": "Range Sum Query 2D Immutable",
    "topic": "Arrays & Hashing",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "range-sum-query-2d-immutable",
    "existing": false
  },
  {
    "slug": "products-of-array-discluding-self",
    "name": "Product of Array Except Self",
    "topic": "Arrays & Hashing",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "product-of-array-except-self",
    "existing": true
  },
  {
    "slug": "valid-sudoku",
    "name": "Valid Sudoku",
    "topic": "Arrays & Hashing",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "valid-sudoku",
    "existing": false
  },
  {
    "slug": "longest-consecutive-sequence",
    "name": "Longest Consecutive Sequence",
    "topic": "Arrays & Hashing",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "longest-consecutive-sequence",
    "existing": true
  },
  {
    "slug": "best-time-to-buy-and-sell-stock-ii",
    "name": "Best Time to Buy And Sell Stock II",
    "topic": "Arrays & Hashing",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "best-time-to-buy-and-sell-stock-ii",
    "existing": false
  },
  {
    "slug": "majority-element-ii",
    "name": "Majority Element II",
    "topic": "Arrays & Hashing",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "majority-element-ii",
    "existing": false
  },
  {
    "slug": "subarray-sum-equals-k",
    "name": "Subarray Sum Equals K",
    "topic": "Arrays & Hashing",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "subarray-sum-equals-k",
    "existing": true
  },
  {
    "slug": "first-missing-positive",
    "name": "First Missing Positive",
    "topic": "Arrays & Hashing",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "first-missing-positive",
    "existing": true
  },
  {
    "slug": "reverse-string",
    "name": "Reverse String",
    "topic": "Two Pointers",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "reverse-string",
    "existing": false
  },
  {
    "slug": "is-palindrome",
    "name": "Valid Palindrome",
    "topic": "Two Pointers",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "valid-palindrome",
    "existing": true
  },
  {
    "slug": "valid-palindrome-ii",
    "name": "Valid Palindrome II",
    "topic": "Two Pointers",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "valid-palindrome-ii",
    "existing": false
  },
  {
    "slug": "merge-strings-alternately",
    "name": "Merge Strings Alternately",
    "topic": "Two Pointers",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "merge-strings-alternately",
    "existing": false
  },
  {
    "slug": "merge-sorted-array",
    "name": "Merge Sorted Array",
    "topic": "Two Pointers",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "merge-sorted-arrays",
    "existing": true
  },
  {
    "slug": "remove-duplicates-from-sorted-array",
    "name": "Remove Duplicates From Sorted Array",
    "topic": "Two Pointers",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "remove-duplicates-from-sorted-array",
    "existing": true
  },
  {
    "slug": "two-integer-sum-ii",
    "name": "Two Sum II Input Array Is Sorted",
    "topic": "Two Pointers",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "two-sum-ii",
    "existing": true
  },
  {
    "slug": "three-integer-sum",
    "name": "3Sum",
    "topic": "Two Pointers",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "three-sum",
    "existing": true
  },
  {
    "slug": "4sum",
    "name": "4Sum",
    "topic": "Two Pointers",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "four-sum",
    "existing": true
  },
  {
    "slug": "rotate-array",
    "name": "Rotate Array",
    "topic": "Two Pointers",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "rotate-array",
    "existing": true
  },
  {
    "slug": "max-water-container",
    "name": "Container With Most Water",
    "topic": "Two Pointers",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "container-with-most-water",
    "existing": true
  },
  {
    "slug": "boats-to-save-people",
    "name": "Boats to Save People",
    "topic": "Two Pointers",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "boats-to-save-people",
    "existing": false
  },
  {
    "slug": "trapping-rain-water",
    "name": "Trapping Rain Water",
    "topic": "Two Pointers",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "trapping-rain-water",
    "existing": true
  },
  {
    "slug": "contains-duplicate-ii",
    "name": "Contains Duplicate II",
    "topic": "Sliding Window",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "contains-duplicate-ii",
    "existing": false
  },
  {
    "slug": "buy-and-sell-crypto",
    "name": "Best Time to Buy And Sell Stock",
    "topic": "Sliding Window",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "best-time-to-buy-and-sell-stock",
    "existing": true
  },
  {
    "slug": "longest-substring-without-duplicates",
    "name": "Longest Substring Without Repeating Characters",
    "topic": "Sliding Window",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "longest-substring-without-repeating-characters",
    "existing": true
  },
  {
    "slug": "longest-repeating-substring-with-replacement",
    "name": "Longest Repeating Character Replacement",
    "topic": "Sliding Window",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "longest-repeating-character-replacement",
    "existing": true
  },
  {
    "slug": "permutation-string",
    "name": "Permutation In String",
    "topic": "Sliding Window",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "permutation-in-string",
    "existing": true
  },
  {
    "slug": "minimum-size-subarray-sum",
    "name": "Minimum Size Subarray Sum",
    "topic": "Sliding Window",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "minimum-size-subarray-sum",
    "existing": true
  },
  {
    "slug": "find-k-closest-elements",
    "name": "Find K Closest Elements",
    "topic": "Sliding Window",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "find-k-closest-elements",
    "existing": false
  },
  {
    "slug": "minimum-window-with-characters",
    "name": "Minimum Window Substring",
    "topic": "Sliding Window",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "minimum-window-substring",
    "existing": true
  },
  {
    "slug": "sliding-window-maximum",
    "name": "Sliding Window Maximum",
    "topic": "Sliding Window",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "sliding-window-maximum",
    "existing": true
  },
  {
    "slug": "binary-search",
    "name": "Binary Search",
    "topic": "Binary Search",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "binary-search",
    "existing": true
  },
  {
    "slug": "search-insert-position",
    "name": "Search Insert Position",
    "topic": "Binary Search",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "search-insert-position",
    "existing": true
  },
  {
    "slug": "guess-number-higher-or-lower",
    "name": "Guess Number Higher Or Lower",
    "topic": "Binary Search",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "guess-number-higher-or-lower",
    "existing": false
  },
  {
    "slug": "sqrtx",
    "name": "Sqrt(x)",
    "topic": "Binary Search",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "sqrtx",
    "existing": false
  },
  {
    "slug": "search-2d-matrix",
    "name": "Search a 2D Matrix",
    "topic": "Binary Search",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "search-a-2d-matrix",
    "existing": true
  },
  {
    "slug": "eating-bananas",
    "name": "Koko Eating Bananas",
    "topic": "Binary Search",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "koko-eating-bananas",
    "existing": true
  },
  {
    "slug": "capacity-to-ship-packages-within-d-days",
    "name": "Capacity to Ship Packages Within D Days",
    "topic": "Binary Search",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "capacity-to-ship-packages",
    "existing": true
  },
  {
    "slug": "find-minimum-in-rotated-sorted-array",
    "name": "Find Minimum In Rotated Sorted Array",
    "topic": "Binary Search",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "find-minimum-in-rotated-sorted-array",
    "existing": true
  },
  {
    "slug": "find-target-in-rotated-sorted-array",
    "name": "Search In Rotated Sorted Array",
    "topic": "Binary Search",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "search-in-rotated-sorted-array",
    "existing": true
  },
  {
    "slug": "search-in-rotated-sorted-array-ii",
    "name": "Search In Rotated Sorted Array II",
    "topic": "Binary Search",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "search-in-rotated-sorted-array-ii",
    "existing": false
  },
  {
    "slug": "time-based-key-value-store",
    "name": "Time Based Key Value Store",
    "topic": "Binary Search",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "time-based-key-value-store",
    "existing": false
  },
  {
    "slug": "split-array-largest-sum",
    "name": "Split Array Largest Sum",
    "topic": "Binary Search",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "split-array-largest-sum",
    "existing": true
  },
  {
    "slug": "median-of-two-sorted-arrays",
    "name": "Median of Two Sorted Arrays",
    "topic": "Binary Search",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "median-of-two-sorted-arrays",
    "existing": true
  },
  {
    "slug": "find-in-mountain-array",
    "name": "Find in Mountain Array",
    "topic": "Binary Search",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "find-in-mountain-array",
    "existing": false
  },
  {
    "slug": "reverse-a-linked-list",
    "name": "Reverse Linked List",
    "topic": "Linked List",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "reverse-linked-list",
    "existing": true
  },
  {
    "slug": "merge-two-sorted-linked-lists",
    "name": "Merge Two Sorted Lists",
    "topic": "Linked List",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "merge-two-sorted-lists",
    "existing": true
  },
  {
    "slug": "linked-list-cycle-detection",
    "name": "Linked List Cycle",
    "topic": "Linked List",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "linked-list-cycle",
    "existing": true
  },
  {
    "slug": "reorder-linked-list",
    "name": "Reorder List",
    "topic": "Linked List",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "reorder-list",
    "existing": true
  },
  {
    "slug": "remove-node-from-end-of-linked-list",
    "name": "Remove Nth Node From End of List",
    "topic": "Linked List",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "remove-nth-node-from-end",
    "existing": true
  },
  {
    "slug": "copy-linked-list-with-random-pointer",
    "name": "Copy List With Random Pointer",
    "topic": "Linked List",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "copy-list-with-random-pointer",
    "existing": true
  },
  {
    "slug": "add-two-numbers",
    "name": "Add Two Numbers",
    "topic": "Linked List",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "add-two-numbers",
    "existing": true
  },
  {
    "slug": "find-duplicate-integer",
    "name": "Find The Duplicate Number",
    "topic": "Linked List",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "find-duplicate-integer",
    "existing": false
  },
  {
    "slug": "reverse-linked-list-ii",
    "name": "Reverse Linked List II",
    "topic": "Linked List",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "reverse-linked-list-ii",
    "existing": true
  },
  {
    "slug": "design-circular-queue",
    "name": "Design Circular Queue",
    "topic": "Linked List",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "design-circular-queue",
    "existing": true
  },
  {
    "slug": "lru-cache",
    "name": "LRU Cache",
    "topic": "Linked List",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "lru-cache",
    "existing": true
  },
  {
    "slug": "lfu-cache",
    "name": "LFU Cache",
    "topic": "Linked List",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "lfu-cache",
    "existing": true
  },
  {
    "slug": "merge-k-sorted-linked-lists",
    "name": "Merge K Sorted Lists",
    "topic": "Linked List",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "merge-k-sorted-lists",
    "existing": true
  },
  {
    "slug": "reverse-nodes-in-k-group",
    "name": "Reverse Nodes In K Group",
    "topic": "Linked List",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "reverse-nodes-in-k-group",
    "existing": true
  },
  {
    "slug": "baseball-game",
    "name": "Baseball Game",
    "topic": "Stack",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "baseball-game",
    "existing": false
  },
  {
    "slug": "validate-parentheses",
    "name": "Valid Parentheses",
    "topic": "Stack",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "valid-parentheses",
    "existing": true
  },
  {
    "slug": "implement-stack-using-queues",
    "name": "Implement Stack Using Queues",
    "topic": "Stack",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "implement-stack-using-queues",
    "existing": true
  },
  {
    "slug": "implement-queue-using-stacks",
    "name": "Implement Queue using Stacks",
    "topic": "Stack",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "implement-queue-using-stacks",
    "existing": true
  },
  {
    "slug": "minimum-stack",
    "name": "Min Stack",
    "topic": "Stack",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "min-stack",
    "existing": true
  },
  {
    "slug": "evaluate-reverse-polish-notation",
    "name": "Evaluate Reverse Polish Notation",
    "topic": "Stack",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "evaluate-reverse-polish-notation",
    "existing": true
  },
  {
    "slug": "asteroid-collision",
    "name": "Asteroid Collision",
    "topic": "Stack",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "asteroid-collision",
    "existing": true
  },
  {
    "slug": "daily-temperatures",
    "name": "Daily Temperatures",
    "topic": "Stack",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "daily-temperatures",
    "existing": true
  },
  {
    "slug": "online-stock-span",
    "name": "Online Stock Span",
    "topic": "Stack",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "stock-span",
    "existing": true
  },
  {
    "slug": "car-fleet",
    "name": "Car Fleet",
    "topic": "Stack",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "car-fleet",
    "existing": false
  },
  {
    "slug": "simplify-path",
    "name": "Simplify Path",
    "topic": "Stack",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "simplify-path",
    "existing": true
  },
  {
    "slug": "decode-string",
    "name": "Decode String",
    "topic": "Stack",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "decode-string",
    "existing": true
  },
  {
    "slug": "maximum-frequency-stack",
    "name": "Maximum Frequency Stack",
    "topic": "Stack",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "maximum-frequency-stack",
    "existing": false
  },
  {
    "slug": "largest-rectangle-in-histogram",
    "name": "Largest Rectangle In Histogram",
    "topic": "Stack",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "largest-rectangle-in-histogram",
    "existing": true
  },
  {
    "slug": "binary-tree-inorder-traversal",
    "name": "Binary Tree Inorder Traversal",
    "topic": "Trees",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "binary-tree-inorder-traversal",
    "existing": false
  },
  {
    "slug": "binary-tree-preorder-traversal",
    "name": "Binary Tree Preorder Traversal",
    "topic": "Trees",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "binary-tree-preorder-traversal",
    "existing": false
  },
  {
    "slug": "binary-tree-postorder-traversal",
    "name": "Binary Tree Postorder Traversal",
    "topic": "Trees",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "binary-tree-postorder-traversal",
    "existing": false
  },
  {
    "slug": "invert-a-binary-tree",
    "name": "Invert Binary Tree",
    "topic": "Trees",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "invert-binary-tree",
    "existing": true
  },
  {
    "slug": "depth-of-binary-tree",
    "name": "Maximum Depth of Binary Tree",
    "topic": "Trees",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "maximum-depth-of-binary-tree",
    "existing": true
  },
  {
    "slug": "binary-tree-diameter",
    "name": "Diameter of Binary Tree",
    "topic": "Trees",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "diameter-of-binary-tree",
    "existing": true
  },
  {
    "slug": "balanced-binary-tree",
    "name": "Balanced Binary Tree",
    "topic": "Trees",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "balanced-binary-tree",
    "existing": true
  },
  {
    "slug": "same-binary-tree",
    "name": "Same Tree",
    "topic": "Trees",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "same-tree",
    "existing": true
  },
  {
    "slug": "subtree-of-a-binary-tree",
    "name": "Subtree of Another Tree",
    "topic": "Trees",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "subtree-of-a-binary-tree",
    "existing": false
  },
  {
    "slug": "lowest-common-ancestor-in-binary-search-tree",
    "name": "Lowest Common Ancestor of a Binary Search Tree",
    "topic": "Trees",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "lowest-common-ancestor",
    "existing": true
  },
  {
    "slug": "insert-into-a-binary-search-tree",
    "name": "Insert into a Binary Search Tree",
    "topic": "Trees",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "insert-into-a-binary-search-tree",
    "existing": false
  },
  {
    "slug": "delete-node-in-a-bst",
    "name": "Delete Node in a BST",
    "topic": "Trees",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "delete-node-in-a-bst",
    "existing": false
  },
  {
    "slug": "level-order-traversal-of-binary-tree",
    "name": "Binary Tree Level Order Traversal",
    "topic": "Trees",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "binary-tree-level-order-traversal",
    "existing": true
  },
  {
    "slug": "binary-tree-right-side-view",
    "name": "Binary Tree Right Side View",
    "topic": "Trees",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "right-side-view",
    "existing": true
  },
  {
    "slug": "construct-quad-tree",
    "name": "Construct Quad Tree",
    "topic": "Trees",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "construct-quad-tree",
    "existing": true
  },
  {
    "slug": "count-good-nodes-in-binary-tree",
    "name": "Count Good Nodes In Binary Tree",
    "topic": "Trees",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "count-good-nodes-in-binary-tree",
    "existing": false
  },
  {
    "slug": "valid-binary-search-tree",
    "name": "Validate Binary Search Tree",
    "topic": "Trees",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "validate-binary-search-tree",
    "existing": true
  },
  {
    "slug": "kth-smallest-integer-in-bst",
    "name": "Kth Smallest Element In a Bst",
    "topic": "Trees",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "kth-smallest-element-in-bst",
    "existing": true
  },
  {
    "slug": "binary-tree-from-preorder-and-inorder-traversal",
    "name": "Construct Binary Tree From Preorder And Inorder Traversal",
    "topic": "Trees",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "construct-tree-from-traversals",
    "existing": true
  },
  {
    "slug": "house-robber-iii",
    "name": "House Robber III",
    "topic": "Trees",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "house-robber-iii",
    "existing": true
  },
  {
    "slug": "delete-leaves-with-a-given-value",
    "name": "Delete Leaves With a Given Value",
    "topic": "Trees",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "delete-leaves-with-a-given-value",
    "existing": false
  },
  {
    "slug": "binary-tree-maximum-path-sum",
    "name": "Binary Tree Maximum Path Sum",
    "topic": "Trees",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "binary-tree-maximum-path-sum",
    "existing": true
  },
  {
    "slug": "serialize-and-deserialize-binary-tree",
    "name": "Serialize And Deserialize Binary Tree",
    "topic": "Trees",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "serialize-and-deserialize-binary-tree",
    "existing": true
  },
  {
    "slug": "implement-prefix-tree",
    "name": "Implement Trie Prefix Tree",
    "topic": "Tries",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "implement-trie",
    "existing": true
  },
  {
    "slug": "design-word-search-data-structure",
    "name": "Design Add And Search Words Data Structure",
    "topic": "Tries",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "design-add-and-search-words",
    "existing": true
  },
  {
    "slug": "extra-characters-in-a-string",
    "name": "Extra Characters in a String",
    "topic": "Tries",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "extra-characters-in-a-string",
    "existing": false
  },
  {
    "slug": "search-for-word-ii",
    "name": "Word Search II",
    "topic": "Tries",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "word-search-ii",
    "existing": true
  },
  {
    "slug": "sum-of-all-subset-xor-totals",
    "name": "Sum of All Subsets XOR Total",
    "topic": "Backtracking",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "sum-of-all-subset-xor-totals",
    "existing": false
  },
  {
    "slug": "subsets",
    "name": "Subsets",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "subsets",
    "existing": true
  },
  {
    "slug": "combination-target-sum",
    "name": "Combination Sum",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "combination-sum",
    "existing": true
  },
  {
    "slug": "combination-target-sum-ii",
    "name": "Combination Sum II",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "combination-sum-ii",
    "existing": true
  },
  {
    "slug": "combinations",
    "name": "Combinations",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "combinations",
    "existing": true
  },
  {
    "slug": "permutations",
    "name": "Permutations",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "permutations",
    "existing": true
  },
  {
    "slug": "subsets-ii",
    "name": "Subsets II",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "subsets-ii",
    "existing": true
  },
  {
    "slug": "permutations-ii",
    "name": "Permutations II",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "permutations-ii",
    "existing": true
  },
  {
    "slug": "generate-parentheses",
    "name": "Generate Parentheses",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "generate-parentheses",
    "existing": true
  },
  {
    "slug": "search-for-word",
    "name": "Word Search",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "word-search",
    "existing": true
  },
  {
    "slug": "palindrome-partitioning",
    "name": "Palindrome Partitioning",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "palindrome-partitioning",
    "existing": true
  },
  {
    "slug": "combinations-of-a-phone-number",
    "name": "Letter Combinations of a Phone Number",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "letter-combinations-of-a-phone-number",
    "existing": true
  },
  {
    "slug": "matchsticks-to-square",
    "name": "Matchsticks to Square",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "matchsticks-to-square",
    "existing": true
  },
  {
    "slug": "partition-to-k-equal-sum-subsets",
    "name": "Partition to K Equal Sum Subsets",
    "topic": "Backtracking",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "partition-to-k-equal-sum-subsets",
    "existing": false
  },
  {
    "slug": "n-queens",
    "name": "N Queens",
    "topic": "Backtracking",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "n-queens",
    "existing": true
  },
  {
    "slug": "n-queens-ii",
    "name": "N Queens II",
    "topic": "Backtracking",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "n-queens-ii",
    "existing": true
  },
  {
    "slug": "word-break-ii",
    "name": "Word Break II",
    "topic": "Backtracking",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "word-break-ii",
    "existing": true
  },
  {
    "slug": "kth-largest-integer-in-a-stream",
    "name": "Kth Largest Element In a Stream",
    "topic": "Heap / Priority Queue",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "kth-largest-integer-in-a-stream",
    "existing": false
  },
  {
    "slug": "last-stone-weight",
    "name": "Last Stone Weight",
    "topic": "Heap / Priority Queue",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "last-stone-weight",
    "existing": true
  },
  {
    "slug": "k-closest-points-to-origin",
    "name": "K Closest Points to Origin",
    "topic": "Heap / Priority Queue",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "k-closest-points-to-origin",
    "existing": true
  },
  {
    "slug": "kth-largest-element-in-an-array",
    "name": "Kth Largest Element In An Array",
    "topic": "Heap / Priority Queue",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "kth-largest-element",
    "existing": true
  },
  {
    "slug": "task-scheduling",
    "name": "Task Scheduler",
    "topic": "Heap / Priority Queue",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "task-scheduler",
    "existing": true
  },
  {
    "slug": "design-twitter-feed",
    "name": "Design Twitter",
    "topic": "Heap / Priority Queue",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "design-twitter-feed",
    "existing": false
  },
  {
    "slug": "single-threaded-cpu",
    "name": "Single Threaded CPU",
    "topic": "Heap / Priority Queue",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "single-threaded-cpu",
    "existing": false
  },
  {
    "slug": "reorganize-string",
    "name": "Reorganize String",
    "topic": "Heap / Priority Queue",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "reorganize-string",
    "existing": true
  },
  {
    "slug": "longest-happy-string",
    "name": "Longest Happy String",
    "topic": "Heap / Priority Queue",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "longest-happy-string",
    "existing": false
  },
  {
    "slug": "car-pooling",
    "name": "Car Pooling",
    "topic": "Heap / Priority Queue",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "car-pooling",
    "existing": true
  },
  {
    "slug": "find-median-in-a-data-stream",
    "name": "Find Median From Data Stream",
    "topic": "Heap / Priority Queue",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "find-median-from-data-stream",
    "existing": true
  },
  {
    "slug": "ipo",
    "name": "IPO",
    "topic": "Heap / Priority Queue",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "ipo",
    "existing": true
  },
  {
    "slug": "island-perimeter",
    "name": "Island Perimeter",
    "topic": "Graphs",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "island-perimeter",
    "existing": false
  },
  {
    "slug": "verifying-an-alien-dictionary",
    "name": "Verifying An Alien Dictionary",
    "topic": "Graphs",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "verifying-an-alien-dictionary",
    "existing": false
  },
  {
    "slug": "find-the-town-judge",
    "name": "Find the Town Judge",
    "topic": "Graphs",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "find-the-town-judge",
    "existing": false
  },
  {
    "slug": "count-number-of-islands",
    "name": "Number of Islands",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "number-of-islands",
    "existing": true
  },
  {
    "slug": "max-area-of-island",
    "name": "Max Area of Island",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "max-area-of-island",
    "existing": true
  },
  {
    "slug": "clone-graph",
    "name": "Clone Graph",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "clone-graph",
    "existing": true
  },
  {
    "slug": "islands-and-treasure",
    "name": "Walls And Gates",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "islands-and-treasure",
    "existing": false
  },
  {
    "slug": "rotting-fruit",
    "name": "Rotting Oranges",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "rotting-oranges",
    "existing": true
  },
  {
    "slug": "pacific-atlantic-water-flow",
    "name": "Pacific Atlantic Water Flow",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "pacific-atlantic-water-flow",
    "existing": true
  },
  {
    "slug": "surrounded-regions",
    "name": "Surrounded Regions",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "surrounded-regions",
    "existing": true
  },
  {
    "slug": "open-the-lock",
    "name": "Open The Lock",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "open-the-lock",
    "existing": true
  },
  {
    "slug": "course-schedule",
    "name": "Course Schedule",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "course-schedule",
    "existing": true
  },
  {
    "slug": "course-schedule-ii",
    "name": "Course Schedule II",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "course-schedule-ii",
    "existing": true
  },
  {
    "slug": "valid-tree",
    "name": "Graph Valid Tree",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "graph-valid-tree",
    "existing": true
  },
  {
    "slug": "course-schedule-iv",
    "name": "Course Schedule IV",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "course-schedule-iv",
    "existing": false
  },
  {
    "slug": "count-connected-components",
    "name": "Number of Connected Components In An Undirected Graph",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "number-of-connected-components",
    "existing": true
  },
  {
    "slug": "redundant-connection",
    "name": "Redundant Connection",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "redundant-connection",
    "existing": true
  },
  {
    "slug": "accounts-merge",
    "name": "Accounts Merge",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "accounts-merge",
    "existing": true
  },
  {
    "slug": "evaluate-division",
    "name": "Evaluate Division",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "evaluate-division",
    "existing": true
  },
  {
    "slug": "minimum-height-trees",
    "name": "Minimum Height Trees",
    "topic": "Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "minimum-height-trees",
    "existing": false
  },
  {
    "slug": "word-ladder",
    "name": "Word Ladder",
    "topic": "Graphs",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "word-ladder",
    "existing": true
  },
  {
    "slug": "path-with-minimum-effort",
    "name": "Path with Minimum Effort",
    "topic": "Advanced Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "path-with-minimum-effort",
    "existing": true
  },
  {
    "slug": "network-delay-time",
    "name": "Network Delay Time",
    "topic": "Advanced Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "network-delay-time",
    "existing": true
  },
  {
    "slug": "reconstruct-flight-path",
    "name": "Reconstruct Itinerary",
    "topic": "Advanced Graphs",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "reconstruct-itinerary",
    "existing": true
  },
  {
    "slug": "min-cost-to-connect-points",
    "name": "Min Cost to Connect All Points",
    "topic": "Advanced Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "min-cost-to-connect-all-points",
    "existing": true
  },
  {
    "slug": "swim-in-rising-water",
    "name": "Swim In Rising Water",
    "topic": "Advanced Graphs",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "swim-in-rising-water",
    "existing": true
  },
  {
    "slug": "foreign-dictionary",
    "name": "Alien Dictionary",
    "topic": "Advanced Graphs",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "alien-dictionary",
    "existing": true
  },
  {
    "slug": "cheapest-flight-path",
    "name": "Cheapest Flights Within K Stops",
    "topic": "Advanced Graphs",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "cheapest-flights-within-k-stops",
    "existing": true
  },
  {
    "slug": "find-critical-and-pseudo-critical-edges-in-minimum-spanning-tree",
    "name": "Find Critical and Pseudo Critical Edges in Minimum Spanning Tree",
    "topic": "Advanced Graphs",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "find-critical-and-pseudo-critical-edges-in-minimum-spanning-tree",
    "existing": false
  },
  {
    "slug": "build-a-matrix-with-conditions",
    "name": "Build a Matrix With Conditions",
    "topic": "Advanced Graphs",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "build-a-matrix-with-conditions",
    "existing": false
  },
  {
    "slug": "greatest-common-divisor-traversal",
    "name": "Greatest Common Divisor Traversal",
    "topic": "Advanced Graphs",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "greatest-common-divisor-traversal",
    "existing": false
  },
  {
    "slug": "climbing-stairs",
    "name": "Climbing Stairs",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "climbing-stairs",
    "existing": true
  },
  {
    "slug": "min-cost-climbing-stairs",
    "name": "Min Cost Climbing Stairs",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "min-cost-climbing-stairs",
    "existing": true
  },
  {
    "slug": "n-th-tribonacci-number",
    "name": "N-th Tribonacci Number",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "tribonacci-number",
    "existing": true
  },
  {
    "slug": "house-robber",
    "name": "House Robber",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "house-robber",
    "existing": true
  },
  {
    "slug": "house-robber-ii",
    "name": "House Robber II",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "house-robber-ii",
    "existing": true
  },
  {
    "slug": "longest-palindromic-substring",
    "name": "Longest Palindromic Substring",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "longest-palindromic-substring",
    "existing": true
  },
  {
    "slug": "palindromic-substrings",
    "name": "Palindromic Substrings",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "palindromic-substrings",
    "existing": true
  },
  {
    "slug": "decode-ways",
    "name": "Decode Ways",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "decode-ways",
    "existing": true
  },
  {
    "slug": "coin-change",
    "name": "Coin Change",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "coin-change",
    "existing": true
  },
  {
    "slug": "maximum-product-subarray",
    "name": "Maximum Product Subarray",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "maximum-product-subarray",
    "existing": true
  },
  {
    "slug": "word-break",
    "name": "Word Break",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "word-break",
    "existing": true
  },
  {
    "slug": "longest-increasing-subsequence",
    "name": "Longest Increasing Subsequence",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "longest-increasing-subsequence",
    "existing": true
  },
  {
    "slug": "partition-equal-subset-sum",
    "name": "Partition Equal Subset Sum",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "partition-equal-subset-sum",
    "existing": true
  },
  {
    "slug": "combination-sum-iv",
    "name": "Combination Sum IV",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "combination-sum-iv",
    "existing": true
  },
  {
    "slug": "perfect-squares",
    "name": "Perfect Squares",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "perfect-squares",
    "existing": true
  },
  {
    "slug": "integer-break",
    "name": "Integer Break",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "integer-break",
    "existing": false
  },
  {
    "slug": "stone-game-iii",
    "name": "Stone Game III",
    "topic": "1-D Dynamic Programming",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "stone-game-iii",
    "existing": false
  },
  {
    "slug": "count-paths",
    "name": "Unique Paths",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "unique-paths",
    "existing": true
  },
  {
    "slug": "unique-paths-ii",
    "name": "Unique Paths II",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "unique-paths-ii",
    "existing": true
  },
  {
    "slug": "minimum-path-sum",
    "name": "Minimum Path Sum",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "minimum-path-sum",
    "existing": true
  },
  {
    "slug": "longest-common-subsequence",
    "name": "Longest Common Subsequence",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "longest-common-subsequence",
    "existing": true
  },
  {
    "slug": "last-stone-weight-ii",
    "name": "Last Stone Weight II",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "last-stone-weight-ii",
    "existing": false
  },
  {
    "slug": "buy-and-sell-crypto-with-cooldown",
    "name": "Best Time to Buy And Sell Stock With Cooldown",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "buy-and-sell-crypto-with-cooldown",
    "existing": false
  },
  {
    "slug": "coin-change-ii",
    "name": "Coin Change II",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "coin-change-ii",
    "existing": true
  },
  {
    "slug": "target-sum",
    "name": "Target Sum",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "target-sum",
    "existing": true
  },
  {
    "slug": "interleaving-string",
    "name": "Interleaving String",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "interleaving-string",
    "existing": true
  },
  {
    "slug": "stone-game",
    "name": "Stone Game",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "stone-game",
    "existing": false
  },
  {
    "slug": "stone-game-ii",
    "name": "Stone Game II",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "stone-game-ii",
    "existing": false
  },
  {
    "slug": "longest-increasing-path-in-matrix",
    "name": "Longest Increasing Path In a Matrix",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "longest-increasing-path-in-matrix",
    "existing": false
  },
  {
    "slug": "count-subsequences",
    "name": "Distinct Subsequences",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "distinct-subsequences",
    "existing": true
  },
  {
    "slug": "edit-distance",
    "name": "Edit Distance",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "edit-distance",
    "existing": true
  },
  {
    "slug": "burst-balloons",
    "name": "Burst Balloons",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "burst-balloons",
    "existing": true
  },
  {
    "slug": "regular-expression-matching",
    "name": "Regular Expression Matching",
    "topic": "2-D Dynamic Programming",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "regular-expression-matching",
    "existing": true
  },
  {
    "slug": "lemonade-change",
    "name": "Lemonade Change",
    "topic": "Greedy",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "lemonade-change",
    "existing": true
  },
  {
    "slug": "maximum-subarray",
    "name": "Maximum Subarray",
    "topic": "Greedy",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "maximum-subarray",
    "existing": true
  },
  {
    "slug": "maximum-sum-circular-subarray",
    "name": "Maximum Sum Circular Subarray",
    "topic": "Greedy",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "maximum-sum-circular-subarray",
    "existing": false
  },
  {
    "slug": "longest-turbulent-subarray",
    "name": "Longest Turbulent Subarray",
    "topic": "Greedy",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "longest-turbulent-subarray",
    "existing": false
  },
  {
    "slug": "jump-game",
    "name": "Jump Game",
    "topic": "Greedy",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "jump-game",
    "existing": true
  },
  {
    "slug": "jump-game-ii",
    "name": "Jump Game II",
    "topic": "Greedy",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "jump-game-ii",
    "existing": true
  },
  {
    "slug": "jump-game-vii",
    "name": "Jump Game VII",
    "topic": "Greedy",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "jump-game-vii",
    "existing": false
  },
  {
    "slug": "gas-station",
    "name": "Gas Station",
    "topic": "Greedy",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "gas-station",
    "existing": true
  },
  {
    "slug": "hand-of-straights",
    "name": "Hand of Straights",
    "topic": "Greedy",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "hand-of-straights",
    "existing": true
  },
  {
    "slug": "dota2-senate",
    "name": "Dota2 Senate",
    "topic": "Greedy",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "dota2-senate",
    "existing": false
  },
  {
    "slug": "merge-triplets-to-form-target",
    "name": "Merge Triplets to Form Target Triplet",
    "topic": "Greedy",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "merge-triplets",
    "existing": true
  },
  {
    "slug": "partition-labels",
    "name": "Partition Labels",
    "topic": "Greedy",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "partition-labels",
    "existing": true
  },
  {
    "slug": "valid-parenthesis-string",
    "name": "Valid Parenthesis String",
    "topic": "Greedy",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "valid-parenthesis-string",
    "existing": false
  },
  {
    "slug": "candy",
    "name": "Candy",
    "topic": "Greedy",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "candy",
    "existing": true
  },
  {
    "slug": "insert-new-interval",
    "name": "Insert Interval",
    "topic": "Intervals",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "insert-interval",
    "existing": true
  },
  {
    "slug": "merge-intervals",
    "name": "Merge Intervals",
    "topic": "Intervals",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "merge-intervals",
    "existing": true
  },
  {
    "slug": "non-overlapping-intervals",
    "name": "Non Overlapping Intervals",
    "topic": "Intervals",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "non-overlapping-intervals",
    "existing": true
  },
  {
    "slug": "meeting-schedule",
    "name": "Meeting Rooms",
    "topic": "Intervals",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "meeting-rooms",
    "existing": true
  },
  {
    "slug": "meeting-schedule-ii",
    "name": "Meeting Rooms II",
    "topic": "Intervals",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "meeting-rooms-ii",
    "existing": true
  },
  {
    "slug": "meeting-rooms-iii",
    "name": "Meeting Rooms III",
    "topic": "Intervals",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "meeting-rooms-iii",
    "existing": false
  },
  {
    "slug": "minimum-interval-including-query",
    "name": "Minimum Interval to Include Each Query",
    "topic": "Intervals",
    "difficulty": "Hard",
    "level": "Advanced",
    "target": "minimum-interval-including-query",
    "existing": false
  },
  {
    "slug": "single-number",
    "name": "Single Number",
    "topic": "Bit Manipulation",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "single-number",
    "existing": true
  },
  {
    "slug": "number-of-one-bits",
    "name": "Number of 1 Bits",
    "topic": "Bit Manipulation",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "number-of-1-bits",
    "existing": true
  },
  {
    "slug": "counting-bits",
    "name": "Counting Bits",
    "topic": "Bit Manipulation",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "counting-bits",
    "existing": true
  },
  {
    "slug": "add-binary",
    "name": "Add Binary",
    "topic": "Bit Manipulation",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "add-binary",
    "existing": false
  },
  {
    "slug": "reverse-bits",
    "name": "Reverse Bits",
    "topic": "Bit Manipulation",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "reverse-bits",
    "existing": true
  },
  {
    "slug": "missing-number",
    "name": "Missing Number",
    "topic": "Bit Manipulation",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "missing-number",
    "existing": true
  },
  {
    "slug": "sum-of-two-integers",
    "name": "Sum of Two Integers",
    "topic": "Bit Manipulation",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "sum-of-two-integers",
    "existing": true
  },
  {
    "slug": "reverse-integer",
    "name": "Reverse Integer",
    "topic": "Bit Manipulation",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "reverse-integer",
    "existing": false
  },
  {
    "slug": "bitwise-and-of-numbers-range",
    "name": "Bitwise AND of Numbers Range",
    "topic": "Bit Manipulation",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "bitwise-and-of-numbers-range",
    "existing": true
  },
  {
    "slug": "minimum-array-end",
    "name": "Minimum Array End",
    "topic": "Bit Manipulation",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "minimum-array-end",
    "existing": false
  },
  {
    "slug": "excel-sheet-column-title",
    "name": "Excel Sheet Column Title",
    "topic": "Math & Geometry",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "excel-sheet-column-title",
    "existing": false
  },
  {
    "slug": "greatest-common-divisor-of-strings",
    "name": "Greatest Common Divisor of Strings",
    "topic": "Math & Geometry",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "gcd-of-strings",
    "existing": true
  },
  {
    "slug": "insert-greatest-common-divisors-in-linked-list",
    "name": "Insert Greatest Common Divisors in Linked List",
    "topic": "Math & Geometry",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "insert-greatest-common-divisors-in-linked-list",
    "existing": false
  },
  {
    "slug": "transpose-matrix",
    "name": "Transpose Matrix",
    "topic": "Math & Geometry",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "transpose-matrix",
    "existing": false
  },
  {
    "slug": "rotate-matrix",
    "name": "Rotate Image",
    "topic": "Math & Geometry",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "rotate-image",
    "existing": true
  },
  {
    "slug": "spiral-matrix",
    "name": "Spiral Matrix",
    "topic": "Math & Geometry",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "spiral-matrix",
    "existing": true
  },
  {
    "slug": "set-zeroes-in-matrix",
    "name": "Set Matrix Zeroes",
    "topic": "Math & Geometry",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "set-matrix-zeroes",
    "existing": true
  },
  {
    "slug": "non-cyclical-number",
    "name": "Happy Number",
    "topic": "Math & Geometry",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "happy-number",
    "existing": true
  },
  {
    "slug": "plus-one",
    "name": "Plus One",
    "topic": "Math & Geometry",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "plus-one",
    "existing": false
  },
  {
    "slug": "roman-to-integer",
    "name": "Roman to Integer",
    "topic": "Math & Geometry",
    "difficulty": "Easy",
    "level": "Beginner",
    "target": "roman-to-integer",
    "existing": true
  },
  {
    "slug": "pow-x-n",
    "name": "Pow(x, n)",
    "topic": "Math & Geometry",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "pow-x-n",
    "existing": true
  },
  {
    "slug": "multiply-strings",
    "name": "Multiply Strings",
    "topic": "Math & Geometry",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "multiply-strings",
    "existing": true
  },
  {
    "slug": "count-squares",
    "name": "Detect Squares",
    "topic": "Math & Geometry",
    "difficulty": "Medium",
    "level": "Intermediate",
    "target": "count-squares",
    "existing": false
  }
];
  const byTarget = Object.create(null);
  for (const p of problems) byTarget[p.target] = p;
  window.NEETCODE250 = { total: problems.length, problems, byTarget };
})();
