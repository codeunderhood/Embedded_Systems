(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  function toTworows(parsed) {
    if (!Array.isArray(parsed)) return [[], []];
    if (parsed.length === 2 && Array.isArray(parsed[0]) && Array.isArray(parsed[1])) return [parsed[0].slice(), parsed[1].slice()];
    if (Array.isArray(parsed[0]) && parsed[0].length === 2) {
      const a = [], b = [];
      for (let i = 0; i < parsed.length; i++) { a.push(parsed[i][0]); b.push(parsed[i][1]); }
      return [a, b];
    }
    return [parsed.slice(), []];
  }

  function toPairs(parsed) {
    if (!parsed || !parsed.length) return [];
    if (parsed.length === 2 && Array.isArray(parsed[0]) && Array.isArray(parsed[1])) {
      const a = parsed[0], b = parsed[1];
      const n = Math.min(a.length, b.length);
      const out = [];
      for (let i = 0; i < n; i++) out.push([a[i], b[i]]);
      return out;
    }
    if (Array.isArray(parsed[0]) && parsed[0].length === 2) return parsed.map(p => [p[0], p[1]]);
    return [];
  }

  // assign-cookies
  V.register({
    id: "assign-cookies",
    title: "Assign Cookies",
    category: "Greedy",
    difficulty: "Beginner",
    description: "Feed each child the smallest cookie that satisfies them by sorting both lists.",
    input: { label: "children | cookies", default: "1, 2, 3 | 1, 1", parse: "tworows" },
    approaches: [
      {
        name: "Greedy with Two Pointers",
        complexity: "O(m log m + n log n) time, O(1) extra space",
        idea: [
          "Sort children ascending and cookies ascending.",
          "Assign smallest feasible cookie to smallest child; if not enough, try next cookie.",
          "Count satisfied children.",
        ],
        problem: [
          "Wasting a large cookie on a small child reduces matches; smallest-first is the safe greedy choice.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

int cmp(const void *a,const void *b){ return *(int*)a-*(int*)b; }

int findContentChildren(int *g,int n,int *s,int m){
    qsort(g,n,sizeof(int),cmp);
    qsort(s,m,sizeof(int),cmp);
    int i=0,j=0,ans=0;
    while(i<n && j<m){
        if(s[j]>=g[i]){ ans++; i++; j++; }
        else { j++; }
    }
    return ans;
}

int main(void){
    int g[]={1,2,3}, s[]={1,1};
    printf("%d\\n", findContentChildren(g,3,s,2));
    return 0;
}`,
          cpp: `#include <vector>
#include <algorithm>
#include <iostream>
using namespace std;

int findContentChildren(vector<int>& g, vector<int>& s){
    sort(g.begin(),g.end());
    sort(s.begin(),s.end());
    size_t i=0,j=0; int ans=0;
    while(i<g.size() && j<s.size()){
        if(s[j]>=g[i]){ ++ans; ++i; ++j; }
        else { ++j; }
    }
    return ans;
}

int main(){
    vector<int> g={1,2,3}, s={1,1};
    cout<<findContentChildren(g,s)<<endl;
    return 0;
}`,
        },
        steps(parsed) {
          const [G,S] = toTworows(parsed);
          const g = G.slice().sort((a,b)=>a-b);
          const sArr = S.slice().sort((a,b)=>a-b);
          const n=g.length,m=sArr.length;
          const steps=[];
          steps.push({
            title:"Sort both lists ascending",
            tracks:[
              track("children",g,fill(n,"idle")),
              track("cookies",sArr,fill(m,"idle")),
            ],
            counters:[count("children fed",0,n), count("cookies used",0,m)],
            legend:["read","good","bad","done","idle"],
            happened:"Children and cookies sorted ascending.",
            why:"Smallest child first; try smallest feasible cookie to save larger ones.",
            codeLine:6,
          });
          steps.push({
            title:"Rule: smallest child gets the smallest cookie that fits",
            tracks:[
              track("children",g,fill(n,"idle")),
              track("cookies",sArr,fill(m,"idle")),
            ],
            counters:[count("children fed",0,n), count("cookies used",0,m)],
            happened:"Walk both rows together: compare the least greedy waiting child with the smallest unused cookie.",
            why:"If this cookie is too small for this child it is too small for every child (both rows are sorted), so skipping it loses nothing; if it fits, spending it now keeps bigger cookies for greedier children.",
            codeLine:9,
          });
          let i=0,j=0,fed=0;
          while(i<n && j<m){
            steps.push({
              title:`Compare child ${g[i]} vs cookie ${sArr[j]}`,
              tracks:[
                track("children",g,paint(fill(n,"done"),{[i]:"read"})),
                track("cookies",sArr,paint(fill(m,"done"),{[j]:"read"})),
              ],
              counters:[count("children fed",fed,n), count("cookies used",j,m)],
              happened:`Test if cookie ${sArr[j]} >= child ${g[i]}.`,
              why:"This pair tells us whether to assign now or to get a larger cookie.",
              codeLine:10,
            });
            if(sArr[j]>=g[i]){
              fed++;
              const ci=i,cj=j; i++; j++;
              steps.push({
                title:`Assign cookie ${sArr[cj]} to child ${g[ci]} → fed ${fed}`,
                tracks:[
                  track("children",g,g.map((_,k)=>k<ci?"good":k===ci?"good":"idle")),
                  track("cookies",sArr,sArr.map((_,k)=>k<cj?"good":k===cj?"good":"idle")),
                ],
                counters:[count("children fed",fed,n), count("cookies used",j,m)],
                happened:"Feasible match found; move both pointers.",
                why:"Assign smallest feasible cookie now so larger cookies stay available.",
                codeLine:10,
              });
            } else {
              const cj=j; j++;
              steps.push({
                title:`Cookie ${sArr[cj]} too small → try next cookie`,
                tracks:[
                  track("children",g,paint(fill(n,"done"),{[i]:"read"})),
                  track("cookies",sArr,sArr.map((_,k)=>k<cj?"done":k===cj?"bad":"idle")),
                ],
                counters:[count("children fed",fed,n), count("cookies used",j,m)],
                happened:"Cookie insufficient; discard it and advance cookie pointer.",
                why:"Child still needs >= requirement; keep child pointer fixed.",
                codeLine:11,
              });
            }
          }
          steps.push({
            title:`Answer: ${fed}`,
            tracks:[
              track("children",g,g.map((_,k)=>k<i?"good": k<fed?"good":"dim")),
              track("cookies",sArr,sArr.map((_,k)=>k<j?"good":"dim")),
            ],
            counters:[count("answer",fed,n)],
            happened:fed?`Fed ${fed} child${fed===1?"":"ren"}.`:"No child satisfied.",
            why:"Greedy smallest-first gives maximum number of satisfied children.",
            codeLine:13,
          });
          return steps;
        },
      },
    ],
  });

  // lemonade-change
  V.register({
    id: "lemonade-change",
    title: "Lemonade Change",
    category: "Greedy",
    difficulty: "Beginner",
    description: "Give change greedily with 5/10 bills and see if every customer can be served.",
    input: { label: "Bills (5, 10, 20)", default: "5, 5, 5, 10, 20", parse: "ints" },
    approaches: [
      {
        name: "Always keep 5s and use them first",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Track count of 5 and 10 bills in the wallet.",
          "For a 5: just keep it. For a 10: give one 5 back (if any). For a 20: prefer 10 + 5 change, else three 5s.",
          "If no change possible, answer is false.",
        ],
        problem: [
          "Running out of 5s at a 20 bill fails the process; keeping 5s is the greedy invariant.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

bool lemonadeChange(int *bills, int n){
    int fives=0, tens=0;
    for(int i=0;i<n;i++){
        if(bills[i]==5) fives++;
        else if(bills[i]==10){ if(fives>0){ fives--; tens++; } else return false; }
        else if(bills[i]==20){
            if(tens>0 && fives>0){ tens--; fives--; }
            else if(fives>=3) fives-=3;
            else return false;
        }
        else return false;   /* not a 5, 10 or 20 bill */
    }
    return true;
}

int main(void){
    int b[]={5,5,5,10,20};
    printf("%d\\n", lemonadeChange(b,5));
    return 0;
}`,
          cpp: `#include <vector>
#include <iostream>
using namespace std;

bool lemonadeChange(vector<int>& bills){
    int fives=0, tens=0;
    for(int x: bills){
        if(x==5) fives++;
        else if(x==10){ if(fives>0){ fives--; tens++; } else return false; }
        else if(x==20){
            if(tens>0 && fives>0){ tens--; fives--; }
            else if(fives>=3) fives-=3;
            else return false;
        }
        else return false;   /* not a 5, 10 or 20 bill */
    }
    return true;
}

int main(){
    vector<int> b={5,5,5,10,20};
    cout<<lemonadeChange(b)<<endl;
    return 0;
}`,
        },
        steps(nums) {
          const bills = nums;
          const n = bills.length;
          let fives=0, tens=0;
          const steps=[];
          steps.push({
            title:"Initialize wallet: 0 fives, 0 tens",
            tracks:[
              track("bills in order",bills,fill(n,"idle")),
              { label:"wallet", cells:[{v:0,state:"result",tag:"5s"},{v:0,state:"result",tag:"10s"}] },
            ],
            counters:[count("customer",0,n), count("5s",0), count("10s",0)],
            legend:["read","good","bad","result","idle"],
            happened:"Empty wallet; process each bill in order.",
            why:"Greedy: keep 5s available; use them whenever possible for future 20s.",
            codeLine:4,
          });
          steps.push({
            title:"Rule: give back the fewest bills that work",
            tracks:[
              track("bills in order",bills,fill(n,"idle")),
              { label:"wallet", cells:[{v:0,state:"result",tag:"5s"},{v:0,state:"result",tag:"10s"}] },
            ],
            counters:[count("customer",0,n), count("5s",0), count("10s",0)],
            legend:["read","good","bad","result","idle"],
            happened:"Policy: a 5 needs no change; a 10 gets one 5 back; a 20 gets a 10 plus a 5 back, or three 5s if we have no 10.",
            why:"Paying with a 10 or a 20 is where 5s get spent, and only 5s can make change for a 10 or a 20 — so hand back the biggest bill we can and keep every 5 we can.",
            codeLine:3,
          });
          let ok = true, last = -1;
          for (let i = 0; i < n; i++) {
            const b = bills[i];
            const baseStates = paint(fill(n, "done"), { [i]: "read" });
            const wallet = () => ({ label: "wallet", cells: [{ v: fives, state: "result", tag: "5s" }, { v: tens, state: "result", tag: "10s" }] });
            let note = "";
            if (b === 5) {
              fives++;
              note = "5 received; no change needed.";
            } else if (b === 10) {
              if (fives > 0) { fives--; tens++; note = "10 received; give back one 5."; }
              else { ok = false; note = "10 received but no 5 to give back!"; }
            } else if (b === 20) {
              if (tens > 0 && fives > 0) { tens--; fives--; note = "20 received; give back 10 + 5."; }
              else if (fives >= 3) { fives -= 3; note = "20 received; give back three 5s."; }
              else { ok = false; note = "20 received but not enough small bills for change!"; }
            } else {
              ok = false;
              note = b + " is not a 5, 10 or 20 bill — cannot serve this customer.";
            }
            steps.push({
              title: "Customer " + (i + 1) + " pays " + b + " → " + note,
              tracks: [track("bills in order", bills, baseStates), wallet()],
              counters: [count("customer", i + 1, n), count("5s", fives), count("10s", tens)],
              happened: note,
              why: "Give the smallest bill possible so we keep many 5s for later change.",
              codeLine: 6,
            });
            if (!ok) { last = i; break; }
            last = i;
          }
          steps.push({
            title: "Answer: " + (ok ? "true" : "false"),
            tracks: [
              track("bills in order", bills, bills.map((_, k) => (ok || k <= last ? "good" : "idle"))),
              { label: "wallet", cells: [{ v: fives, state: "result", tag: "5s" }, { v: tens, state: "result", tag: "10s" }] },
            ],
            counters: [count("answer", ok ? 1 : 0)],
            happened: ok ? "All customers got correct change." : "Failed: not enough small bills for change.",
            why: "5 is the only bill able to make change for 10 and 20; greedy rule guarantees correctness.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  // jump-game
  V.register({
    id: "jump-game",
    title: "Jump Game",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Check if we can reach the last index, greedy on furthest reachable index.",
    input: { label: "Max jump lengths", default: "2, 3, 1, 1, 4", parse: "ints" },
    approaches: [
      {
        name: "Greedy furthest reach",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Track the furthest index we can reach so far while scanning left to right.",
          "If the current index is beyond what we can reach, we are stuck (return false).",
          "If the furthest index reaches or passes the last index, we win.",
        ],
        problem: [
          "Requires that we never jump backwards; the greedy invariant is that everything before current furthest is reachable.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

bool canJump(int *a, int n){
    int furthest=0;
    for(int i=0;i<n;i++){
        if(i>furthest) return false;      /* stuck: this index is out of reach */
        if(i+a[i]>furthest) furthest=i+a[i];
    }
    return furthest>=n-1;                 /* is the last index covered? */
}

int main(void){
    int a[]={2,3,1,1,4};
    printf("%d\\n", canJump(a,5));
    return 0;
}`,
          cpp: `#include <vector>
#include <iostream>
using namespace std;

bool canJump(vector<int>& a){
    int n=(int)a.size(), furthest=0;
    for(int i=0;i<n;i++){
        if(i>furthest) return false;
        furthest=max(furthest, i+a[i]);
    }
    return furthest>=n-1;
}

int main(){
    vector<int> a={2,3,1,1,4};
    cout<<canJump(a)<<endl;
    return 0;
}`,
        },
        steps(nums) {
          const a = nums;
          const n = a.length;
          let furthest = 0;
          const steps=[];
          steps.push({
            title:"Setup: stand on index 0",
            tracks:[track("jump lengths",a,fill(n,"idle"))],
            counters:[count("index",0,n), count("furthest reachable",0), count("last index",n-1), count("answer",0)],
            legend:["read","good","bad","done","idle"],
            happened:"We start on index 0. The only thing we remember is the furthest index we can get to.",
            why:"Greedy keeps one number instead of a whole path; that number is enough to decide reachability.",
            codeLine:4,
          });
          steps.push({
            title:"Rule: every index up to the furthest reach is reachable",
            tracks:[track("jump lengths",a,fill(n,"idle"))],
            counters:[count("index",0,n), count("furthest reachable",0), count("last index",n-1), count("answer",0)],
            legend:["read","good","bad","done","idle"],
            happened:"From index i a jump can land anywhere from i to i + a[i]; while scanning we keep the largest landing seen.",
            why:"We never move backwards, so an index inside the running reach can never fall out of it — the reach only grows. That is why this greedy choice is safe.",
            codeLine:5,
          });
          let stuck = false;
          for (let i = 0; i < n; i++) {
            if (i > furthest) {
              stuck = true;
              steps.push({
                title: `Stuck at index ${i} — out of reach`,
                tracks: [track("jump lengths", a, a.map((_, k) => k < i ? "done" : k === i ? "bad" : "idle"))],
                counters: [count("index", i, n), count("furthest reachable", furthest), count("last index", n-1), count("answer", 0)],
                happened: `Index ${i} is beyond our furthest reach ${furthest}, so we could never stand on it.`,
                why: "The running reach stopped growing before this index; every later index is even further away, so the end is impossible.",
                codeLine: 6,
              });
              break;
            }
            const newReach = Math.max(furthest, i + a[i]);
            steps.push({
              title: `Index ${i}: jump ${a[i]} → furthest ${newReach}`,
              tracks: [track("jump lengths", a, a.map((_, k) => k < i ? "done" : k === i ? "read" : k <= newReach ? "good" : "idle"))],
              counters: [count("index", i, n), count("furthest reachable", newReach), count("last index", n-1), count("answer", newReach >= n - 1 ? 1 : 0)],
              happened: `From index ${i} we can land as far as ${i + a[i]}; the furthest reach becomes ${newReach}.`,
              why: "Using the best landing of every index we stand on can only widen the reach; we keep sweeping so the loop also catches a gap.",
              codeLine: 7,
            });
            furthest = newReach;
          }
          steps.push({
            title: stuck ? "Answer: false — last index unreachable" : "Answer: true — last index reachable",
            tracks: [track("jump lengths", a, a.map((_, k) => k <= furthest ? (stuck ? "done" : "good") : "bad"))],
            counters: [count("answer", stuck ? 0 : 1), count("furthest reachable", furthest), count("last index", n-1)],
            happened: stuck ? `The running reach stalled at ${furthest}, short of the last index ${n-1}.` : `The reach covered index ${n-1}, the last index.`,
            why: stuck ? "We proved the furthest position the jumps can ever give us; it stops before the end, so no path exists." : "If the reach covers the last index then a sequence of jumps must exist that gets there, and the running maximum never misses one.",
            codeLine: 9,
          });
          return steps;
        },
      },
      {
        name: "Brute force: mark every reachable index",
        complexity: "O(n^2) time, O(n) space",
        idea: [
          "Keep a table reach[i] that says whether index i can be reached.",
          "Index 0 is reachable. For each later index i, test every earlier index j: can we jump from j to i?",
          "The answer is reach[last].",
        ],
        problem: [
          "Slower (n^2) but easy to trust: it tries every possible predecessor instead of relying on one running maximum.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

bool canJumpSlow(int *a, int n){
    bool reach[100]={0};
    reach[0]=true;
    for(int i=1;i<n;i++){
        for(int j=0;j<i;j++){
            if(reach[j] && j+a[j]>=i){ reach[i]=true; break; }
        }
    }
    return reach[n-1];
}

int main(void){
    int a[]={2,3,1,1,4};
    printf("%d\\n", canJumpSlow(a,5));
    return 0;
}`,
          cpp: `#include <vector>
#include <iostream>
using namespace std;

bool canJumpSlow(vector<int>& a){
    int n=(int)a.size();
    vector<bool> reach(n,false);
    if(n>0) reach[0]=true;
    for(int i=1;i<n;i++)
        for(int j=0;j<i;j++)
            if(reach[j] && j+a[j]>=i){ reach[i]=true; break; }
    return n>0 && reach[n-1];
}

int main(){
    vector<int> a={2,3,1,1,4};
    cout<<canJumpSlow(a)<<endl;
    return 0;
}`,
        },
        steps(nums) {
          const a = nums;
          const n = a.length;
          const reach = Array(n).fill(false);
          if (n > 0) reach[0] = true;
          const steps=[];
          steps.push({
            title:"Setup: mark index 0 reachable",
            tracks:[
              track("jump lengths",a,fill(n,"idle")),
              track("reachable?",reach.map(v=>v?"yes":"no"),reach.map(v=>v?"good":"dim")),
            ],
            counters:[count("index",0,n), count("reachable indexes",n>0?1:0,n), count("answer",0)],
            legend:["read","good","bad","done","dim","idle"],
            happened:"We can always stand on index 0, so reach[0] = true.",
            why:"Brute force grows from the one certain fact and checks every possible jump, instead of trusting a shortcut.",
            codeLine:5,
          });
          steps.push({
            title:"Rule: index i is reachable if an earlier reachable index can jump to it",
            tracks:[
              track("jump lengths",a,fill(n,"idle")),
              track("reachable?",reach.map(v=>v?"yes":"no"),reach.map(v=>v?"good":"dim")),
            ],
            counters:[count("index",0,n), count("reachable indexes",n>0?1:0,n), count("answer",0)],
            legend:["read","good","bad","done","dim","idle"],
            happened:"For each i we test every j < i: reach[j] and j + a[j] >= i.",
            why:"Checking all predecessors means no path can be missed, so the table is exact even though it is slow.",
            codeLine:7,
          });
          for (let i=1;i<n;i++){
            let via=-1;
            for (let j=0;j<i;j++){
              if (reach[j] && j+a[j]>=i){ via=j; break; }
            }
            if (via>=0) reach[i]=true;
            steps.push({
              title: `Index ${i}: ${via>=0?`reachable from index ${via}`:"no predecessor reaches it"}`,
              tracks:[
                track("jump lengths",a,a.map((_,k)=> k===i?"read":k< i?"done":"idle")),
                track("reachable?",reach.map((v,k)=> v?(k===i?"good":"done"):"dim")),
              ],
              counters:[count("index",i,n), count("reachable indexes",reach.filter(Boolean).length,n), count("answer",0)],
              happened: via>=0?`Index ${via} can jump to ${i}, so reach[${i}] = true.` : `No reachable earlier index can jump as far as ${i}, so reach[${i}] stays false.`,
              why: via>=0?"A concrete predecessor was found, so this index is provably reachable.":"Every possible predecessor was tested and none worked, so this index is provably unreachable.",
              codeLine:8,
            });
          }
          const ok = n>0 && reach[n-1];
          steps.push({
            title: ok ? "Answer: true — last index reachable" : "Answer: false — last index unreachable",
            tracks:[
              track("jump lengths",a,fill(n,"good")),
              track("reachable?",reach.map(v=>v?"yes":"no"),reach.map(v=>v?"good":"bad")),
            ],
            counters:[count("answer",ok?1:0), count("reachable indexes",reach.filter(Boolean).length,n)],
            happened: ok?`The finished table says index ${n-1} (the last index) is reachable.`:`The finished table says index ${n-1} is not reachable.`,
            why: ok?"The table was built from real jumps, so a true entry is a proof that the end can be reached.":"Every predecessor was tested, so a false entry for the last index proves the end cannot be reached.",
            codeLine:11,
          });
          return steps;
        },
      },
    ],
  });

  // jump-game-ii
  V.register({
    id: "jump-game-ii",
    title: "Jump Game II",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Minimum number of jumps to reach the last index, greedy on jump windows.",
    input: { label: "Max jump lengths", default: "2, 3, 1, 1, 4", parse: "ints" },
    approaches: [
      {
        name: "Greedy BFS-like window",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Maintain a window [current_end, next_end]: indexes reachable with the current number of jumps.",
          "For each index in the window, find the farthest index we could jump to (next_end).",
          "When we finish the window, increment jumps and move current_end to next_end.",
        ],
        problem: [
          "Requires we always have a valid jump (window not empty); if window fails, no path exists.",
        ],
        code: {
          c: `#include <stdio.h>

int jump(int *a, int n){
    if(n<=1) return 0;                        /* already at the last index */
    int jumps=0, current_end=0, next_end=0;
    for(int i=0;i<n-1;i++){
        if(i>current_end) return -1;          /* window ran dry: impossible */
        if(i+a[i]>next_end) next_end=i+a[i];
        if(i==current_end){
            jumps++;
            current_end=next_end;
            if(current_end>=n-1) break;
        }
    }
    return current_end>=n-1 ? jumps : -1;     /* -1 if the end was never reached */
}

int main(void){
    int a[]={2,3,1,1,4};
    printf("%d\\n", jump(a,5));
    return 0;
}`,
          cpp: `#include <vector>
#include <iostream>
using namespace std;

int jump(vector<int>& a){
    int n=(int)a.size();
    if(n<=1) return 0;
    int jumps=0, current_end=0, next_end=0;
    for(int i=0;i<n-1;i++){
        if(i>current_end) return -1;
        next_end=max(next_end, i+a[i]);
        if(i==current_end){
            jumps++;
            current_end=next_end;
            if(current_end>=n-1) break;
        }
    }
    return current_end>=n-1 ? jumps : -1;
}

int main(){
    vector<int> a={2,3,1,1,4};
    cout<<jump(a)<<endl;
    return 0;
}`,
        },
        steps(nums) {
          const a=nums;
          const n=a.length;
          if(n<=1){
            return [
              {
                title:"Setup: n <= 1, the start is already the last index",
                tracks:[track("jump lengths",a,fill(n,"idle"))],
                counters:[count("jumps",0), count("last index",n-1)],
                legend:["read","good","result","idle"],
                happened:"The array has at most one index, so index 0 is the last index.",
                why:"Base case: nothing to jump over, so no jump is needed.",
                codeLine:3,
              },
              {
                title:"Answer: 0 jumps",
                tracks:[track("jump lengths",a,fill(n,"good"))],
                counters:[count("answer",0), count("jumps",0)],
                legend:["read","good","result","idle"],
                happened:"Zero jumps needed.",
                why:"We already stand on the last index.",
                codeLine:3,
              },
            ];
          }
          let jumps=0, current_end=0, next_end=0;
          const steps=[];
          steps.push({
            title:"Setup: window [0,0] with 0 jumps",
            tracks:[track("jump lengths",a,fill(n,"idle"))],
            counters:[count("jumps",0), count("current window end",0), count("next window end",0), count("last index",n-1)],
            legend:["read","good","bad","result","done","idle"],
            happened:"With 0 jumps we can only stand on index 0, so the window is [0,0].",
            why:"Greedy counts jumps by growing a window of indexes reachable with the current number of jumps.",
            codeLine:4,
          });
          steps.push({
            title:"Rule: one more jump lets us reach anywhere inside the next window",
            tracks:[track("jump lengths",a,fill(n,"idle"))],
            counters:[count("jumps",0), count("current window end",0), count("next window end",0), count("last index",n-1)],
            legend:["read","good","bad","result","done","idle"],
            happened:"Scan every index in the current window and take the farthest landing; that becomes the next window end.",
            why:"Because every index in the window is reachable with the same jump count, the farthest of their landings is the best we can do with one extra jump — using less would only postpone the inevitable.",
            codeLine:5,
          });
          for(let i=0;i<n-1;i++){
            if(i>current_end){
              steps.push({
                title:`Stuck at index ${i} — window ran dry`,
                tracks:[track("jump lengths",a,a.map((_,k)=> k<=current_end?"done":k===i?"bad":"idle"))],
                counters:[count("jumps",jumps), count("current window end",current_end), count("next window end",next_end), count("last index",n-1)],
                happened:`Index ${i} is past the current window end ${current_end}, so no jump can land there.`,
                why:"The reachable window stopped before this index, so the last index can never be reached.",
                codeLine:6,
              });
              break;
            }
            next_end=Math.max(next_end,i+a[i]);
            steps.push({
              title:`Scan index ${i}: jump ${a[i]} → next window end ${next_end}`,
              tracks:[track("jump lengths",a,a.map((_,k)=> k< i?"done":k===i?"read":k<=next_end?"good":"idle"))],
              counters:[count("jumps",jumps), count("current window end",current_end), count("next window end",next_end), count("last index",n-1)],
              happened:`From index ${i} a jump reaches ${i+a[i]}; the farthest landing seen is ${next_end}.`,
              why:"We are only choosing how far one extra jump can carry us, so keeping the farthest landing is always at least as good as a shorter one.",
              codeLine:7,
            });
            if(i===current_end){
              jumps++;
              current_end=next_end;
              steps.push({
                title:`Close window → jumps=${jumps}, current window end=${current_end}`,
                tracks:[track("jump lengths",a,a.map((_,k)=> k<=current_end?"good":k===current_end+1?"read":"idle"))],
                counters:[count("jumps",jumps), count("current window end",current_end), count("next window end",next_end), count("last index",n-1)],
                happened:`We finished scanning the window, so we spend one jump and move the window end to ${current_end}.`,
                why:"Every index in the old window needed the same number of jumps, so the moment we step past it we must have used exactly one more jump.",
                codeLine:9,
              });
              if(current_end>=n-1){
                steps.push({
                  title:`Answer: ${jumps} jumps`,
                  tracks:[track("jump lengths",a,fill(n,"good"))],
                  counters:[count("answer",jumps), count("jumps",jumps), count("current window end",current_end)],
                  happened:`The window now covers index ${n-1}, the last index, after ${jumps} jumps.`,
                  why:"The window only closes when a jump is truly needed, so the first time it covers the last index is the minimum number of jumps.",
                  codeLine:14,
                });
                return steps;
              }
            }
          }
          const reached = current_end>=n-1;
          steps.push({
            title: reached ? `Answer: ${jumps} jumps` : "Answer: -1 — last index unreachable",
            tracks:[track("jump lengths",a,reached? fill(n,"good") : a.map((_,k)=> k<=current_end?"done":"dim"))],
            counters:[count("answer",reached?jumps:-1), count("jumps",jumps), count("current window end",current_end)],
            happened:reached? `Reached the last index in ${jumps} jumps.` : `The scan ended with the window at ${current_end}, short of the last index ${n-1}.`,
            why:reached? "All windows were expanded and the last one covers the end, so the count is minimal." : "Some index could not be reached at all (a jump length of 0 blocked the way), so no route exists and the honest answer is -1.",
            codeLine:14,
          });
          return steps;
        },
      },
    ],
  });

  // gas-station
  V.register({
    id: "gas-station",
    title: "Gas Station",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Find a starting gas station index to complete a circular tour, or detect impossibility.",
    input: { label: "gas | cost", default: "1, 2, 3, 4, 5 | 3, 4, 5, 1, 2", parse: "tworows" },
    approaches: [
      {
        name: "Greedy with tank and candidate start",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Compute total gas - total cost; if negative, impossible.",
          "Walk stations, tracking current tank. If tank drops below 0, reset start candidate to next station and tank to 0.",
          "After one pass, if total >= 0 the candidate start is valid.",
        ],
        problem: [
          "Requires that when tank fails at index i, no earlier start in the failed segment can succeed; greedy candidate logic guarantees it.",
        ],
        code: {
          c: `#include <stdio.h>

int canCompleteCircuit(int *gas,int *cost,int n){
    int total=0,tank=0,start=0;
    for(int i=0;i<n;i++){
        int diff=gas[i]-cost[i];
        total+=diff;
        tank+=diff;
        if(tank<0){ start=i+1; tank=0; }
    }
    return total>=0?start:-1;
}

int main(void){
    int g[]={1,2,3,4,5}, c[]={3,4,5,1,2};
    printf("%d\\n", canCompleteCircuit(g,c,5));
    return 0;
}`,
          cpp: `#include <vector>
#include <iostream>
using namespace std;

int canCompleteCircuit(vector<int>& gas, vector<int>& cost){
    int n=gas.size(), total=0, tank=0, start=0;
    for(int i=0;i<n;i++){
        int diff=gas[i]-cost[i];
        total+=diff;
        tank+=diff;
        if(tank<0){ start=i+1; tank=0; }
    }
    return total>=0?start:-1;
}

int main(){
    vector<int> g={1,2,3,4,5}, c={3,4,5,1,2};
    cout<<canCompleteCircuit(g,c)<<endl;
    return 0;
}`,
        },
        steps(parsed) {
          const [G,C] = toTworows(parsed);
          const n = Math.min(G.length, C.length);
          const gas=G.slice(0,n), cost=C.slice(0,n);
          let total=0, tank=0, start=0;
          const steps=[];
          const diffs=[]; for(let i=0;i<n;i++) diffs.push(gas[i]-cost[i]);
          total = diffs.reduce((a,b)=>a+b,0);
          steps.push({
            title:"Setup: compute total gas - total cost",
            tracks:[
              track("gas",gas,fill(n,"idle")),
              track("cost",cost,fill(n,"idle")),
              track("diff",diffs,fill(n,"idle")),
            ],
            counters:[count("index",0,n), count("total",total), count("tank",0), count("start",0)],
            legend:["read","good","bad","done","result","idle"],
            happened:`Gas and cost for each station give diff[i] = gas[i] - cost[i]; the total diff is ${total}.`,
            why:"A circuit exists only if the total gas is at least the total cost; otherwise no start can work.",
            codeLine:3,
          });
          steps.push({
            title:"Rule: if the tank goes negative, restart after the failing station",
            tracks:[
              track("gas",gas,fill(n,"idle")),
              track("cost",cost,fill(n,"idle")),
              track("diff",diffs,fill(n,"idle")),
            ],
            counters:[count("index",0,n), count("total",total), count("tank",0), count("start",0)],
            legend:["read","good","bad","done","result","idle"],
            happened:"Walk once, adding each diff to the tank; if the tank drops below 0, set the next station as the new start candidate and empty the tank.",
            why:"Anything we refuse to use on a bargain will never make us fuel; when the tank runs dry at station i, every start inside the failed stretch is also doomed, so skipping past it loses nothing.",
            codeLine:8,
          });
          if(total<0){
            steps.push({
              title:"Impossible — total gas < total cost",
              tracks:[
                track("gas",gas,fill(n,"bad")),
                track("cost",cost,fill(n,"bad")),
                track("diff",diffs,fill(n,"bad")),
              ],
              counters:[count("total",total), count("answer",-1)],
              happened:"Total difference is negative.",
              why:"No starting point can complete the circuit if overall gas is insufficient.",
              codeLine:10,
            });
            return steps;
          }
          for(let i=0;i<n;i++){
            const d=diffs[i];
            tank+=d;
            const fail = tank<0;
            steps.push({
              title:`Station ${i}: tank ${tank}${fail?" → reset start to "+(i+1):""}`,
              tracks:[
                track("gas",gas,paint(fill(n,"done"),{[i]:"read"})),
                track("cost",cost,paint(fill(n,"done"),{[i]:"read"})),
                track("diff",diffs,paint(fill(n,"done"),{[i]:fail?"bad":"read"})),
              ],
              counters:[count("index",i,n), count("total",total), count("tank",tank), count("start",fail?i+1:start)],
              happened:`Add diff ${d}; tank becomes ${tank}.`+(fail?` Tank negative → start resets to ${i+1}, tank to 0.`:""),
              why:fail? "This failed stretch cannot be part of any valid tour: starting anywhere inside it still runs dry before the end, so start fresh after it." : "The tank stays non-negative; keep accumulating from the current candidate start.",
              codeLine:7,
            });
            if(fail){ start=i+1; tank=0; }
          }
          steps.push({
            title:`Answer: ${start<n?start:-1}`,
            tracks:[
              track("gas",gas,gas.map((_,k)=> k===start?"result":"good")),
              track("cost",cost,fill(n,"good")),
              track("diff",diffs,fill(n,"good")),
            ],
            counters:[count("answer",start<n?start:-1), count("total",total), count("tank",tank)],
            happened:start<n?`Valid start index is ${start}.`:"No valid start found.",
            why:"Since the total gas is enough, the only candidate left after skipping every failed stretch must be the valid start — that is why this greedy choice is safe.",
            codeLine:10,
          });
          return steps;
        },
      },
    ],
  });

  // candy
  V.register({
    id: "candy",
    title: "Candy",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Distribute minimum candies so each child gets more than lower-rated neighbors.",
    input: { label: "Ratings", default: "1, 0, 2", parse: "ints" },
    approaches: [
      {
        name: "Two passes (left-to-right, right-to-left)",
        complexity: "O(n) time, O(n) space",
        idea: [
          "First pass left to right: if rating[i] > rating[i-1], give candy[i] = candy[i-1]+1.",
          "Second pass right to left: if rating[i] > rating[i+1], candy[i] = max(candy[i], candy[i+1]+1).",
          "Sum all candies; two passes ensure both neighbor constraints are satisfied.",
        ],
        problem: [
          "Needs two passes and an extra candy array; not a single-pass greedy.",
        ],
        code: {
          c: `#include <stdio.h>

int candy(int *r, int n){
    if(n==0) return 0;
    int c[n];
    for(int i=0;i<n;i++) c[i]=1;
    for(int i=1;i<n;i++) if(r[i]>r[i-1]) c[i]=c[i-1]+1;
    for(int i=n-2;i>=0;i--) if(r[i]>r[i+1] && c[i]<=c[i+1]) c[i]=c[i+1]+1;
    int sum=0; for(int i=0;i<n;i++) sum+=c[i];
    return sum;
}

int main(void){
    int r[]={1,0,2};
    printf("%d\\n", candy(r,3));
    return 0;
}`,
          cpp: `#include <vector>
#include <iostream>
using namespace std;

int candy(vector<int>& r){
    int n=r.size();
    if(n==0) return 0;
    vector<int> c(n,1);
    for(int i=1;i<n;i++) if(r[i]>r[i-1]) c[i]=c[i-1]+1;
    for(int i=n-2;i>=0;i--) if(r[i]>r[i+1] && c[i]<=c[i+1]) c[i]=c[i+1]+1;
    int sum=0; for(int x: c) sum+=x;
    return sum;
}

int main(){
    vector<int> r={1,0,2};
    cout<<candy(r)<<endl;
    return 0;
}`,
        },
        steps(nums) {
          const r=nums;
          const n=r.length;
          const c=Array(n).fill(1);
          const steps=[];
          steps.push({
            title:"Initialize all candies to 1",
            tracks:[track("ratings",r,fill(n,"idle")), track("candies",c,fill(n,"result"))],
            counters:[count("index",0,n), count("candies",n)],
            legend:["read","good","bad","result","done","idle"],
            happened:"Everyone gets at least one candy.",
            why:"Base requirement: each child must receive >=1 candy.",
            codeLine:5,
          });
          steps.push({
            title:"Rule: sweep left→right, then right→left",
            tracks:[track("ratings",r,fill(n,"idle")), track("candies",c,fill(n,"result"))],
            counters:[count("index",0,n), count("candies",n)],
            legend:["read","good","bad","result","done","idle"],
            happened:"First pass: if rating[i] > rating[i-1], set candy[i] = candy[i-1] + 1. Second pass: if rating[i] > rating[i+1], raise candy[i] to max(candy[i], candy[i+1] + 1).",
            why:"A child only has to beat their neighbours, so fixing one side at a time works; raising a value in the second pass can never break the left side, which is why two passes are enough.",
            codeLine:6,
          });
          for(let i=1;i<n;i++){
            const inc = r[i]>r[i-1];
            if(inc) c[i]=c[i-1]+1;
            steps.push({
              title:`L2R index ${i}: ${r[i]} vs ${r[i-1]}${inc?` → candies ${c[i]}`:" (no change)"}`,
              tracks:[
                track("ratings",r,paint(fill(n,"done"),{[i-1]:"read",[i]:inc?"good":"read"})),
                track("candies",c,c.map((_,k)=> k===i?(inc?"good":"read"):"done")),
              ],
              counters:[count("index",i,n), count("candies",c.reduce((a,b)=>a+b,0))],
              happened:inc?`Higher rating than left neighbor → give ${c[i-1]+1}.`:"Not higher; keep 1 or current value.",
              why:"Satisfies the left-neighbour rule with the smallest value that works; giving any more could only waste candy, so this greedy step is safe.",
              codeLine:6,
            });
          }
          steps.push({
            title:"Left pass done — now fix the right-hand constraints",
            tracks:[track("ratings",r,fill(n,"done")), track("candies",c,fill(n,"result"))],
            counters:[count("index",n-1,n), count("candies",c.reduce((a,b)=>a+b,0))],
            legend:["read","good","bad","result","done","idle"],
            happened:`Every child has at least as many candies as their left neighbour deserves: [${c.join(", ")}].`,
            why:"The left pass is finished; the right pass can only raise values, which keeps the left constraints true.",
            codeLine:6,
          });
          for(let i=n-2;i>=0;i--){
            const inc = r[i]>r[i+1] && c[i]<=c[i+1];
            if(r[i]>r[i+1] && c[i]<=c[i+1]) c[i]=c[i+1]+1;
            steps.push({
              title:`R2L index ${i}: ${r[i]} vs ${r[i+1]}${inc?` → candies ${c[i]}`:" (no change)"}`,
              tracks:[
                track("ratings",r,paint(fill(n,"done"),{[i]:"read",[i+1]:r[i]>r[i+1]?"good":"read"})),
                track("candies",c,c.map((_,k)=> k===i?(inc?"good":"read"):"done")),
              ],
              counters:[count("index",i,n), count("candies",c.reduce((a,b)=>a+b,0))],
              happened:inc?`Higher than right neighbor → bump to ${c[i+1]+1}.`:"Already satisfies right constraint.",
              why:"Second pass fixes the right neighbour while keeping the left one; when this child needs more than the right neighbour, raising it is required — that is why this greedy choice is safe.",
              codeLine:7,
            });
          }
          const total=c.reduce((a,b)=>a+b,0);
          steps.push({
            title:`Answer: ${total} candies`,
            tracks:[track("ratings",r,fill(n,"good")), track("candies",c,fill(n,"result"))],
            counters:[count("answer",total), count("candies",total)],
            happened:`Minimum total candies distributed: ${total}.`,
            why:"Each pass only raises a child that must be higher than a neighbour, and the two directions cover both neighbours; a swap argument shows no arrangement can use fewer, so this greedy choice is safe.",
            codeLine:9,
          });
          return steps;
        },
      },
    ],
  });

  // activity-selection
  V.register({
    id: "activity-selection",
    title: "Activity Selection",
    category: "Greedy",
    difficulty: "Beginner",
    description: "Pick maximum non-overlapping activities by sorting on finish times.",
    input: { label: "Intervals start,end", default: "1,3 2,5 4,7 6,8", parse: "pairs" },
    approaches: [
      {
        name: "Greedy on finish time",
        complexity: "O(n log n) time, O(1) space (sort dominates)",
        idea: [
          "Sort all activities by finish time ascending.",
          "Pick first activity; then always pick the next activity whose start >= last picked finish.",
          "Count how many are picked.",
        ],
        problem: [
          "Sorting dominates cost; greedy on earliest finish gives maximum count.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int s,e; } Act;
int cmp(const void *a,const void *b){ return ((Act*)a)->e - ((Act*)b)->e; }

int selectActivities(Act *a,int n){
    if(n==0) return 0;
    qsort(a,n,sizeof(Act),cmp);
    int count=1, last=a[0].e;
    for(int i=1;i<n;i++){
        if(a[i].s>=last){ count++; last=a[i].e; }
    }
    return count;
}

int main(void){
    Act a[]={{1,3},{2,5},{4,7},{6,8}};
    printf("%d\\n", selectActivities(a,4));
    return 0;
}`,
          cpp: `#include <vector>
#include <algorithm>
#include <iostream>
using namespace std;

struct Act { int s,e; };

int selectActivities(vector<Act>& a){
    sort(a.begin(),a.end(),[](Act &x,Act &y){ return x.e<y.e; });
    if(a.empty()) return 0;
    int count=1, last=a[0].e;
    for(size_t i=1;i<a.size();i++){
        if(a[i].s>=last){ count++; last=a[i].e; }
    }
    return count;
}

int main(){
    vector<Act> a={{1,3},{2,5},{4,7},{6,8}};
    cout<<selectActivities(a)<<endl;
    return 0;
}`,
        },
        steps(parsed) {
          const acts = toPairs(parsed).map(p=>({s:p[0],e:p[1]}));
          const n=acts.length;
          const sorted=acts.slice().sort((x,y)=>x.e-y.e);
          const states=Array(n).fill("idle");
          const steps=[];
          steps.push({
            title:"Given: activities in the order they were typed",
            tracks:[track("activities (given)",acts.map(a=>`${a.s}-${a.e}`),fill(n,"idle"))],
            counters:[count("picked",0,n), count("index",0,n)],
            legend:["read","good","bad","done","result","idle"],
            happened:`We have ${n} activities, each shown as start-end.`,
            why:"The order we received them in says nothing about which ones fit together, so we start by looking at the input.",
            codeLine:17,
          });
          steps.push({
            title:"Sort activities by finish time",
            tracks:[track("activities",sorted.map(a=>`${a.s}-${a.e}`),fill(n,"idle"))],
            counters:[count("picked",0,n), count("index",0,n)],
            legend:["read","good","bad","done","result","idle"],
            happened:"Sorted all activities ascending by finish time.",
            why:"The one who finishes earliest leaves the most time free for later activities, so ordering by finish time is the safe greedy order.",
            codeLine:8,
          });
          steps.push({
            title:"Rule: after picking one, take the next activity that starts at or after its finish",
            tracks:[track("activities",sorted.map(a=>`${a.s}-${a.e}`),fill(n,"idle"))],
            counters:[count("picked",0,n), count("index",0,n)],
            legend:["read","good","bad","done","result","idle"],
            happened:"Keep the finish time of the last picked activity; move on and pick the first activity whose start is not before that finish.",
            why:"Any activity that overlaps the chosen one cannot be in the same solution as it, and because activities are sorted by finish time, the chosen one is never a worse pick than an overlapping later one.",
            codeLine:11,
          });
          if(n===0){
            steps.push({title:"Answer: 0",tracks:[{label:"picked",cells:[{v:0,state:"result"}]}],counters:[count("answer",0)],happened:"No activities.",why:"Base case: nothing to schedule.",codeLine:7});
            return steps;
          }
          let picked=1, last=sorted[0].e;
          states[0]="good";
          steps.push({
            title:`Pick activity 0 (${sorted[0].s}-${sorted[0].e})`,
            tracks:[track("activities",sorted.map(a=>`${a.s}-${a.e}`),states.slice())],
            counters:[count("picked",picked,n), count("index",0,n)],
            happened:`Selected the first activity, which ends at ${last}.`,
            why:"The earliest-finishing activity is always safe to pick: swapping it in for any other activity can only free up more time afterwards.",
            codeLine:9,
          });
          for(let i=1;i<n;i++){
            const ok=sorted[i].s>=last;
            if(ok){ picked++; last=sorted[i].e; states[i]="good"; }
            else states[i]="bad";
            steps.push({
              title:`Check ${sorted[i].s}-${sorted[i].e}: ${ok?"picked":"overlap, skip"}`,
              tracks:[track("activities",sorted.map(a=>`${a.s}-${a.e}`),states.slice())],
              counters:[count("picked",picked,n), count("index",i,n)],
              happened:ok?`Start ${sorted[i].s} >= last finish ${last} → pick it.`:`Start ${sorted[i].s} < last finish ${last} → overlaps, skip it.`,
              why:ok?"It starts after the last finish, so it cannot clash, and it finishes earliest among the remaining choices.":"It overlaps the chosen activity, and every later activity finishes no earlier, so skipping it can never cost us a pick.",
              codeLine:11,
            });
          }
          steps.push({
            title:`Answer: ${picked}`,
            tracks:[track("activities",sorted.map(a=>`${a.s}-${a.e}`),states.map(s=>s==="good"?"result":"dim"))],
            counters:[count("answer",picked), count("picked",picked,n)],
            happened:`Picked ${picked} non-overlapping activities.`,
            why:"Greedy on earliest finish is provably optimal: an exchange argument shows the first pick is safe and then the same reasoning repeats for the rest.",
            codeLine:13,
          });
          return steps;
        },
      },
    ],
  });
})();