/* ============================================================
   DSA Visuals — Dynamic Programming I
   Grid paths, path sums, triangle, coin change and 0/1 knapsack.
   ============================================================ */
(function () {
  "use strict";
  const { count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const partsOf = (text) => String(text || "").split("|").map((p) => p.trim());
  const intsOf = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number).filter(Number.isFinite);
  const show = (a) => `[${a.join(", ")}]`;

  /* ---------------------------------------------------------- */
  V.register({
    id: "unique-paths",
    title: "Unique Paths",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Count routes from the top-left to the bottom-right moving only right or down.",
    input: { label: "rows,cols", default: "3,7", parse: "string" },
    approaches: [
      {
        name: "Grid Recurrence",
        complexity: "O(rows × cols) time",
        idea: [
          "A cell can only be entered from above or from the left, so paths(r,c) = paths(r−1,c) + paths(r,c−1).",
          "The first row and first column each have exactly one route. Filling the table row by row gives the corner count without exploring paths individually.",
        ],
        problem: [
          "Enumerating every route is exponential; the recurrence reuses counts of subgrids.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint main(void) {\n    int m = 3, n = 7;\n    int dp[3][7];\n\n    for (int c = 0; c < n; c++) dp[0][c] = 1;\n    for (int r = 0; r < m; r++) dp[r][0] = 1;\n\n    for (int r = 1; r < m; r++)\n        for (int c = 1; c < n; c++)\n            dp[r][c] = dp[r-1][c] + dp[r][c-1];\n\n    printf(\"%d\\n\", dp[m-1][n-1]); /* 28 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint uniquePaths(int m, int n) {\n    vector<vector<int>> dp(m, vector<int>(n, 0));\n    for (int c = 0; c < n; c++) dp[0][c] = 1;\n    for (int r = 0; r < m; r++) dp[r][0] = 1;\n\n    for (int r = 1; r < m; r++)\n        for (int c = 1; c < n; c++)\n            dp[r][c] = dp[r-1][c] + dp[r][c-1];\n    return dp[m-1][n-1];\n}\n\nint main() {\n    cout << uniquePaths(3, 7) << '\\n'; // 28\n}`,
        },
        steps(text) {
          const dims = intsOf(text);
          let m = Math.max(1, Math.min(8, dims[0] || 3));
          let n = Math.max(1, Math.min(10, dims[1] || 7));
          const dp = Array.from({ length: m }, () => Array(n).fill(0));
          const steps = [];
          const cells = (curR, curC) => grid(m, n, (r, c) => ({
            v: dp[r][c],
            state: r === curR && c === curC ? "read" : dp[r][c] > 0 ? "done" : "idle",
          }));
          steps.push({
            title: `A ${m} × ${n} grid`,
            kind: "grid", rows: m, cols: n, cells: cells(-1, -1),
            counters: [count("paths", 0), count("cells", m * n)],
            legend: LEG,
            happened: "Every cell starts with zero paths.",
            why: "The table stores the number of ways to reach each cell, not the routes themselves.",
            codeLine: 4,
          });
          for (let c = 0; c < n; c++) dp[0][c] = 1;
          for (let r = 0; r < m; r++) dp[r][0] = 1;
          steps.push({
            title: "The first row and first column each have one route",
            kind: "grid", rows: m, cols: n, cells: cells(0, 0),
            counters: [count("paths", dp[0][n - 1]), count("base cells", m + n - 1)],
            legend: LEG,
            happened: "Moving only right along the top, or only down the left, gives a single path to each base cell.",
            why: "There is no choice on the border, so every border cell has exactly one route.",
            codeLine: 7,
          });
          for (let r = 1; r < m; r++) {
            for (let c = 1; c < n; c++) {
              dp[r][c] = dp[r - 1][c] + dp[r][c - 1];
            }
            steps.push({
              title: `Row ${r} filled from the row above and the cell to the left`,
              kind: "grid", rows: m, cols: n, cells: cells(r, n - 1),
              counters: [count("paths", dp[r][n - 1]), count("row", r + 1, m)],
              legend: LEG,
              happened: `The last cell of row ${r} holds ${dp[r][n - 1]} paths.`,
              why: "Each cell adds the routes entering from above and from the left, which are already known.",
              codeLine: 12,
            });
          }
          steps.push({
            title: `Answer: ${dp[m - 1][n - 1]} unique paths`,
            kind: "grid", rows: m, cols: n, cells: grid(m, n, (r, c) => ({ v: dp[r][c], state: r === m - 1 && c === n - 1 ? "result" : "done" })),
            counters: [count("paths", dp[m - 1][n - 1]), count("cells", m * n)],
            legend: LEG,
            happened: `The bottom-right cell accumulated ${dp[m - 1][n - 1]} routes.`,
            why: "Every route ends by entering the corner from above or from the left, so the sum is complete.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "unique-paths-ii",
    title: "Unique Paths II",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Count paths through a grid while avoiding blocked cells.",
    input: { label: "Grid rows of digits separated by |", default: "000 | 010 | 000", parse: "string" },
    approaches: [
      {
        name: "Grid Recurrence With Obstacles",
        complexity: "O(rows × cols) time",
        idea: [
          "Use the same recurrence as Unique Paths, but set every obstacle cell to zero routes.",
          "The first row and column stop being reachable after the first obstacle because a blocked cell cannot be crossed.",
        ],
        problem: [
          "Treating obstacles as ordinary cells counts routes that walk through a wall.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint g[3][3] = {{0,0,0},{0,1,0},{0,0,0}};\nint dp[3][3];\n\nint main(void) {\n    for (int r = 0; r < 3; r++)\n        for (int c = 0; c < 3; c++) {\n            if (g[r][c]) { dp[r][c] = 0; continue; }\n            if (r == 0 && c == 0) dp[r][c] = 1;\n            else dp[r][c] = (r ? dp[r-1][c] : 0) + (c ? dp[r][c-1] : 0);\n        }\n    printf(\"%d\\n\", dp[2][2]); /* 2 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint uniquePathsWithObstacles(vector<vector<int>>& g) {\n    int m = g.size(), n = g[0].size();\n    vector<vector<int>> dp(m, vector<int>(n, 0));\n    for (int r = 0; r < m; r++)\n        for (int c = 0; c < n; c++) {\n            if (g[r][c]) continue;\n            if (r == 0 && c == 0) dp[r][c] = 1;\n            else dp[r][c] = (r ? dp[r-1][c] : 0) + (c ? dp[r][c-1] : 0);\n        }\n    return dp[m-1][n-1];\n}\n\nint main() {\n    vector<vector<int>> g{{0,0,0},{0,1,0},{0,0,0}};\n    cout << uniquePathsWithObstacles(g) << '\\n'; // 2\n}`,
        },
        steps(text) {
          const rows = partsOf(text).filter(Boolean).map((r) => r.split("").filter((ch) => ch === "0" || ch === "1"));
          let m = Math.min(8, rows.length);
          if (!m) m = 3;
          const n = Math.min(10, Math.max(1, ...rows.slice(0, m).map((r) => r.length)));
          const g = Array.from({ length: m }, (_, r) => Array.from({ length: n }, (_, c) => (rows[r] && rows[r][c] === "1" ? 1 : 0)));
          const dp = Array.from({ length: m }, () => Array(n).fill(0));
          const steps = [];
          const cells = (curR) => grid(m, n, (r, c) => ({
            v: g[r][c] ? "×" : dp[r][c],
            state: g[r][c] ? "bad" : r === curR ? "read" : dp[r][c] > 0 ? "done" : "idle",
          }));
          steps.push({
            title: `${m} × ${n} grid with blocked cells`,
            kind: "grid", rows: m, cols: n, cells: cells(-1),
            counters: [count("paths", 0), count("walls", g.flat().filter(Boolean).length)],
            legend: LEG,
            happened: "Blocked cells are marked × and will always hold zero paths.",
            why: "A route may not enter or cross a wall.",
            codeLine: 4,
          });
          for (let r = 0; r < m; r++) {
            for (let c = 0; c < n; c++) {
              if (g[r][c]) { dp[r][c] = 0; continue; }
              if (r === 0 && c === 0) dp[r][c] = g[0][0] ? 0 : 1;
              else dp[r][c] = (r ? dp[r - 1][c] : 0) + (c ? dp[r][c - 1] : 0);
            }
            steps.push({
              title: `Fill row ${r}`,
              kind: "grid", rows: m, cols: n, cells: cells(r),
              counters: [count("paths", dp[r][n - 1]), count("row", r + 1, m)],
              legend: LEG,
              happened: `Row ${r} ends with ${dp[r][n - 1]} paths at its last cell.`,
              why: "Walls contribute zero, so routes cannot pass through them.",
              codeLine: 8,
            });
          }
          steps.push({
            title: dp[m - 1][n - 1] ? `Answer: ${dp[m - 1][n - 1]} unique paths` : "Answer: the destination is unreachable",
            kind: "grid", rows: m, cols: n, cells: grid(m, n, (r, c) => ({ v: g[r][c] ? "×" : dp[r][c], state: g[r][c] ? "bad" : r === m - 1 && c === n - 1 ? "result" : "done" })),
            counters: [count("paths", dp[m - 1][n - 1]), count("walls", g.flat().filter(Boolean).length)],
            legend: LEG,
            happened: dp[m - 1][n - 1] ? `The corner accumulates ${dp[m - 1][n - 1]} valid paths.` : "A wall cut off every route to the corner.",
            why: "The recurrence only adds paths that exist in unblocked neighbours.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "minimum-path-sum",
    title: "Minimum Path Sum",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Find the cheapest route from the top-left to the bottom-right moving right or down.",
    input: { label: "Grid rows of numbers separated by |", default: "1,3,1 | 1,5,1 | 4,2,1", parse: "string" },
    approaches: [
      {
        name: "Grid Prefix Costs",
        complexity: "O(rows × cols) time",
        idea: [
          "dp[r][c] is the cheapest cost to reach cell (r,c): the cell's own value plus the cheaper of the best cost from above and from the left.",
          "Border cells have only one predecessor, so their costs are running sums along the first row and first column.",
        ],
        problem: [
          "Choosing the cheaper neighbour by its raw value ignores the cost already paid to reach that neighbour.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint g[3][3] = {{1,3,1},{1,5,1},{4,2,1}};\nint dp[3][3];\n\nint main(void) {\n    for (int r = 0; r < 3; r++)\n        for (int c = 0; c < 3; c++) {\n            int best = 1 << 30;\n            if (r) best = dp[r-1][c];\n            if (c && dp[r][c-1] < best) best = dp[r][c-1];\n            dp[r][c] = g[r][c] + (best == (1 << 30) ? 0 : best);\n        }\n    printf(\"%d\\n\", dp[2][2]); /* 7 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint minPathSum(vector<vector<int>>& g) {\n    int m = g.size(), n = g[0].size();\n    vector<vector<int>> dp(m, vector<int>(n, 0));\n    for (int r = 0; r < m; r++)\n        for (int c = 0; c < n; c++) {\n            if (!r && !c) dp[r][c] = g[r][c];\n            else if (!r) dp[r][c] = dp[r][c-1] + g[r][c];\n            else if (!c) dp[r][c] = dp[r-1][c] + g[r][c];\n            else dp[r][c] = min(dp[r-1][c], dp[r][c-1]) + g[r][c];\n        }\n    return dp[m-1][n-1];\n}\n\nint main() {\n    vector<vector<int>> g{{1,3,1},{1,5,1},{4,2,1}};\n    cout << minPathSum(g) << '\\n'; // 7\n}`,
        },
        steps(text) {
          const rows = partsOf(text).filter(Boolean).map((r) => r.split(",").map(Number).filter(Number.isFinite));
          const m = Math.min(8, rows.length);
          if (!m) return [{
            title: "Give at least one grid row",
            tracks: [chips("grid", ["—"], "idle")],
            counters: [count("cost", 0)],
            legend: LEG,
            happened: "There is no grid.",
            why: "A path needs cells with costs.",
          }];
          const n = Math.min(10, Math.max(...rows.slice(0, m).map((r) => r.length)));
          const g = Array.from({ length: m }, (_, r) => Array.from({ length: n }, (_, c) => (Number.isFinite(rows[r][c]) ? rows[r][c] : 0)));
          const dp = Array.from({ length: m }, () => Array(n).fill(0));
          const steps = [];
          const cells = (curR) => grid(m, n, (r, c) => ({
            v: dp[r][c],
            state: r === curR ? "read" : dp[r][c] > 0 ? "done" : "idle",
          }));
          steps.push({
            title: `${m} × ${n} grid of costs`,
            kind: "grid", rows: m, cols: n, cells: cells(-1),
            counters: [count("rows", m), count("cols", n)],
            legend: LEG,
            happened: "The table is empty; each cell will store the cheapest cost to reach it.",
            why: "The optimum for a cell depends only on the optimum of its top and left neighbours.",
            codeLine: 4,
          });
          for (let r = 0; r < m; r++) {
            for (let c = 0; c < n; c++) {
              if (r === 0 && c === 0) dp[r][c] = g[r][c];
              else if (r === 0) dp[r][c] = dp[r][c - 1] + g[r][c];
              else if (c === 0) dp[r][c] = dp[r - 1][c] + g[r][c];
              else dp[r][c] = Math.min(dp[r - 1][c], dp[r][c - 1]) + g[r][c];
            }
            steps.push({
              title: `Row ${r}: cheapest cost ${dp[r][n - 1]} at the right edge`,
              kind: "grid", rows: m, cols: n, cells: cells(r),
              counters: [count("cost", dp[r][n - 1]), count("row", r + 1, m)],
              legend: LEG,
              happened: `Cell values are reused as the running cheapest cost, not the raw grid cost.`,
              why: "Each cell adds its own cost to the better of the two already-optimal neighbours.",
              codeLine: 10,
            });
          }
          const best = dp[m - 1][n - 1];
          const path = [];
          let r = m - 1, c = n - 1;
          while (r > 0 || c > 0) {
            path.push([r, c]);
            if (r === 0) c--;
            else if (c === 0) r--;
            else if (dp[r - 1][c] <= dp[r][c - 1]) r--;
            else c--;
          }
          path.push([0, 0]);
          steps.push({
            title: `Answer: minimum path sum ${best}`,
            kind: "grid", rows: m, cols: n, cells: grid(m, n, (rr, cc) => ({ v: dp[rr][cc], state: path.some(([a, b]) => a === rr && b === cc) ? "result" : "done" })),
            counters: [count("cost", best), count("cells", path.length)],
            legend: LEG,
            happened: `The best route costs ${best} and contains ${path.length} cells.`,
            why: "Backtracking towards the cheaper predecessor recovers a route that achieves the table value.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "triangle",
    title: "Triangle",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Find the minimum path sum from the top of a number triangle to its base.",
    input: { label: "Rows separated by |", default: "2 | 3,4 | 6,5,7 | 4,1,8,3", parse: "string" },
    approaches: [
      {
        name: "Bottom-Up Triangle DP",
        complexity: "O(rows²) time",
        idea: [
          "Start from the bottom row. Above it, each cell can move to the two adjacent cells below, so it takes its own value plus the smaller of those two.",
          "Collapsing upward row by row leaves one number at the top: the minimum path sum. No separate table is needed if the bottom row is reused.",
        ],
        problem: [
          "Top-down greedy choices can be locally cheap but force a very expensive lower row.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint t[4][4] = {{2},{3,4},{6,5,7},{4,1,8,3}};\nint dp[4];\n\nint main(void) {\n    for (int c = 0; c < 4; c++) dp[c] = t[3][c];\n\n    for (int r = 2; r >= 0; r--)\n        for (int c = 0; c <= r; c++)\n            dp[c] = t[r][c] + (dp[c] < dp[c+1] ? dp[c] : dp[c+1]);\n\n    printf(\"%d\\n\", dp[0]); /* 11 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint minimumTotal(vector<vector<int>>& t) {\n    vector<int> dp = t.back();\n    for (int r = t.size() - 2; r >= 0; r--)\n        for (int c = 0; c <= r; c++)\n            dp[c] = t[r][c] + min(dp[c], dp[c + 1]);\n    return dp[0];\n}\n\nint main() {\n    vector<vector<int>> t{{2},{3,4},{6,5,7},{4,1,8,3}};\n    cout << minimumTotal(t) << '\\n'; // 11\n}`,
        },
        steps(text) {
          const rows = partsOf(text).filter(Boolean).map((r) => r.split(",").map(Number).filter(Number.isFinite));
          const R = Math.min(8, rows.length);
          if (!R) return [{
            title: "Give triangle rows",
            tracks: [chips("rows", ["—"], "idle")],
            counters: [count("rows", 0)],
            legend: LEG,
            happened: "There is no triangle.",
            why: "Each row needs at least one number.",
          }];
          const C = Math.min(10, Math.max(...rows.slice(0, R).map((r) => r.length)));
          const t = Array.from({ length: R }, (_, r) => Array.from({ length: C }, (_, c) => (Number.isFinite(rows[r][c]) ? rows[r][c] : null)));
          const dp = t[R - 1].slice();
          const steps = [];
          const cells = (curR) => grid(R, C, (r, c) => {
            const blank = t[r][c] == null;
            const val = r === R - 1 ? t[r][c] : dp[c];
            return { v: blank ? "·" : val, state: blank ? "dim" : r === curR ? "read" : "done" };
          });
          steps.push({
            title: `${R} rows in the triangle`,
            kind: "grid", rows: R, cols: C, cells: cells(-1),
            counters: [count("rows", R), count("numbers", t.flat().filter((x) => x != null).length)],
            legend: LEG,
            happened: "The bottom row is copied into the working DP array.",
            why: "Paths only move downward, so solving from the base upward avoids unknown future choices.",
            codeLine: 4,
          });
          steps.push({
            title: "Start with the base row",
            kind: "grid", rows: R, cols: C, cells: cells(R - 1),
            counters: [count("best", dp[0]), count("row", R)],
            legend: LEG,
            happened: `The base costs are ${dp.filter((x) => x != null).join(", ")}.`,
            why: "At the bottom there is no further choice, so the cost is just the cell value.",
            codeLine: 5,
          });
          for (let r = R - 2; r >= 0; r--) {
            for (let c = 0; c <= r; c++) dp[c] = t[r][c] + Math.min(dp[c], dp[c + 1]);
            steps.push({
              title: `Collapse row ${r}: best from the top becomes ${dp[0]}`,
              kind: "grid", rows: R, cols: C, cells: cells(r),
              counters: [count("best", dp[0]), count("row", r + 1, R)],
              legend: LEG,
              happened: `Each cell of row ${r} adds its value to the cheaper child below it.`,
              why: "The two child values are already optimal for their subtriangles.",
              codeLine: 8,
            });
          }
          steps.push({
            title: `Answer: minimum triangle path ${dp[0]}`,
            kind: "grid", rows: R, cols: C, cells: grid(R, C, (r, c) => ({ v: t[r][c] == null ? "·" : r === 0 ? dp[0] : t[r][c], state: t[r][c] == null ? "dim" : r === 0 ? "result" : "done" })),
            counters: [count("minimum", dp[0]), count("rows", R)],
            legend: LEG,
            happened: `The top of the collapsed table is ${dp[0]}.`,
            why: "Every row chose the cheaper of its two children, so the surviving number is the global minimum.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "coin-change",
    title: "Coin Change",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Use the fewest coins to make an amount when every coin can be reused.",
    input: { label: "Coins | amount", default: "1,2,5 | 11", parse: "string" },
    approaches: [
      {
        name: "Fewest Coins per Amount",
        complexity: "O(amount × coins) time",
        idea: [
          "dp[a] is the fewest coins that make amount a, with dp[0] = 0 and every other amount initially infinite.",
          "For each amount, try every coin no larger than it: dp[a] = min(dp[a], dp[a − coin] + 1). The coin count adds one to a smaller, already-solved amount.",
        ],
        problem: [
          "A greedy largest-coin-first choice fails for many coin systems, such as coins 1, 3, 4 and amount 6.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint main(void) {\n    int coins[] = {1,2,5}, n = 3, amount = 11;\n    int dp[12];\n    dp[0] = 0;\n    for (int a = 1; a <= amount; a++) dp[a] = 1 << 30;\n\n    for (int a = 1; a <= amount; a++)\n        for (int i = 0; i < n; i++)\n            if (coins[i] <= a && dp[a - coins[i]] + 1 < dp[a])\n                dp[a] = dp[a - coins[i]] + 1;\n\n    printf(\"%d\\n\", dp[amount]); /* 3 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint coinChange(vector<int>& coins, int amount) {\n    vector<int> dp(amount + 1, amount + 1);\n    dp[0] = 0;\n    for (int a = 1; a <= amount; a++)\n        for (int c : coins)\n            if (c <= a) dp[a] = min(dp[a], dp[a - c] + 1);\n    return dp[amount] > amount ? -1 : dp[amount];\n}\n\nint main() {\n    vector<int> coins{1,2,5};\n    cout << coinChange(coins, 11) << '\\n'; // 3\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const coins = [...new Set(intsOf(parts[0]).filter((c) => c > 0))].sort((a, b) => a - b).slice(0, 10);
          const amount = Math.min(30, Math.max(0, parseInt(parts[1], 10) || 0));
          if (!coins.length || !amount) return [{
            title: "Give coins and a positive amount",
            tracks: [chips("coins", coins.length ? coins : ["—"], "idle")],
            counters: [count("coins", 0)],
            legend: LEG,
            happened: "The input is incomplete.",
            why: "The DP needs at least one coin denomination and a target amount.",
          }];
          const dp = Array(amount + 1).fill(Infinity);
          dp[0] = 0;
          const steps = [];
          const val = (x) => (x === Infinity ? "∞" : x);
          steps.push({
            title: `Make ${amount} from coins ${show(coins)}`,
            tracks: [chips("coins", coins, "compare"), chips("dp", dp.map(val), (i) => (i === 0 ? "result" : "dim"))],
            counters: [count("amount", amount), count("coins", coins.length)],
            legend: LEG,
            happened: "Amount 0 needs zero coins; every larger amount starts impossible.",
            why: "Infinity represents an amount that has not been reached yet.",
            codeLine: 4,
          });
          for (let a = 1; a <= amount; a++) {
            let from = -1;
            coins.forEach((c) => {
              if (c <= a && dp[a - c] + 1 < dp[a]) { dp[a] = dp[a - c] + 1; from = c; }
            });
            steps.push({
              title: `Amount ${a}: ${dp[a] === Infinity ? "impossible" : `${dp[a]} coins`}${from > 0 ? ` (last coin ${from})` : ""}`,
              tracks: [
                chips("dp", dp.map(val), (i) => (i === a ? "read" : i < a ? "done" : "dim")),
                chips("coins", coins, (i) => (from > 0 && coins[i] === from ? "result" : "idle")),
              ],
              counters: [count("amount", a, amount), count("coins used", dp[a] === Infinity ? -1 : dp[a])],
              legend: LEG,
              happened: from > 0 ? `Using coin ${from} adds one to the best solution for ${a - from}.` : "No coin can reach this amount.",
              why: "Every solution for a ends with some coin c, leaving the smaller amount a − c.",
              codeLine: 9,
            });
          }
          steps.push({
            title: dp[amount] === Infinity ? `Answer: ${amount} cannot be formed` : `Answer: ${dp[amount]} coins`,
            tracks: [chips("dp", dp.map(val), (i) => (i === amount ? "result" : "done")), chips("coins", coins, "good")],
            counters: [count("coins used", dp[amount] === Infinity ? -1 : dp[amount]), count("amount", amount)],
            legend: LEG,
            happened: dp[amount] === Infinity ? "The target stayed infinite after every coin was considered." : `The target needs ${dp[amount]} coins.`,
            why: "The table stores the optimum for every smaller amount, so the final entry is optimal.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "coin-change-ii",
    title: "Coin Change II",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Count the number of combinations that make an amount, reusing coins in any order.",
    input: { label: "Coins | amount", default: "1,2,5 | 5", parse: "string" },
    approaches: [
      {
        name: "Combinations by Coin Order",
        complexity: "O(amount × coins) time",
        idea: [
          "dp[a] counts combinations for amount a, starting with dp[0] = 1 for the empty combination.",
          "Process one coin at a time and update capacities upward. A coin is allowed any number of times, but processing coins in an outer loop prevents counting 1+2 and 2+1 as different combinations.",
        ],
        problem: [
          "Looping amounts outside coins counts permutations; this problem wants combinations.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint main(void) {\n    int coins[] = {1,2,5}, n = 3, amount = 5;\n    int dp[6] = {1,0,0,0,0,0};\n\n    for (int i = 0; i < n; i++)\n        for (int a = coins[i]; a <= amount; a++)\n            dp[a] += dp[a - coins[i]];\n\n    printf(\"%d\\n\", dp[amount]); /* 4 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint change(int amount, vector<int>& coins) {\n    vector<int> dp(amount + 1, 0);\n    dp[0] = 1;\n    for (int c : coins)\n        for (int a = c; a <= amount; a++)\n            dp[a] += dp[a - c];\n    return dp[amount];\n}\n\nint main() {\n    vector<int> coins{1,2,5};\n    cout << change(5, coins) << '\\n'; // 4\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const coins = [...new Set(intsOf(parts[0]).filter((c) => c > 0))].sort((a, b) => a - b).slice(0, 10);
          const amount = Math.min(30, Math.max(0, parseInt(parts[1], 10) || 0));
          if (!coins.length || !amount) return [{
            title: "Give coins and a positive amount",
            tracks: [chips("coins", coins.length ? coins : ["—"], "idle")],
            counters: [count("combinations", 0)],
            legend: LEG,
            happened: "The input is incomplete.",
            why: "Counting combinations needs denominations and a target.",
          }];
          const dp = Array(amount + 1).fill(0);
          dp[0] = 1;
          const steps = [];
          steps.push({
            title: `Count combinations for ${amount} using ${show(coins)}`,
            tracks: [chips("coins", coins, "compare"), chips("dp", dp, (i) => (i === 0 ? "result" : "dim"))],
            counters: [count("amount", amount), count("combinations", 0)],
            legend: LEG,
            happened: "Only amount 0 has one combination: choose nothing.",
            why: "Every other amount starts with zero known combinations.",
            codeLine: 4,
          });
          coins.forEach((coin, idx) => {
            for (let a = coin; a <= amount; a++) dp[a] += dp[a - coin];
            steps.push({
              title: `After allowing coin ${coin}: ${dp[amount]} combinations`,
              tracks: [
                chips("dp", dp, (i) => (i === amount ? "read" : i > 0 ? "done" : "result")),
                chips("coins used so far", coins.slice(0, idx + 1), (i) => (i === idx ? "active" : "done")),
              ],
              counters: [count("combinations", dp[amount]), count("coin types", idx + 1, coins.length)],
              legend: LEG,
              happened: `Adding coin ${coin} creates combinations that end with it, on top of the previous coin types.`,
              why: "The outer loop fixes the coin order, so each combination is generated once.",
              codeLine: 7,
            });
          });
          steps.push({
            title: `Answer: ${dp[amount]} combination${dp[amount] === 1 ? "" : "s"}`,
            tracks: [chips("dp", dp, (i) => (i === amount ? "result" : "done")), chips("coins", coins, "good")],
            counters: [count("combinations", dp[amount]), count("amount", amount)],
            legend: LEG,
            happened: `There are ${dp[amount]} distinct ways to combine the coins into ${amount}.`,
            why: "dp[amount] accumulates one contribution per coin type, never per ordering.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "0-1-knapsack",
    title: "0/1 Knapsack",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Choose whole items to maximise value without exceeding the weight limit.",
    input: { label: "weights | values | capacity", default: "1,3,4,5 | 1,4,5,7 | 7", parse: "string" },
    approaches: [
      {
        name: "Item-by-Item Capacity Table",
        complexity: "O(items × capacity) time",
        idea: [
          "dp[i][w] is the best value using the first i items with capacity w. For each item there are two choices: skip it, or take it if it fits.",
          "Taking item i adds its value to the best solution for the remaining capacity using earlier items only, which prevents reusing the same item.",
        ],
        problem: [
          "A greedy value-to-weight order fails when a heavy high-value item blocks a better combination of lighter items.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint main(void) {\n    int wt[] = {1,3,4,5}, val[] = {1,4,5,7};\n    int n = 4, cap = 7;\n    int dp[5][8] = {0};\n\n    for (int i = 1; i <= n; i++)\n        for (int w = 0; w <= cap; w++) {\n            dp[i][w] = dp[i-1][w];\n            if (wt[i-1] <= w && dp[i-1][w-wt[i-1]] + val[i-1] > dp[i][w])\n                dp[i][w] = dp[i-1][w-wt[i-1]] + val[i-1];\n        }\n\n    printf(\"%d\\n\", dp[n][cap]); /* 9 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint knapsack(vector<int>& wt, vector<int>& val, int cap) {\n    int n = wt.size();\n    vector<vector<int>> dp(n + 1, vector<int>(cap + 1, 0));\n    for (int i = 1; i <= n; i++)\n        for (int w = 0; w <= cap; w++) {\n            dp[i][w] = dp[i-1][w];\n            if (wt[i-1] <= w) dp[i][w] = max(dp[i][w], dp[i-1][w-wt[i-1]] + val[i-1]);\n        }\n    return dp[n][cap];\n}\n\nint main() {\n    vector<int> wt{1,3,4,5}, val{1,4,5,7};\n    cout << knapsack(wt, val, 7) << '\\n'; // 9\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const weights = intsOf(parts[0]).filter((w) => w > 0);
          const values = intsOf(parts[1]);
          const cap = Math.min(20, Math.max(0, parseInt(parts[2], 10) || 0));
          const n = Math.min(8, Math.min(weights.length, values.length));
          if (!n || !cap) return [{
            title: "Give weights, values and a capacity",
            tracks: [chips("items", ["—"], "idle")],
            counters: [count("value", 0)],
            legend: LEG,
            happened: "The knapsack input is incomplete.",
            why: "The table needs items and a positive capacity.",
          }];
          const dp = Array.from({ length: n + 1 }, () => Array(cap + 1).fill(0));
          const steps = [];
          steps.push({
            title: `${n} items, capacity ${cap}`,
            kind: "grid", rows: n + 1, cols: cap + 1,
            rowHeads: Array.from({ length: n + 1 }, (_, i) => (i === 0 ? "none" : `#${i}`)),
            colHeads: Array.from({ length: cap + 1 }, (_, w) => String(w)),
            cells: grid(n + 1, cap + 1, (r, c) => ({ v: dp[r][c], state: r === 0 ? "done" : "idle" })),
            counters: [count("items", n), count("capacity", cap)],
            legend: LEG,
            happened: "With no items, every capacity has value zero.",
            why: "dp[0][w] is the empty knapsack base case.",
            codeLine: 4,
          });
          for (let i = 1; i <= n; i++) {
            for (let w = 0; w <= cap; w++) {
              dp[i][w] = dp[i - 1][w];
              if (weights[i - 1] <= w) dp[i][w] = Math.max(dp[i][w], dp[i - 1][w - weights[i - 1]] + values[i - 1]);
            }
            steps.push({
              title: `Item ${i} (weight ${weights[i - 1]}, value ${values[i - 1]}): best ${dp[i][cap]}`,
              kind: "grid", rows: n + 1, cols: cap + 1,
              rowHeads: Array.from({ length: n + 1 }, (_, r) => (r === 0 ? "none" : `#${r}`)),
              colHeads: Array.from({ length: cap + 1 }, (_, w) => String(w)),
              cells: grid(n + 1, cap + 1, (r, c) => ({ v: dp[r][c], state: r === i ? "read" : r < i ? "done" : "idle" })),
              counters: [count("value", dp[i][cap]), count("items", i, n)],
              legend: LEG,
              happened: `Row ${i} either skips the item or takes it and reuses row ${i - 1} at the reduced capacity.`,
              why: "Referring to the previous row guarantees each item is used at most once.",
              codeLine: 8,
            });
          }
          steps.push({
            title: `Answer: maximum value ${dp[n][cap]}`,
            kind: "grid", rows: n + 1, cols: cap + 1,
            rowHeads: Array.from({ length: n + 1 }, (_, i) => (i === 0 ? "none" : `#${i}`)),
            colHeads: Array.from({ length: cap + 1 }, (_, w) => String(w)),
            cells: grid(n + 1, cap + 1, (r, c) => ({ v: dp[r][c], state: r === n && c === cap ? "result" : "done" })),
            counters: [count("value", dp[n][cap]), count("capacity", cap)],
            legend: LEG,
            happened: `The bottom-right cell holds ${dp[n][cap]}.`,
            why: "Every item was considered once, and each capacity stored its best achievable value.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });
})();
