/* ============================================================
   DSA Visuals — Tree Basics
   Depth, comparison, mirroring, balance and diameter on
   binary trees built from level-order input (token "null"
   marks a gap). Trees whose structure changes between steps
   are re-snapshotted with a deep clone per step so earlier
   steps stay frozen.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, binaryTree } = window.H;
  const V = window.VIZ;

  /* ---------------- shared helpers ---------------- */

  /* one input token -> node value: "null" (any case) -> gap,
     numeric tokens -> numbers, anything else kept as text */
  function toVal(t) {
    if (t == null) return null;
    const s = String(t).trim();
    if (!s || s.toLowerCase() === "null" || s === "-") return null;
    const n = Number(s);
    return Number.isFinite(n) ? n : s;
  }
  function toVals(tokens) {
    return (tokens || []).map(toVal);
  }
  /* one side of a "tree1 | tree2" string, tokenized here */
  function sideVals(text) {
    return String(text || "").split(/[\s,;]+/).filter(Boolean).map(toVal);
  }
  /* deep copy keeping the original ids stable across steps */
  function cloneTree(n) {
    return n ? { id: n.id, v: n.v, l: cloneTree(n.l), r: cloneTree(n.r) } : null;
  }
  /* nodes in breadth-first (level) order */
  function bfsList(root) {
    const out = [];
    for (const q = root ? [root] : []; q.length;) {
      const n = q.shift();
      out.push(n);
      if (n.l) q.push(n.l);
      if (n.r) q.push(n.r);
    }
    return out;
  }
  /* nodes in post-order (children before parent) */
  function postList(root) {
    const out = [];
    (function walk(n) {
      if (!n) return;
      walk(n.l);
      walk(n.r);
      out.push(n);
    })(root);
    return out;
  }
  /* Map node -> height (1 for a leaf, 0 for null) via one post-order pass */
  function heightsOf(root) {
    const h = new Map();
    (function walk(n) {
      if (!n) return 0;
      const a = walk(n.l), b = walk(n.r);
      const v = 1 + Math.max(a, b);
      h.set(n, v);
      return v;
    })(root);
    return h;
  }
  /* "measured: 9 → 1, 15 → 1" style label from a node -> number map */
  function mapLabel(m, prefix) {
    if (!m.size) return prefix + "none yet";
    return prefix + [...m].map(([nd, v]) => nd.v + " → " + v).join(", ");
  }
  /* friendly single step when the input builds no tree at all */
  function emptyTreeSteps(title, happened, why, answer) {
    return [{
      title,
      kind: "cells",
      tracks: [{ label: "tree", cells: [{ v: "∅", state: "idle", empty: true }] }],
      counters: [count("nodes in tree", 0), count("answer", answer)],
      legend: ["read", "done", "result", "idle"],
      happened,
      why,
    }];
  }
  /* cells track for one tree; falls back to an empty cell */
  function sideTrack(label, list, states, tags) {
    if (!list.length)
      return { label, cells: [{ v: "∅", state: "idle", empty: true }] };
    return track(label, list.map((n) => n.v), states, tags);
  }

  /* ============================================================
     1. Maximum Depth of Binary Tree
     ============================================================ */
  V.register({
    id: "maximum-depth-of-binary-tree",
    title: "Maximum Depth of Binary Tree",
    category: "Trees",
    difficulty: "Beginner",
    description: "The number of levels from the root down to the deepest leaf, measured two ways.",
    input: { label: "Tree (level order, null = gap)", default: "3, 9, 20, null, null, 15, 7", parse: "tokens" },
    approaches: [
      {
        name: "Recursive Depth Count",
        complexity: "O(n) time, O(h) stack space",
        idea: [
          "Ask every subtree the same question: how tall am I? A missing node answers 0, a leaf answers 1, and any other node answers one more than its taller child.",
          "The answers bubble up from the leaves. When the root finally replies, its number is the maximum depth of the whole tree.",
        ],
        problem: [
          "The call stack grows as deep as the tree: a chain-shaped tree of n nodes makes n nested calls, so the recursion itself can be the thing that overflows on very deep input.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };

/* height of a subtree: 0 when null, else 1 + taller side */
int max_depth(struct node *n) {
    if (n == NULL) return 0;
    int lh = max_depth(n->l);
    int rh = max_depth(n->r);
    return 1 + (lh > rh ? lh : rh);
}

int main(void) {
    struct node n4 = {15, NULL, NULL}, n5 = {7, NULL, NULL};
    struct node n3 = {20, &n4, &n5}, n2 = {9, NULL, NULL};
    struct node root = {3, &n2, &n3};
    printf("%d\\n", max_depth(&root)); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <algorithm>

struct Node { int v; Node *l = nullptr; Node *r = nullptr; };

// subtree height: 0 for null, else one plus the taller side
int maxDepth(Node* n) {
    if (!n) return 0;
    int lh = maxDepth(n->l);
    int rh = maxDepth(n->r);
    return 1 + std::max(lh, rh);
}

int main() {
    Node n4{15}, n5{7}, n3{20}, n2{9};
    n3.l = &n4; n3.r = &n5;          // 20 with children 15 and 7
    Node root{3}; root.l = &n2; root.r = &n3;
    std::cout << maxDepth(&root) << '\\n'; // 3
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root)
            return emptyTreeSteps(
              "Empty tree — depth 0",
              "There is no root node, so the walk never starts.",
              "The null check at the top of the function answers 0 straight away: an empty tree has no levels at all.",
              0);
          const total = bfsList(root).length;
          const steps = [];
          let visited = 0, maxSoFar = 0;
          const stack = [];      // node ids waiting in the call stack
          const known = new Set(); // node ids whose height is already reported
          const heights = new Map(); // node -> reported height
          const stateMap = (current) => {
            const m = {};
            known.forEach((id) => { m[id] = "done"; });
            stack.forEach((id) => { if (m[id] == null) m[id] = "active"; });
            if (current) m[current.id] = "read";
            return m;
          };
          const countersNow = (depth) => [
            count("current depth", depth),
            count("max so far", maxSoFar),
            count("nodes visited", visited, total),
          ];
          steps.push({
            title: "The tree and an empty call stack",
            kind: "tree", tree: root, nodeStates: {},
            label: "no heights measured yet",
            counters: [count("current depth", 0), count("max so far", 0), count("nodes visited", 0, total)],
            legend: ["read", "active", "done", "result", "idle"],
            happened: `Root ${root.v} waits at depth 0. The height of every subtree is still unknown.`,
            why: "Depth-first search dives to the leaves first — a node's height is only knowable once both of its children have reported back.",
            codeLine: 6,
          });
          function dfs(node, depth) {
            stack.push(node.id);
            visited++;
            if (!node.l && !node.r) {
              heights.set(node, 1);
              known.add(node.id);
              maxSoFar = Math.max(maxSoFar, 1);
              steps.push({
                title: `Leaf ${node.v} at depth ${depth} → height 1`,
                kind: "tree", tree: root, nodeStates: stateMap(node),
                label: mapLabel(heights, "heights known: "),
                counters: countersNow(depth),
                legend: ["read", "active", "done", "result", "idle"],
                happened: `${node.v} has no children, so its subtree is just itself — height 1. The frame pops and hands 1 back to the parent.`,
                why: "The base case turns a leaf into a number the parent can weigh against its other child.",
                codeLine: 7,
              });
              stack.pop();
              return 1;
            }
            steps.push({
              title: `Descend into ${node.v} at depth ${depth}`,
              kind: "tree", tree: root, nodeStates: stateMap(node),
              label: mapLabel(heights, "heights known: "),
              counters: countersNow(depth),
              legend: ["read", "active", "done", "result", "idle"],
              happened: `Node ${node.v} joins the call stack and the walk dives ${node.l ? "left" : "right"} first. Its own height waits on the children.`,
              why: "Every frame remembers its own node — that is exactly what makes the walk depth-first rather than level-by-level.",
              codeLine: node.l ? 8 : 9,
            });
            let lh = 0, rh = 0;
            if (node.l) lh = dfs(node.l, depth + 1);
            if (node.r) rh = dfs(node.r, depth + 1);
            const h = 1 + Math.max(lh, rh);
            heights.set(node, h);
            known.add(node.id);
            maxSoFar = Math.max(maxSoFar, h);
            steps.push({
              title: `${node.v} returns height ${h} (children ${lh} and ${rh})`,
              kind: "tree", tree: root, nodeStates: stateMap(node),
              label: mapLabel(heights, "heights known: "),
              counters: countersNow(depth),
              legend: ["read", "active", "done", "result", "idle"],
              happened: `Both children have reported: max(${lh}, ${rh}) + 1 = ${h}. The frame for ${node.v} pops back to its parent.`,
              why: "Only the taller side decides — the shallower child can never stretch the depth.",
              codeLine: 10,
            });
            stack.pop();
            return h;
          }
          const answer = dfs(root, 0);
          const finalStates = {};
          bfsList(root).forEach((nd) => { finalStates[nd.id] = nd === root ? "result" : "done"; });
          steps.push({
            title: `Answer: ${answer} — the depth of the whole tree`,
            kind: "tree", tree: root, nodeStates: finalStates,
            label: mapLabel(heights, "heights known: "),
            counters: [count("current depth", 0), count("max so far", maxSoFar), count("answer", answer)],
            legend: ["read", "active", "done", "result", "idle"],
            happened: `The root reports ${answer}: the deepest leaf sits ${answer} levels below it, and every node was visited exactly once on the way.`,
            why: "Because each subtree answered for itself, the root's single number already summarises the tallest branch anywhere in the tree.",
            codeLine: 17,
          });
          return steps;
        },
      },
      {
        name: "Level-Order Level Count",
        complexity: "O(n) time, O(w) queue space",
        idea: [
          "Walk the tree level by level with a queue. At any moment everything sitting in the queue belongs to exactly one level.",
          "Drain one whole level, bump a depth counter, refill the queue with the next level's nodes — the counter after the last drain is the answer.",
        ],
        problem: [
          "The queue can hold an entire level at once — up to n/2 nodes on the widest level — so the extra memory follows the tree's width instead of its depth.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };

/* one while-loop round drains exactly one level of the tree */
int depth_by_levels(struct node *root) {
    if (root == NULL) return 0;
    struct node *q[64];
    int head = 0, tail = 0, depth = 0;
    q[tail++] = root;
    while (head < tail) {
        int level_end = tail;   /* everything queued is one level */
        for (; head < level_end; head++) {
            if (q[head]->l) q[tail++] = q[head]->l;
            if (q[head]->r) q[tail++] = q[head]->r;
        }
        depth++;                /* level fully drained */
    }
    return depth;
}

int main(void) {
    struct node n4 = {15, NULL, NULL}, n5 = {7, NULL, NULL};
    struct node n3 = {20, &n4, &n5}, n2 = {9, NULL, NULL};
    struct node root = {3, &n2, &n3};
    printf("%d\\n", depth_by_levels(&root)); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <queue>

struct Node { int v; Node *l = nullptr; Node *r = nullptr; };

// one full drain of the queue per level, so count the drains
int depthByLevels(Node* root) {
    if (!root) return 0;
    std::queue<Node*> q;
    q.push(root);
    int depth = 0;
    while (!q.empty()) {
        int levelSize = (int)q.size();   // everything queued is one level
        while (levelSize--) {
            Node* n = q.front(); q.pop();
            if (n->l) q.push(n->l);
            if (n->r) q.push(n->r);
        }
        ++depth;                         // level fully drained
    }
    return depth;
}

int main() {
    Node n4{15}, n5{7}, n3{20}, n2{9};
    n3.l = &n4; n3.r = &n5;
    Node root{3}; root.l = &n2; root.r = &n3;
    std::cout << depthByLevels(&root) << '\\n'; // 3
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root)
            return emptyTreeSteps(
              "Empty tree — depth 0",
              "There is no root node, so the queue never fills up.",
              "With nothing to enqueue the level loop never runs and the counter stays at 0.",
              0);
          const total = bfsList(root).length;
          const levels = [];
          let cur = [root];
          while (cur.length) {
            levels.push(cur);
            const next = [];
            cur.forEach((nd) => { if (nd.l) next.push(nd.l); if (nd.r) next.push(nd.r); });
            cur = next;
          }
          const steps = [];
          let seen = 0;
          const statesFor = (d) => {
            const m = {};
            levels.forEach((lv, k) => lv.forEach((nd) => {
              m[nd.id] = k < d ? "done" : k === d ? "read" : "idle";
            }));
            return m;
          };
          steps.push({
            title: "Queue primed with the root",
            kind: "tree", tree: root, nodeStates: {},
            label: "the queue holds the root only",
            counters: [count("current depth", 0), count("max so far", 0), count("nodes seen", 0, total)],
            legend: ["read", "done", "result", "idle"],
            happened: `One node (${root.v}) sits in the queue; everything else is still unvisited. The depth counter starts at 0.`,
            why: "The queue is what turns a tangled tree into tidy rows — draining it one row at a time makes 'how many rows?' a simple tally.",
            codeLine: 9,
          });
          levels.forEach((lv, d) => {
            seen += lv.length;
            const nextLvl = levels[d + 1];
            steps.push({
              title: `Level ${d + 1}: ${lv.map((n) => n.v).join(", ")} → depth ${d + 1}`,
              kind: "tree", tree: root, nodeStates: statesFor(d),
              label: nextLvl ? "queue next holds: " + nextLvl.map((n) => n.v).join(", ") : "queue will empty after this level",
              counters: [count("current depth", d + 1), count("max so far", d + 1), count("nodes seen", seen, total)],
              legend: ["read", "done", "result", "idle"],
              happened: `The whole of level ${d + 1} is drained in one go; its children (if any) were queued for the next round.`,
              why: "One drain per level means the counter ticks exactly once per level — no recursion needed.",
              codeLine: 13,
            });
          });
          const answer = levels.length;
          const finalStates = {};
          bfsList(root).forEach((nd) => { finalStates[nd.id] = nd === root ? "result" : "done"; });
          steps.push({
            title: `Answer: ${answer} levels`,
            kind: "tree", tree: root, nodeStates: finalStates,
            label: `${answer} levels drained, ${total} nodes seen`,
            counters: [count("current depth", answer), count("max so far", answer), count("answer", answer)],
            legend: ["read", "done", "result", "idle"],
            happened: `The queue finally emptied after ${answer} drains — the tree is ${answer} levels deep.`,
            why: "Every node passed through the queue exactly once, so both the count and the work are linear in the number of nodes.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     2. Same Tree
     ============================================================ */
  V.register({
    id: "same-tree",
    title: "Same Tree",
    category: "Trees",
    difficulty: "Beginner",
    description: "Check whether two trees hold the same values in the same shape.",
    input: { label: "Tree 1 | Tree 2 (level order)", default: "1, 2, 3 | 1, 2, 3", parse: "string" },
    approaches: [
      {
        name: "Paired Recursive Compare",
        complexity: "O(n) time, O(h) stack space",
        idea: [
          "Stand one node from each tree side by side and ask three questions: are they both missing, do their values match, and do their children pair up the same way?",
          "The walk pairs left with left and right with right; one mismatch anywhere settles the verdict for both whole trees.",
        ],
        problem: [
          "Shape matters as much as values — a child that exists on one side but not the other is already a difference, even when the values could be rearranged to look alike.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

struct node { int v; struct node *l, *r; };

/* true when both are empty, or equal values with equal subtrees */
bool same_tree(struct node *a, struct node *b) {
    if (a == NULL && b == NULL) return true;
    if (a == NULL || b == NULL) return false;  /* one side ran out */
    if (a->v != b->v) return false;            /* values differ here */
    return same_tree(a->l, b->l) && same_tree(a->r, b->r);
}

int main(void) {
    struct node a1 = {2, NULL, NULL}, b1 = {3, NULL, NULL};
    struct node a2 = {2, NULL, NULL}, b2 = {3, NULL, NULL};
    struct node r1 = {1, &a1, &b1}, r2 = {1, &a2, &b2};
    printf("%s\\n", same_tree(&r1, &r2) ? "same" : "different"); /* same */
    return 0;
}`,
          cpp: `#include <iostream>

struct Node { int v; Node *l = nullptr; Node *r = nullptr; };

// both empty, or equal values and equal subtrees
bool sameTree(Node* a, Node* b) {
    if (!a && !b) return true;
    if (!a || !b) return false;       // one tree ran out early
    if (a->v != b->v) return false;   // values differ right here
    return sameTree(a->l, b->l) && sameTree(a->r, b->r);
}

int main() {
    Node a1{2}, b1{3}, a2{2}, b2{3}, r1{1}, r2{1};
    r1.l = &a1; r1.r = &b1;
    r2.l = &a2; r2.r = &b2;
    std::cout << (sameTree(&r1, &r2) ? "same" : "different") << '\\n';
}`,
        },
        steps(str) {
          const parts = String(str).split("|");
          const A = binaryTree(sideVals(parts[0]));
          const B = binaryTree(sideVals(parts[1]));
          if (!A && !B)
            return emptyTreeSteps(
              "Both trees are empty → same",
              "Neither side has a root, so there is nothing that could differ.",
              "Two missing trees agree on everything: the first base case treats two nulls as a match.",
              "same");
          const listA = bfsList(A), listB = bfsList(B);
          const posA = new Map(listA.map((x, i) => [x, i]));
          const posB = new Map(listB.map((x, i) => [x, i]));
          const checkedA = new Set(), checkedB = new Set();
          const steps = [];
          const sideTracks = (curA, curB, verdict) => {
            const stA = listA.map((_, i) => (checkedA.has(i) ? "done" : "idle"));
            const stB = listB.map((_, i) => (checkedB.has(i) ? "done" : "idle"));
            const tgA = listA.map(() => undefined), tgB = listB.map(() => undefined);
            if (curA != null) { stA[curA] = verdict; tgA[curA] = "T1"; }
            if (curB != null) { stB[curB] = verdict; tgB[curB] = "T2"; }
            return [
              sideTrack("tree 1 · level order", listA, stA, tgA),
              sideTrack("tree 2 · level order", listB, stB, tgB),
            ];
          };
          steps.push({
            title: "Two trees, paired node by node",
            kind: "cells", tracks: sideTracks(null, null, "compare"),
            counters: [count("pairs checked", 0), count("nodes in tree 1", listA.length), count("nodes in tree 2", listB.length)],
            legend: ["compare", "done", "good", "bad", "idle"],
            happened: `Tree 1 reads ${listA.map((n) => n.v).join(", ") || "∅"}; tree 2 reads ${listB.map((n) => n.v).join(", ") || "∅"}. The comparison starts at the two roots.`,
            why: "Same-tree is a structural promise: values and shape must both agree, so the walk compares matching positions in lockstep.",
            codeLine: 7,
          });
          const queue = [[A, B]];
          let pairs = 0;
          while (queue.length) {
            const [a, b] = queue.shift();
            if (!a && !b) continue;
            pairs++;
            const i = a ? posA.get(a) : null, j = b ? posB.get(b) : null;
            let ok = true, note = "";
            if (!a || !b) {
              ok = false;
              note = a ? "tree 2 has nothing here" : "tree 1 has nothing here";
            } else if (a.v !== b.v) {
              ok = false;
              note = `${a.v} against ${b.v}`;
            }
            if (!ok) {
              if (i != null) checkedA.add(i);
              if (j != null) checkedB.add(j);
              const stA = listA.map((_, k) => (k === i ? "bad" : "dim"));
              const stB = listB.map((_, k) => (k === j ? "bad" : "dim"));
              steps.push({
                title: `Pair ${pairs}: ${note} ✗ mismatch`,
                kind: "cells",
                tracks: [
                  sideTrack("tree 1 · level order", listA, i != null ? stA : fill(Math.max(1, listA.length), "dim"), i != null ? listA.map((_, k) => (k === i ? "T1" : undefined)) : undefined),
                  sideTrack("tree 2 · level order", listB, j != null ? stB : fill(Math.max(1, listB.length), "dim"), j != null ? listB.map((_, k) => (k === j ? "T2" : undefined)) : undefined),
                ],
                counters: [count("pairs checked", pairs), count("verdict", "different")],
                legend: ["compare", "done", "good", "bad", "idle"],
                happened: `Pair ${pairs} disagrees (${note}), and a single broken pair dooms both trees at once.`,
                why: "The walk can stop here — later pairs cannot repair a mismatch that has already happened.",
                codeLine: !a || !b ? 9 : 10,
              });
              steps.push({
                title: "Answer: different trees",
                kind: "cells",
                tracks: [
                  sideTrack("tree 1 · level order", listA, listA.map((_, k) => (k === i ? "bad" : "dim")), i != null ? listA.map((_, k) => (k === i ? "T1" : undefined)) : undefined),
                  sideTrack("tree 2 · level order", listB, listB.map((_, k) => (k === j ? "bad" : "dim")), j != null ? listB.map((_, k) => (k === j ? "T2" : undefined)) : undefined),
                ],
                counters: [count("pairs checked", pairs), count("answer", "different")],
                legend: ["compare", "done", "good", "bad", "idle"],
                happened: `The two trees are not the same — the disagreement sits at the pair marked in red.`,
                why: "Value or shape, either kind of mismatch is enough: identity requires every pair to agree.",
                codeLine: 10,
              });
              return steps;
            }
            if (i != null) checkedA.add(i);
            if (j != null) checkedB.add(j);
            steps.push({
              title: `Pair ${pairs}: ${a.v} vs ${b.v} ✓`,
              kind: "cells", tracks: sideTracks(i, j, "compare"),
              counters: [count("pairs checked", pairs), count("verdict", "still matching")],
              legend: ["compare", "done", "good", "bad", "idle"],
              happened: `Both trees show ${a.v} at this position, so the pair is recorded as a match and its children join the queue.`,
              why: "Left is compared with left and right with right — wandering off the paired order could fake a match.",
              codeLine: 11,
            });
            if (a.l || b.l) queue.push([a.l, b.l]);
            if (a.r || b.r) queue.push([a.r, b.r]);
          }
          steps.push({
            title: "Answer: same tree",
            kind: "cells",
            tracks: [
              sideTrack("tree 1 · level order", listA, fill(listA.length, "good")),
              sideTrack("tree 2 · level order", listB, fill(listB.length, "good")),
            ],
            counters: [count("pairs checked", pairs), count("answer", "same")],
            legend: ["compare", "done", "good", "bad", "idle"],
            happened: `All ${pairs} pairs agreed on value and shape — the two trees are identical.`,
            why: "Every reachable node took part in exactly one pair, so no hidden difference was skipped.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     3. Invert Binary Tree
     ============================================================ */
  V.register({
    id: "invert-binary-tree",
    title: "Invert Binary Tree",
    category: "Trees",
    difficulty: "Beginner",
    description: "Flip left and right at every node so the tree becomes its own mirror.",
    input: { label: "Tree (level order, null = gap)", default: "3, 9, 20, null, null, 15, 7", parse: "tokens" },
    approaches: [
      {
        name: "Swap On The Way Down",
        complexity: "O(n) time, O(h) stack space",
        idea: [
          "Visit a node, immediately trade its left and right children, then recurse into whichever children now sit on each side.",
          "Because every node swaps exactly once on the way down, each subtree is already mirrored by the time the walk passes through it.",
        ],
        problem: [
          "The recursion still touches every node once, so a chain-shaped tree uses stack space proportional to its length — and the swap must happen before recursing, not after, or the children get double-swapped.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };

/* swap at the node first, then recurse into the swapped children */
void invert(struct node *n) {
    if (n == NULL) return;
    struct node *t = n->l;
    n->l = n->r;
    n->r = t;
    invert(n->l);
    invert(n->r);
}

int main(void) {
    struct node n4 = {15, NULL, NULL}, n5 = {7, NULL, NULL};
    struct node n3 = {20, &n4, &n5}, n2 = {9, NULL, NULL};
    struct node root = {3, &n2, &n3};
    invert(&root);              /* now 3(20(7, 15), 9) */
    printf("%d\\n", root.l->v); /* 20 */
    return 0;
}`,
          cpp: `#include <iostream>

struct Node { int v; Node *l = nullptr; Node *r = nullptr; };

// swap here first, then recurse into the swapped children
void invert(Node* n) {
    if (!n) return;
    std::swap(n->l, n->r);
    invert(n->l);
    invert(n->r);
}

int main() {
    Node n4{15}, n5{7}, n3{20}, n2{9};
    n3.l = &n4; n3.r = &n5;
    Node root{3}; root.l = &n2; root.r = &n3;
    invert(root);
    std::cout << root.l->v << '\\n'; // 20
}`,
        },
        steps(tokens) {
          const values = toVals(tokens);
          const root = binaryTree(values);
          if (!root)
            return emptyTreeSteps(
              "Empty tree — nothing to invert",
              "There is no root node, so the swap visits nothing.",
              "The null check returns immediately: an empty tree is trivially its own mirror.",
              "mirrored");
          const order = bfsList(root); // every node gets a visit, leaves included
          const parents = order.filter((n) => n.l || n.r).length;
          const steps = [];
          const done = new Set();
          const statesFor = (current, mode, kids) => {
            const m = {};
            done.forEach((id) => { m[id] = "done"; });
            if (current) m[current.id] = mode;
            if (kids) kids.forEach((c) => { m[c.id] = "read"; });
            return m;
          };
          let swaps = 0;
          steps.push({
            title: "The tree before any mirroring",
            kind: "tree", tree: cloneTree(root), nodeStates: {},
            label: `${order.length} nodes, ${parents} of them with children to swap`,
            counters: [count("nodes visited", 0, order.length), count("children swapped", 0, parents)],
            legend: ["read", "swap", "done", "result", "idle"],
            happened: `${order.map((n) => n.v).join(", ")} in level order. Every node with two children will have them traded.`,
            why: "A mirror swaps the two sides at each node — visiting every node once guarantees the whole tree flips, not just the top.",
            codeLine: 7,
          });
          order.forEach((n) => {
            if (!n.l && !n.r) {
              done.add(n.id);
              steps.push({
                title: `${n.v} is a leaf — nothing to swap`,
                kind: "tree", tree: cloneTree(root), nodeStates: statesFor(n, "read"),
                label: "leaf — already its own mirror",
                counters: [count("nodes visited", done.size, order.length), count("children swapped", swaps, parents)],
                legend: ["read", "swap", "done", "result", "idle"],
                happened: `Node ${n.v} has no children, so its visit ends without a swap.`,
                why: "Leaves are their own mirror — the walk only has to be sure it reached them.",
                codeLine: 7,
              });
              return;
            }
            const before = [n.l ? n.l.v : "∅", n.r ? n.r.v : "∅"];
            const kids = [n.l, n.r].filter(Boolean);
            [n.l, n.r] = [n.r, n.l];
            swaps++;
            done.add(n.id);
            steps.push({
              title: `${n.v}: swap its children — ${before[0]} ⇄ ${before[1]}`,
              kind: "tree", tree: cloneTree(root), nodeStates: statesFor(n, "swap", kids),
              label: `swap ${swaps} of ${parents}`,
              counters: [count("nodes visited", done.size, order.length), count("children swapped", swaps, parents)],
              legend: ["read", "swap", "done", "result", "idle"],
              happened: `The two children of ${n.v} trade places: the left side is now ${before[1]} and the right side is ${before[0]}.`,
              why: "One temporary pointer per node does the exchange — the subtrees hanging below simply ride along to the other side.",
              codeLine: 8,
            });
          });
          const finalStates = {};
          order.forEach((n) => { finalStates[n.id] = "result"; });
          steps.push({
            title: "Answer: fully inverted",
            kind: "tree", tree: cloneTree(root), nodeStates: finalStates,
            label: "every node mirrored",
            counters: [count("nodes visited", order.length, order.length), count("children swapped", swaps, parents), count("answer", "mirrored")],
            legend: ["read", "swap", "done", "result", "idle"],
            happened: `All ${parents} parent nodes swapped their children — the tree now reads the same from either side.`,
            why: "Each node was touched exactly once, so the mirror is complete rather than half-applied.",
            codeLine: 19,
          });
          return steps;
        },
      },
      {
        name: "Swap On The Way Up",
        complexity: "O(n) time, O(h) stack space",
        idea: [
          "Flip the order: finish both of a node's subtrees first, then swap the node's own children as the last act of the visit.",
          "When the swap finally happens at a node, both sides below are already mirrored — the swap completes that node's slice of the mirror in one move.",
        ],
        problem: [
          "Same work and same stack depth as swapping on the way down; the only difference is timing, which matters when what you do at a node depends on finished subtrees — validating or printing while you go, for instance.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };

/* finish both subtrees before swapping at this node */
void invert(struct node *n) {
    if (n == NULL) return;
    invert(n->l);
    invert(n->r);
    struct node *t = n->l;
    n->l = n->r;
    n->r = t;
}

int main(void) {
    struct node n4 = {15, NULL, NULL}, n5 = {7, NULL, NULL};
    struct node n3 = {20, &n4, &n5}, n2 = {9, NULL, NULL};
    struct node root = {3, &n2, &n3};
    invert(&root);              /* now 3(20(7, 15), 9) */
    printf("%d\\n", root.l->v); /* 20 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <swap>

struct Node { int v; Node *l = nullptr; Node *r = nullptr; };

// children first, then the swap at this node
void invert(Node* n) {
    if (!n) return;
    invert(n->l);
    invert(n->r);
    std::swap(n->l, n->r);
}

int main() {
    Node n4{15}, n5{7}, n3{20}, n2{9};
    n3.l = &n4; n3.r = &n5;
    Node root{3}; root.l = &n2; root.r = &n3;
    invert(root);
    std::cout << root.l->v << '\\n'; // 20
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root)
            return emptyTreeSteps(
              "Empty tree — nothing to invert",
              "There is no root node, so the post-order walk visits nothing.",
              "The null check returns immediately: an empty tree is trivially its own mirror.",
              "mirrored");
          const order = postList(root); // deepest nodes first
          const parents = bfsList(root).filter((n) => n.l || n.r).length;
          const steps = [];
          const done = new Set();
          const statesFor = (current, mode, kids) => {
            const m = {};
            done.forEach((id) => { m[id] = "done"; });
            if (current) m[current.id] = mode;
            if (kids) kids.forEach((c) => { m[c.id] = "read"; });
            return m;
          };
          let swaps = 0;
          steps.push({
            title: "The tree before any mirroring",
            kind: "tree", tree: cloneTree(root), nodeStates: {},
            label: `post-order visit: ${order.map((n) => n.v).join(", ")}`,
            counters: [count("nodes visited", 0, order.length), count("children swapped", 0, parents)],
            legend: ["read", "swap", "done", "result", "idle"],
            happened: `The walk will touch the deepest nodes first and save the root for last. Nothing is swapped yet.`,
            why: "Bottom-up ordering means a node's swap happens only once its whole subtree is finished — handy when later work needs mirrored children.",
            codeLine: 8,
          });
          order.forEach((n) => {
            if (!n.l && !n.r) {
              done.add(n.id);
              steps.push({
                title: `${n.v} is a leaf — nothing to swap`,
                kind: "tree", tree: cloneTree(root), nodeStates: statesFor(n, "read"),
                label: `post-order visit: ${order.map((x) => x.v).join(", ")}`,
                counters: [count("nodes visited", done.size, order.length), count("children swapped", swaps, parents)],
                legend: ["read", "swap", "done", "result", "idle"],
                happened: `Node ${n.v} has no children; its visit ends without a swap and it is already its own mirror.`,
                why: "Base case of the post-order walk: nothing below to finish, nothing here to swap.",
                codeLine: 7,
              });
              return;
            }
            const before = [n.l ? n.l.v : "∅", n.r ? n.r.v : "∅"];
            const kids = [n.l, n.r].filter(Boolean);
            [n.l, n.r] = [n.r, n.l];
            swaps++;
            done.add(n.id);
            steps.push({
              title: `${n.v}: swap its children — ${before[0]} ⇄ ${before[1]}`,
              kind: "tree", tree: cloneTree(root), nodeStates: statesFor(n, "swap", kids),
              label: `subtrees below were already mirrored`,
              counters: [count("nodes visited", done.size, order.length), count("children swapped", swaps, parents)],
              legend: ["read", "swap", "done", "result", "idle"],
              happened: `${n.v}'s children trade places — and because both subtrees were finished first, this single swap finishes ${n.v}'s whole slice of the mirror.`,
              why: "Bottom-up means each swap is the last touch at that node: nothing later has to come back and fix it.",
              codeLine: 10,
            });
          });
          const finalStates = {};
          bfsList(root).forEach((n) => { finalStates[n.id] = "result"; });
          steps.push({
            title: "Answer: fully inverted",
            kind: "tree", tree: cloneTree(root), nodeStates: finalStates,
            label: "every node mirrored",
            counters: [count("nodes visited", order.length, order.length), count("children swapped", swaps, parents), count("answer", "mirrored")],
            legend: ["read", "swap", "done", "result", "idle"],
            happened: `The root was the final swap — with every subtree mirrored below it, the whole tree is now a mirror image of the original.`,
            why: "Same one-swap-per-node work as the top-down version; only the order of operations differed.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     4. Symmetric Tree
     ============================================================ */
  V.register({
    id: "symmetric-tree",
    title: "Symmetric Tree",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Check whether a tree is a mirror image of itself across the middle.",
    input: { label: "Tree (level order, null = gap)", default: "1, 2, 2, 3, 4, 4, 3", parse: "tokens" },
    approaches: [
      {
        name: "Mirrored Pair Walk",
        complexity: "O(n) time, O(h) stack space",
        idea: [
          "Symmetry is a promise about pairs: the left child must mirror the right child. Walk both sides at once, comparing left against right — never left against left.",
          "Each matching pair spawns the next generation of pairs — outer against outer, inner against inner — until the leaves all agree or something breaks.",
        ],
        problem: [
          "One mismatch anywhere dooms the whole check, but reaching that verdict still means walking every mirrored pair that comes before it; a shape mismatch shows up as one side running out of nodes early.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

struct node { int v; struct node *l, *r; };

/* left side must mirror right side, values included */
bool mirror(struct node *a, struct node *b) {
    if (a == NULL && b == NULL) return true;
    if (a == NULL || b == NULL) return false;
    return a->v == b->v && mirror(a->l, b->r) && mirror(a->r, b->l);
}

bool is_symmetric(struct node *root) {
    return root == NULL || mirror(root->l, root->r);
}

int main(void) {
    struct node l2 = {2, NULL, NULL}, r2 = {2, NULL, NULL};
    struct node root = {1, &l2, &r2};
    printf("%s\\n", is_symmetric(&root) ? "symmetric" : "not"); /* symmetric */
    return 0;
}`,
          cpp: `#include <iostream>

struct Node { int v; Node *l = nullptr; Node *r = nullptr; };

// left must mirror right: outer with outer, inner with inner
bool mirror(Node* a, Node* b) {
    if (!a && !b) return true;
    if (!a || !b) return false;      // one side ran out early
    return a->v == b->v && mirror(a->l, b->r) && mirror(a->r, b->l);
}

bool isSymmetric(Node* root) {
    return !root || mirror(root->l, root->r);
}

int main() {
    Node l2{2}, r2{2}, root{1};
    root.l = &l2; root.r = &r2;
    std::cout << (isSymmetric(root) ? "symmetric" : "not") << '\\n';
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root)
            return emptyTreeSteps(
              "Empty tree — symmetric by convention",
              "There is no root node, so there are no two sides to compare.",
              "With both halves missing, nothing can disagree: the base case calls the empty tree symmetric.",
              "symmetric");
          const list = bfsList(root);
          const pos = new Map(list.map((x, i) => [x, i]));
          const checked = new Set();
          const steps = [];
          const tracks = (cur, verdict, extra) => {
            const st = list.map((_, i) => (checked.has(i) ? "done" : "idle"));
            const tg = list.map(() => undefined);
            if (cur && cur[0] != null) { st[pos.get(cur[0])] = verdict; tg[pos.get(cur[0])] = "left"; }
            if (cur && cur[1] != null) { st[pos.get(cur[1])] = verdict; tg[pos.get(cur[1])] = "right"; }
            const out = [sideTrack("tree · level order", list, st, tg)];
            if (extra) out.push(extra);
            return out;
          };
          const pairTrack = (a, b, verdict) => ({
            label: "mirror pair",
            cells: [
              { v: a ? a.v : "∅", state: verdict, tag: "left side", empty: !a },
              { v: b ? b.v : "∅", state: verdict, tag: "right side", empty: !b },
            ],
          });
          if (!root.l && !root.r)
            return [{
              title: "A single node is its own mirror",
              kind: "tree", tree: root, nodeStates: { [root.id]: "result" },
              label: "no pairs to check",
              counters: [count("pairs checked", 0), count("answer", "symmetric")],
              legend: ["compare", "good", "bad", "done", "idle"],
              happened: `The tree holds only the root ${root.v}, so there are no two sides that could disagree.`,
              why: "Zero pairs means zero mismatches — a lone node is symmetric by definition.",
              codeLine: 15,
            }];
          steps.push({
            title: `Start at the two children of ${root.v}`,
            kind: "tree", tree: root,
            nodeStates: Object.assign({}, root.l ? { [root.l.id]: "compare" } : {}, root.r ? { [root.r.id]: "compare" } : {}),
            label: `level order: ${list.map((n) => n.v).join(", ")}`,
            counters: [count("pairs checked", 0), count("nodes in tree", list.length)],
            legend: ["compare", "good", "bad", "done", "idle"],
            happened: `The root compares with itself trivially; the real work is whether ${root.l ? root.l.v : "∅"} mirrors ${root.r ? root.r.v : "∅"}.`,
            why: "Everything below the root is judged as a mirrored pair — left side against right side, generation by generation.",
            codeLine: 15,
          });
          const queue = [[root.l, root.r]];
          let pairs = 0;
          while (queue.length) {
            const [a, b] = queue.shift();
            if (!a && !b) continue;
            pairs++;
            let ok = true, note = "";
            if (!a || !b) {
              ok = false;
              note = "one side has a node where the other has none";
            } else if (a.v !== b.v) {
              ok = false;
              note = `${a.v} against ${b.v}`;
            }
            if (!ok) {
              if (a) checked.add(pos.get(a));
              if (b) checked.add(pos.get(b));
              steps.push({
                title: `Pair ${pairs}: ${note} ✗`,
                kind: "cells", tracks: tracks([a, b], "bad", pairTrack(a, b, "bad")),
                counters: [count("pairs checked", pairs), count("verdict", "not symmetric")],
                legend: ["compare", "good", "bad", "done", "idle"],
                happened: `The mirrored pair ${a ? a.v : "∅"} / ${b ? b.v : "∅"} disagrees, so the two halves of the tree are not reflections.`,
                why: "A single broken pair anywhere breaks the reflection of the whole tree — no later pair can rescue it.",
                codeLine: !a || !b ? 9 : 10,
              });
              const stBad = list.map((n, i) => (checked.has(i) ? "dim" : i === pos.get(a) || i === pos.get(b) ? "bad" : "dim"));
              steps.push({
                title: "Answer: not symmetric",
                kind: "cells", tracks: [sideTrack("tree · level order", list, stBad, list.map((n, i) => (i === pos.get(a) || i === pos.get(b) ? "pair" : undefined)))],
                counters: [count("pairs checked", pairs), count("answer", "not symmetric")],
                legend: ["compare", "good", "bad", "done", "idle"],
                happened: `The tree fails the mirror test at the pair marked in red.`,
                why: "Symmetry demands every mirrored position agree — one exception is a definitive no.",
                codeLine: 10,
              });
              return steps;
            }
            if (a) checked.add(pos.get(a));
            if (b) checked.add(pos.get(b));
            steps.push({
              title: `Pair ${pairs}: ${a.v} mirrors ${b.v} ✓`,
              kind: "cells", tracks: tracks([a, b], "compare", pairTrack(a, b, "good")),
              counters: [count("pairs checked", pairs), count("verdict", "still symmetric")],
              legend: ["compare", "good", "bad", "done", "idle"],
              happened: `Both sides show ${a.v} at mirrored positions, so the reflection holds for this pair so far.`,
              why: "Outer meets outer and inner meets inner — the pairing order is what makes the check a true mirror test.",
              codeLine: 10,
            });
            if (a.l || b.r) queue.push([a.l, b.r]);
            if (a.r || b.l) queue.push([a.r, b.l]);
          }
          steps.push({
            title: "Answer: symmetric",
            kind: "cells", tracks: [sideTrack("tree · level order", list, fill(list.length, "good"))],
            counters: [count("pairs checked", pairs), count("answer", "symmetric")],
            legend: ["compare", "good", "bad", "done", "idle"],
            happened: `All ${pairs} mirrored pairs agreed — the tree reflects perfectly down its middle.`,
            why: "Every mirrored position was checked exactly once, so the whole tree honours the reflection promise.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     5. Balanced Binary Tree
     ============================================================ */
  V.register({
    id: "balanced-binary-tree",
    title: "Balanced Binary Tree",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Every subtree's two child heights must differ by at most one.",
    input: { label: "Tree (level order, null = gap)", default: "3, 9, 20, null, null, 15, 7", parse: "tokens" },
    approaches: [
      {
        name: "Height Check At Every Subtree",
        complexity: "O(n²) time worst case, O(h) stack space",
        idea: [
          "A tree is balanced when every node's left and right subtrees differ in height by no more than one. Measure heights from the bottom up, then apply that rule at each node.",
          "Leaves report height 1; every parent adds one to its taller side and checks the gap between its two answers as it goes.",
        ],
        problem: [
          "Calling a fresh height() at every node re-measures the same subtrees again and again — quadratic work on a long chain. The slicker fix returns the height and a failure sentinel in one pass, trading a magic value for all that recomputation.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

struct node { int v; struct node *l, *r; };

/* height counted in nodes: null is 0, a leaf is 1 */
int height(struct node *n) {
    if (n == NULL) return 0;
    int lh = height(n->l);
    int rh = height(n->r);
    return 1 + (lh > rh ? lh : rh);
}

/* balanced means child heights differ by at most 1, everywhere */
bool balanced(struct node *n) {
    if (n == NULL) return true;
    int d = height(n->l) - height(n->r);
    if (d < 0) d = -d;
    if (d > 1) return false;
    return balanced(n->l) && balanced(n->r);
}

int main(void) {
    struct node n4 = {15, NULL, NULL}, n5 = {7, NULL, NULL};
    struct node n3 = {20, &n4, &n5}, n2 = {9, NULL, NULL};
    struct node root = {3, &n2, &n3};
    printf("%s\\n", balanced(&root) ? "balanced" : "not"); /* balanced */
    return 0;
}`,
          cpp: `#include <iostream>
#include <cstdlib>

struct Node { int v; Node *l = nullptr; Node *r = nullptr; };

// height counted in nodes: 0 for null, 1 for a leaf
int height(Node* n) {
    if (!n) return 0;
    return 1 + std::max(height(n->l), height(n->r));
}

// every node's child heights must differ by at most one
bool balanced(Node* n) {
    if (!n) return true;
    int d = std::abs(height(n->l) - height(n->r));
    if (d > 1) return false;
    return balanced(n->l) && balanced(n->r);
}

int main() {
    Node n4{15}, n5{7}, n3{20}, n2{9};
    n3.l = &n4; n3.r = &n5;
    Node root{3}; root.l = &n2; root.r = &n3;
    std::cout << (balanced(root) ? "balanced" : "not") << '\\n';
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root)
            return emptyTreeSteps(
              "Empty tree — balanced by convention",
              "There is no root node, so there are no subtree heights that could disagree.",
              "The first null check returns true immediately: with no subtrees at all, nothing can be lopsided.",
              "balanced");
          const order = postList(root);
          const total = order.length;
          const heights = new Map();
          const steps = [];
          const measured = new Map(); // node -> height, in measurement order
          let offender = null;
          const stateMap = (current, extra) => {
            const m = {};
            measured.forEach((_, nd) => { m[nd.id] = "result"; });
            if (current) m[current.id] = extra || "read";
            return m;
          };
          steps.push({
            title: "The tree, heights all unknown",
            kind: "tree", tree: root, nodeStates: {},
            label: "measuring from the leaves upward",
            counters: [count("subtrees measured", 0, total), count("balance ok so far", "yes")],
            legend: ["read", "result", "bad", "good", "idle"],
            happened: `${total} nodes wait for their heights. Leaves will answer first, then each parent adds one to its taller side.`,
            why: "Balance is a local promise checked at every node, but keeping the promise needs real heights from below.",
            codeLine: 7,
          });
          order.forEach((n) => {
            const lh = n.l ? heights.get(n.l) : 0;
            const rh = n.r ? heights.get(n.r) : 0;
            const h = 1 + Math.max(lh, rh);
            heights.set(n, h);
            measured.set(n, h);
            const diff = Math.abs(lh - rh);
            const bad = diff > 1;
            if (bad && !offender) offender = n;
            steps.push({
              title: bad
                ? `${n.v}: heights ${lh} and ${rh} differ by ${diff} ✗ imbalance`
                : `${n.v}: heights ${lh} and ${rh} → height ${h}`,
              kind: "tree", tree: root, nodeStates: stateMap(n, bad ? "bad" : "read"),
              label: mapLabel(measured, "heights known: "),
              counters: [count("subtrees measured", measured.size, total), count(`height of ${n.v}`, h), count("balance ok so far", offender ? "no" : "yes")],
              legend: ["read", "result", "bad", "good", "idle"],
              happened: bad
                ? `Node ${n.v} wants sides of ${lh} and ${rh} — a gap of ${diff} is more than the allowed one, so this subtree is lopsided.`
                : `Node ${n.v} measures its children at ${lh} and ${rh}, adds one to the taller side, and reports height ${h}. The gap of ${diff} is within the allowed one.`,
              why: bad
                ? "One lopsided node anywhere means the whole tree fails the balance rule, no matter how tidy the rest looks."
                : "The gap check runs at every node as its height arrives — a rule this local is cheap to verify bottom-up.",
              codeLine: bad ? 19 : 10,
            });
          });
          const finalStates = {};
          bfsList(root).forEach((nd) => {
            finalStates[nd.id] = offender ? (nd === offender ? "bad" : "dim") : "good";
          });
          steps.push({
            title: offender ? `Answer: not balanced — ${offender.v} is lopsided` : "Answer: balanced",
            kind: "tree", tree: root, nodeStates: finalStates,
            label: mapLabel(measured, "heights known: "),
            counters: [count("subtrees measured", total, total), count("answer", offender ? "not balanced" : "balanced")],
            legend: ["read", "result", "bad", "good", "idle"],
            happened: offender
              ? `Every subtree reported, and ${offender.v} showed child heights differing by more than one — that single violation decides the verdict.`
              : `All ${total} subtrees showed a child-height gap of at most one, so the tree is balanced top to bottom.`,
            why: offender
              ? "Balance is judged node by node; one failing node is a definitive no for the entire tree."
              : "Because every node was checked — not just the root — no hidden lopsided subtree can be hiding lower down.",
            codeLine: offender ? 20 : 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     6. Diameter of Binary Tree
     ============================================================ */
  V.register({
    id: "diameter-of-binary-tree",
    title: "Diameter of Binary Tree",
    category: "Trees",
    difficulty: "Intermediate",
    description: "The longest path between any two nodes, counted in edges.",
    input: { label: "Tree (level order, null = gap)", default: "1, 2, null, 3, 4, null, null, 5, 6, 7, 8", parse: "tokens" },
    approaches: [
      {
        name: "Heights In, Best Path Out",
        complexity: "O(n) time, O(h) stack space",
        idea: [
          "The longest path anywhere bends at exactly one node — it drops down through that node's left subtree and its right subtree. So the best candidate through a node is (left height) + (right height) edges.",
          "Compute each subtree's height once on the way back up, keep the biggest candidate seen anywhere, and that global best is the diameter.",
        ],
        problem: [
          "The best path through the root is not always the diameter — here the root offers only 3 edges while a path bending at node 2 stretches to 4 — which is why every node gets a candidate checked, not just the top.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };

static int best;   /* longest bending path so far, in edges */

/* returns the subtree height; records the path bending here */
int depth(struct node *n) {
    if (n == NULL) return 0;
    int lh = depth(n->l);
    int rh = depth(n->r);
    if (lh + rh > best) best = lh + rh;
    return 1 + (lh > rh ? lh : rh);
}

int diameter(struct node *root) {
    best = 0;
    depth(root);
    return best;
}

int main(void) {
    struct node n7 = {5, NULL, NULL}, n8 = {6, NULL, NULL};
    struct node l = {3, &n7, &n8}, r = {4, NULL, NULL};
    struct node n2 = {2, &l, &r}, n9 = {1, NULL, NULL};
    struct node root = {10, &n2, &n9};
    printf("%d\\n", diameter(&root)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <algorithm>

struct Node { int v; Node *l = nullptr; Node *r = nullptr; };

int best;   // longest bending path so far, in edges

// returns height; records the path bending at this node
int depth(Node* n) {
    if (!n) return 0;
    int lh = depth(n->l);
    int rh = depth(n->r);
    best = std::max(best, lh + rh);   // path that bends here
    return 1 + std::max(lh, rh);
}

int diameter(Node* root) {
    best = 0;
    depth(root);
    return best;
}

int main() {
    Node n7{5}, n8{6}, l{3}, r{4}, n2{2}, n9{1}, root{10};
    l.l = &n7; l.r = &n8; n2.l = &l; n2.r = &r;
    root.l = &n2; root.r = &n9;
    std::cout << diameter(&root) << '\\n'; // 4
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root)
            return emptyTreeSteps(
              "Empty tree — diameter 0",
              "There is no root node, so there is no path to measure.",
              "A path needs at least one node to stand on; with none, the longest path holds zero edges.",
              0);
          const order = postList(root);
          const total = order.length;
          const heights = new Map();
          const measured = new Map();
          const steps = [];
          let best = 0, bestNode = null;
          const stateMap = (current) => {
            const m = {};
            measured.forEach((_, nd) => { m[nd.id] = "done"; });
            if (bestNode) m[bestNode.id] = "result";
            if (current) m[current.id] = "read";
            return m;
          };
          steps.push({
            title: "The tree, paths all unmeasured",
            kind: "tree", tree: root, nodeStates: {},
            label: "post-order: height first, then the path bending here",
            counters: [count("nodes processed", 0, total), count("longest path so far", 0)],
            legend: ["read", "done", "result", "good", "idle"],
            happened: `${total} nodes wait. Each will report a height upward and offer one candidate path: down its left side plus down its right.`,
            why: "Every candidate path bends at exactly one node, so collecting one candidate per node catches the winner wherever it lives.",
            codeLine: 8,
          });
          order.forEach((n) => {
            const lh = n.l ? heights.get(n.l) : 0;
            const rh = n.r ? heights.get(n.r) : 0;
            const h = 1 + Math.max(lh, rh);
            heights.set(n, h);
            measured.set(n, h);
            const through = lh + rh;
            const improved = through > best;
            if (improved) { best = through; bestNode = n; }
            steps.push({
              title: improved
                ? `${n.v}: through = ${lh} + ${rh} = ${through} edges — new best`
                : `${n.v}: through = ${lh} + ${rh} = ${through} edges, best stays ${best}`,
              kind: "tree", tree: root, nodeStates: stateMap(n),
              label: mapLabel(measured, "heights known: "),
              counters: [count("nodes processed", measured.size, total), count(`height of ${n.v}`, h), count("longest path so far", best)],
              legend: ["read", "done", "result", "good", "idle"],
              happened: improved
                ? `A path bending at ${n.v} runs ${lh} edges down one side and ${rh} down the other — ${through} edges in total, the longest seen so far.`
                : `The path bending at ${n.v} would run ${through} edges — not enough to beat ${best}. Its height of ${h} still helps its parent.`,
              why: improved
                ? "The bend point is where the two directions meet — heights turn 'longest drop on each side' into one addition."
                : "Most candidates lose, but each node's height still feeds its parent, so the losing check is never wasted work.",
              codeLine: improved ? 12 : 12,
            });
          });
          const finalStates = {};
          bfsList(root).forEach((nd) => { finalStates[nd.id] = nd === bestNode ? "result" : "good"; });
          steps.push({
            title: `Answer: ${best} edges`,
            kind: "tree", tree: root, nodeStates: finalStates,
            label: bestNode ? `best path bends at ${bestNode.v}` : "no bending path needed",
            counters: [count("nodes processed", total, total), count("longest path so far", best), count("answer", best)],
            legend: ["read", "done", "result", "good", "idle"],
            happened: bestNode
              ? `The winning path bends at node ${bestNode.v} and runs ${best} edges — longer than anything the root itself offered.`
              : `Every node offered a candidate; the best is ${best} edges.`,
            why: "One upward pass computed every height and every candidate exactly once — the diameter fell out as a by-product of measuring.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });
})();
