/* ============================================================
   DSA Visuals — Strings & Text II
   Parsing and encoding: palindromes, nested brackets, digit
   multiplication, versions, integers and Roman numerals.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const chars = (text) => Array.from(String(text || ""));
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const isWindow = (i, lo, hi) => i >= lo && i < hi;

  /* ---------------------------------------------------------- */
  V.register({
    id: "palindromic-substrings",
    title: "Palindromic Substrings",
    category: "Strings & Text",
    difficulty: "Intermediate",
    description:
      "Count every palindromic piece by expanding around each of the 2n − 1 centres.",
    input: { label: "text", default: "aaa", parse: "chars" },
    approaches: [
      {
        name: "Count Expansions",
        complexity: "O(n²) time, O(1) space",
        idea: [
          "Each centre produces a run of palindromes: every successful expansion adds one more.",
          "Odd centres sit on characters and even centres sit between characters, so 2n − 1 centres cover every possible palindrome.",
        ],
        problem: [
          "Every centre expands over the same characters again, so repetitive text costs quadratic time.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint count_around(const char *s, int lo, int hi) {\n    int found = 0;\n    while (lo >= 0 && s[hi] && s[lo] == s[hi]) { found++; lo--; hi++; }\n    return found;\n}\n\nint count_palindromes(const char *s, int n) {\n    int total = 0;\n    for (int i = 0; i < n; i++)\n        total += count_around(s, i, i) + count_around(s, i, i + 1);\n    return total;\n}\n\nint main(void) {\n    printf("%d\\\\n", count_palindromes("aaa", 3)); /* 6 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\nusing namespace std;\n\nint around(const string& s, int lo, int hi) {\n    int found = 0;\n    while (lo >= 0 && hi < (int)s.size() && s[lo] == s[hi]) { found++; lo--; hi++; }\n    return found;\n}\n\nint countSubstrings(const string& s) {\n    int total = 0;\n    for (int i = 0; i < (int)s.size(); i++)\n        total += around(s, i, i) + around(s, i, i + 1);\n    return total;\n}\n\nint main() {\n    cout << countSubstrings("aaa") << '\\\\n'; // 6\n}`,
        },
        steps(text) {
          const s = chars(text);
          if (!s.length) {
            return [{
              title: "Give some text",
              tracks: [chips("text", ["—"], "idle")],
              counters: [count("palindromes", 0)],
              legend: ["idle", "result"],
              happened: "An empty text has no palindromes.",
              why: "Each character alone is a palindrome, so the count starts from the centres.",
            }];
          }
          const steps = [];
          let total = 0;
          steps.push({
            title: `${s.length} characters → ${2 * s.length - 1} centres`,
            tracks: [track("text", s, fill(s.length, "idle"))],
            counters: [count("centres left", 2 * s.length - 1), count("palindromes", 0)],
            legend: LEG,
            happened: `The text is "${s.join("")}".`,
            why: "Every palindrome grows out of exactly one centre.",
            codeLine: 9,
          });
          for (let i = 0; i < s.length; i++) {
            for (const even of [false, true]) {
              if (even && i + 1 >= s.length) continue;
              let lo = i, hi = even ? i + 1 : i, found = 0;
              const runs = [];
              while (lo >= 0 && hi < s.length && s[lo] === s[hi]) {
                found++;
                runs.push(`"${s.slice(lo, hi + 1).join("")}"`);
                total++;
                lo--; hi++;
              }
              steps.push({
                title: `${even ? "Even" : "Odd"} centre ${i}${even ? "," + (i + 1) : ""}: ${found} palindrome${found === 1 ? "" : "s"}`,
                tracks: [
                  track("text", s, s.map((_, k) => (k === i || k === lo + 1 || k >= hi && k < hi + 1 ? "read" : isWindow(k, lo + 1, hi) ? "done" : "dim"))),
                  chips("found here", found ? runs : ["none"], found ? "good" : "bad"),
                ],
                counters: [count("centre", i), count("palindromes", total)],
                legend: LEG,
                happened: found ? `${runs.join(", ")} all read the same forwards and backwards.` : "The two sides differ immediately, so no palindrome starts here.",
                why: "Each successful expansion adds exactly one palindrome to the count.",
                codeLine: 3,
              });
            }
          }
          steps.push({
            title: `Answer: ${total} palindromic substring${total === 1 ? "" : "s"}`,
            tracks: [track("text", s, fill(s.length, "done")), chips("answer", [total], "result")],
            counters: [count("centres checked", 2 * s.length - 1), count("answer", total)],
            legend: LEG,
            happened: `Expanding from every centre found ${total} palindromes.`,
            why: "No palindrome is counted twice because each has a unique centre.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "decode-string",
    title: "Decode String",
    category: "Strings & Text",
    difficulty: "Intermediate",
    description:
      "Expand an encoded text such as 3[a2[c]] using a stack of counts and prefixes.",
    input: { label: "encoded text", default: "3[a2[c]]", parse: "string" },
    approaches: [
      {
        name: "Stack of Prefixes and Counts",
        complexity: "O(output length) time, O(nesting) space",
        idea: [
          "Digits build a repeat count. On '[' push the count and the text built so far, then start a fresh piece.",
          "On ']' pop the prefix and count, and append the finished piece repeated that many times.",
        ],
        problem: [
          "The output can be exponentially longer than the input, so both time and memory are measured in decoded size.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n#include <stdlib.h>\n\nchar *decode(const char *s) {\n    char *prefix[64], *out = calloc(1, 1);\n    int repeat[64], depth = 0, len = 0;\n\n    for (int i = 0; s[i]; ) {\n        if (s[i] >= '0' && s[i] <= '9') {\n            int n = 0;\n            while (s[i] >= '0' && s[i] <= '9') n = n * 10 + (s[i++] - '0');\n            prefix[depth] = out;\n            repeat[depth] = n;\n            depth++;\n            out = calloc(1, 1);\n            len = 0;\n        } else if (s[i] == '[') {\n            i++;\n        } else if (s[i] == ']') {\n            depth--;\n            char *inner = out;\n            int copies = repeat[depth];\n            char *joined = calloc(strlen(prefix[depth]) + strlen(inner) * copies + 1, 1);\n            strcpy(joined, prefix[depth]);\n            for (int k = 0; k < copies; k++) strcat(joined, inner);\n            free(prefix[depth]);\n            free(inner);\n            out = joined;\n            i++;\n        } else {\n            int n = strlen(out);\n            out = realloc(out, n + 2);\n            out[n] = s[i++];\n            out[n + 1] = 0;\n        }\n    }\n    return out;\n}\n\nint main(void) {\n    printf("%s\\\\n", decode("3[a2[c]]")); /* accaccacc */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\n#include <stack>\nusing namespace std;\n\nstring decodeString(const string& s) {\n    stack<int> counts;\n    stack<string> prefixes;\n    string out;\n    int number = 0;\n\n    for (char c : s) {\n        if (isdigit(c)) number = number * 10 + (c - '0');\n        else if (c == '[') {\n            counts.push(number);\n            prefixes.push(out);\n            number = 0;\n            out.clear();\n        } else if (c == ']') {\n            string piece = out;\n            out = prefixes.top();\n            prefixes.pop();\n            int copies = counts.top();\n            counts.pop();\n            while (copies--) out += piece;\n        } else out += c;\n    }\n    return out;\n}\n\nint main() {\n    cout << decodeString("3[a2[c]]") << '\\\\n'; // accaccacc\n}`,
        },
        steps(text) {
          const s = chars(text);
          if (!s.length) {
            return [{
              title: "Give an encoded text",
              tracks: [chips("encoded", ["—"], "idle")],
              counters: [count("output length", 0)],
              legend: ["idle", "result"],
              happened: "An empty encoding decodes to nothing.",
              why: "Digits set a repeat count; brackets mark where it applies.",
            }];
          }
          const steps = [];
          const counts = [];
          const prefixes = [];
          let out = "";
          let number = 0;
          steps.push({
            title: `Decode "${s.join("")}"`,
            tracks: [track("encoded", s, fill(s.length, "idle")), chips("output", ["—"], "dim")],
            counters: [count("stack depth", 0), count("output length", 0)],
            legend: LEG,
            happened: "The stack will hold the repeat count and the prefix for each open bracket.",
            why: "Nested brackets are exactly the structure a stack handles.",
            codeLine: 7,
          });
          for (let i = 0; i < s.length; i++) {
            const c = s[i];
            if (c >= "0" && c <= "9") {
              number = number * 10 + Number(c);
              steps.push({
                title: `Digit ${c}: repeat count becomes ${number}`,
                tracks: [track("encoded", s, s.map((_, k) => (k === i ? "read" : k < i ? "done" : "idle"))), chips("count", [number], "active")],
                counters: [count("stack depth", counts.length), count("count", number)],
                legend: LEG,
                happened: "Multi-digit counts are built one digit at a time.",
                why: "The count is only used when the matching '[' appears.",
                codeLine: 9,
              });
            } else if (c === "[") {
              counts.push(number);
              prefixes.push(out);
              number = 0;
              out = "";
              steps.push({
                title: `'[' pushes (${counts[counts.length - 1]}, "${prefixes[prefixes.length - 1]}")`,
                tracks: [track("encoded", s, s.map((_, k) => (k === i ? "read" : k < i ? "done" : "idle"))), chips("stack", counts.map((n, k) => `${n}× "${prefixes[k]}"`), "done")],
                counters: [count("stack depth", counts.length), count("output length", out.length)],
                legend: LEG,
                happened: "The outer work is saved and a fresh piece begins.",
                why: "Saving the prefix is what keeps nesting correct.",
                codeLine: 11,
              });
            } else if (c === "]") {
              const piece = out;
              out = prefixes.pop() || "";
              const copies = counts.pop() || 0;
              out += piece.repeat(copies);
              steps.push({
                title: `']' repeats "${piece}" ${copies}× → length ${out.length}`,
                tracks: [track("encoded", s, s.map((_, k) => (k === i ? "read" : k < i ? "done" : "idle"))), chips("stack", counts.length ? counts.map((n, k) => `${n}× "${prefixes[k]}"`) : ["empty"], "dim"), chips("output", out.length <= 12 ? [out] : [`${out.slice(0, 12)}…`], "result")],
                counters: [count("stack depth", counts.length), count("output length", out.length)],
                legend: LEG,
                happened: `The finished piece is appended ${copies} time${copies === 1 ? "" : "s"} to the saved prefix.`,
                why: "Popping restores the outer context exactly where it left off.",
                codeLine: 17,
              });
            } else {
              out += c;
              steps.push({
                title: `Append '${c}' → "${out.length <= 12 ? out : out.slice(0, 12) + "…"}"`,
                tracks: [track("encoded", s, s.map((_, k) => (k === i ? "read" : k < i ? "done" : "idle"))), chips("output", out.length <= 12 ? [out] : [`${out.slice(0, 12)}…`], "active")],
                counters: [count("stack depth", counts.length), count("output length", out.length)],
                legend: LEG,
                happened: "Plain letters are added to the current piece.",
                why: "Text outside brackets needs no repetition logic.",
                codeLine: 22,
              });
            }
          }
          steps.push({
            title: `Answer: "${out}"`,
            tracks: [track("encoded", s, fill(s.length, "done")), chips("answer", [out.length <= 20 ? out : out.slice(0, 20) + "…"], "result")],
            counters: [count("stack depth", 0), count("answer length", out.length)],
            legend: LEG,
            happened: `All brackets were closed, so the decoded text is complete.`,
            why: "The stack is empty exactly when the encoding has no open group left.",
            codeLine: 24,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "multiply-strings",
    title: "Multiply Strings",
    category: "Strings & Text",
    difficulty: "Advanced",
    description:
      "Multiply two digit strings without converting them to integers, using schoolbook long multiplication.",
    input: { label: "number A | number B", default: "123 | 456", parse: "string" },
    approaches: [
      {
        name: "Digit Array Multiplication",
        complexity: "O(n × m) time, O(n + m) space",
        idea: [
          "Digit i of A times digit j of B lands across positions i + j and i + j + 1 of the result.",
          "Accumulate every product into one array, then carry leftwards once at the end.",
        ],
        problem: [
          "Very long inputs make the quadratic digit loop slow, and the intermediate array must handle carries of any size.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nvoid multiply(const char *a, const char *b, char *out) {\n    int n = strlen(a), m = strlen(b);\n    int res[64] = {0};\n\n    for (int i = n - 1; i >= 0; i--)\n        for (int j = m - 1; j >= 0; j--) {\n            int mul = (a[i] - '0') * (b[j] - '0');\n            int p1 = i + j, p2 = i + j + 1;\n            int sum = mul + res[p2];\n            res[p2] = sum % 10;\n            res[p1] += sum / 10;\n        }\n\n    int k = 0, started = 0;\n    for (int i = 0; i < n + m; i++) {\n        if (res[i]) started = 1;\n        if (started) out[k++] = (char)('0' + res[i]);\n    }\n    if (!k) out[k++] = '0';\n    out[k] = 0;\n}\n\nint main(void) {\n    char out[64];\n    multiply("123", "456", out);\n    printf("%s\\\\n", out); /* 56088 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\n#include <vector>\nusing namespace std;\n\nstring multiply(const string& a, const string& b) {\n    if (a == "0" || b == "0") return "0";\n    int n = a.size(), m = b.size();\n    vector<int> res(n + m, 0);\n\n    for (int i = n - 1; i >= 0; i--)\n        for (int j = m - 1; j >= 0; j--) {\n            int mul = (a[i] - '0') * (b[j] - '0');\n            int p1 = i + j, p2 = i + j + 1;\n            int sum = mul + res[p2];\n            res[p2] = sum % 10;\n            res[p1] += sum / 10;\n        }\n\n    string out;\n    for (int d : res) {\n        if (out.empty() && d == 0) continue;\n        out += char('0' + d);\n    }\n    return out.empty() ? "0" : out;\n}\n\nint main() {\n    cout << multiply("123", "456") << '\\\\n'; // 56088\n}`,
        },
        steps(text) {
          const [aRaw, bRaw] = parts(text);
          const a = String(aRaw || "").replace(/\\D/g, "") || "0";
          const b = String(bRaw || "").replace(/\\D/g, "") || "0";
          const A = chars(a), B = chars(b);
          const n = A.length, m = B.length;
          const res = Array(n + m).fill(0);
          const steps = [];
          steps.push({
            title: `${a} × ${b}: ${n + m} result slots`,
            tracks: [
              track("A", A, fill(n, "idle")),
              track("B", B, fill(m, "idle")),
              chips("result digits", res, "dim"),
            ],
            counters: [count("digit pairs", 0, n * m), count("partial value", 0)],
            legend: LEG,
            happened: `Each pair of digits writes into positions i + j and i + j + 1.`,
            why: "The result of an n-digit by m-digit product needs at most n + m digits.",
            codeLine: 6,
          });
          let pairs = 0;
          for (let i = n - 1; i >= 0; i--) {
            for (let j = m - 1; j >= 0; j--) {
              const mul = Number(A[i]) * Number(B[j]);
              const p1 = i + j, p2 = i + j + 1;
              const sum = mul + res[p2];
              res[p2] = sum % 10;
              res[p1] += Math.floor(sum / 10);
              pairs++;
              steps.push({
                title: `${A[i]} × ${B[j]} = ${mul} into slots ${p1},${p2}`,
                tracks: [
                  track("A", A, A.map((_, k) => (k === i ? "read" : k > i ? "done" : "idle"))),
                  track("B", B, B.map((_, k) => (k === j ? "read" : k > j ? "done" : "idle"))),
                  chips("result digits", res, (k) => (k === p1 || k === p2 ? "active" : "dim")),
                ],
                counters: [count("digit pairs", pairs, n * m), count("carry into", Math.floor(sum / 10))],
                legend: LEG,
                happened: `${mul} plus the existing digit makes ${sum}; ${sum % 10} stays and ${Math.floor(sum / 10)} carries left.`,
                why: "Working right to left matches how column multiplication carries.",
                codeLine: 10,
              });
            }
          }
          const out = res.join("").replace(/^0+(?=\\d)/, "");
          steps.push({
            title: `Answer: ${out}`,
            tracks: [
              track("A", A, fill(n, "done")),
              track("B", B, fill(m, "done")),
              chips("answer", [out], "result"),
            ],
            counters: [count("digit pairs", n * m, n * m), count("answer", out)],
            legend: LEG,
            happened: `The accumulated digits read ${out}.`,
            why: "Every product contributed to a fixed pair of slots, so the array already holds the column sums.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "compare-version-numbers",
    title: "Compare Version Numbers",
    category: "Strings & Text",
    difficulty: "Beginner",
    description:
      "Compare dotted version strings segment by segment, treating missing segments as zero.",
    input: { label: "version A | version B", default: "1.01 | 1.001", parse: "string" },
    approaches: [
      {
        name: "Split and Compare",
        complexity: "O(n + m) time, O(n + m) space",
        idea: [
          "Split each version on dots and compare the numeric value of each segment from left to right.",
          "When one version runs out of segments, the missing ones count as zero, so 1.0 equals 1.",
        ],
        problem: [
          "Leading zeroes and very long numeric segments must be parsed carefully; comparing as text would rank \"10\" below \"9\".",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n#include <stdlib.h>\n\nint compare_version(const char *a, const char *b) {\n    int i = 0, j = 0;\n    while (a[i] || b[j]) {\n        long x = 0, y = 0;\n        while (a[i] && a[i] != '.') x = x * 10 + (a[i++] - '0');\n        while (b[j] && b[j] != '.') y = y * 10 + (b[j++] - '0');\n        if (x < y) return -1;\n        if (x > y) return 1;\n        if (a[i] == '.') i++;\n        if (b[j] == '.') j++;\n    }\n    return 0;\n}\n\nint main(void) {\n    printf("%d\\\\n", compare_version("1.01", "1.001")); /* 0 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\n#include <sstream>\n#include <vector>\nusing namespace std;\n\nvector<long long> split(const string& v) {\n    vector<long long> out;\n    stringstream ss(v);\n    string part;\n    while (getline(ss, part, '.')) out.push_back(stoll(part));\n    return out;\n}\n\nint compareVersion(const string& a, const string& b) {\n    auto x = split(a), y = split(b);\n    size_t n = max(x.size(), y.size());\n    for (size_t i = 0; i < n; i++) {\n        long long p = i < x.size() ? x[i] : 0;\n        long long q = i < y.size() ? y[i] : 0;\n        if (p < q) return -1;\n        if (p > q) return 1;\n    }\n    return 0;\n}\n\nint main() {\n    cout << compareVersion("1.01", "1.001") << '\\\\n'; // 0\n}`,
        },
        steps(text) {
          const [a, b] = parts(text);
          const A = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
          const B = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
          const steps = [];
          const width = Math.max(A.length, B.length);
          steps.push({
            title: `Compare ${A.join(".")} with ${B.join(".")}`,
            tracks: [chips("version A", A, "idle"), chips("version B", B, "idle")],
            counters: [count("segments compared", 0, width), count("result", "equal so far")],
            legend: LEG,
            happened: "Numeric segments are compared left to right, so the first difference decides.",
            why: "Missing segments count as zero, which is why trailing .0 does not matter.",
            codeLine: 4,
          });
          let verdict = 0;
          for (let i = 0; i < width; i++) {
            const x = i < A.length ? A[i] : 0;
            const y = i < B.length ? B[i] : 0;
            if (x !== y && verdict === 0) verdict = x < y ? -1 : 1;
            steps.push({
              title: `Segment ${i}: ${x} vs ${y} → ${x === y ? "tie" : x < y ? "A smaller" : "A larger"}`,
              tracks: [
                chips("version A", A, (k) => (k === i ? "read" : k < i ? "done" : "dim")),
                chips("version B", B, (k) => (k === i ? "read" : k < i ? "done" : "dim")),
                chips("missing as zero", [i < A.length ? A[i] : 0, i < B.length ? B[i] : 0], "compare"),
              ],
              counters: [count("segments compared", i + 1, width), count("result", verdict === 0 ? "equal" : verdict < 0 ? "A < B" : "A > B")],
              legend: LEG,
              happened: x === y ? "This segment does not separate the versions." : `The first difference is here, so the answer is fixed.`,
              why: "Version comparison is lexicographic on numeric segments.",
              codeLine: x === y ? 9 : 8,
            });
          }
          steps.push({
            title: verdict === 0 ? "Answer: versions are equal" : verdict < 0 ? "Answer: version A is older" : "Answer: version A is newer",
            tracks: [chips("version A", A, "done"), chips("version B", B, "done"), chips("answer", [verdict], "result")],
            counters: [count("segments compared", width, width), count("answer", verdict)],
            legend: LEG,
            happened: verdict === 0 ? "Every segment matched, including the implied zeroes." : "The first differing segment settled the comparison.",
            why: "No later segment can overturn an earlier difference.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "string-to-integer",
    title: "String to Integer",
    category: "Strings & Text",
    difficulty: "Intermediate",
    description:
      "Parse an integer from text, handling spaces, signs and overflow clamping.",
    input: { label: "text", default: "   -42", parse: "string" },
    approaches: [
      {
        name: "Scan, Sign, Clamp",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Skip leading whitespace, read one optional sign, then consume digits until something else appears.",
          "Accumulate the value while checking the 32-bit limits so overflow clamps instead of wrapping.",
        ],
        problem: [
          "Accumulating into a 32-bit integer overflows before the check can run, so the running value must use a wider type.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <limits.h>\n\nint my_atoi(const char *s) {\n    int i = 0, sign = 1;\n    long value = 0;\n\n    while (s[i] == ' ' || s[i] == '\\\\t') i++;\n    if (s[i] == '+' || s[i] == '-') { if (s[i] == '-') sign = -1; i++; }\n\n    while (s[i] >= '0' && s[i] <= '9') {\n        value = value * 10 + (s[i++] - '0');\n        if (sign * value > INT_MAX) return INT_MAX;\n        if (sign * value < INT_MIN) return INT_MIN;\n    }\n    return (int)(sign * value);\n}\n\nint main(void) {\n    printf("%d\\\\n", my_atoi("   -42")); /* -42 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\n#include <climits>\nusing namespace std;\n\nint myAtoi(const string& s) {\n    int i = 0, sign = 1;\n    long long value = 0;\n    while (i < (int)s.size() && s[i] == ' ') i++;\n    if (i < (int)s.size() && (s[i] == '+' || s[i] == '-')) {\n        if (s[i] == '-') sign = -1;\n        i++;\n    }\n    while (i < (int)s.size() && isdigit(s[i])) {\n        value = value * 10 + (s[i++] - '0');\n        if (sign * value > INT_MAX) return INT_MAX;\n        if (sign * value < INT_MIN) return INT_MIN;\n    }\n    return (int)(sign * value);\n}\n\nint main() {\n    cout << myAtoi("   -42") << '\\\\n'; // -42\n}`,
        },
        steps(text) {
          const s = chars(text);
          if (!s.length) {
            return [{
              title: "Give some text",
              tracks: [chips("text", ["—"], "idle")],
              counters: [count("value", 0)],
              legend: ["idle", "result"],
              happened: "Empty text parses as zero.",
              why: "With no digits the value stays at its initial zero.",
            }];
          }
          const steps = [];
          let i = 0, sign = 1, value = 0;
          steps.push({
            title: `Parse "${s.join("")}"`,
            tracks: [track("text", s, fill(s.length, "idle"))],
            counters: [count("sign", "+"), count("value", 0)],
            legend: LEG,
            happened: "Leading spaces, one sign and then digits are allowed; anything else ends the number.",
            why: "The parser has to stop at the first unexpected character rather than fail.",
            codeLine: 5,
          });
          while (i < s.length && (s[i] === " " || s[i] === "\t")) {
            steps.push({
              title: "Skip whitespace",
              tracks: [track("text", s, s.map((_, k) => (k === i ? "dim" : k < i ? "done" : "idle")))],
              counters: [count("index", i), count("value", value)],
              legend: LEG,
              happened: "Spaces before the number are ignored.",
              why: "Only leading whitespace is skipped; spaces later would stop the parse.",
              codeLine: 5,
            });
            i++;
          }
          if (i < s.length && (s[i] === "+" || s[i] === "-")) {
            sign = s[i] === "-" ? -1 : 1;
            steps.push({
              title: `Sign ${s[i]} → ${sign < 0 ? "negative" : "positive"}`,
              tracks: [track("text", s, s.map((_, k) => (k === i ? "read" : k < i ? "done" : "idle")))],
              counters: [count("sign", sign < 0 ? "−" : "+"), count("value", 0)],
              legend: LEG,
              happened: "At most one sign is consumed.",
              why: "The sign applies to every digit that follows.",
              codeLine: 6,
            });
            i++;
          }
          let clamped = false;
          while (i < s.length && s[i] >= "0" && s[i] <= "9") {
            value = value * 10 + Number(s[i]);
            const signed = sign * value;
            if (signed > 2147483647) { value = 2147483647; clamped = true; }
            if (signed < -2147483648) { value = 2147483648; clamped = true; }
            steps.push({
              title: `Digit ${s[i]} → ${sign < 0 ? "-" : ""}${value}${clamped ? " (clamped)" : ""}`,
              tracks: [track("text", s, s.map((_, k) => (k === i ? "read" : k < i ? "done" : "idle"))), chips("value", [sign < 0 ? -value : value], clamped ? "bad" : "active")],
              counters: [count("digits read", i + 1, s.length), count("value", sign < 0 ? -value : value)],
              legend: LEG,
              happened: clamped ? "The value crossed the 32-bit limit, so it is clamped." : "The digit extends the number by one decimal place.",
              why: "Checking after each digit stops the value before it can overflow.",
              codeLine: 10,
            });
            i++;
          }
          const answer = sign * value;
          steps.push({
            title: `Answer: ${answer}`,
            tracks: [track("text", s, fill(s.length, "done")), chips("answer", [answer], "result")],
            counters: [count("digits read", i, s.length), count("answer", answer)],
            legend: LEG,
            happened: "The scan stopped at the first non-digit and applied the sign.",
            why: "Leading zeroes contribute nothing, and clamping keeps the result representable.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "roman-to-integer",
    title: "Roman to Integer",
    category: "Strings & Text",
    difficulty: "Beginner",
    description:
      "Convert a Roman numeral by subtracting a symbol that is smaller than the one after it.",
    input: { label: "numeral", default: "MCMXCIV", parse: "chars" },
    approaches: [
      {
        name: "Compare With the Next Symbol",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Add each symbol's value, except when a smaller symbol sits before a larger one — then subtract it instead.",
          "That single rule covers IV, IX, XL, XC, CD and CM without any special cases.",
        ],
        problem: [
          "The method assumes a valid numeral; malformed input such as IIII still produces a number rather than an error.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint value(char c) {\n    switch (c) {\n        case 'I': return 1;   case 'V': return 5;\n        case 'X': return 10;  case 'L': return 50;\n        case 'C': return 100; case 'D': return 500;\n        case 'M': return 1000;\n        default: return 0;\n    }\n}\n\nint roman_to_int(const char *s) {\n    int total = 0, n = strlen(s);\n    for (int i = 0; i < n; i++) {\n        int v = value(s[i]), next = i + 1 < n ? value(s[i + 1]) : 0;\n        if (v < next) total -= v;\n        else total += v;\n    }\n    return total;\n}\n\nint main(void) {\n    printf("%d\\\\n", roman_to_int("MCMXCIV")); /* 1994 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\nusing namespace std;\n\nint value(char c) {\n    switch (c) {\n        case 'I': return 1;   case 'V': return 5;\n        case 'X': return 10;  case 'L': return 50;\n        case 'C': return 100; case 'D': return 500;\n        case 'M': return 1000;\n        default: return 0;\n    }\n}\n\nint romanToInt(const string& s) {\n    int total = 0;\n    for (int i = 0; i < (int)s.size(); i++) {\n        int v = value(s[i]);\n        int next = i + 1 < (int)s.size() ? value(s[i + 1]) : 0;\n        total += v < next ? -v : v;\n    }\n    return total;\n}\n\nint main() {\n    cout << romanToInt("MCMXCIV") << '\\\\n'; // 1994\n}`,
        },
        steps(text) {
          const s = chars(text).filter((c) => "IVXLCDM".includes(c));
          if (!s.length) {
            return [{
              title: "Give a Roman numeral",
              tracks: [chips("symbols", ["—"], "idle")],
              counters: [count("value", 0)],
              legend: ["idle", "result"],
              happened: "Only I, V, X, L, C, D and M carry values.",
              why: "Each symbol maps to a fixed number.",
            }];
          }
          const value = (c) => ({ I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 }[c] || 0);
          const steps = [];
          let total = 0;
          steps.push({
            title: `Read ${s.join("")} left to right`,
            tracks: [track("symbols", s, fill(s.length, "idle"))],
            counters: [count("value", 0), count("position", 0, s.length)],
            legend: LEG,
            happened: "Normally values add, but a smaller symbol before a larger one subtracts.",
            why: "Subtractive pairs are exactly how Roman numerals avoid four repeats.",
            codeLine: 13,
          });
          for (let i = 0; i < s.length; i++) {
            const v = value(s[i]);
            const next = i + 1 < s.length ? value(s[i + 1]) : 0;
            const subtract = v < next;
            total += subtract ? -v : v;
            steps.push({
              title: `${s[i]} = ${v}, next ${i + 1 < s.length ? s[i + 1] : "—"} → ${subtract ? "subtract" : "add"}`,
              tracks: [
                track("symbols", s, s.map((_, k) => (k === i ? (subtract ? "bad" : "read") : k === i + 1 ? "compare" : k < i ? "done" : "idle"))),
                chips("running total", [total], "result"),
              ],
              counters: [count("value", total), count("position", i + 1, s.length)],
              legend: LEG,
              happened: subtract ? `${v} is subtracted because ${s[i + 1]} is larger.` : `${v} is added to the total.`,
              why: "Looking only one symbol ahead is enough because valid numerals never chain more than one subtractive step.",
              codeLine: subtract ? 16 : 17,
            });
          }
          steps.push({
            title: `Answer: ${total}`,
            tracks: [track("symbols", s, fill(s.length, "done")), chips("answer", [total], "result")],
            counters: [count("value", total), count("answer", total)],
            legend: LEG,
            happened: `${s.join("")} evaluates to ${total}.`,
            why: "The single look-ahead rule handles all nine subtractive pairs.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "integer-to-roman",
    title: "Integer to Roman",
    category: "Strings & Text",
    difficulty: "Beginner",
    description:
      "Turn an integer into a Roman numeral by peeling off the largest symbol value that fits.",
    input: { label: "number (1..3999)", default: "1994", parse: "int" },
    approaches: [
      {
        name: "Greedy Symbol Table",
        complexity: "O(1) time and space",
        idea: [
          "List the symbol values from largest to smallest, including the subtractive pairs CM, CD, XC, XL, IX and IV.",
          "Repeatedly take the largest value that fits and append its symbol. The remainder always shrinks.",
        ],
        problem: [
          "The greedy order only works because the table includes the subtractive pairs; without them the numeral would need repeated symbols.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint main(void) {\n    int values[] = {1000,900,500,400,100,90,50,40,10,9,5,4,1};\n    const char *symbols[] = {"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};\n    int n = 1994;\n\n    for (int i = 0; i < 13; i++)\n        while (n >= values[i]) {\n            printf("%s", symbols[i]);\n            n -= values[i];\n        }\n    printf("\\\\n"); /* MCMXCIV */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\nusing namespace std;\n\nstring intToRoman(int n) {\n    int values[] = {1000,900,500,400,100,90,50,40,10,9,5,4,1};\n    string symbols[] = {"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};\n    string out;\n    for (int i = 0; i < 13; i++)\n        while (n >= values[i]) {\n            out += symbols[i];\n            n -= values[i];\n        }\n    return out;\n}\n\nint main() {\n    cout << intToRoman(1994) << '\\\\n'; // MCMXCIV\n}`,
        },
        steps(n) {
          const num = Math.max(1, Math.min(3999, n | 0));
          const values = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1];
          const symbols = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"];
          const steps = [];
          let rest = num;
          let out = "";
          steps.push({
            title: `Convert ${num} using 13 symbol values`,
            tracks: [chips("values", values, "dim"), chips("symbols", symbols, "dim"), chips("output", ["—"], "idle")],
            counters: [count("remaining", rest), count("symbols used", 0)],
            legend: LEG,
            happened: "The table runs from 1000 down to 1 and already includes the subtractive pairs.",
            why: "Taking the largest fitting value keeps the numeral as short as possible.",
            codeLine: 4,
          });
          for (let i = 0; i < values.length; i++) {
            while (rest >= values[i]) {
              out += symbols[i];
              rest -= values[i];
              steps.push({
                title: `Take ${symbols[i]} (${values[i]}); ${rest} left`,
                tracks: [chips("values", values, (k) => (k === i ? "active" : k < i ? "done" : "dim")), chips("symbols", symbols, (k) => (k === i ? "active" : k < i ? "done" : "dim")), chips("output", [out], "result")],
                counters: [count("remaining", rest), count("symbols used", out.length)],
                legend: LEG,
                happened: `${symbols[i]} fits into the remainder, so it is appended.`,
                why: "The remainder never increases, so the loop must terminate.",
                codeLine: 7,
              });
            }
          }
          steps.push({
            title: `Answer: ${out}`,
            tracks: [chips("output", [out], "result"), chips("answer", [out], "result")],
            counters: [count("remaining", 0), count("answer", out)],
            legend: LEG,
            happened: `${num} is written as ${out}.`,
            why: "Greedy over a table that includes subtractive pairs matches the Roman rules exactly.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });
})();
