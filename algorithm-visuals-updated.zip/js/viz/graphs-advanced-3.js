﻿/* ============================================================
   DSA Visuals â€” Graphs III
   Components, MSTs, water wells, equality constraints,
   stone removal and slash regions.
   ============================================================ */
(function () {
  "use strict";
  const { fill, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => `[${a.join(", ")}]`;
  const partsOf = (text) => String(text || "").split("|").map((p) => p.trim());
  const pairsOf = (text) =>
    String(text || "").split(/\s+/).filter(Boolean).map((p) => p.split(",").map((x) => parseInt(x, 10))).filter((p) => p.length === 2 && p.every(Number.isFinite));
  const triplesOf = (text) =>
    String(text || "").split(/\s+/).filter(Boolean).map((p) => p.split(",").map((x) => parseInt(x, 10))).filter((p) => p.length === 3 && p.every(Number.isFinite));

  function circlePos(i, n) {
    const a = (2 * Math.PI * i) / Math.max(1, n) - Math.PI / 2;
    return { x: +(25 + 20 * Math.cos(a)).toFixed(1), y: +(25 + 20 * Math.sin(a)).toFixed(1) };
  }
  function graphStep(labels, edges, states, edgeStates, extra) {
    return Object.assign({
      kind: "graph",
      nodes: labels.map((lab, i) => {
        const p = circlePos(i, labels.length);
        return { id: "n" + i, label: String(lab), x: p.x, y: p.y, state: (states && states[i]) || "idle" };
      }),
      edges: edges.map(([u, v], i) => ({ a: "n" + u, b: "n" + v, state: (edgeStates && edgeStates[i]) || "idle" })),
      legend: LEG,
    }, extra);
  }
  function pointGraph(points, edges, states, edgeStates, extra) {
    const xs = points.map((p) => p[0]), ys = points.map((p) => p[1]);
    const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
    const sx = (x) => +(10 + ((x - minX) / Math.max(1, maxX - minX)) * 80).toFixed(1);
    const sy = (y) => +(10 + ((y - minY) / Math.max(1, maxY - minY)) * 80).toFixed(1);
    return Object.assign({
      kind: "graph",
      nodes: points.map((p, i) => ({ id: "n" + i, label: String(i), x: sx(p[0]), y: sy(p[1]), state: (states && states[i]) || "idle" })),
      edges: edges.map((e, i) => ({ a: "n" + e.u, b: "n" + e.v, state: (edgeStates && edgeStates[i]) || "idle" })),
      legend: LEG,
    }, extra);
  }
  function dsuOf(n) {
    const p = Array.from({ length: n }, (_, i) => i);
    const find = (x) => {
      while (p[x] !== x) { p[x] = p[p[x]]; x = p[x]; }
      return x;
    };
    const union = (a, b) => {
      const ra = find(a), rb = find(b);
      if (ra === rb) return false;
      p[rb] = ra;
      return true;
    };
    return { p, find, union };
  }

  /* ---------------------------------------------------------- */
  V.register({
    id: "number-of-provinces",
    title: "Number of Provinces",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Count the connected groups in an undirected adjacency matrix.",
    input: { label: "Adjacency rows of 0/1 separated by |", default: "110 | 110 | 001", parse: "string" },
    approaches: [
      {
        name: "Flood Each Unvisited Province",
        complexity: "O(nÂ²) time",
        idea: [
          "The matrix says which pairs are directly connected. Start at any unvisited row; that begins a new province.",
          "From each row in the province, walk every column marked 1 and mark that row visited. When the walk ends, all rows in that province are marked; count one province and look for another unvisited row.",
        ],
        problem: [
          "A single scan of the matrix only sees direct edges; transitive membership needs a flood or union-find.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint g[3][3] = {{1,1,0},{1,1,0},{0,0,1}};\nint seen[3];\n\nvoid dfs(int u, int n) {\n    seen[u] = 1;\n    for (int v = 0; v < n; v++)\n        if (g[u][v] && !seen[v]) dfs(v, n);\n}\n\nint main(void) {\n    int provinces = 0;\n    for (int i = 0; i < 3; i++)\n        if (!seen[i]) { provinces++; dfs(i, 3); }\n    printf(\"%d\\\\n\", provinces); /* 2 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nvoid dfs(vector<vector<int>>& g, vector<bool>& seen, int u) {\n    seen[u] = true;\n    for (int v = 0; v < (int)g.size(); v++)\n        if (g[u][v] && !seen[v]) dfs(g, seen, v);\n}\n\nint findCircleNum(vector<vector<int>>& g) {\n    int n = g.size(), provinces = 0;\n    vector<bool> seen(n, false);\n    for (int i = 0; i < n; i++)\n        if (!seen[i]) { provinces++; dfs(g, seen, i); }\n    return provinces;\n}\n\nint main() {\n    vector<vector<int>> g{{1,1,0},{1,1,0},{0,0,1}};\n    cout << findCircleNum(g) << '\\\\n'; // 2\n}`,
        },
        steps(text) {
          const raw = partsOf(text).filter(Boolean);
          const rows = raw.map((r) => r.split("").filter((ch) => ch === "0" || ch === "1"));
          const n = Math.min(10, rows.length);
          if (!n) return [{
            title: "Give adjacency rows",
            tracks: [chips("rows", ["â€”"], "idle")],
            counters: [count("provinces", 0)],
            legend: LEG,
            happened: "The matrix is empty.",
            why: "Each row describes one city's connections.",
          }];
          const g = Array.from({ length: n }, (_, r) => Array.from({ length: n }, (_, c) => rows[r][c] === "1" ? 1 : 0));
          const seen = Array(n).fill(false);
          const steps = [];
          let provinces = 0;
          const stateGrid = (cur, inFlood) => grid(n, n, (r, c) => ({
            v: g[r][c],
            state: r === cur ? "read" : seen[r] && seen[c] ? "done" : inFlood && inFlood.has(r) ? "active" : g[r][c] ? "dim" : "idle",
          }));
          steps.push({
            title: `${n} cities in an adjacency matrix`,
            kind: "grid", rows: n, cols: n, cells: stateGrid(null),
            counters: [count("provinces", 0), count("visited", 0, n)],
            legend: LEG,
            happened: "No city has been assigned to a province yet.",
            why: "A 1 at row u, column v means u and v are directly connected.",
            codeLine: 4,
          });
          for (let start = 0; start < n; start++) {
            if (seen[start]) continue;
            provinces++;
            seen[start] = true;
            const stack = [start];
            const flood = new Set([start]);
            while (stack.length) {
              const u = stack.pop();
              for (let v = 0; v < n; v++) {
                if (g[u][v] && !seen[v]) {
                  seen[v] = true;
                  flood.add(v);
                  stack.push(v);
                }
              }
            }
            steps.push({
              title: `Province ${provinces} starts at city ${start}`,
              kind: "grid", rows: n, cols: n, cells: stateGrid(start, flood),
              counters: [count("provinces", provinces), count("visited", seen.filter(Boolean).length, n)],
              legend: LEG,
              happened: `The flood reaches cit${flood.size === 1 ? "y" : "ies"} ${[...flood].join(", ")}.`,
              why: "Every city reached from one start belongs to the same connected component.",
              codeLine: 10,
            });
          }
          steps.push({
            title: `Answer: ${provinces} province${provinces === 1 ? "" : "s"}`,
            kind: "grid", rows: n, cols: n, cells: grid(n, n, (r, c) => ({ v: g[r][c], state: "result" })),
            counters: [count("provinces", provinces), count("visited", seen.filter(Boolean).length, n)],
            legend: LEG,
            happened: `The matrix splits into ${provinces} connected group${provinces === 1 ? "" : "s"}.`,
            why: "Each flood marks exactly one component, so the number of floods is the number of provinces.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "min-cost-to-connect-all-points",
    title: "Min Cost to Connect All Points",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Connect every point with the cheapest possible set of Manhattan-distance edges.",
    input: { label: "Points as x,y pairs", default: "0,0 2,2 3,10 5,2 7,0", parse: "string" },
    approaches: [
      {
        name: "Prim's Manhattan MST",
        complexity: "O(nÂ²) time",
        idea: [
          "The cost of an edge is the Manhattan distance between its points. Start with point 0 in the tree.",
          "Repeatedly add the cheapest edge that joins a tree point to a point outside. After n âˆ’ 1 additions every point is connected and the accumulated cost is minimal.",
        ],
        problem: [
          "Choosing edges globally by weight without tracking connectivity can create cycles or leave points stranded; Prim always grows one connected tree.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\nint pts[5][2] = {{0,0},{2,2},{3,10},{5,2},{7,0}};\nint dist(int a, int b) {\n    return abs(pts[a][0] - pts[b][0]) + abs(pts[a][1] - pts[b][1]);\n}\n\nint main(void) {\n    int n = 5, in[5] = {1,0,0,0,0}, total = 0;\n\n    for (int k = 1; k < n; k++) {\n        int best = 1 << 30, to = -1;\n        for (int i = 0; i < n; i++) if (in[i])\n            for (int j = 0; j < n; j++) if (!in[j]) {\n                int w = dist(i, j);\n                if (w < best) { best = w; to = j; }\n            }\n        in[to] = 1;\n        total += best;\n    }\n    printf(\"%d\\\\n\", total); /* 20 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <cstdlib>\nusing namespace std;\n\nint manhattan(vector<int>& a, vector<int>& b) {\n    return abs(a[0]-b[0]) + abs(a[1]-b[1]);\n}\n\nint minCostConnectPoints(vector<vector<int>>& p) {\n    int n = p.size(), total = 0;\n    vector<bool> in(n, false);\n    vector<int> best(n, 1e9);\n    best[0] = 0;\n\n    for (int k = 0; k < n; k++) {\n        int u = -1;\n        for (int i = 0; i < n; i++)\n            if (!in[i] && (u < 0 || best[i] < best[u])) u = i;\n        in[u] = true;\n        total += best[u];\n        for (int v = 0; v < n; v++)\n            if (!in[v]) best[v] = min(best[v], manhattan(p[u], p[v]));\n    }\n    return total;\n}\n\nint main() {\n    vector<vector<int>> p{{0,0},{2,2},{3,10},{5,2},{7,0}};\n    cout << minCostConnectPoints(p) << '\\\\n'; // 20\n}`,
        },
        steps(text) {
          const pts = pairsOf(text).slice(0, 10);
          if (pts.length < 2) return [{
            title: "Give at least two points",
            tracks: [chips("points", pts.map((p) => `${p[0]},${p[1]}`), "idle")],
            counters: [count("cost", 0)],
            legend: LEG,
            happened: "A spanning tree needs two or more points.",
            why: "With one point there is nothing to connect.",
          }];
          const n = pts.length;
          const edges = [];
          for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
            edges.push({ u: i, v: j, w: Math.abs(pts[i][0] - pts[j][0]) + Math.abs(pts[i][1] - pts[j][1]) });
          }
          const inTree = Array(n).fill(false);
          inTree[0] = true;
          const chosen = [];
          let total = 0;
          const steps = [];
          const nodeStates = (cur) => Object.fromEntries(pts.map((_, i) => [i, i === cur ? "read" : inTree[i] ? "good" : "idle"]));
          const edgeStates = (picked) => edges.map((e) => (chosen.some((c) => c.u === e.u && c.v === e.v) ? "good" : picked && picked.u === e.u && picked.v === e.v ? "read" : "dim"));
          steps.push(pointGraph(pts, edges, nodeStates(0), edgeStates(), {
            title: `Start the tree at point 0 (${pts[0][0]},${pts[0][1]})`,
            label: "every other point is still outside",
            counters: [count("cost", 0), count("in tree", 1, n)],
            happened: "The tree contains only the first point.",
            why: "Prim grows a tree instead of choosing edges globally.",
            codeLine: 8,
          }));
          for (let k = 1; k < n; k++) {
            let best = null;
            for (let i = 0; i < n; i++) {
              if (!inTree[i]) continue;
              for (let j = 0; j < n; j++) {
                if (inTree[j]) continue;
                const w = Math.abs(pts[i][0] - pts[j][0]) + Math.abs(pts[i][1] - pts[j][1]);
                if (!best || w < best.w) best = { u: i, v: j, w };
              }
            }
            if (!best) break;
            inTree[best.v] = true;
            chosen.push(best);
            total += best.w;
            steps.push(pointGraph(pts, edges, nodeStates(best.v), edgeStates(best), {
              title: `Add point ${best.v} for cost ${best.w}`,
              label: `edge ${best.u}â€“${best.v}: |dx| + |dy| = ${best.w}`,
              counters: [count("cost", total), count("in tree", k + 1, n)],
              happened: `The cheapest edge from the current tree reaches (${pts[best.v][0]},${pts[best.v][1]}).`,
              why: "Cutting the points into tree and non-tree, the lightest crossing edge is always safe to add.",
              codeLine: 15,
            }));
          }
          steps.push(pointGraph(pts, edges, Object.fromEntries(pts.map((_, i) => [i, "result"])), edges.map((e) => (chosen.some((c) => c.u === e.u && c.v === e.v) ? "good" : "dim")), {
            title: `Answer: connect all points for ${total}`,
            label: `${chosen.length} edges chosen`,
            counters: [count("cost", total), count("edges", chosen.length, n - 1)],
            legend: LEG,
            happened: `${chosen.map((c) => `${c.u}â€“${c.v}(${c.w})`).join(", ")}.`,
            why: "A minimum spanning tree has exactly n âˆ’ 1 edges and minimum total weight.",
            codeLine: 19,
          }));
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "connecting-cities-with-minimum-cost",
    title: "Connecting Cities with Minimum Cost",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Choose the cheapest roads that leave every city reachable from every other.",
    input: { label: "cities | edges as u,v,cost", default: "3 | 1,2,5 1,3,6 2,3,1", parse: "string" },
    approaches: [
      {
        name: "Kruskal on Sorted Roads",
        complexity: "O(E log E) time",
        idea: [
          "Sort all roads by cost. Walk the sorted list and keep a road only when its endpoints are in different components.",
          "Each accepted road merges two components. After n âˆ’ 1 acceptances the cities are connected; otherwise the graph is disconnected.",
        ],
        problem: [
          "Taking the cheapest road at every moment without checking connectivity can form a cycle that wastes budget.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\ntypedef struct { int u, v, w; } Edge;\nint cmp(const void *a, const void *b) {\n    return ((Edge*)a)->w - ((Edge*)b)->w;\n}\nint parent[8];\nint find(int x) {\n    while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }\n    return x;\n}\n\nint main(void) {\n    int n = 3;\n    Edge e[] = {{1,2,5},{1,3,6},{2,3,1}};\n    qsort(e, 3, sizeof(Edge), cmp);\n    for (int i = 1; i <= n; i++) parent[i] = i;\n\n    int used = 0, cost = 0;\n    for (int i = 0; i < 3; i++) {\n        int a = find(e[i].u), b = find(e[i].v);\n        if (a == b) continue;\n        parent[b] = a;\n        cost += e[i].w;\n        used++;\n    }\n    printf(\"%d\\\\n\", used == n - 1 ? cost : -1); /* 6 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <algorithm>\n#include <numeric>\nusing namespace std;\n\nint find(vector<int>& p, int x) {\n    while (p[x] != x) { p[x] = p[p[x]]; x = p[x]; }\n    return x;\n}\n\nint minimumCost(int n, vector<vector<int>>& edges) {\n    sort(edges.begin(), edges.end(), [](auto& a, auto& b) { return a[2] < b[2]; });\n    vector<int> p(n + 1);\n    iota(p.begin(), p.end(), 0);\n\n    int used = 0, cost = 0;\n    for (auto& e : edges) {\n        int a = find(p, e[0]), b = find(p, e[1]);\n        if (a == b) continue;\n        p[b] = a;\n        cost += e[2];\n        used++;\n    }\n    return used == n - 1 ? cost : -1;\n}\n\nint main() {\n    vector<vector<int>> edges{{1,2,5},{1,3,6},{2,3,1}};\n    cout << minimumCost(3, edges) << '\\\\n'; // 6\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const n = Math.min(10, Math.max(0, parseInt(parts[0], 10) || 0));
          const roads = triplesOf(parts[1] || "").filter(([u, v]) => u >= 1 && v >= 1 && u <= n && v <= n && u !== v);
          if (!n || !roads.length) return [{
            title: "Give cities and roads",
            tracks: [chips("roads", ["â€”"], "idle")],
            counters: [count("cost", 0)],
            legend: LEG,
            happened: "There are no usable roads.",
            why: "Kruskal needs at least one edge between two different cities.",
          }];
          const sorted = roads.slice().sort((a, b) => a[2] - b[2]);
          const { find, union } = dsuOf(n + 1);
          const steps = [];
          const order = Array.from({ length: n }, (_, i) => i + 1);
          const kept = [];
          const rejected = [];
          let cost = 0;
          let used = 0;
          const edgeLabels = sorted.map(([u, v, w]) => `${u}-${v}:${w}`);
          const stateFor = (i) => (kept.includes(i) ? "good" : rejected.includes(i) ? "bad" : i === used + rejected.length ? "read" : "idle");
          steps.push({
            title: `${roads.length} roads sorted by cost`,
            tracks: [
              chips("roads", edgeLabels, "idle"),
              chips("cities", order, "idle"),
              chips("total", [0], "dim"),
            ],
            counters: [count("accepted", 0, n - 1), count("cost", 0)],
            legend: LEG,
            happened: `Sorting puts road ${sorted[0][0]}â€“${sorted[0][1]} (cost ${sorted[0][2]}) first.`,
            why: "Kruskal considers cheap roads before expensive ones.",
            codeLine: 6,
          });
          sorted.forEach(([u, v, w], i) => {
            const ok = union(u, v);
            if (ok) { kept.push(i); used++; cost += w; } else rejected.push(i);
            const comps = new Set(order.map((c) => find(c))).size;
            steps.push({
              title: ok ? `Keep ${u}â€“${v} for ${w}` : `Skip ${u}â€“${v}: already connected`,
              tracks: [
                chips("roads", edgeLabels, stateFor),
                chips("components", [...new Set(order.map((c) => find(c)))].map((r) => `root ${r}`), "compare"),
                chips("total", [`${cost}`], ok ? "result" : "dim"),
              ],
              counters: [count("accepted", used, n - 1), count("cost", cost), count("components", comps)],
              legend: LEG,
              happened: ok ? `The road merges two components; cost becomes ${cost}.` : "Both cities already sit in the same component, so this road would close a cycle.",
              why: "Accepting exactly n âˆ’ 1 cycle-free roads builds a spanning tree.",
              codeLine: ok ? 13 : 15,
            });
          });
          const connected = used === n - 1;
          steps.push({
            title: connected ? `Answer: minimum cost ${cost}` : "Answer: the cities cannot all be connected",
            tracks: [
              chips("kept", kept.map((i) => edgeLabels[i]), connected ? "result" : "good"),
              chips("skipped", rejected.map((i) => edgeLabels[i]), "bad"),
            ],
            counters: [count("accepted", used, n - 1), count("cost", connected ? cost : -1)],
            legend: LEG,
            happened: connected ? `${used} roads connect all ${n} cities.` : `Only ${used} of the ${n - 1} needed roads could be accepted.`,
            why: "A spanning tree needs both enough edges and no cycle; DSU enforces both.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "optimize-water-distribution",
    title: "Optimize Water Distribution",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Mix wells and pipes to supply every house at the lowest total cost.",
    input: { label: "houses | well costs | pipes as u,v,cost", default: "3 | 1,2,2 | 1,2,1 2,3,1", parse: "string" },
    approaches: [
      {
        name: "Virtual Source Plus Kruskal",
        complexity: "O((n + p) log(n + p)) time",
        idea: [
          "Treat building a well in house i as an edge from a virtual source 0 to i with cost wells[i].",
          "Pipes are ordinary edges between houses. Running Kruskal on this combined graph chooses a cheapest set of wells and pipes that reaches every house.",
        ],
        problem: [
          "Deciding wells separately from pipes misses the trade-off: a shared well can be cheaper than many local ones.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\ntypedef struct { int u, v, w; } Edge;\nint cmp(const void *a, const void *b) { return ((Edge*)a)->w - ((Edge*)b)->w; }\nint parent[16];\nint find(int x) {\n    while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }\n    return x;\n}\n\nint main(void) {\n    int n = 3;\n    Edge e[16] = {{0,1,1},{0,2,2},{0,3,2},{1,2,1},{2,3,1}};\n    int m = 5;\n    qsort(e, m, sizeof(Edge), cmp);\n    for (int i = 0; i <= n; i++) parent[i] = i;\n\n    int cost = 0, used = 0;\n    for (int i = 0; i < m; i++) {\n        int a = find(e[i].u), b = find(e[i].v);\n        if (a == b) continue;\n        parent[b] = a;\n        cost += e[i].w;\n        if (++used == n) break;\n    }\n    printf(\"%d\\\\n\", cost); /* 3 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <algorithm>\n#include <numeric>\nusing namespace std;\n\nint find(vector<int>& p, int x) {\n    while (p[x] != x) { p[x] = p[p[x]]; x = p[x]; }\n    return x;\n}\n\nint minCostToSupplyWater(int n, vector<int>& wells, vector<vector<int>>& pipes) {\n    vector<vector<int>> e;\n    for (int i = 1; i <= n; i++) e.push_back({0, i, wells[i - 1]});\n    for (auto& p : pipes) e.push_back(p);\n    sort(e.begin(), e.end(), [](auto& a, auto& b) { return a[2] < b[2]; });\n\n    vector<int> p(n + 1);\n    iota(p.begin(), p.end(), 0);\n    int cost = 0, used = 0;\n\n    for (auto& x : e) {\n        int a = find(p, x[0]), b = find(p, x[1]);\n        if (a == b) continue;\n        p[b] = a;\n        cost += x[2];\n        if (++used == n) break;\n    }\n    return cost;\n}\n\nint main() {\n    vector<int> wells{1,2,2};\n    vector<vector<int>> pipes{{1,2,1},{2,3,1}};\n    cout << minCostToSupplyWater(3, wells, pipes) << '\\\\n'; // 3\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const n = Math.min(10, Math.max(0, parseInt(parts[0], 10) || 0));
          const wells = String(parts[1] || "").split(/[\s,]+/).filter(Boolean).map(Number).slice(0, n);
          const pipes = triplesOf(parts[2] || "").filter(([u, v]) => u >= 1 && v >= 1 && u <= n && v <= n && u !== v);
          if (!n || wells.length < n) return [{
            title: "Give a well cost for every house",
            tracks: [chips("wells", wells.length ? wells : ["â€”"], "idle")],
            counters: [count("cost", 0)],
            legend: LEG,
            happened: "The well list is incomplete.",
            why: "The virtual source needs one edge per house.",
          }];
          const edges = [];
          wells.forEach((w, i) => edges.push({ u: 0, v: i + 1, w, kind: "well" }));
          pipes.forEach(([u, v, w]) => edges.push({ u, v, w, kind: "pipe" }));
          const sorted = edges.slice().sort((a, b) => a.w - b.w);
          const labels = sorted.map((e) => (e.kind === "well" ? `well ${e.v}:${e.w}` : `${e.u}-${e.v}:${e.w}`));
          const { find, union } = dsuOf(n + 1);
          const steps = [];
          const kept = [];
          const rejected = [];
          let cost = 0;
          let used = 0;
          const stateFor = (i) => (kept.includes(i) ? "good" : rejected.includes(i) ? "bad" : "idle");
          steps.push({
            title: `Add virtual node 0 with one well edge per house`,
            tracks: [
              chips("wells", wells.map((w, i) => `house ${i + 1}: ${w}`), "idle"),
              chips("edges", labels, "idle"),
              chips("cost", [0], "dim"),
            ],
            counters: [count("accepted", 0, n), count("cost", 0)],
            legend: LEG,
            happened: `There are ${sorted.length} candidate edges after adding the wells.`,
            why: "A well is an edge from the source; buying it connects that house to the water supply.",
            codeLine: 8,
          });
          sorted.forEach((e, i) => {
            const ok = union(e.u, e.v);
            if (ok) { kept.push(i); used++; cost += e.w; } else rejected.push(i);
            steps.push({
              title: ok ? `Buy ${e.kind === "well" ? `well for house ${e.v}` : `pipe ${e.u}â€“${e.v}`} for ${e.w}` : `Skip ${e.kind} ${e.u === 0 ? e.v : `${e.u}â€“${e.v}`}: already supplied`,
              tracks: [
                chips("edges", labels, stateFor),
                chips("houses supplied", Array.from({ length: n }, (_, h) => h + 1).filter((h) => find(h) === find(0)), "good"),
                chips("cost", [`${cost}`], ok ? "result" : "dim"),
              ],
              counters: [count("accepted", used, n), count("cost", cost)],
              legend: LEG,
              happened: ok ? `The chosen edge lowers the source's component by one more house; total ${cost}.` : "Both endpoints already receive water from the same component.",
              why: "Kruskal treats wells and pipes as interchangeable edges, so it can pick whichever is cheaper.",
              codeLine: ok ? 14 : 16,
            });
          });
          const done = used === n;
          steps.push({
            title: done ? `Answer: supply every house for ${cost}` : "Answer: some houses cannot be supplied",
            tracks: [chips("chosen", kept.map((i) => labels[i]), done ? "result" : "good")],
            counters: [count("accepted", used, n), count("cost", done ? cost : -1)],
            legend: LEG,
            happened: done ? `${used} edges connect all houses to the virtual source.` : "The available edges do not connect every house.",
            why: "A minimum spanning tree on the augmented graph minimises wells plus pipes.",
            codeLine: 21,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "satisfiability-of-equality-equations",
    title: "Satisfiability of Equality Equations",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Decide whether == and != constraints over single letters can all hold.",
    input: { label: "Equations separated by commas", default: "a==b,b!=c,a==c", parse: "string" },
    approaches: [
      {
        name: "Union Equalities, Check Inequalities",
        complexity: "O(equations Ã— Î±(26)) time",
        idea: [
          "Equalities merge letters into the same set. After all equalities, every letter in one set must have one value.",
          "An inequality is impossible exactly when its two letters ended up in the same set. Process every equality first, then test the inequalities.",
        ],
        problem: [
          "Checking equations in their original mixed order can miss that a later equality makes an earlier inequality impossible.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint parent[26];\nint find(int x) {\n    while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }\n    return x;\n}\n\nint main(void) {\n    char *eqs[] = {\"a==b\",\"b!=c\",\"a==c\"};\n    int m = 3;\n    for (int i = 0; i < 26; i++) parent[i] = i;\n\n    for (int i = 0; i < m; i++)\n        if (eqs[i][1] == '=') {\n            int a = find(eqs[i][0] - 'a'), b = find(eqs[i][3] - 'a');\n            if (a != b) parent[b] = a;\n        }\n\n    for (int i = 0; i < m; i++)\n        if (eqs[i][1] == '!' && find(eqs[i][0] - 'a') == find(eqs[i][3] - 'a')) {\n            printf(\"false\\\\n\");\n            return 0;\n        }\n    printf(\"true\\\\n\");\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <numeric>\nusing namespace std;\n\nint find(vector<int>& p, int x) {\n    while (p[x] != x) { p[x] = p[p[x]]; x = p[x]; }\n    return x;\n}\n\nbool equationsPossible(vector<string>& eqs) {\n    vector<int> p(26);\n    iota(p.begin(), p.end(), 0);\n\n    for (auto& s : eqs)\n        if (s[1] == '=') {\n            int a = find(p, s[0] - 'a'), b = find(p, s[3] - 'a');\n            if (a != b) p[b] = a;\n        }\n\n    for (auto& s : eqs)\n        if (s[1] == '!' && find(p, s[0] - 'a') == find(p, s[3] - 'a')) return false;\n    return true;\n}\n\nint main() {\n    vector<string> eqs{\"a==b\",\"b!=c\",\"a==c\"};\n    cout << equationsPossible(eqs) << '\\\\n'; // 0\n}`,
        },
        steps(text) {
          const eqs = String(text || "").split(/[\s,]+/).filter((s) => /^[a-z](==|!=)[a-z]$/.test(s));
          if (!eqs.length) return [{
            title: "Give equality or inequality equations",
            tracks: [chips("equations", ["â€”"], "idle")],
            counters: [count("equalities", 0), count("inequalities", 0)],
            legend: LEG,
            happened: "There are no valid equations.",
            why: "Each equation must look like a==b or a!=b.",
          }];
          const { find, union } = dsuOf(26);
          const letters = [...new Set(eqs.flatMap((s) => [s[0], s[3]]))].sort();
          const letterState = (l) => (letters.includes(l) ? "active" : "dim");
          const steps = [];
          const stateFor = (i, done) => (done.includes(i) ? "done" : i === done.length ? "read" : "idle");
          const doneEq = [];
          steps.push({
            title: `${eqs.length} constraints over ${letters.length} letters`,
            tracks: [
              chips("equations", eqs, (i) => (eqs[i][1] === "=" ? "compare" : "bad")),
              chips("letters", letters, letterState),
            ],
            counters: [count("equalities", eqs.filter((s) => s[1] === "=").length), count("inequalities", eqs.filter((s) => s[1] === "!").length)],
            legend: LEG,
            happened: "Every letter starts in its own singleton set.",
            why: "Equalities will merge sets; inequalities must stay between different sets.",
            codeLine: 7,
          });
          eqs.forEach((s, i) => {
            if (s[1] !== "=") return;
            union(s.charCodeAt(0) - 97, s.charCodeAt(3) - 97);
            doneEq.push(i);
            steps.push({
              title: `Merge ${s[0]} and ${s[3]}`,
              tracks: [
                chips("equations", eqs, (j) => (doneEq.includes(j) ? "done" : j === i ? "read" : "idle")),
                chips("sets", [...new Set(letters.map((l) => find(l.charCodeAt(0) - 97)))].map((r) => `root ${String.fromCharCode(97 + r)}`), "compare"),
                chips("letters", letters, (j) => { const l = letters[j]; return find(l.charCodeAt(0) - 97) === find(s.charCodeAt(0) - 97) ? "good" : "dim"; }),
              ],
              counters: [count("equalities processed", doneEq.length), count("sets", new Set(letters.map((l) => find(l.charCodeAt(0) - 97))).size)],
              legend: LEG,
              happened: `${s[0]} and ${s[3]} must share one value from now on.`,
              why: "Union-find stores the transitive closure of all equalities.",
              codeLine: 10,
            });
          });
          let bad = null;
          eqs.forEach((s, i) => {
            if (s[1] !== "!" || bad != null) return;
            if (find(s.charCodeAt(0) - 97) === find(s.charCodeAt(3) - 97)) bad = { s, i };
          });
          steps.push({
            title: bad ? `Contradiction: ${bad.s[0]} and ${bad.s[3]} must differ but are equal` : "Answer: every constraint can be satisfied",
            tracks: [
              chips("equations", eqs, (i) => (bad && i === bad.i ? "bad" : eqs[i][1] === "=" ? "done" : "good")),
              chips("sets", [...new Set(letters.map((l) => find(l.charCodeAt(0) - 97)))].map((r) => `root ${String.fromCharCode(97 + r)}`), bad ? "bad" : "result"),
            ],
            counters: [count("answer", bad ? "false" : "true"), count("sets", new Set(letters.map((l) => find(l.charCodeAt(0) - 97))).size)],
            legend: LEG,
            happened: bad ? `The equalities already forced ${bad.s[0]} = ${bad.s[3]}, contradicting ${bad.s}.` : "No inequality joins two letters in the same set.",
            why: "The equalities define equivalence classes; inequalities are satisfiable exactly when they cross classes.",
            codeLine: bad ? 17 : 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "most-stones-removed",
    title: "Most Stones Removed",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Remove stones that share a row or column with another remaining stone.",
    input: { label: "Stones as row,col pairs", default: "0,0 0,1 1,0 1,2 2,1 2,2", parse: "string" },
    approaches: [
      {
        name: "Union Rows With Columns",
        complexity: "O(stones Î±) time",
        idea: [
          "Make a graph node for every distinct row and every distinct column. Each stone is an edge between its row and its column.",
          "Inside a connected group of k stones, k âˆ’ 1 stones can be removed while one stone remains to keep the group connected. Summing gives stones âˆ’ number of groups.",
        ],
        problem: [
          "Removing stones greedily can strand a stone with no partner. Union-find captures the whole row/column group at once.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint parent[32];\nint find(int x) {\n    while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }\n    return x;\n}\n\nint main(void) {\n    int stones[6][2] = {{0,0},{0,1},{1,0},{1,2},{2,1},{2,2}};\n    int n = 6, R = 3, C = 3;\n    for (int i = 0; i < R + C; i++) parent[i] = i;\n\n    for (int i = 0; i < n; i++) {\n        int a = find(stones[i][0]), b = find(R + stones[i][1]);\n        if (a != b) parent[b] = a;\n    }\n\n    int groups = 0;\n    for (int i = 0; i < R + C; i++) if (find(i) == i) groups++;\n    printf(\"%d\\\\n\", n - groups); /* 5 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <set>\n#include <numeric>\nusing namespace std;\n\nint find(vector<int>& p, int x) {\n    while (p[x] != x) { p[x] = p[p[x]]; x = p[x]; }\n    return x;\n}\n\nint removeStones(vector<vector<int>>& stones) {\n    int maxR = 0, maxC = 0;\n    for (auto& s : stones) { maxR = max(maxR, s[0]); maxC = max(maxC, s[1]); }\n\n    vector<int> p(maxR + maxC + 2);\n    iota(p.begin(), p.end(), 0);\n\n    for (auto& s : stones) {\n        int a = find(p, s[0]), b = find(p, maxR + 1 + s[1]);\n        if (a != b) p[b] = a;\n    }\n\n    set<int> groups;\n    for (auto& s : stones)\n        groups.insert(find(p, s[0]));\n    return stones.size() - groups.size();\n}\n\nint main() {\n    vector<vector<int>> stones{{0,0},{0,1},{1,0},{1,2},{2,1},{2,2}};\n    cout << removeStones(stones) << '\\\\n'; // 5\n}`,
        },
        steps(text) {
          const stones = pairsOf(text).slice(0, 14);
          if (!stones.length) return [{
            title: "Give stone coordinates",
            tracks: [chips("stones", ["â€”"], "idle")],
            counters: [count("stones", 0)],
            legend: LEG,
            happened: "There are no stones.",
            why: "Rows and columns are only created by stones.",
          }];
          const rowSet = [...new Set(stones.map(([r]) => r))].sort((a, b) => a - b);
          const colSet = [...new Set(stones.map(([, c]) => c))].sort((a, b) => a - b);
          const rowIdx = new Map(rowSet.map((r, i) => [r, i]));
          const colIdx = new Map(colSet.map((c, i) => [c, i]));
          const R = rowSet.length;
          const total = R + colSet.length;
          const { find, union } = dsuOf(total);
          const steps = [];
          const stateFor = (i, current) => (i === current ? "read" : i < current ? "done" : "idle");
          steps.push({
            title: `${stones.length} stones on ${R} rows and ${colSet.length} columns`,
            tracks: [
              chips("stones", stones.map(([r, c]) => `${r},${c}`), "idle"),
              chips("rows", rowSet.map((r) => `r${r}`), "dim"),
              chips("columns", colSet.map((c) => `c${c}`), "dim"),
            ],
            counters: [count("stones", stones.length), count("groups", total)],
            legend: LEG,
            happened: "Each distinct row and column is a graph node; each stone is an edge between its row and column.",
            why: "Stones in one connected group can be reduced to a single survivor.",
            codeLine: 9,
          });
          stones.forEach(([r, c], i) => {
            union(rowIdx.get(r), R + colIdx.get(c));
            const groups = new Set(stones.map(([rr, cc]) => find(rowIdx.get(rr)))).size;
            steps.push({
              title: `Link row ${r} with column ${c}`,
              tracks: [
                chips("stones", stones.map(([rr, cc]) => `${rr},${cc}`), (j) => stateFor(j, i)),
                chips("rows", rowSet.map((rr) => `r${rr}`), (j) => (find(j) === find(rowIdx.get(r)) ? "good" : "dim")),
                chips("columns", colSet.map((cc) => `c${cc}`), (j) => (find(R + j) === find(rowIdx.get(r)) ? "good" : "dim")),
              ],
              counters: [count("stones linked", i + 1, stones.length), count("groups", groups)],
              legend: LEG,
              happened: `Stone (${r},${c}) joins row ${r} and column ${c}; the whole group can lose one more stone.`,
              why: "A tree on k stones has k âˆ’ 1 removable stones.",
              codeLine: 12,
            });
          });
          const groups = new Set(stones.map(([r]) => find(rowIdx.get(r)))).size;
          steps.push({
            title: `Answer: remove at most ${stones.length - groups}`,
            tracks: [chips("groups", [...new Set(stones.map(([r]) => rowIdx.get(r)))].map((r) => `group ${find(r)}`), "done"), chips("answer", [stones.length - groups], "result")],
            counters: [count("stones", stones.length), count("groups", groups), count("removable", stones.length - groups)],
            legend: LEG,
            happened: `${stones.length} stones form ${groups} independent row/column group${groups === 1 ? "" : "s"}; each keeps one survivor.`,
            why: "Every group of k stones contributes exactly k âˆ’ 1 removals, so the total is stones âˆ’ groups.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "regions-cut-by-slashes",
    title: "Regions Cut by Slashes",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Count the connected empty regions formed by slash and backslash walls.",
    input: { label: "Rows of / \\ and . separated by |", default: "/\\ | \\/", parse: "string" },
    approaches: [
      {
        name: "Expand Each Cell to Three Pixels",
        complexity: "O(rows Ã— cols) time",
        idea: [
          "A cell is too small to represent a diagonal wall. Replace each cell by a 3 Ã— 3 block and draw the slash or backslash as blocked pixels.",
          "Flood-fill the unblocked pixels with four-way moves. Each flood is one region, and diagonal walls now separate regions exactly as the drawing suggests.",
        ],
        problem: [
          "Flood-filling the original cells without expansion lets regions leak through the corners of diagonal walls.",
        ],
        code: {
          c: `#include <stdio.h>\n\nchar grid[2][2] = {{\'/\',\'\\\\\'},{\'\\\\\',\'/\'}};\nint wall[6][6], seen[6][6];\nint dr[] = {1,-1,0,0}, dc[] = {0,0,1,-1};\n\nvoid flood(int r, int c) {\n    if (r < 0 || r > 5 || c < 0 || c > 5 || wall[r][c] || seen[r][c]) return;\n    seen[r][c] = 1;\n    for (int d = 0; d < 4; d++) flood(r + dr[d], c + dc[d]);\n}\n\nint main(void) {\n    for (int r = 0; r < 2; r++)\n        for (int c = 0; c < 2; c++) {\n            if (grid[r][c] == \'/\') { wall[3*r][3*c+2] = wall[3*r+1][3*c+1] = wall[3*r+2][3*c] = 1; }\n            else if (grid[r][c] == \'\\\\\') { wall[3*r][3*c] = wall[3*r+1][3*c+1] = wall[3*r+2][3*c+2] = 1; }\n        }\n\n    int regions = 0;\n    for (int r = 0; r < 6; r++)\n        for (int c = 0; c < 6; c++)\n            if (!wall[r][c] && !seen[r][c]) { regions++; flood(r, c); }\n    printf(\"%d\\\\n\", regions);\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint dr[] = {1,-1,0,0}, dc[] = {0,0,1,-1};\n\nvoid flood(vector<vector<int>>& wall, vector<vector<bool>>& seen, int r, int c) {\n    int n = wall.size();\n    if (r < 0 || r >= n || c < 0 || c >= n || wall[r][c] || seen[r][c]) return;\n    seen[r][c] = true;\n    for (int d = 0; d < 4; d++) flood(wall, seen, r + dr[d], c + dc[d]);\n}\n\nint regionsBySlashes(vector<string>& g) {\n    int n = g.size();\n    vector<vector<int>> wall(3*n, vector<int>(3*n, 0));\n    vector<vector<bool>> seen(3*n, vector<bool>(3*n, false));\n\n    for (int r = 0; r < n; r++)\n        for (int c = 0; c < n; c++) {\n            if (g[r][c] == \'/\') { wall[3*r][3*c+2] = wall[3*r+1][3*c+1] = wall[3*r+2][3*c] = 1; }\n            else if (g[r][c] == \'\\\\\') { wall[3*r][3*c] = wall[3*r+1][3*c+1] = wall[3*r+2][3*c+2] = 1; }\n        }\n\n    int regions = 0;\n    for (int r = 0; r < 3*n; r++)\n        for (int c = 0; c < 3*n; c++)\n            if (!wall[r][c] && !seen[r][c]) { regions++; flood(wall, seen, r, c); }\n    return regions;\n}\n\nint main() {\n    vector<string> g{\"/\\\\\",\"\\\\/\"};\n    cout << regionsBySlashes(g) << '\\\\n';\n}`,
        },
        steps(text) {
          const rows = partsOf(text).filter(Boolean).map((r) => r.split(""));
          const R = Math.min(5, rows.length);
          if (!R) return [{
            title: "Give at least one row",
            tracks: [chips("rows", ["â€”"], "idle")],
            counters: [count("regions", 0)],
            legend: LEG,
            happened: "There are no cells to draw.",
            why: "A slash grid needs at least one row.",
          }];
          const C = Math.min(5, Math.max(...rows.slice(0, R).map((r) => r.length)));
          const cellAt = (r, c) => (rows[r] && rows[r][c]) || ".";
          const W = 3 * R, H = 3 * C;
          const wall = Array.from({ length: W }, () => Array(H).fill(false));
          const region = Array.from({ length: W }, () => Array(H).fill(-1));
          const steps = [];
          const draw = (cur, states) => grid(W, H, (r, c) => ({
            v: wall[r][c] ? "#" : region[r][c] >= 0 ? String(region[r][c]) : "Â·",
            state: wall[r][c] ? "bad" : states ? states(r, c) : "idle",
          }));
          steps.push({
            title: `Expand ${R} Ã— ${C} cells to ${W} Ã— ${H} pixels`,
            kind: "grid", rows: W, cols: H, cells: draw(),
            counters: [count("cells", R * C), count("regions", 0)],
            legend: LEG,
            happened: "Every cell becomes a 3 Ã— 3 block so a diagonal wall has room to exist.",
            why: "Slashes cut a cell diagonally; a single pixel cannot represent both sides.",
            codeLine: 4,
          });
          for (let r = 0; r < R; r++) {
            for (let c = 0; c < C; c++) {
              const ch = cellAt(r, c);
              if (ch === "/") { wall[3 * r][3 * c + 2] = true; wall[3 * r + 1][3 * c + 1] = true; wall[3 * r + 2][3 * c] = true; }
              else if (ch === "\\") { wall[3 * r][3 * c] = true; wall[3 * r + 1][3 * c + 1] = true; wall[3 * r + 2][3 * c + 2] = true; }
            }
            steps.push({
              title: `Draw the walls in row ${r}`,
              kind: "grid", rows: W, cols: H, cells: draw(null),
              counters: [count("cells", R * C), count("walls", wall.flat().filter(Boolean).length)],
              legend: LEG,
              happened: `Slash cells in row ${r} add diagonal blocked pixels; dots stay fully open.`,
              why: "Backslashes block the top-left to bottom-right diagonal; slashes block the other diagonal.",
              codeLine: 7,
            });
          }
          let regions = 0;
          const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
          for (let r = 0; r < W; r++) {
            for (let c = 0; c < H; c++) {
              if (wall[r][c] || region[r][c] !== -1) continue;
              regions++;
              const queue = [[r, c]];
              region[r][c] = regions;
              while (queue.length) {
                const [x, y] = queue.shift();
                dirs.forEach(([dx, dy]) => {
                  const nx = x + dx, ny = y + dy;
                  if (nx < 0 || nx >= W || ny < 0 || ny >= H) return;
                  if (wall[nx][ny] || region[nx][ny] !== -1) return;
                  region[nx][ny] = regions;
                  queue.push([nx, ny]);
                });
              }
              const palette = ["active", "good", "compare", "result", "done"];
              const fixed = regions - 1;
              const size = queue.length ? region.flat().filter((x) => x === regions).length : 1;
              steps.push({
                title: `Region ${regions} floods ${size} open pixel${size === 1 ? "" : "s"}`,
                kind: "grid", rows: W, cols: H, cells: draw(null, (rr, cc) => (region[rr][cc] === regions ? palette[fixed % palette.length] : region[rr][cc] > 0 ? "done" : "idle")),
                counters: [count("regions", regions), count("open pixels", region.flat().filter((x) => x > 0).length, W * H - wall.flat().filter(Boolean).length)],
                legend: LEG,
                happened: `Region ${regions} is one connected area of unblocked pixels.`,
                why: "Each four-way flood marks exactly one connected region; diagonals do not connect.",
                codeLine: 17,
              });
            }
          }
          steps.push({
            title: `Answer: ${regions} region${regions === 1 ? "" : "s"}`,
            kind: "grid", rows: W, cols: H, cells: grid(W, H, (r, c) => ({ v: wall[r][c] ? "#" : String(region[r][c]), state: wall[r][c] ? "bad" : "result" })),
            counters: [count("regions", regions), count("cells", R * C)],
            legend: LEG,
            happened: `The ${W} Ã— ${H} pixel grid contains ${regions} connected open region${regions === 1 ? "" : "s"}.`,
            why: "Diagonal walls separate pixels that touch only at a corner, which is why four-way flooding counts them separately.",
            codeLine: 22,
          });
          return steps;
        },
      },
    ],
  });
})();

