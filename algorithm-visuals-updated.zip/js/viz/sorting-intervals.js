/* ============================================================
   DSA Visuals — Sorting & Intervals
   Original step generators for six sorting / interval problems:
     sort-colors, merge-intervals, insert-interval,
     non-overlapping-intervals, largest-number, relative-sort-array
   Contract and palette follow SPEC.md.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  /* ---------------- shared little helpers ---------------- */

  // an interval [a, b] as a short display string
  const ivStr = (p) => `[${p[0]},${p[1]}]`;
  const copyIv = (p) => [p[0], p[1]];

  // a track of interval cells; `state` may be a string or fn(pair, i)
  const ivTrack = (label, list, state) => ({
    label,
    cells: list.map((p, i) => ({
      v: ivStr(p),
      state: typeof state === "function" ? state(p, i) : state || "idle",
    })),
  });

  // states for a left-to-right scan: everything before i is done, i is read
  const prog = (n, i) => Array.from({ length: n }, (_, k) => (k < i ? "done" : k === i ? "read" : "idle"));

  // a single-cell track showing one interval as the "current" working block
  const oneIv = (label, iv, state, tag) => ({
    label,
    cells: [{ v: ivStr(iv), state: state || "active", tag }],
  });

  // insert `iv` into a sorted, non-overlapping list of intervals.
  // returns the new list, which old blocks overlapped, and the merged block.
  function insertIntervalInto(list, iv) {
    const res = [];
    const merged = copyIv(iv);
    const overlappedWith = [];
    let placed = false;
    for (const p of list) {
      if (p[1] < merged[0]) {
        res.push(copyIv(p)); // sits entirely before the new block
      } else if (p[0] > merged[1]) {
        if (!placed) { res.push(copyIv(merged)); placed = true; }
        res.push(copyIv(p)); // sits entirely after the new block
      } else {
        overlappedWith.push(copyIv(p)); // touches the new block
        merged[0] = Math.min(merged[0], p[0]);
        merged[1] = Math.max(merged[1], p[1]);
      }
    }
    if (!placed) res.push(copyIv(merged));
    res.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    return { res, overlappedWith, merged };
  }

  /* ============================================================
     1. Sort Colors — two ways
     ============================================================ */
  V.register({
    id: "sort-colors",
    title: "Sort Colors",
    category: "Sorting & Intervals",
    difficulty: "Intermediate",
    description: "Group a row of 0s, 1s and 2s in place — count-and-fill, then the Dutch flag swap.",
    input: { label: "Colors (0, 1, 2)", default: "2, 0, 2, 1, 1, 0, 2, 1", parse: "ints" },
    approaches: [
      {
        name: "Count Then Overwrite",
        complexity: "O(n) time, O(1) space",
        idea: [
          "First pass: count how many 0s, how many 1s and how many 2s live in the row — three small tallies are enough.",
          "Second pass: walk the row again from the left and overwrite it with that many 0s, then that many 1s, then that many 2s.",
        ],
        problem: [
          "The row is touched twice and the old numbers are simply thrown away while rewriting. This only works because there are exactly three possible kinds of value.",
        ],
        code: {
          c: `#include <stdio.h>

/* count the three colours, then rewrite the row grouped */
void sort_colors(int *a, int n) {
    int c0 = 0, c1 = 0, c2 = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] == 0) c0++;
        else if (a[i] == 1) c1++;
        else c2++;
    }
    int k = 0;
    for (int i = 0; i < c0; i++) a[k++] = 0;
    for (int i = 0; i < c1; i++) a[k++] = 1;
    for (int i = 0; i < c2; i++) a[k++] = 2;
}

int main(void) {
    int a[] = {2, 0, 2, 1, 1, 0, 2, 1};
    sort_colors(a, 8);
    for (int i = 0; i < 8; i++) printf("%d ", a[i]);
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// count each colour, then write them back grouped
void sortColors(std::vector<int>& a) {
    int c[3] = {0, 0, 0};
    for (int x : a) c[x]++;
    int k = 0;
    for (int v = 0; v < 3; v++)
        for (int i = 0; i < c[v]; i++)
            a[k++] = v;
}

int main() {
    std::vector<int> a{2, 0, 2, 1, 1, 0, 2, 1};
    sortColors(a);
    for (int x : a) std::cout << x << ' ';   // 0 0 1 1 1 2 2 2
}`,
        },
        steps(nums) {
          const n = nums.length;
          const bucketOf = (v) => (v === 0 ? 0 : v === 1 ? 1 : 2);
          const cnt = [0, 0, 0];
          const steps = [];
          const buckets = (hot) => ({
            label: "colour counts",
            cells: [0, 1, 2].map((k) => ({
              v: `${k} × ${cnt[k]}`,
              state: hot === k ? "read" : cnt[k] ? "done" : "idle",
              tag: k === 0 ? "zeros" : k === 1 ? "ones" : "twos",
            })),
          });
          const built = [];

          steps.push({
            title: "Set up: count first, rewrite second",
            tracks: [track("the numbers", nums, fill(n, "idle")), buckets(-1)],
            counters: [count("numbers read", 0, n), count("cells rewritten", 0, n)],
            legend: ["read", "done", "result", "idle"],
            happened: `The row has ${n} numbers and the three colour tallies all start at zero.`,
            why: "If the counts are known up front, the second pass never has to compare anything.",
            codeLine: 3,
          });

          for (let i = 0; i < n; i++) {
            const b = bucketOf(nums[i]);
            cnt[b]++;
            const odd = nums[i] !== b;
            steps.push({
              title: odd ? `${nums[i]} counted with the 2s → ${cnt[b]} of them` : `${nums[i]} joins the ${b}s → ${cnt[b]} so far`,
              tracks: [track("the numbers", nums, prog(n, i)), buckets(b)],
              counters: [count("numbers read", i + 1, n), count("zeros", cnt[0]), count("ones", cnt[1]), count("twos", cnt[2])],
              happened: `The tally for ${b} ticks up to ${cnt[b]}.${odd ? ` (${nums[i]} is not a colour, so the demo treats it as a 2.)` : ""}`,
              why: "Every number is read once and reduces to a single tally bump — no ordering yet.",
              codeLine: nums[i] === 0 ? 6 : nums[i] === 1 ? 7 : 8,
            });
          }

          steps.push({
            title: `Counts ready: ${cnt[0]} zeros, ${cnt[1]} ones, ${cnt[2]} twos`,
            tracks: [track("the numbers", nums, fill(n, "done")), buckets(-1)],
            counters: [count("numbers read", n, n), count("zeros", cnt[0]), count("ones", cnt[1]), count("twos", cnt[2])],
            happened: "The first pass is over; the three tallies add up to exactly the row length.",
            why: "The final row is now fully decided — the rest is just writing it down.",
            codeLine: 10,
          });

          const builtTrack = () => ({
            label: "rewritten array",
            cells: Array.from({ length: n }, (_, k) =>
              k < built.length
                ? { v: built[k], state: k === built.length - 1 ? "read" : "result" }
                : { v: "—", state: "idle", empty: true }),
          });

          for (let k = 0; k < n; k++) {
            const val = k < cnt[0] ? 0 : k < cnt[0] + cnt[1] ? 1 : 2;
            built.push(val);
            steps.push({
              title: `Write ${val} at index ${k}`,
              tracks: [track("the numbers", nums, fill(n, "dim")), builtTrack()],
              counters: [count("cells rewritten", k + 1, n), count("writing", val)],
              happened: `Slot ${k} receives ${val}${k === 0 ? `, the very first value of the grouped row` : ""}.`,
              why: "Knowing the counts means each slot's value is read off directly — no comparisons, no swaps.",
              codeLine: val === 0 ? 11 : val === 1 ? 12 : 13,
            });
          }

          steps.push({
            title: `Answer: ${built.join(", ")}`,
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              { label: "rewritten array", cells: built.map((v) => ({ v, state: "result" })) },
            ],
            counters: [count("numbers read", n, n), count("cells rewritten", n, n)],
            happened: `After two passes the row reads ${built.join(", ")} — all 0s, then 1s, then 2s.`,
            why: "Counting turned the sort into a straight pour: O(n) time, no extra array.",
            codeLine: 19,
          });
          return steps;
        },
      },
      {
        name: "Dutch Flag Three Pointers",
        complexity: "O(n) time, O(1) space, one pass",
        idea: [
          "Keep three boundaries: everything left of low is finished 0s, everything between low and mid is finished 1s, everything right of high is finished 2s.",
          "Look at the value under mid: a 0 is swapped back to low, a 2 is swapped forward to high, and a 1 is simply left where it is while mid walks on.",
        ],
        problem: [
          "The pointer dance is fiddly: after swapping in a 2 you must NOT advance mid, because the value you just received has never been looked at.",
        ],
        code: {
          c: `#include <stdio.h>

static void swap(int *x, int *y) { int t = *x; *x = *y; *y = t; }

/* dutch flag: 0s grow from the left, 2s from the right */
void sort_colors(int *a, int n) {
    int low = 0, mid = 0, high = n - 1;
    while (mid <= high) {
        if (a[mid] == 0) {
            swap(&a[low], &a[mid]);
            low++; mid++;
        } else if (a[mid] == 2) {
            swap(&a[mid], &a[high]);
            high--;
        } else {
            mid++;
        }
    }
}

int main(void) {
    int a[] = {2, 0, 2, 1, 1, 0, 2, 1};
    sort_colors(a, 8);
    for (int i = 0; i < 8; i++) printf("%d ", a[i]);
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

// one pass, three moving boundaries
void sortColors(std::vector<int>& a) {
    int low = 0, mid = 0, high = (int)a.size() - 1;
    while (mid <= high) {
        if (a[mid] == 0)
            std::swap(a[low++], a[mid++]);
        else if (a[mid] == 2)
            std::swap(a[mid], a[high--]);   // mid stays: fresh value arrived
        else
            ++mid;                          // a 1 is already in place
    }
}

int main() {
    std::vector<int> a{2, 0, 2, 1, 1, 0, 2, 1};
    sortColors(a);
    for (int x : a) std::cout << x << ' ';   // 0 0 1 1 1 2 2 2
}`,
        },
        steps(nums) {
          const n = nums.length;
          const a = nums.slice();
          let low = 0, mid = 0, high = n - 1, swaps = 0;
          const steps = [];

          const states = () =>
            Array.from({ length: n }, (_, i) =>
              i < low ? "good" : i < mid ? "active" : i > high ? "result" : i === mid ? "read" : "idle");
          const tags = () => {
            const t = Array(n).fill(undefined);
            const put = (i, s) => { if (i >= 0 && i < n) t[i] = t[i] ? t[i] + "," + s : s; };
            if (mid <= high) { put(low, "low"); put(mid, "mid"); put(high, "high"); }
            return t;
          };
          const pointers = () => ({
            label: "pointers",
            cells: [
              { v: low, state: "good", tag: "low" },
              { v: mid, state: "read", tag: "mid" },
              { v: high, state: "result", tag: "high" },
            ],
          });
          const swapStates = (i, j) => {
            const s = states();
            [i, j].forEach((k) => { if (k >= 0 && k < n) s[k] = "swap"; });
            return s;
          };

          steps.push({
            title: "Set up: three regions in one row",
            tracks: [track("the numbers", nums, fill(n, "idle"))],
            counters: [count("swaps", 0), count("numbers placed", 0, n)],
            legend: ["good", "active", "read", "result", "swap", "idle"],
            happened: `The goal is the left end full of 0s, the middle full of 1s and the right end full of 2s — all in place.`,
            why: "Instead of sorting, we only have to decide which region each value belongs to.",
            codeLine: 5,
          });
          steps.push({
            title: `Pointers: low ${low}, mid ${mid}, high ${high}`,
            tracks: [track("the numbers", a, states(), tags()), pointers()],
            counters: [count("swaps", 0), count("numbers placed", 0, n)],
            happened: `mid starts at the left; low marks the 0-region and high marks the 2-region. Everything under mid is still unknown.`,
            why: "The three boundaries always tile the whole row, so no value can ever be lost.",
            codeLine: 6,
          });

          while (mid <= high) {
            const v = a[mid];
            if (v === 0) {
              steps.push({
                title: `0 under mid → swap it left to index ${low}`,
                tracks: [track("the numbers", a, swapStates(low, mid), tags()), pointers()],
                counters: [count("swaps", swaps + 1), count("numbers placed", low, n)],
                happened: `${v} at index ${mid} swaps with ${a[low]} at the 0-boundary.`,
                why: "A 0 belongs at the far left, so low and mid both move right afterwards.",
                codeLine: 9,
              });
              [a[low], a[mid]] = [a[mid], a[low]];
              swaps++; low++; mid++;
              steps.push({
                title: `low and mid advance → ${low}, ${mid}`,
                tracks: [track("the numbers", a, states(), tags()), pointers()],
                counters: [count("swaps", swaps), count("numbers placed", low, n)],
                happened: `Another 0 is locked on the left, so low and mid step forward together.`,
                why: "The value that moved to low is already known to be a 0 — no need to revisit it.",
                codeLine: 10,
              });
            } else if (v === 2) {
              steps.push({
                title: `2 under mid → swap it right to index ${high}`,
                tracks: [track("the numbers", a, swapStates(mid, high), tags()), pointers()],
                counters: [count("swaps", swaps + 1), count("numbers placed", n - 1 - high, n)],
                happened: `${v} at index ${mid} swaps with ${a[high]} at the 2-boundary.`,
                why: "A 2 belongs at the far right, so high pulls back and mid stays put.",
                codeLine: 12,
              });
              [a[mid], a[high]] = [a[high], a[mid]];
              swaps++; high--;
              steps.push({
                title: `high retreats → ${high}`,
                tracks: [track("the numbers", a, states(), tags()), pointers()],
                counters: [count("swaps", swaps), count("numbers placed", n - 1 - high, n)],
                happened: `high moves one step left; mid keeps its place.`,
                why: "The value swapped into mid came from the far right and has never been examined, so mid must look at it again.",
                codeLine: 13,
              });
            } else {
              mid++;
              steps.push({
                title: v === 1 ? `1 under mid → leave it, mid → ${mid}` : `${v} treated as a 1, mid → ${mid}`,
                tracks: [track("the numbers", a, states(), tags()), pointers()],
                counters: [count("swaps", swaps), count("numbers placed", mid - low, n)],
                happened: `The middle region already holds 1s, so this value can stay; mid simply walks forward.`,
                why: "No swap is needed because the value is already inside its correct region.",
                codeLine: 15,
              });
            }
          }

          steps.push({
            title: "Pointers crossed — every value is placed",
            tracks: [track("the numbers", a, fill(n, "done"))],
            counters: [count("swaps", swaps), count("numbers placed", n, n)],
            happened: `mid (${mid}) has passed high (${high}), so the unexamined middle is empty.`,
            why: "The three regions tile the row: [0,low) are 0s, [low,mid) are 1s and the rest are 2s.",
            codeLine: 7,
          });
          steps.push({
            title: `Answer: ${a.join(", ")}`,
            tracks: [track("the numbers", a, fill(n, "result"))],
            counters: [count("swaps", swaps), count("answer", a.join(", "))],
            happened: `One pass and ${swaps} swap${swaps === 1 ? "" : "s"} left the row sorted: ${a.join(", ")}.`,
            why: "Dutch-flag sorting finishes in a single scan and never needs a counting pass.",
            codeLine: 23,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     2. Merge Intervals
     ============================================================ */
  V.register({
    id: "merge-intervals",
    title: "Merge Intervals",
    category: "Sorting & Intervals",
    difficulty: "Intermediate",
    description: "Join every pair of intervals that overlap into single blocks.",
    input: { label: "Intervals (start,end)", default: "1,3 2,6 8,10 15,18", parse: "pairs" },
    approaches: [
      {
        name: "Sort by Start, Then Sweep",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Sort the intervals by their starting point. Now any interval that overlaps the current block must appear immediately after it.",
          "Keep one open block: if the next interval starts at or before the block's end, stretch the block's end; otherwise close the block and open a new one.",
        ],
        problem: [
          "The sort costs O(n log n) and you need the output list, so this is not in place. Without sorting, any interval could overlap any other and one sweep would not be enough.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int start, end; } Interval;

int by_start(const void *x, const void *y) {
    const Interval *a = x, *b = y;
    if (a->start != b->start) return a->start - b->start;
    return a->end - b->end;
}

/* intervals sorted by start; merge in one sweep */
int merge(Interval *v, int n, Interval *out) {
    int m = 0;
    for (int i = 0; i < n; i++) {
        if (m == 0 || v[i].start > out[m - 1].end)
            out[m++] = v[i];              /* gap: start a new block */
        else if (v[i].end > out[m - 1].end)
            out[m - 1].end = v[i].end;    /* overlap: stretch the end */
    }
    return m;
}

int main(void) {
    Interval v[] = {{1,3},{2,6},{8,10},{15,18}};
    int n = 4;
    qsort(v, n, sizeof(Interval), by_start);
    Interval out[4];
    int m = merge(v, n, out);
    for (int i = 0; i < m; i++) printf("[%d,%d] ", out[i].start, out[i].end);
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

std::vector<std::vector<int>> merge(std::vector<std::vector<int>> iv) {
    std::sort(iv.begin(), iv.end());
    std::vector<std::vector<int>> out;
    for (auto& cur : iv) {
        if (out.empty() || cur[0] > out.back()[1])
            out.push_back(cur);                  // gap: new block
        else
            out.back()[1] = std::max(out.back()[1], cur[1]);
    }
    return out;
}

int main() {
    for (auto& iv : merge({{1,3},{2,6},{8,10},{15,18}}))
        std::cout << '[' << iv[0] << ',' << iv[1] << "] "; // [1,6] [8,10] [15,18]
}`,
        },
        steps(pairs) {
          const n = pairs.length;
          const given = pairs.map(copyIv);
          const sorted = pairs.map(copyIv).sort((a, b) => a[0] - b[0] || a[1] - b[1]);
          const steps = [];
          let merged = [];
          const mergedTrack = () =>
            merged.length
              ? {
                  label: "merged blocks",
                  cells: merged.map((p, i) => ({ v: ivStr(p), state: i === merged.length - 1 ? "active" : "result" })),
                }
              : { label: "merged blocks", cells: [{ v: "∅", state: "idle", empty: true }] };

          steps.push({
            title: "Set up: sort first, then merge",
            tracks: [ivTrack("intervals (as given)", given, "idle"), { label: "merged blocks", cells: [{ v: "∅", state: "idle", empty: true }] }],
            counters: [count("intervals", n)],
            legend: ["compare", "active", "result", "dim", "idle"],
            happened: `There are ${n} interval${n === 1 ? "" : "s"} and they are in no useful order yet.`,
            why: "Sorting by start lines up the intervals so a single left-to-right sweep can catch every overlap.",
            codeLine: 12,
          });

          steps.push({
            title: `Sorted by start: ${sorted.map(ivStr).join(" ")}`,
            tracks: [
              ivTrack("intervals (as given)", given, "dim"),
              ivTrack("sorted by start", sorted, "good"),
              { label: "merged blocks", cells: [{ v: "∅", state: "idle", empty: true }] },
            ],
            counters: [count("intervals", n)],
            happened: `After sorting the order is ${sorted.map(ivStr).join(", ")}.`,
            why: "If the next interval starts after the current block ends, no later interval can reach back — one pass suffices.",
            codeLine: 26,
          });

          merged = [copyIv(sorted[0])];
          steps.push({
            title: `Open the first block with ${ivStr(sorted[0])}`,
            tracks: [
              ivTrack("sorted by start", sorted, (_, i) => (i === 0 ? "read" : "idle")),
              mergedTrack(),
            ],
            counters: [count("intervals seen", 1, n), count("blocks", merged.length)],
            happened: `The earliest interval ${ivStr(sorted[0])} becomes the block we are currently building.`,
            why: "Starting from the leftmost interval guarantees the block can only ever grow to the right.",
            codeLine: 14,
          });
          steps.push({
            title: "Now compare each later interval with the open block",
            tracks: [
              ivTrack("sorted by start", sorted, (_, i) => (i === 0 ? "done" : "idle")),
              mergedTrack(),
            ],
            counters: [count("intervals seen", 1, n), count("blocks", merged.length)],
            happened: "The open block is the only thing a new interval can touch, so that is all we compare against.",
            why: "This invariant is what removes the need to check every other pair.",
            codeLine: 15,
          });

          for (let i = 1; i < n; i++) {
            const cur = merged[merged.length - 1];
            const nxt = sorted[i];
            const curEnd = cur[1];
            if (nxt[0] <= curEnd) {
              cur[1] = Math.max(curEnd, nxt[1]);
              steps.push({
                title: `${ivStr(nxt)} starts at ${nxt[0]} ≤ ${curEnd} → merge`,
                tracks: [
                  ivTrack("sorted by start", sorted, (_, k) => (k < i ? "done" : k === i ? "compare" : "idle")),
                  mergedTrack(),
                ],
                counters: [count("intervals seen", i + 1, n), count("blocks", merged.length)],
                happened: `${ivStr(nxt)} overlaps the open block, so the block stretches to ${ivStr(cur)}.`,
                why: "Two overlapping intervals have to become one; taking the larger end covers both.",
                codeLine: 17,
              });
            } else {
              merged.push(copyIv(nxt));
              steps.push({
                title: `${ivStr(nxt)} starts after ${curEnd} → new block`,
                tracks: [
                  ivTrack("sorted by start", sorted, (_, k) => (k < i ? "done" : k === i ? "compare" : "idle")),
                  mergedTrack(),
                ],
                counters: [count("intervals seen", i + 1, n), count("blocks", merged.length)],
                happened: `There is a gap after ${curEnd}, so ${ivStr(nxt)} begins a fresh block.`,
                why: "A gap means the previous block can never grow again — it is finished.",
                codeLine: 15,
              });
            }
          }

          steps.push({
            title: `Answer: ${merged.map(ivStr).join(" ")}`,
            tracks: [
              ivTrack("intervals (as given)", given, "dim"),
              ivTrack("merged", merged, "result"),
            ],
            counters: [count("intervals", n), count("merged blocks", merged.length)],
            happened: `The sweep produced ${merged.length} block${merged.length === 1 ? "" : "s"}: ${merged.map(ivStr).join(", ")}.`,
            why: "Each interval was compared once with the open block — O(n log n) for the sort and O(n) for the sweep.",
            codeLine: 29,
          });
          return steps;
        },
      },
      {
        name: "Insert One Interval at a Time",
        complexity: "O(n²) time, O(n) space",
        idea: [
          "Keep a growing list that is always sorted and non-overlapping. Take the next interval and slot it into that list by hand.",
          "While slotting it in, any block it touches is absorbed and the block widens; blocks that do not touch it are copied across untouched.",
        ],
        problem: [
          "Every insertion scans the whole list, so the total work is quadratic. The sort-then-sweep version does the same job in O(n log n).",
        ],
        code: {
          c: `#include <stdio.h>
#define MAXN 20

typedef struct { int start, end; } Interval;

/* insert iv into a sorted, non-overlapping list out[0..m) */
int insert_one(Interval *out, int m, Interval iv) {
    Interval tmp[MAXN];
    int i = 0;
    while (i < m && out[i].end < iv.start) tmp[i] = out[i], i++;
    while (i < m && out[i].start <= iv.end) {       /* overlapping run */
        if (out[i].start < iv.start) iv.start = out[i].start;
        if (out[i].end   > iv.end)   iv.end   = out[i].end;
        i++;
    }
    int k = i;
    tmp[k++] = iv;                                  /* merged block */
    while (i < m) tmp[k++] = out[i++];
    for (i = 0; i < k; i++) out[i] = tmp[i];
    return k;
}

int main(void) {
    Interval in[] = {{1,3},{2,6},{8,10},{15,18}};
    Interval out[MAXN];
    int m = 0;
    for (int i = 0; i < 4; i++) m = insert_one(out, m, in[i]);
    for (int i = 0; i < m; i++) printf("[%d,%d] ", out[i].start, out[i].end);
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

// insert one interval into a sorted, non-overlapping list
std::vector<std::vector<int>> addBlock(std::vector<std::vector<int>> out, std::vector<int> iv) {
    std::vector<std::vector<int>> res;
    size_t i = 0;
    for (; i < out.size() && out[i][1] < iv[0]; ++i) res.push_back(out[i]);
    for (; i < out.size() && out[i][0] <= iv[1]; ++i) {
        iv[0] = std::min(iv[0], out[i][0]);
        iv[1] = std::max(iv[1], out[i][1]);
    }
    res.push_back(iv);
    for (; i < out.size(); ++i) res.push_back(out[i]);
    return res;
}

int main() {
    std::vector<std::vector<int>> out;
    for (auto& iv : {std::vector<int>{1,3}, {2,6}, {8,10}, {15,18}})
        out = addBlock(out, iv);
    for (auto& iv : out) std::cout << '[' << iv[0] << ',' << iv[1] << "] ";
}`,
        },
        steps(pairs) {
          const n = pairs.length;
          const given = pairs.map(copyIv);
          const steps = [];
          let out = [];
          const outTrack = () =>
            out.length
              ? { label: "merged blocks", cells: out.map((p, i) => ({ v: ivStr(p), state: i === out.length - 1 ? "active" : "result" })) }
              : { label: "merged blocks", cells: [{ v: "∅", state: "idle", empty: true }] };

          steps.push({
            title: "Set up: build the answer one interval at a time",
            tracks: [ivTrack("intervals (as given)", given, "idle"), { label: "merged blocks", cells: [{ v: "∅", state: "idle", empty: true }] }],
            counters: [count("intervals placed", 0, n), count("blocks", 0)],
            legend: ["read", "compare", "active", "result", "dim", "idle"],
            happened: `The ${n} interval${n === 1 ? "" : "s"} arrive in the given order and the result list starts empty.`,
            why: "Adding intervals one by one keeps the list sorted and non-overlapping after every single step.",
            codeLine: 6,
          });
          steps.push({
            title: "Empty list — the first interval will define it",
            tracks: [ivTrack("intervals (as given)", given, "idle"), outTrack()],
            counters: [count("intervals placed", 0, n), count("blocks", 0)],
            happened: "There are no blocks yet, so the first interval simply becomes the first block.",
            why: "Maintaining the sorted invariant from an empty list is the simplest possible start.",
            codeLine: 12,
          });

          for (let i = 0; i < n; i++) {
            const iv = copyIv(given[i]);
            const { res, overlappedWith, merged } = insertIntervalInto(out, iv);
            steps.push({
              title: `Look at ${ivStr(iv)} and find its place`,
              tracks: [
                ivTrack("intervals (as given)", given, (_, k) => (k < i ? "dim" : k === i ? "read" : "idle")),
                outTrack(),
                oneIv("incoming", iv, "compare", "insert this"),
              ],
              counters: [count("intervals placed", i, n), count("blocks", out.length)],
              happened: `We scan the existing blocks to see where ${ivStr(iv)} belongs.`,
              why: "Because the list is sorted, a single scan finds either a gap or a run of blocks to absorb.",
              codeLine: 8,
            });
            out = res;
            if (overlappedWith.length) {
              steps.push({
                title: `${ivStr(iv)} touches ${overlappedWith.map(ivStr).join(", ")} → merge to ${ivStr(merged)}`,
                tracks: [
                  ivTrack("intervals (as given)", given, (_, k) => (k <= i ? "done" : "idle")),
                  outTrack(),
                  oneIv("merged block", merged, "active", "new block"),
                ],
                counters: [count("intervals placed", i + 1, n), count("blocks", out.length)],
                happened: `${ivStr(iv)} overlapped ${overlappedWith.length} block${overlappedWith.length === 1 ? "" : "s"}, producing ${ivStr(merged)}.`,
                why: "Overlapping blocks are widened together until no neighbour touches the new one.",
                codeLine: 10,
              });
            } else {
              steps.push({
                title: `${ivStr(iv)} fits between blocks → insert unchanged`,
                tracks: [
                  ivTrack("intervals (as given)", given, (_, k) => (k <= i ? "done" : "idle")),
                  outTrack(),
                  oneIv("inserted", merged, "good", "no overlap"),
                ],
                counters: [count("intervals placed", i + 1, n), count("blocks", out.length)],
                happened: `${ivStr(iv)} did not touch any existing block, so it slots straight in.`,
                why: "A clean gap means the interval can stay exactly as it is.",
                codeLine: 8,
              });
            }
          }

          steps.push({
            title: `Answer: ${out.map(ivStr).join(" ")}`,
            tracks: [ivTrack("intervals (as given)", given, "dim"), ivTrack("merged", out, "result")],
            counters: [count("intervals placed", n, n), count("merged blocks", out.length)],
            happened: `All intervals were placed; the merged list is ${out.map(ivStr).join(", ")}.`,
            why: "Same result as the sweep, but the list was never sorted up front — each insert did its own scan.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     3. Insert Interval
     ============================================================ */
  V.register({
    id: "insert-interval",
    title: "Insert Interval",
    category: "Sorting & Intervals",
    difficulty: "Intermediate",
    description: "Drop one new interval into a sorted, non-overlapping set and repair the overlaps.",
    input: { label: "Sorted intervals, then the new one", default: "1,3 6,9 | 2,5", parse: "pairs" },
    approaches: [
      {
        name: "One Left-to-Right Pass",
        complexity: "O(n) time, O(n) space",
        idea: [
          "The intervals already come sorted by start. Copy every interval that ends before the new one begins — those can never touch it.",
          "Then swallow every interval that overlaps the new one, widening the new interval as you go. Finally copy the untouched tail.",
        ],
        problem: [
          "It relies on the input already being sorted and non-overlapping. If someone hands you jumbled intervals, this single pass quietly produces garbage.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct { int start, end; } Interval;

/* intervals sorted by start; insert one, merging as we go */
int insert(Interval *v, int n, Interval nw, Interval *out) {
    int m = 0, i = 0;
    while (i < n && v[i].end < nw.start)
        out[m++] = v[i++];                 /* entirely to the left */
    while (i < n && v[i].start <= nw.end) {
        if (v[i].start < nw.start) nw.start = v[i].start;
        if (v[i].end   > nw.end)   nw.end   = v[i].end;
        i++;                               /* overlap: widen the new block */
    }
    out[m++] = nw;
    while (i < n) out[m++] = v[i++];       /* everything to the right */
    return m;
}

int main(void) {
    Interval v[] = {{1,3},{6,9}};
    Interval out[10];
    Interval nw = {2, 5};
    int m = insert(v, 2, nw, out);
    for (int i = 0; i < m; i++) printf("[%d,%d] ", out[i].start, out[i].end);
    printf("\\n"); /* [1,5] [6,9] */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

std::vector<std::vector<int>> insert(std::vector<std::vector<int>> v, std::vector<int> nw) {
    std::vector<std::vector<int>> out;
    size_t i = 0;
    for (; i < v.size() && v[i][1] < nw[0]; ++i) out.push_back(v[i]);
    for (; i < v.size() && v[i][0] <= nw[1]; ++i) {
        nw[0] = std::min(nw[0], v[i][0]);
        nw[1] = std::max(nw[1], v[i][1]);
    }
    out.push_back(nw);
    for (; i < v.size(); ++i) out.push_back(v[i]);
    return out;
}

int main() {
    for (auto& iv : insert({{1,3},{6,9}}, {2,5}))
        std::cout << '[' << iv[0] << ',' << iv[1] << "] "; // [1,5] [6,9]
}`,
        },
        steps(pairs) {
          const all = pairs.map(copyIv);
          const newIv = all.length ? copyIv(all[all.length - 1]) : [0, 0];
          const existing = all.slice(0, Math.max(0, all.length - 1));
          const m = existing.length;
          const steps = [];
          const nw = copyIv(newIv);
          const out = [];
          const outTrack = () =>
            out.length
              ? { label: "result", cells: out.map((p, i) => ({ v: ivStr(p), state: i === out.length - 1 ? "active" : "result" })) }
              : { label: "result", cells: [{ v: "∅", state: "idle", empty: true }] };

          steps.push({
            title: "Set up: the list is sorted, one new interval arrives",
            tracks: [
              ivTrack("existing intervals", existing, "idle"),
              oneIv("new interval", nw, "compare", "to insert"),
              { label: "result", cells: [{ v: "∅", state: "idle", empty: true }] },
            ],
            counters: [count("existing intervals", m), count("copied", 0, m)],
            legend: ["read", "compare", "active", "result", "good", "dim", "idle"],
            happened: existing.length
              ? `There are ${m} sorted interval${m === 1 ? "" : "s"} and the new interval ${ivStr(nw)} must join them.`
              : `There are no existing intervals, so only ${ivStr(nw)} has to be placed.`,
            why: "Because the list is sorted, the intervals we keep whole are exactly the ones before and after the overlap window.",
            codeLine: 5,
          });

          steps.push({
            title: `Phase 1 — copy every interval that ends before ${nw[0]}`,
            tracks: [ivTrack("existing intervals", existing, "idle"), oneIv("new interval", nw, "compare"), outTrack()],
            counters: [count("existing intervals", m), count("copied", 0, m)],
            happened: `An interval ending before ${nw[0]} is entirely to the left of the new one, so it can never overlap.`,
            why: "Copying these straight across is safe and needs no comparison beyond the end point.",
            codeLine: 6,
          });

          let i = 0;
          let copiedAny = false;
          while (i < m && existing[i][1] < nw[0]) {
            out.push(copyIv(existing[i]));
            copiedAny = true;
            steps.push({
              title: `${ivStr(existing[i])} ends at ${existing[i][1]} < ${nw[0]} → copy`,
              tracks: [
                ivTrack("existing intervals", existing, (_, k) => (k < i ? "dim" : k === i ? "read" : "idle")),
                oneIv("new interval", nw, "compare"),
                outTrack(),
              ],
              counters: [count("existing intervals", m), count("copied", out.length, m)],
              happened: `${ivStr(existing[i])} passes straight into the result.`,
              why: "It lies fully left of the new interval, so it is already final.",
              codeLine: 6,
            });
            i++;
          }
          if (!copiedAny) {
            steps.push({
              title: `No interval ends before ${nw[0]} — nothing copied here`,
              tracks: [ivTrack("existing intervals", existing, "idle"), oneIv("new interval", nw, "compare"), outTrack()],
              counters: [count("existing intervals", m), count("copied", 0, m)],
              happened: `The very first existing interval already reaches ${nw[0]}, so the left phase is empty.`,
              why: "Fillers, not work: any number of intervals can fall into this left region.",
              codeLine: 7,
            });
          }

          steps.push({
            title: "Phase 2 — absorb every interval that overlaps the new one",
            tracks: [ivTrack("existing intervals", existing, (_, k) => (k < i ? "dim" : "idle")), oneIv("new interval", nw, "compare"), outTrack()],
            counters: [count("existing intervals", m), count("copied", out.length, m)],
            happened: "Now any interval starting at or before the new interval's end is part of the same block.",
            why: "Each absorbed interval can only push the block's end further right, never left.",
            codeLine: 8,
          });

          let touchedAny = false;
          while (i < m && existing[i][0] <= nw[1]) {
            const before = ivStr(nw);
            nw[0] = Math.min(nw[0], existing[i][0]);
            nw[1] = Math.max(nw[1], existing[i][1]);
            touchedAny = true;
            steps.push({
              title: `${ivStr(existing[i])} overlaps → new interval becomes ${ivStr(nw)}`,
              tracks: [
                ivTrack("existing intervals", existing, (_, k) => (k < i ? "dim" : k === i ? "read" : "idle")),
                oneIv("new interval", nw, "active", "widened"),
                outTrack(),
              ],
              counters: [count("existing intervals", m), count("merged", i + 1 - out.length)],
              happened: `${ivStr(existing[i])} touched ${before}, so the block widened to ${ivStr(nw)}.`,
              why: "Swallowing the neighbour and extending both bounds keeps the block a single interval.",
              codeLine: 10,
            });
            i++;
          }
          if (!touchedAny) {
            steps.push({
              title: `Nothing overlaps ${ivStr(nw)}`,
              tracks: [ivTrack("existing intervals", existing, (_, k) => (k < i ? "dim" : "idle")), oneIv("new interval", nw, "compare"), outTrack()],
              counters: [count("existing intervals", m), count("merged", 0)],
              happened: `No existing interval touches ${ivStr(nw)}, so it stays exactly as it arrived.`,
              why: "An empty overlap window just means the new interval sits neatly in a gap.",
              codeLine: 9,
            });
          }

          out.push(copyIv(nw));
          steps.push({
            title: `Place the settled interval ${ivStr(nw)}`,
            tracks: [
              ivTrack("existing intervals", existing, (_, k) => (k < i ? "dim" : "idle")),
              oneIv("new interval", nw, "good", "final"),
              outTrack(),
            ],
            counters: [count("existing intervals", m), count("copied", out.length, m)],
            happened: `${ivStr(nw)} is now complete and joins the result.`,
            why: "Once every overlapping neighbour is absorbed, the block cannot grow any further.",
            codeLine: 11,
          });

          steps.push({
            title: `Phase 3 — copy everything that starts after ${nw[1]}`,
            tracks: [ivTrack("existing intervals", existing, (_, k) => (k < i ? "dim" : "idle")), outTrack()],
            counters: [count("existing intervals", m), count("copied", out.length, m)],
            happened: `Any remaining interval begins after ${nw[1]}, so it is untouched by the new block.`,
            why: "The sorted order guarantees there can be no more overlaps once we are past the new end.",
            codeLine: 12,
          });

          let rightAny = false;
          while (i < m) {
            out.push(copyIv(existing[i]));
            rightAny = true;
            steps.push({
              title: `${ivStr(existing[i])} starts at ${existing[i][0]} > ${nw[1]} → copy`,
              tracks: [
                ivTrack("existing intervals", existing, (_, k) => (k < i ? "dim" : k === i ? "read" : "idle")),
                outTrack(),
              ],
              counters: [count("existing intervals", m), count("copied", out.length, m)],
              happened: `${ivStr(existing[i])} passes into the result unchanged.`,
              why: "It lies fully to the right of the merged block.",
              codeLine: 13,
            });
            i++;
          }
          if (!rightAny) {
            steps.push({
              title: `Nothing lies to the right of ${ivStr(nw)}`,
              tracks: [ivTrack("existing intervals", existing, "dim"), outTrack()],
              counters: [count("existing intervals", m), count("copied", out.length, m)],
              happened: "The new interval was the last block in the list, so the tail is empty.",
              why: "The three phases together still describe the whole result.",
              codeLine: 13,
            });
          }

          steps.push({
            title: `Answer: ${out.map(ivStr).join(" ")}`,
            tracks: [ivTrack("existing intervals", existing, "dim"), ivTrack("result", out, "result")],
            counters: [count("existing intervals", m), count("answer", out.map(ivStr).join(" "))],
            happened: `After one pass the set reads ${out.map(ivStr).join(", ")}.`,
            why: "Left copies, overlap merges and right copies together rebuild the list in O(n).",
            codeLine: 15,
          });
          return steps;
        },
      },
      {
        name: "Append, Sort, Merge",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Throw the new interval onto the end of the list, then sort the whole thing by start point.",
          "Now it is exactly the merge-intervals problem: sweep once and join any block that overlaps the one before it.",
        ],
        problem: [
          "Sorting costs O(n log n) where the linear pass would do, but it does not care whether the input was sorted to begin with.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int start, end; } Interval;

int by_start(const void *x, const void *y) {
    const Interval *a = x, *b = y;
    return a->start - b->start;
}

/* append the new interval, sort, then merge neighbours */
int insert(Interval *v, int n, Interval nw, Interval *out) {
    v[n] = nw;                       /* n is the capacity left for the new one */
    qsort(v, n + 1, sizeof(Interval), by_start);
    int m = 0;
    for (int i = 0; i <= n; i++) {
        if (m == 0 || v[i].start > out[m - 1].end)
            out[m++] = v[i];
        else if (v[i].end > out[m - 1].end)
            out[m - 1].end = v[i].end;
    }
    return m;
}

int main(void) {
    Interval v[3] = {{1,3},{6,9}};
    Interval out[3];
    Interval nw = {2, 5};
    int m = insert(v, 2, nw, out);
    for (int i = 0; i < m; i++) printf("[%d,%d] ", out[i].start, out[i].end);
    printf("\\n"); /* [1,5] [6,9] */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

std::vector<std::vector<int>> insert(std::vector<std::vector<int>> v, std::vector<int> nw) {
    v.push_back(nw);
    std::sort(v.begin(), v.end());
    std::vector<std::vector<int>> out;
    for (auto& cur : v) {
        if (out.empty() || cur[0] > out.back()[1])
            out.push_back(cur);
        else
            out.back()[1] = std::max(out.back()[1], cur[1]);
    }
    return out;
}

int main() {
    for (auto& iv : insert({{1,3},{6,9}}, {2,5}))
        std::cout << '[' << iv[0] << ',' << iv[1] << "] "; // [1,5] [6,9]
}`,
        },
        steps(pairs) {
          const all = pairs.map(copyIv);
          const newIv = all.length ? copyIv(all[all.length - 1]) : [0, 0];
          const existing = all.slice(0, Math.max(0, all.length - 1));
          const steps = [];

          steps.push({
            title: "Set up: put the new interval into the list",
            tracks: [ivTrack("existing intervals", existing, "idle"), oneIv("new interval", newIv, "compare", "to add")],
            counters: [count("existing intervals", existing.length)],
            legend: ["read", "compare", "active", "result", "good", "dim", "idle"],
            happened: `We start with ${existing.length} interval${existing.length === 1 ? "" : "s"} and must also place ${ivStr(newIv)}.`,
            why: "This approach makes no assumption that the existing list is sorted — it fixes that itself.",
            codeLine: 11,
          });

          const list = existing.map(copyIv).concat([copyIv(newIv)]);
          steps.push({
            title: `Append ${ivStr(newIv)} → ${list.length} intervals`,
            tracks: [ivTrack("combined list", list, (_, i) => (i === list.length - 1 ? "read" : "dim"))],
            counters: [count("intervals", list.length)],
            happened: `The new interval becomes the last element: ${list.map(ivStr).join(", ")}.`,
            why: "Appending is a cheap way to get everything into one collection to work on.",
            codeLine: 12,
          });

          const sorted = list.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]);
          steps.push({
            title: `Sort by start: ${sorted.map(ivStr).join(" ")}`,
            tracks: [ivTrack("sorted combined list", sorted, "good")],
            counters: [count("intervals", sorted.length)],
            happened: `Sorting lines everything up by its start point.`,
            why: "Now any overlap can only happen between an interval and the block right before it.",
            codeLine: 12,
          });

          const out = [copyIv(sorted[0])];
          steps.push({
            title: `Open a block with ${ivStr(sorted[0])}`,
            tracks: [ivTrack("sorted combined list", sorted, (_, i) => (i === 0 ? "read" : "idle")), ivTrack("merged", out, "active")],
            counters: [count("intervals seen", 1, sorted.length), count("blocks", out.length)],
            happened: `${ivStr(sorted[0])} is the leftmost interval, so it starts the sweep.`,
            why: "From here the merge is identical to the plain merge-intervals sweep.",
            codeLine: 15,
          });

          for (let i = 1; i < sorted.length; i++) {
            const cur = out[out.length - 1];
            const nxt = sorted[i];
            const curEnd = cur[1];
            if (nxt[0] <= curEnd) {
              cur[1] = Math.max(curEnd, nxt[1]);
              steps.push({
                title: `${ivStr(nxt)} overlaps → block becomes ${ivStr(cur)}`,
                tracks: [
                  ivTrack("sorted combined list", sorted, (_, k) => (k < i ? "done" : k === i ? "compare" : "idle")),
                  ivTrack("merged", out, (_, k) => (k === out.length - 1 ? "active" : "result")),
                ],
                counters: [count("intervals seen", i + 1, sorted.length), count("blocks", out.length)],
                happened: `${ivStr(nxt)} starts at ${nxt[0]} ≤ ${curEnd}, so the block widens to ${ivStr(cur)}.`,
                why: "Overlaps always collapse into the running block; the sort made them neighbours.",
                codeLine: 17,
              });
            } else {
              out.push(copyIv(nxt));
              steps.push({
                title: `${ivStr(nxt)} starts after ${curEnd} → new block`,
                tracks: [
                  ivTrack("sorted combined list", sorted, (_, k) => (k < i ? "done" : k === i ? "compare" : "idle")),
                  ivTrack("merged", out, (_, k) => (k === out.length - 1 ? "active" : "result")),
                ],
                counters: [count("intervals seen", i + 1, sorted.length), count("blocks", out.length)],
                happened: `A gap separates the two, so ${ivStr(nxt)} starts its own block.`,
                why: "Past a gap, the old block can never grow again.",
                codeLine: 15,
              });
            }
          }

          steps.push({
            title: `Answer: ${out.map(ivStr).join(" ")}`,
            tracks: [ivTrack("existing intervals", existing, "dim"), ivTrack("merged", out, "result")],
            counters: [count("intervals", sorted.length), count("answer", out.map(ivStr).join(" "))],
            happened: `After sorting and one sweep the set reads ${out.map(ivStr).join(", ")}.`,
            why: "Same answer as the linear pass, but no sorted input was ever required.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     4. Non Overlapping Intervals
     ============================================================ */
  V.register({
    id: "non-overlapping-intervals",
    title: "Non Overlapping Intervals",
    category: "Sorting & Intervals",
    difficulty: "Intermediate",
    description: "Remove the fewest intervals so that none of the rest overlap.",
    input: { label: "Intervals (start,end)", default: "1,2 2,3 3,4 1,3", parse: "pairs" },
    approaches: [
      {
        name: "Sort by End, Keep the Earliest Finisher",
        complexity: "O(n log n) time, O(1) extra space",
        idea: [
          "Sort the intervals by their finishing point. Keep the first one and remember when it ends.",
          "Walk on: an interval that starts before that end clashes and must be removed; one that starts at or after it is compatible and is kept, updating the end.",
        ],
        problem: [
          "Picking by earliest end is a greedy rule, so it is worth trusting only because it can be proved: finishing early leaves the most room for everything after it.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int start, end; } Interval;

int by_end(const void *x, const void *y) {
    const Interval *a = x, *b = y;
    return (a->end > b->end) - (a->end < b->end);
}

int erase_overlap(Interval *v, int n) {
    if (n == 0) return 0;
    qsort(v, n, sizeof(Interval), by_end);
    int removed = 0, lastEnd = v[0].end;
    for (int i = 1; i < n; i++) {
        if (v[i].start < lastEnd)
            removed++;                   /* clashes with a kept interval */
        else
            lastEnd = v[i].end;          /* compatible: keep and extend */
    }
    return removed;
}

int main(void) {
    Interval v[] = {{1,2},{2,3},{3,4},{1,3}};
    printf("%d\\n", erase_overlap(v, 4)); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int eraseOverlap(std::vector<std::vector<int>> v) {
    if (v.empty()) return 0;
    std::sort(v.begin(), v.end(),
              [](const std::vector<int>& a, const std::vector<int>& b) { return a[1] < b[1]; });
    int removed = 0, lastEnd = v[0][1];
    for (size_t i = 1; i < v.size(); ++i) {
        if (v[i][0] < lastEnd)
            ++removed;                   // starts before the last kept end
        else
            lastEnd = v[i][1];           // compatible
    }
    return removed;
}

int main() {
    std::cout << eraseOverlap({{1,2},{2,3},{3,4},{1,3}}) << '\\n'; // 1
}`,
        },
        steps(pairs) {
          const n = pairs.length;
          const given = pairs.map(copyIv);
          const sorted = pairs.map(copyIv).sort((a, b) => a[1] - b[1] || a[0] - b[0]);
          const steps = [];
          const kept = [];
          const st = fill(n, "idle");
          let removed = 0;
          const stShow = (hot) => {
            const s = st.slice();
            if (hot >= 0 && hot < n) s[hot] = "read";
            return s;
          };
          const keptTrack = () =>
            kept.length
              ? { label: "kept so far", cells: kept.map((p) => ({ v: ivStr(p), state: "good" })) }
              : { label: "kept so far", cells: [{ v: "∅", state: "idle", empty: true }] };

          steps.push({
            title: "Set up: remove as few intervals as possible",
            tracks: [ivTrack("intervals (as given)", given, "idle"), keptTrack()],
            counters: [count("intervals", n), count("removed", 0)],
            legend: ["read", "compare", "good", "bad", "dim", "idle"],
            happened: `There are ${n} interval${n === 1 ? "" : "s"}; some may overlap and have to be dropped.`,
            why: "Any two intervals that share a point cannot both stay, so every clash forces a removal.",
            codeLine: 11,
          });

          steps.push({
            title: `Sorted by end: ${sorted.map(ivStr).join(" ")}`,
            tracks: [ivTrack("sorted by end", sorted, "good")],
            counters: [count("intervals", n), count("removed", 0)],
            happened: `Sorting by finishing point gives ${sorted.map(ivStr).join(", ")}.`,
            why: "Keeping the interval that finishes soonest leaves the greatest room for later intervals.",
            codeLine: 13,
          });

          kept.push(copyIv(sorted[0]));
          st[0] = "good";
          let lastEnd = sorted[0][1];
          steps.push({
            title: `Keep ${ivStr(sorted[0])} — it finishes first`,
            tracks: [ivTrack("sorted by end", sorted, stShow(0)), keptTrack()],
            counters: [count("intervals", n), count("kept", kept.length), count("removed", removed)],
            happened: `The earliest finisher ${ivStr(sorted[0])} is always safe to keep.`,
            why: "Nothing that starts later can clash with it more than with any other first choice.",
            codeLine: 14,
          });

          for (let i = 1; i < n; i++) {
            const iv = sorted[i];
            if (iv[0] < lastEnd) {
              removed++;
              st[i] = "bad";
              steps.push({
                title: `${ivStr(iv)} starts at ${iv[0]} < ${lastEnd} → remove`,
                tracks: [ivTrack("sorted by end", sorted, stShow(i)), keptTrack()],
                counters: [count("intervals", n), count("kept", kept.length), count("removed", removed)],
                happened: `${ivStr(iv)} begins before the last kept interval ends at ${lastEnd}, so it clashes.`,
                why: "When two overlap, dropping the later finisher keeps the best possible end point.",
                codeLine: 17,
              });
            } else {
              const prevEnd = lastEnd;
              kept.push(copyIv(iv));
              lastEnd = iv[1];
              st[i] = "good";
              steps.push({
                title: `${ivStr(iv)} starts at ${iv[0]} ≥ ${prevEnd} → keep`,
                tracks: [ivTrack("sorted by end", sorted, stShow(i)), keptTrack()],
                counters: [count("intervals", n), count("kept", kept.length), count("removed", removed)],
                happened: `${ivStr(iv)} starts at or after ${prevEnd}, so it is compatible and kept.`,
                why: "Extending the last end to this interval's end keeps the invariant valid.",
                codeLine: 19,
              });
            }
          }

          steps.push({
            title: `Sweep finished: ${kept.length} kept, ${removed} removed`,
            tracks: [ivTrack("sorted by end", sorted, st), ivTrack("kept", kept, "good")],
            counters: [count("intervals", n), count("kept", kept.length), count("removed", removed)],
            happened: `Every interval was examined once; ${kept.length} survived and ${removed} were dropped.`,
            why: "No overlap remains among the kept intervals, by construction.",
            codeLine: 14,
          });
          steps.push({
            title: `Answer: remove ${removed} interval${removed === 1 ? "" : "s"}`,
            tracks: [ivTrack("sorted by end", sorted, st), ivTrack("kept", kept, "result")],
            counters: [count("intervals", n), count("answer", removed)],
            happened: `The fewest possible removals is ${removed}; the kept set is ${kept.map(ivStr).join(", ")}.`,
            why: "Greedily keeping each earliest finisher is optimal, proved by an exchange argument.",
            codeLine: 20,
          });
          return steps;
        },
      },
      {
        name: "Sort by Start, Drop the Longer Interval",
        complexity: "O(n log n) time, O(1) extra space",
        idea: [
          "Sort by starting point instead. Whenever the next interval clashes with the last kept one, exactly one of the two must go.",
          "Drop whichever ends later: if the new interval ends earlier it is the better keeper, so the older one is swapped out.",
        ],
        problem: [
          "It is easy to get this version subtly wrong by forgetting to replace the kept interval when the newcomer finishes earlier. The sort-by-end rule avoids that whole decision.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int start, end; } Interval;

int by_start(const void *x, const void *y) {
    const Interval *a = x, *b = y;
    return (a->start > b->start) - (a->start < b->start);
}

/* sort by start; when two clash, drop the one that ends later */
int erase_overlap(Interval *v, int n) {
    if (n == 0) return 0;
    qsort(v, n, sizeof(Interval), by_start);
    int removed = 0, lastEnd = v[0].end;
    for (int i = 1; i < n; i++) {
        if (v[i].start < lastEnd) {
            removed++;
            if (v[i].end < lastEnd) lastEnd = v[i].end;  /* keep the shorter */
        } else {
            lastEnd = v[i].end;
        }
    }
    return removed;
}

int main(void) {
    Interval v[] = {{1,2},{2,3},{3,4},{1,3}};
    printf("%d\\n", erase_overlap(v, 4)); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int eraseOverlap(std::vector<std::vector<int>> v) {
    if (v.empty()) return 0;
    std::sort(v.begin(), v.end(),
              [](const std::vector<int>& a, const std::vector<int>& b) { return a[0] < b[0]; });
    int removed = 0, lastEnd = v[0][1];
    for (size_t i = 1; i < v.size(); ++i) {
        if (v[i][0] < lastEnd) {
            ++removed;                          // one of the two must go
            lastEnd = std::min(lastEnd, v[i][1]); // keep the shorter one
        } else {
            lastEnd = v[i][1];
        }
    }
    return removed;
}

int main() {
    std::cout << eraseOverlap({{1,2},{2,3},{3,4},{1,3}}) << '\\n'; // 1
}`,
        },
        steps(pairs) {
          const n = pairs.length;
          const given = pairs.map(copyIv);
          const sorted = pairs.map(copyIv).sort((a, b) => a[0] - b[0] || a[1] - b[1]);
          const steps = [];
          const kept = [];
          const st = fill(n, "idle");
          let removed = 0;
          const stShow = (hot) => {
            const s = st.slice();
            if (hot >= 0 && hot < n) s[hot] = "read";
            return s;
          };
          const keptTrack = () =>
            kept.length
              ? { label: "kept so far", cells: kept.map((p) => ({ v: ivStr(p), state: "good" })) }
              : { label: "kept so far", cells: [{ v: "∅", state: "idle", empty: true }] };

          steps.push({
            title: "Set up: sort by start this time",
            tracks: [ivTrack("intervals (as given)", given, "idle"), keptTrack()],
            counters: [count("intervals", n), count("removed", 0)],
            legend: ["read", "compare", "good", "bad", "dim", "idle"],
            happened: `Again we may only keep intervals that share no point, but the ordering rule changes.`,
            why: "Sorting by start puts clashing intervals next to each other, where one of them can be discarded.",
            codeLine: 11,
          });
          steps.push({
            title: `Sorted by start: ${sorted.map(ivStr).join(" ")}`,
            tracks: [ivTrack("sorted by start", sorted, "good")],
            counters: [count("intervals", n), count("removed", 0)],
            happened: `The order is now ${sorted.map(ivStr).join(", ")}.`,
            why: "Any overlap can only occur between an interval and the last one we decided to keep.",
            codeLine: 13,
          });

          kept.push(copyIv(sorted[0]));
          st[0] = "good";
          let lastEnd = sorted[0][1];
          steps.push({
            title: `Keep ${ivStr(sorted[0])} to start the run`,
            tracks: [ivTrack("sorted by start", sorted, stShow(0)), keptTrack()],
            counters: [count("intervals", n), count("kept", kept.length), count("removed", removed)],
            happened: `The first interval is kept, with end ${lastEnd}.`,
            why: "A run of compatible intervals has to start somewhere; the leftmost is as good as any.",
            codeLine: 14,
          });

          for (let i = 1; i < n; i++) {
            const iv = sorted[i];
            if (iv[0] < lastEnd) {
              removed++;
              st[i] = "bad";
              const better = iv[1] < lastEnd;
              if (better) {
                kept.pop();
                kept.push(copyIv(iv));
                st[i] = "good";
                const oldEnd = lastEnd;
                lastEnd = iv[1];
                steps.push({
                  title: `${ivStr(iv)} clashes but ends sooner → swap keepers`,
                  tracks: [ivTrack("sorted by start", sorted, stShow(i)), keptTrack()],
                  counters: [count("intervals", n), count("kept", kept.length), count("removed", removed)],
                  happened: `${ivStr(iv)} overlaps the kept interval ending at ${oldEnd}, but finishes at ${lastEnd} instead.`,
                  why: "Keeping the earlier finisher frees up more room, so the older keeper is dropped and one removal is counted.",
                  codeLine: 18,
                });
              } else {
                steps.push({
                  title: `${ivStr(iv)} clashes and ends later → drop it`,
                  tracks: [ivTrack("sorted by start", sorted, stShow(i)), keptTrack()],
                  counters: [count("intervals", n), count("kept", kept.length), count("removed", removed)],
                  happened: `${ivStr(iv)} overlaps the kept end at ${lastEnd} and finishes at ${iv[1]}, no earlier.`,
                  why: "Dropping the later finisher keeps the current end as small as possible.",
                  codeLine: 17,
                });
              }
            } else {
              const prevEnd = lastEnd;
              kept.push(copyIv(iv));
              lastEnd = iv[1];
              st[i] = "good";
              steps.push({
                title: `${ivStr(iv)} starts at ${iv[0]} ≥ ${prevEnd} → keep`,
                tracks: [ivTrack("sorted by start", sorted, stShow(i)), keptTrack()],
                counters: [count("intervals", n), count("kept", kept.length), count("removed", removed)],
                happened: `${ivStr(iv)} starts after the last kept end, so it is compatible.`,
                why: "No clash means we keep it and move the end forward.",
                codeLine: 20,
              });
            }
          }

          steps.push({
            title: `Sweep finished: ${kept.length} kept, ${removed} removed`,
            tracks: [ivTrack("sorted by start", sorted, st), ivTrack("kept", kept, "good")],
            counters: [count("intervals", n), count("kept", kept.length), count("removed", removed)],
            happened: `${removed} interval${removed === 1 ? "" : "s"} had to go; ${kept.length} remain non-overlapping.`,
            why: "Every clash forced exactly one removal, and we always discarded the worse finisher.",
            codeLine: 14,
          });
          steps.push({
            title: `Answer: remove ${removed} interval${removed === 1 ? "" : "s"}`,
            tracks: [ivTrack("sorted by start", sorted, st), ivTrack("kept", kept, "result")],
            counters: [count("intervals", n), count("answer", removed)],
            happened: `The minimum number of removals is ${removed}, keeping ${kept.map(ivStr).join(", ")}.`,
            why: "Both greedy orders reach the same optimum here, which is a good sanity check.",
            codeLine: 21,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     5. Largest Number
     ============================================================ */
  V.register({
    id: "largest-number",
    title: "Largest Number",
    category: "Sorting & Intervals",
    difficulty: "Intermediate",
    description: "Arrange digits so their concatenation is as large as possible.",
    input: { label: "The numbers", default: "10, 2, 9, 39, 17", parse: "ints" },
    approaches: [
      {
        name: "Sort with a Concatenation Comparator",
        complexity: "O(n log n · k) time, O(n · k) space",
        idea: [
          "There is no ordinary sort order here. Instead, two numbers x and y are compared by gluing them into text: x before y is correct exactly when \"xy\" reads larger than \"yx\".",
          "Feed that rule to any comparison sort and the resulting order, read left to right, is the biggest possible number.",
        ],
        problem: [
          "Each comparison builds two temporary strings, so the constant factor is worse than a numeric sort. It also assumes the numbers are non-negative, since a minus sign breaks the \"xy bigger\" intuition.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { char s[12]; } Num;

/* x should come before y when "xy" reads bigger than "yx" */
int cmp(const void *px, const void *py) {
    const Num *a = px, *b = py;
    char ab[24], ba[24];
    sprintf(ab, "%s%s", a->s, b->s);
    sprintf(ba, "%s%s", b->s, a->s);
    return strcmp(ba, ab);            /* bigger first */
}

void largest_number(const int *v, int n, char *out) {
    Num t[20];
    for (int i = 0; i < n; i++) sprintf(t[i].s, "%d", v[i]);
    qsort(t, n, sizeof(Num), cmp);
    out[0] = '\\0';
    for (int i = 0; i < n; i++) strcat(out, t[i].s);
}

int main(void) {
    int v[] = {10, 2, 9, 39, 17};
    char out[256];
    largest_number(v, 5, out);
    printf("%s\\n", out); /* 93921710 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

std::string largestNumber(std::vector<int> v) {
    std::vector<std::string> s;
    for (int x : v) s.push_back(std::to_string(x));
    std::sort(s.begin(), s.end(), [](const std::string& a, const std::string& b) {
        return a + b > b + a;        // xy beats yx
    });
    std::string out;
    for (auto& t : s) out += t;
    if (out[0] == '0') return "0";   // all numbers were zero
    return out;
}

int main() {
    std::cout << largestNumber({10, 2, 9, 39, 17}) << '\\n'; // 93921710
}`,
        },
        steps(nums) {
          const n = nums.length;
          const s = nums.map(String);
          const a = s.slice();
          const steps = [];
          const better = (x, y) => x + y > y + x; // true when x must stand before y
          const cmpStates = (j) => {
            const st = fill(n, "dim");
            st[j] = "compare";
            st[j + 1] = "compare";
            return st;
          };

          steps.push({
            title: "Set up: compare numbers as glued text",
            tracks: [track("the numbers", s, fill(n, "idle"))],
            counters: [count("numbers", n)],
            legend: ["compare", "swap", "done", "result", "dim", "idle"],
            happened: `Numerical order is wrong here: 9 before 39 gives 939, but 39 before 9 gives only 399.`,
            why: "The right order depends on the concatenation, not on the values themselves.",
            codeLine: 7,
          });
          steps.push({
            title: "Rule: put x first when \"xy\" beats \"yx\"",
            tracks: [track("the numbers", s, fill(n, "idle"))],
            counters: [count("numbers", n)],
            happened: `For any two numbers we test both orders and keep the one that reads larger.`,
            why: "This single rule is enough; a comparison sort takes care of the rest.",
            codeLine: 11,
          });
          if (n <= 1) {
            steps.push({
              title: "Only one number — nothing to order",
              tracks: [track("the numbers", s, fill(n, "idle"))],
              counters: [count("numbers", n)],
              happened: `With ${n} number${n === 1 ? "" : "s"} the answer is already fixed.`,
              why: "A comparison needs two numbers, so no swaps can happen at all.",
              codeLine: 15,
            });
          }

          for (let pass = 0; pass < n - 1; pass++) {
            let swapped = false;
            for (let j = 0; j < n - 1 - pass; j++) {
              const x = a[j], y = a[j + 1];
              const keep = better(x, y);
              const ab = x + y, ba = y + x;
              steps.push({
                title: `"${x}" vs "${y}": ${ab} ${keep ? ">" : "<"} ${ba}`,
                tracks: [track("the numbers", a, cmpStates(j))],
                counters: [count("comparisons", pass * (n - 1) + j + 1), count("pass", pass + 1, Math.max(1, n - 1))],
                happened: `Gluing gives ${x}${y} = ${ab} and ${y}${x} = ${ba}, so ${keep ? x + " stays first" : y + " should come first"}.`,
                why: "The comparator turns a vague \"which is bigger\" into an exact string test.",
                codeLine: 9,
              });
              if (!keep) {
                [a[j], a[j + 1]] = [a[j + 1], a[j]];
                swapped = true;
                const st = fill(n, "dim");
                st[j] = "swap";
                st[j + 1] = "swap";
                steps.push({
                  title: `Swap → "${y}" before "${x}"`,
                  tracks: [track("the numbers", a, st)],
                  counters: [count("comparisons", pass * (n - 1) + j + 1)],
                  happened: `The pair trades places so the larger glue is formed.`,
                  why: "Bubble sort keeps pushing bad neighbours apart until none are left.",
                  codeLine: 12,
                });
              }
            }
            const st = fill(n, "done");
            for (let k = n - pass - 1; k < n; k++) st[k] = "result";
            steps.push({
              title: `Pass ${pass + 1} done — the tail is settling`,
              tracks: [track("the numbers", a, st)],
              counters: [count("comparisons", pass * (n - 1) + (n - 1 - pass), (n - 1) * n / 2)],
              happened: swapped ? `Some swaps happened in this pass.` : `No swaps happened, so the order is already settled.`,
              why: "The last position after each pass is final: nothing later can dislodge it.",
              codeLine: 15,
            });
          }

          steps.push({
            title: "Read the settled order left to right",
            tracks: [track("the numbers", a, fill(n, "done"))],
            counters: [count("numbers", n)],
            happened: `The row is now ${a.join(" → ")}.`,
            why: "No neighbouring pair can be improved, so gluing them in this order is the largest result.",
            codeLine: 19,
          });
          let joined = a.join("");
          if (/^0+$/.test(joined)) joined = "0";
          steps.push({
            title: `Answer: "${joined}"`,
            tracks: [track("the numbers", a, fill(n, "result"))],
            counters: [count("numbers", n), count("answer", joined)],
            happened: `Reading the settled order left to right gives ${joined}.`,
            why: "Any other arrangement would put a couple in the wrong order and yield a smaller number.",
            codeLine: 20,
          });
          return steps;
        },
      },
      {
        name: "Repeatedly Pick the Best Head",
        complexity: "O(n² · k) time, O(n · k) space",
        idea: [
          "Do not sort the whole row. Instead, repeatedly scan the numbers that are left and pick the one that should stand first.",
          "Glue the winner onto the answer and strike it off, then repeat until nothing is left. It is a selection sort driven by the same glue rule.",
        ],
        problem: [
          "Each pick rescans everything remaining, so this is quadratic. Sorting once up front does the same comparisons more cheaply.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

/* x should stand before y when "xy" reads bigger than "yx" */
int before(const char *x, const char *y) {
    char ab[24], ba[24];
    sprintf(ab, "%s%s", x, y);
    sprintf(ba, "%s%s", y, x);
    return strcmp(ab, ba) > 0;
}

void largest_number(const int *v, int n, char *out) {
    char s[20][12];
    int used[20] = {0};
    for (int i = 0; i < n; i++) sprintf(s[i], "%d", v[i]);
    out[0] = '\\0';
    for (int picked = 0; picked < n; picked++) {
        int best = -1;
        for (int i = 0; i < n; i++) {
            if (used[i]) continue;
            if (best < 0 || before(s[i], s[best])) best = i;
        }
        strcat(out, s[best]);
        used[best] = 1;
    }
}

int main(void) {
    int v[] = {10, 2, 9, 39, 17};
    char out[256];
    largest_number(v, 5, out);
    printf("%s\\n", out); /* 93921710 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <string>

std::string largestNumber(std::vector<int> v) {
    std::vector<std::string> s;
    for (int x : v) s.push_back(std::to_string(x));
    std::string out;
    while (!s.empty()) {
        size_t best = 0;
        for (size_t i = 1; i < s.size(); ++i)
            if (s[i] + s[best] > s[best] + s[i]) best = i; // s[i] should lead
        out += s[best];
        s.erase(s.begin() + best);
    }
    if (out[0] == '0') return "0";
    return out;
}

int main() {
    std::cout << largestNumber({10, 2, 9, 39, 17}) << '\\n'; // 93921710
}`,
        },
        steps(nums) {
          const n = nums.length;
          const s = nums.map(String);
          const remaining = s.slice();
          const chosen = [];
          const steps = [];
          const better = (x, y) => x + y > y + x;

          steps.push({
            title: "Set up: build the number head first",
            tracks: [track("numbers left", remaining, fill(remaining.length, "idle"))],
            counters: [count("picked", 0, n)],
            legend: ["compare", "read", "result", "dim", "idle"],
            happened: `${n} number${n === 1 ? "" : "s"} to place; the answer string starts empty.`,
            why: "Fixing the first character is the hardest choice, so we make it deliberately each round.",
            codeLine: 13,
          });
          steps.push({
            title: "Rule: the head is the one that beats all rivals",
            tracks: [track("numbers left", remaining, fill(remaining.length, "idle"))],
            counters: [count("picked", 0, n)],
            happened: `A candidate is the head when gluing it with every rival in both orders favours the candidate.`,
            why: "Scanning for that winner needs no full sort, just one pass per position.",
            codeLine: 16,
          });

          while (remaining.length) {
            steps.push({
              title: `Scan for the head among ${remaining.join(", ")}`,
              tracks: [track("numbers left", remaining, fill(remaining.length, "idle"))],
              counters: [count("picked", chosen.length, n)],
              happened: `The current best is tentatively ${remaining[0]}.`,
              why: "One pass over everything left finds the best possible next character.",
              codeLine: 17,
            });
            let best = 0;
            for (let k = 1; k < remaining.length; k++) {
              const win = better(remaining[k], remaining[best]);
              const st = remaining.map((_, idx) => (idx === best ? "read" : idx === k ? "compare" : "dim"));
              steps.push({
                title: win ? `"${remaining[k]}" beats "${remaining[best]}" → new best` : `"${remaining[k]}" loses to "${remaining[best]}"`,
                tracks: [track("numbers left", remaining, st)],
                counters: [count("picked", chosen.length, n), count("candidates seen", k, remaining.length)],
                happened: `Gluing gives ${remaining[k]}${remaining[best]} vs ${remaining[best]}${remaining[k]}.`,
                why: "Each rival is checked once, and only a strict win replaces the current best.",
                codeLine: 18,
              });
              if (win) best = k;
            }
            const pick = remaining[best];
            chosen.push(pick);
            remaining.splice(best, 1);
            steps.push({
              title: `Append "${pick}" → "${chosen.join("")}"…`,
              tracks: [
                track("numbers left", remaining, fill(remaining.length, "dim")),
                { label: "built so far", cells: chosen.map((v) => ({ v, state: v === pick ? "read" : "result" })) },
              ],
              counters: [count("picked", chosen.length, n)],
              happened: `The winner ${pick} is glued onto the answer and removed from the pool.`,
              why: "Because it beat every remaining rival, no later choice can improve its position.",
              codeLine: 19,
            });
          }

          let joined = chosen.join("");
          if (/^0+$/.test(joined)) joined = "0";
          steps.push({
            title: `Answer: "${joined}"`,
            tracks: [{ label: "built number", cells: chosen.map((v) => ({ v, state: "result" })) }],
            counters: [count("picked", n, n), count("answer", joined)],
            happened: `All numbers were placed one by one, giving ${joined}.`,
            why: "The same greedy rule as sorting, applied by selection instead of by ordering the whole row.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     6. Relative Sort Array
     ============================================================ */
  V.register({
    id: "relative-sort-array",
    title: "Relative Sort Array",
    category: "Sorting & Intervals",
    difficulty: "Beginner",
    description: "Order one row by a given key row, then sort whatever is left.",
    input: { label: "arr1 | arr2", default: "2,3,1,3,4,3 | 4,1,2,0", parse: "tworows" },
    approaches: [
      {
        name: "Count arr1, Emit in arr2 Order",
        complexity: "O(n + m + k) time, O(k) space",
        idea: [
          "Tally how often each value of arr1 appears. Then walk arr2 in order and, for every value, pour out that many copies.",
          "Anything arr1 contains that arr2 never mentions is appended at the end, sorted in ascending order.",
        ],
        problem: [
          "The tally wants a small, known range of values (the classic version uses 0..1000). With arbitrary integers you would need a hash map instead of an array.",
        ],
        code: {
          c: `#include <stdio.h>

/* counts assume values 0..1000, as the usual constraints guarantee */
int relative_sort(const int *a, int n, const int *b, int m, int *out) {
    int count[1001] = {0};
    for (int i = 0; i < n; i++) count[a[i]]++;
    int k = 0;
    for (int i = 0; i < m; i++)                 /* arr2 order first */
        while (count[b[i]] > 0) { out[k++] = b[i]; count[b[i]]--; }
    for (int v = 0; v <= 1000; v++)             /* leftovers ascending */
        while (count[v] > 0) { out[k++] = v; count[v]--; }
    return k;
}

int main(void) {
    int a[] = {2, 3, 1, 3, 4, 3};
    int b[] = {4, 1, 2, 0};
    int out[10];
    int k = relative_sort(a, 6, b, 4, out);
    for (int i = 0; i < k; i++) printf("%d ", out[i]); /* 4 1 2 3 3 3 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <map>

std::vector<int> relativeSort(const std::vector<int>& a, const std::vector<int>& b) {
    std::map<int, int> count;
    for (int x : a) ++count[x];
    std::vector<int> out;
    for (int v : b)
        while (count[v]-- > 0) out.push_back(v);   // arr2 order
    for (auto& [v, c] : count)
        for (int i = 0; i < c; i++) out.push_back(v); // leftovers ascending
    return out;
}

int main() {
    for (int x : relativeSort({2,3,1,3,4,3}, {4,1,2,0})) std::cout << x << ' ';
}`,
        },
        steps(rows) {
          const A = (rows && rows[0]) || [];
          const B = (rows && rows[1]) || [];
          const na = A.length;
          const tally = new Map();
          const result = [];
          const donneB = new Set();
          const steps = [];
          const tallyTrack = (hot) => ({
            label: "arr1 tally",
            cells: tally.size
              ? [...tally].map(([v, c]) => ({ v: `${v}×${c}`, state: v === hot ? "read" : "done" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });
          const resTrack = () => ({
            label: "result",
            cells: result.length
              ? result.map((v, i) => ({ v, state: i === result.length - 1 ? "read" : "result" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          steps.push({
            title: "Set up: one row to order, one row as the key",
            tracks: [
              track("arr1", A, fill(na, "idle")),
              track("arr2 (order)", B, fill(B.length, "idle")),
              { label: "arr1 tally", cells: [{ v: "∅", state: "idle", empty: true }] },
            ],
            counters: [count("arr1 values", na), count("arr2 values", B.length)],
            legend: ["read", "done", "result", "idle"],
            happened: `arr1 has ${na} value${na === 1 ? "" : "s"}; arr2 lists the order in which values must appear.`,
            why: "Counting arr1 once lets each value of arr2 be poured out without searching.",
            codeLine: 3,
          });

          for (let i = 0; i < na; i++) {
            tally.set(A[i], (tally.get(A[i]) || 0) + 1);
            steps.push({
              title: `${A[i]} counted → ${tally.get(A[i])} time${tally.get(A[i]) === 1 ? "" : "s"}`,
              tracks: [track("arr1", A, prog(na, i)), track("arr2 (order)", B, fill(B.length, "idle")), tallyTrack(A[i])],
              counters: [count("arr1 read", i + 1, na), count("distinct values", tally.size)],
              happened: `The tally for ${A[i]} grows to ${tally.get(A[i])}.`,
              why: "A tally answers \"how many copies?\" in one lookup later on.",
              codeLine: 5,
            });
          }

          steps.push({
            title: `Tally ready: ${[...tally].map(([v, c]) => `${v}×${c}`).join(", ")}`,
            tracks: [track("arr1", A, fill(na, "done")), track("arr2 (order)", B, fill(B.length, "idle")), tallyTrack(null)],
            counters: [count("arr1 read", na, na), count("distinct values", tally.size)],
            happened: `Every arr1 value is counted; now we know exactly how many of each to place.`,
            why: "The rest of the work is pure output order.",
            codeLine: 6,
          });

          steps.push({
            title: "Walk arr2 and pour out its values",
            tracks: [track("arr1", A, fill(na, "dim")), track("arr2 (order)", B, fill(B.length, "idle")), resTrack(), tallyTrack(null)],
            counters: [count("arr2 read", 0, B.length)],
            happened: "Each value of arr2 is taken in turn and all its copies are appended.",
            why: "Because arr2 is the key order, following it exactly is what 'relative' sorting means.",
            codeLine: 7,
          });

          for (let i = 0; i < B.length; i++) {
            const v = B[i];
            const c = tally.get(v) || 0;
            if (c > 0) {
              for (let k = 0; k < c; k++) result.push(v);
              tally.set(v, 0);
              donneB.add(v);
              steps.push({
                title: `${v} appears ${c}× → append ${c}`,
                tracks: [
                  track("arr1", A, fill(na, "dim")),
                  track("arr2 (order)", B, prog(B.length, i)),
                  resTrack(),
                  tallyTrack(v),
                ],
                counters: [count("arr2 read", i + 1, B.length), count("placed", result.length)],
                happened: `All ${c} cop${c === 1 ? "y" : "ies"} of ${v} are written into the result.`,
                why: "Pouring the whole group at once guarantees no value can appear twice out of order.",
                codeLine: 8,
              });
            } else {
              steps.push({
                title: `${v} is not in arr1 → nothing to append`,
                tracks: [
                  track("arr1", A, fill(na, "dim")),
                  track("arr2 (order)", B, prog(B.length, i)),
                  resTrack(),
                  tallyTrack(v),
                ],
                counters: [count("arr2 read", i + 1, B.length), count("placed", result.length)],
                happened: `${v} has no copies in arr1, so this key contributes nothing.`,
                why: "Keys that never appear simply leave the result unchanged.",
                codeLine: 8,
              });
            }
          }

          steps.push({
            title: "Append the leftovers in ascending order",
            tracks: [track("arr1", A, fill(na, "dim")), track("arr2 (order)", B, fill(B.length, "done")), resTrack()],
            counters: [count("arr2 read", B.length, B.length), count("placed", result.length)],
            happened: "Any arr1 value that arr2 forgot is still waiting; it must go last, sorted ascending.",
            why: "The leftover rule keeps the result deterministic instead of simply dumping them.",
            codeLine: 9,
          });

          const leftover = [...tally.keys()].filter((v) => !donneB.has(v)).sort((x, y) => x - y);
          if (leftover.length) {
            for (const v of leftover) {
              const c = tally.get(v);
              for (let k = 0; k < c; k++) result.push(v);
              tally.set(v, 0);
              steps.push({
                title: `leftover ${v} ×${c} → append`,
                tracks: [track("arr1", A, fill(na, "dim")), track("arr2 (order)", B, fill(B.length, "done")), resTrack()],
                counters: [count("leftovers handled", result.length), count("placed", result.length)],
                happened: `Unmentioned value ${v} appears ${c} time${c === 1 ? "" : "s"} and goes to the end.`,
                why: "Leftovers are sorted by value so the tail is ordered too.",
                codeLine: 10,
              });
            }
          } else {
            steps.push({
              title: "No leftovers — arr2 covered every value",
              tracks: [track("arr1", A, fill(na, "dim")), track("arr2 (order)", B, fill(B.length, "done")), resTrack()],
              counters: [count("arr2 read", B.length, B.length), count("placed", result.length)],
              happened: "Every arr1 value was mentioned by arr2, so nothing is left over.",
              why: "The result is already complete.",
              codeLine: 9,
            });
          }

          steps.push({
            title: `Answer: ${result.join(", ")}`,
            tracks: [track("arr1", A, fill(na, "dim")), track("result", result, "result")],
            counters: [count("arr1 values", na), count("answer", result.join(", "))],
            happened: `Arranging by arr2 and appending leftovers gives ${result.join(", ")}.`,
            why: "A tally plus one ordered pass builds the answer in linear-ish time.",
            codeLine: 11,
          });
          return steps;
        },
      },
      {
        name: "Sort by Rank, Then Value",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Give every value a rank: its position in arr2, or a rank past the end if arr2 never mentions it.",
          "Sort arr1 so that smaller ranks come first, and ties are broken by the value itself — that is exactly the required order.",
        ],
        problem: [
          "Each rank lookup scans arr2, so a careless version is O(n·m) before the sort even starts. The tally approach avoids that scanning entirely.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

static const int *B; static int M;   /* key array, shared by the comparator */

/* position of v in arr2, or M when it is not listed */
static int rank_of(int v) {
    for (int i = 0; i < M; i++)
        if (B[i] == v) return i;
    return M;
}

int cmp(const void *px, const void *py) {
    int x = *(const int *)px, y = *(const int *)py;
    int rx = rank_of(x), ry = rank_of(y);
    if (rx != ry) return rx - ry;    /* arr2 order wins */
    return x - y;                    /* leftovers: ascending value */
}

void relative_sort(int *a, int n, const int *b, int m) {
    B = b; M = m;
    qsort(a, n, sizeof(int), cmp);
}

int main(void) {
    int a[] = {2, 3, 1, 3, 4, 3};
    int b[] = {4, 1, 2, 0};
    relative_sort(a, 6, b, 4);
    for (int i = 0; i < 6; i++) printf("%d ", a[i]); /* 4 1 2 3 3 3 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

std::vector<int> relativeSort(std::vector<int> a, const std::vector<int>& b) {
    auto rankOf = [&](int v) {
        auto it = std::find(b.begin(), b.end(), v);
        return it == b.end() ? (int)b.size() : (int)(it - b.begin());
    };
    std::stable_sort(a.begin(), a.end(), [&](int x, int y) {
        int rx = rankOf(x), ry = rankOf(y);
        return rx != ry ? rx < ry : x < y;
    });
    return a;
}

int main() {
    for (int x : relativeSort({2,3,1,3,4,3}, {4,1,2,0})) std::cout << x << ' ';
}`,
        },
        steps(rows) {
          const A = (rows && rows[0]) || [];
          const B = (rows && rows[1]) || [];
          const n = A.length;
          const rankOf = (v) => {
            const i = B.indexOf(v);
            return i === -1 ? B.length : i;
          };
          const less = (x, y) => {
            const rx = rankOf(x), ry = rankOf(y);
            return rx !== ry ? rx < ry : x < y;
          };
          const a = A.slice();
          const steps = [];

          steps.push({
            title: "Set up: ranks from arr2, values from arr1",
            tracks: [track("arr1 (to order)", A, fill(n, "idle")), track("arr2 (ranks)", B, fill(B.length, "good"))],
            counters: [count("arr1 values", n), count("ranked values", B.length)],
            legend: ["compare", "read", "good", "result", "dim", "idle"],
            happened: `arr2 gives the ranking: ${B.map((v, i) => `${v} is rank ${i}`).join(", ")}.`,
            why: "Turning the order into numbers lets an ordinary sort do the arranging.",
            codeLine: 4,
          });
          steps.push({
            title: "Unlisted values get the worst (largest) rank",
            tracks: [track("arr1 (to order)", A, fill(n, "idle")), track("arr2 (ranks)", B, fill(B.length, "good"))],
            counters: [count("arr1 values", n), count("ranked values", B.length)],
            happened: `A value that arr2 never mentions ranks ${B.length} — after every listed value.`,
            why: "That pushes leftovers to the end, where they are then sorted by value.",
            codeLine: 8,
          });

          steps.push({
            title: `Start the sorted prefix with ${a[0]}`,
            tracks: [track("building order", a, paint(fill(n, "dim"), { 0: "read" }))],
            counters: [count("placed", 1, n)],
            happened: `${a[0]} has rank ${rankOf(a[0])}; a single value is always in order.`,
            why: "Insertion sort grows a sorted prefix one element at a time.",
            codeLine: 17,
          });

          if (n <= 1) {
            steps.push({
              title: "Nothing else to insert",
              tracks: [track("building order", a, fill(n, "good"))],
              counters: [count("placed", n, n)],
              happened: `With ${n} value${n === 1 ? "" : "s"} the ranked order is already complete.`,
              why: "Insertion sort only has work when there is at least a second element.",
              codeLine: 14,
            });
          }

          for (let i = 1; i < n; i++) {
            const x = a[i];
            let j = i - 1;
            steps.push({
              title: `Insert ${x} (rank ${rankOf(x)})`,
              tracks: [
                { label: "building order", cells: a.map((v, idx) => ({ v, state: idx < i ? "good" : idx === i ? "read" : "dim" })) },
              ],
              counters: [count("placed", i, n)],
              happened: `${x} must find its spot among the ${i} values already in order.`,
              why: "Insertion sort compares against the prefix from the right and shifts as it goes.",
              codeLine: 12,
            });
            while (j >= 0 && !less(a[j], x)) {
              const y = a[j];
              steps.push({
                title: `${y} (rank ${rankOf(y)}) comes after ${x} → shift right`,
                tracks: [
                  { label: "building order", cells: a.map((v, idx) => ({ v, state: idx === j || idx === i ? "compare" : idx < i ? "good" : "dim" })) },
                ],
                counters: [count("placed", i, n), count("shifts", i - j)],
                happened: `The key for ${y}, rank ${rankOf(y)}, is not smaller than the key for ${x}, rank ${rankOf(x)}.`,
                why: "Everything that should follow x has to move right to open a slot.",
                codeLine: 13,
              });
              a[j + 1] = a[j];
              j--;
            }
            a[j + 1] = x;
            steps.push({
              title: `Place ${x} at index ${j + 1}`,
              tracks: [
                { label: "building order", cells: a.map((v, idx) => ({ v, state: idx <= i ? "good" : "dim" })) },
              ],
              counters: [count("placed", i + 1, n)],
              happened: `${x} settles into the first spot whose key is larger.`,
              why: "The prefix stays sorted by (rank, value) after every insertion.",
              codeLine: 14,
            });
          }

          steps.push({
            title: `Answer: ${a.join(", ")}`,
            tracks: [track("arr1 (to order)", A, fill(n, "dim")), track("result", a, "result")],
            counters: [count("arr1 values", n), count("answer", a.join(", "))],
            happened: `Sorting by rank then value gives ${a.join(", ")}.`,
            why: "It matches the tally method's output, using a comparator instead of counts.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });
})();
