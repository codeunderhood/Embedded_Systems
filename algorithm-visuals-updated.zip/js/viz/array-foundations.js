/* ============================================================
   DSA Visuals — Array Foundations
   Reference visualisation module. Every entry shows the exact
   contract other modules follow (see SPEC.md):
     { id, title, category, difficulty, description,
       input: { label, default, parse },
       approaches: [ { name, complexity, idea, problem,
                       code: { c, cpp }, steps(parsed) } ] }
   Each step: { title, tracks, counters, happened, why,
                legend?, codeLine? }   (kind defaults to "cells")
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  /* ---------------------------------------------------------- */
  V.register({
    id: "sum-of-array-elements",
    title: "Sum of Array Elements",
    category: "Array Foundations",
    difficulty: "Beginner",
    description: "Add up every number in a row, two different ways.",
    input: { label: "The numbers", default: "4, 8, 15, 16, 23, 42", parse: "ints" },
    approaches: [
      {
        name: "Keep Every Running Total",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Walk the row from the left and write down a running total after every step — position i of a second row holds the sum of everything up to and including i.",
          "The answer is simply the last cell of the totals row.",
        ],
        problem: [
          "Keeping every total costs an extra row the same size as the input. If you only ever need the final sum, all those stored intermediates are wasted work.",
        ],
        code: {
          c: `#include <stdio.h>

/* Write every running total into totals[]. Answer: totals[n-1]. */
void running_totals(const int *a, int n, int *totals) {
    for (int i = 0; i < n; i++) {
        if (i == 0)
            totals[i] = a[i];
        else
            totals[i] = totals[i - 1] + a[i];
    }
}

int main(void) {
    int a[] = {4, 8, 15, 16, 23, 42};
    int n = 6, totals[6];
    running_totals(a, n, totals);
    printf("%d\\n", totals[n - 1]); /* 108 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// Write every running total. Answer: totals.back().
std::vector<int> runningTotals(const std::vector<int>& a) {
    std::vector<int> totals;
    int soFar = 0;
    for (int x : a) {
        soFar += x;          // carry the sum forward
        totals.push_back(soFar);
    }
    return totals;
}

int main() {
    std::vector<int> a{4, 8, 15, 16, 23, 42};
    auto totals = runningTotals(a);
    std::cout << totals.back() << '\\n'; // 108
}`,
        },
        steps(nums) {
          const n = nums.length;
          const totals = [];
          const steps = [];
          const base = fill(n, "done");
          steps.push({
            title: "Set up: room for every running total",
            tracks: [
              track("the numbers", nums, fill(n, "idle")),
              track("running totals", Array(n).fill("—"), fill(n, "idle")),
            ],
            counters: [count("numbers read", 0, n), count("totals written", 0, n)],
            legend: ["read", "done", "result", "idle"],
            happened: `There are ${n} numbers to add up, and an empty totals row waiting below with one slot per number.`,
            why: "Keeping a slot per position is the natural first idea: you can see the sum grow at every stage.",
            codeLine: 3,
          });
          for (let i = 0; i < n; i++) {
            totals.push(nums.slice(0, i + 1).reduce((a, b) => a + b, 0));
            const readStates = paint(base, { [i]: "read" });
            const totStates = totals.map((_, k) => (k === i ? "result" : "done")).concat(fill(n - totals.length, "idle"));
            steps.push({
              title: i === 0 ? `Starting the total with ${nums[i]}` : `Adding ${nums[i]} brings the total to ${totals[i]}`,
              tracks: [
                track("the numbers", nums, readStates),
                track("running totals", totals.concat(Array(n - totals.length).fill("—")), totStates),
              ],
              counters: [count("numbers read", i + 1, n), count("totals written", i + 1, n), count("total so far", totals[i])],
              happened: i === 0
                ? `The first number ${nums[i]} starts the walk — it is its own running total.`
                : `${nums[i]} joins the run: ${totals[i - 1]} + ${nums[i]} = ${totals[i]}.`,
              why: i === 0
                ? "Someone has to seed the sum; with no earlier total the first cell copies the first number."
                : "Each position only looks one cell back, so the whole row is filled in a single left-to-right pass.",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Answer: ${totals[n - 1]}, the last of the running totals`,
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              track("running totals", totals, fill(n, "done").map((s, i) => (i === n - 1 ? "result" : s))),
            ],
            counters: [count("numbers read", n, n), count("answer", totals[n - 1])],
            happened: `The walk is finished — the last cell ${totals[n - 1]} already holds the sum of everything.`,
            why: "Because every number was folded in as we passed it, the final cell is the whole row's answer.",
            codeLine: 7,
          });
          return steps;
        },
      },
      {
        name: "Carry One Total",
        complexity: "O(n) time, O(1) space",
        idea: [
          "You don't need to remember old totals — keep a single running value in one variable and add each number into it as you go.",
          "One pass, one variable, and the variable itself is the answer.",
        ],
        problem: [
          "The trade-off is that intermediate totals vanish: if someone later asks \"what was the sum of the first three numbers?\", you'd have to walk the row again.",
        ],
        code: {
          c: `#include <stdio.h>

/* One accumulator, O(1) extra space. */
int sum(const int *a, int n) {
    int total = 0;
    for (int i = 0; i < n; i++)
        total += a[i];
    return total;
}

int main(void) {
    int a[] = {4, 8, 15, 16, 23, 42};
    printf("%d\\n", sum(a, 6)); /* 108 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

int sum(const std::vector<int>& a) {
    int total = 0;
    for (int x : a)
        total += x;      // fold every element into one variable
    return total;
}

int main() {
    std::vector<int> a{4, 8, 15, 16, 23, 42};
    std::cout << sum(a) << '\\n'; // 108
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          let total = 0;
          steps.push({
            title: "One variable, starting at zero",
            tracks: [
              track("the numbers", nums, fill(n, "idle")),
              { label: "total carried", cells: [{ v: 0, state: "result", tag: "one variable" }] },
            ],
            counters: [count("numbers read", 0, n), count("total so far", 0)],
            legend: ["read", "done", "result", "idle"],
            happened: "A single carrying slot starts at 0 — nothing is stored per position this time.",
            why: "One variable is all the memory the answer needs; old totals are simply not kept.",
            codeLine: 3,
          });
          for (let i = 0; i < n; i++) {
            const prev = total;
            total += nums[i];
            steps.push({
              title: `Add ${nums[i]} → total becomes ${total}`,
              tracks: [
                track("the numbers", nums, paint(fill(n, "done"), { [i]: "read" })),
                { label: "total carried", cells: [{ v: total, state: "result", tag: i === 0 ? "seeded" : `${prev} + ${nums[i]}` }] },
              ],
              counters: [count("numbers read", i + 1, n), count("total so far", total)],
              happened: `The carrying slot swallows ${nums[i]}: ${prev} + ${nums[i]} = ${total}.`,
              why: "Read, add, move on — the row itself never needs a second row of cells beside it.",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Answer: ${total}`,
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              { label: "total carried", cells: [{ v: total, state: "result", tag: "answer" }] },
            ],
            counters: [count("numbers read", n, n), count("answer", total)],
            happened: `After the last number the carrying slot holds ${total} — that is the whole sum.`,
            why: "Same answer as the first approach, but only O(1) extra space instead of a full totals row.",
            codeLine: 5,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "count-positive-values",
    title: "Count Positive Values",
    category: "Array Foundations",
    difficulty: "Beginner",
    description: "Count how many numbers in a row are greater than zero.",
    input: { label: "The numbers", default: "3, -2, 0, 7, -5, 9, 4", parse: "ints" },
    approaches: [
      {
        name: "Walk and Count",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Keep a counter at zero. Look at each number: if it is above zero, bump the counter; otherwise leave it alone.",
          "After the last number the counter is the answer.",
        ],
        problem: ["The walk has to visit every number — one pass is the best any comparison-based method can do."],
        code: {
          c: `#include <stdio.h>

int count_positive(const int *a, int n) {
    int count = 0;
    for (int i = 0; i < n; i++)
        if (a[i] > 0)
            count++;
    return count;
}

int main(void) {
    int a[] = {3, -2, 0, 7, -5, 9, 4};
    printf("%d\\n", count_positive(a, 7)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

int countPositive(const std::vector<int>& a) {
    int count = 0;
    for (int x : a)
        if (x > 0)
            ++count;
    return count;
}

int main() {
    std::vector<int> a{3, -2, 0, 7, -5, 9, 4};
    std::cout << countPositive(a) << '\\n'; // 4
}`,
        },
        steps(nums) {
          const n = nums.length;
          let found = 0;
          const steps = [];
          steps.push({
            title: "Counter ready at 0",
            tracks: [track("the numbers", nums, fill(n, "idle"))],
            counters: [count("numbers checked", 0, n), count("positives found", 0)],
            legend: ["read", "good", "bad", "idle"],
            happened: "An empty row of numbers and a counter that starts at nothing.",
            why: "A tally only makes sense once you agree where it starts: zero positives seen so far.",
            codeLine: 2,
          });
          for (let i = 0; i < n; i++) {
            const pos = nums[i] > 0;
            if (pos) found++;
            steps.push({
              title: pos ? `${nums[i]} is positive → count = ${found}` : `${nums[i]} is not positive → count stays ${found}`,
              tracks: [track("the numbers", nums, paint(fill(n, pos ? "done" : "dim"), { [i]: pos ? "good" : "read" }))],
              counters: [count("numbers checked", i + 1, n), count("positives found", found)],
              happened: pos
                ? `${nums[i]} is above zero, so the counter ticks up to ${found}.`
                : `${nums[i]} is zero or below, so the counter is left alone at ${found}.`,
              why: "Only the current number decides — nothing about earlier numbers needs to be remembered.",
              codeLine: 4,
            });
          }
          steps.push({
            title: `Answer: ${found} positive values`,
            tracks: [track("the numbers", nums, nums.map((v) => (v > 0 ? "good" : "dim")))],
            counters: [count("numbers checked", n, n), count("answer", found)],
            happened: `Every number has been checked; ${found} of them were above zero.`,
            why: "The single pass looked at each number exactly once — O(n) and impossible to beat without reading the input.",
            codeLine: 3,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-minimum-and-maximum",
    title: "Find Minimum and Maximum",
    category: "Array Foundations",
    difficulty: "Beginner",
    description: "One walk that tracks both the smallest and largest number seen.",
    input: { label: "The numbers", default: "7, 2, 9, 4, 11, 3, 8", parse: "ints" },
    approaches: [
      {
        name: "Two Keepers",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Hold two values: the smallest seen so far and the largest seen so far. Both start as the first number.",
          "For every later number, update whichever keeper it beats — or neither.",
        ],
        problem: ["Reading the first number twice (once for each keeper) is a small wrinkle; some code instead starts both at ±∞."],
        code: {
          c: `#include <stdio.h>

void min_max(const int *a, int n, int *outMin, int *outMax) {
    int mn = a[0], mx = a[0];
    for (int i = 1; i < n; i++) {
        if (a[i] < mn) mn = a[i];
        if (a[i] > mx) mx = a[i];
    }
    *outMin = mn; *outMax = mx;
}

int main(void) {
    int a[] = {7, 2, 9, 4, 11, 3, 8};
    int mn, mx;
    min_max(a, 7, &mn, &mx);
    printf("min %d max %d\\n", mn, mx); /* min 2 max 11 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::vector<int> a{7, 2, 9, 4, 11, 3, 8};
    int mn = a[0], mx = a[0];
    for (size_t i = 1; i < a.size(); ++i) {
        mn = std::min(mn, a[i]);   // keep the smallest
        mx = std::max(mx, a[i]);   // keep the largest
    }
    std::cout << "min " << mn << " max " << mx << '\\n'; // min 2 max 11
}`,
        },
        steps(nums) {
          const n = nums.length;
          let mn = nums[0], mx = nums[0];
          const steps = [];
          const keeper = (i) => {
            const cells = [{ v: mn, state: "good", tag: "min" }, { v: mx, state: "active", tag: "max" }];
            return { label: "keepers", cells };
          };
          steps.push({
            title: `Seed both keepers with ${nums[0]}`,
            tracks: [track("the numbers", nums, paint(fill(n, "idle"), { 0: "read" })), keeper()],
            counters: [count("numbers seen", 1, n)],
            legend: ["read", "good", "active", "idle"],
            happened: `The first number ${nums[0]} becomes both the smallest and the largest — it has no rivals yet.`,
            why: "Seeding with a real element (rather than ±∞) keeps the keepers honest about the input's own range.",
            codeLine: 2,
          });
          for (let i = 1; i < n; i++) {
            const isMin = nums[i] < mn, isMax = nums[i] > mx;
            const prevMin = mn, prevMax = mx;
            if (isMin) mn = nums[i];
            if (isMax) mx = nums[i];
            const note = isMin && isMax ? `new min AND max!` : isMin ? "new min" : isMax ? "new max" : "no change";
            steps.push({
              title: `${nums[i]} → ${note}`,
              tracks: [
                track("the numbers", nums, paint(fill(n, i === 0 ? "read" : "done"), { [i]: isMin || isMax ? "read" : "dim" })),
                keeper(i),
              ],
              counters: [count("numbers seen", i + 1, n), count("min", mn), count("max", mx)],
              happened: isMin && isMax
                ? `${nums[i]} beats both keepers at once (${prevMin}, ${prevMax}) — a single number can reset both.`
                : isMin
                  ? `${nums[i]} is below ${prevMin}, so the minimum keeper drops to ${nums[i]}. The maximum keeper keeps ${mx}.`
                  : isMax
                    ? `${nums[i]} is above ${prevMax}, so the maximum keeper climbs to ${nums[i]}. The minimum keeper keeps ${mn}.`
                    : `${nums[i]} sits between ${mn} and ${mx} — neither keeper moves.`,
              why: "Two independent questions, one pass: each number is compared against both keepers in the same visit.",
              codeLine: 4,
            });
          }
          steps.push({
            title: `Answer: min ${mn}, max ${mx}`,
            tracks: [
              track("the numbers", nums, nums.map((v) => (v === mn ? "good" : v === mx ? "active" : "dim"))),
              keeper(),
            ],
            counters: [count("numbers seen", n, n), count("min", mn), count("max", mx)],
            happened: `After one walk: the smallest number is ${mn} and the largest is ${mx}.`,
            why: "Both answers arrived together — the whole row was examined exactly once.",
            codeLine: 6,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "reverse-an-array",
    title: "Reverse an Array",
    category: "Array Foundations",
    difficulty: "Beginner",
    description: "Flip the row end-to-end by swapping from both sides.",
    input: { label: "The numbers", default: "1, 2, 3, 4, 5, 6, 7", parse: "ints" },
    approaches: [
      {
        name: "Two Pointers Swapping",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Place one pointer at the left end and one at the right end. Swap what they point at, then both step inwards.",
          "When the pointers cross (or meet), the row is reversed.",
        ],
        problem: ["Half the swaps are mirrors of the other half — n/2 swaps total. A copy-based approach would use O(n) extra memory to do the same job."],
        code: {
          c: `#include <stdio.h>

void reverse(int *a, int n) {
    for (int lo = 0, hi = n - 1; lo < hi; lo++, hi--) {
        int t = a[lo];
        a[lo] = a[hi];
        a[hi] = t;
    }
}

int main(void) {
    int a[] = {1, 2, 3, 4, 5, 6, 7};
    reverse(a, 7);
    for (int i = 0; i < 7; i++) printf("%d ", a[i]); /* 7 6 5 4 3 2 1 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <swap>

void reverse(std::vector<int>& a) {
    for (int lo = 0, hi = (int)a.size() - 1; lo < hi; ++lo, --hi)
        std::swap(a[lo], a[hi]);   // ends meet in the middle
}

int main() {
    std::vector<int> a{1, 2, 3, 4, 5, 6, 7};
    reverse(a);
    for (int x : a) std::cout << x << ' '; // 7 6 5 4 3 2 1
}`,
        },
        steps(nums) {
          const n = nums.length;
          const arr = nums.slice();
          const steps = [];
          const show = (lo, hi, swapStates) =>
            track("the numbers", arr, arr.map((_, i) =>
              swapStates && (i === lo || i === hi) ? "swap" : i === lo || i === hi ? "compare" : (i < lo || i > hi ? "done" : "idle")));
          steps.push({
            title: "Pointers at the two ends",
            tracks: [show(0, n - 1)],
            counters: [count("left pointer", 0), count("right pointer", n - 1), count("swaps", 0, Math.floor(n / 2))],
            legend: ["compare", "swap", "done", "idle"],
            happened: `Left starts at index 0 (${arr[0]}) and right at index ${n - 1} (${arr[n - 1]}).`,
            why: "The ends must trade places; working inwards means no element is ever moved twice.",
            codeLine: 2,
          });
          let swaps = 0;
          for (let lo = 0, hi = n - 1; lo < hi; lo++, hi--) {
            swaps++;
            const a = arr[lo], b = arr[hi];
            steps.push({
              title: `Swap ${a} ⇄ ${b}`,
              tracks: [show(lo, hi, true)],
              counters: [count("left pointer", lo), count("right pointer", hi), count("swaps", swaps, Math.floor(n / 2))],
              happened: `Positions ${lo} and ${hi} trade: ${a} goes right, ${b} comes left.`,
              why: "A three-step dance with one temporary variable puts each value in its mirror position.",
              codeLine: 4,
            });
            [arr[lo], arr[hi]] = [arr[hi], arr[lo]];
            if (lo + 1 <= hi - 1) {
              steps.push({
                title: "Pointers step inwards",
                tracks: [show(lo + 1, hi - 1)],
                counters: [count("left pointer", lo + 1), count("right pointer", hi - 1), count("swaps", swaps, Math.floor(n / 2))],
                happened: `Both pointers move one step closer: now ${lo + 1} and ${hi - 1}. The outer cells are locked in.`,
                why: "Everything outside the pointers is finished — the untouched middle shrinks by two each round.",
                codeLine: 2,
              });
            }
          }
          steps.push({
            title: "Reversed",
            tracks: [track("the numbers", arr, fill(n, "result"))],
            counters: [count("swaps", swaps), count("answer", "done")],
            happened: `The pointers met in the middle: the row now reads ${arr.join(", ")}.`,
            why: "Only n/2 swaps and a single temporary — the row was flipped in place.",
            codeLine: 3,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "check-whether-an-array-is-sorted",
    title: "Check Whether an Array Is Sorted",
    category: "Array Foundations",
    difficulty: "Beginner",
    description: "Verify each number is not smaller than the one before it.",
    input: { label: "The numbers", default: "2, 5, 8, 11, 14, 19", parse: "ints" },
    approaches: [
      {
        name: "Compare Each Pair",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Sorted means every neighbour pair is in non-decreasing order. Walk the row and compare each number with its left neighbour.",
          "The moment a pair breaks the rule, the answer is 'no' — you can stop early.",
        ],
        problem: ["Early exit means the worst case (a sorted row, or a violation at the very end) still visits every number — O(n) either way."],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

bool is_sorted(const int *a, int n) {
    for (int i = 1; i < n; i++)
        if (a[i] < a[i - 1])
            return false;
    return true;
}

int main(void) {
    int a[] = {2, 5, 8, 11, 14, 19};
    printf("%s\\n", is_sorted(a, 6) ? "yes" : "no"); /* yes */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

bool isSorted(const std::vector<int>& a) {
    for (size_t i = 1; i < a.size(); ++i)
        if (a[i] < a[i - 1])
            return false;          // found a drop — stop early
    return true;
}

int main() {
    std::vector<int> a{2, 5, 8, 11, 14, 19};
    std::cout << (isSorted(a) ? "yes" : "no") << '\\n'; // yes
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          steps.push({
            title: "Rule: each number must be ≥ the one before",
            tracks: [track("the numbers", nums, fill(n, "idle"))],
            counters: [count("pairs checked", 0, Math.max(0, n - 1))],
            legend: ["compare", "good", "bad", "done"],
            happened: `${n} numbers; there are ${Math.max(0, n - 1)} neighbour pairs that must all obey the rule.`,
            why: "Sorting is a local promise: if every adjacent pair behaves, the whole row is ordered.",
            codeLine: 3,
          });
          for (let i = 1; i < n; i++) {
            const ok = nums[i] >= nums[i - 1];
            steps.push({
              title: ok ? `${nums[i - 1]} ≤ ${nums[i]} ✓` : `${nums[i - 1]} > ${nums[i]} ✗ drop found`,
              tracks: [track("the numbers", nums, paint(fill(n, "done"), { [i - 1]: "compare", [i]: ok ? "good" : "bad" }))],
              counters: [count("pairs checked", i, n - 1)],
              happened: ok
                ? `Pair (${nums[i - 1]}, ${nums[i]}) keeps the promise.`
                : `Pair (${nums[i - 1]}, ${nums[i]}) drops backwards — the row cannot be sorted.`,
              why: ok
                ? "Each pair is checked exactly once against its immediate left neighbour."
                : "One broken pair is enough to decide, so the walk can quit here.",
              codeLine: ok ? 4 : 5,
            });
            if (!ok) {
              steps.push({
                title: "Answer: not sorted",
                tracks: [track("the numbers", nums, nums.map((_, k) => (k === i || k === i - 1 ? "bad" : "dim")))],
                counters: [count("pairs checked", i, n - 1), count("answer", "no")],
                happened: `Stopped early at index ${i}: ${nums[i]} is smaller than ${nums[i - 1]}.`,
                why: "The first violation settles the question — remaining pairs cannot repair it.",
                codeLine: 5,
              });
              return steps;
            }
          }
          steps.push({
            title: "Answer: sorted",
            tracks: [track("the numbers", nums, fill(n, "good"))],
            counters: [count("pairs checked", n - 1, n - 1), count("answer", "yes")],
            happened: `All ${n - 1} pairs obeyed the rule, so the row is sorted.`,
            why: "No pair was skipped, so no hidden drop can exist anywhere in the row.",
            codeLine: 7,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-the-second-largest-element",
    title: "Find the Second Largest Element",
    category: "Array Foundations",
    difficulty: "Beginner",
    description: "Track the biggest and the next-biggest in one walk.",
    input: { label: "The numbers", default: "6, 12, 4, 12, 9, 3, 15", parse: "ints" },
    approaches: [
      {
        name: "Best and Runner-Up",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Keep two values: largest and second. A new number replaces largest only if it is strictly bigger; if it is strictly between them it replaces second.",
          "Strict inequality is what makes duplicates of the winner not count as runner-up.",
        ],
        problem: ["If several numbers tie for largest, the runner-up must still be smaller than them — a careless >= turns a duplicate winner into 'second largest'."],
        code: {
          c: `#include <stdio.h>
#include <limits.h>

int second_largest(const int *a, int n) {
    int largest = INT_MIN, second = INT_MIN;
    for (int i = 0; i < n; i++) {
        if (a[i] > largest) {
            second = largest;
            largest = a[i];
        } else if (a[i] > second && a[i] < largest) {
            second = a[i];
        }
    }
    return second;
}

int main(void) {
    int a[] = {6, 12, 4, 12, 9, 3, 15};
    printf("%d\\n", second_largest(a, 7)); /* 12 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <climits>

int secondLargest(const std::vector<int>& a) {
    int largest = INT_MIN, second = INT_MIN;
    for (int x : a) {
        if (x > largest) {          // old largest becomes runner-up
            second = largest;
            largest = x;
        } else if (x > second && x < largest) {
            second = x;             // strictly between the two
        }
    }
    return second;
}

int main() {
    std::vector<int> a{6, 12, 4, 12, 9, 3, 15};
    std::cout << secondLargest(a) << '\\n'; // 12
}`,
        },
        steps(nums) {
          const n = nums.length;
          let largest = -Infinity, second = -Infinity;
          const steps = [];
          const keepers = () => ({
            label: "keepers",
            cells: [
              { v: largest === -Infinity ? "—" : largest, state: "result", tag: "largest" },
              { v: second === -Infinity ? "—" : second, state: "active", tag: "second" },
            ],
          });
          steps.push({
            title: "Both keepers empty",
            tracks: [track("the numbers", nums, fill(n, "idle")), keepers()],
            counters: [count("numbers seen", 0, n)],
            legend: ["read", "result", "active", "dim"],
            happened: "Largest and second both start empty — nothing has been seen yet.",
            why: "Two slots are enough: everything else in the row can be forgotten after one look.",
            codeLine: 2,
          });
          for (let i = 0; i < n; i++) {
            const x = nums[i];
            let note;
            if (x > largest) {
              second = largest === -Infinity ? second : largest;
              if (x !== largest) second = largest === -Infinity && second === -Infinity ? second : largest;
              const oldLargest = largest;
              largest = x;
              note = oldLargest === -Infinity ? "becomes first largest" : `${oldLargest} demoted to second`;
              if (oldLargest !== -Infinity) second = oldLargest;
            } else if (x > second && x < largest) {
              second = x;
              note = "new runner-up";
            } else if (x === largest) {
              note = "ties the largest — ignored";
            } else {
              note = "too small — ignored";
            }
            steps.push({
              title: `${x} → ${note}`,
              tracks: [
                track("the numbers", nums, paint(fill(n, i === 0 ? "read" : "done"), { [i]: note.includes("ignored") ? "dim" : "read" })),
                keepers(),
              ],
              counters: [count("numbers seen", i + 1, n), count("largest", largest === -Infinity ? "—" : largest), count("second", second === -Infinity ? "—" : second)],
              happened: `The number ${x} ${note}.`,
              why: "Only two comparisons decide its fate; after that the number itself is history.",
              codeLine: x > largest || (x > second && x < largest) ? 4 : 7,
            });
          }
          steps.push({
            title: `Answer: ${second}`,
            tracks: [
              track("the numbers", nums, nums.map((v) => (v === second ? "good" : v === largest ? "result" : "dim"))),
              keepers(),
            ],
            counters: [count("numbers seen", n, n), count("answer", second)],
            happened: `The runner-up is ${second} — the biggest value that is still strictly below ${largest}.`,
            why: "One pass, two kept values, and duplicates of the winner correctly skipped.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "remove-duplicates",
    title: "Remove Duplicates",
    category: "Array Foundations",
    difficulty: "Beginner",
    description: "Keep only the first occurrence of each value.",
    input: { label: "The numbers", default: "3, 1, 3, 4, 1, 5, 3", parse: "ints" },
    approaches: [
      {
        name: "Seen-Set Filter",
        complexity: "O(n) time, O(k) space",
        idea: [
          "Hold a set of values already kept. Walk the input left to right: a value joins the output only if the set has never seen it.",
          "First occurrence wins, order is preserved.",
        ],
        problem: ["The set costs extra memory proportional to the number of distinct values — but it is what lets the check be O(1) per number."],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* Compact in place: keep first occurrence of each value. */
int remove_duplicates(int *a, int n) {
    int out = 0;
    for (int i = 0; i < n; i++) {
        bool seen = false;
        for (int j = 0; j < out; j++)
            if (a[j] == a[i]) { seen = true; break; }
        if (!seen) a[out++] = a[i];
    }
    return out;
}

int main(void) {
    int a[] = {3, 1, 3, 4, 1, 5, 3};
    int n = remove_duplicates(a, 7);
    for (int i = 0; i < n; i++) printf("%d ", a[i]); /* 3 1 4 5 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_set>

// Keep the first occurrence of each value, in order.
std::vector<int> removeDuplicates(const std::vector<int>& a) {
    std::unordered_set<int> seen;
    std::vector<int> out;
    for (int x : a)
        if (seen.insert(x).second)   // true only the first time
            out.push_back(x);
    return out;
}

int main() {
    for (int x : removeDuplicates({3, 1, 3, 4, 1, 5, 3}))
        std::cout << x << ' ';        // 3 1 4 5
}`,
        },
        steps(nums) {
          const n = nums.length;
          const seen = new Set();
          const kept = [];
          const steps = [];
          steps.push({
            title: "Empty set, empty output",
            tracks: [
              track("input", nums, fill(n, "idle")),
              { label: "kept so far", cells: [{ v: "∅", state: "idle", empty: true }] },
              { label: "seen set", cells: [{ v: "∅", state: "idle", empty: true }] },
            ],
            counters: [count("read", 0, n), count("kept", 0)],
            legend: ["read", "good", "bad", "done"],
            happened: "Nothing read yet — the seen-set and the output both start empty.",
            why: "The set exists purely to remember earlier values so later duplicates can be spotted instantly.",
            codeLine: 3,
          });
          for (let i = 0; i < n; i++) {
            const x = nums[i];
            const dup = seen.has(x);
            if (!dup) { seen.add(x); kept.push(x); }
            steps.push({
              title: dup ? `${x} already seen → dropped` : `${x} is new → kept`,
              tracks: [
                track("input", nums, paint(fill(n, dup ? "bad" : "done"), { [i]: dup ? "bad" : "read" })),
                { label: "kept so far", cells: kept.map((v) => ({ v, state: "good" })) },
                { label: "seen set", cells: [...seen].map((v) => ({ v, state: v === x && !dup ? "read" : "done" })) },
              ],
              counters: [count("read", i + 1, n), count("kept", kept.length)],
              happened: dup
                ? `${x} is already in the seen-set, so this copy is thrown away.`
                : `${x} has never appeared — it enters both the output and the seen-set.`,
              why: dup
                ? "Because the set already held it, the check was a single lookup instead of re-scanning the output."
                : "Keeping the first copy only preserves the original order while duplicates vanish.",
              codeLine: dup ? 9 : 10,
            });
          }
          steps.push({
            title: `Answer: ${kept.join(", ")}`,
            tracks: [
              track("input", nums, nums.map((v, i) => (nums.indexOf(v) === i ? "good" : "bad"))),
              { label: "kept so far", cells: kept.map((v) => ({ v, state: "result" })) },
            ],
            counters: [count("read", n, n), count("kept", kept.length)],
            happened: `${n - kept.length} duplicate ${n - kept.length === 1 ? "copy was" : "copies were"} dropped; ${kept.length} distinct values remain in original order.`,
            why: "Each value was tested once against the set — the whole row is processed in a single pass.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "build-a-frequency-map",
    title: "Build a Frequency Map",
    category: "Array Foundations",
    difficulty: "Beginner",
    description: "Tally how often each value appears.",
    input: { label: "The numbers", default: "2, 5, 2, 8, 5, 2, 9", parse: "ints" },
    approaches: [
      {
        name: "Count as You Walk",
        complexity: "O(n) time, O(k) space",
        idea: [
          "Use a map from value → count. For each number, increment whatever the map already holds for it (zero if new).",
          "One pass produces the whole tally.",
        ],
        problem: ["The map's iteration order is not the input order — if you need sorted output you must sort the keys afterwards (an extra O(k log k))."],
        code: {
          c: `#include <stdio.h>

/* Small demo with values 0..99; real code would use a hash map. */
void frequencies(const int *a, int n, int *tally /* [100] */) {
    for (int i = 0; i < n; i++)
        tally[a[i]]++;
}

int main(void) {
    int a[] = {2, 5, 2, 8, 5, 2, 9};
    int tally[100] = {0};
    frequencies(a, 7, tally);
    for (int v = 0; v < 100; v++)
        if (tally[v]) printf("%d x%d\\n", v, tally[v]);
    /* 2 x3, 5 x2, 8 x1, 9 x1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <map>

// value -> how often it appears
std::map<int, int> frequencies(const std::vector<int>& a) {
    std::map<int, int> tally;
    for (int x : a)
        ++tally[x];        // missing keys start at 0
    return tally;
}

int main() {
    for (auto [v, c] : frequencies({2, 5, 2, 8, 5, 2, 9}))
        std::cout << v << " x" << c << '\\n'; // 2 x3 5 x2 8 x1 9 x1
}`,
        },
        steps(nums) {
          const n = nums.length;
          const tally = new Map();
          const steps = [];
          const tallyTrack = () => ({
            label: "frequency map",
            cells: tally.size
              ? [...tally].map(([v, c], i) => ({ v: `${v}×${c}`, state: c > 1 ? "result" : "done", tag: undefined }))
              : [{ v: "∅", state: "idle", empty: true }],
          });
          steps.push({
            title: "Empty tally",
            tracks: [track("the numbers", nums, fill(n, "idle")), tallyTrack()],
            counters: [count("read", 0, n), count("distinct values", 0)],
            legend: ["read", "done", "result", "idle"],
            happened: "The tally starts empty — every value is still a stranger.",
            why: "A map turns 'how many times have I seen this?' into a single O(1) question.",
            codeLine: 3,
          });
          for (let i = 0; i < n; i++) {
            const x = nums[i];
            const isNew = !tally.has(x);
            tally.set(x, (tally.get(x) || 0) + 1);
            steps.push({
              title: isNew ? `${x} appears — opens a new bucket` : `${x} seen again → now ×${tally.get(x)}`,
              tracks: [
                track("the numbers", nums, paint(fill(n, "done"), { [i]: "read" })),
                tallyTrack(),
              ],
              counters: [count("read", i + 1, n), count("distinct values", tally.size), count(`${x} count`, tally.get(x))],
              happened: isNew
                ? `${x} had no bucket, so one is opened with a count of 1.`
                : `The bucket for ${x} ticks up to ${tally.get(x)}.`,
              why: isNew
                ? "New keys are created on demand — no need to know the value range in advance."
                : "Whatever arrives, one lookup plus one increment is all the work.",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Answer: ${[...tally].map(([v, c]) => `${v}×${c}`).join(", ")}`,
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              tallyTrack(),
            ],
            counters: [count("read", n, n), count("distinct values", tally.size)],
            happened: `The finished tally: ${[...tally].map(([v, c]) => `${v} appears ${c}×`).join(", ")}.`,
            why: "Counts for every distinct value arrived in one pass and stay available for any later question.",
            codeLine: 7,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-the-first-repeated-value",
    title: "Find the First Repeated Value",
    category: "Array Foundations",
    difficulty: "Beginner",
    description: "The earliest number that appears twice.",
    input: { label: "The numbers", default: "4, 7, 1, 9, 7, 4, 2", parse: "ints" },
    approaches: [
      {
        name: "Seen-Set Scan",
        complexity: "O(n) time, O(k) space",
        idea: [
          "Walk left to right with a set of values seen so far. The first number already in the set is the answer — and you can stop there.",
          "Earliest repeat means earliest second occurrence, which is exactly what a left-to-right walk finds.",
        ],
        problem: ["The set grows with distinct values, and worst case (no repeat at all) you still scan everything once."],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* Returns index of first repeated value, or -1. */
int first_repeat(const int *a, int n) {
    bool seen[10000] = {false};   /* stands in for a set */
    for (int i = 0; i < n; i++) {
        if (seen[a[i]]) return i;
        seen[a[i]] = true;
    }
    return -1;
}

int main(void) {
    int a[] = {4, 7, 1, 9, 7, 4, 2};
    int i = first_repeat(a, 7);
    printf("%d\\n", a[i]); /* 7 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <unordered_set>

// Earliest value whose second copy comes first.
int firstRepeat(const std::vector<int>& a) {
    std::unordered_set<int> seen;
    for (int x : a) {
        if (!seen.insert(x).second)
            return x;          // already there -> repeat
        // insert succeeded -> x is new
    }
    return -1;                 // nothing repeats
}

int main() {
    std::cout << firstRepeat({4, 7, 1, 9, 7, 4, 2}) << '\\n'; // 7
}`,
        },
        steps(nums) {
          const n = nums.length;
          const seen = new Set();
          const steps = [];
          const seenTrack = () => ({
            label: "seen set",
            cells: seen.size ? [...seen].map((v) => ({ v, state: "done" })) : [{ v: "∅", state: "idle", empty: true }],
          });
          steps.push({
            title: "Nothing seen yet",
            tracks: [track("the numbers", nums, fill(n, "idle")), seenTrack()],
            counters: [count("read", 0, n)],
            legend: ["read", "bad", "done", "idle"],
            happened: "The walk starts at the left with an empty memory of previous numbers.",
            why: "The set answers 'did this appear before?' in O(1) — that is the whole trick.",
            codeLine: 4,
          });
          for (let i = 0; i < n; i++) {
            const x = nums[i];
            const dup = seen.has(x);
            steps.push({
              title: dup ? `${x} already in the set → first repeat!` : `${x} is new → remember it`,
              tracks: [
                track("the numbers", nums, paint(fill(n, dup ? "bad" : "done"), { [i]: dup ? "bad" : "read" })),
                seenTrack(),
              ],
              counters: [count("read", i + 1, n), count("distinct seen", seen.size)],
              happened: dup
                ? `${x} was already recorded (at index ${nums.indexOf(x)}) — this is the earliest repeat.`
                : `${x} is recorded for the first time.`,
              why: dup
                ? "Because the walk is strictly left to right, no earlier repeat could have been missed."
                : "Recording every value once is what makes the next duplicate obvious.",
              codeLine: dup ? 6 : 7,
            });
            if (dup) {
              steps.push({
                title: `Answer: ${x}`,
                tracks: [
                  track("the numbers", nums, nums.map((v, k) => (v === x ? (k <= i ? "bad" : "dim") : "dim"))),
                  { label: "answer", cells: [{ v: x, state: "result", tag: "first repeat" }] },
                ],
                counters: [count("read", i + 1, n), count("answer", x)],
                happened: `${x} is the first value with two copies inside the row.`,
                why: "The scan stops as soon as the repeat is confirmed — later numbers never need reading.",
                codeLine: 6,
              });
              return steps;
            }
            seen.add(x);
          }
          steps.push({
            title: "Answer: no repeat",
            tracks: [track("the numbers", nums, fill(n, "good")), seenTrack()],
            counters: [count("read", n, n), count("answer", "none")],
            happened: "Every number was distinct — no value repeated.",
            why: "A full pass with no set hit proves absence just as firmly as a hit proves presence.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "compare-two-integer-multisets",
    title: "Compare Two Integer Multisets",
    category: "Array Foundations",
    difficulty: "Beginner",
    description: "Same numbers, same counts — different order?",
    input: { label: "Row A | Row B", default: "1, 3, 5, 3 | 3, 1, 3, 5", parse: "tworows" },
    approaches: [
      {
        name: "Tally Both, Compare Counts",
        complexity: "O(n) time, O(k) space",
        idea: [
          "Build a frequency map for each row, then walk A's map: every value must exist in B's map with exactly the same count.",
          "Same multiset means same values with same multiplicities — order never matters.",
        ],
        problem: ["If the rows differ in length the answer is 'no' immediately; otherwise every distinct value must be cross-checked once."],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* Are a[] and b[] the same multiset? (values 0..999) */
bool same_multiset(const int *a, int na, const int *b, int nb) {
    if (na != nb) return false;
    int ta[1000] = {0}, tb[1000] = {0};
    for (int i = 0; i < na; i++) { ta[a[i]]++; tb[b[i]]++; }
    for (int v = 0; v < 1000; v++)
        if (ta[v] != tb[v]) return false;
    return true;
}

int main(void) {
    int a[] = {1, 3, 5, 3}, b[] = {3, 1, 3, 5};
    printf("%s\\n", same_multiset(a, 4, b, 4) ? "same" : "different");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_map>

// Same values with same counts = same multiset.
bool sameMultiset(const std::vector<int>& a, const std::vector<int>& b) {
    if (a.size() != b.size()) return false;
    std::unordered_map<int, int> tally;
    for (int x : a) ++tally[x];
    for (int x : b) if (--tally[x] < 0) return false;
    for (auto& [v, c] : tally) if (c != 0) return false;
    return true;
}

int main() {
    std::cout << (sameMultiset({1, 3, 5, 3}, {3, 1, 3, 5}) ? "same" : "different");
}`,
        },
        steps(rows) {
          const A = rows[0] || [];
          const B = rows[1] || [];
          const n = A.length;
          const tallyA = new Map(), tallyB = new Map();
          A.forEach((v) => tallyA.set(v, (tallyA.get(v) || 0) + 1));
          B.forEach((v) => tallyB.set(v, (tallyB.get(v) || 0) + 1));
          const keys = [...new Set([...tallyA.keys(), ...tallyB.keys()])];
          const steps = [];
          const tallyTrack = (map, label) => ({
            label,
            cells: map.size ? [...map].map(([v, c]) => ({ v: `${v}×${c}`, state: "done" })) : [{ v: "∅", state: "idle", empty: true }],
          });
          steps.push({
            title: "Two rows, order irrelevant",
            tracks: [
              track("row A", A, fill(n, "idle")),
              track("row B", B, fill(B.length, "idle")),
            ],
            counters: [count("lengths", `${A.length} vs ${B.length}`)],
            legend: ["read", "good", "bad", "result"],
            happened: `Row A holds ${A.join(", ")}; row B holds ${B.join(", ")}. They look shuffled.`,
            why: "A multiset comparison ignores order, so the walk compares tallies rather than positions.",
            codeLine: 3,
          });
          steps.push({
            title: "Tally both rows",
            tracks: [
              track("row A", A, fill(n, "done")),
              track("row B", B, fill(B.length, "done")),
              tallyTrack(tallyA, "tally A"),
              tallyTrack(tallyB, "tally B"),
            ],
            counters: [count("distinct in A", tallyA.size), count("distinct in B", tallyB.size)],
            happened: `A's tally: ${[...tallyA].map(([v, c]) => `${v}×${c}`).join(" ")}. B's tally: ${[...tallyB].map(([v, c]) => `${v}×${c}`).join(" ")}.`,
            why: "With counts side by side, the question becomes 'are these two tables identical?'.",
            codeLine: 5,
          });
          let allOk = true;
          keys.forEach((k, i) => {
            const ca = tallyA.get(k) || 0, cb = tallyB.get(k) || 0;
            const ok = ca === cb;
            if (!ok) allOk = false;
            steps.push({
              title: ok ? `Value ${k}: ${ca} in A, ${cb} in B ✓` : `Value ${k}: ${ca} in A but ${cb} in B ✗`,
              tracks: [
                track("row A", A, fill(n, "done")),
                track("row B", B, fill(B.length, "done")),
                {
                  label: "count check",
                  cells: [
                    { v: `${k}×${ca}`, state: ok ? "good" : "bad", tag: "A" },
                    { v: `${k}×${cb}`, state: ok ? "good" : "bad", tag: "B" },
                  ],
                },
              ],
              counters: [count("values compared", i + 1, keys.length), count("match so far", allOk ? "yes" : "no")],
              happened: ok
                ? `Both rows show ${k} exactly ${ca} ${ca === 1 ? "time" : "times"}.`
                : `The counts differ for ${k}: A has ${ca}, B has ${cb}.`,
              why: ok
                ? "Each distinct value must agree in count — matching one more keeps the verdict alive."
                : "One mismatched count is enough: the rows can never be the same multiset.",
              codeLine: ok ? 7 : 8,
            });
          });
          steps.push({
            title: allOk ? "Answer: same multiset" : "Answer: different multisets",
            tracks: [
              track("row A", A, fill(n, allOk ? "good" : "bad")),
              track("row B", B, fill(B.length, allOk ? "good" : "bad")),
            ],
            counters: [count("values compared", keys.length), count("answer", allOk ? "same" : "different")],
            happened: allOk
              ? `All ${keys.length} distinct values matched in count — the rows are rearrangements of each other.`
              : "At least one value's count differed, so the rows are not the same multiset.",
            why: "Tallying converts an ordering-obsessed comparison into a plain table equality check.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });
})();
