/* ============================================================
   DSA Visuals — Bits & Bit Tricks I
   Nine small problems solved with xor, masks, shifts and the
   classic bit-counting identities. Every visual keeps the
   binary rows short enough to read comfortably.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  /* ---------- small local helpers ---------- */
  function clamp(v, lo, hi) {
    return Math.max(lo, Math.min(hi, v));
  }

  /* Right-aligned binary string, masked to `width` low bits. */
  function bits(v, width) {
    const w = clamp(width | 0, 1, 12);
    let s = (v >>> 0).toString(2);
    if (s.length > w) s = s.slice(s.length - w);
    while (s.length < w) s = "0" + s;
    return s;
  }

  function bitLength(v) {
    return Math.max(1, (Math.abs(Math.trunc(v)) >>> 0).toString(2).length);
  }

  function widthFor(values, min, max) {
    let w = min || 4;
    for (const v of values) w = Math.max(w, bitLength(v));
    return clamp(w, min || 4, max || 12);
  }

  /* A row of "1"/"0" cells. `hot` is a bit index (0 = rightmost). */
  function bitRow(label, value, width, hot, hotState, oneState, zeroState) {
    const s = bits(value, width);
    const states = s.split("").map((ch, i) => {
      const bit = width - 1 - i;
      if (hot != null && bit === hot) return hotState || "read";
      return ch === "1" ? oneState || "done" : zeroState || "idle";
    });
    return track(label, s.split(""), states);
  }

  function valueTrack(label, v, state, tag) {
    return { label, cells: [{ v, state, tag }] };
  }

  function lowOnes(v, width) {
    const out = [];
    const s = bits(v, width);
    for (let i = 0; i < width; i++)
      if (s[width - 1 - i] === "1") out.push(i);
    return out;
  }

  /* ---------------------------------------------------------- */
  V.register({
    id: "single-number",
    title: "Single Number",
    category: "Bits & Bit Tricks",
    difficulty: "Intermediate",
    description: "Find the one value that appears once when every other value appears twice.",
    input: { label: "The numbers", default: "4, 1, 2, 1, 2", parse: "ints" },
    approaches: [
      {
        name: "XOR Everything",
        complexity: "O(n) time, O(1) space",
        idea: [
          "XOR has a useful habit: a value XORed with itself becomes zero. If every number except one appears in a pair, folding the whole row with XOR makes all the pairs disappear.",
          "Whatever is left in the accumulator is the lonely value. Order does not matter, so one left-to-right pass is enough.",
        ],
        problem: [
          "This trick only works when the duplicates really are pairs. If some value appeared three times, its bits would not cancel, so the answer would be misleading.",
        ],
        code: {
          c: `#include <stdio.h>

/* Every value appears twice except one; xor wipes out pairs. */
int single_number(const int *a, int n) {
    int x = 0;
    for (int i = 0; i < n; i++) {
        x ^= a[i];          /* same value twice cancels */
    }
    return x;
}

int main(void) {
    int a[] = {4, 1, 2, 1, 2};
    printf("%d\\n", single_number(a, 5)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// XOR folds pairs away; the leftover is the unique value.
int singleNumber(const std::vector<int>& a) {
    int x = 0;
    for (int v : a)
        x ^= v;
    return x;
}

int main() {
    std::vector<int> a{4, 1, 2, 1, 2};
    std::cout << singleNumber(a) << '\\n'; // 4
}`,
        },
        steps(nums) {
          const n = nums.length;
          const width = widthFor(nums, 4, 8);
          const LEG = ["read", "done", "result", "good", "dim", "idle"];
          const counts = new Map();
          for (const v of nums) counts.set(v, (counts.get(v) || 0) + 1);
          const steps = [];
          let x = 0;

          steps.push({
            title: "One accumulator, starting at 0",
            tracks: [
              track("the numbers", nums, fill(n, "idle")),
              valueTrack("xor so far", 0, "idle", "starts at zero"),
              bitRow("xor in binary (" + width + " bits)", 0, width),
            ],
            counters: [count("numbers read", 0, n), count("xor so far", 0)],
            legend: LEG,
            happened: `The row holds ${nums.join(", ")}. The xor accumulator is still 0.`,
            why: "XOR is the whole tool here: it remembers differences and forgets values that repeat.",
            codeLine: 4,
          });

          for (let i = 0; i < n; i++) {
            const before = x;
            x ^= nums[i];
            steps.push({
              title: `${before} xor ${nums[i]} → ${x}`,
              tracks: [
                track("the numbers", nums, paint(fill(n, i === 0 ? "idle" : "done"), { [i]: "read" })),
                valueTrack("xor so far", x, "result", `${before} ^ ${nums[i]}`),
                bitRow("xor in binary (" + width + " bits)", x, width, null, "read"),
              ],
              counters: [count("numbers read", i + 1, n), count("xor so far", x)],
              legend: LEG,
              happened: `The accumulator takes in ${nums[i]}: ${before} xor ${nums[i]} is ${x}.`,
              why: "Each step folds one more value into the same running answer, so no extra row is needed.",
              codeLine: 6,
            });
          }

          const lonely = nums.find((v) => (counts.get(v) % 2) === 1);
          const shownLonely = lonely === undefined ? x : lonely;
          steps.push({
            title: `Pairs cancel, leaving ${x}`,
            tracks: [
              track("the numbers", nums, nums.map((v) => (v === shownLonely ? "good" : "dim"))),
              valueTrack("xor so far", x, "result", "odd count"),
              bitRow("xor in binary (" + width + " bits)", x, width, null, "read", "good", "dim"),
            ],
            counters: [count("numbers read", n, n), count("xor so far", x)],
            legend: LEG,
            happened: `Every value with an even count has cancelled itself out. The only odd-count value is ${shownLonely}.`,
            why: "Pairs vanish because a xor a is 0, while a single unpaired value survives unchanged.",
            codeLine: 8,
          });

          steps.push({
            title: `Answer: ${x}`,
            tracks: [
              track("the numbers", nums, nums.map((v) => (v === shownLonely ? "good" : "dim"))),
              valueTrack("answer", x, "result", "the single value"),
              bitRow("answer in binary (" + width + " bits)", x, width, null, "result", "result", "dim"),
            ],
            counters: [count("numbers read", n, n), count("answer", x)],
            legend: LEG,
            happened: `After one pass the accumulator holds ${x} — the value without a partner.`,
            why: "The answer appeared automatically; no sorting or counting table was needed.",
            codeLine: 8,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "single-number-ii",
    title: "Single Number II",
    category: "Bits & Bit Tricks",
    difficulty: "Advanced",
    description: "Find the one value that appears once when every other value appears three times.",
    input: { label: "The numbers", default: "2, 2, 3, 2", parse: "ints" },
    approaches: [
      {
        name: "Count Bits Modulo Three",
        complexity: "O(32n) time, O(1) space",
        idea: [
          "Look at one bit position at a time. Add that bit across every input number, then take the total modulo 3.",
          "For a value that appears three times, its bit contributes a multiple of three and disappears. A bit from the single value contributes one, so it survives and can be placed back into the answer.",
        ],
        problem: [
          "The walk is over 32 bit positions rather than the numbers themselves, so it is still linear in n but with a noticeable constant factor. It also assumes the triples are exact.",
        ],
        code: {
          c: `#include <stdio.h>

/* Add each bit column, then reduce it modulo 3. */
unsigned int single_number(const int *a, int n) {
    unsigned int result = 0;
    for (int bit = 0; bit < 32; bit++) {
        int ones = 0;
        for (int i = 0; i < n; i++)
            ones += ((unsigned int)a[i] >> bit) & 1u;
        if (ones % 3 != 0)
            result |= 1u << bit;
    }
    return result;
}

int main(void) {
    int a[] = {2, 2, 3, 2};
    printf("%u\\n", single_number(a, 4)); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// A bit that appears three times cancels modulo 3.
unsigned int singleNumber(const std::vector<int>& a) {
    unsigned int result = 0;
    for (int bit = 0; bit < 32; ++bit) {
        int ones = 0;
        for (int v : a)
            ones += (static_cast<unsigned int>(v) >> bit) & 1u;
        if (ones % 3 != 0)
            result |= 1u << bit;
    }
    return result;
}

int main() {
    std::vector<int> a{2, 2, 3, 2};
    std::cout << singleNumber(a) << '\\n'; // 3
}`,
        },
        steps(nums) {
          const n = nums.length;
          const width = widthFor(nums, 4, 12);
          const LEG = ["read", "active", "done", "result", "good", "dim", "idle"];
          const bitCounts = new Array(32).fill(0);
          for (const v of nums)
            for (let b = 0; b < 32; b++)
              bitCounts[b] += ((v >>> b) & 1);
          const steps = [];
          const countCells = (hot, doneAbove) => {
            const cells = [];
            for (let b = width - 1; b >= 0; b--) {
              const state = b === hot ? "read" : doneAbove && b > hot ? "good" : "active";
              cells.push({ v: bitCounts[b], state, tag: "bit " + b });
            }
            return cells;
          };

          steps.push({
            title: "One counter per bit column",
            tracks: [
              track("the numbers", nums, fill(n, "idle")),
              { label: "1s counted per bit", cells: countCells(null, false) },
            ],
            counters: [count("numbers read", 0, n), count("bit columns", width)],
            legend: LEG,
            happened: `The row holds ${nums.join(", ")}. Every bit column starts with a count of zero.`,
            why: "We are not comparing whole numbers — we are counting how many times each bit is switched on.",
            codeLine: 5,
          });

          for (let i = 0; i < n; i++) {
            steps.push({
              title: `${nums[i]} adds its bits to the counters`,
              tracks: [
                track("the numbers", nums, paint(fill(n, i === 0 ? "idle" : "done"), { [i]: "read" })),
                bitRow(`${nums[i]} in binary (${width} bits)`, nums[i], width, null, "read", "active", "idle"),
                { label: "1s counted per bit", cells: countCells(null, false) },
              ],
              counters: [count("numbers read", i + 1, n), count("bit columns", width)],
              legend: LEG,
              happened: `The 1s inside ${nums[i]} are added into their matching bit counters.`,
              why: "After every number has been seen, each counter tells us how many inputs contributed that bit.",
              codeLine: 7,
            });
          }

          const answerBits = [];
          for (let b = 0; b < 32; b++)
            if (bitCounts[b] % 3 !== 0) answerBits.push(b);
          for (let b = width - 1; b >= 0; b--) {
            const rem = bitCounts[b] % 3;
            steps.push({
              title: `Bit ${b}: ${bitCounts[b]} mod 3 = ${rem}`,
              tracks: [
                track("the numbers", nums, fill(n, "dim")),
                {
                  label: "reduce each column",
                  cells: (() => {
                    const cells = [];
                    for (let k = width - 1; k >= 0; k--) {
                      const state = k === b ? "read" : k > b ? "good" : "active";
                      cells.push({ v: bitCounts[k] + " % 3 = " + (bitCounts[k] % 3), state, tag: "bit " + k });
                    }
                    return cells;
                  })(),
                },
              ],
              counters: [count("columns reduced", width - b, width), count("kept so far", rem ? "yes" : "no")],
              legend: LEG,
              happened: `Column ${b} holds ${bitCounts[b]} ones. Reducing modulo 3 leaves ${rem}.`,
              why: rem
                ? `A remainder of ${rem} means the single value has a 1 in bit ${b}, so that bit is kept.`
                : "A remainder of zero means only complete triples used this bit, so it is dropped.",
              codeLine: 8,
            });
          }

          const answer = answerBits.reduce((acc, b) => acc + Math.pow(2, b), 0) | 0;
          const shown = answer & ((1 << width) - 1);
          steps.push({
            title: `Answer: ${answer}`,
            tracks: [
              track("the numbers", nums, nums.map((v) => (v === answer ? "good" : "dim"))),
              valueTrack("answer", answer, "result", "surviving bits"),
              bitRow(`answer in binary (${width} bits)`, shown, width, null, "result", "result", "dim"),
            ],
            counters: [count("numbers read", n, n), count("answer", answer)],
            legend: LEG,
            happened: `The surviving bit positions rebuild the number ${answer}.`,
            why: "Every bit that was not part of a full triple belongs to the value that appeared only once.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "number-of-1-bits",
    title: "Number of 1 Bits",
    category: "Bits & Bit Tricks",
    difficulty: "Beginner",
    description: "Count how many bits are switched on in a number.",
    input: { label: "A whole number", default: "11", parse: "int" },
    approaches: [
      {
        name: "Clear the Lowest Set Bit",
        complexity: "O(k) time for k set bits, O(1) space",
        idea: [
          "The expression n & (n - 1) erases the lowest 1 bit of n and leaves the rest untouched. Repeating it removes one set bit per round.",
          "Count the rounds until n becomes zero. The count is exactly the number of 1 bits.",
        ],
        problem: [
          "It only loops once per set bit, which is great for sparse numbers, but the binary view still has a fixed width; very large or negative values need a note about which bits are shown.",
        ],
        code: {
          c: `#include <stdio.h>

/* n & (n - 1) removes the lowest set bit each round. */
int count_ones(unsigned int n) {
    int count = 0;
    while (n != 0) {
        n = n & (n - 1);
        count++;
    }
    return count;
}

int main(void) {
    printf("%d\\n", count_ones(11)); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>

// Clearing the lowest set bit once per 1 bit.
int countOnes(unsigned int n) {
    int count = 0;
    while (n != 0) {
        n = n & (n - 1);
        ++count;
    }
    return count;
}

int main() {
    std::cout << countOnes(11) << '\\n'; // 3
}`,
        },
        steps(value) {
          const start = Math.trunc(value);
          let n = start >>> 0;
          const width = clamp(Math.max(8, bitLength(start)), 8, 12);
          const LEG = ["read", "compare", "done", "result", "good", "bad", "dim", "idle"];
          const steps = [];
          let ones = 0;

          steps.push({
            title: `Start with ${start} (${bits(n, width)})`,
            tracks: [
              bitRow(`n in binary (${width} bits)`, n, width),
              valueTrack("ones counted", 0, "idle", "count starts at zero"),
            ],
            counters: [count("ones counted", 0), count("rounds", 0)],
            legend: LEG,
            happened: `The low ${width} bits of ${start} are ${bits(n, width)}. The counter is still zero.`,
            why: "Each round will switch off exactly one 1 bit, so the number of rounds is the answer.",
            codeLine: 4,
          });

          let rounds = 0;
          while (n !== 0 && rounds < 32) {
            const lowest = lowOnes(n, width)[0];
            const before = n;
            steps.push({
              title: lowest == null ? "The lowest 1 bit is above the displayed bits" : `Lowest 1 bit is at position ${lowest}`,
              tracks: [
                bitRow(`n in binary (${width} bits)`, n, width, lowest, "compare", "done", "idle"),
                valueTrack("ones counted", ones, "idle", "not cleared yet"),
              ],
              counters: [count("ones counted", ones), count("rounds", rounds)],
              legend: LEG,
              happened: `The rightmost switched-on bit is the next one to remove.`,
              why: "n - 1 flips that bit to 0 and turns all lower zeros into ones, so ANDing with the old n clears exactly that bit.",
              codeLine: 6,
            });

            n = (n & (n - 1)) >>> 0;
            ones++;
            rounds++;
            steps.push({
              title: `Clear it → ${bits(n, width)}, count = ${ones}`,
              tracks: [
                bitRow(`n in binary (${width} bits)`, n, width, null, "read", "done", "idle"),
                valueTrack("ones counted", ones, "result", "one bit removed"),
              ],
              counters: [count("ones counted", ones), count("rounds", rounds)],
              legend: LEG,
              happened: `The lowest 1 bit of ${bits(before, width)} is gone, leaving ${bits(n, width)}.`,
              why: "One round always removes exactly one set bit, never zero and never two.",
              codeLine: 6,
            });
          }

          steps.push({
            title: n === 0 ? "No 1 bits left" : "Stopped after 32 rounds",
            tracks: [
              bitRow(`n in binary (${width} bits)`, n, width, null, "read", "done", "idle"),
              valueTrack("ones counted", ones, "result", "all removed"),
            ],
            counters: [count("ones counted", ones), count("rounds", rounds)],
            legend: LEG,
            happened: n === 0 ? "Every set bit has been cleared, so the loop has nothing left to do." : "The safety limit of 32 rounds was reached.",
            why: "A 32-bit value can contain at most 32 ones, so the loop can never run longer than that.",
            codeLine: 5,
          });

          steps.push({
            title: `Answer: ${ones} one ${ones === 1 ? "bit" : "bits"}`,
            tracks: [
              bitRow(`original in binary (${width} bits)`, start, width, null, "result", "good", "dim"),
              valueTrack("answer", ones, "result", "number of 1 bits"),
            ],
            counters: [count("ones counted", ones), count("answer", ones)],
            legend: LEG,
            happened: `${start} contains ${ones} switched-on ${ones === 1 ? "bit" : "bits"}.`,
            why: "We removed one set bit per round, so the number of rounds is precisely the bit count.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "counting-bits",
    title: "Counting Bits",
    category: "Bits & Bit Tricks",
    difficulty: "Intermediate",
    description: "List the number of 1 bits for every value from 0 to n.",
    input: { label: "n", default: "8", parse: "int" },
    approaches: [
      {
        name: "Build on Half the Number",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Shifting a number right by one throws away its last bit. So bits[i] is simply bits[i >> 1] plus the bit that was thrown away, i & 1.",
          "Because i >> 1 is always smaller than i, the answer for every value can be filled in one increasing pass.",
        ],
        problem: [
          "The result array costs one slot per number from 0 to n. When n is large that is O(n) memory, even though any single entry only needs an earlier entry.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

/* bits[i] = bits[i >> 1] + (i & 1). */
int *count_bits(int n) {
    int *bits = calloc((size_t)n + 1, sizeof(int));
    for (int i = 1; i <= n; i++)
        bits[i] = bits[i >> 1] + (i & 1);
    return bits;
}

int main(void) {
    int n = 8;
    int *bits = count_bits(n);
    for (int i = 0; i <= n; i++)
        printf("%d ", bits[i]); /* 0 1 1 2 1 2 2 3 */
    printf("\\n");
    free(bits);
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// Each value borrows the count of its right-shifted half.
std::vector<int> countBits(int n) {
    std::vector<int> bits(n + 1, 0);
    for (int i = 1; i <= n; ++i)
        bits[i] = bits[i >> 1] + (i & 1);
    return bits;
}

int main() {
    auto bits = countBits(8);
    for (int x : bits) std::cout << x << ' '; // 0 1 1 2 1 2 2 3
    std::cout << '\\n';
}`,
        },
        steps(value) {
          const wanted = Math.trunc(value);
          const N = clamp(wanted, 0, 24);
          const width = widthFor([N], 3, 8);
          const LEG = ["read", "compare", "done", "result", "good", "bad", "dim", "idle"];
          const numbers = [];
          for (let i = 0; i <= N; i++) numbers.push(i);
          const dp = new Array(N + 1).fill("—");
          dp[0] = 0;
          const steps = [];

          steps.push({
            title: wanted < 0 ? "n is negative — showing the zero case" : `Fill 0 through ${N}, starting with bits[0] = 0`,
            tracks: [
              track("values", numbers, fill(numbers.length, "idle")),
              track("1-bit counts", dp, dp.map((v, i) => (i === 0 ? "done" : "idle"))),
              bitRow("0 in binary (" + width + " bits)", 0, width, null, "read", "done", "idle"),
            ],
            counters: [count("values filled", 1, N + 1), count("answer at n", dp[N])],
            legend: LEG,
            happened: wanted < 0
              ? `${wanted} is below zero; the counting problem starts at 0, so only bits[0] is meaningful here.`
              : `The table has room for every value from 0 to ${N}. Only bits[0] is known so far, and it is 0.`,
            why: "Starting with a known zero lets every later entry reuse an earlier one.",
            codeLine: 4,
          });

          if (wanted < 0) {
            steps.push({
              title: "No non-negative values to fill",
              tracks: [
                track("values", numbers, fill(numbers.length, "dim")),
                track("1-bit counts", dp, ["result"]),
              ],
              counters: [count("values filled", 1, 1), count("answer at n", 0)],
              legend: LEG,
              happened: "The loop from 1 to n is empty, so the table stays at its single entry.",
              why: "A negative n never enters the increasing pass at all.",
              codeLine: 6,
            });
          }

          for (let i = 1; i <= N; i++) {
            dp[i] = dp[i >> 1] + (i & 1);
            steps.push({
              title: `bits[${i}] = bits[${i >> 1}] + ${i & 1} = ${dp[i]}`,
              tracks: [
                track("values", numbers, numbers.map((v) => (v < i ? "done" : v === i ? "read" : "idle"))),
                track("1-bit counts", dp, dp.map((v, k) => (k < i ? "done" : k === i ? "result" : "idle"))),
                bitRow(`${i} in binary (${width} bits)`, i, width, 0, "compare", "done", "idle"),
              ],
              counters: [count("values filled", i + 1, N + 1), count("ones in " + i, dp[i])],
              legend: LEG,
              happened: `Half of ${i} is ${i >> 1}, whose count is ${dp[i >> 1]}. Its last bit is ${i & 1}, so the total is ${dp[i]}.`,
              why: "The half was filled earlier, so this entry costs one lookup and one addition.",
              codeLine: 7,
            });
          }

          steps.push({
            title: `Answer: bits = ${dp.join(", ")}`,
            tracks: [
              track("values", numbers, numbers.map((v) => (v === N ? "result" : "good"))),
              track("1-bit counts", dp, dp.map((v) => "result")),
              bitRow(`${N} in binary (${width} bits)`, N, width, null, "result", "result", "dim"),
            ],
            counters: [count("values filled", N + 1, N + 1), count("answer", `bits[${N}] = ${dp[N]}`)],
            legend: LEG,
            happened: `Every entry from 0 to ${N} has its 1-bit count. The last one is ${dp[N]}.`,
            why: "One increasing pass filled the whole table, and each entry reused a smaller one.",
            codeLine: 7,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "reverse-bits",
    title: "Reverse Bits",
    category: "Bits & Bit Tricks",
    difficulty: "Intermediate",
    description: "Flip an 8-bit number end to end so its lowest bit becomes its highest bit.",
    input: { label: "An 8-bit number", default: "13", parse: "int" },
    approaches: [
      {
        name: "Shift Out and Shift In",
        complexity: "O(8) time, O(1) space",
        idea: [
          "Read the input one bit at a time from the right. Push each bit into the result from the right as well, but shift the result left first.",
          "After eight rounds the first bit read has travelled all the way to the top, which is exactly a reversal.",
        ],
        problem: [
          "The width is fixed. This version is deliberately an 8-bit demo; a 32-bit version needs 32 rounds and care with the sign bit.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdint.h>

/* Reverse the low 8 bits: take the last bit, push it into result. */
uint8_t reverse_bits(uint8_t n) {
    uint8_t result = 0;
    for (int i = 0; i < 8; i++) {
        result = (uint8_t)((result << 1) | (n & 1));
        n >>= 1;
    }
    return result;
}

int main(void) {
    printf("%u\\n", reverse_bits(13)); /* 176 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <cstdint>

// Take the last bit of n and push it onto the end of result.
std::uint8_t reverseBits(std::uint8_t n) {
    std::uint8_t result = 0;
    for (int i = 0; i < 8; ++i) {
        result = static_cast<std::uint8_t>((result << 1) | (n & 1));
        n >>= 1;
    }
    return result;
}

int main() {
    std::cout << static_cast<int>(reverseBits(13)) << '\\n'; // 176
}`,
        },
        steps(value) {
          const raw = Math.trunc(value);
          const source = raw & 0xff;
          const width = 8;
          const LEG = ["read", "compare", "done", "result", "dim", "idle"];
          const steps = [];
          let working = source;
          let result = 0;

          steps.push({
            title: `Reverse ${source} = ${bits(source, width)}`,
            tracks: [
              bitRow("input in binary (8 bits)", source, width),
              bitRow("result in binary (8 bits)", 0, width),
            ],
            counters: [count("bits moved", 0, 8), count("result so far", 0)],
            legend: LEG,
            happened: `Only the low 8 bits of ${raw} are used, so the input is ${bits(source, width)}. The result starts as 00000000.`,
            why: "Reversal reads from the right of the input and writes towards the left of the result.",
            codeLine: 5,
          });

          for (let i = 0; i < 8; i++) {
            const bit = working & 1;
            const before = result;
            result = ((result << 1) | bit) & 0xff;
            const hot = i;
            steps.push({
              title: `Take bit ${i} (${bit}) → result ${bits(result, width)}`,
              tracks: [
                bitRow("input in binary (8 bits)", source, width, hot, "compare", "done", "dim"),
                bitRow("result in binary (8 bits)", result, width, 0, "read", "done", "idle"),
              ],
              counters: [count("bits moved", i + 1, 8), count("result so far", result)],
              legend: LEG,
              happened: `The next input bit from the right is ${bit}. Shifting ${bits(before, width)} left and appending ${bit} gives ${bits(result, width)}.`,
              why: "Bits are consumed in reverse order and appended in that same order, so the final arrangement is flipped.",
              codeLine: 7,
            });
            working >>= 1;
          }

          steps.push({
            title: `Answer: ${result} (${bits(result, width)})`,
            tracks: [
              bitRow("original in binary (8 bits)", source, width, null, "result", "result", "dim"),
              bitRow("reversed in binary (8 bits)", result, width, null, "result", "result", "dim"),
            ],
            counters: [count("bits moved", 8, 8), count("answer", result)],
            legend: LEG,
            happened: `${bits(source, width)} becomes ${bits(result, width)}, which is ${result} in decimal.`,
            why: "Eight rounds are enough for an 8-bit number, so the reversal is complete.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "power-of-two",
    title: "Power of Two",
    category: "Bits & Bit Tricks",
    difficulty: "Beginner",
    description: "Decide whether a number is 1, 2, 4, 8 and so on, using its bits.",
    input: { label: "A whole number", default: "16", parse: "int" },
    approaches: [
      {
        name: "Clear the Only Set Bit",
        complexity: "O(1) time, O(1) space",
        idea: [
          "A power of two has exactly one bit switched on. Subtracting one flips that bit off and turns every lower bit on.",
          "So for a positive power of two, n & (n - 1) is zero. Any other positive number leaves at least one bit behind.",
        ],
        problem: [
          "Zero and negative numbers must be rejected first; the bit test alone would happily call a negative value a power of two.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* A power of two has exactly one set bit. */
bool is_power_of_two(long long n) {
    if (n <= 0)
        return false;
    return (n & (n - 1)) == 0;
}

int main(void) {
    printf("%s\\n", is_power_of_two(16) ? "yes" : "no"); /* yes */
    return 0;
}`,
          cpp: `#include <iostream>

// One set bit, and a positive value, means power of two.
bool isPowerOfTwo(long long n) {
    if (n <= 0)
        return false;
    return (n & (n - 1)) == 0;
}

int main() {
    std::cout << (isPowerOfTwo(16) ? "yes" : "no") << '\\n'; // yes
}`,
        },
        steps(value) {
          const n = Math.trunc(value);
          const width = clamp(Math.max(8, bitLength(n)), 8, 12);
          const LEG = ["read", "compare", "active", "done", "result", "good", "bad", "dim", "idle"];
          const steps = [];
          const positive = n > 0;
          const low = n & ((1 << width) - 1);
          const prev = n - 1;

          steps.push({
            title: `Test ${n} = ${bits(low, width)}`,
            tracks: [
              bitRow(`n in binary (${width} bits)`, low, width),
              valueTrack("power of two?", "not yet", "idle", "test pending"),
            ],
            counters: [count("bit checks", 0), count("n", n)],
            legend: LEG,
            happened: `The low ${width} bits of ${n} are ${bits(low, width)}.`,
            why: "A power of two is easy to recognise from its bit pattern: a single 1 and a lot of 0s.",
            codeLine: 4,
          });

          steps.push({
            title: positive ? `${n} is positive → continue` : `${n} is not positive → reject`,
            tracks: [
              bitRow(`n in binary (${width} bits)`, low, width, null, "read", "compare", "idle"),
              valueTrack("sign check", positive ? "passes" : "fails", positive ? "good" : "bad", "must be > 0"),
            ],
            counters: [count("bit checks", 0), count("n", n)],
            legend: LEG,
            happened: positive ? `${n} is greater than zero, so the bit test can run.` : `${n} is zero or negative, which can never be a positive power of two.`,
            why: "The subtraction trick is only meaningful for positive values; the sign check removes that whole awkward range.",
            codeLine: 5,
          });

          if (!positive) {
            steps.push({
              title: `${n} cannot be a power of two`,
              tracks: [
                bitRow(`n in binary (${width} bits)`, low, width, null, "bad", "bad", "dim"),
                valueTrack("answer", "no", "result", "sign rules it out"),
              ],
              counters: [count("bit checks", 1), count("answer", "no")],
              legend: LEG,
              happened: `${n} is zero or negative, so there is no positive power of two to find.`,
              why: "The sequence 1, 2, 4, 8, ... never contains zero or a negative value.",
              codeLine: 6,
            });
            return steps;
          }

          const setBits = lowOnes(low, width).length;
          steps.push({
            title: `${n} uses ${setBits} set bit${setBits === 1 ? "" : "s"}`,
            tracks: [
              bitRow(`n in binary (${width} bits)`, low, width, null, "read", "result", "idle"),
              valueTrack("set bits", setBits, "active", "in the shown width"),
            ],
            counters: [count("bit checks", 1), count("set bits", setBits)],
            legend: LEG,
            happened: `Looking at the displayed bits, ${n} has ${setBits} bit${setBits === 1 ? "" : "s"} switched on.`,
            why: "A true power of two has exactly one set bit; this row makes that pattern visible.",
            codeLine: 7,
          });

          steps.push({
            title: `Subtracting 1 will clear that lone 1`,
            tracks: [
              bitRow(`n in binary (${width} bits)`, low, width, null, "compare", "result", "dim"),
              valueTrack("next move", "n - 1", "compare", "flip the lowest 1 and all zeros below it"),
            ],
            counters: [count("bit checks", 1), count("set bits", setBits)],
            legend: LEG,
            happened: `Subtracting one from ${n} will flip its lowest set bit to 0 and fill the lower positions with 1s.`,
            why: "That is exactly the bit pattern that makes n & (n - 1) erase the lowest set bit.",
            codeLine: 7,
          });

          steps.push({
            title: `n - 1 = ${prev} = ${bits(prev, width)}`,
            tracks: [
              bitRow("n - 1 in binary", prev, width, null, "read", "done", "idle"),
              valueTrack("the flipped bit", "one 1 becomes 0", "compare", "lower bits become 1"),
            ],
            counters: [count("bit checks", 2), count("n - 1", prev)],
            legend: LEG,
            happened: `Subtracting one changes ${bits(low, width)} into ${bits(prev, width)}.`,
            why: "Within a single 1 bit, subtracting one clears it and fills every lower position with 1s.",
            codeLine: 7,
            showIdx: false,
          });

          const anded = n & prev;
          steps.push({
            title: `n & (n - 1) = ${anded} = ${bits(anded, width)}`,
            tracks: [
              bitRow("n & (n - 1) in binary", anded, width, null, "result", "result", "dim"),
              valueTrack("is it zero?", anded === 0 ? "yes" : "no", anded === 0 ? "good" : "bad", "the deciding test"),
            ],
            counters: [count("bit checks", 3), count("AND result", anded)],
            legend: LEG,
            happened: `The AND keeps only positions that are 1 in both values, and the result is ${anded}.`,
            why: "Clearing the lowest set bit of a one-bit number leaves nothing behind.",
            codeLine: 7,
          });

          const verdict = anded === 0;
          steps.push({
            title: verdict ? "Zero leftover → power of two" : "Non-zero leftover → not a power of two",
            tracks: [
              bitRow(`n in binary (${width} bits)`, low, width, null, "read", "result", "dim"),
              valueTrack("verdict", verdict ? "yes" : "no", verdict ? "good" : "bad", "checked against zero"),
            ],
            counters: [count("bit checks", 3), count("verdict", verdict ? "yes" : "no")],
            legend: LEG,
            happened: verdict
              ? `The AND came out zero and ${n} is positive, so ${n} is a power of two.`
              : `The AND still has a set bit left, so ${n} has more than one 1 and is not a power of two.`,
            why: "For a positive value, a zero after clearing the lowest bit means there was only one bit to clear.",
            codeLine: 7,
          });

          steps.push({
            title: `Answer: ${verdict ? "yes" : "no"}`,
            tracks: [
              bitRow(`${n} in binary (${width} bits)`, low, width, null, verdict ? "result" : "bad", verdict ? "good" : "bad", "dim"),
              valueTrack("answer", verdict ? "yes" : "no", "result", "power of two?"),
            ],
            counters: [count("bit checks", 3), count("answer", verdict ? "yes" : "no")],
            legend: LEG,
            happened: verdict ? `${n} is exactly one power of two.` : `${n} is not a power of two.`,
            why: "The whole decision took constant time: one sign test, one subtraction and one AND.",
            codeLine: 7,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "bitwise-and-of-numbers-range",
    title: "Bitwise and of Numbers Range",
    category: "Bits & Bit Tricks",
    difficulty: "Intermediate",
    description: "AND together every number from left to right without walking the whole range.",
    input: { label: "Left, right", default: "5, 7", parse: "ints" },
    approaches: [
      {
        name: "Shift Until Both Ends Match",
        complexity: "O(1) time (at most 32 shifts), O(1) space",
        idea: [
          "In a range of consecutive numbers, low bits change constantly but the shared high bits stay put. The answer is exactly that common prefix, with zeros below it.",
          "Shift both ends right together until they are equal. Count the shifts, then put that many zeros back by shifting left.",
        ],
        problem: [
          "The method quietly assumes left and right are non-negative; negative values need careful 32-bit treatment because the sign bit never moves.",
        ],
        code: {
          c: `#include <stdio.h>

/* The common prefix of left and right survives the range and. */
int range_bitwise_and(int left, int right) {
    int shifts = 0;
    while (left < right) {
        left >>= 1;
        right >>= 1;
        shifts++;
    }
    return left << shifts;
}

int main(void) {
    printf("%d\\n", range_bitwise_and(5, 7)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>

// Find the shared prefix, then restore the shifted zeros.
int rangeBitwiseAnd(int left, int right) {
    int shifts = 0;
    while (left < right) {
        left >>= 1;
        right >>= 1;
        ++shifts;
    }
    return left << shifts;
}

int main() {
    std::cout << rangeBitwiseAnd(5, 7) << '\\n'; // 4
}`,
        },
        steps(parsed) {
          const list = parsed.map((v) => Math.trunc(v));
          let left = list.length ? list[0] : 0;
          let right = list.length > 1 ? list[1] : left;
          if (left > right) { const t = left; left = right; right = t; }
          const clamped = left < 0 || right < 0;
          if (left < 0) left = 0;
          if (right < 0) right = 0;
          const width = clamp(Math.max(4, bitLength(right)), 4, 8);
          const LEG = ["read", "compare", "active", "done", "result", "good", "bad", "dim", "idle"];
          const steps = [];
          let shifts = 0;
          let a = left;
          let b = right;

          steps.push({
            title: clamped ? "Negative range shifted to 0 — showing the non-negative case" : `AND every number from ${left} to ${right}`,
            tracks: [
              bitRow(`left ${a} in binary (${width} bits)`, a, width, null, "read", "done", "idle"),
              bitRow(`right ${b} in binary (${width} bits)`, b, width, null, "read", "compare", "idle"),
              track("range ends", [left, right], ["good", "active"]),
            ],
            counters: [count("shifts", 0), count("range size", right - left + 1)],
            legend: LEG,
            happened: clamped
              ? "A negative end is outside this unsigned demo, so the range starts at 0 for the visual."
              : `The range runs from ${left} to ${right}. The answer must agree in every bit position along the way.`,
            why: "Instead of ANDing every value, we compare the two ends and keep only the high bits they already share.",
            codeLine: 4,
          });

          let guard = 0;
          while (a < b && guard < 32) {
            steps.push({
              title: `${bits(a, width)} and ${bits(b, width)} differ → shift`,
              tracks: [
                bitRow(`left ${a} in binary`, a, width, null, "compare", "done", "idle"),
                bitRow(`right ${b} in binary`, b, width, null, "compare", "done", "idle"),
              ],
              counters: [count("shifts", shifts), count("left", a), count("right", b)],
              legend: LEG,
              happened: `The two ends are not equal yet, so some low bit will change somewhere inside the range.`,
              why: "A differing low bit cannot survive in the final AND, so both values can drop it for now.",
              codeLine: 5,
            });

            a >>= 1;
            b >>= 1;
            shifts++;
            guard++;
            steps.push({
              title: `Shift ${shifts}: left ${a}, right ${b}`,
              tracks: [
                bitRow(`left ${a} in binary`, a, width),
                bitRow(`right ${b} in binary`, b, width),
                valueTrack("shifts counted", shifts, "active", "zeros to restore"),
              ],
              counters: [count("shifts", shifts), count("left", a), count("right", b)],
              legend: LEG,
              happened: `Both ends move one bit to the right, becoming ${a} and ${b}.`,
              why: "The count of shifts remembers how many zeros must be appended to the common prefix later.",
              codeLine: 6,
            });
          }

          steps.push({
            title: a === b ? `${a} and ${b} finally match` : "Safety limit reached",
            tracks: [
              bitRow(`left ${a} in binary`, a, width, null, "good", "done", "idle"),
              bitRow(`right ${b} in binary`, b, width, null, "good", "done", "idle"),
              valueTrack("common prefix", a, "result", "shared high bits"),
            ],
            counters: [count("shifts", shifts), count("prefix", a)],
            legend: LEG,
            happened: a === b ? `Both ends collapsed to the same value ${a}, so the shared prefix is ${bits(a, width)}.` : "The loop stopped at the 32-shift safety limit.",
            why: "Once the ends match, every number in the original range shares those leading bits.",
            codeLine: 5,
          });

          const answer = a * Math.pow(2, shifts);
          steps.push({
            title: `Put ${shifts} zero${shifts === 1 ? "" : "s"} back → ${answer}`,
            tracks: [
              bitRow(`prefix ${a} in binary`, a, width),
              bitRow(`answer ${answer} in binary`, answer, width, null, "result", "result", "dim"),
              valueTrack("zeros restored", shifts, "active", "shift left"),
            ],
            counters: [count("shifts", shifts), count("answer so far", answer)],
            legend: LEG,
            happened: `Shifting ${a} left by ${shifts} adds the zeros that the range forced to clear.`,
            why: "The high prefix survives, while all the changing low positions must end up as zero.",
            codeLine: 10,
          });

          steps.push({
            title: `Answer: ${answer}`,
            tracks: [
              bitRow(`answer ${answer} in binary (${width} bits)`, answer, width, null, "result", "result", "dim"),
              track("range ends", [left, right], ["dim", "dim"]),
              valueTrack("final AND", answer, "result", "every value from left to right"),
            ],
            counters: [count("shifts", shifts), count("answer", answer)],
            legend: LEG,
            happened: `ANDing all numbers from ${left} through ${right} gives ${answer}.`,
            why: "Only the prefix shared by both ends is still set in every value of the range.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "sum-of-two-integers",
    title: "Sum of Two Integers",
    category: "Bits & Bit Tricks",
    difficulty: "Advanced",
    description: "Add two numbers with xor and carry shifts instead of the plus operator.",
    input: { label: "Two numbers", default: "7, 5", parse: "ints" },
    approaches: [
      {
        name: "XOR Adds, AND Carries",
        complexity: "O(32) time, O(1) space",
        idea: [
          "Adding two bits without carrying is just xor. The positions where both bits are 1 produce a carry, which is (a & b) shifted left by one.",
          "Repeat with the xor as the new sum and the shifted carry as the new addend. When the carry becomes zero, the sum is finished.",
        ],
        problem: [
          "The loop depends on carries eventually disappearing. Fixed-width machines guarantee that within 32 rounds, but the reasoning is less obvious than a plain addition.",
        ],
        code: {
          c: `#include <stdio.h>

/* Add without +: xor is the sum, and <<1 is the carry. */
int add(int a, int b) {
    while (b != 0) {
        int carry = (a & b) << 1;
        a = a ^ b;
        b = carry;
    }
    return a;
}

int main(void) {
    printf("%d\\n", add(7, 5)); /* 12 */
    return 0;
}`,
          cpp: `#include <iostream>

// XOR gives the sum bits; AND shifted left gives the carry.
int add(int a, int b) {
    while (b != 0) {
        int carry = (a & b) << 1;
        a = a ^ b;
        b = carry;
    }
    return a;
}

int main() {
    std::cout << add(7, 5) << '\\n'; // 12
}`,
        },
        steps(parsed) {
          const list = parsed.map((v) => Math.trunc(v));
          let a = list.length ? list[0] : 0;
          let b = list.length > 1 ? list[1] : 0;
          const width = 8;
          const LEG = ["read", "compare", "active", "done", "result", "good", "dim", "idle"];
          const steps = [];
          let round = 0;

          steps.push({
            title: `Add ${a} and ${b} with bits`,
            tracks: [
              bitRow(`a = ${a} in binary (8 bits)`, a, width),
              bitRow(`b = ${b} in binary (8 bits)`, b, width),
            ],
            counters: [count("rounds", 0), count("carry", b)],
            legend: LEG,
            happened: `We start with a = ${a} and b = ${b}. The second value will act as the carry waiting to be added.`,
            why: "XOR can add bits without carrying; the AND tells us where a carry is needed.",
            codeLine: 4,
          });

          let guard = 0;
          while (b !== 0 && guard < 40) {
            round++;
            const oldA = a, oldB = b;
            const sum = a ^ b;
            steps.push({
              title: `Round ${round}: ${oldA} xor ${oldB} = ${sum}`,
              tracks: [
                bitRow("a xor b (sum bits)", sum, width, null, "result", "done", "idle"),
                bitRow(`b = ${oldB} in binary`, oldB, width, null, "compare", "done", "idle"),
                valueTrack("carry pending", oldB, "active", "still to add"),
              ],
              counters: [count("rounds", round), count("sum bits", sum)],
              legend: LEG,
              happened: `The xor of ${bits(oldA & 0xff, width)} and ${bits(oldB & 0xff, width)} is ${bits(sum & 0xff, width)}.`,
              why: "XOR gives 1 where exactly one input has a 1 — the correct sum bit before carries.",
              codeLine: 6,
            });

            const carry = (a & b) << 1;
            a = sum;
            b = carry;
            steps.push({
              title: `Carry ${oldA & oldB} << 1 = ${carry}`,
              tracks: [
                bitRow(`carry = ${carry} in binary`, carry, width, null, "result", "done", "idle"),
                bitRow(`b becomes ${carry}`, carry, width),
                valueTrack("carry pending", carry, b === 0 ? "good" : "active", b === 0 ? "none left" : "add next round"),
              ],
              counters: [count("rounds", round), count("carry", carry)],
              legend: LEG,
              happened: `Positions where both values had a 1 are shifted left to become the carry ${carry}.`,
              why: "A carry always moves one place to the left, exactly like carrying in ordinary addition.",
              codeLine: 5,
            });
            guard++;
          }

          steps.push({
            title: b === 0 ? `Carry is zero — stop with a = ${a}` : "Stopped at the safety limit",
            tracks: [
              bitRow(`a = ${a} in binary (8 bits)`, a, width, null, "good", "done", "idle"),
              bitRow("b = 0 in binary (8 bits)", b, width, null, "good", "dim", "idle"),
            ],
            counters: [count("rounds", round), count("sum", a)],
            legend: LEG,
            happened: b === 0 ? "No carry is left, so the value in a is the complete sum." : "The guard stopped a carry that refused to settle.",
            why: "When b is zero, there is nothing left to add, so the loop has finished its job.",
            codeLine: 4,
          });

          steps.push({
            title: `Answer: ${a}`,
            tracks: [
              bitRow(`sum = ${a} in binary (8 bits)`, a, width, null, "result", "result", "dim"),
              valueTrack("answer", a, "result", `${list[0] || 0} + ${list[1] || 0}`),
            ],
            counters: [count("rounds", round), count("answer", a)],
            legend: LEG,
            happened: `The carries have stopped, so the sum is ${a}.`,
            why: "Every carry was folded back in one place to the left, exactly as a normal addition would.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "subsets-with-bitmasks",
    title: "Subsets with Bitmasks",
    category: "Bits & Bit Tricks",
    difficulty: "Intermediate",
    description: "Use the binary form of a counter to choose which elements join each subset.",
    input: { label: "The numbers", default: "1, 2, 3", parse: "ints" },
    approaches: [
      {
        name: "Each Mask Picks a Subset",
        complexity: "O(2^k · k) time, O(2^k · k) output space",
        idea: [
          "For k elements there are 2^k masks, numbered 0 through 2^k - 1. Bit i of a mask decides whether element i is included.",
          "Counting the masks in binary therefore visits every possible subset exactly once, including the empty set at mask 0.",
        ],
        problem: [
          "The number of masks explodes with k: doubling the elements doubles the work. The visual limits itself to the first 8 elements so the rows stay readable.",
        ],
        code: {
          c: `#include <stdio.h>

/* Mask m picks element i when bit i of m is 1. */
void print_subsets(const int *a, int k) {
    int total = 1 << k;
    for (int m = 0; m < total; m++) {
        printf("{ ");
        for (int i = 0; i < k; i++)
            if (m & (1 << i))
                printf("%d ", a[i]);
        printf("}\\n");
    }
}

int main(void) {
    int a[] = {1, 2, 3};
    print_subsets(a, 3); /* 8 subsets, including the empty set */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// One mask per subset; bit i includes a[i].
void printSubsets(const std::vector<int>& a) {
    int k = static_cast<int>(a.size());
    int total = 1 << k;
    for (int m = 0; m < total; ++m) {
        std::cout << "{ ";
        for (int i = 0; i < k; ++i)
            if (m & (1 << i))
                std::cout << a[i] << ' ';
        std::cout << "}\\n";
    }
}

int main() {
    printSubsets({1, 2, 3}); // 8 subsets
}`,
        },
        steps(nums) {
          const fullCount = nums.length;
          const k = Math.min(fullCount, 8);
          const shown = nums.slice(0, k);
          const total = Math.pow(2, k);
          const width = Math.max(1, k);
          const LEG = ["read", "active", "done", "result", "good", "dim", "idle"];
          const steps = [];

          steps.push({
            title: `${k} element${k === 1 ? "" : "s"} → ${total} masks`,
            tracks: [
              track("the numbers", shown, fill(k, "idle")),
              bitRow(`mask 0 in binary (${width} bits)`, 0, width),
              { label: "subset so far", cells: [{ v: "∅", state: "dim", tag: "empty set" }] },
            ],
            counters: [count("masks tried", 0, total), count("subsets found", 0)],
            legend: LEG,
            happened: fullCount > 8
              ? `There are ${fullCount} numbers, but the visual shows the first ${k}. That gives ${total} masks to try.`
              : `There are ${k} numbers, so there are 2^${k} = ${total} masks, one per subset.`,
            why: "A mask is just a binary switchboard: each bit says yes or no for one element.",
            codeLine: 4,
          });

          for (let m = 0; m < total; m++) {
            const chosen = [];
            for (let i = 0; i < k; i++)
              if (m & (1 << i)) chosen.push(i);
            const subset = chosen.map((i) => shown[i]);
            steps.push({
              title: `Mask ${bits(m, width)} → {${subset.join(", ")}}`,
              tracks: [
                track("the numbers", shown, shown.map((v, i) => (chosen.includes(i) ? "good" : "dim"))),
                bitRow(`mask ${m} in binary (${width} bits)`, m, width, null, "result", "active", "dim"),
                {
                  label: "subset",
                  cells: subset.length
                    ? subset.map((v) => ({ v, state: "result" }))
                    : [{ v: "∅", state: "dim", tag: "empty set" }],
                },
              ],
              counters: [count("masks tried", m + 1, total), count("subsets found", m + 1, total)],
              legend: LEG,
              happened: subset.length
                ? `The 1 bits in ${bits(m, width)} select ${subset.join(", ")}.`
                : "All mask bits are 0, so nothing is selected — this is the empty subset.",
              why: "Reading the mask from right to left maps bit i directly onto element i.",
              codeLine: 5,
            });
          }

          const all = [];
          for (let m = 0; m < total; m++) {
            const subset = [];
            for (let i = 0; i < k; i++)
              if (m & (1 << i)) subset.push(shown[i]);
            all.push("{" + subset.join(",") + "}");
          }
          steps.push({
            title: `Answer: ${total} subsets`,
            tracks: [
              track("the numbers", shown, fill(k, "dim")),
              { label: "all subsets", cells: all.map((s) => ({ v: s, state: "result" })) },
            ],
            counters: [count("masks tried", total, total), count("answer", total)],
            legend: LEG,
            happened: `Every mask from 0 to ${total - 1} produced a distinct subset.`,
            why: "Counting all masks visits the whole power set once, with no duplicates.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });
})();
