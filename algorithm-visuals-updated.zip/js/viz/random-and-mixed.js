/* ============================================================
   DSA Visuals — Randomisation and Mixed Techniques
   Weighted picking, reservoir sampling, shuffling, average
   splitting, four-sum counting, offline DSU queries, index
   picking, refuelling and shortest superstrings.
   ============================================================ */
(function () {
  "use strict";
  const { count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const partsOf = (text) => String(text || "").split("|").map((p) => p.trim());
  const intsOf = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number).filter(Number.isFinite);

  /* ---------------------------------------------------------- */
  V.register({
    id: "random-pick-with-weight",
    title: "Random Pick with Weight",
    category: "Randomization",
    difficulty: "Intermediate",
    description: "Pick an index with probability proportional to its weight.",
    input: { label: "Weights", default: "1,3", parse: "string" },
    approaches: [
      {
        name: "Prefix Sums and Binary Search",
        complexity: "O(n) setup, O(log n) per pick",
        idea: [
          "Build prefix sums so weight i occupies the interval (prefix[i−1], prefix[i]]. A uniform random value in [0, total) lands in each interval with probability equal to its weight.",
          "Binary search for the first prefix greater than the random value. The resulting index is the weighted choice.",
        ],
        problem: [
          "Picking a random index uniformly ignores the weights; expanding each weight into repeated entries wastes memory.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <stdlib.h>\\n\\nint main(void) {\\n    int w[] = {1,3}, n = 2;\\n    int pref[2];\\n    pref[0] = w[0];\\n    for (int i = 1; i < n; i++) pref[i] = pref[i-1] + w[i];\\n\\n    int r = rand() % pref[n-1];\\n    int lo = 0, hi = n - 1;\\n    while (lo < hi) { int mid = (lo + hi) / 2; if (pref[mid] <= r) lo = mid + 1; else hi = mid; }\\n    printf(\\\"%d\\\\n\\\", lo); /* weighted index */\\n    return 0;\\n}`,
          cpp: `#include <cstdlib>\\n#include <iostream>\\n#include <numeric>\\n#include <vector>\\nusing namespace std;\\n\\nint pickIndex(vector<int>& w) {\\n    vector<int> pref(w.size());\\n    partial_sum(w.begin(), w.end(), pref.begin());\\n    int r = rand() % pref.back();\\n    return upper_bound(pref.begin(), pref.end(), r) - pref.begin();\\n}\\n\\nint main() {\\n    vector<int> w{1,3};\\n    cout << pickIndex(w) << '\\\\n'; // 0 with p=1/4, 1 with p=3/4\\n}`,
        },
        steps(text) {
          const weights = intsOf(text).filter((w) => w > 0).slice(0, 10);
          if (!weights.length) return [{
            title: "Give positive weights",
            tracks: [chips("weights", ["—"], "idle")],
            counters: [count("total weight", 0)],
            legend: LEG,
            happened: "There are no weights to sample.",
            why: "Each index needs a positive probability.",
          }];
          const pref = [];
          weights.forEach((w, i) => pref.push((i ? pref[i - 1] : 0) + w));
          const total = pref[pref.length - 1];
          const r = Math.floor(total / 2);
          const steps = [];
          steps.push({
            title: `Weights ${weights.join(", ")}`,
            tracks: [chips("weights", weights, "compare"), chips("prefix", pref, "idle")],
            counters: [count("total weight", total), count("indices", weights.length)],
            legend: LEG,
            happened: "Prefix sums partition [0, total) into intervals whose widths are the weights.",
            why: "A uniform draw over the total range is therefore not uniform over indices.",
            codeLine: 4,
          });
          steps.push({
            title: `Random draw r = ${r} in [0, ${total})`,
            tracks: [chips("prefix", pref, (i) => (pref[i] > r ? "read" : "done")), chips("intervals", weights.map((w, i) => `${i}: ${i ? pref[i - 1] : 0}–${pref[i]}`), (i) => (pref[i] > r && (i === 0 || pref[i - 1] <= r) ? "result" : "idle"))],
            counters: [count("draw", r), count("total weight", total)],
            legend: LEG,
            happened: `The draw falls inside index 1's interval because ${pref[0]} ≤ ${r} < ${pref[1]}.`,
            why: "The first prefix strictly above r identifies the interval containing the draw.",
            codeLine: 8,
          });
          let lo = 0, hi = weights.length - 1;
          while (lo < hi) {
            const mid = (lo + hi) >> 1;
            if (pref[mid] <= r) lo = mid + 1; else hi = mid;
          }
          steps.push({
            title: `Answer: index ${lo} (weight ${weights[lo]})`,
            tracks: [chips("weights", weights, (i) => (i === lo ? "result" : "dim")), chips("prefix", pref, (i) => (i === lo ? "result" : "dim"))],
            counters: [count("index", lo), count("probability", `${weights[lo]}/${total}`)],
            legend: LEG,
            happened: `Index ${lo} is chosen with probability ${weights[lo]}/${total}.`,
            why: "Binary search locates the unique interval containing r in logarithmic time.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "reservoir-sampling",
    title: "Reservoir Sampling",
    category: "Randomization",
    difficulty: "Intermediate",
    description: "Choose a uniform random item from a stream without storing the whole stream.",
    input: { label: "Stream values", default: "5,10,20,30,40,50", parse: "string" },
    approaches: [
      {
        name: "Reservoir of Size One",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "Keep the first item as the reservoir. For the i-th item (1-indexed), replace the reservoir with probability 1/i.",
          "At every prefix, each item seen so far has the same chance of surviving. Later items do not retroactively change the uniformity of earlier choices.",
        ],
        problem: [
          "Buffering the stream and picking an index at the end uses memory proportional to the stream length.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <stdlib.h>\\n\\nint main(void) {\\n    int stream[] = {5,10,20,30,40,50}, n = 6;\\n    int reservoir = stream[0];\\n\\n    for (int i = 1; i < n; i++) {\\n        int r = rand() % (i + 1);\\n        if (r == 0) reservoir = stream[i];\\n    }\\n\\n    printf(\\\"%d\\\\n\\\", reservoir); /* uniform sample */\\n    return 0;\\n}`,
          cpp: `#include <cstdlib>\\n#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint reservoirSample(vector<int>& stream) {\\n    int reservoir = stream[0];\\n    for (int i = 1; i < stream.size(); i++) {\\n        int r = rand() % (i + 1);\\n        if (r == 0) reservoir = stream[i];\\n    }\\n    return reservoir;\\n}\\n\\nint main() {\\n    vector<int> s{5,10,20,30,40,50};\\n    cout << reservoirSample(s) << '\\\\n';\\n}`,
        },
        steps(text) {
          const stream = intsOf(text).slice(0, 12);
          if (!stream.length) return [{
            title: "Give at least one stream value",
            tracks: [chips("stream", ["—"], "idle")],
            counters: [count("reservoir", 0)],
            legend: LEG,
            happened: "There is no stream.",
            why: "Sampling needs at least one item.",
          }];
          let reservoir = stream[0];
          const steps = [];
          steps.push({
            title: `Reservoir starts as ${reservoir}`,
            tracks: [chips("stream", stream, (i) => (i === 0 ? "result" : "idle")), chips("reservoir", [reservoir], "good")],
            counters: [count("seen", 1), count("reservoir", reservoir)],
            legend: LEG,
            happened: "The first item is always kept initially.",
            why: "With one item, it is trivially the uniform sample.",
            codeLine: 4,
          });
          for (let i = 1; i < stream.length; i++) {
            const r = ((i * 37) % 100) / 100;
            const take = r < 1 / (i + 1);
            if (take) reservoir = stream[i];
            steps.push({
              title: `Item ${i + 1} (${stream[i]}): r = ${r.toFixed(2)}, replace if r < ${(1 / (i + 1)).toFixed(2)}`,
              tracks: [chips("stream", stream, (j) => (j === i ? "active" : j < i ? "done" : "idle")), chips("reservoir", [reservoir], take ? "result" : "good")],
              counters: [count("seen", i + 1, stream.length), count("reservoir", reservoir)],
              legend: LEG,
              happened: take ? `Replaced the reservoir with ${stream[i]}.` : `Kept the existing reservoir value ${reservoir}.`,
              why: "Replacing with probability 1/(i+1) keeps every seen item equally likely.",
              codeLine: 7,
            });
          }
          steps.push({
            title: `Answer: sampled ${reservoir}`,
            tracks: [chips("stream", stream, (i) => (stream[i] === reservoir ? "result" : "done")), chips("reservoir", [reservoir], "result")],
            counters: [count("reservoir", reservoir), count("seen", stream.length)],
            legend: LEG,
            happened: `Every one of the ${stream.length} items had probability 1/${stream.length} of being chosen.`,
            why: "The final reservoir is uniform over the whole stream even though only one slot was stored.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "shuffle-an-array",
    title: "Shuffle an Array",
    category: "Randomization",
    difficulty: "Intermediate",
    description: "Shuffle an array so that every permutation is equally likely.",
    input: { label: "Array", default: "1,2,3,4,5", parse: "string" },
    approaches: [
      {
        name: "Fisher-Yates Shuffle",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "Walk from the last position down to the second. At position i, choose a random index j in 0..i and swap positions i and j.",
          "After the swap, position i is final and never touched again. Each of the n! permutations is produced with equal probability.",
        ],
        problem: [
          "Assigning each item an independent random key and sorting can bias the result and costs extra memory and sorting time.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <stdlib.h>\\n\\nint main(void) {\\n    int a[] = {1,2,3,4,5}, n = 5;\\n\\n    for (int i = n - 1; i > 0; i--) {\\n        int j = rand() % (i + 1);\\n        int t = a[i]; a[i] = a[j]; a[j] = t;\\n    }\\n\\n    for (int i = 0; i < n; i++) printf(\\\"%d \\\", a[i]);\\n    printf(\\\"\\\\n\\\");\\n    return 0;\\n}`,
          cpp: `#include <algorithm>\\n#include <cstdlib>\\n#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nvoid shuffleArray(vector<int>& a) {\\n    for (int i = a.size() - 1; i > 0; i--) {\\n        int j = rand() % (i + 1);\\n        swap(a[i], a[j]);\\n    }\\n}\\n\\nint main() {\\n    vector<int> a{1,2,3,4,5};\\n    shuffleArray(a);\\n    for (int x : a) cout << x << ' ';\\n    cout << '\\\\n';\\n}`,
        },
        steps(text) {
          const a = intsOf(text).slice(0, 12);
          if (!a.length) return [{
            title: "Give at least one number",
            tracks: [chips("array", ["—"], "idle")],
            counters: [count("swaps", 0)],
            legend: LEG,
            happened: "There is nothing to shuffle.",
            why: "The array needs at least one item.",
          }];
          const steps = [];
          steps.push({
            title: `Shuffle ${a.length} items`,
            tracks: [chips("array", a, "compare")],
            counters: [count("positions", a.length), count("swaps", 0)],
            legend: LEG,
            happened: "Fisher-Yates fixes one position per pass, from right to left.",
            why: "Positions to the right are already final and must not be disturbed.",
            codeLine: 4,
          });
          for (let i = a.length - 1; i > 0; i--) {
            const j = (i * 7 + 3) % (i + 1);
            const before = a[i];
            [a[i], a[j]] = [a[j], a[i]];
            steps.push({
              title: `Position ${i}: swap with random index ${j}`,
              tracks: [chips("array", a, (k) => (k === i ? "result" : k === j ? "active" : k > i ? "done" : "idle"))],
              counters: [count("swaps", a.length - i), count("fixed", a.length - i, a.length)],
              legend: LEG,
              happened: j === i ? `Index ${i} stayed in place.` : `${before} and ${a[i]} traded places.`,
              why: "Choosing j uniformly from 0..i gives every remaining item an equal chance at position i.",
              codeLine: 7,
            });
          }
          steps.push({
            title: `Answer: ${a.join(", ")}`,
            tracks: [chips("array", a, "result")],
            counters: [count("items", a.length), count("permutations", "n!")],
            legend: LEG,
            happened: "All positions are fixed, producing one of the equally likely permutations.",
            why: "Each pass multiplies the number of possibilities by exactly the size of its remaining range.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "split-array-with-same-average",
    title: "Split Array with Same Average",
    category: "Mix & Match",
    difficulty: "Advanced",
    description: "Decide whether a non-empty proper subset can have the same average as the whole array.",
    input: { label: "Numbers", default: "1,2,3,4,5,6,7,8", parse: "string" },
    approaches: [
      {
        name: "Subset Sums by Size",
        complexity: "O(n² × total) time",
        idea: [
          "A subset of size k with the same average must sum to total × k / n. If that value is not an integer, size k cannot work.",
          "Track every sum reachable with exactly k numbers. The answer is yes as soon as a reachable sum equals the required k-sized target for some k from 1 to n−1.",
        ],
        problem: [
          "Checking all subsets is exponential, and floating-point average comparisons can hide exact equality.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <stdbool.h>\\n\\nint main(void) {\\n    int a[] = {1,2,3,4,5,6,7,8}, n = 8;\\n    int total = 36, maxK = n / 2;\\n    bool dp[5][37] = {{true}};\\n\\n    for (int i = 0; i < n; i++)\\n        for (int k = maxK; k >= 1; k--)\\n            for (int s = total; s >= a[i]; s--)\\n                if (dp[k-1][s-a[i]]) dp[k][s] = true;\\n\\n    bool ok = false;\\n    for (int k = 1; k <= maxK; k++) {\\n        int target = total * k / n;\\n        if (total * k % n == 0 && dp[k][target]) ok = true;\\n    }\\n    printf(\\\"%s\\\\n\\\", ok ? \\\"true\\\" : \\\"false\\\"); /* true */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <numeric>\\n#include <unordered_set>\\n#include <vector>\\nusing namespace std;\\n\\nbool splitArraySameAverage(vector<int>& a) {\\n    int n = a.size(), total = accumulate(a.begin(), a.end(), 0);\\n    vector<unordered_set<int>> sums(n / 2 + 1);\\n    sums[0].insert(0);\\n    for (int x : a)\\n        for (int k = n / 2; k >= 1; k--)\\n            for (int s : vector<int>(sums[k-1].begin(), sums[k-1].end()))\\n                sums[k].insert(s + x);\\n    for (int k = 1; k <= n / 2; k++)\\n        if (total * k % n == 0 && sums[k].count(total * k / n)) return true;\\n    return false;\\n}\\n\\nint main() {\\n    vector<int> a{1,2,3,4,5,6,7,8};\\n    cout << (splitArraySameAverage(a) ? \\\"true\\\" : \\\"false\\\") << '\\\\n'; // true\\n}`,
        },
        steps(text) {
          const nums = intsOf(text).filter((x) => x >= 0).slice(0, 12);
          if (nums.length < 2) return [{
            title: "Give at least two numbers",
            tracks: [chips("numbers", nums.length ? nums : ["—"], "idle")],
            counters: [count("total", 0)],
            legend: LEG,
            happened: "A proper split needs at least two numbers.",
            why: "Both parts must be non-empty.",
          }];
          const n = nums.length;
          const total = nums.reduce((a, b) => a + b, 0);
          const maxK = Math.floor(n / 2);
          const sums = Array.from({ length: maxK + 1 }, () => new Set());
          sums[0].add(0);
          nums.forEach((x) => {
            for (let k = maxK; k >= 1; k--) {
              Array.from(sums[k - 1]).forEach((s) => sums[k].add(s + x));
            }
          });
          const steps = [];
          steps.push({
            title: `Total ${total}, average ${(total / n).toFixed(2)}`,
            tracks: [chips("numbers", nums, "compare"), chips("subset sizes", Array.from({ length: maxK }, (_, i) => i + 1), "idle")],
            counters: [count("total", total), count("size", n)],
            legend: LEG,
            happened: "A matching subset of size k must sum to total × k / n.",
            why: "Only sizes up to n/2 need checking, because the complement has the same average.",
            codeLine: 4,
          });
          let answer = false;
          let answerK = 0;
          for (let k = 1; k <= maxK; k++) {
            const target = total * k / n;
            const integral = (total * k) % n === 0;
            const reachable = integral && sums[k].has(target);
            if (reachable && !answer) { answer = true; answerK = k; }
            steps.push({
              title: `Size ${k}: ${integral ? `target sum ${target}` : "target is not an integer"}`,
              tracks: [chips("reachable sums", Array.from(sums[k]).sort((a, b) => a - b), (i) => (integral && Array.from(sums[k]).sort((a, b) => a - b)[i] === target ? "result" : "done")), chips("sizes", Array.from({ length: maxK }, (_, i) => i + 1), (i) => (i + 1 === k ? "read" : "idle"))],
              counters: [count("size", k), count("reachable sums", sums[k].size)],
              legend: LEG,
              happened: integral ? (reachable ? `Sum ${target} is reachable with ${k} numbers.` : `No ${k}-number subset reaches ${target}.`) : `total × ${k} / ${n} is not a whole number.`,
              why: "The subset sum table is built once and queried for each possible size.",
              codeLine: 10,
            });
          }
          steps.push({
            title: answer ? `Answer: yes, a size-${answerK} subset matches the average` : "Answer: no proper subset matches the average",
            tracks: [chips("numbers", nums, "done"), chips("result", [answer ? "true" : "false"], answer ? "result" : "bad")],
            counters: [count("match", answer ? 1 : 0), count("checked sizes", maxK)],
            legend: LEG,
            happened: answer ? `A subset of ${answerK} numbers sums to the required target.` : "No size produced the required exact sum.",
            why: "Equal averages are equivalent to equal exact sums at a fixed subset size.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "four-sum-ii",
    title: "Four Sum II",
    category: "Mix & Match",
    difficulty: "Advanced",
    description: "Count index quadruples from four arrays whose values sum to zero.",
    input: { label: "Four arrays separated by |", default: "1,2 | -2,-1 | -1,2 | 0,2", parse: "string" },
    approaches: [
      {
        name: "Meet in the Middle",
        complexity: "O(n²) time, O(n²) space",
        idea: [
          "Store the frequency of every sum A[i] + B[j]. Then for each pair C[k] + D[l], add the frequency of its negation.",
          "This replaces a four-way loop with two pair loops plus hash lookups. Indices are allowed to repeat across arrays, so order within each pair does not matter.",
        ],
        problem: [
          "Four nested loops take O(n⁴); sorting all pair sums would add an avoidable logarithmic factor.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int A[] = {1,2}, B[] = {-2,-1}, C[] = {-1,2}, D[] = {0,2};\\n    int n = 2, ans = 0;\\n    int sums[4], cnt = 0;\\n\\n    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) sums[cnt++] = A[i] + B[j];\\n    for (int k = 0; k < n; k++)\\n        for (int l = 0; l < n; l++) {\\n            int need = -(C[k] + D[l]);\\n            for (int t = 0; t < cnt; t++) if (sums[t] == need) ans++;\\n        }\\n\\n    printf(\\\"%d\\\\n\\\", ans); /* 2 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <unordered_map>\\n#include <vector>\\nusing namespace std;\\n\\nint fourSumCount(vector<int>& A, vector<int>& B, vector<int>& C, vector<int>& D) {\\n    unordered_map<int,int> freq;\\n    for (int a : A) for (int b : B) freq[a + b]++;\\n    int ans = 0;\\n    for (int c : C) for (int d : D) ans += freq[-(c + d)];\\n    return ans;\\n}\\n\\nint main() {\\n    vector<int> A{1,2}, B{-2,-1}, C{-1,2}, D{0,2};\\n    cout << fourSumCount(A, B, C, D) << '\\\\n'; // 2\\n}`,
        },
        steps(text) {
          const rows = partsOf(text).map((r) => intsOf(r)).filter((r) => r.length);
          const arrs = rows.slice(0, 4);
          while (arrs.length < 4) arrs.push([]);
          const [A, B, C, D] = arrs;
          if (!A.length || !B.length || !C.length || !D.length) return [{
            title: "Give four non-empty arrays",
            tracks: [chips("A", A.length ? A : ["—"], "idle"), chips("B", B.length ? B : ["—"], "idle")],
            counters: [count("quadruples", 0)],
            legend: LEG,
            happened: "At least one array is empty.",
            why: "A quadruple needs one index from each array.",
          }];
          const freq = new Map();
          const steps = [];
          const mapChips = (state) => chips("A+B sums", Array.from(freq.entries()).sort((a, b) => a[0] - b[0]).map(([s, c]) => `${s}×${c}`), state);
          steps.push({
            title: `Four arrays of length ${A.length}`,
            tracks: [chips("A", A, "compare"), chips("B", B, "compare"), chips("C", C, "compare"), chips("D", D, "compare")],
            counters: [count("pair sums", 0), count("quadruples", 0)],
            legend: LEG,
            happened: "First build the distribution of sums from A and B.",
            why: "Then every C+D pair needs exactly its negation from that distribution.",
            codeLine: 4,
          });
          A.forEach((a, ai) => {
            B.forEach((b, bi) => {
              const s = a + b;
              freq.set(s, (freq.get(s) || 0) + 1);
            });
            steps.push({
              title: `Added all pairs with A[${ai}] = ${a}`,
              tracks: [chips("A", A, (i) => (i === ai ? "active" : i < ai ? "done" : "idle")), mapChips("done")],
              counters: [count("pair sums", Array.from(freq.values()).reduce((x, y) => x + y, 0)), count("distinct sums", freq.size)],
              legend: LEG,
              happened: `A+B sum frequencies now cover ${freq.size} distinct values.`,
              why: "Duplicate sums are stored as counts rather than repeated entries.",
              codeLine: 7,
            });
          });
          let ans = 0;
          C.forEach((c, ci) => {
            D.forEach((d) => {
              const need = -(c + d);
              ans += freq.get(need) || 0;
            });
            steps.push({
              title: `Look up complements for C[${ci}] = ${c}`,
              tracks: [chips("C", C, (i) => (i === ci ? "active" : i < ci ? "done" : "idle")), mapChips("compare")],
              counters: [count("quadruples", ans), count("C index", ci + 1, C.length)],
              legend: LEG,
              happened: `All D values were paired with C[${ci}], adding matching A+B counts.`,
              why: "Each matching A+B sum forms a distinct quadruple through the current C,D pair.",
              codeLine: 10,
            });
          });
          steps.push({
            title: `Answer: ${ans} quadruple${ans === 1 ? "" : "s"}`,
            tracks: [chips("A+B sums", Array.from(freq.entries()).sort((a, b) => a[0] - b[0]).map(([s, c]) => `${s}×${c}`), "result"), chips("quadruples", [ans], "result")],
            counters: [count("quadruples", ans), count("distinct pair sums", freq.size)],
            legend: LEG,
            happened: `${ans} combinations of indices make the four values sum to zero.`,
            why: "Every zero-sum quadruple is counted once by its C+D pair and its matching A+B sum.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "offline-connectivity-queries",
    title: "Offline Connectivity Queries",
    category: "Mix & Match",
    difficulty: "Advanced",
    description: "Answer reachability queries while edges become usable up to a weight limit.",
    input: { label: "n | edges u,v,w ; … | queries x,y,limit ; …", default: "4 | 0,1,3; 1,2,5; 2,3,2 | 0,2,3; 0,3,2; 1,3,5", parse: "string" },
    approaches: [
      {
        name: "Sort Queries and Grow a DSU",
        complexity: "O((edges + queries) log edges + α(n))",
        idea: [
          "Sort edges by weight and queries by their limit. Process queries from smallest limit to largest, adding every edge whose weight is within the current limit.",
          "A disjoint-set union structure answers whether two nodes are connected in near-constant time. Once an edge is added it stays valid for all later limits.",
        ],
        problem: [
          "Running a fresh graph search per query repeats work and can be much slower for many queries.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <stdlib.h>\\n\\ntypedef struct { int u, v, w; } Edge;\\ntypedef struct { int x, y, lim, id; } Query;\\nint parent[16];\\nint find(int x) { return parent[x] == x ? x : (parent[x] = find(parent[x])); }\\nvoid unite(int a, int b) { a = find(a); b = find(b); if (a != b) parent[a] = b; }\\nint cmpE(const void *a, const void *b) { return ((Edge*)a)->w - ((Edge*)b)->w; }\\nint cmpQ(const void *a, const void *b) { return ((Query*)a)->lim - ((Query*)b)->lim; }\\n\\nint main(void) {\\n    int n = 4;\\n    Edge e[] = {{0,1,3},{1,2,5},{2,3,2}};\\n    Query q[] = {{0,2,3,0},{0,3,2,1},{1,3,5,2}};\\n    int answers[3], ei = 0;\\n    for (int i = 0; i < n; i++) parent[i] = i;\\n    qsort(e, 3, sizeof(Edge), cmpE);\\n    qsort(q, 3, sizeof(Query), cmpQ);\\n\\n    for (int i = 0; i < 3; i++) {\\n        while (ei < 3 && e[ei].w <= q[i].lim) unite(e[ei].u, e[ei++].v);\\n        answers[q[i].id] = find(q[i].x) == find(q[i].y);\\n    }\\n\\n    for (int i = 0; i < 3; i++) printf(\\\"%d \\\", answers[i]); /* 0 0 1 */\\n    printf(\\\"\\\\n\\\");\\n    return 0;\\n}`,
          cpp: `#include <algorithm>\\n#include <iostream>\\n#include <numeric>\\n#include <vector>\\nusing namespace std;\\n\\nstruct DSU {\\n    vector<int> p;\\n    DSU(int n) : p(n) { iota(p.begin(), p.end(), 0); }\\n    int find(int x) { return p[x] == x ? x : p[x] = find(p[x]); }\\n    void unite(int a, int b) { a = find(a); b = find(b); if (a != b) p[a] = b; }\\n};\\n\\nint main() {\\n    int n = 4;\\n    vector<array<int,3>> edges{{0,1,3},{1,2,5},{2,3,2}};\\n    vector<array<int,4>> queries{{0,2,3,0},{0,3,2,1},{1,3,5,2}};\\n    sort(edges.begin(), edges.end(), [](auto& a, auto& b) { return a[2] < b[2]; });\\n    sort(queries.begin(), queries.end(), [](auto& a, auto& b) { return a[2] < b[2]; });\\n    DSU dsu(n);\\n    vector<int> ans(3);\\n    int e = 0;\\n    for (auto& q : queries) {\\n        while (e < edges.size() && edges[e][2] <= q[2]) dsu.unite(edges[e][0], edges[e++][1]);\\n        ans[q[3]] = dsu.find(q[0]) == dsu.find(q[1]);\\n    }\\n    for (int x : ans) cout << x << ' ';\\n    cout << '\\\\n'; // 0 0 1\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const n = Math.max(2, Math.min(12, parseInt(parts[0], 10) || 4));
          const edges = String(parts[1] || "").split(";").map((chunk) => intsOf(chunk)).filter((e) => e.length >= 3).slice(0, 12).map(([u, v, w], i) => ({ u: Math.min(n - 1, u), v: Math.min(n - 1, v), w, i }));
          const queries = String(parts[2] || "").split(";").map((chunk) => intsOf(chunk)).filter((q) => q.length >= 3).slice(0, 10).map(([x, y, lim], i) => ({ x: Math.min(n - 1, x), y: Math.min(n - 1, y), lim, i }));
          if (!edges.length || !queries.length) return [{
            title: "Give edges and queries",
            tracks: [chips("edges", ["—"], "idle")],
            counters: [count("answers", 0)],
            legend: LEG,
            happened: "The input is incomplete.",
            why: "The offline method needs both an edge list and queries.",
          }];
          edges.sort((a, b) => a.w - b.w);
          const order = queries.slice().sort((a, b) => a.lim - b.lim);
          const parent = Array.from({ length: n }, (_, i) => i);
          const find = (x) => { while (parent[x] !== x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; };
          const unite = (a, b) => { a = find(a); b = find(b); if (a !== b) parent[a] = b; };
          const answers = Array(queries.length).fill(false);
          let ei = 0;
          const steps = [];
          const qChips = (stateFor) => chips("queries x,y,limit", queries.map((q) => `${q.x},${q.y} ≤ ${q.lim}`), stateFor);
          const eChips = (stateFor) => chips("edges u,v,w", edges.map((e) => `${e.u}-${e.v} (${e.w})`), stateFor);
          steps.push({
            title: `${n} nodes, ${edges.length} weighted edges, ${queries.length} queries`,
            tracks: [eChips("compare"), qChips("idle"), chips("parent", parent, "idle")],
            counters: [count("edges added", 0), count("answers", 0)],
            legend: LEG,
            happened: "Queries are about to be processed from the smallest limit upward.",
            why: "An edge usable at a small limit remains usable at every larger limit, so edges only need to be added once.",
            codeLine: 4,
          });
          order.forEach((q, qi) => {
            const added = [];
            while (ei < edges.length && edges[ei].w <= q.lim) {
              unite(edges[ei].u, edges[ei].v);
              added.push(edges[ei]);
              ei++;
            }
            const ok = find(q.x) === find(q.y);
            answers[q.i] = ok;
            steps.push({
              title: `Query (${q.x}, ${q.y}) with limit ${q.lim}: ${ok ? "connected" : "not connected"}`,
              tracks: [
                eChips((i) => (added.some((e) => e.i === edges[i].i) ? "result" : i < ei ? "done" : "idle")),
                qChips((i) => (queries[i].i === q.i ? "read" : "idle")),
                chips("parent", parent, (i) => (i === q.x || i === q.y ? "active" : "done")),
              ],
              counters: [count("edge limit", q.lim), count("yes answers", answers.filter(Boolean).length)],
              legend: LEG,
              happened: added.length ? `Added ${added.map((e) => `${e.u}-${e.v}`).join(", ")} before answering.` : "No new edges became usable.",
              why: "The DSU contains exactly the edges with weight at most the current limit.",
              codeLine: 12,
            });
          });
          steps.push({
            title: `Answers in original order: ${answers.map((b) => (b ? "yes" : "no")).join(", ")}`,
            tracks: [qChips((i) => (answers[i] ? "result" : "bad")), chips("parent", parent, "done")],
            counters: [count("yes answers", answers.filter(Boolean).length), count("queries", queries.length)],
            legend: LEG,
            happened: `Connectivity is ${answers.filter(Boolean).length ? `confirmed for ${answers.filter(Boolean).length}` : "not confirmed for any"} of the queries.`,
            why: "Sorting by limit lets a single growing DSU answer all queries without rebuilding the graph.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "random-pick-index",
    title: "Random Pick Index",
    category: "Mix & Match",
    difficulty: "Intermediate",
    description: "Return a uniformly random index of a target value in an array.",
    input: { label: "Numbers | target", default: "1,2,3,3,3 | 3", parse: "string" },
    approaches: [
      {
        name: "Reservoir over Matching Indices",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "Scan the array and count how many occurrences of the target have been seen. The count-th occurrence replaces the stored index with probability 1/count.",
          "Non-matching values are ignored, so the reservoir contains a uniform random matching index without storing all positions.",
        ],
        problem: [
          "Collecting every matching index uses memory proportional to the number of occurrences, which may be large.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <stdlib.h>\\n\\nint main(void) {\\n    int a[] = {1,2,3,3,3}, n = 5, target = 3;\\n    int seen = 0, pick = -1;\\n\\n    for (int i = 0; i < n; i++)\\n        if (a[i] == target) {\\n            seen++;\\n            if (rand() % seen == 0) pick = i;\\n        }\\n\\n    printf(\\\"%d\\\\n\\\", pick); /* uniform matching index */\\n    return 0;\\n}`,
          cpp: `#include <cstdlib>\\n#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint pick(vector<int>& a, int target) {\\n    int seen = 0, pick = -1;\\n    for (int i = 0; i < a.size(); i++)\\n        if (a[i] == target) {\\n            seen++;\\n            if (rand() % seen == 0) pick = i;\\n        }\\n    return pick;\\n}\\n\\nint main() {\\n    vector<int> a{1,2,3,3,3};\\n    cout << pick(a, 3) << '\\\\n';\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const nums = intsOf(parts[0]).slice(0, 16);
          const target = parseInt(parts[1], 10);
          if (!nums.length || !Number.isFinite(target)) return [{
            title: "Give numbers and a target",
            tracks: [chips("numbers", nums.length ? nums : ["—"], "idle")],
            counters: [count("matches", 0)],
            legend: LEG,
            happened: "The input is incomplete.",
            why: "The method needs values and a target to match.",
          }];
          const matches = nums.filter((x) => x === target);
          let seen = 0, pick = -1;
          const steps = [];
          steps.push({
            title: `Find a random index of ${target}`,
            tracks: [chips("numbers", nums, "compare"), chips("matching indices", nums.map((x, i) => (x === target ? i : null)).filter((x) => x !== null), "good")],
            counters: [count("matches", matches.length), count("pick", -1)],
            legend: LEG,
            happened: matches.length ? `${matches.length} positions hold the target.` : "The target does not appear.",
            why: "A uniform pick must give every matching index the same probability.",
            codeLine: 4,
          });
          nums.forEach((x, i) => {
            if (x !== target) return;
            seen++;
            const r = ((i * 37) % 100) / 100;
            const take = r < 1 / seen;
            if (take) pick = i;
            steps.push({
              title: `Occurrence ${seen} at index ${i}: r = ${r.toFixed(2)}`,
              tracks: [chips("numbers", nums, (j) => (j === i ? "active" : j < i ? "done" : "idle")), chips("pick", [pick], take ? "result" : "good")],
              counters: [count("matches seen", seen, matches.length), count("pick", pick)],
              legend: LEG,
              happened: take ? `This occurrence replaced the pick.` : `The previous pick ${pick} was kept.`,
              why: "Replacing with probability 1/seen keeps all matching indices equally likely.",
              codeLine: 8,
            });
          });
          steps.push({
            title: pick >= 0 ? `Answer: index ${pick}` : "Answer: target not found",
            tracks: [chips("numbers", nums, (i) => (i === pick ? "result" : "done")), chips("pick", [pick >= 0 ? pick : "none"], pick >= 0 ? "result" : "bad")],
            counters: [count("matches", matches.length), count("pick", pick)],
            legend: LEG,
            happened: pick >= 0 ? `Index ${pick} is a uniform random occurrence of ${target}.` : `${target} never occurs.`,
            why: "The reservoir holds one matching index and was updated with the correct probabilities.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "minimum-number-of-refueling-stops",
    title: "Minimum Number of Refueling Stops",
    category: "Mix & Match",
    difficulty: "Advanced",
    description: "Reach a target using the fewest refuelling stops.",
    input: { label: "Target | start fuel | stations pos,fuel ; …", default: "100 | 10 | 10,60; 20,30; 30,30; 60,40", parse: "string" },
    approaches: [
      {
        name: "Furthest Reach with a Max Heap",
        complexity: "O(stations log stations) time",
        idea: [
          "Drive as far as possible and remember the fuel of every station passed. When the next station or the target is out of reach, refuel from the largest remembered station.",
          "Refuelling at the station with the most fuel is safe because all passed stations are already behind the car. Each refuel is therefore one necessary stop in the best possible order.",
        ],
        problem: [
          "Choosing the nearest station or the first station encountered can waste stops on small fuel amounts.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int target = 100, fuel = 10, stops = 0;\\n    int pos[] = {10,20,30,60}, add[] = {60,30,30,40}, n = 4;\\n    int heap[8], hn = 0, prev = 0;\\n\\n    for (int i = 0; i < n; i++) {\\n        fuel -= pos[i] - prev;\\n        while (fuel < 0 && hn > 0) {\\n            int best = 0;\\n            for (int j = 1; j < hn; j++) if (heap[j] > heap[best]) best = j;\\n            fuel += heap[best]; heap[best] = heap[--hn]; stops++;\\n        }\\n        if (fuel < 0) { printf(\\\"-1\\\\n\\\"); return 0; }\\n        heap[hn++] = add[i];\\n        prev = pos[i];\\n    }\\n\\n    fuel -= target - prev;\\n    while (fuel < 0 && hn > 0) {\\n        int best = 0;\\n        for (int j = 1; j < hn; j++) if (heap[j] > heap[best]) best = j;\\n        fuel += heap[best]; heap[best] = heap[--hn]; stops++;\\n    }\\n    printf(\\\"%d\\\\n\\\", fuel >= 0 ? stops : -1); /* 2 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <queue>\\n#include <vector>\\nusing namespace std;\\n\\nint minRefuelStops(int target, int fuel, vector<vector<int>>& st) {\\n    priority_queue<int> pq;\\n    int stops = 0, prev = 0;\\n    for (auto& s : st) {\\n        fuel -= s[0] - prev;\\n        while (fuel < 0 && !pq.empty()) { fuel += pq.top(); pq.pop(); stops++; }\\n        if (fuel < 0) return -1;\\n        pq.push(s[1]);\\n        prev = s[0];\\n    }\\n    fuel -= target - prev;\\n    while (fuel < 0 && !pq.empty()) { fuel += pq.top(); pq.pop(); stops++; }\\n    return fuel >= 0 ? stops : -1;\\n}\\n\\nint main() {\\n    vector<vector<int>> st{{10,60},{20,30},{30,30},{60,40}};\\n    cout << minRefuelStops(100, 10, st) << '\\\\n'; // 2\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const target = Math.max(1, parseInt(parts[0], 10) || 100);
          let fuel = Math.max(0, parseInt(parts[1], 10) || 0);
          const stations = String(parts[2] || "").split(";").map((s) => intsOf(s)).filter((s) => s.length >= 2).slice(0, 12).map(([pos, add]) => ({ pos, add })).sort((a, b) => a.pos - b.pos);
          if (!stations.length) return [{
            title: "Give at least one station",
            tracks: [chips("stations", ["—"], "idle")],
            counters: [count("stops", 0)],
            legend: LEG,
            happened: "There are no stations to consider.",
            why: "Refuelling needs at least one station.",
          }];
          const steps = [];
          const labels = stations.map((s) => `${s.pos}:+${s.add}`);
          let prev = 0, stops = 0;
          let heap = [];
          const heapShow = () => (heap.length ? heap.slice().sort((a, b) => b - a) : ["empty"]);
          steps.push({
            title: `Target ${target}, start fuel ${fuel}`,
            tracks: [chips("stations", labels, "compare"), chips("fuel available", heapShow(), "idle")],
            counters: [count("fuel", fuel), count("stops", 0)],
            legend: LEG,
            happened: "No stations have been passed yet.",
            why: "Stations become available only after the car reaches their position.",
            codeLine: 4,
          });
          let failed = false;
          for (const [idx, st] of stations.entries()) {
            fuel -= st.pos - prev;
            const used = [];
            while (fuel < 0 && heap.length) {
              heap.sort((a, b) => b - a);
              const best = heap.shift();
              fuel += best;
              stops++;
              used.push(best);
            }
            const possible = fuel >= 0;
            if (possible) heap.push(st.add);
            steps.push({
              title: `Station ${idx + 1} at ${st.pos}${used.length ? `: refuel ${used.join(" + ")}` : ": no stop"}`,
              tracks: [chips("stations", labels, (i) => (i === idx ? "active" : i < idx ? "done" : "idle")), chips("fuel available", heapShow(), (i) => (i === 0 && used.length ? "result" : "idle"))],
              counters: [count("fuel", fuel), count("stops", stops)],
              legend: LEG,
              happened: possible ? `Fuel after arriving is ${fuel}; station fuel ${st.add} is now available.` : "Even the largest remembered station cannot reach this position.",
              why: "The largest remembered fuel is always the best choice for the next refuel.",
              codeLine: 9,
            });
            prev = st.pos;
            if (!possible) { failed = true; break; }
          }
          if (failed) return steps;
          fuel -= target - prev;
          const used = [];
          while (fuel < 0 && heap.length) {
            heap.sort((a, b) => b - a);
            const best = heap.shift();
            fuel += best;
            stops++;
            used.push(best);
          }
          steps.push({
            title: fuel >= 0 ? `Answer: ${stops} refuelling stop${stops === 1 ? "" : "s"}` : "Answer: target is unreachable",
            tracks: [chips("stations", labels, "done"), chips("fuel used at the end", used.length ? used : ["none"], used.length ? "result" : "dim")],
            counters: [count("fuel", fuel), count("stops", stops)],
            legend: LEG,
            happened: fuel >= 0 ? `The car reaches ${target} with ${stops} stops.` : "The car runs out of fuel before the target.",
            why: "Each refuel used the largest available tank, so no solution with fewer stops can exist.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "shortest-superstring",
    title: "Shortest Superstring",
    category: "Mix & Match",
    difficulty: "Advanced",
    description: "Find the shortest string that contains every word as a substring.",
    input: { label: "Words separated by |", default: "alex | loves | leetcode", parse: "string" },
    approaches: [
      {
        name: "Bitmask DP Over Word Orders",
        complexity: "O(2ⁿ × n²) time",
        idea: [
          "Precompute how many characters word j adds after word i, which is its length minus the longest suffix-prefix overlap. A superset's best length ending at j comes from adding j to a smaller superset ending at i.",
          "The mask records which words are already placed; the endpoint records the last word, since only its suffix can overlap the next word. Reconstructing parents recovers the actual string.",
        ],
        problem: [
          "Trying every permutation is factorial; many orders share the same set of placed words and the same last word.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <string.h>\\n\\nint overlap(char *a, char *b) {\\n    int n = strlen(a), m = strlen(b);\\n    for (int len = n < m ? n : m; len > 0; len--)\\n        if (strncmp(a + n - len, b, len) == 0) return len;\\n    return 0;\\n}\\n\\nint main(void) {\\n    char *w[] = {\\\"alex\\\", \\\"loves\\\", \\\"leetcode\\\"};\\n    int n = 3, full = 1 << n, INF = 1 << 30;\\n    int add[3][3], dp[8][3], par[8][3];\\n    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) add[i][j] = strlen(w[j]) - overlap(w[i], w[j]);\\n    for (int m = 0; m < full; m++) for (int i = 0; i < n; i++) dp[m][i] = INF;\\n    for (int i = 0; i < n; i++) dp[1 << i][i] = strlen(w[i]);\\n\\n    for (int m = 1; m < full; m++)\\n        for (int i = 0; i < n; i++) if ((m & (1 << i)) && dp[m][i] < INF)\\n            for (int j = 0; j < n; j++) if (!(m & (1 << j)) && dp[m][i] + add[i][j] < dp[m | 1 << j][j]) {\\n                dp[m | 1 << j][j] = dp[m][i] + add[i][j];\\n                par[m | 1 << j][j] = i;\\n            }\\n\\n    int best = 0;\\n    for (int i = 1; i < n; i++) if (dp[full-1][i] < dp[full-1][best]) best = i;\\n    printf(\\\"%d\\\\n\\\", dp[full-1][best]); /* 18 */\\n    return 0;\\n}`,
          cpp: `#include <algorithm>\\n#include <iostream>\\n#include <string>\\n#include <vector>\\nusing namespace std;\\n\\nint overlap(const string& a, const string& b) {\\n    for (int len = min(a.size(), b.size()); len > 0; len--)\\n        if (a.compare(a.size() - len, len, b, 0, len) == 0) return len;\\n    return 0;\\n}\\n\\nstring shortestSuperstring(vector<string>& w) {\\n    int n = w.size(), full = 1 << n;\\n    vector<vector<int>> add(n, vector<int>(n)), dp(full, vector<int>(n, 1e9)), par(full, vector<int>(n, -1));\\n    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) add[i][j] = w[j].size() - overlap(w[i], w[j]);\\n    for (int i = 0; i < n; i++) dp[1 << i][i] = w[i].size();\\n    for (int m = 1; m < full; m++)\\n        for (int i = 0; i < n; i++) if ((m & (1 << i)) && dp[m][i] < 1e9)\\n            for (int j = 0; j < n; j++) if (!(m & (1 << j)) && dp[m][i] + add[i][j] < dp[m | 1 << j][j]) {\\n                dp[m | 1 << j][j] = dp[m][i] + add[i][j];\\n                par[m | 1 << j][j] = i;\\n            }\\n    int best = min_element(dp[full-1].begin(), dp[full-1].end()) - dp[full-1].begin();\\n    string out; int m = full - 1, i = best;\\n    while (m) { int p = par[m][i]; out = (p < 0 ? w[i] : w[i].substr(overlap(w[p], w[i]))) + out; m ^= 1 << i; i = p; }\\n    return out;\\n}\\n\\nint main() {\\n    vector<string> w{\\\"alex\\\",\\\"loves\\\",\\\"leetcode\\\"};\\n    cout << shortestSuperstring(w) << '\\\\n'; // alexlovesleetcode\\n}`,
        },
        steps(text) {
          const words = partsOf(text).map((w) => w.replace(/\s/g, "")).filter(Boolean).slice(0, 4);
          if (!words.length) return [{
            title: "Give at least one word",
            tracks: [chips("words", ["—"], "idle")],
            counters: [count("length", 0)],
            legend: LEG,
            happened: "There are no words.",
            why: "The superstring needs at least one word.",
          }];
          const n = words.length;
          const full = 1 << n;
          const overlap = (a, b) => {
            for (let len = Math.min(a.length, b.length); len > 0; len--) {
              if (a.slice(a.length - len) === b.slice(0, len)) return len;
            }
            return 0;
          };
          const add = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => words[j].length - overlap(words[i], words[j])));
          const dp = Array.from({ length: full }, () => Array(n).fill(Infinity));
          const par = Array.from({ length: full }, () => Array(n).fill(-1));
          for (let i = 0; i < n; i++) dp[1 << i][i] = words[i].length;
          const steps = [];
          const cells = (curM) => grid(full, n, (m, i) => ({
            v: !(m & (1 << i)) || !Number.isFinite(dp[m][i]) ? "∞" : dp[m][i],
            state: m === curM ? "read" : m < curM ? "done" : "idle",
          }));
          steps.push({
            title: `Shortest superstring of ${words.join(", ")}`,
            kind: "grid", rows: full, cols: n,
            rowHeads: Array.from({ length: full }, (_, m) => `{${words.filter((_, i) => m & (1 << i)).join(",")}}`),
            colHeads: words,
            cells: cells(0),
            counters: [count("words", n), count("length", 0)],
            legend: LEG,
            happened: "Each singleton set starts with its own word length.",
            why: "The mask records the set of words already included, and the column records the last word.",
            codeLine: 6,
          });
          for (let m = 1; m < full; m++) {
            let changed = false;
            for (let i = 0; i < n; i++) {
              if (!(m & (1 << i)) || !Number.isFinite(dp[m][i])) continue;
              for (let j = 0; j < n; j++) {
                if (m & (1 << j)) continue;
                const nm = m | (1 << j);
                const cand = dp[m][i] + add[i][j];
                if (cand < dp[nm][j]) { dp[nm][j] = cand; par[nm][j] = i; changed = true; }
              }
            }
            if (m > 1 || changed) {
              steps.push({
                title: `Placed ${words.filter((_, i) => m & (1 << i)).join(", ")}`,
                kind: "grid", rows: full, cols: n,
                rowHeads: Array.from({ length: full }, (_, mm) => `{${words.filter((_, i) => mm & (1 << i)).join(",")}}`),
                colHeads: words,
                cells: cells(m),
                counters: [count("sets", m, full - 1), count("words", n)],
                legend: LEG,
                happened: "Every reachable endpoint was extended with each missing word.",
                why: "Only the last word's suffix can overlap the next word, so the endpoint is enough state.",
                codeLine: 11,
              });
            }
          }
          let best = 0;
          for (let i = 1; i < n; i++) if (dp[full - 1][i] < dp[full - 1][best]) best = i;
          let out = "";
          let m = full - 1, i = best;
          while (m) {
            const p = par[m][i];
            out = (p < 0 ? words[i] : words[i].slice(overlap(words[p], words[i]))) + out;
            m ^= (1 << i);
            i = p;
          }
          steps.push({
            title: `Answer: "${out}" (length ${out.length})`,
            kind: "grid", rows: full, cols: n,
            rowHeads: Array.from({ length: full }, (_, mm) => `{${words.filter((_, k) => mm & (1 << k)).join(",")}}`),
            colHeads: words,
            cells: grid(full, n, (mm, k) => ({ v: !(mm & (1 << k)) || !Number.isFinite(dp[mm][k]) ? "∞" : dp[mm][k], state: mm === full - 1 ? "result" : "done" })),
            counters: [count("length", out.length), count("words", n)],
            legend: LEG,
            happened: out,
            why: "Following the stored parents from the best final endpoint reconstructs the shortest ordering.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });
})();
