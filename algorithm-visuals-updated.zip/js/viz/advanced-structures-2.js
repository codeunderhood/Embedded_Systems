/* ============================================================
   DSA Visuals — Advanced Structures II
   Offline queries, range counting, dynamic connectivity and a
   persistent order-statistic tree. Every visual keeps the data
   small enough to follow by eye.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const num = (v) => (Number.isFinite(v) ? String(v) : "—");

  /* prefix sums, prefix[0] = 0 */
  function prefixOf(a) {
    const p = [0];
    for (const v of a) p.push(p[p.length - 1] + v);
    return p;
  }

  /* a row of scalar chips */
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: num(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "count-of-range-sum",
    title: "Count of Range Sum",
    category: "Advanced Structures",
    difficulty: "Advanced",
    description:
      "Count how many subarrays have a total between two bounds, first by brute force and then with prefix sums.",
    input: {
      label: "lower, upper, then the numbers",
      default: "-2, 2, -2, 5, -1, 0, 3",
      parse: "ints",
    },
    approaches: [
      {
        name: "Prefix Sums, Every Pair",
        complexity: "O(n²) time, O(n) space",
        idea: [
          "The total of a[i..j] is prefix[j+1] − prefix[i]. Instead of adding the same numbers again for every starting point, build one prefix row and subtract.",
          "For each right end j, look back at every earlier prefix i and test whether the difference lands inside [lower, upper].",
        ],
        problem: [
          "Looking back at every earlier prefix makes the work grow with the square of the input, which is too slow once the array is large.",
        ],
        code: {
          c: `#include <stdio.h>

/* Count subarrays whose sum is in [lower, upper]. */
int count_range_sum(const int *a, int n, int lower, int upper) {
    long prefix[64];
    prefix[0] = 0;
    for (int i = 0; i < n; i++)
        prefix[i + 1] = prefix[i] + a[i];

    int total = 0;
    for (int j = 0; j <= n; j++) {
        for (int i = 0; i < j; i++) {
            long sum = prefix[j] - prefix[i];
            if (sum >= lower && sum <= upper) total++;
        }
    }
    return total;
}

int main(void) {
    int a[] = {-2, 5, -1, 0, 3};
    printf("%d\\n", count_range_sum(a, 5, -2, 2)); /* 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

// prefix[j] - prefix[i] is the sum of a[i..j-1]
int countRangeSum(const vector<int>& a, int lower, int upper) {
    vector<long long> pre(a.size() + 1, 0);
    for (size_t i = 0; i < a.size(); i++)
        pre[i + 1] = pre[i] + a[i];

    int total = 0;
    for (size_t j = 0; j <= a.size(); j++)
        for (size_t i = 0; i < j; i++) {
            long long sum = pre[j] - pre[i];
            if (sum >= lower && sum <= upper) total++;
        }
    return total;
}

int main() {
    vector<int> a{-2, 5, -1, 0, 3};
    cout << countRangeSum(a, -2, 2) << '\\n'; // 5
}`,
        },
        steps(nums) {
          if (nums.length < 3) {
            return [{
              title: "Give a lower bound, an upper bound and some numbers",
              tracks: [chips("input", nums.length ? nums : ["—"], "idle")],
              counters: [count("numbers", nums.length)],
              legend: ["idle", "bad", "result"],
              happened: "The first two numbers are the bounds; at least one number is needed after them.",
              why: "Example: -2, 2, -2, 5, -1, 0, 3 means count subarray sums from -2 to 2.",
            }];
          }
          const lo = Math.min(nums[0], nums[1]);
          const hi = Math.max(nums[0], nums[1]);
          const a = nums.slice(2);
          const pre = prefixOf(a);
          const steps = [];
          let hits = 0;

          steps.push({
            title: `Bounds ${lo} to ${hi} over ${a.length} number${a.length === 1 ? "" : "s"}`,
            tracks: [
              track("numbers", a, fill(a.length, "idle")),
              chips("prefix sums", pre, "dim"),
            ],
            counters: [count("subarrays checked", 0), count("inside bounds", 0)],
            legend: LEG,
            happened: `The numbers are ${a.join(", ")}. The bounds are ${lo} and ${hi}.`,
            why: "A prefix row turns any subarray total into one subtraction, so the numbers never have to be re-added.",
            codeLine: 5,
          });

          for (let j = 1; j <= a.length; j++) {
            let rowHits = 0;
            for (let i = 0; i < j; i++) {
              const sum = pre[j] - pre[i];
              const inside = sum >= lo && sum <= hi;
              if (inside) hits++;
              rowHits++;
              steps.push({
                title: `a[${i}..${j - 1}] = ${sum}${inside ? " ✓" : " ✗"}`,
                tracks: [
                  track("numbers", a, a.map((_, k) => (k >= i && k < j ? "read" : k < i ? "done" : "idle"))),
                  chips("prefix sums", pre, (k) => (k === i ? "compare" : k === j ? "read" : "dim")),
                  chips("working", [sum], inside ? "good" : "bad"),
                ],
                counters: [
                  count("subarrays checked", hits === 0 ? rowHits : hits + (hits - rowHits), a.length * (a.length + 1) / 2),
                  count("inside bounds", hits),
                ],
                legend: LEG,
                happened: `prefix[${j}] − prefix[${i}] = ${pre[j]} − ${pre[i]} = ${sum}. ${inside ? "That is inside the bounds." : "That is outside the bounds."}`,
                why: inside
                  ? "This subarray counts, so the answer grows by one."
                  : "Rejected sums are not counted, but they still had to be looked at.",
                codeLine: 7,
              });
            }
          }
          steps.push({
            title: `Answer: ${hits} subarray${hits === 1 ? "" : "s"} in range`,
            tracks: [
              track("numbers", a, fill(a.length, "done")),
              chips("prefix sums", pre, "done"),
              chips("answer", [hits], "result"),
            ],
            counters: [count("subarrays checked", a.length * (a.length + 1) / 2), count("inside bounds", hits)],
            legend: LEG,
            happened: `Every starting point was paired with every ending point and ${hits} of those totals sat between ${lo} and ${hi}.`,
            why: "The prefix row made each test one subtraction; the merge-sort version does the same counting without the quadratic scan.",
            codeLine: 12,
          });
          return steps;
        },
      },
      {
        name: "Merge Sort Counting",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Sort the prefix row while counting. In a sorted window, the prefixes worth between pre[j] − upper and pre[j] − lower form one contiguous run, found with two moving pointers.",
          "Merging the two sorted halves afterwards keeps the next level sorted too, so each pair is counted once.",
        ],
        problem: [
          "The bounds have to be folded into the merge step, which makes the code noticeably harder to get right than the direct scan.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

static long buf[64];

/* merge-sort a[lo..hi) and count sums inside [lower, upper] */
long sort_count(long *a, int lo, int hi, long lower, long upper) {
    if (hi - lo < 2) return 0;
    int mid = (lo + hi) / 2;
    long total = sort_count(a, lo, mid, lower, upper)
               + sort_count(a, mid, hi, lower, upper);

    int i = lo, j = mid, k = lo;
    for (; i < mid; i++) {
        while (j < hi && a[j] - a[i] < lower) j++;
        while (k < hi && a[k] - a[i] <= upper) k++;
        total += k - j;
    }

    i = lo; j = mid; k = lo;
    while (i < mid && j < hi) buf[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    while (i < mid) buf[k++] = a[i++];
    while (j < hi) buf[k++] = a[j++];
    for (i = lo; i < hi; i++) a[i] = buf[i];
    return total;
}

int main(void) {
    long pre[] = {0, -2, 3, 2, 2, 5};
    printf("%ld\\n", sort_count(pre, 0, 6, -2, 2));
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

long long mergeCount(vector<long long>& a, int lo, int hi, long long lower, long long upper) {
    if (hi - lo < 2) return 0;
    int mid = (lo + hi) / 2;
    long long total = mergeCount(a, lo, mid, lower, upper)
                    + mergeCount(a, mid, hi, lower, upper);

    int j = mid, k = mid;
    for (int i = lo; i < mid; i++) {
        while (j < hi && a[j] - a[i] < lower) j++;
        while (k < hi && a[k] - a[i] <= upper) k++;
        total += k - j;
    }
    vector<long long> tmp;
    int i = lo;
    j = mid;
    while (i < mid && j < hi) tmp.push_back(a[i] <= a[j] ? a[i++] : a[j++]);
    while (i < mid) tmp.push_back(a[i++]);
    while (j < hi) tmp.push_back(a[j++]);
    for (int t = 0; t < (int)tmp.size(); t++) a[lo + t] = tmp[t];
    return total;
}

int main() {
    vector<long long> pre{0, -2, 3, 2, 2, 5};
    cout << mergeCount(pre, 0, pre.size(), -2, 2) << '\\n';
}`,
        },
        steps(nums) {
          if (nums.length < 3) {
            return [{
              title: "Not enough numbers to count",
              tracks: [chips("input", nums.length ? nums : ["—"], "idle")],
              counters: [count("numbers", nums.length)],
              legend: ["idle", "result"],
              happened: "The bounds and at least one value are required.",
              why: "The count compares prefix sums, so the prefix row needs both a start and an end.",
            }];
          }
          const lo = Math.min(nums[0], nums[1]);
          const hi = Math.max(nums[0], nums[1]);
          const a = nums.slice(2);
          const pre = prefixOf(a);
          const steps = [];
          const sorted = pre.slice().sort((x, y) => x - y);

          steps.push({
            title: "Same prefix row, viewed in sorted order",
            tracks: [
              track("prefix sums", pre, fill(pre.length, "idle")),
              chips("sorted prefixes", sorted, "dim"),
            ],
            counters: [count("prefixes", pre.length), count("pairs to count", 0)],
            legend: LEG,
            happened: `The prefix row is ${pre.join(", ")}. Sorting it puts every possible prefix value in order.`,
            why: "In a sorted window the prefixes inside a value range sit next to each other, so two pointers can measure the run.",
            codeLine: 4,
          });

          let total = 0;
          for (let j = 2; j < pre.length; j++) {
            const wantLo = pre[j] - hi;
            const wantHi = pre[j] - lo;
            const window = pre.slice(0, j).sort((x, y) => x - y);
            const inside = window.filter((v) => v >= wantLo && v <= wantHi);
            total += inside.length;
            steps.push({
              title: `Ending at prefix ${pre[j]}: ${inside.length} partner${inside.length === 1 ? "" : "s"}`,
              tracks: [
                track("prefix sums", pre, (() => {
                  const s = fill(pre.length, "dim");
                  for (let i = 0; i < j; i++) s[i] = "done";
                  s[j] = "read";
                  return s;
                })()),
                chips("partners in range", inside.length ? inside : ["none"], inside.length ? "good" : "bad"),
              ],
              counters: [count("prefixes", pre.length), count("pairs counted", total)],
              legend: LEG,
              happened: `Partners must fall from ${wantLo} to ${wantHi}; ${inside.length ? inside.join(", ") : "no earlier prefix did"}.`,
              why: "Two pointers find the same run in linear time, which is why the merge version avoids the quadratic scan.",
              codeLine: 12,
            });
          }
          steps.push({
            title: `Answer: ${total} subarray sums in range`,
            tracks: [
              track("prefix sums", pre, fill(pre.length, "done")),
              chips("answer", [total], "result"),
            ],
            counters: [count("prefixes", pre.length), count("pairs counted", total)],
            legend: LEG,
            happened: `All pairs of prefix sums were counted, giving ${total} totals between ${lo} and ${hi}.`,
            why: "Sorting once and walking with pointers turns the pair count from quadratic into n log n.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "longest-increasing-subsequence-with-constraints",
    title: "Longest Increasing Subsequence with Constraints",
    category: "Advanced Structures",
    difficulty: "Advanced",
    description:
      "Grow an increasing subsequence where consecutive chosen values must sit at most k positions apart.",
    input: {
      label: "gap k, then the numbers",
      default: "2, 1, 3, 2, 4, 3, 5",
      parse: "ints",
    },
    approaches: [
      {
        name: "Windowed Dynamic Programming",
        complexity: "O(n·k) time, O(n) space",
        idea: [
          "Keep dp[i] = the best length of an increasing subsequence that ends exactly at position i. To extend it, look only at the previous k positions and take the best one holding a smaller value.",
          "Limiting the look-back to k positions is what the constraint buys: the old O(n²) table becomes O(n·k).",
        ],
        problem: [
          "A small k can hide a much longer subsequence that reaches further back, so the constraint changes the answer — it is not just an optimisation.",
        ],
        code: {
          c: `#include <stdio.h>

/* longest increasing run where chosen indices stay within k of each other */
int lis_gap(const int *a, int n, int k) {
    int dp[64], best = 0;
    for (int i = 0; i < n; i++) {
        dp[i] = 1;
        for (int j = i - k; j < i; j++) {
            if (j >= 0 && a[j] < a[i] && dp[j] + 1 > dp[i])
                dp[i] = dp[j] + 1;
        }
        if (dp[i] > best) best = dp[i];
    }
    return best;
}

int main(void) {
    int a[] = {1, 3, 2, 4, 3, 5};
    printf("%d\\n", lis_gap(a, 6, 2)); /* 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int lisWithGap(const vector<int>& a, int k) {
    vector<int> dp(a.size(), 1);
    int best = 0;
    for (int i = 0; i < (int)a.size(); i++) {
        for (int j = i - k; j < i; j++)
            if (j >= 0 && a[j] < a[i])
                dp[i] = max(dp[i], dp[j] + 1);
        best = max(best, dp[i]);
    }
    return best;
}

int main() {
    vector<int> a{1, 3, 2, 4, 3, 5};
    cout << lisWithGap(a, 2) << '\\n'; // 5
}`,
        },
        steps(nums) {
          const k = Math.max(1, Math.abs(nums[0] || 1));
          const a = nums.slice(1);
          if (!a.length) {
            return [{
              title: "Give a gap and some numbers",
              tracks: [chips("input", nums.length ? nums : ["—"], "idle")],
              counters: [count("numbers", 0)],
              legend: ["idle", "result"],
              happened: "The first number is the allowed index gap; at least one value must follow.",
              why: "Example: 2, 1, 3, 2, 4, 3, 5 allows chosen indices to be at most 2 apart.",
            }];
          }
          const dp = a.map(() => 1);
          const steps = [];
          let best = 1;
          let bestAt = 0;

          steps.push({
            title: `Gap ${k}: every value can start a run of length 1`,
            tracks: [
              track("numbers", a, fill(a.length, "idle")),
              chips("best length to here", dp, "dim"),
            ],
            counters: [count("positions", 0, a.length), count("best length", 1)],
            legend: LEG,
            happened: `The row is ${a.join(", ")} and the longest run so far is 1.`,
            why: "Each position begins as its own run; later steps try to attach it to something smaller nearby.",
            codeLine: 4,
          });

          for (let i = 0; i < a.length; i++) {
            let from = -1;
            for (let j = Math.max(0, i - k); j < i; j++) {
              if (a[j] < a[i] && dp[j] + 1 > dp[i]) {
                dp[i] = dp[j] + 1;
                from = j;
              }
            }
            if (dp[i] > best) { best = dp[i]; bestAt = i; }
            steps.push({
              title: from < 0
                ? `${a[i]} starts a new run at length 1`
                : `${a[i]} extends ${a[from]} → length ${dp[i]}`,
              tracks: [
                track("numbers", a, a.map((v, j) => {
                  if (j === i) return "read";
                  if (from === j) return "compare";
                  if (j >= i - k && j < i) return "done";
                  return "dim";
                })),
                chips("best length to here", dp, (j) => (j === i ? "result" : j <= i ? "done" : "dim")),
                chips("chosen partner", [from < 0 ? "none" : a[from]], from < 0 ? "bad" : "good"),
              ],
              counters: [count("positions", i + 1, a.length), count("best length", best)],
              legend: LEG,
              happened: from < 0
                ? `No value in the last ${k} position${k === 1 ? "" : "s"} was smaller than ${a[i]}, so it restarts at 1.`
                : `The best partner is ${a[from]} at position ${from}, giving ${dp[from]} + 1 = ${dp[i]}.`,
              why: "Only positions inside the gap window are legal partners, which is exactly the constraint.",
              codeLine: 7,
            });
          }
          steps.push({
            title: `Answer: ${best}, ending at ${a[bestAt]}`,
            tracks: [
              track("numbers", a, a.map((v, j) => (j === bestAt ? "good" : dp[j] === best ? "result" : "dim"))),
              chips("best length to here", dp, (j) => (j === bestAt ? "good" : "dim")),
              chips("answer", [best], "result"),
            ],
            counters: [count("positions", a.length, a.length), count("best length", best)],
            legend: LEG,
            happened: `The longest run has ${best} value${best === 1 ? "" : "s"} and finishes at ${a[bestAt]}.`,
            why: "Every legal attachment was tried once, so the largest table entry is the answer.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "kth-smallest-value-in-a-range",
    title: "Kth Smallest Value in a Range",
    category: "Advanced Structures",
    difficulty: "Advanced",
    description:
      "Answer many questions of the form: what is the kth smallest value between positions l and r?",
    input: {
      label: "row 1 = array, row 2 = l,r,k triples",
      default: "3, 1, 4, 5, 2, 6, 1 | 0, 3, 2, 2, 5, 1",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Slice, Sort, Pick",
        complexity: "O(q·m log m) time, O(m) space",
        idea: [
          "For one query the slow but obvious method is honest: cut out positions l through r, sort that slice, then read the kth entry.",
          "It is a good baseline because every answer can be checked by hand, which makes it easy to test a faster structure against it.",
        ],
        problem: [
          "Sorting the same overlapping slices again and again repeats most of the work; a query-heavy workload would crawl.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

static int cmp(const void *x, const void *y) {
    int a = *(const int *)x, b = *(const int *)y;
    return (a > b) - (a < b);
}

/* naive: copy the slice, sort it, take index k-1 */
int kth_in_range(const int *a, int l, int r, int k) {
    int slice[64], m = 0;
    for (int i = l; i <= r; i++) slice[m++] = a[i];
    qsort(slice, m, sizeof(int), cmp);
    return slice[k - 1];
}

int main(void) {
    int a[] = {3, 1, 4, 5, 2, 6, 1};
    printf("%d\\n", kth_in_range(a, 0, 3, 2)); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int kthInRange(const vector<int>& a, int l, int r, int k) {
    vector<int> slice(a.begin() + l, a.begin() + r + 1);
    sort(slice.begin(), slice.end());
    return slice[k - 1];
}

int main() {
    vector<int> a{3, 1, 4, 5, 2, 6, 1};
    cout << kthInRange(a, 0, 3, 2) << '\\n'; // 3
}`,
        },
        steps(rows) {
          const a = rows[0] || [];
          const flat = rows[1] || [];
          const queries = [];
          for (let i = 0; i + 2 < flat.length; i += 3) queries.push([flat[i], flat[i + 1], flat[i + 2]]);
          if (!a.length || !queries.length) {
            return [{
              title: "Give an array and at least one l,r,k triple",
              tracks: [track("array", a.length ? a : ["—"], fill(Math.max(1, a.length), "idle"))],
              counters: [count("queries", queries.length)],
              legend: ["idle", "result"],
              happened: "The second row must hold triples: left, right, k.",
              why: "Example: 0, 3, 2 asks for the 2nd smallest value between positions 0 and 3.",
            }];
          }
          const steps = [];
          steps.push({
            title: `${a.length} values, ${queries.length} quer${queries.length === 1 ? "y" : "ies"}`,
            tracks: [
              track("array", a, fill(a.length, "idle")),
              chips("queries", queries.map((q) => `[${q[0]},${q[1]}] k=${q[2]}`), "dim"),
            ],
            counters: [count("queries answered", 0, queries.length)],
            legend: LEG,
            happened: `The array is ${a.join(", ")}; the first query asks for the ${queries[0][2]}${queries[0][2] === 1 ? "st" : queries[0][2] === 2 ? "nd" : queries[0][2] === 3 ? "rd" : "th"} smallest between ${queries[0][0]} and ${queries[0][1]}.`,
            why: "A naive answer sorts the slice, so overlapping queries repeat most of the same comparisons.",
            codeLine: 9,
          });
          queries.forEach((q, qi) => {
            const l = Math.max(0, Math.min(a.length - 1, q[0] | 0));
            const r = Math.max(l, Math.min(a.length - 1, q[1] | 0));
            const k = Math.max(1, Math.min(r - l + 1, q[2] | 0));
            const slice = a.slice(l, r + 1);
            const sorted = slice.slice().sort((x, y) => x - y);
            const ans = sorted[k - 1];
            steps.push({
              title: `Query ${qi + 1}: k=${k} of [${l}..${r}] is ${ans}`,
              tracks: [
                track("array", a, a.map((v, i) => (i >= l && i <= r ? "read" : "dim"))),
                track("slice", slice, fill(slice.length, "done")),
                track("sorted slice", sorted, sorted.map((v) => (v === ans ? "result" : "done"))),
                chips("answer", [ans], "result"),
              ],
              counters: [count("queries answered", qi + 1, queries.length), count("values in slice", slice.length)],
              legend: LEG,
              happened: `Positions ${l}..${r} hold ${slice.join(", ")}; sorted they become ${sorted.join(", ")}, and entry ${k} is ${ans}.`,
              why: "Sorting is correct but wasteful when the next query covers almost the same positions.",
              codeLine: 11,
            });
          });
          return steps;
        },
      },
      {
        name: "Merge-Sort Tree",
        complexity: "O(n log n) build, O(log² n) per query",
        idea: [
          "Every node of a segment tree stores the sorted list of values in its range. A query splits [l, r] into O(log n) nodes.",
          "To test a guess value, count how many stored values are ≤ it; binary search the answer instead of sorting the slice.",
        ],
        problem: [
          "Storing a sorted copy per node multiplies memory by log n, and each query pays another log factor for the binary searches.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

#define N 16
static int tree[4 * N][N], len[4 * N];

void build(int node, int lo, int hi, const int *a) {
    if (lo == hi) { tree[node][0] = a[lo]; len[node] = 1; return; }
    int mid = (lo + hi) / 2;
    build(2 * node, lo, mid, a);
    build(2 * node + 1, mid + 1, hi, a);

    int i = 0, j = 0, k = 0;
    int *L = tree[2 * node], *R = tree[2 * node + 1];
    while (i < len[2 * node] && j < len[2 * node + 1])
        tree[node][k++] = L[i] <= R[j] ? L[i++] : R[j++];
    while (i < len[2 * node]) tree[node][k++] = L[i++];
    while (j < len[2 * node + 1]) tree[node][k++] = R[j++];
    len[node] = k;
}

int count_le(int node, int lo, int hi, int l, int r, int x) {
    if (r < lo || hi < l) return 0;
    if (l <= lo && hi <= r) {
        int c = 0;
        while (c < len[node] && tree[node][c] <= x) c++;
        return c;
    }
    int mid = (lo + hi) / 2;
    return count_le(2 * node, lo, mid, l, r, x)
         + count_le(2 * node + 1, mid + 1, hi, l, r, x);
}

int main(void) {
    int a[] = {3, 1, 4, 5, 2, 6, 1};
    build(1, 0, 6, a);
    printf("%d\\n", count_le(1, 0, 6, 0, 3, 3)); /* 3 values <= 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct MergeSortTree {
    int n;
    vector<vector<int>> t;
    MergeSortTree(const vector<int>& a)
        : n(a.size()), t(4 * n) { build(1, 0, n - 1, a); }
    void build(int v, int lo, int hi, const vector<int>& a) {
        if (lo == hi) { t[v] = {a[lo]}; return; }
        int mid = (lo + hi) / 2;
        build(2 * v, lo, mid, a);
        build(2 * v + 1, mid + 1, hi, a);
        merge(t[2 * v].begin(), t[2 * v].end(),
              t[2 * v + 1].begin(), t[2 * v + 1].end(),
              back_inserter(t[v]));
    }
    int countLe(int v, int lo, int hi, int l, int r, int x) const {
        if (r < lo || hi < l) return 0;
        if (l <= lo && hi <= r)
            return upper_bound(t[v].begin(), t[v].end(), x) - t[v].begin();
        int mid = (lo + hi) / 2;
        return countLe(2 * v, lo, mid, l, r, x)
             + countLe(2 * v + 1, mid + 1, hi, l, r, x);
    }
};

int main() {
    vector<int> a{3, 1, 4, 5, 2, 6, 1};
    MergeSortTree tree(a);
    cout << tree.countLe(1, 0, 6, 0, 3, 3) << '\\n'; // 3
}`,
        },
        steps(rows) {
          const a = rows[0] || [];
          const flat = rows[1] || [];
          const queries = [];
          for (let i = 0; i + 2 < flat.length; i += 3) queries.push([flat[i], flat[i + 1], flat[i + 2]]);
          if (!a.length || !queries.length) {
            return [{
              title: "Give an array and at least one l,r,k triple",
              tracks: [track("array", a.length ? a : ["—"], fill(Math.max(1, a.length), "idle"))],
              counters: [count("queries", 0)],
              legend: ["idle", "result"],
              happened: "Nothing to answer without an array and a triple.",
              why: "The sorted blocks are built from the array, so both rows matter.",
            }];
          }
          const steps = [];
          const sortedAll = a.slice().sort((x, y) => x - y);
          steps.push({
            title: "Sorted blocks cover the array in halves",
            tracks: [
              track("array", a, fill(a.length, "idle")),
              track("all values, sorted", sortedAll, fill(sortedAll.length, "dim")),
            ],
            counters: [count("blocks", 1), count("queries answered", 0, queries.length)],
            legend: LEG,
            happened: `The array is ${a.join(", ")}. The root block holds every value in order.`,
            why: "A block can answer \"how many values are ≤ x?\" without ever sorting the query range.",
            codeLine: 10,
          });
          queries.forEach((q, qi) => {
            const l = Math.max(0, Math.min(a.length - 1, q[0] | 0));
            const r = Math.max(l, Math.min(a.length - 1, q[1] | 0));
            const k = Math.max(1, Math.min(r - l + 1, q[2] | 0));
            const slice = a.slice(l, r + 1).sort((x, y) => x - y);
            const ans = slice[k - 1];
            const guesses = [];
            for (const g of slice) guesses.push([g, slice.filter((v) => v <= g).length]);
            steps.push({
              title: `Query ${qi + 1}: guess values until the count reaches ${k}`,
              tracks: [
                track("array", a, a.map((v, i) => (i >= l && i <= r ? "read" : "dim"))),
                chips("guesses (value → count)", guesses.map(([g, c]) => `${g}:${c}`), (i) => (slice[i] === ans ? "result" : "dim")),
                chips("answer", [ans], "result"),
              ],
              counters: [count("queries answered", qi + 1, queries.length), count("guesses", guesses.length)],
              legend: LEG,
              happened: `Counting values ≤ each guess shows the ${k}th smallest between ${l} and ${r} is ${ans}.`,
              why: "The count only grows with the guess, so the first guess reaching k is the answer; binary search would find it faster.",
              codeLine: 20,
            });
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "dynamic-connectivity",
    title: "Dynamic Connectivity",
    category: "Advanced Structures",
    difficulty: "Advanced",
    description:
      "Add edges one at a time and answer whether two nodes are in the same component.",
    input: { label: "edges as a,b pairs", default: "0,1 1,2 3,4 2,4", parse: "pairs" },
    approaches: [
      {
        name: "Union-Find",
        complexity: "O(α(n)) per operation",
        idea: [
          "Each component has one root. `find` walks up parent pointers to that root; `union` hangs one root under the other.",
          "Two nodes are connected exactly when their roots match, so a query is just two find calls.",
        ],
        problem: [
          "Union-find only supports adding connections. Removing an edge needs a different structure, such as a fully dynamic tree or rebuilding.",
        ],
        code: {
          c: `#include <stdio.h>

static int parent[64];

int find(int x) {
    while (parent[x] != x) {
        parent[x] = parent[parent[x]];  /* path compression */
        x = parent[x];
    }
    return x;
}

int unite(int a, int b) {
    int ra = find(a), rb = find(b);
    if (ra == rb) return 0;             /* already joined */
    parent[rb] = ra;
    return 1;
}

int main(void) {
    for (int i = 0; i < 8; i++) parent[i] = i;
    printf("%d\\n", unite(0, 1));       /* 1, merged */
    printf("%d\\n", unite(1, 2));       /* 1 */
    printf("%d\\n", unite(0, 2));       /* 0, already same set */
    printf("%d\\n", find(0) == find(2));/* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <numeric>
using namespace std;

struct DSU {
    vector<int> p;
    explicit DSU(int n) : p(n) { iota(p.begin(), p.end(), 0); }
    int find(int x) { return p[x] == x ? x : p[x] = find(p[x]); }
    bool unite(int a, int b) {
        a = find(a);
        b = find(b);
        if (a == b) return false;
        p[b] = a;
        return true;
    }
};

int main() {
    DSU dsu(8);
    cout << dsu.unite(0, 1) << '\\n';  // 1
    cout << dsu.unite(1, 2) << '\\n';  // 1
    cout << dsu.unite(0, 2) << '\\n';  // 0
    cout << (dsu.find(0) == dsu.find(2)) << '\\n'; // 1
}`,
        },
        steps(pairs) {
          if (!pairs.length) {
            return [{
              title: "Give at least one edge",
              tracks: [track("edges", ["—"], ["idle"])],
              counters: [count("edges", 0)],
              legend: ["idle", "result"],
              happened: "With no edges every node is its own component.",
              why: "Edges are written as a,b pairs, for example 0,1 1,2 3,4.",
            }];
          }
          const ids = [...new Set(pairs.flat())].sort((x, y) => x - y);
          const parent = new Map(ids.map((v) => [v, v]));
          const find = (x) => {
            let r = x;
            while (parent.get(r) !== r) r = parent.get(r);
            while (parent.get(x) !== r) { const nx = parent.get(x); parent.set(x, r); x = nx; }
            return r;
          };
          const steps = [];
          const snapshot = (hot) => track("nodes", ids, ids.map((v) => (v === hot ? "read" : find(v) === find(ids[0]) ? "done" : "idle")));

          steps.push({
            title: `${ids.length} nodes, each its own component`,
            tracks: [snapshot(null), chips("parents", ids.map((v) => `${v}→${parent.get(v)}`), "dim")],
            counters: [count("edges added", 0, pairs.length), count("components", ids.length)],
            legend: LEG,
            happened: `Nodes ${ids.join(", ")} start disconnected; every parent points at itself.`,
            why: "Union-find begins with the finest possible partition and only ever merges.",
            codeLine: 3,
          });

          let comps = ids.length;
          pairs.forEach(([a, b], ei) => {
            const ra = find(a);
            const rb = find(b);
            const merged = ra !== rb;
            if (merged) { parent.set(rb, ra); comps--; }
            steps.push({
              title: merged ? `Edge ${a}–${b} merges two sets` : `Edge ${a}–${b} is already inside one set`,
              tracks: [
                snapshot(b),
                chips("roots", [a, ra, b, rb].map((v) => num(v)), (i) => (i === 1 || i === 3 ? "result" : "compare")),
                chips("parents", ids.map((v) => `${v}→${find(v)}`), "dim"),
              ],
              counters: [count("edges added", ei + 1, pairs.length), count("components", comps)],
              legend: LEG,
              happened: merged
                ? `find(${a}) = ${ra} and find(${b}) = ${rb}, so ${rb}'s tree now hangs under ${ra}.`
                : `Both ${a} and ${b} already report root ${ra}, so nothing changes.`,
              why: "Comparing roots is the whole connectivity test; merging roots keeps the forest shallow.",
              codeLine: merged ? 11 : 9,
            });
          });

          const allConnected = comps === 1;
          steps.push({
            title: `Answer: ${comps} component${comps === 1 ? "" : "s"}${allConnected ? " — fully connected" : ""}`,
            tracks: [
              snapshot(null),
              chips("answer", [comps], "result"),
            ],
            counters: [count("edges added", pairs.length, pairs.length), count("components", comps)],
            legend: LEG,
            happened: allConnected
              ? "Every node now shares the same root, so any pair is connected."
              : `The nodes split into ${comps} groups; nodes in different groups cannot reach each other.`,
            why: "Two nodes are connected exactly when find returns the same root for both.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "offline-range-queries",
    title: "Offline Range Queries",
    category: "Advanced Structures",
    difficulty: "Advanced",
    description:
      "Answer many sum queries without a segment tree by sorting them and sweeping once.",
    input: {
      label: "row 1 = array, row 2 = l,r pairs",
      default: "2, 4, 1, 7, 3, 5 | 0,2 1,4 2,5",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Sort Queries, Sweep Right",
        complexity: "O((n + q) log n)",
        idea: [
          "When all queries are known in advance they can be reordered. Sort them by their right end and sweep the array once, adding each value to a Fenwick tree.",
          "At the moment the sweep reaches r, the tree holds exactly positions 0..r, so the answer is prefix(r) − prefix(l − 1).",
        ],
        problem: [
          "Answers come out of the original order; you must store them by query id and put them back. The method also needs every query up front.",
        ],
        code: {
          c: `#include <stdio.h>

static int bit[64];

void add(int n, int i, int v) {
    for (i++; i <= n; i += i & -i) bit[i] += v;
}
int pref(int i) {
    int s = 0;
    for (; i > 0; i -= i & -i) s += bit[i];
    return s;
}

/* queries sorted by right end: ql[], qr[] */
void answer_all(const int *a, int n, const int *ql, const int *qr, int q, int *out) {
    int upto = -1;
    for (int k = 0; k < q; k++) {
        while (upto < qr[k]) add(n, ++upto, a[upto]);
        out[k] = pref(qr[k] + 1) - pref(ql[k]);
    }
}

int main(void) {
    int a[] = {2, 4, 1, 7, 3, 5};
    int ql[] = {0, 1, 2}, qr[] = {2, 4, 5}, out[3];
    answer_all(a, 6, ql, qr, 3, out);
    printf("%d %d %d\\n", out[0], out[1], out[2]); /* 7 12 15 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Query { int l, r, id; };

int main() {
    vector<int> a{2, 4, 1, 7, 3, 5};
    vector<Query> qs{{0, 2, 0}, {1, 4, 1}, {2, 5, 2}};
    sort(qs.begin(), qs.end(), [](auto& x, auto& y) { return x.r < y.r; });

    int n = a.size();
    vector<int> bit(n + 1, 0), out(qs.size());
    auto add = [&](int i, int v) {
        for (i++; i <= n; i += i & -i) bit[i] += v;
    };
    auto pref = [&](int i) {
        int s = 0;
        for (; i > 0; i -= i & -i) s += bit[i];
        return s;
    };
    int upto = -1;
    for (auto& q : qs) {
        while (upto < q.r) add(++upto, a[upto]);
        out[q.id] = pref(q.r + 1) - pref(q.l);
    }
    for (int v : out) cout << v << ' '; // 7 12 15
    cout << '\\n';
}`,
        },
        steps(rows) {
          const a = rows[0] || [];
          const flat = rows[1] || [];
          const qs = [];
          for (let i = 0; i + 1 < flat.length; i += 2) qs.push({ l: flat[i], r: flat[i + 1], id: qs.length });
          if (!a.length || !qs.length) {
            return [{
              title: "Give an array and at least one l,r pair",
              tracks: [track("array", a.length ? a : ["—"], fill(Math.max(1, a.length), "idle"))],
              counters: [count("queries", 0)],
              legend: ["idle", "result"],
              happened: "The second row must hold pairs such as 0,2 1,4.",
              why: "Offline methods need the whole query list before the sweep starts.",
            }];
          }
          const sorted = qs.slice().sort((x, y) => x.r - y.r || x.l - y.l);
          const steps = [];
          steps.push({
            title: `${qs.length} queries, reordered by right end`,
            tracks: [
              track("array", a, fill(a.length, "idle")),
              chips("queries in order", qs.map((q) => `[${q.l},${q.r}]`), "dim"),
              chips("sorted by r", sorted.map((q) => `[${q.l},${q.r}]`), "read"),
            ],
            counters: [count("queries", qs.length)],
            legend: LEG,
            happened: `The queries are ${qs.map((q) => `[${q.l},${q.r}]`).join(", ")}; sorting by the right end gives ${sorted.map((q) => `[${q.l},${q.r}]`).join(", ")}.`,
            why: "Reordering lets one left-to-right sweep serve every query instead of restarting for each one.",
            codeLine: 12,
          });
          let upto = -1;
          const answers = new Map();
          sorted.forEach((q, qi) => {
            const r = Math.max(0, Math.min(a.length - 1, q.r | 0));
            const l = Math.max(0, Math.min(r, q.l | 0));
            while (upto < r) upto++;
            const sum = a.slice(l, r + 1).reduce((s, v) => s + v, 0);
            answers.set(q.id, sum);
            steps.push({
              title: `Sweep reaches ${r}: [${l},${r}] sums to ${sum}`,
              tracks: [
                track("array", a, a.map((v, i) => (i < l ? "dim" : i >= l && i <= r ? "read" : i <= upto ? "done" : "idle"))),
                chips("queries", sorted.map((x) => `[${x.l},${x.r}]`), (i) => (i === qi ? "active" : "dim")),
                chips("answers", sorted.filter((x) => answers.has(x.id)).map((x) => `[${x.l},${x.r}]=${answers.get(x.id)}`), "result"),
              ],
              counters: [count("sweep index", upto + 1, a.length), count("queries answered", answers.size, qs.length)],
              legend: LEG,
              happened: `Once position ${r} has been added, the tree holds positions 0..${r}, so the window ${l}..${r} can be read as one difference of prefixes.`,
              why: "A Fenwick prefix is the running total; subtracting the prefix before l removes everything outside the window.",
              codeLine: 16,
            });
          });
          steps.push({
            title: `Answers in the original order: ${qs.map((q) => answers.get(q.id)).join(", ")}`,
            tracks: [
              track("array", a, fill(a.length, "done")),
              chips("answers", qs.map((q) => `${answers.get(q.id)}`), "result"),
            ],
            counters: [count("sweep index", a.length, a.length), count("queries answered", qs.length, qs.length)],
            legend: LEG,
            happened: `Sorted processing produced ${qs.map((q) => `[${q.l},${q.r}]→${answers.get(q.id)}`).join(", ")}.`,
            why: "Storing by id makes the reordered answers line up with the questions the caller asked.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "distinct-values-in-a-range",
    title: "Distinct Values in a Range",
    category: "Advanced Structures",
    difficulty: "Advanced",
    description:
      "Count distinct values between l and r by sweeping right and remembering only the latest copy of each value.",
    input: {
      label: "row 1 = array, row 2 = l,r pairs",
      default: "1, 2, 1, 3, 2, 4 | 0,3 1,5 2,2",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Latest Copy Only",
        complexity: "O((n + q) log n)",
        idea: [
          "Sort queries by right end and sweep. When a value appears again, remove its earlier mark and place the mark at the new position.",
          "At right end r the Fenwick tree holds exactly one mark per distinct value seen so far, so a range count answers the question directly.",
        ],
        problem: [
          "Only the newest position of a value is kept, so the structure cannot answer questions that need the old positions too.",
        ],
        code: {
          c: `#include <stdio.h>

static int bit[64], last[128];

void add(int n, int i, int v) {
    for (i++; i <= n; i += i & -i) bit[i] += v;
}
int pref(int i) {
    int s = 0;
    for (; i > 0; i -= i & -i) s += bit[i];
    return s;
}

/* qs sorted by right end; values assumed in 0..127 */
void distinct_counts(const int *a, int n, const int *ql, const int *qr, int q, int *out) {
    for (int v = 0; v < 128; v++) last[v] = -1;
    int upto = -1;
    for (int k = 0; k < q; k++) {
        while (upto < qr[k]) {
            upto++;
            if (last[a[upto]] >= 0) add(n, last[a[upto]], -1);
            last[a[upto]] = upto;
            add(n, upto, 1);
        }
        out[k] = pref(qr[k] + 1) - pref(ql[k]);
    }
}

int main(void) {
    int a[] = {1, 2, 1, 3, 2, 4}, ql[] = {0, 1, 2}, qr[] = {3, 5, 2}, out[3];
    distinct_counts(a, 6, ql, qr, 3, out);
    printf("%d %d %d\\n", out[0], out[1], out[2]); /* 3 4 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;

struct Query { int l, r, id; };

int main() {
    vector<int> a{1, 2, 1, 3, 2, 4};
    vector<Query> qs{{0, 3, 0}, {1, 5, 1}, {2, 2, 2}};
    sort(qs.begin(), qs.end(), [](auto& x, auto& y) { return x.r < y.r; });

    int n = a.size();
    vector<int> bit(n + 1, 0), out(qs.size());
    map<int, int> last;
    auto add = [&](int i, int v) {
        for (i++; i <= n; i += i & -i) bit[i] += v;
    };
    auto pref = [&](int i) {
        int s = 0;
        for (; i > 0; i -= i & -i) s += bit[i];
        return s;
    };
    int upto = -1;
    for (auto& q : qs) {
        while (upto < q.r) {
            upto++;
            auto it = last.find(a[upto]);
            if (it != last.end()) add(it->second, -1);
            last[a[upto]] = upto;
            add(upto, 1);
        }
        out[q.id] = pref(q.r + 1) - pref(q.l);
    }
    for (int v : out) cout << v << ' '; // 3 4 1
    cout << '\\n';
}`,
        },
        steps(rows) {
          const a = rows[0] || [];
          const flat = rows[1] || [];
          const qs = [];
          for (let i = 0; i + 1 < flat.length; i += 2) qs.push({ l: flat[i], r: flat[i + 1], id: qs.length });
          if (!a.length || !qs.length) {
            return [{
              title: "Give an array and at least one l,r pair",
              tracks: [track("array", a.length ? a : ["—"], fill(Math.max(1, a.length), "idle"))],
              counters: [count("queries", 0)],
              legend: ["idle", "result"],
              happened: "The second row must hold pairs such as 0,3 1,5.",
              why: "Each query needs a left and right position.",
            }];
          }
          const sorted = qs.slice().sort((x, y) => x.r - y.r || x.l - y.l);
          const steps = [];
          const marks = fill(a.length, "idle");
          steps.push({
            title: "One mark per distinct value",
            tracks: [
              track("array", a, fill(a.length, "idle")),
              chips("queries sorted by r", sorted.map((q) => `[${q.l},${q.r}]`), "read"),
            ],
            counters: [count("marks placed", 0), count("queries answered", 0, qs.length)],
            legend: LEG,
            happened: `The array is ${a.join(", ")}; every value will keep only its newest mark.`,
            why: "If an older copy is removed when a newer one appears, a suffix count equals the distinct count.",
            codeLine: 13,
          });
          const last = new Map();
          let upto = -1;
          const answers = new Map();
          sorted.forEach((q, qi) => {
            const r = Math.max(0, Math.min(a.length - 1, q.r | 0));
            const l = Math.max(0, Math.min(r, q.l | 0));
            while (upto < r) {
              upto++;
              const prev = last.get(a[upto]);
              if (prev != null) marks[prev] = "dim";
              last.set(a[upto], upto);
              marks[upto] = "done";
            }
            const countDistinct = new Set(a.slice(l, r + 1)).size;
            answers.set(q.id, countDistinct);
            steps.push({
              title: `[${l},${r}]: ${countDistinct} distinct value${countDistinct === 1 ? "" : "s"}`,
              tracks: [
                track("array", a, a.map((v, i) => {
                  if (i > r) return "idle";
                  if (i >= l && i <= r) return last.get(v) === i ? "result" : "read";
                  return "dim";
                })),
                chips("newest positions", [...last.entries()].sort((x, y) => x[1] - y[1]).map(([v, i]) => `${v}@${i}`), "dim"),
                chips("answer", [countDistinct], "result"),
              ],
              counters: [count("sweep index", upto + 1, a.length), count("queries answered", answers.size, qs.length)],
              legend: LEG,
              happened: `Inside ${l}..${r} a value counts once, so ${countDistinct} marks fall in the window.`,
              why: "Duplicates contribute nothing extra because only the newest copy stays marked.",
              codeLine: 18,
            });
          });
          steps.push({
            title: `Answers: ${qs.map((q) => answers.get(q.id)).join(", ")}`,
            tracks: [track("array", a, fill(a.length, "done")), chips("answers", qs.map((q) => `${answers.get(q.id)}`), "result")],
            counters: [count("sweep index", a.length, a.length), count("queries answered", qs.length, qs.length)],
            legend: LEG,
            happened: `Every query was answered during a single sweep, giving ${qs.map((q) => `[${q.l},${q.r}]→${answers.get(q.id)}`).join(", ")}.`,
            why: "Moving a mark instead of adding another is what keeps duplicates from being counted twice.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "persistent-kth-order-statistic",
    title: "Persistent Kth Order Statistic",
    category: "Advanced Structures",
    difficulty: "Advanced",
    description:
      "Keep every historical version of a counting tree so the kth smallest value in a past range can be found.",
    input: {
      label: "l, r, k, then the numbers",
      default: "1, 5, 2, 5, 2, 7, 3, 6, 1",
      parse: "ints",
    },
    approaches: [
      {
        name: "Versioned Counts",
        complexity: "O(n log n) build, O(log n) per query",
        idea: [
          "Sort the distinct values and give each a rank. Version i of the tree counts how many values in a[0..i-1] fall in each rank range.",
          "A new version only copies the path it touches; the untouched branches are shared with the previous version. A range count is version(r) − version(l−1).",
        ],
        problem: [
          "Sharing nodes saves memory but every version still needs a new root and a copied path, and the rank mapping must be prepared first.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

#define MAXN 64

typedef struct Node { int left, right, sum; } Node;
static Node pool[MAXN * 16];
static int used = 0, roots[MAXN], rankOf[MAXN], vals[MAXN];

int update(int prev, int lo, int hi, int pos) {
    int cur = used++;
    pool[cur] = pool[prev];
    pool[cur].sum++;
    if (lo == hi) return cur;
    int mid = (lo + hi) / 2;
    if (pos <= mid) pool[cur].left  = update(pool[prev].left,  lo, mid, pos);
    else            pool[cur].right = update(pool[prev].right, mid + 1, hi, pos);
    return cur;
}

int kth(int a, int b, int lo, int hi, int k) {
    if (lo == hi) return lo;
    int mid = (lo + hi) / 2;
    int leftCount = pool[pool[b].left].sum - pool[pool[a].left].sum;
    if (k <= leftCount) return kth(pool[a].left, pool[b].left, lo, mid, k);
    return kth(pool[a].right, pool[b].right, mid + 1, hi, k - leftCount);
}

int main(void) {
    int a[] = {5, 2, 7, 3, 6, 1}, n = 6;
    /* ranks would be prepared by sorting here */
    roots[0] = 0; pool[0] = (Node){0, 0, 0};
    used = 1;
    for (int i = 0; i < n; i++) roots[i + 1] = update(roots[i], 0, n - 1, rankOf[i]);
    printf("%d\\n", vals[kth(roots[1], roots[6], 0, n - 1, 2)]);
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Node { int l = 0, r = 0, sum = 0; };
vector<Node> pool(1);
vector<int> roots(1, 0);

int update(int prev, int lo, int hi, int pos) {
    int cur = pool.size();
    pool.push_back(pool[prev]);
    pool[cur].sum++;
    if (lo == hi) return cur;
    int mid = (lo + hi) / 2;
    if (pos <= mid) pool[cur].l = update(pool[prev].l, lo, mid, pos);
    else pool[cur].r = update(pool[prev].r, mid + 1, hi, pos);
    return cur;
}

int kth(int a, int b, int lo, int hi, int k) {
    if (lo == hi) return lo;
    int mid = (lo + hi) / 2;
    int left = pool[pool[b].l].sum - pool[pool[a].l].sum;
    if (k <= left) return kth(pool[a].l, pool[b].l, lo, mid, k);
    return kth(pool[a].r, pool[b].r, mid + 1, hi, k - left);
}

int main() {
    vector<int> a{5, 2, 7, 3, 6, 1};
    vector<int> sorted = a;
    sort(sorted.begin(), sorted.end());
    for (int v : a) {
        int rank = lower_bound(sorted.begin(), sorted.end(), v) - sorted.begin();
        roots.push_back(update(roots.back(), 0, a.size() - 1, rank));
    }
    int rank = kth(roots[1], roots[6], 0, a.size() - 1, 2);
    cout << sorted[rank] << '\\n'; // 2
}`,
        },
        steps(nums) {
          if (nums.length < 4) {
            return [{
              title: "Give l, r, k and some numbers",
              tracks: [chips("input", nums.length ? nums : ["—"], "idle")],
              counters: [count("numbers", 0)],
              legend: ["idle", "result"],
              happened: "The first three numbers are the left, right and k; values follow.",
              why: "Example: 1, 5, 2, 5, 2, 7, 3, 6, 1 asks for the 2nd smallest in positions 1..5.",
            }];
          }
          const l = nums[0], r = nums[1], k = Math.max(1, nums[2] | 0);
          const a = nums.slice(3);
          const sorted = a.slice().sort((x, y) => x - y);
          const steps = [];
          const clampL = Math.max(0, Math.min(a.length - 1, l | 0));
          const clampR = Math.max(clampL, Math.min(a.length - 1, r | 0));
          const kk = Math.max(1, Math.min(clampR - clampL + 1, k));
          const ans = a.slice(clampL, clampR + 1).slice().sort((x, y) => x - y)[kk - 1];

          steps.push({
            title: `Values ranked: ${sorted.join(" ≤ ")}`,
            tracks: [
              track("numbers", a, fill(a.length, "idle")),
              track("sorted ranks", sorted, fill(sorted.length, "dim")),
            ],
            counters: [count("versions", 0, a.length + 1), count("query", `[${clampL},${clampR}] k=${kk}`)],
            legend: LEG,
            happened: `The distinct rank order is ${[...new Set(sorted)].join(", ")}. Version 0 counts nothing.`,
            why: "Compressing values to ranks keeps the counting tree shallow even for large numbers.",
            codeLine: 4,
          });

          for (let i = 0; i < a.length; i++) {
            const rank = sorted.indexOf(a[i]);
            const counts = sorted.slice(0, rank + 1).map((v) => a.slice(0, i + 1).filter((x) => x <= v).length);
            steps.push({
              title: `Version ${i + 1} adds ${a[i]} at rank ${rank}`,
              tracks: [
                track("numbers", a, a.map((v, j) => (j < i ? "done" : j === i ? "read" : "idle"))),
                chips("counts by rank", counts, (j) => (j === rank ? "result" : "dim")),
              ],
              counters: [count("versions", i + 1, a.length + 1), count("values stored", i + 1, a.length)],
              legend: LEG,
              happened: `Only the path from the root to rank ${rank} is copied; every other node is shared with version ${i}.`,
              why: "Persistent versions let a range be the difference of two roots without undoing updates.",
              codeLine: 9,
            });
          }

          steps.push({
            title: `Version ${clampR + 1} minus version ${clampL} leaves the range`,
            tracks: [
              track("numbers", a, a.map((v, i) => (i >= clampL && i <= clampR ? "read" : "dim"))),
              chips("range values", a.slice(clampL, clampR + 1), "done"),
            ],
            counters: [count("versions", a.length + 1, a.length + 1), count("range size", clampR - clampL + 1)],
            legend: LEG,
            happened: `Subtracting the counts of version ${clampL} from version ${clampR + 1} counts only positions ${clampL}..${clampR}.`,
            why: "Both versions share structure, so the subtraction is a walk down two roots in parallel.",
            codeLine: 16,
          });

          steps.push({
            title: `Answer: ${kk}${kk === 1 ? "st" : kk === 2 ? "nd" : kk === 3 ? "rd" : "th"} smallest is ${ans}`,
            tracks: [
              track("numbers", a, a.map((v, i) => (i >= clampL && i <= clampR ? (v === ans ? "good" : "done") : "dim"))),
              chips("range, sorted", a.slice(clampL, clampR + 1).slice().sort((x, y) => x - y), (i) => (i === kk - 1 ? "result" : "dim")),
              chips("answer", [ans], "result"),
            ],
            counters: [count("versions", a.length + 1, a.length + 1), count("answer", ans)],
            legend: LEG,
            happened: `Descending by the left-child counts lands on rank of ${ans}, so the answer is ${ans}.`,
            why: "One root difference plus one descent answers any range selection in logarithmic time.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

})();
