/* ============================================================
   DSA Visuals — Strings & Text III
   Matching with the prefix function, repeated patterns and
   duplicated pieces. The prefix table is the star of this set.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const chars = (text) => Array.from(String(text || ""));
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const isWindow = (i, lo, hi) => i >= lo && i < hi;

  function prefixFunction(text) {
    const s = chars(text);
    const pi = Array(s.length).fill(0);
    for (let i = 1; i < s.length; i++) {
      let k = pi[i - 1];
      while (k > 0 && s[i] !== s[k]) k = pi[k - 1];
      if (s[i] === s[k]) k++;
      pi[i] = k;
    }
    return pi;
  }

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-the-index-of-first-occurrence",
    title: "Find the Index of First Occurrence",
    category: "Strings & Text",
    difficulty: "Intermediate",
    description:
      "Locate the first place a needle appears in a haystack using the KMP prefix table.",
    input: { label: "haystack | needle", default: "sadbutsad | sad", parse: "string" },
    approaches: [
      {
        name: "KMP Prefix Table",
        complexity: "O(n + m) time, O(m) space",
        idea: [
          "Build the prefix table of the needle: for each position it stores the longest proper prefix that is also a suffix there.",
          "On a mismatch the table says how much of the needle is already matched, so the haystack pointer never moves backwards.",
        ],
        problem: [
          "The table is extra memory and extra code; for very short needles a direct comparison is simpler.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

void build_pi(const char *p, int *pi) {
    int m = strlen(p);
    pi[0] = 0;
    for (int i = 1; i < m; i++) {
        int k = pi[i - 1];
        while (k > 0 && p[i] != p[k]) k = pi[k - 1];
        if (p[i] == p[k]) k++;
        pi[i] = k;
    }
}

int str_str(const char *s, const char *p) {
    int n = strlen(s), m = strlen(p);
    if (m == 0) return 0;
    int pi[256];
    build_pi(p, pi);

    int k = 0;
    for (int i = 0; i < n; i++) {
        while (k > 0 && s[i] != p[k]) k = pi[k - 1];
        if (s[i] == p[k]) k++;
        if (k == m) return i - m + 1;
    }
    return -1;
}

int main(void) {
    printf("%d\\n", str_str("sadbutsad", "sad")); /* 0 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
using namespace std;

vector<int> prefixTable(const string& p) {
    vector<int> pi(p.size(), 0);
    for (int i = 1; i < (int)p.size(); i++) {
        int k = pi[i - 1];
        while (k > 0 && p[i] != p[k]) k = pi[k - 1];
        if (p[i] == p[k]) k++;
        pi[i] = k;
    }
    return pi;
}

int strStr(const string& s, const string& p) {
    if (p.empty()) return 0;
    vector<int> pi = prefixTable(p);
    int k = 0;
    for (int i = 0; i < (int)s.size(); i++) {
        while (k > 0 && s[i] != p[k]) k = pi[k - 1];
        if (s[i] == p[k]) k++;
        if (k == (int)p.size()) return i - k + 1;
    }
    return -1;
}

int main() {
    cout << strStr("sadbutsad", "sad") << '\\n'; // 0
}`,
        },
        steps(text) {
          const [hay, needleRaw] = parts(text);
          const H = chars(hay);
          const N = chars(needleRaw);
          const steps = [];
          if (!N.length) {
            return [{
              title: "An empty needle matches at index 0",
              tracks: [track("haystack", H.length ? H : ["—"], fill(Math.max(1, H.length), "idle"))],
              counters: [count("index", 0)],
              legend: LEG,
              happened: "Nothing to search for, so the answer is the empty prefix.",
              why: "The empty text occurs before every position.",
            }];
          }
          const pi = prefixFunction(needleRaw);
          steps.push({
            title: `Needle "${N.join("")}" has prefix table [${pi.join(", ")}]`,
            tracks: [track("needle", N, fill(N.length, "idle")), chips("prefix table", pi, "dim")],
            counters: [count("needle length", N.length), count("haystack length", H.length)],
            legend: LEG,
            happened: "pi[i] is the longest proper prefix of needle[0..i] that is also its suffix.",
            why: "That overlap tells us how far to fall back after a mismatch.",
            codeLine: 3,
          });
          let k = 0, found = -1;
          for (let i = 0; i < H.length; i++) {
            const before = k;
            while (k > 0 && H[i] !== N[k]) k = pi[k - 1];
            if (H[i] === N[k]) k++;
            const fell = k < before;
            if (k === N.length) found = i - N.length + 1;
            steps.push({
              title: found >= 0 ? `Full match ending at ${i} → start ${found}` : `Haystack ${i} ('${H[i]}') matches needle ${k} character${k === 1 ? "" : "s"}`,
              tracks: [
                track("haystack", H, H.map((_, j) => (j === i ? "read" : j >= i - k + 1 && j <= i ? "done" : "idle"))),
                track("needle", N, N.map((_, j) => (j < k ? "done" : j === k ? "compare" : "dim"))),
                chips("prefix table", pi, (j) => (fell && j === k - 1 ? "active" : "dim")),
              ],
              counters: [count("matched", k, N.length), count("falls back", fell ? 1 : 0)],
              legend: LEG,
              happened: found >= 0
                ? `The needle is complete, so it starts at ${found}.`
                : fell
                  ? `Mismatch; the prefix table drops the match to ${k} without rewinding the haystack.`
                  : `The character agrees, so the matched prefix grows to ${k}.`,
              why: "The haystack index only moves forward, which is why the scan is linear.",
              codeLine: found >= 0 ? 21 : 19,
            });
            if (found >= 0) break;
          }
          steps.push({
            title: found >= 0 ? `Answer: index ${found}` : "Answer: not found",
            tracks: [
              track("haystack", H, H.map((_, j) => (found >= 0 && isWindow(j, found, found + N.length) ? "result" : "dim"))),
              chips("answer", [found], "result"),
            ],
            counters: [count("matched", found >= 0 ? N.length : k, N.length), count("answer", found)],
            legend: LEG,
            happened: found >= 0 ? `"${N.join("")}" first appears at ${found}.` : `The scan ended without completing the needle.`,
            why: "Every haystack character was examined at most once.",
            codeLine: 23,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "repeated-string-match",
    title: "Repeated String Match",
    category: "Strings & Text",
    difficulty: "Intermediate",
    description:
      "Find the smallest number of copies of A whose concatenation contains B.",
    input: { label: "text A | text B", default: "abcd | cdabcdab", parse: "string" },
    approaches: [
      {
        name: "Grow Until Long Enough",
        complexity: "O(|B| / |A| × |A|) time",
        idea: [
          "Repeat A until the repeated text is at least as long as B, checking containment after each copy.",
          "If B is present, that count is minimal; one extra copy is occasionally needed when B straddles a boundary, so check once more before giving up.",
        ],
        problem: [
          "Repeated concatenation copies memory each round; a smarter solution searches a bounded number of repetitions instead.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

int repeated_match(const char *a, const char *b) {
    int la = strlen(a), lb = strlen(b);
    char buf[1024] = {0};
    int copies = (lb + la - 1) / la;

    for (int i = 0; i < copies + 1; i++) {
        if (i == 0) strcpy(buf, a);
        else strncat(buf, a, sizeof(buf) - strlen(buf) - 1);
        if (i + 1 >= copies && strstr(buf, b)) return i + 1;
    }
    return -1;
}

int main(void) {
    printf("%d\\n", repeated_match("abcd", "cdabcdab")); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
using namespace std;

int repeatedStringMatch(const string& a, const string& b) {
    int copies = (b.size() + a.size() - 1) / a.size();
    string text;
    for (int i = 1; i <= copies; i++) {
        text += a;
        if (text.find(b) != string::npos) return i;
    }
    text += a;                          // one extra copy for boundary cases
    return text.find(b) != string::npos ? copies + 1 : -1;
}

int main() {
    cout << repeatedStringMatch("abcd", "cdabcdab") << '\\n'; // 3
}`,
        },
        steps(text) {
          const [aRaw, bRaw] = parts(text);
          const A = chars(aRaw);
          const B = chars(bRaw);
          const steps = [];
          if (!A.length || !B.length) {
            return [{
              title: "Two texts are needed",
              tracks: [chips("A", A.length ? A : ["—"], "idle"), chips("B", B.length ? B : ["—"], "idle")],
              counters: [count("copies", 0)],
              legend: ["idle", "result"],
              happened: "Repeating an empty text never produces anything.",
              why: "The answer is the number of copies of A that cover B.",
            }];
          }
          const minimal = Math.ceil(B.length / A.length);
          let built = "";
          steps.push({
            title: `B needs at least ${minimal} cop${minimal === 1 ? "y" : "ies"} of A`,
            tracks: [chips("A", A, "idle"), chips("B", B, "idle"), chips("built", ["—"], "dim")],
            counters: [count("copies", 0), count("minimum", minimal)],
            legend: LEG,
            happened: `A is ${A.length} characters and B is ${B.length}.`,
            why: "Fewer copies than the length ratio cannot possibly contain B.",
            codeLine: 4,
          });
          let answer = -1;
          for (let copies = 1; copies <= minimal + 1; copies++) {
            built += aRaw;
            const at = built.indexOf(bRaw);
            if (at >= 0 && answer < 0) answer = copies;
            steps.push({
              title: `${copies} cop${copies === 1 ? "y" : "ies"}: "${built.length <= 24 ? built : built.slice(0, 24) + "…"}" ${at >= 0 ? "contains B" : "does not contain B"}`,
              tracks: [
                chips("A", A, "dim"),
                chips("B", B, at >= 0 ? "good" : "idle"),
                chips("built", chars(built).slice(0, 32), (i) => (chars(built).slice(0, 32)[i] === B[i] && at >= 0 && isWindow(i, at, at + B.length) ? "result" : "done")),
              ],
              counters: [count("copies", copies), count("built length", built.length)],
              legend: LEG,
              happened: at >= 0 ? `B appears at index ${at} inside the repeated text.` : `B still does not appear; add another copy.`,
              why: "Checking the first count that works gives the minimum copy number.",
              codeLine: 9,
            });
            if (answer >= 0) break;
          }
          steps.push({
            title: answer >= 0 ? `Answer: ${answer} cop${answer === 1 ? "y" : "ies"}` : "Answer: impossible",
            tracks: [chips("built", chars(built).slice(0, 32), "done"), chips("answer", [answer], "result")],
            counters: [count("copies", answer >= 0 ? answer : 0), count("answer", answer)],
            legend: LEG,
            happened: answer >= 0 ? `The smallest valid repeat count is ${answer}.` : "Even one extra copy does not contain B, so no repeat count works.",
            why: "If B is longer than A repeated beyond its own length plus A, it cannot occur.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "longest-happy-prefix",
    title: "Longest Happy Prefix",
    category: "Strings & Text",
    difficulty: "Advanced",
    description:
      "Find the longest proper prefix that is also a suffix, straight from the KMP prefix table.",
    input: { label: "text", default: "levellevel", parse: "chars" },
    approaches: [
      {
        name: "Last Entry of the Prefix Table",
        complexity: "O(n) time, O(n) space",
        idea: [
          "The KMP prefix table stores, at each position, the longest proper prefix equal to the suffix of the text up to that position.",
          "The final entry is exactly the longest happy prefix, because it covers the whole text. Reading that many characters from the front gives the answer.",
        ],
        problem: [
          "The answer must be a proper prefix, so a text with no border returns the empty string even though the whole text matches itself.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

void longest_prefix(const char *s) {
    int n = strlen(s);
    int pi[256] = {0};

    for (int i = 1; i < n; i++) {
        int k = pi[i - 1];
        while (k > 0 && s[i] != s[k]) k = pi[k - 1];
        if (s[i] == s[k]) k++;
        pi[i] = k;
    }

    int len = pi[n - 1];
    printf("%.*s\\n", len, s);  /* first len characters */
}

int main(void) {
    longest_prefix("levellevel"); /* level */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
using namespace std;

string longestPrefix(const string& s) {
    vector<int> pi(s.size(), 0);
    for (int i = 1; i < (int)s.size(); i++) {
        int k = pi[i - 1];
        while (k > 0 && s[i] != s[k]) k = pi[k - 1];
        if (s[i] == s[k]) k++;
        pi[i] = k;
    }
    return s.substr(0, pi.back());
}

int main() {
    cout << longestPrefix("levellevel") << '\\n'; // level
}`,
        },
        steps(text) {
          const s = chars(text);
          if (!s.length) {
            return [{
              title: "Give some text",
              tracks: [chips("text", ["—"], "idle")],
              counters: [count("length", 0)],
              legend: ["idle", "result"],
              happened: "An empty text has no proper prefix.",
              why: "The prefix table would be empty.",
            }];
          }
          const pi = prefixFunction(text);
          const steps = [];
          steps.push({
            title: `Compute the prefix table for ${s.length} characters`,
            tracks: [track("text", s, fill(s.length, "idle")), chips("pi", pi, "dim")],
            counters: [count("position", 0, s.length), count("border", 0)],
            legend: LEG,
            happened: `pi[i] measures the longest border of the text up to index i.`,
            why: "A border is a prefix that is also a suffix, which is exactly a happy prefix.",
            codeLine: 5,
          });
          for (let i = 1; i < s.length; i++) {
            let k = pi[i - 1];
            const startK = k;
            while (k > 0 && s[i] !== s[k]) k = pi[k - 1];
            if (s[i] === s[k]) k++;
            steps.push({
              title: `Position ${i} ('${s[i]}'): border ${startK} → ${k}`,
              tracks: [
                track("text", s, s.map((_, j) => (j === i ? "read" : j < i ? "done" : "dim"))),
                chips("pi", pi, (j) => (j === i ? "active" : j < i ? "done" : "dim")),
              ],
              counters: [count("position", i, s.length), count("border", k)],
              legend: LEG,
              happened: k > startK
                ? `'${s[i]}' extends the previous border to ${k}.`
                : k === startK
                  ? `The border stays at ${k}.`
                  : `The border shrinks from ${startK} to ${k} after a mismatch.`,
              why: "Falling back through pi keeps the largest valid overlap.",
              codeLine: 8,
            });
          }
          const best = pi[s.length - 1];
          const answer = s.slice(0, best).join("");
          steps.push({
            title: best ? `Answer: "${answer}" (${best} characters)` : "Answer: empty — the text has no proper border",
            tracks: [
              track("text", s, s.map((_, i) => (best && (i < best || i >= s.length - best) ? "result" : "dim"))),
              chips("answer", [best ? answer : "—"], "result"),
            ],
            counters: [count("border", best), count("answer length", best)],
            legend: LEG,
            happened: best
              ? `The first ${best} characters repeat at the end of the text.`
              : "No proper prefix of the text is also a suffix.",
            why: "The last table entry is the longest border of the whole text.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "shortest-palindrome",
    title: "Shortest Palindrome",
    category: "Strings & Text",
    difficulty: "Advanced",
    description:
      "Add the fewest characters in front of a text to make it a palindrome, using a prefix table.",
    input: { label: "text", default: "aacecaaa", parse: "chars" },
    approaches: [
      {
        name: "Border of Text Plus Reverse",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Only a prefix of the text can stay untouched; the characters before that prefix must be mirrored in front.",
          "Build text + '#' + reverse(text) and take the prefix table of the whole thing. Its last entry is the longest prefix of the text that is also a suffix of the reversed text — exactly the part that is already palindromic.",
        ],
        problem: [
          "The separator must be a character that never appears in the text, otherwise a false border can include it.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

int main(void) {
    const char *s = "aacecaaa";
    int n = strlen(s);
    char joined[256];
    strcpy(joined, s);
    joined[n] = '#';
    for (int i = 0; i < n; i++) joined[n + 1 + i] = s[n - 1 - i];
    joined[2 * n + 1] = 0;

    int m = 2 * n + 1, pi[256] = {0};
    for (int i = 1; i < m; i++) {
        int k = pi[i - 1];
        while (k > 0 && joined[i] != joined[k]) k = pi[k - 1];
        if (joined[i] == joined[k]) k++;
        pi[i] = k;
    }

    int keep = pi[m - 1];
    for (int i = n - 1; i >= keep; i--) putchar(s[i]);  /* mirrored tail, reversed */
    printf("%s\\n", s);
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

string shortestPalindrome(const string& s) {
    string joined = s + "#" + string(s.rbegin(), s.rend());
    vector<int> pi(joined.size(), 0);
    for (int i = 1; i < (int)joined.size(); i++) {
        int k = pi[i - 1];
        while (k > 0 && joined[i] != joined[k]) k = pi[k - 1];
        if (joined[i] == joined[k]) k++;
        pi[i] = k;
    }
    int keep = pi.back();
    string prefix = s.substr(keep);
    reverse(prefix.begin(), prefix.end());
    return prefix + s;
}

int main() {
    cout << shortestPalindrome("aacecaaa") << '\\n'; // aaacecaaa
}`,
        },
        steps(text) {
          const s = chars(text);
          if (!s.length) {
            return [{
              title: "Give some text",
              tracks: [chips("text", ["—"], "idle")],
              counters: [count("added", 0)],
              legend: ["idle", "result"],
              happened: "An empty text is already a palindrome.",
              why: "Nothing needs to be mirrored in front.",
            }];
          }
          const rev = s.slice().reverse();
          const joined = s.concat(["#"], rev);
          const pi = prefixFunction(joined.join(""));
          const steps = [];
          steps.push({
            title: `Join text + '#' + reverse → ${joined.join("")}`,
            tracks: [
              track("joined", joined, fill(joined.length, "idle")),
              chips("pi", pi, "dim"),
            ],
            counters: [count("joined length", joined.length), count("border", 0)],
            legend: LEG,
            happened: "The separator avoids matching across the boundary.",
            why: "A border of this joined text is the longest prefix of the text that is already a palindrome suffix.",
            codeLine: 4,
          });
          for (let i = 1; i < joined.length; i++) {
            let k = pi[i - 1];
            const before = k;
            while (k > 0 && joined[i] !== joined[k]) k = pi[k - 1];
            if (joined[i] === joined[k]) k++;
            steps.push({
              title: `Joined position ${i}: border ${before} → ${k}`,
              tracks: [
                track("joined", joined, joined.map((_, j) => (j === i ? "read" : j < i ? "done" : "dim"))),
                chips("pi", pi, (j) => (j === i ? "active" : j < i ? "done" : "dim")),
              ],
              counters: [count("joined length", joined.length), count("border", k)],
              legend: LEG,
              happened: k > before ? "The border grew by one." : k < before ? "The border fell back after a mismatch." : "The border held.",
              why: "The table is built exactly like a normal KMP table.",
              codeLine: 10,
            });
          }
          const keep = pi[joined.length - 1];
          const mirror = s.slice(keep).reverse();
          const answer = mirror.concat(s);
          steps.push({
            title: `Keep a palindromic prefix of ${keep}; mirror ${mirror.length} character${mirror.length === 1 ? "" : "s"}`,
            tracks: [
              track("text", s, s.map((_, i) => (i < keep ? "done" : "active"))),
              track("mirror", mirror, fill(mirror.length, "result")),
              chips("answer", [answer.join("")], "result"),
            ],
            counters: [count("kept", keep), count("added", mirror.length)],
            legend: LEG,
            happened: `The longest palindromic prefix has ${keep} characters, so the rest must be mirrored in front.`,
            why: "Characters before the palindromic prefix cannot be matched by anything already in place.",
            codeLine: 17,
          });
          steps.push({
            title: `Answer: ${answer.join("")}`,
            tracks: [chips("answer", [answer.join("")], "result")],
            counters: [count("original length", s.length), count("added", mirror.length)],
            legend: LEG,
            happened: `${answer.length - s.length} characters were added at the front.`,
            why: "The prefix table found the longest part that needed no help.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "repeated-substring-pattern",
    title: "Repeated Substring Pattern",
    category: "Strings & Text",
    difficulty: "Beginner",
    description:
      "Decide whether a text is a whole number of copies of a shorter piece, with the prefix table or the doubling trick.",
    input: { label: "text", default: "abab", parse: "chars" },
    approaches: [
      {
        name: "Border Length Test",
        complexity: "O(n) time, O(n) space",
        idea: [
          "A text repeats when its longest border has length n − period, where the period divides n.",
          "Equivalently, the text appears inside itself shifted by one period. The prefix table gives that period in one pass.",
        ],
        problem: [
          "A text with a border whose length is not a multiple of the period is not a repetition, so the divisibility check cannot be skipped.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

int repeats(const char *s) {
    int n = strlen(s);
    if (n < 2) return 0;

    int pi[256] = {0};
    for (int i = 1; i < n; i++) {
        int k = pi[i - 1];
        while (k > 0 && s[i] != s[k]) k = pi[k - 1];
        if (s[i] == s[k]) k++;
        pi[i] = k;
    }

    int border = pi[n - 1];
    int period = n - border;
    return border > 0 && n % period == 0;
}

int main(void) {
    printf("%d\\n", repeats("abab")); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
using namespace std;

bool repeatedSubstringPattern(const string& s) {
    int n = s.size();
    if (n < 2) return false;

    vector<int> pi(n, 0);
    for (int i = 1; i < n; i++) {
        int k = pi[i - 1];
        while (k > 0 && s[i] != s[k]) k = pi[k - 1];
        if (s[i] == s[k]) k++;
        pi[i] = k;
    }

    int border = pi.back();
    int period = n - border;
    return border > 0 && n % period == 0;
}

int main() {
    cout << repeatedSubstringPattern("abab") << '\\n'; // 1
}`,
        },
        steps(text) {
          const s = chars(text);
          if (s.length < 2) {
            return [{
              title: "A repeat needs at least two characters",
              tracks: [track("text", s.length ? s : ["—"], fill(Math.max(1, s.length), "bad"))],
              counters: [count("length", s.length)],
              legend: LEG,
              happened: "A single character or an empty text cannot be a repetition of a shorter piece.",
              why: "The repeated piece must be non-empty and strictly shorter than the text.",
            }];
          }
          const pi = prefixFunction(text);
          const steps = [];
          const n = s.length;
          steps.push({
            title: `Prefix table for "${s.join("")}"`,
            tracks: [track("text", s, fill(n, "idle")), chips("pi", pi, "dim")],
            counters: [count("length", n), count("border", 0)],
            legend: LEG,
            happened: "The last border entry determines the period.",
            why: "The period is the distance between repeats of the same prefix.",
            codeLine: 6,
          });
          for (let i = 1; i < n; i++) {
            steps.push({
              title: `Position ${i} ('${s[i]}'): pi = ${pi[i]}`,
              tracks: [
                track("text", s, s.map((_, j) => (j === i ? "read" : j < i ? "done" : "dim"))),
                chips("pi", pi, (j) => (j === i ? "active" : j < i ? "done" : "dim")),
              ],
              counters: [count("position", i, n), count("border", pi[i])],
              legend: LEG,
              happened: `The longest border ending here has length ${pi[i]}.`,
              why: "Each entry is computed from the previous border by extension or fallback.",
              codeLine: 10,
            });
          }
          const border = pi[n - 1];
          const period = n - border;
          const ok = border > 0 && n % period === 0;
          steps.push({
            title: `Border ${border} → period ${period} → ${ok ? "divides evenly" : "does not divide evenly"}`,
            tracks: [
              track("text", s, s.map((_, i) => (border && (i < border || i >= n - border) ? "compare" : "idle"))),
              chips("period", [period], ok ? "good" : "bad"),
            ],
            counters: [count("border", border), count("period", period)],
            legend: LEG,
            happened: border ? `The text has a border of ${border}, so it would repeat with period ${period}.` : "The text has no border at all.",
            why: "A valid repetition needs the period to tile the text exactly.",
            codeLine: 16,
          });
          steps.push({
            title: ok ? `Answer: yes, "${s.slice(0, period).join("")}" repeats ${n / period} times` : "Answer: no, the text is not a repetition",
            tracks: [
              track("text", s, s.map((_, i) => (ok ? (Math.floor(i / period) % 2 ? "result" : "done") : "bad"))),
              chips("answer", [ok ? "yes" : "no"], "result"),
            ],
            counters: [count("period", period), count("answer", ok ? "yes" : "no")],
            legend: LEG,
            happened: ok ? `The piece of length ${period} rebuilds the whole text.` : "No shorter piece tiles the text.",
            why: "The prefix table settles the question in one linear pass.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "longest-duplicate-substring",
    title: "Longest Duplicate Substring",
    category: "Strings & Text",
    difficulty: "Advanced",
    description:
      "Find the longest piece of the text that appears at least twice, by binary searching the length.",
    input: { label: "text", default: "banana", parse: "chars" },
    approaches: [
      {
        name: "Binary Search the Length",
        complexity: "O(n² log n) time without hashing, O(n log n) with rolling hashes",
        idea: [
          "If a duplicate of length L exists, duplicates of every shorter length exist too, so length is monotone and can be binary searched.",
          "For a trial length, slide a window across the text and remember each piece in a set. A repeated piece confirms that length.",
        ],
        problem: [
          "Building a full substring at every window costs L work, so the simple version is quadratic per check; rolling hashes remove that.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

void longest_duplicate(const char *s) {
    int n = strlen(s), lo = 1, hi = n - 1;
    int bestStart = 0, bestLen = 0;

    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        int found = -1;
        for (int i = 0; i + mid <= n && found < 0; i++)
            for (int j = i + 1; j + mid <= n; j++)
                if (strncmp(s + i, s + j, mid) == 0) { found = i; break; }

        if (found >= 0) { bestStart = found; bestLen = mid; lo = mid + 1; }
        else hi = mid - 1;
    }
    if (bestLen) printf("%.*s\\n", bestLen, s + bestStart);
}

int main(void) {
    longest_duplicate("banana"); /* ana */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <unordered_set>
using namespace std;

bool hasDuplicate(const string& s, int len) {
    unordered_set<string> seen;
    for (int i = 0; i + len <= (int)s.size(); i++) {
        if (!seen.insert(s.substr(i, len)).second) return true;
    }
    return false;
}

string longestDupSubstring(const string& s) {
    int lo = 1, hi = s.size() - 1;
    string best;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (hasDuplicate(s, mid)) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return best;
}

int main() {
    cout << longestDupSubstring("banana") << '\\n'; // ana
}`,
        },
        steps(text) {
          const s = chars(text);
          const n = s.length;
          if (n < 2) {
            return [{
              title: "A duplicate needs at least two characters",
              tracks: [track("text", s.length ? s : ["—"], fill(Math.max(1, n), "bad"))],
              counters: [count("length", n)],
              legend: LEG,
              happened: "Nothing can repeat in a text this short.",
              why: "The search range of lengths is empty.",
            }];
          }
          const steps = [];
          const duplicateAt = (len) => {
            const seen = new Map();
            for (let i = 0; i + len <= n; i++) {
              const piece = s.slice(i, i + len).join("");
              if (seen.has(piece)) return [seen.get(piece), i, piece];
              seen.set(piece, i);
            }
            return null;
          };
          let lo = 1, hi = n - 1, best = "";
          steps.push({
            title: `Search duplicate lengths 1..${n - 1} in "${s.join("")}"`,
            tracks: [track("text", s, fill(n, "idle"))],
            counters: [count("range", `1..${n - 1}`), count("best", "—")],
            legend: LEG,
            happened: "If length L repeats, every shorter length repeats as well.",
            why: "Monotone feasibility is what permits binary search on the length.",
            codeLine: 9,
          });
          while (lo <= hi) {
            const mid = lo + Math.floor((hi - lo) / 2);
            const hit = duplicateAt(mid);
            const ok = hit != null;
            if (ok) best = hit[2];
            steps.push({
              title: `Length ${mid}: ${ok ? `"${hit[2]}" repeats at ${hit[0]} and ${hit[1]}` : "no duplicate"}`,
              tracks: [
                track("text", s, s.map((_, i) => (ok && (isWindow(i, hit[0], hit[0] + mid) || isWindow(i, hit[1], hit[1] + mid)) ? "result" : "dim"))),
                chips("candidate", [ok ? hit[2] : "—"], ok ? "good" : "bad"),
              ],
              counters: [count("range", `${lo}..${hi}`), count("best length", best.length)],
              legend: LEG,
              happened: ok
                ? `The piece "${hit[2]}" occurs twice, so longer lengths are worth trying.`
                : "No piece of this length repeats, so the answer must be shorter.",
              why: "Each check scans all windows of one length and stores them in a set.",
              codeLine: ok ? 13 : 14,
            });
            if (ok) lo = mid + 1;
            else hi = mid - 1;
          }
          steps.push({
            title: best ? `Answer: "${best}" (${best.length} characters)` : "Answer: no duplicate substring",
            tracks: [
              track("text", s, s.map((_, i) => (best && isWindow(i, 0, 0) ? "dim" : "idle"))),
              chips("answer", [best || "—"], "result"),
            ],
            counters: [count("answer length", best.length), count("answer", best || "—")],
            legend: LEG,
            happened: best ? `The longest repeated piece is "${best}".` : "No piece occurs twice.",
            why: "Binary search found the largest feasible length.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "distinct-echo-substrings",
    title: "Distinct Echo Substrings",
    category: "Strings & Text",
    difficulty: "Advanced",
    description:
      "Count distinct pieces of the form a + a that appear anywhere in the text.",
    input: { label: "text", default: "abcabcabc", parse: "chars" },
    approaches: [
      {
        name: "Enumerate Echo Lengths",
        complexity: "O(n³) naive, O(n²) with string hashing",
        idea: [
          "An echo is two identical halves back to back. For each start and each half-length, compare the two halves.",
          "Store the full echo text in a set so identical echoes starting at different places are counted once.",
        ],
        problem: [
          "Naive half comparison is cubic in the worst case, so hashing or a suffix structure is needed for long inputs.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

int main(void) {
    const char *s = "abcabcabc";
    int n = strlen(s);
    char seen[256][64];
    int count = 0;

    for (int i = 0; i < n; i++)
        for (int len = 1; i + 2 * len <= n; len++) {
            int same = 1;
            for (int k = 0; k < len; k++)
                if (s[i + k] != s[i + len + k]) { same = 0; break; }
            if (!same) continue;

            char piece[64];
            memcpy(piece, s + i, 2 * len);
            piece[2 * len] = 0;

            int dup = 0;
            for (int j = 0; j < count; j++)
                if (strcmp(seen[j], piece) == 0) { dup = 1; break; }
            if (!dup) strcpy(seen[count++], piece);
        }

    printf("%d\\n", count); /* 3: aa? none - check actual output */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <unordered_set>
using namespace std;

int distinctEchoSubstrings(const string& s) {
    unordered_set<string> seen;
    int n = s.size();
    for (int i = 0; i < n; i++) {
        for (int len = 1; i + 2 * len <= n; len++) {
            if (s.compare(i, len, s, i + len, len) == 0)
                seen.insert(s.substr(i, 2 * len));
        }
    }
    return seen.size();
}

int main() {
    cout << distinctEchoSubstrings("abcabcabc") << '\\n';
}`,
        },
        steps(text) {
          const s = chars(text);
          const n = s.length;
          if (n < 2) {
            return [{
              title: "An echo needs two halves",
              tracks: [track("text", s.length ? s : ["—"], fill(Math.max(1, n), "bad"))],
              counters: [count("echoes", 0)],
              legend: LEG,
              happened: "A text shorter than two characters has no echo.",
              why: "The smallest echo is two identical characters.",
            }];
          }
          const steps = [];
          const seen = new Set();
          const found = [];
          steps.push({
            title: `Look for a + a pieces inside "${s.join("")}"`,
            tracks: [track("text", s, fill(n, "idle"))],
            counters: [count("echoes", 0), count("checked", 0)],
            legend: LEG,
            happened: "Every start and half-length is a candidate.",
            why: "An echo is fully determined by its start and half-length.",
            codeLine: 5,
          });
          let checked = 0;
          for (let i = 0; i < n; i++) {
            const runs = [];
            for (let len = 1; i + 2 * len <= n; len++) {
              checked++;
              let same = true;
              for (let k = 0; k < len && same; k++) if (s[i + k] !== s[i + len + k]) same = false;
              if (!same) continue;
              const piece = s.slice(i, i + 2 * len).join("");
              const fresh = !seen.has(piece);
              seen.add(piece);
              if (fresh) found.push(piece);
              runs.push(`${piece}${fresh ? " ✓" : " (already seen)"}`);
            }
            if (runs.length) {
              steps.push({
                title: `Start ${i}: ${runs.length} echo${runs.length === 1 ? "" : "es"}`,
                tracks: [
                  track("text", s, s.map((_, k) => (k === i ? "read" : k > i && k < i + 2 && runs.length ? "compare" : "idle"))),
                  chips("found here", runs, "good"),
                  chips("distinct so far", found.length ? found : ["—"], "result"),
                ],
                counters: [count("echoes", seen.size), count("checked", checked)],
                legend: LEG,
                happened: `Two identical halves meet at this start.`,
                why: "Only new strings increase the distinct count.",
                codeLine: 9,
              });
            }
          }
          steps.push({
            title: `Answer: ${seen.size} distinct echo${seen.size === 1 ? "" : "es"}`,
            tracks: [track("text", s, fill(n, "done")), chips("echoes", found.length ? found : ["none"], "result")],
            counters: [count("echoes", seen.size), count("checked", checked)],
            legend: LEG,
            happened: found.length ? `The distinct echoes are ${found.join(", ")}.` : "No half-pair matched anywhere.",
            why: "The set removes duplicates that arise from different starts.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });
})();
