/* ============================================================
   DSA Visuals — Divide & Conquer I
   Split a problem, solve the pieces, combine the answers. The
   recursion tree is shown as it unfolds.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "swap", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const nums = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number);
  const show = (a) => `[${a.join(", ")}]`;

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-subarray-with-divide-and-conquer",
    title: "Maximum Subarray with Divide and Conquer",
    category: "Divide & Conquer",
    difficulty: "Intermediate",
    description:
      "Find the best subarray sum by splitting the row and also considering sums that cross the middle.",
    input: { label: "numbers", default: "-2,1,-3,4,-1,2,1,-5,4", parse: "ints" },
    approaches: [
      {
        name: "Left, Right and Crossing",
        complexity: "O(n log n) time, O(log n) stack space",
        idea: [
          "Split the row in half. The best subarray lies entirely left, entirely right, or crosses the midpoint.",
          "The crossing sum is the best suffix of the left half plus the best prefix of the right half, computed in one scan each.",
        ],
        problem: [
          "Crossing sums must respect the midpoint, so a plain maximum-prefix on the whole row is not enough.",
        ],
        code: {
          c: `#include <stdio.h>
#include <limits.h>

int best_crossing(int *a, int lo, int mid, int hi) {
    int sum = 0, leftBest = INT_MIN;
    for (int i = mid; i >= lo; i--) { sum += a[i]; if (sum > leftBest) leftBest = sum; }

    sum = 0;
    int rightBest = INT_MIN;
    for (int i = mid + 1; i <= hi; i++) { sum += a[i]; if (sum > rightBest) rightBest = sum; }

    return leftBest + rightBest;
}

int best_sum(int *a, int lo, int hi) {
    if (lo == hi) return a[lo];
    int mid = (lo + hi) / 2;
    int left = best_sum(a, lo, mid);
    int right = best_sum(a, mid + 1, hi);
    int cross = best_crossing(a, lo, mid, hi);

    int best = left > right ? left : right;
    return cross > best ? cross : best;
}

int main(void) {
    int a[] = {-2,1,-3,4,-1,2,1,-5,4};
    printf("%d\\n", best_sum(a, 0, 8)); /* 6 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <climits>
using namespace std;

int bestSum(const vector<int>& a, int lo, int hi) {
    if (lo == hi) return a[lo];
    int mid = (lo + hi) / 2;

    int left = bestSum(a, lo, mid);
    int right = bestSum(a, mid + 1, hi);

    int sum = 0, leftBest = INT_MIN;
    for (int i = mid; i >= lo; i--) { sum += a[i]; leftBest = max(leftBest, sum); }
    sum = 0;
    int rightBest = INT_MIN;
    for (int i = mid + 1; i <= hi; i++) { sum += a[i]; rightBest = max(rightBest, sum); }

    return max({left, right, leftBest + rightBest});
}

int main() {
    cout << bestSum({-2,1,-3,4,-1,2,1,-5,4}, 0, 8) << '\\n'; // 6
}`,
        },
        steps(values) {
          const a = values.slice();
          if (!a.length) {
            return [{
              title: "Give some numbers",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("best", 0)],
              legend: ["idle", "result"],
              happened: "There is no subarray to measure.",
              why: "The split needs at least one value.",
            }];
          }
          const steps = [];
          steps.push({
            title: `${a.length} values; a best subarray is left, right or crossing`,
            tracks: [track("numbers", a, fill(a.length, "idle"))],
            counters: [count("window", `0..${a.length - 1}`), count("best", "—")],
            legend: LEG,
            happened: "The crossing case is the only one that needs the midpoint.",
            why: "Every subarray is entirely on one side or straddles the split.",
            codeLine: 14,
          });
          const solve = (lo, hi) => {
            if (lo === hi) return a[lo];
            const mid = Math.floor((lo + hi) / 2);
            const left = solve(lo, mid);
            const right = solve(mid + 1, hi);
            let sum = 0, leftBest = -Infinity;
            for (let i = mid; i >= lo; i--) { sum += a[i]; leftBest = Math.max(leftBest, sum); }
            sum = 0;
            let rightBest = -Infinity;
            for (let i = mid + 1; i <= hi; i++) { sum += a[i]; rightBest = Math.max(rightBest, sum); }
            const cross = leftBest + rightBest;
            const best = Math.max(left, right, cross);
            steps.push({
              title: `Split ${lo}..${hi}: left ${left}, right ${right}, crossing ${cross} → ${best}`,
              tracks: [
                track("numbers", a, a.map((_, i) => (i >= lo && i <= hi ? (i <= mid ? "done" : "compare") : "dim"))),
                chips("cases", [`left ${left}`, `right ${right}`, `cross ${cross}`], (i) => ([left, right, cross][i] === best ? "result" : "dim")),
              ],
              counters: [count("window", `${lo}..${hi}`), count("best here", best)],
              legend: LEG,
              happened: cross > Math.max(left, right)
                ? "The crossing sum wins, so the best subarray must include the midpoint."
                : `A subarray entirely in one half wins with ${best}.`,
              why: "The crossing sum is a suffix of the left half plus a prefix of the right half.",
              codeLine: 18,
            });
            return best;
          };
          const answer = solve(0, a.length - 1);
          steps.push({
            title: `Answer: ${answer}`,
            tracks: [chips("answer", [answer], "result")],
            counters: [count("answer", answer), count("values", a.length)],
            legend: LEG,
            happened: `The largest subarray sum is ${answer}.`,
            why: "At every level the three cases cover all possible subarrays.",
            codeLine: 21,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "different-ways-to-add-parentheses",
    title: "Different Ways to Add Parentheses",
    category: "Divide & Conquer",
    difficulty: "Advanced",
    description:
      "Enumerate every result obtainable by parenthesising an arithmetic expression in all valid ways.",
    input: { label: "expression of numbers and + - *", default: "2-1-1", parse: "string" },
    approaches: [
      {
        name: "Split at Every Operator",
        complexity: "O(Catalan(n)) results, exponential worst case",
        idea: [
          "Every top-level operator could be the last one evaluated. Split the expression at each operator and solve both sides recursively.",
          "Combine every left result with every right result using that operator. The union over all splits is the answer.",
        ],
        problem: [
          "The number of parenthesations grows as the Catalan numbers, so long expressions explode without memoisation.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int solve(const char *s, int *out) {
    int n = 0, is_number = 1;

    for (int i = 0; s[i]; i++) if (s[i] == '+' || s[i] == '-' || s[i] == '*') is_number = 0;
    if (is_number) { out[0] = atoi(s); return 1; }

    int total = 0;
    for (int i = 0; s[i]; i++) {
        if (s[i] != '+' && s[i] != '-' && s[i] != '*') continue;

        char left[64], right[64];
        strncpy(left, s, i); left[i] = 0;
        strcpy(right, s + i + 1);

        int lv[64], rv[64];
        int ln = solve(left, lv), rn = solve(right, rv);

        for (int p = 0; p < ln; p++)
            for (int q = 0; q < rn; q++) {
                int v = s[i] == '+' ? lv[p] + rv[q] : s[i] == '-' ? lv[p] - rv[q] : lv[p] * rv[q];
                out[total++] = v;
            }
    }
    return total;
}

int main(void) {
    int out[64];
    int n = solve("2-1-1", out);
    for (int i = 0; i < n; i++) printf("%d ", out[i]);
    printf("\\n"); /* 0 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <string>
using namespace std;

vector<int> diffWaysToCompute(const string& s) {
    vector<int> out;

    for (int i = 0; i < (int)s.size(); i++) {
        if (s[i] != '+' && s[i] != '-' && s[i] != '*') continue;

        auto left = diffWaysToCompute(s.substr(0, i));
        auto right = diffWaysToCompute(s.substr(i + 1));

        for (int l : left) for (int r : right) {
            if (s[i] == '+') out.push_back(l + r);
            else if (s[i] == '-') out.push_back(l - r);
            else out.push_back(l * r);
        }
    }
    if (out.empty()) out.push_back(stoi(s));
    return out;
}

int main() {
    for (int v : diffWaysToCompute("2-1-1")) cout << v << ' '; // 0 2
    cout << '\\n';
}`,
        },
        steps(text) {
          const raw = String(text || "").replace(/\s+/g, "");
          if (!raw) {
            return [{
              title: "Give an expression",
              tracks: [chips("expression", ["—"], "idle")],
              counters: [count("results", 0)],
              legend: ["idle", "result"],
              happened: "Use numbers and the operators +, - and *.",
              why: "Each operator is a possible last evaluation.",
            }];
          }
          const memo = new Map();
          const steps = [];
          const solveExpr = (expr) => {
            if (memo.has(expr)) return memo.get(expr);
            const results = [];
            const splits = [];
            for (let i = 0; i < expr.length; i++) {
              const op = expr[i];
              if (op !== "+" && op !== "-" && op !== "*") continue;
              const left = solveExpr(expr.slice(0, i));
              const right = solveExpr(expr.slice(i + 1));
              const combined = [];
              for (const l of left) for (const r of right) {
                const v = op === "+" ? l + r : op === "-" ? l - r : l * r;
                combined.push(v);
                results.push(v);
              }
              splits.push(`${expr.slice(0, i)} ${op} ${expr.slice(i + 1)} → ${show(combined)}`);
            }
            if (!splits.length) results.push(parseInt(expr, 10) || 0);
            memo.set(expr, results);
            steps.push({
              title: splits.length ? `"${expr}" splits into ${results.length} value${results.length === 1 ? "" : "s"}` : `"${expr}" is a number → ${results[0]}`,
              tracks: [
                chips("expression", [expr], "read"),
                chips("splits", splits.length ? splits : ["literal"], "dim"),
                chips("results", results.length ? results : ["—"], "result"),
              ],
              counters: [count("results", results.length), count("memo entries", memo.size)],
              legend: LEG,
              happened: splits.length ? "Each operator is evaluated last in turn." : "A literal is its own only result.",
              why: "Every parenthesation has exactly one top-level operator.",
              codeLine: splits.length ? 8 : 16,
            });
            return results;
          };
          const answer = solveExpr(raw);
          steps.push({
            title: `Answer: ${show(answer)}`,
            tracks: [chips("answer", answer, "result")],
            counters: [count("results", answer.length), count("distinct", new Set(answer).size)],
            legend: LEG,
            happened: `There are ${answer.length} ways to evaluate the expression.`,
            why: "Different split orders can produce the same value, so duplicates may appear.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "sort-a-stack-recursively",
    title: "Sort a Stack Recursively",
    category: "Divide & Conquer",
    difficulty: "Advanced",
    description:
      "Sort a stack using only push, pop and recursion, inserting each held value in the right place.",
    input: { label: "stack values (top first)", default: "3,1,4,1,5", parse: "ints" },
    approaches: [
      {
        name: "Pop, Sort, Insert",
        complexity: "O(n²) time, O(n) stack space",
        idea: [
          "Pop the top value and recursively sort the rest of the stack. Then insert the held value back in sorted position.",
          "Insertion pops larger values aside, recurses, places the value, and pushes the larger ones back on top.",
        ],
        problem: [
          "Only stack operations are allowed, so the algorithm cannot index into the middle and pays quadratic time.",
        ],
        code: {
          c: `#include <stdio.h>

int stack_values[64], top = 0;

void push(int v) { stack_values[top++] = v; }
int pop(void) { return stack_values[--top]; }

void insert_sorted(int v) {
    if (top == 0 || stack_values[top - 1] <= v) { push(v); return; }
    int held = pop();
    insert_sorted(v);
    push(held);
}

void sort_stack(void) {
    if (top == 0) return;
    int held = pop();
    sort_stack();
    insert_sorted(held);
}

int main(void) {
    push(3); push(1); push(4); push(1); push(5);
    sort_stack();
    while (top > 0) printf("%d ", pop());
    printf("\\n"); /* 5 4 3 1 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <stack>
using namespace std;

void insertSorted(stack<int>& s, int v) {
    if (s.empty() || s.top() <= v) { s.push(v); return; }
    int held = s.top(); s.pop();
    insertSorted(s, v);
    s.push(held);
}

void sortStack(stack<int>& s) {
    if (s.empty()) return;
    int held = s.top(); s.pop();
    sortStack(s);
    insertSorted(s, held);
}

int main() {
    stack<int> s;
    for (int v : {3,1,4,1,5}) s.push(v);
    sortStack(s);
    while (!s.empty()) { cout << s.top() << ' '; s.pop(); } // 5 4 3 1 1
    cout << '\\n';
}`,
        },
        steps(values) {
          const a = values.slice();
          if (!a.length) {
            return [{
              title: "Give some stack values",
              tracks: [chips("stack (top first)", ["—"], "idle")],
              counters: [count("size", 0)],
              legend: ["idle", "result"],
              happened: "The leftmost value is the top of the stack.",
              why: "Only the top is reachable without extra structures.",
            }];
          }
          const steps = [];
          const stack = a.slice();
          steps.push({
            title: `Stack top first: ${show(stack)}`,
            tracks: [chips("stack (top first)", stack, "idle")],
            counters: [count("size", stack.length), count("sorted suffix", 0)],
            legend: LEG,
            happened: "The goal is the largest value on top.",
            why: "Recursion can hold popped values while the rest is sorted.",
            codeLine: 3,
          });
          const simulate = [];
          const simulateInsert = (v, depth) => {
            if (!simulate.length || simulate[0] <= v) {
              simulate.unshift(v);
              steps.push({
                title: `Insert ${v}: the stack top ${simulate[1] != null ? simulate[1] : "—"} is not larger, so place it`,
                tracks: [chips("working stack", simulate, (i) => (i === 0 ? "result" : "done")), chips("held", ["—"], "dim")],
                counters: [count("size", simulate.length), count("depth", depth)],
                legend: LEG,
                happened: `${v} belongs above every value no larger than it.`,
                why: "The rest of the stack is already sorted from top to bottom.",
                codeLine: 6,
              });
              return;
            }
            const held = simulate.shift();
            steps.push({
              title: `Insert ${v}: pop ${held} aside`,
              tracks: [chips("working stack", simulate, "dim"), chips("held", [held], "active")],
              counters: [count("size", simulate.length), count("depth", depth)],
              legend: LEG,
              happened: `${held} is larger than ${v}, so it must stay above it.`,
              why: "Larger values are held until the correct place for v appears.",
              codeLine: 8,
            });
            simulateInsert(v, depth + 1);
            simulate.unshift(held);
            steps.push({
              title: `Put ${held} back on top`,
              tracks: [chips("working stack", simulate, (i) => (i === 0 ? "good" : "done"))],
              counters: [count("size", simulate.length), count("depth", depth)],
              legend: LEG,
              happened: `${held} resumes its place above ${v}.`,
              why: "Held values are returned in the reverse order they were popped.",
              codeLine: 9,
            });
          };
          for (let i = 0; i < a.length; i++) {
            const held = a[i];
            steps.push({
              title: `Pop ${held} and sort the rest`,
              tracks: [chips("remaining", a.slice(i + 1), "dim"), chips("held", [held], "active")],
              counters: [count("remaining", a.length - i - 1), count("held", held)],
              legend: LEG,
              happened: `The top ${held} waits while the deeper stack is sorted.`,
              why: "Recursion solves the smaller stack before inserting the held value.",
              codeLine: 13,
            });
            simulateInsert(held, 0);
          }
          const finalTop = simulate.slice().sort((x, y) => y - x);
          steps.push({
            title: `Answer (top first): ${show(finalTop)}`,
            tracks: [chips("stack (top first)", finalTop, "result")],
            counters: [count("size", finalTop.length), count("answer", finalTop[0])],
            legend: LEG,
            happened: `The largest value ${finalTop[0]} is now on top.`,
            why: "Inserting every held value in order sorts the stack using only stack operations.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "tower-of-hanoi",
    title: "Tower of Hanoi",
    category: "Divide & Conquer",
    difficulty: "Beginner",
    description:
      "Move a stack of disks between pegs without ever placing a larger disk on a smaller one.",
    input: { label: "number of disks", default: "3", parse: "int" },
    approaches: [
      {
        name: "Move n−1, Move Largest, Move n−1",
        complexity: "O(2ⁿ) moves",
        idea: [
          "To move n disks from source to target, first move n−1 disks to the spare peg.",
          "Then move the largest disk to the target, and finally move the n−1 disks from the spare onto it.",
        ],
        problem: [
          "The move count doubles with each extra disk, so even moderate n is impractical.",
        ],
        code: {
          c: `#include <stdio.h>

void hanoi(int n, char from, char to, char spare) {
    if (n == 0) return;
    hanoi(n - 1, from, spare, to);
    printf("%c -> %c\\n", from, to);
    hanoi(n - 1, spare, to, from);
}

int main(void) {
    hanoi(3, 'A', 'C', 'B'); /* 7 moves */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

void hanoi(int n, char from, char to, char spare) {
    if (n == 0) return;
    hanoi(n - 1, from, spare, to);
    cout << from << " -> " << to << '\\n';
    hanoi(n - 1, spare, to, from);
}

int main() {
    hanoi(3, 'A', 'C', 'B'); // 7 moves
}`,
        },
        steps(nRaw) {
          const n = Math.max(1, Math.min(5, parseInt(nRaw, 10) || 1));
          const pegs = {
            A: Array.from({ length: n }, (_, i) => n - i),
            B: [],
            C: [],
          };
          const steps = [];
          const totalMoves = Math.pow(2, n) - 1;
          const pegsChips = (states) => ["A", "B", "C"].map((name) =>
            chips(`peg ${name}${name === "A" ? " (source)" : name === "C" ? " (target)" : " (spare)"}`, pegs[name].length ? pegs[name] : ["—"], states && states[name])
          );
          steps.push({
            title: `${n} disks on A; ${totalMoves} moves are required`,
            tracks: pegsChips(),
            counters: [count("disks", n), count("moves done", 0, totalMoves)],
            legend: LEG,
            happened: "A larger disk may never sit on a smaller one.",
            why: "Each disk can only move onto an empty peg or a larger disk.",
            codeLine: 3,
          });
          let moves = 0;
          const move = (countDisks, from, to, spare, depth) => {
            if (countDisks === 0) return;
            move(countDisks - 1, from, spare, to, depth + 1);
            const disk = pegs[from].pop();
            pegs[to].push(disk);
            moves++;
            steps.push({
              title: `Move disk ${disk}: ${from} → ${to} (move ${moves})`,
              tracks: [
                chips("from " + from, pegs[from].length ? pegs[from] : ["—"], "active"),
                chips("to " + to, pegs[to].length ? pegs[to] : ["—"], "done"),
                chips("spare " + spare, pegs[spare].length ? pegs[spare] : ["—"], "dim"),
              ],
              counters: [count("moves done", moves, totalMoves), count("disk", disk)],
              legend: LEG,
              happened: `Disk ${disk} moved with the larger disks still underneath.`,
              why: "The recursion guarantees the target peg is ready for this disk.",
              codeLine: 4,
            });
            move(countDisks - 1, spare, to, from, depth + 1);
          };
          move(n, "A", "C", "B", 0);
          steps.push({
            title: `Answer: ${moves} moves — stack ${show(pegs.C)} on C`,
            tracks: pegsChips({ A: "dim", B: "dim", C: "result" }),
            counters: [count("moves", moves, totalMoves), count("disks on C", pegs.C.length)],
            legend: LEG,
            happened: `All ${n} disks are stacked on the target peg.`,
            why: "The move count is exactly 2ⁿ − 1, as the recurrence predicts.",
            codeLine: 8,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "kth-symbol-in-grammar",
    title: "Kth Symbol in Grammar",
    category: "Divide & Conquer",
    difficulty: "Intermediate",
    description:
      "Find the kth symbol of a row generated by replacing 0 with 01 and 1 with 10, without building the rows.",
    input: { label: "row n | position k", default: "4 | 5", parse: "string" },
    approaches: [
      {
        name: "Walk Up the Parent Chain",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Each pair in the next row comes from one symbol in the previous row: 0 becomes 01 and 1 becomes 10.",
          "The kth symbol in row n comes from the ceil(k / 2) symbol in row n − 1. Odd k keeps the parent value, even k flips it.",
        ],
        problem: [
          "The flip rule depends on parity; treating all children as copies gives wrong answers for even k.",
        ],
        code: {
          c: `#include <stdio.h>

int kth_symbol(int n, int k) {
    int value = 0;
    int flips = 0;

    while (n > 1) {
        if (k % 2 == 0) flips++;      /* right child is flipped */
        k = (k + 1) / 2;
        n--;
    }
    value = 0;
    return flips % 2 ? 1 : value;
}

int main(void) {
    printf("%d\\n", kth_symbol(4, 5)); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

int kthGrammar(int n, int k) {
    int value = 0;

    while (n > 1) {
        if (k % 2 == 0) value ^= 1;   // right child flips
        k = (k + 1) / 2;
        n--;
    }
    return value;
}

int main() {
    cout << kthGrammar(4, 5) << '\\n'; // 1
}`,
        },
        steps(text) {
          const [nRaw, kRaw] = parts(text);
          const n = Math.max(1, Math.min(10, parseInt(nRaw, 10) || 1));
          const k = Math.max(1, parseInt(kRaw, 10) || 1);
          const steps = [];
          const rows = ["0"];
          for (let r = 1; r < n; r++) {
            rows.push(Array.from(rows[r - 1]).map((c) => (c === "0" ? "01" : "10")).join(""));
          }
          steps.push({
            title: `Build rows 1..${n} for reference (row ${n} has ${Math.pow(2, n - 1)} symbols)`,
            tracks: rows.map((row, r) => chips(`row ${r + 1}`, row.length <= 40 ? Array.from(row) : [row.slice(0, 37) + "…"], "dim")),
            counters: [count("row", n), count("target k", k)],
            legend: LEG,
            happened: `Looking for position ${k} in the last row.`,
            why: "The walk upward never needs to store these rows.",
            codeLine: 4,
          });
          let pos = k, row = n, flips = 0;
          steps.push({
            title: `Start at row ${row}, position ${pos}, value unknown`,
            tracks: [chips(`row ${row}`, Array.from(rows[row - 1]).slice(0, 32), (i) => (i === pos - 1 ? "read" : "dim")), chips("flips", [flips], "idle")],
            counters: [count("row", row), count("position", pos)],
            legend: LEG,
            happened: "Move to the parent by halving the position.",
            why: "Each parent has exactly two children in the next row.",
            codeLine: 5,
          });
          while (row > 1) {
            const right = pos % 2 === 0;
            if (right) flips++;
            const parent = Math.ceil(pos / 2);
            pos = parent;
            row--;
            steps.push({
              title: `Row ${row + 1} position ${pos * 2 - (right ? 0 : 1)} → parent ${pos}${right ? ", flipped" : ", same"}`,
              tracks: [
                chips(`row ${row + 1}`, Array.from(rows[row]).slice(0, 32), (i) => (i === (right ? pos * 2 - 1 : pos * 2 - 2) ? "read" : "dim")),
                chips(`row ${row}`, Array.from(rows[row - 1]).slice(0, 32), (i) => (i === pos - 1 ? "active" : "dim")),
                chips("flips", [flips], flips % 2 ? "bad" : "dim"),
              ],
              counters: [count("row", row), count("position", pos), count("flips", flips)],
              legend: LEG,
              happened: right ? "An even position is a right child, so its value is flipped." : "An odd position is a left child, so its value matches the parent.",
              why: "The first symbol is always 0, so parity of flips determines the value.",
              codeLine: right ? 5 : 6,
            });
          }
          const answer = flips % 2;
          steps.push({
            title: `Answer: ${answer}`,
            tracks: [chips("row 1", ["0"], "dim"), chips("answer", [answer], "result")],
            counters: [count("flips", flips), count("answer", answer)],
            legend: LEG,
            happened: `Starting from 0 and flipping ${flips} time${flips === 1 ? "" : "s"} gives ${answer}.`,
            why: "Exactly one parent step is taken per row, so the walk is linear.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "count-good-numbers",
    title: "Count Good Numbers",
    category: "Divide & Conquer",
    difficulty: "Intermediate",
    description:
      "Count length-n digit strings where even indices hold even digits and odd indices hold primes.",
    input: { label: "length n", default: "4", parse: "int" },
    approaches: [
      {
        name: "Fast Power Over Two Choices",
        complexity: "O(log n) time",
        idea: [
          "Positions 0, 2, 4, … may hold one of five even digits. Positions 1, 3, 5, … may hold one of four prime digits.",
          "The count is 5^evenPositions × 4^oddPositions modulo 1e9+7. Fast exponentiation computes each power in logarithmic multiplications.",
        ],
        problem: [
          "A linear loop over positions would be too slow for large n, and plain exponentiation overflows long before the modulo.",
        ],
        code: {
          c: `#include <stdio.h>

#define MOD 1000000007

long long power(long long base, long long exp) {
    long long result = 1;
    base %= MOD;
    while (exp > 0) {
        if (exp & 1) result = result * base % MOD;
        base = base * base % MOD;
        exp >>= 1;
    }
    return result;
}

int count_good(long long n) {
    long long evens = (n + 1) / 2;
    long long odds = n / 2;
    return (int)(power(5, evens) * power(4, odds) % MOD);
}

int main(void) {
    printf("%d\\n", count_good(4)); /* 400 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

const long long MOD = 1000000007;

long long power(long long base, long long exp) {
    long long result = 1;
    while (exp > 0) {
        if (exp & 1) result = result * base % MOD;
        base = base * base % MOD;
        exp >>= 1;
    }
    return result;
}

int countGoodNumbers(long long n) {
    return (int)(power(5, (n + 1) / 2) * power(4, n / 2) % MOD);
}

int main() {
    cout << countGoodNumbers(4) << '\\n'; // 400
}`,
        },
        steps(nRaw) {
          const n = Math.max(1, Math.min(1000000, parseInt(nRaw, 10) || 1));
          const evens = Math.ceil(n / 2);
          const odds = Math.floor(n / 2);
          const MOD = 1000000007;
          const steps = [];
          steps.push({
            title: `Length ${n}: ${evens} even position${evens === 1 ? "" : "s"}, ${odds} odd`,
            tracks: [chips("positions", Array.from({ length: Math.min(n, 20) }, (_, i) => (i % 2 === 0 ? "5" : "4")), (i) => (i % 2 === 0 ? "done" : "compare")), chips("choices", [`even 5`, `odd 4`], "dim")],
            counters: [count("even positions", evens), count("odd positions", odds)],
            legend: LEG,
            happened: "Even digits are 0,2,4,6,8; prime digits are 2,3,5,7.",
            why: "Each position is independent, so the counts multiply.",
            codeLine: 12,
          });
          const fastPower = (base, exp) => {
            let result = 1, b = base % MOD, e = exp, rounds = 0;
            const trace = [];
            while (e > 0) {
              if (e % 2 === 1) {
                result = (result * b) % MOD;
                trace.push(`${e} is odd → result × ${b} → ${result}`);
              } else {
                trace.push(`${e} is even → nothing to multiply`);
              }
              b = (b * b) % MOD;
              e = Math.floor(e / 2);
              rounds++;
              if (rounds >= 12) break;
            }
            return { result, rounds, trace };
          };
          const p5 = fastPower(5, evens);
          const p4 = fastPower(4, odds);
          steps.push({
            title: `Compute 5^${evens} and 4^${odds} by repeated squaring`,
            tracks: [chips("5 power trace", p5.trace.length ? p5.trace : ["exponent 0"], "active"), chips("4 power trace", p4.trace.length ? p4.trace : ["exponent 0"], "active")],
            counters: [count("5^even", p5.result), count("4^odd", p4.result)],
            legend: LEG,
            happened: `Squaring halves the exponent each round, so only ${Math.max(p5.rounds, p4.rounds)} rounds are needed.`,
            why: "Each bit of the exponent is processed once.",
            codeLine: 6,
          });
          const answer = (p5.result * p4.result) % MOD;
          steps.push({
            title: `Answer: ${answer}`,
            tracks: [chips("5^even", [p5.result], "done"), chips("4^odd", [p4.result], "done"), chips("answer", [answer], "result")],
            counters: [count("positions", n), count("answer", answer)],
            legend: LEG,
            happened: `${p5.result} × ${p4.result} mod ${MOD} = ${answer}.`,
            why: "The choices at each position are independent, so multiplication counts all strings.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "beautiful-array",
    title: "Beautiful Array",
    category: "Divide & Conquer",
    difficulty: "Advanced",
    description:
      "Arrange 1..n so no two values average to a third value in the array, by separating odd and even parts.",
    input: { label: "n", default: "5", parse: "int" },
    approaches: [
      {
        name: "Odds and Evens Recursively",
        complexity: "O(n log n) time",
        idea: [
          "A beautiful array stays beautiful after doubling and subtracting one.",
          "Build the answer for n by taking the beautiful array of the odd part, mapping it to odd numbers, then the even part mapped to even numbers.",
        ],
        problem: [
          "The odd and even pieces must be built for ⌈n/2⌉ and ⌊n/2⌋ separately; reusing the same n is incorrect.",
        ],
        code: {
          c: `#include <stdio.h>

void build(int n, int *out, int *size) {
    if (n == 1) { out[0] = 1; *size = 1; return; }

    int left[64], right[64], ln, rn;
    build((n + 1) / 2, left, &ln);
    build(n / 2, right, &rn);

    int k = 0;
    for (int i = 0; i < ln; i++) out[k++] = 2 * left[i] - 1;   /* odds */
    for (int i = 0; i < rn; i++) out[k++] = 2 * right[i];      /* evens */
    *size = k;
}

int main(void) {
    int out[64], size;
    build(5, out, &size);
    for (int i = 0; i < size; i++) printf("%d ", out[i]);
    printf("\\n"); /* 1 5 3 2 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

vector<int> beautiful(int n) {
    if (n == 1) return {1};

    vector<int> odds = beautiful((n + 1) / 2);
    vector<int> evens = beautiful(n / 2);

    vector<int> out;
    for (int v : odds) out.push_back(2 * v - 1);
    for (int v : evens) out.push_back(2 * v);
    return out;
}

int main() {
    for (int v : beautiful(5)) cout << v << ' '; // 1 5 3 2 4
    cout << '\\n';
}`,
        },
        steps(nRaw) {
          const n = Math.max(1, Math.min(14, parseInt(nRaw, 10) || 1));
          const steps = [];
          steps.push({
            title: `Build an arrangement of 1..${n}`,
            tracks: [chips("target", Array.from({ length: n }, (_, i) => i + 1), "idle")],
            counters: [count("n", n), count("built", 0)],
            legend: LEG,
            happened: "No value may sit exactly halfway between two others.",
            why: "Separating odd and even values prevents a mixed-parity midpoint.",
            codeLine: 4,
          });
          const build = (m) => {
            if (m === 1) return [1];
            const odds = build(Math.ceil(m / 2));
            const evens = build(Math.floor(m / 2));
            const mappedOdds = odds.map((v) => 2 * v - 1);
            const mappedEvens = evens.map((v) => 2 * v);
            steps.push({
              title: `n=${m}: odds ${show(mappedOdds)} then evens ${show(mappedEvens)}`,
              tracks: [
                chips(`odds from ${Math.ceil(m / 2)}`, mappedOdds, "done"),
                chips(`evens from ${Math.floor(m / 2)}`, mappedEvens, "compare"),
                chips("combined", mappedOdds.concat(mappedEvens), "result"),
              ],
              counters: [count("n", m), count("length", m)],
              legend: LEG,
              happened: `Doubling and shifting preserves the no-average property.`,
              why: "The average of an odd and an even is not an integer, and equal-parity midpoints are excluded recursively.",
              codeLine: 9,
            });
            return mappedOdds.concat(mappedEvens);
          };
          const answer = build(n);
          steps.push({
            title: `Answer: ${show(answer)}`,
            tracks: [chips("arrangement", answer, "result")],
            counters: [count("n", n), count("answer", show(answer))],
            legend: LEG,
            happened: `Every value 1..${n} appears exactly once.`,
            why: "The two recursive halves partition the value range by parity.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "construct-quad-tree",
    title: "Construct Quad Tree",
    category: "Divide & Conquer",
    difficulty: "Advanced",
    description:
      "Compress a binary matrix into a quad tree by splitting regions only when they are not uniform.",
    input: {
      label: "rows of 0/1 separated by |",
      default: "0,1 | 1,0",
      parse: "string",
    },
    approaches: [
      {
        name: "Split Non-Uniform Regions",
        complexity: "O(n² log n) worst case",
        idea: [
          "For a square region, check whether every cell has the same bit. If so, the region becomes one leaf whose value is that bit.",
          "Otherwise split the region into four quadrants and recurse, marking the node as internal.",
        ],
        problem: [
          "Checking uniformity at every level rescans cells multiple times, giving extra logarithmic work.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Quad {
    int isLeaf, value;
    struct Quad *topLeft, *topRight, *bottomLeft, *bottomRight;
} Quad;

int same(int m[8][8], int r0, int c0, int size) {
    for (int r = r0; r < r0 + size; r++)
        for (int c = c0; c < c0 + size; c++)
            if (m[r][c] != m[r0][c0]) return 0;
    return 1;
}

Quad *build(int m[8][8], int r0, int c0, int size) {
    Quad *node = calloc(1, sizeof(Quad));
    if (same(m, r0, c0, size)) {
        node->isLeaf = 1;
        node->value = m[r0][c0];
        return node;
    }
    int half = size / 2;
    node->topLeft = build(m, r0, c0, half);
    node->topRight = build(m, r0, c0 + half, half);
    node->bottomLeft = build(m, r0 + half, c0, half);
    node->bottomRight = build(m, r0 + half, c0 + half, half);
    return node;
}

int main(void) { return 0; }`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

struct Node {
    bool val, isLeaf;
    Node *topLeft, *topRight, *bottomLeft, *bottomRight;
    Node(bool v, bool leaf) : val(v), isLeaf(leaf),
        topLeft(nullptr), topRight(nullptr), bottomLeft(nullptr), bottomRight(nullptr) {}
};

Node* build(vector<vector<int>>& g, int r0, int c0, int size) {
    bool uniform = true;
    for (int r = r0; r < r0 + size && uniform; r++)
        for (int c = c0; c < c0 + size; c++)
            if (g[r][c] != g[r0][c0]) { uniform = false; break; }

    if (uniform) return new Node(g[r0][c0], true);

    int half = size / 2;
    Node* node = new Node(true, false);
    node->topLeft = build(g, r0, c0, half);
    node->topRight = build(g, r0, c0 + half, half);
    node->bottomLeft = build(g, r0 + half, c0, half);
    node->bottomRight = build(g, r0 + half, c0 + half, half);
    return node;
}

int main() {
    vector<vector<int>> g{{0,1},{1,0}};
    build(g, 0, 0, 2);
}`,
        },
        steps(text) {
          const rows = parts(text).map((r) => r.split(/[\s,]+/).filter((c) => c.length).map(Number)).filter((r) => r.length);
          if (!rows.length) {
            return [{
              title: "Give a square binary matrix",
              tracks: [chips("matrix", ["—"], "idle")],
              counters: [count("nodes", 0)],
              legend: ["idle", "result"],
              happened: "Rows are separated by | and cells by commas.",
              why: "A quad tree splits squares into four equal quadrants.",
            }];
          }
          const limit = Math.min(8, rows.length, Math.max(...rows.map((r) => r.length)));
          let n = 1;
          while (n * 2 <= limit) n *= 2;
          const g = Array.from({ length: n }, (_, r) => Array.from({ length: n }, (_, c) => (rows[r] && rows[r][c]) ? 1 : 0));
          const steps = [];
          steps.push({
            title: `${n}×${n} matrix; test the whole square first`,
            kind: "grid", rows: n, cols: n,
            cells: grid(n, n, (r, c) => ({ v: g[r][c], state: "read" })),
            counters: [count("regions", 1), count("leaves", 0)],
            legend: LEG,
            happened: "A uniform square needs no splitting.",
            why: "Splitting only non-uniform regions is what compresses the tree.",
            codeLine: 9,
          });
          let leaves = 0, internals = 0;
          const build = (r0, c0, size) => {
            let uniform = true;
            for (let r = r0; r < r0 + size && uniform; r++)
              for (let c = c0; c < c0 + size; c++) if (g[r][c] !== g[r0][c0]) { uniform = false; break; }
            if (uniform) {
              leaves++;
              steps.push({
                title: `Leaf ${g[r0][c0]} for rows ${r0}..${r0 + size - 1}, cols ${c0}..${c0 + size - 1}`,
                kind: "grid", rows: n, cols: n,
                cells: grid(n, n, (r, c) => {
                  const inside = r >= r0 && r < r0 + size && c >= c0 && c < c0 + size;
                  if (inside) return { v: g[r][c], state: "result" };
                  return { v: g[r][c], state: "dim" };
                }),
                counters: [count("leaves", leaves), count("region size", size)],
                legend: LEG,
                happened: `All ${size * size} cells agree on ${g[r0][c0]}.`,
                why: "A uniform region becomes one node instead of four subtrees.",
                codeLine: 11,
              });
              return;
            }
            internals++;
            const half = Math.max(1, size / 2);
            steps.push({
              title: `Split rows ${r0}..${r0 + size - 1}, cols ${c0}..${c0 + size - 1} into four`,
              kind: "grid", rows: n, cols: n,
              cells: grid(n, n, (r, c) => {
                const inside = r >= r0 && r < r0 + size && c >= c0 && c < c0 + size;
                if (!inside) return { v: g[r][c], state: "dim" };
                const quad = (r < r0 + half ? 0 : 2) + (c < c0 + half ? 0 : 1);
                return { v: g[r][c], state: ["active", "compare", "read", "swap"][quad] };
              }),
              counters: [count("internal nodes", internals), count("region size", size)],
              legend: LEG,
              happened: "The region has mixed values, so each quadrant must be examined.",
              why: "Every child covers exactly one quarter of the square.",
              codeLine: 14,
            });
            if (size <= 1) return;
            build(r0, c0, half);
            build(r0, c0 + half, half);
            build(r0 + half, c0, half);
            build(r0 + half, c0 + half, half);
          };
          build(0, 0, n);
          steps.push({
            title: `Answer: ${leaves} leaf node${leaves === 1 ? "" : "s"}, ${internals} internal`,
            tracks: [chips("leaves", [leaves], "result"), chips("internal", [internals], "done")],
            counters: [count("leaves", leaves), count("internal nodes", internals)],
            legend: LEG,
            happened: `The ${n}×${n} grid compressed to ${leaves + internals} nodes.`,
            why: "Quadrants that are uniform stop the recursion early.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });
})();
