/* ============================================================
   DSA Visuals — Monotonic Stack
   One stack shape solves neighbours, spans and rectangles.
   Each state shows the stack as it actually stands.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const nums = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number);
  const show = (a) => `[${a.join(", ")}]`;

  /* Shared histogram engine: returns steps for the largest rectangle. */
  function histogramSteps(heights, extra) {
    const steps = [];
    const n = heights.length;
    const stack = [];
    let best = 0, bestRange = null;
    const areaAt = (i) => heights[i] * (i - (stack.length ? stack[stack.length - 1] : -1));

    steps.push({
      title: "Heights with an empty stack",
      tracks: [track("heights", heights, fill(n, "idle")), chips("stack (indices)", ["—"], "dim")],
      counters: [count("bars", n), count("best area", 0)],
      legend: LEG,
      happened: "The stack keeps indices with increasing heights.",
      why: "A shorter bar blocks every taller bar behind it, so those can be settled.",
      codeLine: extra.codeLine || 5,
    });

    for (let i = 0; i <= n; i++) {
      const h = i === n ? 0 : heights[i];
      let settled = 0;
      while (stack.length && heights[stack[stack.length - 1]] >= h) {
        const top = stack.pop();
        const left = stack.length ? stack[stack.length - 1] : -1;
        const area = heights[top] * (i - left - 1);
        if (area > best) { best = area; bestRange = [left + 1, i - 1, heights[top]]; }
        settled++;
        steps.push({
          title: i === n
            ? `Sentinel 0 settles bar ${top} (height ${heights[top]}, area ${area})`
            : `Bar ${i} (${h}) is shorter, so bar ${top} settles: ${heights[top]} × ${i - left - 1} = ${area}`,
          tracks: [
            track("heights", heights, heights.map((_, j) => (j === top ? "result" : j === i ? "read" : stack.includes(j) ? "active" : j < top ? "dim" : "idle"))),
            chips("stack (indices)", stack.length ? stack : ["—"], (j) => (j === stack.length - 1 ? "active" : "dim")),
          ],
          counters: [count("bar", top), count("area", area), count("best area", best)],
          legend: LEG,
          happened: `The popped bar can only extend to index ${i - 1}, giving width ${i - left - 1}.`,
          why: "A bar's widest rectangle stops at the first shorter bar on each side.",
          codeLine: extra.settleLine || 8,
        });
      }
      if (i < n) {
        stack.push(i);
        steps.push({
          title: `Push bar ${i} (${h}); stack heights ${stack.map((x) => heights[x]).join(" ≤ ")}`,
          tracks: [
            track("heights", heights, heights.map((_, j) => (j === i ? "read" : stack.includes(j) ? "active" : "idle"))),
            chips("stack (indices)", stack, (j) => (j === stack.length - 1 ? "read" : "dim")),
          ],
          counters: [count("bar", i), count("stack size", stack.length), count("best area", best)],
          legend: LEG,
          happened: settled ? `${settled} taller bar${settled === 1 ? " was" : "s were"} settled before this push.` : "The new bar is not shorter than the stack top, so it simply joins.",
          why: "Only increasing heights stay useful for future rectangles.",
          codeLine: extra.pushLine || 9,
        });
      }
    }

    steps.push({
      title: `Answer: ${best}${bestRange ? ` (bars ${bestRange[0]}..${bestRange[1]} at height ${bestRange[2]})` : ""}`,
      tracks: [
        track("heights", heights, heights.map((_, j) => (bestRange && j >= bestRange[0] && j <= bestRange[1] ? "result" : "dim"))),
        chips("answer", [best], "result"),
      ],
      counters: [count("best area", best), count("answer", best)],
      legend: LEG,
      happened: bestRange ? `The widest rectangle uses ${bestRange[1] - bestRange[0] + 1} bars.` : "No bar produced a positive area.",
      why: "Every bar was popped exactly once, so the scan is linear.",
      codeLine: extra.answerLine || 12,
    });
    return steps;
  }

  /* ---------------------------------------------------------- */
  V.register({
    id: "simplify-path",
    title: "Simplify Path",
    category: "Monotonic Stack",
    difficulty: "Intermediate",
    description:
      "Collapse a Unix path by handling '.', '..' and repeated slashes with a stack of directory names.",
    input: { label: "path", default: "/a/./b/../../c/", parse: "string" },
    approaches: [
      {
        name: "Stack of Directory Names",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Split the path on slashes and ignore empty pieces and single dots.",
          "A double dot pops the previous directory; any other name is pushed. The stack is the canonical path.",
        ],
        problem: [
          "Popping an empty stack must be ignored, since '..' at the root stays at the root.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

int main(void) {
    const char *path = "/a/./b/../../c/";
    const char *stack[64];
    int top = 0;

    char buffer[256];
    strcpy(buffer, path);
    char *token = strtok(buffer, "/");

    while (token) {
        if (strcmp(token, ".") == 0) {
            /* ignore */
        } else if (strcmp(token, "..") == 0) {
            if (top > 0) top--;
        } else {
            stack[top++] = token;
        }
        token = strtok(NULL, "/");
    }

    if (top == 0) printf("/");
    for (int i = 0; i < top; i++) printf("/%s", stack[i]);
    printf("\\n"); /* /c */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
#include <sstream>
using namespace std;

string simplifyPath(const string& path) {
    vector<string> parts;
    stringstream ss(path);
    string token;

    while (getline(ss, token, '/')) {
        if (token.empty() || token == ".") continue;
        if (token == "..") { if (!parts.empty()) parts.pop_back(); }
        else parts.push_back(token);
    }

    string out;
    for (const string& p : parts) out += "/" + p;
    return out.empty() ? "/" : out;
}

int main() {
    cout << simplifyPath("/a/./b/../../c/") << '\\n'; // /c
}`,
        },
        steps(text) {
          const raw = String(text || "");
          const tokens = raw.split("/").filter((t) => t.length);
          const steps = [];
          const stack = [];
          steps.push({
            title: `Split "${raw}" into ${tokens.length} pieces`,
            tracks: [chips("pieces", tokens.length ? tokens : ["—"], "dim"), chips("stack", ["—"], "idle")],
            counters: [count("pieces", tokens.length), count("stack size", 0)],
            legend: LEG,
            happened: "Empty pieces from repeated slashes never enter the stack.",
            why: "The stack rebuilds the path one canonical component at a time.",
            codeLine: 4,
          });
          for (const t of tokens) {
            let action = "";
            if (t === ".") {
              action = "current directory, ignore it";
            } else if (t === "..") {
              if (stack.length) {
                const gone = stack.pop();
                action = `go up, pop "${gone}"`;
              } else {
                action = "already at the root, stay put";
              }
            } else {
              stack.push(t);
              action = `enter "${t}"`;
            }
            steps.push({
              title: `"${t}" → ${action}`,
              tracks: [
                chips("pieces", tokens, (i) => (tokens[i] === t && tokens.indexOf(t) === i ? "read" : "dim")),
                chips("stack", stack.length ? stack : ["—"], (i) => (i === stack.length - 1 ? "active" : "done")),
              ],
              counters: [count("stack size", stack.length), count("pieces seen", tokens.indexOf(t) + 1, tokens.length)],
              legend: LEG,
              happened: action,
              why: "A double dot always removes exactly one previous component.",
              codeLine: t === ".." ? 11 : t === "." ? 8 : 13,
            });
          }
          const answer = "/" + stack.join("/");
          steps.push({
            title: `Answer: ${answer}`,
            tracks: [chips("answer", [answer], "result"), chips("stack", stack.length ? stack : ["root"], "result")],
            counters: [count("components", stack.length), count("answer", answer)],
            legend: LEG,
            happened: stack.length ? `The canonical path is ${answer}.` : "The canonical path is the root.",
            why: "The stack content read from bottom to top is already the simplified path.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "daily-temperatures",
    title: "Daily Temperatures",
    category: "Monotonic Stack",
    difficulty: "Intermediate",
    description:
      "For each day, find how many days until a warmer temperature using a decreasing stack of days.",
    input: { label: "temperatures", default: "73,74,75,71,69,72,76,73", parse: "ints" },
    approaches: [
      {
        name: "Decreasing Stack of Indices",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Keep a stack of days whose warmer day is still unknown, with temperatures decreasing from bottom to top.",
          "When today is warmer than the top day, that day's answer is today minus its index; keep popping while today is warmer.",
        ],
        problem: [
          "Storing temperatures instead of indices loses the distance information needed for the answer.",
        ],
        code: {
          c: `#include <stdio.h>

int main(void) {
    int t[] = {73, 74, 75, 71, 69, 72, 76, 73};
    int n = 8, stack[64], top = 0;
    int answer[64] = {0};

    for (int i = 0; i < n; i++) {
        while (top > 0 && t[i] > t[stack[top - 1]]) {
            int day = stack[--top];
            answer[day] = i - day;
        }
        stack[top++] = i;
    }

    for (int i = 0; i < n; i++) printf("%d ", answer[i]);
    printf("\\n"); /* 1 1 4 2 1 1 0 0 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

vector<int> dailyTemperatures(const vector<int>& t) {
    int n = t.size();
    vector<int> answer(n, 0);
    vector<int> stack;

    for (int i = 0; i < n; i++) {
        while (!stack.empty() && t[i] > t[stack.back()]) {
            int day = stack.back();
            stack.pop_back();
            answer[day] = i - day;
        }
        stack.push_back(i);
    }
    return answer;
}

int main() {
    for (int d : dailyTemperatures({73,74,75,71,69,72,76,73})) cout << d << ' '; // 1 1 4 2 1 1 0 0
    cout << '\\n';
}`,
        },
        steps(values) {
          const t = values.slice();
          const n = t.length;
          if (!n) {
            return [{
              title: "Give some temperatures",
              tracks: [chips("days", ["—"], "idle")],
              counters: [count("days", 0)],
              legend: ["idle", "result"],
              happened: "There are no days to wait.",
              why: "The stack stores days that still need a warmer day.",
            }];
          }
          const steps = [];
          const stack = [];
          const answer = Array(n).fill(0);
          steps.push({
            title: `${n} days; the stack will hold waiting days`,
            tracks: [track("temperatures", t, fill(n, "idle")), chips("waiting days", ["—"], "dim")],
            counters: [count("days", n), count("answered", 0)],
            legend: LEG,
            happened: "Temperatures decrease from the bottom of the stack to the top.",
            why: "A colder day is settled as soon as a warmer one appears.",
            codeLine: 4,
          });
          for (let i = 0; i < n; i++) {
            const popped = [];
            while (stack.length && t[i] > t[stack[stack.length - 1]]) {
              const day = stack.pop();
              answer[day] = i - day;
              popped.push(day);
            }
            stack.push(i);
            steps.push({
              title: popped.length
                ? `Day ${i} (${t[i]}) settles ${popped.map((d) => `day ${d}`).join(", ")}`
                : `Day ${i} (${t[i]}) has no warmer day yet`,
              tracks: [
                track("temperatures", t, t.map((_, j) => (j === i ? "read" : stack.includes(j) ? "active" : j < i && answer[j] > 0 ? "done" : j < i ? "dim" : "idle"))),
                chips("waiting days", stack.length ? stack : ["—"], (j) => (j === stack.length - 1 ? "read" : "dim")),
                chips("answers", answer.map((a) => (a || "·")), "dim"),
              ],
              counters: [count("day", i, n), count("answered", answer.filter((a) => a > 0).length)],
              legend: LEG,
              happened: popped.length ? `${popped.length} waiting day${popped.length === 1 ? " got" : "s got"} their distance.` : "Today joins the waiting stack.",
              why: "Each day is pushed once and popped once, so the scan is linear.",
              codeLine: popped.length ? 6 : 9,
            });
          }
          steps.push({
            title: `Answer: ${show(answer)}`,
            tracks: [chips("answers", answer, (i) => (answer[i] === 0 ? "bad" : "result"))],
            counters: [count("answered", answer.filter((a) => a > 0).length), count("unanswered", answer.filter((a) => a === 0).length)],
            legend: LEG,
            happened: `${answer.filter((a) => a === 0).length} day${answer.filter((a) => a === 0).length === 1 ? " has" : "s have"} no warmer day ahead.`,
            why: "Leftover stack entries simply keep their default zero.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "next-greater-element",
    title: "Next Greater Element",
    category: "Monotonic Stack",
    difficulty: "Intermediate",
    description:
      "For every value, find the next value to its right that is larger, using a decreasing stack.",
    input: { label: "numbers", default: "2,1,2,4,3", parse: "ints" },
    approaches: [
      {
        name: "Right-to-Left Decreasing Stack",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Scan from right to left. The stack holds candidates in increasing distance, with values increasing toward the top.",
          "Pop every value not greater than the current one; the new top, if any, is the next greater element.",
        ],
        problem: [
          "The stack stores values rather than indices, which is fine for values but would not give distances.",
        ],
        code: {
          c: `#include <stdio.h>

int main(void) {
    int a[] = {2, 1, 2, 4, 3};
    int n = 5, stack[64], top = 0, answer[64];

    for (int i = n - 1; i >= 0; i--) {
        while (top > 0 && stack[top - 1] <= a[i]) top--;
        answer[i] = top > 0 ? stack[top - 1] : -1;
        stack[top++] = a[i];
    }

    for (int i = 0; i < n; i++) printf("%d ", answer[i]);
    printf("\\n"); /* 4 2 4 -1 -1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

vector<int> nextGreater(const vector<int>& a) {
    vector<int> answer(a.size(), -1), stack;

    for (int i = a.size() - 1; i >= 0; i--) {
        while (!stack.empty() && stack.back() <= a[i]) stack.pop_back();
        answer[i] = stack.empty() ? -1 : stack.back();
        stack.push_back(a[i]);
    }
    return answer;
}

int main() {
    for (int v : nextGreater({2,1,2,4,3})) cout << v << ' '; // 4 2 4 -1 -1
    cout << '\\n';
}`,
        },
        steps(values) {
          const a = values.slice();
          const n = a.length;
          if (!n) {
            return [{
              title: "Give some numbers",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("values", 0)],
              legend: ["idle", "result"],
              happened: "There is nothing to compare.",
              why: "A next greater value needs a value to its right.",
            }];
          }
          const steps = [];
          const stack = [];
          const answer = Array(n).fill(-1);
          steps.push({
            title: `Scan from the right; stack values increase toward the top`,
            tracks: [track("numbers", a, fill(n, "idle")), chips("stack (values)", ["—"], "dim")],
            counters: [count("position", n - 1), count("answered", 0)],
            legend: LEG,
            happened: "Current values are checked by value, not by index.",
            why: "Anything smaller than the current value can never be a next greater for positions further left.",
            codeLine: 4,
          });
          for (let i = n - 1; i >= 0; i--) {
            const popped = [];
            while (stack.length && stack[stack.length - 1] <= a[i]) popped.push(stack.pop());
            answer[i] = stack.length ? stack[stack.length - 1] : -1;
            stack.push(a[i]);
            steps.push({
              title: `Index ${i} (${a[i]}) → next greater ${answer[i] === -1 ? "none" : answer[i]}`,
              tracks: [
                track("numbers", a, a.map((_, j) => (j === i ? "read" : j > i ? "done" : "idle"))),
                chips("stack (values)", stack, (j) => (j === stack.length - 1 ? "result" : "dim")),
                chips("answers", answer.map((v) => (v === -1 ? "·" : v)), (j) => (j === i ? "active" : "dim")),
              ],
              counters: [count("position", i), count("answered", answer.filter((v, j) => j >= i && v !== -1).length)],
              legend: LEG,
              happened: popped.length
                ? `${popped.length} smaller candidate${popped.length === 1 ? " was" : "s were"} discarded before choosing the top.`
                : "The stack top is already greater than the current value.",
              why: "The nearest greater value is always the first surviving candidate on the stack.",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Answer: ${show(answer)}`,
            tracks: [track("numbers", a, fill(n, "done")), chips("answers", answer, (i) => (answer[i] === -1 ? "bad" : "result"))],
            counters: [count("with answer", answer.filter((v) => v !== -1).length), count("none", answer.filter((v) => v === -1).length)],
            legend: LEG,
            happened: `${answer.filter((v) => v === -1).length} position${answer.filter((v) => v === -1).length === 1 ? " has" : "s have"} no greater value to the right.`,
            why: "Each value entered and left the stack at most once.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "stock-span",
    title: "Stock Span",
    category: "Monotonic Stack",
    difficulty: "Intermediate",
    description:
      "Compute how many consecutive previous days had a price no higher than today's.",
    input: { label: "prices", default: "100,80,60,70,60,75,85", parse: "ints" },
    approaches: [
      {
        name: "Stack of Undefeated Days",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Keep a decreasing stack of days. Today's span extends back over every day whose price it reaches or exceeds.",
          "Pop those days and add their spans; the accumulated total is today's span.",
        ],
        problem: [
          "The span must include consecutive days, so storing only prices is not enough; indices or accumulated spans are required.",
        ],
        code: {
          c: `#include <stdio.h>

int main(void) {
    int price[] = {100, 80, 60, 70, 60, 75, 85};
    int n = 7, stack[64], top = 0, span[64];

    for (int i = 0; i < n; i++) {
        while (top > 0 && price[stack[top - 1]] <= price[i]) top--;
        span[i] = top > 0 ? i - stack[top - 1] : i + 1;
        stack[top++] = i;
    }

    for (int i = 0; i < n; i++) printf("%d ", span[i]);
    printf("\\n"); /* 1 1 1 2 1 4 6 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

vector<int> stockSpan(const vector<int>& price) {
    vector<int> span(price.size()), stack;

    for (int i = 0; i < (int)price.size(); i++) {
        while (!stack.empty() && price[stack.back()] <= price[i]) stack.pop_back();
        span[i] = stack.empty() ? i + 1 : i - stack.back();
        stack.push_back(i);
    }
    return span;
}

int main() {
    for (int s : stockSpan({100,80,60,70,60,75,85})) cout << s << ' '; // 1 1 1 2 1 4 6
    cout << '\\n';
}`,
        },
        steps(values) {
          const price = values.slice();
          const n = price.length;
          if (!n) {
            return [{
              title: "Give some prices",
              tracks: [chips("prices", ["—"], "idle")],
              counters: [count("days", 0)],
              legend: ["idle", "result"],
              happened: "There are no days to span.",
              why: "A span counts consecutive earlier days.",
            }];
          }
          const steps = [];
          const stack = [];
          const span = Array(n).fill(1);
          steps.push({
            title: `${n} prices; the stack holds days with decreasing prices`,
            tracks: [track("prices", price, fill(n, "idle")), chips("stack (days)", ["—"], "dim")],
            counters: [count("days", n), count("span", 1)],
            legend: LEG,
            happened: "Today's span reaches back until a strictly higher price blocks it.",
            why: "A higher earlier price caps the consecutive run.",
            codeLine: 4,
          });
          for (let i = 0; i < n; i++) {
            const popped = [];
            while (stack.length && price[stack[stack.length - 1]] <= price[i]) popped.push(stack.pop());
            span[i] = stack.length ? i - stack[stack.length - 1] : i + 1;
            stack.push(i);
            steps.push({
              title: `Day ${i} (${price[i]}): span ${span[i]}`,
              tracks: [
                track("prices", price, price.map((_, j) => (j === i ? "read" : stack.includes(j) ? "active" : j < i ? "dim" : "idle"))),
                chips("stack (days)", stack, (j) => (j === stack.length - 1 ? "active" : "dim")),
                chips("spans", span.map((v, j) => (j <= i ? v : "·")), (j) => (j === i ? "result" : "dim")),
              ],
              counters: [count("day", i, n), count("span", span[i])],
              legend: LEG,
              happened: popped.length
                ? `${popped.length} earlier day${popped.length === 1 ? " was" : "s were"} absorbed by a price at least as high.`
                : "The previous day is already higher, so the span stops at one.",
              why: "Popped days can never limit a later span because today's price dominates them.",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Answer: ${show(span)}`,
            tracks: [chips("spans", span, "result")],
            counters: [count("days", n), count("max span", Math.max(...span))],
            legend: LEG,
            happened: `The largest span is ${Math.max(...span)} days.`,
            why: "Every day is pushed and popped at most once.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "largest-rectangle-in-histogram",
    title: "Largest Rectangle in Histogram",
    category: "Monotonic Stack",
    difficulty: "Advanced",
    description:
      "Find the largest rectangle inside a row of bars using a stack of increasing heights.",
    input: { label: "bar heights", default: "2,1,5,6,2,3", parse: "ints" },
    approaches: [
      {
        name: "Increasing Stack With a Sentinel",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Keep bars in increasing height order. When a shorter bar arrives, the taller bars can no longer extend right.",
          "Pop each taller bar, compute width up to the new shorter bar, and track the best area. A zero-height sentinel at the end flushes the stack.",
        ],
        problem: [
          "Without the sentinel, bars still on the stack at the end would never be evaluated.",
        ],
        code: {
          c: `#include <stdio.h>

int largest_rectangle(int *h, int n) {
    int stack[256], top = 0, best = 0;

    for (int i = 0; i <= n; i++) {
        int height = i == n ? 0 : h[i];
        while (top > 0 && h[stack[top - 1]] >= height) {
            int bar = stack[--top];
            int left = top > 0 ? stack[top - 1] : -1;
            int area = h[bar] * (i - left - 1);
            if (area > best) best = area;
        }
        stack[top++] = i;
    }
    return best;
}

int main(void) {
    int h[] = {2, 1, 5, 6, 2, 3};
    printf("%d\\n", largest_rectangle(h, 6)); /* 10 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int largestRectangleArea(const vector<int>& h) {
    vector<int> stack;
    int best = 0, n = h.size();

    for (int i = 0; i <= n; i++) {
        int height = i == n ? 0 : h[i];
        while (!stack.empty() && h[stack.back()] >= height) {
            int bar = stack.back(); stack.pop_back();
            int left = stack.empty() ? -1 : stack.back();
            best = max(best, h[bar] * (i - left - 1));
        }
        stack.push_back(i);
    }
    return best;
}

int main() {
    cout << largestRectangleArea({2,1,5,6,2,3}) << '\\n'; // 10
}`,
        },
        steps(values) {
          const h = values.slice();
          if (!h.length) {
            return [{
              title: "Give some bar heights",
              tracks: [chips("heights", ["—"], "idle")],
              counters: [count("bars", 0)],
              legend: ["idle", "result"],
              happened: "There are no bars to form a rectangle.",
              why: "Every rectangle is limited by its shortest bar.",
            }];
          }
          return histogramSteps(h, {
            codeLine: 4,
            pushLine: 10,
            settleLine: 6,
            answerLine: 14,
          });
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximal-rectangle",
    title: "Maximal Rectangle",
    category: "Monotonic Stack",
    difficulty: "Advanced",
    description:
      "Treat each matrix row as the base of a histogram of consecutive ones and reuse the histogram solver.",
    input: {
      label: "rows of 0/1 separated by |",
      default: "1,0,1,0,0 | 1,0,1,1,1 | 1,1,1,1,1 | 1,0,0,1,0",
      parse: "string",
    },
    approaches: [
      {
        name: "Row Histograms",
        complexity: "O(rows × cols) time, O(cols) space",
        idea: [
          "For each column track how many consecutive ones end at the current row, forming a histogram.",
          "Run the largest-rectangle-in-histogram scan on every row and keep the best area.",
        ],
        problem: [
          "A zero resets the column height, so the histogram must be updated before the scan, not after.",
        ],
        code: {
          c: `#include <stdio.h>

int hist_area(int *h, int cols) {
    int stack[256], top = 0, best = 0;
    for (int i = 0; i <= cols; i++) {
        int height = i == cols ? 0 : h[i];
        while (top > 0 && h[stack[top - 1]] >= height) {
            int bar = stack[--top];
            int left = top > 0 ? stack[top - 1] : -1;
            int area = h[bar] * (i - left - 1);
            if (area > best) best = area;
        }
        stack[top++] = i;
    }
    return best;
}

int main(void) {
    int m[4][5] = {{1,0,1,0,0},{1,0,1,1,1},{1,1,1,1,1},{1,0,0,1,0}};
    int heights[5] = {0}, best = 0;

    for (int r = 0; r < 4; r++) {
        for (int c = 0; c < 5; c++)
            heights[c] = m[r][c] ? heights[c] + 1 : 0;
        int area = hist_area(heights, 5);
        if (area > best) best = area;
    }
    printf("%d\\n", best); /* 6 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int histogramArea(const vector<int>& h) {
    vector<int> stack;
    int best = 0;
    for (int i = 0; i <= (int)h.size(); i++) {
        int height = i == h.size() ? 0 : h[i];
        while (!stack.empty() && h[stack.back()] >= height) {
            int bar = stack.back(); stack.pop_back();
            int left = stack.empty() ? -1 : stack.back();
            best = max(best, h[bar] * (i - left - 1));
        }
        stack.push_back(i);
    }
    return best;
}

int maximalRectangle(vector<vector<char>> m) {
    if (m.empty()) return 0;
    int cols = m[0].size(), best = 0;
    vector<int> heights(cols, 0);

    for (auto& row : m) {
        for (int c = 0; c < cols; c++) heights[c] = row[c] == '1' ? heights[c] + 1 : 0;
        best = max(best, histogramArea(heights));
    }
    return best;
}

int main() {
    cout << maximalRectangle({{'1','0','1','0','0'},{'1','0','1','1','1'},{'1','1','1','1','1'},{'1','0','0','1','0'}}) << '\\n'; // 6
}`,
        },
        steps(text) {
          const rows = parts(text).map((r) => r.split(/[\s,]+/).filter((c) => c.length).map(Number)).filter((r) => r.length);
          if (!rows.length) {
            return [{
              title: "Give a matrix of 0s and 1s",
              tracks: [chips("matrix", ["—"], "idle")],
              counters: [count("rows", 0)],
              legend: ["idle", "result"],
              happened: "Rows are separated by | and cells by commas.",
              why: "Every row becomes a histogram of consecutive ones above it.",
            }];
          }
          const cols = Math.max(...rows.map((r) => r.length));
          const steps = [];
          const heights = Array(cols).fill(0);
          let best = 0;
          steps.push({
            title: `${rows.length} rows; start with a flat histogram`,
            tracks: [chips("column heights", heights, "dim")],
            counters: [count("rows", rows.length), count("best area", 0)],
            legend: LEG,
            happened: "Heights record consecutive ones ending at the current row.",
            why: "A rectangle spanning several rows is a rectangle in this histogram.",
            codeLine: 4,
          });
          rows.forEach((row, r) => {
            for (let c = 0; c < cols; c++) heights[c] = row[c] ? heights[c] + 1 : 0;
            const area = histogramSteps(heights, { codeLine: 14, pushLine: 9, settleLine: 7, answerLine: 18 });
            const rowBest = area[area.length - 1].counters[0].value;
            const numeric = Number(rowBest);
            if (Number.isFinite(numeric) && numeric > best) best = numeric;
            steps.push({
              title: `Row ${r}: heights ${show(heights)}`,
              tracks: [track("row", row, (c) => (row[c] ? "read" : "dim")), chips("column heights", heights, "active")],
              counters: [count("row", r + 1, rows.length), count("best area", best)],
              legend: LEG,
              happened: "Ones extend the column by one; zeros reset it to zero.",
              why: "The histogram now describes the best rectangle whose bottom edge is this row.",
              codeLine: 11,
            });
            steps.push(...area.slice(0, -1).map((s) => Object.assign({}, s, { title: `Row ${r}: ${s.title}` })));
          });
          steps.push({
            title: `Answer: ${best}`,
            tracks: [chips("column heights", heights, "dim"), chips("answer", [best], "result")],
            counters: [count("rows", rows.length), count("answer", best)],
            legend: LEG,
            happened: `The largest all-ones rectangle covers ${best} cells.`,
            why: "Every row's histogram was solved in linear time.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "remove-k-digits",
    title: "Remove K Digits",
    category: "Monotonic Stack",
    difficulty: "Advanced",
    description:
      "Delete k digits to leave the smallest possible number, by popping larger digits before smaller ones.",
    input: { label: "digits | k", default: "1432219 | 3", parse: "string" },
    approaches: [
      {
        name: "Greedy Increasing Stack",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Build the answer left to right. Whenever the previous digit is larger than the current one, removing that previous digit makes the number smaller.",
          "Pop up to k such digits, then trim any remaining removals from the end and strip leading zeros.",
        ],
        problem: [
          "If k is larger than the number of removable leading digits, the leftover removals must come off the end, not the front.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

int main(void) {
    char s[] = "1432219";
    int k = 3, top = 0;

    for (int i = 0; s[i]; i++) {
        while (top > 0 && k > 0 && s[top - 1] > s[i]) { top--; k--; }
        s[top++] = s[i];
    }
    top -= k;                       /* remove leftovers from the end */

    int start = 0;
    while (start < top && s[start] == '0') start++;
    if (start == top) printf("0");
    for (int i = start; i < top; i++) putchar(s[i]);
    printf("\\n"); /* 1219 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
using namespace std;

string removeKdigits(const string& num, int k) {
    string stack;

    for (char c : num) {
        while (!stack.empty() && k > 0 && stack.back() > c) {
            stack.pop_back();
            k--;
        }
        stack.push_back(c);
    }
    while (k-- > 0 && !stack.empty()) stack.pop_back();

    size_t start = stack.find_first_not_of('0');
    if (start == string::npos) return "0";
    return stack.substr(start);
}

int main() {
    cout << removeKdigits("1432219", 3) << '\\n'; // 1219
}`,
        },
        steps(text) {
          const [numRaw, kRaw] = parts(text);
          const digits = Array.from(String(numRaw || ""));
          let k = Math.max(0, parseInt(kRaw, 10) || 0);
          if (!digits.length) {
            return [{
              title: "Give a number and k",
              tracks: [chips("digits", ["—"], "idle")],
              counters: [count("k", k)],
              legend: ["idle", "result"],
              happened: "The left field holds the digits, the right field k.",
              why: "Removing a larger earlier digit lowers the number most.",
            }];
          }
          const steps = [];
          const stack = [];
          const removedTotal = k;
          steps.push({
            title: `Remove ${k} digit${k === 1 ? "" : "s"} from ${digits.join("")}`,
            tracks: [track("digits", digits, fill(digits.length, "idle")), chips("stack", ["—"], "dim")],
            counters: [count("removals left", k), count("stack size", 0)],
            legend: LEG,
            happened: "The stack will stay as small as possible from left to right.",
            why: "Dropping a larger digit before a smaller one always helps.",
            codeLine: 4,
          });
          for (let i = 0; i < digits.length; i++) {
            const popped = [];
            while (stack.length && k > 0 && stack[stack.length - 1] > digits[i]) {
              popped.push(stack.pop());
              k--;
            }
            stack.push(digits[i]);
            steps.push({
              title: popped.length ? `Digit ${digits[i]} replaces ${popped.join(", ")}` : `Push ${digits[i]}`,
              tracks: [
                track("digits", digits, digits.map((_, j) => (j === i ? "read" : j < i ? "done" : "dim"))),
                chips("stack", stack, (j) => (j === stack.length - 1 ? "active" : "dim")),
                chips("removed", popped.length ? popped : ["—"], popped.length ? "bad" : "dim"),
              ],
              counters: [count("removals left", k, removedTotal), count("stack size", stack.length)],
              legend: LEG,
              happened: popped.length ? `${popped.length} larger digit${popped.length === 1 ? " was" : "s were"} removed.` : "The digit keeps the stack non-decreasing.",
              why: "Each removal happens exactly when a smaller digit arrives.",
              codeLine: popped.length ? 5 : 7,
            });
          }
          while (k > 0 && stack.length) {
            const gone = stack.pop();
            k--;
            steps.push({
              title: `Still ${k} removal${k === 1 ? "" : "s"} left: drop ${gone} from the end`,
              tracks: [chips("stack", stack.length ? stack : ["—"], "dim"), chips("removed", [gone], "bad")],
              counters: [count("removals left", k, removedTotal), count("stack size", stack.length)],
              legend: LEG,
              happened: "The remaining digits are non-decreasing, so the end is the cheapest place to cut.",
              why: "Removing a later digit affects fewer significant positions.",
              codeLine: 9,
            });
          }
          let start = 0;
          while (start < stack.length && stack[start] === "0") start++;
          const answer = start === stack.length ? "0" : stack.slice(start).join("");
          steps.push({
            title: `Answer: ${answer}`,
            tracks: [chips("stack", stack.length ? stack : ["—"], "dim"), chips("answer", [answer], "result")],
            counters: [count("removed", removedTotal - k, removedTotal), count("answer", answer)],
            legend: LEG,
            happened: `Leading zeros are dropped, leaving ${answer}.`,
            why: "The greedy stack gives the smallest number for the removals spent.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });
})();
