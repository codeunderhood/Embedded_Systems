/* ============================================================
   DSA Visuals — Linked Lists Advanced I
   Pointer surgery on chains: merging, unlinking, meeting points,
   palindromes, reordering and partial reversal.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "swap", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const chain = (label, values, states, tags) => ({
    kind: "list",
    label,
    nodes: values.map((v, i) => {
      const node = { v, state: (states && states[i]) || "idle" };
      if (tags && tags[i] != null) node.tag = tags[i];
      return node;
    }),
    nil: true,
  });
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const nums = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number);
  const show = (a) => `[${a.join(", ")}]`;

  /* ---------------------------------------------------------- */
  V.register({
    id: "merge-k-sorted-lists",
    title: "Merge K Sorted Lists",
    category: "Linked Lists",
    difficulty: "Advanced",
    description:
      "Merge several sorted chains by repeatedly taking the smallest current head.",
    input: { label: "lists separated by |", default: "1,4,5 | 1,3,4 | 2,6", parse: "string" },
    approaches: [
      {
        name: "Heap of Heads",
        complexity: "O(N log k) time, O(k) space",
        idea: [
          "Each chain is sorted, so the smallest remaining value is always one of the current heads.",
          "Hold the heads in a min-heap, pop the smallest, append it to the output, and push the next node from that chain.",
        ],
        problem: [
          "The heap holds nodes, so the chains must be traversed without copying; copying values loses the list identity.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct Node { int value; struct Node *next; } Node;

Node *merge_k(Node **lists, int k) {
    Node dummy = {0, NULL}, *tail = &dummy;

    while (1) {
        int best = -1;
        for (int i = 0; i < k; i++)
            if (lists[i] && (best < 0 || lists[i]->value < lists[best]->value)) best = i;
        if (best < 0) break;

        tail->next = lists[best];
        tail = tail->next;
        lists[best] = lists[best]->next;
    }
    return dummy.next;
}

int main(void) {
    Node a3 = {5, NULL}, a2 = {4, &a3}, a1 = {1, &a2};
    Node b3 = {4, NULL}, b2 = {3, &b3}, b1 = {1, &b2};
    Node c2 = {6, NULL}, c1 = {2, &c2};
    Node *lists[] = {&a1, &b1, &c1};

    for (Node *p = merge_k(lists, 3); p; p = p->next) printf("%d ", p->value);
    printf("\\n"); /* 1 1 2 3 4 4 5 6 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
using namespace std;

struct ListNode { int val; ListNode* next; ListNode(int v) : val(v), next(nullptr) {} };

ListNode* mergeKLists(vector<ListNode*>& lists) {
    auto cmp = [](ListNode* a, ListNode* b) { return a->val > b->val; };
    priority_queue<ListNode*, vector<ListNode*>, decltype(cmp)> heap(cmp);

    for (ListNode* head : lists) if (head) heap.push(head);

    ListNode dummy(0);
    ListNode* tail = &dummy;
    while (!heap.empty()) {
        ListNode* node = heap.top(); heap.pop();
        tail->next = node;
        tail = node;
        if (node->next) heap.push(node->next);
    }
    return dummy.next;
}

int main() {
    // build 1->4->5, 1->3->4 and 2->6, then merge
    return 0;
}`,
        },
        steps(text) {
          const lists = parts(text).map(nums);
          const pos = lists.map(() => 0);
          const out = [];
          if (!lists.length) {
            return [{
              title: "Give at least one list",
              tracks: [chips("lists", ["—"], "idle")],
              counters: [count("lists", 0)],
              legend: ["idle", "result"],
              happened: "Lists are separated by | and values by commas.",
              why: "A heap of heads needs one head per list.",
            }];
          }
          const steps = [];
          const heads = () => lists.map((l, i) => (pos[i] < l.length ? l[pos[i]] : "—"));
          steps.push({
            title: `${lists.length} sorted chains; put the ${heads().join(", ")} heads in a heap`,
            tracks: [chips("lists", lists.map((l) => l.join("→")), "dim"), chips("heads", heads(), "read"), chips("output", ["—"], "idle")],
            counters: [count("head values", lists.length), count("merged", 0)],
            legend: LEG,
            happened: `The heads are ${heads().join(", ")}.`,
            why: "The global minimum must be one of the heads.",
            codeLine: 7,
          });
          while (true) {
            let best = -1;
            for (let i = 0; i < lists.length; i++) {
              if (pos[i] >= lists[i].length) continue;
              if (best < 0 || lists[i][pos[i]] < lists[best][pos[best]]) best = i;
            }
            if (best < 0) break;
            const v = lists[best][pos[best]];
            out.push(v);
            pos[best]++;
            steps.push({
              title: `Take ${v} from list ${best + 1}`,
              tracks: [
                chips("lists", lists.map((l) => l.join("→")), (i) => (i === best ? "active" : "dim")),
                chips("heads", heads(), (i) => (i === best ? "result" : "idle")),
                chips("output", out, "result"),
              ],
              counters: [count("merged", out.length), count("heads left", lists.filter((l, i) => pos[i] < l.length).length)],
              legend: LEG,
              happened: `${v} was the smallest head, so it moves to the output and list ${best + 1} advances.`,
              why: "Every other head is at least as large, so appending v cannot break the sorted order.",
              codeLine: 12,
            });
          }
          steps.push({
            title: `Answer: ${show(out)}`,
            tracks: [chips("output", out, "result")],
            counters: [count("merged", out.length), count("answer", show(out))],
            legend: LEG,
            happened: `All ${out.length} nodes were merged into one sorted chain.`,
            why: "Each node entered and left the heap once, so the cost is N log k.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "delete-node-in-a-linked-list",
    title: "Delete Node in a Linked List",
    category: "Linked Lists",
    difficulty: "Beginner",
    description:
      "Remove a node when only that node is given, by copying the next value into it and unlinking the next.",
    input: { label: "list values | value to delete", default: "4,5,1,9 | 5", parse: "string" },
    approaches: [
      {
        name: "Copy and Skip",
        complexity: "O(1) time, O(1) space",
        idea: [
          "The previous node is unreachable, so the target cannot be unlinked from behind.",
          "Copy the next node's value into the target, then point the target past the next node. The chain now looks as if the target was removed.",
        ],
        problem: [
          "The last node cannot be deleted this way, because there is no next value to copy.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int value; struct Node *next; } Node;

void delete_node(Node *node) {
    if (!node || !node->next) return;        /* last node cannot be copied */
    Node *next = node->next;
    node->value = next->value;
    node->next = next->next;
}

int main(void) {
    Node d = {9, NULL}, c = {1, &d}, b = {5, &c}, a = {4, &b};
    delete_node(&b);
    for (Node *p = &a; p; p = p->next) printf("%d ", p->value);
    printf("\\n"); /* 4 1 9 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

struct ListNode { int val; ListNode* next; ListNode(int v) : val(v), next(nullptr) {} };

void deleteNode(ListNode* node) {
    if (!node || !node->next) return;
    ListNode* next = node->next;
    node->val = next->val;
    node->next = next->next;
    delete next;
}

int main() {
    ListNode d(9), c(1), b(5), a(4);
    a.next = &b; b.next = &c; c.next = &d;
    deleteNode(&b);
    for (ListNode* p = &a; p; p = p->next) cout << p->val << ' '; // 4 1 9
    cout << '\\n';
}`,
        },
        steps(text) {
          const [valsRaw, targetRaw] = parts(text);
          const values = nums(valsRaw);
          const target = parseInt(targetRaw, 10);
          const steps = [];
          const at = values.indexOf(target);
          if (!values.length || at < 0) {
            return [{
              title: "The target value is not in the list",
              ...chain("list", values, fill(values.length, "idle")),
              counters: [count("nodes", values.length)],
              legend: LEG,
              happened: "The value to delete must appear in the chain.",
              why: "Deletion starts from a node reference, not from the head.",
            }];
          }
          if (at === values.length - 1) {
            return [{
              title: "Cannot delete the last node this way",
              ...chain("list", values, (i) => (i === at ? "bad" : "idle")),
              counters: [count("nodes", values.length)],
              legend: LEG,
              happened: "There is no next node to copy from.",
              why: "The method needs a successor to take the last position.",
            }];
          }
          steps.push({
            title: `Target node holds ${target}; previous node is unknown`,
            ...chain("list", values, (i) => (i === at ? "read" : "idle"), (i) => (i === at ? "target" : null)),
            counters: [count("nodes", values.length), count("target index", at)],
            legend: LEG,
            happened: "We only have the node itself, so the link behind it cannot be changed.",
            why: "Copying from the next node sidesteps the missing predecessor.",
            codeLine: 4,
          });
          const working = values.slice();
          working[at] = values[at + 1];
          steps.push({
            title: `Copy ${values[at + 1]} into the target slot`,
            ...chain("list", working, (i) => (i === at ? "swap" : "dim"), (i) => (i === at ? "copied" : null)),
            counters: [count("nodes", working.length), count("copied", values[at + 1])],
            legend: LEG,
            happened: `The target now reads ${working[at]}, the same as its successor.`,
            why: "Two equal neighbours prepare the chain for skipping.",
            codeLine: 5,
          });
          working.splice(at + 1, 1);
          steps.push({
            title: `Skip the duplicate → ${show(working)}`,
            ...chain("list", working, (i) => (i === at ? "done" : "idle")),
            counters: [count("nodes", working.length), count("removed", 1)],
            legend: LEG,
            happened: `The successor is unlinked, leaving ${show(working)}.`,
            why: "The copied value occupies the target position, so the original successor is redundant.",
            codeLine: 6,
          });
          steps.push({
            title: `Answer: ${show(working)}`,
            ...chain("list", working, fill(working.length, "result")),
            counters: [count("nodes", working.length), count("answer", show(working))],
            legend: LEG,
            happened: `The chain lost one node and kept its order.`,
            why: "Only two pointers changed; the predecessor was never needed.",
            codeLine: 7,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "intersection-of-two-linked-lists",
    title: "Intersection of Two Linked Lists",
    category: "Linked Lists",
    difficulty: "Intermediate",
    description:
      "Find the node where two chains join by walking both with pointer switching.",
    input: { label: "list A | list B | shared tail start value", default: "4,1,8,4,5 | 5,6,1,8,4,5 | 8", parse: "string" },
    approaches: [
      {
        name: "Two Pointers, Switch Heads",
        complexity: "O(n + m) time, O(1) space",
        idea: [
          "Let pointer A walk list A then continue on list B; pointer B does the mirror. Both walk the same total distance.",
          "If there is a shared tail, the pointers arrive together at its first node. If both reach null, there is no intersection.",
        ],
        problem: [
          "Comparing node identity is essential; equal values in different nodes are not an intersection.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int value; struct Node *next; } Node;

Node *meeting(Node *a, Node *b) {
    Node *pa = a, *pb = b;
    while (pa != pb) {
        pa = pa ? pa->next : b;
        pb = pb ? pb->next : a;
    }
    return pa;
}

int main(void) {
    Node y3 = {5, NULL}, y2 = {4, &y3}, y1 = {8, &y2};
    Node a2 = {1, &y1}, a1 = {4, &a2};
    Node b3 = {1, &y1}, b2 = {6, &b3}, b1 = {5, &b2};

    Node *hit = meeting(&a1, &b1);
    printf("%d\\n", hit ? hit->value : -1); /* 8 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

struct ListNode { int val; ListNode* next; ListNode(int v) : val(v), next(nullptr) {} };

ListNode* getIntersectionNode(ListNode* headA, ListNode* headB) {
    ListNode* a = headA;
    ListNode* b = headB;
    while (a != b) {
        a = a ? a->next : headB;
        b = b ? b->next : headA;
    }
    return a;
}

int main() {
    // shared tail 8->4->5 reached from 4->1 and 5->6->1
    return 0;
}`,
        },
        steps(text) {
          const [aRaw, bRaw, sharedRaw] = parts(text);
          const A = nums(aRaw);
          const B = nums(bRaw);
          const shared = parseInt(sharedRaw, 10);
          const ai = A.indexOf(shared), bi = B.indexOf(shared);
          const steps = [];
          if (ai < 0 || bi < 0) {
            return [{
              title: "The shared value must appear in both lists",
              tracks: [chips("A", A.length ? A : ["—"], "idle"), chips("B", B.length ? B : ["—"], "idle")],
              counters: [count("A length", A.length), count("B length", B.length)],
              legend: ["idle", "result"],
              happened: "The third field names the first value of the shared tail.",
              why: "Intersection compares node identity, not just values.",
            }];
          }
          const tailA = A.length - ai, tailB = B.length - bi;
          steps.push({
            title: `Shared tail ${A.slice(ai).join("→")}; lengths differ by ${Math.abs(tailA - tailB)}`,
            tracks: [chips("A", A, (i) => (i >= ai ? "compare" : "idle")), chips("B", B, (i) => (i >= bi ? "compare" : "idle"))],
            counters: [count("A length", A.length), count("B length", B.length)],
            legend: LEG,
            happened: `The shared part starts at value ${shared}.`,
            why: "Walking both chains with head switching equalises the distances.",
            codeLine: 4,
          });
          const walk = [];
          for (let i = 0; i < A.length; i++) walk.push(`A${i}=${A[i]}`);
          for (let i = 0; i < B.length; i++) walk.push(`B${i}=${B[i]}`);
          const total = A.length + B.length;
          for (let step = 1; step <= total; step++) {
            const ia = step - 1;
            const onA = ia < A.length;
            const value = onA ? A[ia] : B[ia - A.length];
            const reached = step >= Math.max(A.length, B.length) + 1;
            steps.push({
              title: `Pointer ${onA ? "A" : "B"} reads ${value}${reached ? " — both are now in the shared tail" : ""}`,
              tracks: [
                chips("A", A, (i) => (onA && i === ia ? "read" : i >= ai ? "done" : "dim")),
                chips("B", B, (i) => (!onA && i === ia - A.length ? "read" : i >= bi ? "done" : "dim")),
              ],
              counters: [count("step", step, total), count("shared start", shared)],
              legend: LEG,
              happened: reached ? `Both pointers have covered the same total distance.` : `The pointer is still in its own list.`,
              why: "After one chain ends the pointer jumps to the other head, so both paths have equal length.",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Answer: intersection at value ${shared}`,
            tracks: [
              chips("A", A, (i) => (i >= ai ? "result" : "dim")),
              chips("B", B, (i) => (i >= bi ? "result" : "dim")),
            ],
            counters: [count("steps", total), count("answer", shared)],
            legend: LEG,
            happened: `The first common node holds ${shared}.`,
            why: "Equal total distances mean the pointers meet exactly at the shared node.",
            codeLine: 7,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "palindrome-linked-list",
    title: "Palindrome Linked List",
    category: "Linked Lists",
    difficulty: "Intermediate",
    description:
      "Check whether a chain reads the same both ways by reversing the second half in place.",
    input: { label: "list values", default: "1,2,2,1", parse: "ints" },
    approaches: [
      {
        name: "Middle, Reverse, Compare",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Use slow and fast pointers to find the middle, then reverse the second half so both halves can be walked forwards.",
          "Compare the two halves node by node. A mismatch means the chain is not a palindrome.",
        ],
        problem: [
          "The reverse step mutates the input; if the original list must be preserved, it has to be restored afterwards.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int value; struct Node *next; } Node;

Node *reverse(Node *head) {
    Node *prev = NULL;
    while (head) { Node *next = head->next; head->next = prev; prev = head; head = next; }
    return prev;
}

int is_palindrome(Node *head) {
    Node *slow = head, *fast = head;
    while (fast && fast->next) { slow = slow->next; fast = fast->next->next; }

    Node *right = reverse(slow);
    Node *left = head;
    while (right) {
        if (left->value != right->value) return 0;
        left = left->next;
        right = right->next;
    }
    return 1;
}

int main(void) {
    Node d = {1, NULL}, c = {2, &d}, b = {2, &c}, a = {1, &b};
    printf("%d\\n", is_palindrome(&a)); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

struct ListNode { int val; ListNode* next; ListNode(int v) : val(v), next(nullptr) {} };

ListNode* reverse(ListNode* head) {
    ListNode* prev = nullptr;
    while (head) { ListNode* next = head->next; head->next = prev; prev = head; head = next; }
    return prev;
}

bool isPalindrome(ListNode* head) {
    ListNode *slow = head, *fast = head;
    while (fast && fast->next) { slow = slow->next; fast = fast->next->next; }

    ListNode* right = reverse(slow);
    ListNode* left = head;
    while (right) {
        if (left->val != right->val) return false;
        left = left->next;
        right = right->next;
    }
    return true;
}

int main() {
    ListNode d(1), c(2), b(2), a(1);
    a.next = &b; b.next = &c; c.next = &d;
    cout << isPalindrome(&a) << '\\n'; // 1
}`,
        },
        steps(values) {
          const a = values.slice();
          const n = a.length;
          if (!n) {
            return [{
              title: "An empty chain is a palindrome",
              ...chain("list", ["—"], ["idle"]),
              counters: [count("nodes", 0)],
              legend: LEG,
              happened: "There is nothing to compare.",
              why: "The empty sequence reads the same in both directions.",
            }];
          }
          const steps = [];
          let slow = 0, fast = 0;
          steps.push({
            title: `${n} nodes; find the middle with slow and fast pointers`,
            ...chain("list", a, (i) => (i === 0 ? "read" : "idle"), (i) => (i === 0 ? "start" : null)),
            counters: [count("slow", slow), count("fast", fast)],
            legend: LEG,
            happened: `Slow moves one node, fast moves two.`,
            why: "When fast reaches the end, slow is at the middle.",
            codeLine: 10,
          });
          while (fast < n && fast + 1 < n) {
            slow++;
            fast += 2;
            steps.push({
              title: `Slow ${slow}, fast ${fast}`,
              ...chain("list", a, (i) => (i === slow ? "active" : i === Math.min(fast, n - 1) ? "compare" : "idle"), (i) => (i === slow ? "slow" : i === Math.min(fast, n - 1) ? "fast" : null)),
              counters: [count("slow", slow), count("fast", Math.min(fast, n - 1))],
              legend: LEG,
              happened: `Fast advanced two steps, slow one.`,
              why: "The speed ratio of two keeps slow at the midpoint.",
              codeLine: 11,
            });
          }
          const right = a.slice(slow).reverse();
          steps.push({
            title: `Reverse the second half → ${show(right)}`,
            ...chain("list", right, fill(right.length, "swap")),
            counters: [count("second half", right.length), count("middle index", slow)],
            legend: LEG,
            happened: `The tail now runs ${right.join("→")}.`,
            why: "Reversing lets both halves be scanned in the same direction.",
            codeLine: 12,
          });
          let bad = -1;
          for (let i = 0; i < right.length; i++) {
            const same = a[i] === right[i];
            if (!same && bad < 0) bad = i;
            steps.push({
              title: `Compare ${a[i]} with ${right[i]} → ${same ? "match" : "mismatch"}`,
              tracks: [
                chips("left half", a.slice(0, right.length), (k) => (k === i ? (same ? "good" : "bad") : k < i ? "done" : "idle")),
                chips("reversed half", right, (k) => (k === i ? (same ? "good" : "bad") : k < i ? "done" : "idle")),
              ],
              counters: [count("compared", i + 1, right.length), count("mismatches", bad >= 0 ? 1 : 0)],
              legend: LEG,
              happened: same ? "The mirrored positions agree." : `Position ${i} differs, so the chain cannot be a palindrome.`,
              why: "A palindrome must match at every mirrored pair.",
              codeLine: 16,
            });
            if (!same) break;
          }
          steps.push({
            title: bad >= 0 ? `Answer: not a palindrome (position ${bad})` : "Answer: palindrome",
            tracks: [
              chips("original", a, (k) => (bad >= 0 && k === bad ? "bad" : "done")),
              chips("answer", [bad >= 0 ? "no" : "yes"], "result"),
            ],
            counters: [count("nodes", n), count("answer", bad >= 0 ? "no" : "yes")],
            legend: LEG,
            happened: bad >= 0 ? "A mirrored pair disagreed." : "Every mirrored pair matched.",
            why: "The comparison used constant extra space after the in-place reverse.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "reorder-list",
    title: "Reorder List",
    category: "Linked Lists",
    difficulty: "Intermediate",
    description:
      "Reorder the chain as first, last, second, second-last, … using middle finding and reversal.",
    input: { label: "list values", default: "1,2,3,4,5", parse: "ints" },
    approaches: [
      {
        name: "Split, Reverse, Weave",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Cut the chain at the middle. Reverse the second half so it runs from the old tail backwards.",
          "Weave the two halves together one node at a time: left, right, left, right.",
        ],
        problem: [
          "The middle split must give the first half the extra node for odd lengths, or the weave loses the centre.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int value; struct Node *next; } Node;

void reorder(Node *head) {
    if (!head || !head->next) return;

    Node *slow = head, *fast = head;
    while (fast->next && fast->next->next) { slow = slow->next; fast = fast->next->next; }

    Node *second = slow->next;
    slow->next = NULL;

    Node *prev = NULL;
    while (second) { Node *next = second->next; second->next = prev; prev = second; second = next; }
    second = prev;

    Node *first = head;
    while (second) {
        Node *nextFirst = first->next, *nextSecond = second->next;
        first->next = second;
        second->next = nextFirst;
        first = nextFirst;
        second = nextSecond;
    }
}

int main(void) {
    Node e = {5, NULL}, d = {4, &e}, c = {3, &d}, b = {2, &c}, a = {1, &b};
    reorder(&a);
    for (Node *p = &a; p; p = p->next) printf("%d ", p->value);
    printf("\\n"); /* 1 5 2 4 3 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

struct ListNode { int val; ListNode* next; ListNode(int v) : val(v), next(nullptr) {} };

void reorderList(ListNode* head) {
    if (!head || !head->next) return;

    ListNode *slow = head, *fast = head;
    while (fast->next && fast->next->next) { slow = slow->next; fast = fast->next->next; }

    ListNode* second = slow->next;
    slow->next = nullptr;

    ListNode* prev = nullptr;
    while (second) { ListNode* next = second->next; second->next = prev; prev = second; second = next; }

    ListNode* first = head;
    second = prev;
    while (second) {
        ListNode* nextFirst = first->next;
        ListNode* nextSecond = second->next;
        first->next = second;
        second->next = nextFirst;
        first = nextFirst;
        second = nextSecond;
    }
}

int main() {
    ListNode e(5), d(4), c(3), b(2), a(1);
    a.next = &b; b.next = &c; c.next = &d; d.next = &e;
    reorderList(&a);
    for (ListNode* p = &a; p; p = p->next) cout << p->val << ' '; // 1 5 2 4 3
    cout << '\\n';
}`,
        },
        steps(values) {
          const a = values.slice();
          const n = a.length;
          if (!n) {
            return [{
              title: "Give some values",
              ...chain("list", ["—"], ["idle"]),
              counters: [count("nodes", 0)],
              legend: LEG,
              happened: "There is nothing to reorder.",
              why: "The weave needs at least one node.",
            }];
          }
          const steps = [];
          const middle = Math.floor((n - 1) / 2);
          steps.push({
            title: `Split at index ${middle}: first half ${show(a.slice(0, middle + 1))}`,
            ...chain("list", a, (i) => (i === middle ? "active" : i < middle ? "done" : "idle"), (i) => (i === middle ? "middle" : null)),
            counters: [count("nodes", n), count("middle", middle)],
            legend: LEG,
            happened: `The second half starts at index ${middle + 1}.`,
            why: "For odd lengths the first half keeps the centre node.",
            codeLine: 7,
          });
          const second = a.slice(middle + 1).reverse();
          steps.push({
            title: `Reverse the second half → ${show(second)}`,
            ...chain("list", second, fill(second.length, "swap")),
            counters: [count("first half", middle + 1), count("second half", second.length)],
            legend: LEG,
            happened: `The tail now runs from the old last node backwards.`,
            why: "Weaving needs the last node available first.",
            codeLine: 12,
          });
          const out = [];
          const first = a.slice(0, middle + 1);
          let i = 0, j = 0;
          while (i < first.length || j < second.length) {
            if (i < first.length) out.push(first[i++]);
            if (j < second.length) out.push(second[j++]);
            steps.push({
              title: `Weave → ${show(out)}`,
              ...chain("list", out, (k) => (k >= out.length - 2 ? "active" : "done")),
              counters: [count("woven", out.length, n), count("first used", i), count("second used", j)],
              legend: LEG,
              happened: `The next pair alternates between the halves.`,
              why: "Interleaving one node from each half produces the required order.",
              codeLine: 18,
            });
          }
          steps.push({
            title: `Answer: ${show(out)}`,
            ...chain("list", out, fill(out.length, "result")),
            counters: [count("woven", out.length, n), count("answer", show(out))],
            legend: LEG,
            happened: `The chain now alternates ends.`,
            why: "Every node was visited a constant number of times.",
            codeLine: 22,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "reverse-linked-list-ii",
    title: "Reverse Linked List II",
    category: "Linked Lists",
    difficulty: "Intermediate",
    description:
      "Reverse only the nodes between two positions, keeping the rest of the chain intact.",
    input: { label: "list values | left | right", default: "1,2,3,4,5 | 2 | 4", parse: "string" },
    approaches: [
      {
        name: "Head Insertion Inside the Window",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Walk to the node just before the window and remember it. Then take each node after the window start and move it to the front of the window.",
          "A dummy node before the head removes the special case where the window begins at position one.",
        ],
        problem: [
          "The moving node must be re-linked after the window start, not after its old predecessor, or the window collapses.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int value; struct Node *next; } Node;

Node *reverse_between(Node *head, int left, int right) {
    Node dummy = {0, head}, *prev = &dummy;
    for (int i = 1; i < left; i++) prev = prev->next;

    Node *start = prev->next;
    for (int i = 0; i < right - left; i++) {
        Node *move = start->next;
        start->next = move->next;
        move->next = prev->next;
        prev->next = move;
    }
    return dummy.next;
}

int main(void) {
    Node e = {5, NULL}, d = {4, &e}, c = {3, &d}, b = {2, &c}, a = {1, &b};
    for (Node *p = reverse_between(&a, 2, 4); p; p = p->next) printf("%d ", p->value);
    printf("\\n"); /* 1 4 3 2 5 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

struct ListNode { int val; ListNode* next; ListNode(int v) : val(v), next(nullptr) {} };

ListNode* reverseBetween(ListNode* head, int left, int right) {
    ListNode dummy(0);
    dummy.next = head;
    ListNode* prev = &dummy;
    for (int i = 1; i < left; i++) prev = prev->next;

    ListNode* start = prev->next;
    for (int i = 0; i < right - left; i++) {
        ListNode* move = start->next;
        start->next = move->next;
        move->next = prev->next;
        prev->next = move;
    }
    return dummy.next;
}

int main() {
    ListNode e(5), d(4), c(3), b(2), a(1);
    a.next = &b; b.next = &c; c.next = &d; d.next = &e;
    for (ListNode* p = reverseBetween(&a, 2, 4); p; p = p->next) cout << p->val << ' '; // 1 4 3 2 5
    cout << '\\n';
}`,
        },
        steps(text) {
          const [valsRaw, lRaw, rRaw] = parts(text);
          const values = nums(valsRaw);
          const left = Math.max(1, parseInt(lRaw, 10) || 1);
          const right = Math.min(values.length, parseInt(rRaw, 10) || values.length);
          const steps = [];
          if (!values.length || right < left) {
            return [{
              title: "Give a list and a valid window",
              ...chain("list", values.length ? values : ["—"], ["idle"]),
              counters: [count("nodes", values.length)],
              legend: LEG,
              happened: "Fields are values, left position and right position.",
              why: "The reversal only touches nodes between left and right.",
            }];
          }
          steps.push({
            title: `Reverse positions ${left}..${right} of ${show(values)}`,
            ...chain("list", values, (i) => (i + 1 >= left && i + 1 <= right ? "active" : "dim"), (i) => (i + 1 === left ? "left" : i + 1 === right ? "right" : null)),
            counters: [count("window", right - left + 1), count("reversed", 0)],
            legend: LEG,
            happened: `Only the ${right - left + 1} nodes in the window change order.`,
            why: "Moving nodes to the front of the window reverses it in place.",
            codeLine: 5,
          });
          const working = values.slice();
          const windowStart = left - 1;
          for (let k = 0; k < right - left; k++) {
            const node = working.splice(windowStart + k + 1, 1)[0];
            working.splice(windowStart + k, 0, node);
            steps.push({
              title: `Move ${node} to the front of the window`,
              ...chain("list", working, (i) => (i + 1 >= left && i + 1 <= right ? (i === windowStart + k ? "swap" : "done") : "dim")),
              counters: [count("window", right - left + 1), count("reversed", k + 1, right - left)],
              legend: LEG,
              happened: `The window now reads ${working.slice(left - 1, right).join("→")}.`,
              why: "Each moved node becomes the new first node of the window.",
              codeLine: 10,
            });
          }
          steps.push({
            title: `Answer: ${show(working)}`,
            ...chain("list", working, fill(working.length, "result")),
            counters: [count("reversed", right - left, right - left), count("answer", show(working))],
            legend: LEG,
            happened: `The window is reversed and the surrounding nodes are untouched.`,
            why: "The dummy node handled the case where the window starts at the head.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });
})();
