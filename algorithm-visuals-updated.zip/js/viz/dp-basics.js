/* ============================================================
   DSA Visuals — Dynamic Programming Basics
   Eleven beginner-to-advanced DP problems. Everything here is
   original work written for this app: the prose, the C/C++ and
   the step sequences all grow out of the recurrence each entry
   states up front. A second approach is offered wherever one
   honestly exists (top-down vs bottom-up, brute vs optimal).
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const H = window.H;
  const V = window.VIZ;

  /* ---------------- small shared helpers ---------------- */

  /* Split free text into whitespace-separated tokens. */
  function tokens(text) {
    return String(text).trim().split(/\s+/).filter(Boolean);
  }

  /* Friendly five-step story when a two-string problem only got one word. */
  function oneToken(first, subject) {
    const shown = (first || "").slice(0, 24) || "word1";
    const guess = (first || "").slice(0, 3) || "abc";
    return [
      {
        title: `Only one word arrived: "${shown}"`,
        tracks: [track("first word", shown.split(""), fill(shown.length, "idle"))],
        counters: [count("words given", 1, 2)],
        legend: ["idle", "read", "bad"],
        happened: "This visualisation compares two words, but the box holds a single token.",
        why: `A ${subject} table needs two sides before it can ask anything about a pair of prefixes.`,
      },
      {
        title: "Type a second word after a space",
        tracks: [{ label: "example input", cells: [{ v: `${shown} ${guess}`, state: "idle" }] }],
        counters: [count("words given", 1, 2)],
        legend: ["idle"],
        happened: `Two words separated by one space, for example "${shown} ${guess}".`,
        why: "One word becomes the rows, the other the columns; both are needed for a table.",
      },
      {
        title: "Every cell will compare two prefixes",
        tracks: [{ label: "the plan", cells: [{ v: "row prefix × column prefix", state: "idle" }] }],
        counters: [count("words given", 1, 2)],
        legend: ["idle"],
        happened: "Each grid cell asks one question about a prefix of each word.",
        why: "Prefixes are exactly the sub-problems a two-string DP table is built from.",
      },
      {
        title: "Nothing to compute yet",
        tracks: [{ label: "status", cells: [{ v: "waiting for a second word", state: "bad" }] }],
        counters: [count("words given", 1, 2)],
        legend: ["bad"],
        happened: "The table stays blank until a second word arrives.",
        why: "With only one side there is no pair of prefixes to compare, so no cell has a value.",
      },
      {
        title: "Answer: n/a — add a second word",
        tracks: [{ label: "status", cells: [{ v: "add a second word, then press Run", state: "bad" }] }],
        counters: [count("words given", 1, 2), count("answer", "—")],
        legend: ["bad"],
        happened: "Re-run with two space-separated words to see the whole table fill in.",
        why: "The algorithm is defined for two inputs; a single word simply has no answer here.",
      },
    ];
  }

  /* ---------------- 1. Climbing Stairs ---------------- */
  V.register({
    id: "climbing-stairs",
    title: "Climbing Stairs",
    category: "Dynamic Programming",
    difficulty: "Beginner",
    description: "Count the distinct ways to reach step n when each move climbs 1 or 2 steps.",
    input: { label: "Number of steps", default: "6", parse: "int" },
    approaches: [
      {
        name: "Bottom-Up Table",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Let dp[i] be the number of ways to stand on step i. The last move onto step i either came from step i-1 (a single step) or from step i-2 (a double step).",
          "So dp[i] = dp[i-1] + dp[i-2]. The base cases are dp[0] = 1 (the ground, one way to be there) and dp[1] = 1.",
          "Fill the row left to right; the final cell dp[n] is the answer.",
        ],
        problem: [
          "Storing every dp value costs a whole row when only the last two are ever read — the second approach shows how to drop that.",
        ],
        code: {
          c: `#include <stdio.h>

/* dp[i] = ways to stand on step i: dp[i] = dp[i-1] + dp[i-2]. */
int climb(int n) {
    if (n <= 1) return 1;               /* ground or one step */
    int dp[64];
    dp[0] = 1;
    dp[1] = 1;
    for (int i = 2; i <= n; i++)
        dp[i] = dp[i - 1] + dp[i - 2];
    return dp[n];
}

int main(void) {
    printf("%d\\n", climb(6)); /* 13 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

int climb(int n) {
    if (n <= 1) return 1;                 // ground or a single step
    std::vector<int> dp(n + 1, 0);
    dp[0] = 1;
    dp[1] = 1;
    for (int i = 2; i <= n; i++)
        dp[i] = dp[i - 1] + dp[i - 2];    // climb 1 or climb 2
    return dp[n];
}

int main() {
    std::cout << climb(6) << '\\n';        // 13
}`,
        },
        steps(parsed) {
          const raw = Number(parsed);
          const n = Number.isFinite(raw) ? raw : 0;
          const trimmed = n > 30 || n < 0;
          const N = Math.max(0, Math.min(30, n));
          const dp = new Array(N + 1).fill(null);
          const tag = new Array(N + 1).fill(undefined);
          const steps = [];
          const LEG = ["read", "result", "done", "idle"];
          const cells = (active) =>
            dp.map((v, i) => ({
              v: v == null ? "—" : v,
              state: v == null ? "idle" : i === active ? "read" : "done",
              tag: tag[i],
            }));

          steps.push({
            title: `The question: how many routes reach step ${N}?`,
            tracks: [track("steps", Array.from({ length: N + 1 }, (_, i) => i), fill(N + 1, "idle"))],
            counters: [count("steps to climb", N)],
            legend: LEG,
            happened: trimmed
              ? `The input was ${n}; the row is trimmed to ${N} steps so the picture stays readable. Each move is 1 or 2 steps at a time.`
              : `There are ${N} steps. Each move climbs either 1 step or 2 steps.`,
            why: "Counting routes is not obvious from the wording, so the plan is to build up answers for small step counts first.",
            codeLine: 3,
          });

          steps.push({
            title: "Recurrence: dp[i] = dp[i-1] + dp[i-2]",
            tracks: [{ label: "dp (ways to stand on step i)", cells: cells(-1) }],
            counters: [count("steps to climb", N), count("cells filled", 0)],
            legend: LEG,
            happened: "An empty row dp[0..n] is ready. Each cell will hold the number of ways to stand on that step.",
            why: "The final move onto step i is either one step or two steps, so the routes split into two disjoint groups.",
            codeLine: 6,
          });

          dp[0] = 1;
          tag[0] = "ground";
          steps.push({
            title: "Base case: dp[0] = 1",
            tracks: [{ label: "dp (ways to stand on step i)", cells: cells(0) }],
            counters: [count("steps to climb", N), count("cells filled", 1)],
            legend: LEG,
            happened: "Standing on the ground (step 0) counts as one way — the way where you have not moved yet.",
            why: "Every climb has to start somewhere; anchoring dp[0] at 1 lets the recurrence count the first real step correctly.",
            codeLine: 7,
          });

          if (N >= 1) {
            dp[1] = 1;
            tag[1] = "one step";
            steps.push({
              title: "Base case: dp[1] = 1",
              tracks: [{ label: "dp (ways to stand on step i)", cells: cells(1) }],
              counters: [count("steps to climb", N), count("cells filled", 2)],
              legend: LEG,
              happened: "Step 1 has exactly one route: a single 1-step climb.",
              why: "With the two smallest answers fixed, the recurrence can now produce every larger one.",
              codeLine: 8,
            });
          }

          for (let i = 2; i <= N; i++) {
            dp[i] = dp[i - 1] + dp[i - 2];
            tag[i] = `${dp[i - 1]} + ${dp[i - 2]}`;
            steps.push({
              title: `dp[${i}] = dp[${i - 1}] + dp[${i - 2}] = ${dp[i]}`,
              tracks: [{ label: "dp (ways to stand on step i)", cells: cells(i) }],
              counters: [count("steps to climb", N), count("cells filled", i + 1), count("ways to step " + i, dp[i])],
              legend: LEG,
              happened: `Step ${i} is reached from step ${i - 1} or step ${i - 2}, so its routes add: ${dp[i - 1]} + ${dp[i - 2]} = ${dp[i]}.`,
              why: "Every route belongs to exactly one of those two groups — no route is double-counted, none is missed.",
              codeLine: 9,
            });
          }

          if (N === 0) {
            steps.push({
              title: "No stairs to climb",
              tracks: [{ label: "dp (ways to stand on step i)", cells: cells(0) }],
              counters: [count("steps to climb", 0), count("cells filled", 1)],
              legend: LEG,
              happened: "With zero steps the only route is to stay on the ground.",
              why: "The base case already is the whole answer here; the loop body never runs.",
              codeLine: 10,
            });
          }

          steps.push({
            title: `Answer: ${dp[N]} ways to reach step ${N}`,
            tracks: [{ label: "dp (ways to stand on step i)", cells: cells(N).map((c, i) => (i === N ? { ...c, state: "result" } : c)) }],
            counters: [count("steps to climb", N), count("answer", dp[N])],
            legend: LEG,
            happened: `The last cell holds ${dp[N]} — the number of distinct 1-and-2 step climbs to step ${N}.`,
            why: "Because each cell was built from the two before it, one left-to-right pass produced the answer.",
            codeLine: 10,
          });
          return steps;
        },
      },
      {
        name: "Memoised Recursion",
        complexity: "O(n) time, O(n) space",
        idea: [
          "State the answer directly: ways(n) is the number of climbs from the ground to step n, and ways(n) = ways(n-1) + ways(n-2).",
          "Without memory that recursion branches into two at every level, which is why it becomes slow; storing each answer the first time it is computed removes the repeats.",
          "The memo is filled wherever the recursion first reaches it, so some cells are solved from the top down rather than strictly left to right.",
        ],
        problem: [
          "Recursion spends call-stack space and, without the memo, re-solves the same sub-problem again and again — the memo is what keeps it linear.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

static long memo[64];

long ways(int n) {
    if (n <= 1) return 1;               /* ground or one step */
    if (memo[n] >= 0) return memo[n];   /* solved before */
    return memo[n] = ways(n - 1) + ways(n - 2);
}

int main(void) {
    memset(memo, -1, sizeof memo);
    printf("%ld\\n", ways(6)); /* 13 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

std::vector<long> memo;

long ways(int n) {
    if (n <= 1) return 1;                 // ground or a single step
    if (memo[n] != -1) return memo[n];    // cached answer
    return memo[n] = ways(n - 1) + ways(n - 2);
}

int main() {
    memo.assign(64, -1);
    std::cout << ways(6) << '\\n';        // 13
}`,
        },
        steps(parsed) {
          const raw = Number(parsed);
          const n = Number.isFinite(raw) ? raw : 0;
          const trimmed = n > 30 || n < 0;
          const N = Math.max(0, Math.min(30, n));
          const memo = new Array(N + 1).fill(null);
          const events = [];
          let calls = 0, hits = 0;
          (function ways(i) {
            calls++;
            if (memo[i] != null) {
              hits++;
              events.push({ type: "hit", i, v: memo[i], calls, hits });
              return memo[i];
            }
            if (i <= 1) {
              memo[i] = 1;
              events.push({ type: "base", i, v: 1, calls, hits });
              return 1;
            }
            const a = ways(i - 1);
            const b = ways(i - 2);
            memo[i] = a + b;
            events.push({ type: "fill", i, v: memo[i], a, b, calls, hits });
            return memo[i];
          })(N);

          const steps = [];
          const LEG = ["read", "result", "done", "idle"];
          const cells = (active) =>
            memo.map((v, i) => ({
              v: v == null ? "—" : v,
              state: v == null ? "idle" : i === active ? "read" : "done",
              tag: i === active && v != null ? "cached" : undefined,
            }));

          steps.push({
            title: `Call ways(${N}) and let it ask for smaller steps`,
            tracks: [{ label: "memo (answer per step)", cells: cells(-1) }],
            counters: [count("calls", 0), count("cache hits", 0)],
            legend: LEG,
            happened: trimmed
              ? `The input was ${n}; the picture is trimmed to ${N} steps. The recursion starts at the top.`
              : `The recursion starts at step ${N} and immediately asks for steps ${Math.max(0, N - 1)} and ${Math.max(0, N - 2)}.`,
            why: "Working downwards is natural: the big question is defined in terms of smaller ones that may already be known.",
            codeLine: 6,
          });

          events.forEach((e) => {
            if (e.type === "base") {
              steps.push({
                title: `Base case reached: memo[${e.i}] = 1`,
                tracks: [{ label: "memo (answer per step)", cells: cells(e.i) }],
                counters: [count("calls", e.calls), count("cache hits", e.hits)],
                legend: LEG,
                happened: `Step ${e.i} is small enough to answer at once, so memo[${e.i}] is set to 1.`,
                why: "Small cases are the recursion's floor; they stop it from descending forever.",
                codeLine: 4,
              });
            } else if (e.type === "hit") {
              steps.push({
                title: `Cache hit: ways(${e.i}) is already ${e.v}`,
                tracks: [{ label: "memo (answer per step)", cells: cells(e.i) }],
                counters: [count("calls", e.calls), count("cache hits", e.hits)],
                legend: LEG,
                happened: `This branch needs step ${e.i}, which was solved earlier, so the stored value ${e.v} is reused instantly.`,
                why: "This reuse is the whole point of the memo — without it the same sub-problem would be recomputed.",
                codeLine: 5,
              });
            } else {
              steps.push({
                title: `memo[${e.i}] = ${e.a} + ${e.b} = ${e.v}`,
                tracks: [{ label: "memo (answer per step)", cells: cells(e.i) }],
                counters: [count("calls", e.calls), count("cache hits", e.hits), count("stored for step " + e.i, e.v)],
                legend: LEG,
                happened: `Both child answers (${e.a} and ${e.b}) are back, so step ${e.i} is stored as ${e.v}.`,
                why: "Once a value is stored, every later request for it becomes a cheap lookup instead of another search.",
                codeLine: 7,
              });
            }
          });

          steps.push({
            title: "Why the memory matters",
            tracks: [{ label: "memo (answer per step)", cells: cells(-1) }],
            counters: [count("calls", calls), count("cache hits", hits)],
            legend: LEG,
            happened: `${calls} calls were made and ${hits} of them were answered straight from the memo.`,
            why: "The naive recursion would branch into about 2^n calls; remembering each answer once collapses that to one call per step.",
            codeLine: 5,
          });

          steps.push({
            title: `Answer: ${memo[N]} ways to reach step ${N}`,
            tracks: [{ label: "memo (answer per step)", cells: cells(N).map((c, i) => (i === N ? { ...c, state: "result" } : c)) }],
            counters: [count("calls", calls), count("cache hits", hits), count("answer", memo[N])],
            legend: LEG,
            happened: `The top-level call returns ${memo[N]}, the same number the table approach produced.`,
            why: "Top-down and bottom-up solve exactly the same sub-problems — they only differ in the order they visit them.",
            codeLine: 6,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------- 2. Min Cost Climbing Stairs ---------------- */
  V.register({
    id: "min-cost-climbing-stairs",
    title: "Min Cost Climbing Stairs",
    category: "Dynamic Programming",
    difficulty: "Beginner",
    description: "Find the cheapest way to the top when each step you land on charges its own cost.",
    input: { label: "Cost per step", default: "10, 15, 20", parse: "ints" },
    approaches: [
      {
        name: "Top-Down with Memo",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Look from a step up towards the top: let f(i) be the cheapest total still to be paid if you are standing on step i.",
          "From step i you pay cost[i] and then either hop one step (to i+1) or two steps (to i+2), so f(i) = cost[i] + min(f(i+1), f(i+2)).",
          "The top is index n and f(n) = 0; the answer is min(f(0), f(1)) because you may start on either of the first two steps.",
        ],
        problem: [
          "The recursion asks about i+1 and i+2, which point forward; without a memo the branching repeats the same suffixes many times.",
        ],
        code: {
          c: `#include <stdio.h>

static int memo[100];

/* f(i) = cheapest from step i to the top (index n). */
int f(const int *cost, int n, int i) {
    if (i >= n) return 0;                 /* standing on the top */
    if (memo[i] != -1) return memo[i];
    int a = f(cost, n, i + 1);
    int b = f(cost, n, i + 2);
    return memo[i] = cost[i] + (a < b ? a : b);
}

int main(void) {
    int cost[] = {10, 15, 20};
    int n = 3;
    for (int i = 0; i < n; i++) memo[i] = -1;
    int a = f(cost, n, 0), b = f(cost, n, 1);
    printf("%d\\n", a < b ? a : b); /* 15 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int f(const std::vector<int>& cost, std::vector<int>& memo, int i, int n) {
    if (i >= n) return 0;                 // on the top, nothing left to pay
    if (memo[i] != -1) return memo[i];
    int best = std::min(f(cost, memo, i + 1, n), f(cost, memo, i + 2, n));
    return memo[i] = cost[i] + best;
}

int main() {
    std::vector<int> cost{10, 15, 20}, memo(cost.size(), -1);
    int n = (int)cost.size();
    std::cout << std::min(f(cost, memo, 0, n), f(cost, memo, 1, n)) << '\\n'; // 15
}`,
        },
        steps(costs) {
          const n = costs.length;
          const memo = new Array(n + 1).fill(null);
          const events = [];
          let calls = 0, hits = 0;
          (function f(i) {
            calls++;
            if (i >= n) {
              events.push({ type: "top", i, v: 0, calls, hits });
              return 0;
            }
            if (memo[i] != null) {
              hits++;
              events.push({ type: "hit", i, v: memo[i], calls, hits });
              return memo[i];
            }
            const a = f(i + 1);
            const b = f(i + 2);
            memo[i] = costs[i] + Math.min(a, b);
            events.push({ type: "fill", i, v: memo[i], a, b, calls, hits });
            return memo[i];
          })(0);

          const steps = [];
          const LEG = ["read", "result", "done", "idle"];
          const costTrack = (active) => track("cost per step", costs, costs.map((_, i) => (i === active ? "read" : "done")));
          const memoTrack = (active) => ({
            label: "f (cheapest from here to the top)",
            cells: Array.from({ length: n + 1 }, (_, i) => ({
              v: memo[i] == null ? "—" : memo[i],
              state: memo[i] == null ? "idle" : i === active ? "read" : "done",
              tag: i === n ? "the top" : undefined,
            })),
          });

          steps.push({
            title: `The top sits one step past the last price (index ${n})`,
            tracks: [costTrack(-1), memoTrack(-1)],
            counters: [count("steps priced", n), count("calls", 0)],
            legend: LEG,
            happened: `Costs ${costs.join(", ")} apply to steps 0 to ${n - 1}. The top is index ${n}.`,
            why: "The recursion works backwards from the top, so the top row is worth defining before anything else.",
            codeLine: 3,
          });

          steps.push({
            title: `Call f(0) and f(1): you may start on either first step`,
            tracks: [costTrack(0), memoTrack(-1)],
            counters: [count("steps priced", n), count("calls", 0)],
            legend: LEG,
            happened: "The climb may begin on step 0 or step 1, so both are explored and the cheaper is kept.",
            why: "Forcing a start would miss the option of skipping the expensive first step.",
            codeLine: 13,
          });

          events.forEach((e) => {
            if (e.type === "top") {
              steps.push({
                title: `f(${e.i}) = 0 — standing on the top`,
                tracks: [costTrack(-1), memoTrack(e.i)],
                counters: [count("steps priced", n), count("calls", e.calls), count("cache hits", e.hits)],
                legend: LEG,
                happened: `Index ${e.i} is the top, so there is no further cost to pay there.`,
                why: "This zero is the floor that lets every earlier answer add up to something finite.",
                codeLine: 4,
              });
            } else if (e.type === "hit") {
              steps.push({
                title: `Cache hit: f(${e.i}) is already ${e.v}`,
                tracks: [costTrack(-1), memoTrack(e.i)],
                counters: [count("steps priced", n), count("calls", e.calls), count("cache hits", e.hits)],
                legend: LEG,
                happened: `Step ${e.i} was priced earlier, so its stored value ${e.v} is reused.`,
                why: "Reusing a solved suffix is what keeps a forward-pointing recursion from exploding.",
                codeLine: 5,
              });
            } else {
              steps.push({
                title: `f(${e.i}) = ${costs[e.i]} + min(${e.a}, ${e.b}) = ${e.v}`,
                tracks: [costTrack(e.i), memoTrack(e.i)],
                counters: [count("steps priced", n), count("calls", e.calls), count("cheapest from " + e.i, e.v)],
                legend: LEG,
                happened: `Landing on step ${e.i} costs ${costs[e.i]}; from there the cheaper of ${e.a} and ${e.b} follows, giving ${e.v}.`,
                why: "Paying the current price is unavoidable once you land, so only the hop after it is a real choice.",
                codeLine: 8,
              });
            }
          });

          const best = Math.min(memo[0], memo[1]);
          steps.push({
            title: `Answer: min(f(0), f(1)) = ${best}`,
            tracks: [
              track("cost per step", costs, fill(n, "dim")),
              {
                label: "the two possible starts",
                cells: [
                  { v: memo[0], state: memo[0] === best ? "result" : "dim", tag: "start on 0" },
                  { v: memo[1], state: memo[1] === best ? "result" : "dim", tag: "start on 1" },
                ],
              },
            ],
            counters: [count("steps priced", n), count("answer", best)],
            legend: LEG,
            happened: `Starting on step 0 costs ${memo[0]}; starting on step 1 costs ${memo[1]}. The cheaper is ${best}.`,
            why: "The problem allows either starting step, so the final answer is the minimum of the two finished draws.",
            codeLine: 13,
          });
          return steps;
        },
      },
      {
        name: "Bottom-Up Table",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Now build from the bottom: dp[i] is the cheapest total to stand on step i, having paid cost[i] when you arrived.",
          "dp[0] = cost[0] and dp[1] = cost[1]; then dp[i] = cost[i] + min(dp[i-1], dp[i-2]).",
          "The top is index n, reachable from step n-1 or n-2, so the answer is min(dp[n-1], dp[n-2]).",
        ],
        problem: [
          "The table keeps every intermediate price, though only the last two entries are read as the pass continues.",
        ],
        code: {
          c: `#include <stdio.h>

/* dp[i] = cheapest total to stand on step i, cost[i] included. */
int min_cost(const int *cost, int n) {
    if (n == 1) return cost[0];
    int dp[100];
    dp[0] = cost[0];
    dp[1] = cost[1];
    for (int i = 2; i < n; i++) {
        int back = dp[i - 1] < dp[i - 2] ? dp[i - 1] : dp[i - 2];
        dp[i] = cost[i] + back;
    }
    return dp[n - 1] < dp[n - 2] ? dp[n - 1] : dp[n - 2];
}

int main(void) {
    int cost[] = {10, 15, 20};
    printf("%d\\n", min_cost(cost, 3)); /* 15 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int minCost(const std::vector<int>& cost) {
    int n = (int)cost.size();
    if (n == 1) return cost[0];
    std::vector<int> dp(n, 0);
    dp[0] = cost[0];
    dp[1] = cost[1];
    for (int i = 2; i < n; i++)
        dp[i] = cost[i] + std::min(dp[i - 1], dp[i - 2]);
    return std::min(dp[n - 1], dp[n - 2]);
}

int main() {
    std::cout << minCost({10, 15, 20}) << '\\n'; // 15
}`,
        },
        steps(costs) {
          const n = costs.length;
          const dp = new Array(n).fill(null);
          const tag = new Array(n).fill(undefined);
          const steps = [];
          const LEG = ["read", "result", "done", "idle"];
          const dpCells = (active) =>
            dp.map((v, i) => ({
              v: v == null ? "—" : v,
              state: v == null ? "idle" : i === active ? "read" : "done",
              tag: tag[i],
            }));

          steps.push({
            title: "Recurrence: dp[i] = cost[i] + min(dp[i-1], dp[i-2])",
            tracks: [track("cost per step", costs, fill(n, "idle")), { label: "dp (cheapest to stand here)", cells: dpCells(-1) }],
            counters: [count("steps", n), count("cells filled", 0)],
            legend: LEG,
            happened: `dp[i] will mean "cheapest total to stand on step i". Its value depends only on the two steps below it.`,
            why: "Filling upward avoids recursion: when processing step i, both steps it can come from are already known.",
            codeLine: 3,
          });

          dp[0] = costs[0];
          tag[0] = "paid " + costs[0];
          steps.push({
            title: `Base: dp[0] = ${dp[0]}`,
            tracks: [track("cost per step", costs, paint(fill(n, "done"), { 0: "read" })), { label: "dp (cheapest to stand here)", cells: dpCells(0) }],
            counters: [count("steps", n), count("cells filled", 1)],
            legend: LEG,
            happened: `To stand on step 0 you pay its price ${costs[0]}; nothing came before it.`,
            why: "Seeding the first cell is the anchor the rest of the row grows from.",
            codeLine: 6,
          });

          if (n >= 2) {
            dp[1] = costs[1];
            tag[1] = "paid " + costs[1];
            steps.push({
              title: `Base: dp[1] = ${dp[1]}`,
              tracks: [track("cost per step", costs, paint(fill(n, "done"), { 1: "read" })), { label: "dp (cheapest to stand here)", cells: dpCells(1) }],
              counters: [count("steps", n), count("cells filled", 2)],
              legend: LEG,
              happened: `Step 1 can be reached in one hop from the ground, so it simply pays its own price ${costs[1]}.`,
              why: "Both starting steps are priced, so later steps may arrive from either of them.",
              codeLine: 7,
            });
          }

          for (let i = 2; i < n; i++) {
            const back = Math.min(dp[i - 1], dp[i - 2]);
            dp[i] = costs[i] + back;
            tag[i] = `${costs[i]} + ${back}`;
            steps.push({
              title: `dp[${i}] = ${costs[i]} + min(${dp[i - 1]}, ${dp[i - 2]}) = ${dp[i]}`,
              tracks: [track("cost per step", costs, paint(fill(n, "done"), { [i]: "read" })), { label: "dp (cheapest to stand here)", cells: dpCells(i) }],
              counters: [count("steps", n), count("cells filled", i + 1), count("cheapest to step " + i, dp[i])],
              legend: LEG,
              happened: `Reaching step ${i} means paying ${costs[i]} plus the cheaper way into the previous two: ${back}. Total ${dp[i]}.`,
              why: "Because the cheaper predecessor is chosen, dp[i] is the cheapest possible total for that step.",
              codeLine: 9,
            });
          }

          let best, from;
          if (n === 1) {
            best = dp[0];
            from = "only one step";
          } else {
            best = Math.min(dp[n - 1], dp[n - 2]);
            from = dp[n - 1] <= dp[n - 2] ? `from step ${n - 1}` : `from step ${n - 2}`;
          }
          steps.push({
            title: `Answer: ${best} (top reached ${from})`,
            tracks: [
              track("cost per step", costs, fill(n, "dim")),
              { label: "dp (cheapest to stand here)", cells: dpCells(-1).map((c, i) => (i === n - 1 || (n >= 2 && i === n - 2) ? { ...c, state: i === (dp[n - 1] <= dp[n - 2] ? n - 1 : n - 2) && n >= 2 ? "result" : c.state } : c)) },
            ],
            counters: [count("steps", n), count("answer", best)],
            legend: LEG,
            happened: n === 1
              ? `With a single priced step the climb is just its cost ${best}.`
              : `The top is one step past the last index, reachable from step ${n - 1} or ${n - 2}; the smaller total ${best} wins.`,
            why: "The final hop is free, so the answer is the cheaper of the two last step totals.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------- 3. House Robber ---------------- */
  V.register({
    id: "house-robber",
    title: "House Robber",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Rob the most money from a row of houses without ever taking two neighbours.",
    input: { label: "Money in each house", default: "2, 7, 9, 3, 1", parse: "ints" },
    approaches: [
      {
        name: "Bottom-Up Table",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Let dp[i] be the best loot possible using only the first i houses. House i is either skipped (keep dp[i-1]) or robbed (then house i-1 is forbidden, so add it to dp[i-2]).",
          "So dp[i] = max(dp[i-1], dp[i-2] + money[i]). The bases are dp[0] = 0 and dp[1] = money[0].",
          "Filling left to right, dp[n] is the answer, and the decisions can be replayed to show which houses were taken.",
        ],
        problem: [
          "A full dp row is kept even though each cell reads only the previous two; the recursion approach shows the same answer top-down.",
        ],
        code: {
          c: `#include <stdio.h>

/* dp[i] = best loot from the first i houses (i from 0..n). */
int rob(const int *a, int n) {
    int dp[100];
    dp[0] = 0;
    dp[1] = a[0];
    for (int i = 2; i <= n; i++) {
        int skip = dp[i - 1];
        int take = dp[i - 2] + a[i - 1];
        dp[i] = skip > take ? skip : take;
    }
    return dp[n];
}

int main(void) {
    int a[] = {2, 7, 9, 3, 1};
    printf("%d\\n", rob(a, 5)); /* 12 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int rob(const std::vector<int>& a) {
    int n = (int)a.size();
    std::vector<int> dp(n + 1, 0);
    dp[1] = a[0];
    for (int i = 2; i <= n; i++)
        dp[i] = std::max(dp[i - 1], dp[i - 2] + a[i - 1]);
    return dp[n];
}

int main() {
    std::cout << rob({2, 7, 9, 3, 1}) << '\\n'; // 12
}`,
        },
        steps(nums) {
          const n = nums.length;
          const dp = new Array(n + 1).fill(null);
          const tag = new Array(n + 1).fill(undefined);
          const chosen = new Array(n).fill(false);
          const steps = [];
          const LEG = ["read", "good", "result", "done", "idle"];
          const houseCells = (active) =>
            nums.map((v, i) => ({
              v,
              state: i === active ? "read" : chosen[i] ? "good" : "done",
              tag: chosen[i] ? "robbed" : undefined,
            }));
          const dpCells = (active) =>
            dp.map((v, i) => ({
              v: v == null ? "—" : v,
              state: v == null ? "idle" : i === active ? "read" : "done",
              tag: tag[i],
            }));

          steps.push({
            title: "Recurrence: dp[i] = max(dp[i-1], dp[i-2] + money[i])",
            tracks: [track("houses", nums, fill(n, "idle")), { label: "dp (best from first i houses)", cells: dpCells(-1) }],
            counters: [count("houses", n), count("cells filled", 0)],
            legend: LEG,
            happened: "dp[i] will hold the best loot from the first i houses. For house i there are only two sensible choices: skip it or take it.",
            why: "Taking a house forbids only its immediate neighbour, so each decision reaches back just two cells.",
            codeLine: 3,
          });

          dp[0] = 0;
          tag[0] = "no houses";
          steps.push({
            title: "Base: dp[0] = 0",
            tracks: [track("houses", nums, fill(n, "idle")), { label: "dp (best from first i houses)", cells: dpCells(0) }],
            counters: [count("houses", n), count("cells filled", 1)],
            legend: LEG,
            happened: "With no houses to consider there is nothing to steal, so the best is 0.",
            why: "A zero start gives the 'skip the first house' branch something concrete to add to.",
            codeLine: 6,
          });

          dp[1] = nums[0];
          tag[1] = "take house 1";
          steps.push({
            title: `Base: dp[1] = ${nums[0]}`,
            tracks: [
              track("houses", nums, paint(fill(n, "done"), { 0: "read" })),
              { label: "dp (best from first i houses)", cells: dpCells(1) },
            ],
            counters: [count("houses", n), count("cells filled", 2)],
            legend: LEG,
            happened: `With only house 1 available there is no neighbour to clash with, so the best is its own value ${nums[0]}.`,
            why: "The first house is always worth taking on its own, which anchors the recurrence.",
            codeLine: 7,
          });

          if (n <= 2) {
            steps.push({
              title: n === 1 ? "One house: nothing left to compare" : `Two houses: only the pair (${nums[0]}, ${nums[1]}) can clash`,
              tracks: [
                track("houses", nums, paint(fill(n, "done"), { [n - 1]: "read" })),
                { label: "dp (best from first i houses)", cells: dpCells(n) },
              ],
              counters: [count("houses", n), count("cells filled", n + 1), count("best so far", dp[n])],
              legend: LEG,
              happened: n === 1
                ? `With a single house the row is finished: the best is ${dp[1]} and no later cell exists.`
                : `House 2 can be taken only if house 1 is left alone; both options are already in the two base cells, giving ${dp[2]}.`,
              why: n === 1
                ? "The recurrence needs two earlier cells; with one house it never gets to run, so the base case is the whole answer."
                : "The very first real comparison already settles this short row, because there is nothing further along to worry about.",
              codeLine: 7,
            });
          }

          for (let i = 2; i <= n; i++) {
            const skip = dp[i - 1];
            const take = dp[i - 2] + nums[i - 1];
            dp[i] = Math.max(skip, take);
            const took = take > skip;
            tag[i] = `${skip} vs ${take}`;
            steps.push({
              title: `House ${i}: max(skip ${skip}, rob ${take}) = ${dp[i]}`,
              tracks: [
                track("houses", nums, paint(fill(n, "done"), { [i - 1]: took ? "read" : "dim" })),
                { label: "dp (best from first i houses)", cells: dpCells(i) },
              ],
              counters: [count("houses", n), count("cells filled", i + 1), count("best so far", dp[i])],
              legend: LEG,
              happened: took
                ? `Robbing house ${i} for ${nums[i - 1]} plus the best up to house ${i - 2} (${dp[i - 2]}) beats skipping: ${take} > ${skip}.`
                : `Skipping house ${i} keeps ${skip}, which is at least as good as robbing it (${take}).`,
              why: took
                ? "Taking this house only blocks its immediate neighbour, and dp[i-2] already respects that rule."
                : "When skipping ties or wins, leaving the house untouched is the safer choice.",
              codeLine: 9,
            });
          }

          let i = n;
          while (i >= 2) {
            if (dp[i] === dp[i - 1]) {
              i -= 1;
            } else {
              chosen[i - 1] = true;
              i -= 2;
            }
          }
          if (i === 1) chosen[0] = true;

          steps.push({
            title: `Answer: ${dp[n]} from houses ${chosen.map((c, k) => (c ? k + 1 : null)).filter(Boolean).join(", ") || "—"}`,
            tracks: [
              track("houses", nums, nums.map((v, k) => (chosen[k] ? "good" : "dim"))),
              { label: "dp (best from first i houses)", cells: dpCells(n).map((c, k) => (k === n ? { ...c, state: "result" } : c)) },
            ],
            counters: [count("houses", n), count("answer", dp[n])],
            legend: LEG,
            happened: `Replaying the decisions picks houses ${chosen.map((c, k) => (c ? k + 1 : null)).filter(Boolean).join(", ") || "none"} for a total of ${dp[n]}.`,
            why: "The last cell already had the value; walking backwards through equal entries recovers exactly which houses produced it.",
            codeLine: 10,
          });
          return steps;
        },
      },
      {
        name: "Memoised Recursion",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Define g(i) as the best loot obtainable from houses i onwards. At house i you either skip it (g(i+1)) or rob it and jump past its neighbour (money[i] + g(i+2)).",
          "So g(i) = max(g(i+1), money[i] + g(i+2)), with g(n) = g(n+1) = 0 past the end. The answer is g(0).",
          "Each index is solved once and remembered, so the branching recursion becomes linear.",
        ],
        problem: [
          "It reads the row from the far end and relies on the memo; without it the two-way branching would revisit the same suffixes repeatedly.",
        ],
        code: {
          c: `#include <stdio.h>

static int memo[100];

/* g(i) = best loot from houses i..n-1. */
int g(const int *a, int n, int i) {
    if (i >= n) return 0;
    if (memo[i] != -1) return memo[i];
    int skip = g(a, n, i + 1);
    int rob  = a[i] + g(a, n, i + 2);
    return memo[i] = skip > rob ? skip : rob;
}

int main(void) {
    int a[] = {2, 7, 9, 3, 1};
    int n = 5;
    for (int i = 0; i < n; i++) memo[i] = -1;
    printf("%d\\n", g(a, n, 0)); /* 12 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int g(const std::vector<int>& a, std::vector<int>& memo, int i, int n) {
    if (i >= n) return 0;
    if (memo[i] != -1) return memo[i];
    int skip = g(a, memo, i + 1, n);
    int rob  = a[i] + g(a, memo, i + 2, n);
    return memo[i] = std::max(skip, rob);
}

int main() {
    std::vector<int> a{2, 7, 9, 3, 1}, memo(a.size(), -1);
    std::cout << g(a, memo, 0, (int)a.size()) << '\\n'; // 12
}`,
        },
        steps(nums) {
          const n = nums.length;
          const memo = new Array(n).fill(null);
          const events = [];
          let calls = 0, hits = 0;
          (function g(i) {
            calls++;
            if (i >= n) {
              events.push({ type: "end", i, v: 0, calls, hits });
              return 0;
            }
            if (memo[i] != null) {
              hits++;
              events.push({ type: "hit", i, v: memo[i], calls, hits });
              return memo[i];
            }
            const skip = g(i + 1);
            const rob = nums[i] + g(i + 2);
            memo[i] = Math.max(skip, rob);
            events.push({ type: "fill", i, v: memo[i], skip, rob, calls, hits });
            return memo[i];
          })(0);

          const steps = [];
          const LEG = ["read", "result", "done", "idle"];
          const houseCells = (active) => ({
            label: "houses",
            cells: nums.map((v, i) => ({
              v,
              state: i === active ? "read" : memo[i] != null ? "done" : "idle",
            })),
          });
          const memoTrack = (active) => ({
            label: "g (best from here to the end)",
            cells: nums.map((v, i) => ({
              v: memo[i] == null ? "—" : memo[i],
              state: memo[i] == null ? "idle" : i === active ? "read" : "done",
            })),
          });

          steps.push({
            title: "Plan: decide house by house from the left",
            tracks: [houseCells(-1), memoTrack(-1)],
            counters: [count("houses", n), count("calls", 0)],
            legend: LEG,
            happened: `g(i) will mean the best loot from house i to the end. Each house is either skipped or robbed.`,
            why: "Forward recursion makes the neighbour rule local: robbing house i simply skips to i+2.",
            codeLine: 3,
          });

          events.forEach((e) => {
            if (e.type === "end") {
              steps.push({
                title: `g(${e.i}) = 0 — past the last house`,
                tracks: [houseCells(-1), memoTrack(-1)],
                counters: [count("houses", n), count("calls", e.calls), count("cache hits", e.hits)],
                legend: LEG,
                happened: `Index ${e.i} is beyond the row, so there is no loot left to take.`,
                why: "This zero is the boundary that stops the recursion and gives comparison a value to work with.",
                codeLine: 4,
              });
            } else if (e.type === "hit") {
              steps.push({
                title: `Cache hit: g(${e.i}) is already ${e.v}`,
                tracks: [houseCells(-1), memoTrack(e.i)],
                counters: [count("houses", n), count("calls", e.calls), count("cache hits", e.hits)],
                legend: LEG,
                happened: `House ${e.i} was solved before, so ${e.v} is reused instead of recomputed.`,
                why: "Remembering each suffix once is what turns the branching search into a single sweep.",
                codeLine: 5,
              });
            } else {
              const took = e.rob >= e.skip;
              steps.push({
                title: `g(${e.i}) = max(skip ${e.skip}, rob ${e.rob}) = ${e.v}`,
                tracks: [houseCells(e.i), memoTrack(e.i)],
                counters: [count("houses", n), count("calls", e.calls), count("best from " + e.i, e.v)],
                legend: LEG,
                happened: took
                  ? `Robbing house ${e.i} (${nums[e.i]}) plus g(${e.i + 2}) = ${e.rob} beats skipping (${e.skip}), so ${e.v} is stored.`
                  : `Skipping house ${e.i} keeps g(${e.i + 1}) = ${e.skip}, which beats robbing (${e.rob}).`,
                why: "Two options are compared at each house; whichever is larger is the honest best for this suffix.",
                codeLine: 7,
              });
            }
          });

          steps.push({
            title: `Answer: ${memo[0]}`,
            tracks: [
              track("houses", nums, fill(n, "dim")),
              {
                label: "g (best from here to the end)",
                cells: nums.map((v, i) => ({
                  v: memo[i] == null ? "—" : memo[i],
                  state: i === 0 ? "result" : memo[i] == null ? "idle" : "done",
                })),
              },
            ],
            counters: [count("houses", n), count("calls", calls), count("cache hits", hits), count("answer", memo[0])],
            legend: LEG,
            happened: `The very first call returns ${memo[0]}, the best loot from the whole row with no two neighbours taken.`,
            why: "Starting at house 0 covers every valid combination, so its answer is the problem's answer.",
            codeLine: 6,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------- 4. House Robber II ---------------- */
  V.register({
    id: "house-robber-ii",
    title: "House Robber II",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Same rule as House Robber, but the houses sit in a circle, so the first and last touch.",
    input: { label: "Money around the circle", default: "1, 2, 3, 1", parse: "ints" },
    approaches: [
      {
        name: "Two Linear Passes",
        complexity: "O(n) time, O(n) space",
        idea: [
          "On a circle the only new wrinkle is that house 1 and house n cannot both be taken. So every legal plan falls into one of two groups: it skips the last house, or it skips the first house.",
          "Run the straight-line House Robber DP twice: once over houses 1..n-1 (last excluded) and once over houses 2..n (first excluded).",
          "The answer is the larger of the two finished draws, because together the two passes cover every legal plan.",
        ],
        problem: [
          "Two tables mean two sweeps over nearly the same data; the O(1)-space approach runs the same two passes but keeps only two running totals.",
        ],
        code: {
          c: `#include <stdio.h>

/* Fill dp for a straight row a[lo..hi]; dp[k] uses houses lo..lo+k. */
int line(const int *a, int lo, int hi, int *dp) {
    int m = hi - lo + 1;
    if (m == 1) { dp[0] = a[lo]; return dp[0]; }
    dp[0] = a[lo];
    dp[1] = a[lo] > a[lo + 1] ? a[lo] : a[lo + 1];
    for (int k = 2; k < m; k++) {
        int skip = dp[k - 1];
        int take = dp[k - 2] + a[lo + k];
        dp[k] = skip > take ? skip : take;
    }
    return dp[m - 1];
}

int main(void) {
    int a[] = {1, 2, 3, 1};
    int n = 4, dp[100];
    if (n == 1) { printf("%d\\n", a[0]); return 0; }
    int p = line(a, 0, n - 2, dp);   /* skip the last house */
    int q = line(a, 1, n - 1, dp);   /* skip the first house */
    printf("%d\\n", p > q ? p : q);  /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int line(const std::vector<int>& a, int lo, int hi) {
    std::vector<int> dp(hi - lo + 1, 0);
    int m = (int)dp.size();
    if (m == 1) return a[lo];
    dp[0] = a[lo];
    dp[1] = std::max(a[lo], a[lo + 1]);
    for (int k = 2; k < m; k++)
        dp[k] = std::max(dp[k - 1], dp[k - 2] + a[lo + k]);
    return dp[m - 1];
}

int main() {
    std::vector<int> a{1, 2, 3, 1};
    int n = (int)a.size();
    if (n == 1) { std::cout << a[0] << '\\n'; return 0; }
    std::cout << std::max(line(a, 0, n - 2), line(a, 1, n - 1)) << '\\n'; // 4
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const LEG = ["read", "good", "result", "done", "dim", "idle"];

          if (n === 0) {
            return oneToken("", "circular house");
          }
          if (n === 1) {
            steps.push({
              title: "Only one house on the circle",
              tracks: [track("houses", nums, paint(fill(1, "idle"), { 0: "read" }))],
              counters: [count("houses", 1)],
              legend: LEG,
              happened: `A circle of one house has no neighbour clash at all — index 0 holds ${nums[0]}.`,
              why: "The first and last house are the same house, so the circle rule cannot bite.",
              codeLine: 15,
            });
            steps.push({
              title: "No pass needed",
              tracks: [track("houses", nums, paint(fill(1, "done"), { 0: "good" }))],
              counters: [count("houses", 1)],
              legend: LEG,
              happened: "With nothing to choose between, the single house is simply taken.",
              why: "Both linear passes would describe the same one house; running them is unnecessary.",
              codeLine: 16,
            });
            steps.push({
              title: "The two passes would be identical",
              tracks: [{ label: "cases", cells: [{ v: "skip last = take house 1", state: "idle" }, { v: "skip first = take house 1", state: "idle" }] }],
              counters: [count("houses", 1)],
              legend: LEG,
              happened: "Skipping the last house and skipping the first house lead to the same single house.",
              why: "Understanding why the two-case trick degenerates is part of handling these edge sizes safely.",
              codeLine: 16,
            });
            steps.push({
              title: "The straight-line rule still applies",
              tracks: [track("houses", nums, paint(fill(1, "done"), { 0: "good" })), { label: "dp (best so far)", cells: [{ v: nums[0], state: "result", tag: "only house" }] }],
              counters: [count("houses", 1), count("loot", nums[0])],
              legend: LEG,
              happened: `The plain House Robber recurrence would give dp[1] = max(dp[0], dp[0] + ${nums[0]}) = ${nums[0]}.`,
              why: "The circular problem contains the linear one; when the circle cannot clash it falls back to the simple rule.",
              codeLine: 6,
            });
            steps.push({
              title: `Answer: ${nums[0]}`,
              tracks: [track("houses", nums, fill(1, "result"))],
              counters: [count("houses", 1), count("answer", nums[0])],
              legend: LEG,
              happened: `The only plan takes house 1 for ${nums[0]}.`,
              why: "A one-house circle has exactly one legal loot.",
              codeLine: 16,
            });
            return steps;
          }

          const results = [];
          const runs = [
            { lo: 0, hi: n - 2, label: "pass 1 — skip the last house", note: `houses 1..${n - 1}` },
            { lo: 1, hi: n - 1, label: "pass 2 — skip the first house", note: `houses 2..${n}` },
          ];

          runs.forEach((run, ri) => {
            const arr = nums.slice(run.lo, run.hi + 1);
            const m = arr.length;
            const dp = new Array(m).fill(null);
            const chosen = new Array(n).fill(false);
            const houseCells = (active) => {
              const cells = nums.map((v, i) => ({
                v,
                state: i < run.lo || i > run.hi ? "dim" : chosen[i] ? "good" : i === active ? "read" : "done",
                tag: chosen[i] ? "robbed" : undefined,
              }));
              return track(run.label, cells.map((c) => c.v), cells.map((c) => c.state), cells.map((c) => c.tag));
            };
            const dpCells = (active) =>
              dp.map((v, k) => ({
                v: v == null ? "—" : v,
                state: v == null ? "idle" : k === active ? "read" : "done",
              }));

            steps.push({
              title: `${run.label} (${run.note})`,
              tracks: [
                track(run.label, nums, nums.map((_, i) => (i < run.lo || i > run.hi ? "dim" : "idle"))),
                { label: "dp for this pass", cells: dpCells(-1) },
              ],
              counters: [count("pass", ri + 1, 2), count("houses in this pass", m)],
              legend: LEG,
              happened: `Cut the circle at ${ri === 0 ? "the last house" : "the first house"} and it becomes a straight row of ${m} house${m === 1 ? "" : "s"}.`,
              why: "Each plan either misses house 1 or misses house n; handling both cases on a line covers all of them.",
              codeLine: 11,
            });

            dp[0] = arr[0];
            steps.push({
              title: `Base: dp[0] = ${arr[0]}`,
              tracks: [
                track(run.label, nums, nums.map((_, i) => (i < run.lo || i > run.hi ? "dim" : i === run.lo ? "read" : "done"))),
                { label: "dp for this pass", cells: dpCells(0) },
              ],
              counters: [count("pass", ri + 1, 2), count("houses in this pass", m)],
              legend: LEG,
              happened: `The first house of this row is ${arr[0]}, worth taking on its own.`,
              why: "As in the straight version, one house has no neighbour to conflict with.",
              codeLine: 6,
            });

            if (m >= 2) {
              dp[1] = Math.max(arr[0], arr[1]);
              steps.push({
                title: `Base: dp[1] = max(${arr[0]}, ${arr[1]}) = ${dp[1]}`,
                tracks: [
                  track(run.label, nums, nums.map((_, i) => (i < run.lo || i > run.hi ? "dim" : i <= run.lo + 1 ? "read" : "done"))),
                  { label: "dp for this pass", cells: dpCells(1) },
                ],
                counters: [count("pass", ri + 1, 2), count("houses in this pass", m)],
                legend: LEG,
                happened: `Two houses clash, so only the richer one can be taken: ${dp[1]}.`,
                why: "This small base is exactly the straight-line House Robber rule applied to the first two.",
                codeLine: 7,
              });
            }

            for (let k = 2; k < m; k++) {
              const skip = dp[k - 1];
              const take = dp[k - 2] + arr[k];
              dp[k] = Math.max(skip, take);
              steps.push({
                title: `House ${run.lo + k + 1}: max(${skip}, ${take}) = ${dp[k]}`,
                tracks: [
                  track(run.label, nums, nums.map((_, i) => (i < run.lo || i > run.hi ? "dim" : i === run.lo + k ? (take > skip ? "read" : "dim") : "done"))),
                  { label: "dp for this pass", cells: dpCells(k) },
                ],
                counters: [count("pass", ri + 1, 2), count("houses in this pass", m), count("best in this pass", dp[k])],
                legend: LEG,
                happened: `Within this straight row, robbing house ${run.lo + k + 1} gives ${take} versus skipping for ${skip}.`,
                why: "The same recurrence as the linear problem — the circle has already been cut, so nothing else changes.",
                codeLine: 9,
              });
            }

            let k = m - 1;
            while (k >= 1) {
              if (dp[k] === dp[k - 1]) k -= 1;
              else { chosen[run.lo + k] = true; k -= 2; }
            }
            if (k === 0) chosen[run.lo] = true;
            results.push(dp[m - 1]);

            steps.push({
              title: `Pass ${ri + 1} result: ${dp[m - 1]}`,
              tracks: [
                track(run.label, nums, nums.map((_, i) => (i < run.lo || i > run.hi ? "dim" : chosen[i] ? "good" : "done"))),
                { label: "dp for this pass", cells: dpCells(m - 1).map((c, x) => (x === m - 1 ? { ...c, state: "result" } : c)) },
              ],
              counters: [count("pass", ri + 1, 2), count("best in this pass", dp[m - 1])],
              legend: LEG,
              happened: `This pass settles on houses ${chosen.map((c, i) => (c ? i + 1 : null)).filter(Boolean).join(", ")} for ${dp[m - 1]}.`,
              why: "Walking back through equal dp entries reveals which houses the best plan actually took.",
              codeLine: 11,
            });
          });

          const best = Math.max(results[0], results[1]);
          steps.push({
            title: `Answer: max(${results[0]}, ${results[1]}) = ${best}`,
            tracks: [
              track("houses", nums, fill(n, "dim")),
              {
                label: "the two cut points",
                cells: [
                  { v: results[0], state: results[0] === best ? "result" : "dim", tag: "skip last" },
                  { v: results[1], state: results[1] === best ? "result" : "dim", tag: "skip first" },
                ],
              },
            ],
            counters: [count("passes run", 2, 2), count("answer", best)],
            legend: LEG,
            happened: `Skipping the last house yields ${results[0]}; skipping the first yields ${results[1]}. The better circle plan is ${best}.`,
            why: "Every legal plan appears in at least one of the two passes, so the maximum of the two is the true answer.",
            codeLine: 17,
          });
          return steps;
        },
      },
      {
        name: "Two Passes, O(1) Space",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Same two-case idea, but the straight-line sweep keeps only two running totals instead of a table: prev2 is the best up to two houses back, prev1 the best up to the previous house.",
          "For each house, cur = max(prev1, prev2 + money). Then slide the window forward: prev2 = prev1, prev1 = cur.",
          "Run that sweep once skipping the last house and once skipping the first, then take the larger result.",
        ],
        problem: [
          "The saved memory costs the ability to replay which houses were taken — the running totals keep the value but not the choices.",
        ],
        code: {
          c: `#include <stdio.h>

/* Best loot on the straight row a[lo..hi], using two variables. */
int line(const int *a, int lo, int hi) {
    int prev2 = 0, prev1 = 0;
    for (int i = lo; i <= hi; i++) {
        int cur = prev1 > prev2 + a[i] ? prev1 : prev2 + a[i];
        prev2 = prev1;
        prev1 = cur;
    }
    return prev1;
}

int main(void) {
    int a[] = {1, 2, 3, 1};
    int n = 4;
    if (n == 1) { printf("%d\\n", a[0]); return 0; }
    int p = line(a, 0, n - 2);       /* skip the last house */
    int q = line(a, 1, n - 1);       /* skip the first house */
    printf("%d\\n", p > q ? p : q);  /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int line(const std::vector<int>& a, int lo, int hi) {
    int prev2 = 0, prev1 = 0;            // best from two back, one back
    for (int i = lo; i <= hi; i++) {
        int cur = std::max(prev1, prev2 + a[i]);
        prev2 = prev1;
        prev1 = cur;                     // slide the window
    }
    return prev1;
}

int main() {
    std::vector<int> a{1, 2, 3, 1};
    int n = (int)a.size();
    if (n == 1) { std::cout << a[0] << '\\n'; return 0; }
    std::cout << std::max(line(a, 0, n - 2), line(a, 1, n - 1)) << '\\n'; // 4
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const LEG = ["read", "result", "done", "dim", "idle"];

          if (n === 1) {
            steps.push({
              title: "One house, one choice",
              tracks: [track("houses", nums, paint(fill(1, "idle"), { 0: "read" }))],
              counters: [count("houses", 1)],
              legend: LEG,
              happened: `There is a single house worth ${nums[0]}.`,
              why: "A one-house circle has no neighbour, so the running-total sweep never even needs two variables.",
              codeLine: 6,
            });
            steps.push({
              title: "Both passes coincide",
              tracks: [{ label: "cases", cells: [{ v: "skip last", state: "idle" }, { v: "skip first", state: "idle" }] }],
              counters: [count("houses", 1)],
              legend: LEG,
              happened: "Skipping the last and skipping the first both leave the same single house.",
              why: "Recognising this degenerate case keeps the two-pass idea from doing needless work.",
              codeLine: 6,
            });
            steps.push({
              title: "Nothing to carry yet",
              tracks: [{ label: "running totals", cells: [{ v: 0, state: "idle", tag: "two back" }, { v: 0, state: "idle", tag: "one back" }] }],
              counters: [count("houses", 1)],
              legend: LEG,
              happened: "prev2 and prev1 would both start at 0 before the single house is read.",
              why: "The window starts empty because no house has been considered.",
              codeLine: 3,
            });
            steps.push({
              title: "Sweeping one house: max(0, 0 + " + nums[0] + ") = " + nums[0],
              tracks: [
                track("houses", nums, paint(fill(1, "done"), { 0: "read" })),
                { label: "running totals", cells: [{ v: 0, state: "done", tag: "two back" }, { v: nums[0], state: "result", tag: "one back" }] },
              ],
              counters: [count("houses", 1), count("best in this pass", nums[0])],
              legend: LEG,
              happened: `The single house is read: skipping gives 0, robbing gives 0 + ${nums[0]}, so the carried total becomes ${nums[0]}.`,
              why: "The sweep does not need a special case — it simply runs once and carries the answer forward.",
              codeLine: 5,
            });
            steps.push({
              title: `Answer: ${nums[0]}`,
              tracks: [track("houses", nums, fill(1, "result"))],
              counters: [count("houses", 1), count("answer", nums[0])],
              legend: LEG,
              happened: `The only legal loot is ${nums[0]}.`,
              why: "With one house the circle rule is vacuous.",
              codeLine: 6,
            });
            return steps;
          }

          const results = [];
          const runs = [
            { lo: 0, hi: n - 2, label: "pass 1 — skip last" },
            { lo: 1, hi: n - 1, label: "pass 2 — skip first" },
          ];

          runs.forEach((run, ri) => {
            let prev2 = 0, prev1 = 0;
            const runCells = () => ({
              label: "running totals",
              cells: [
                { v: prev2, state: "done", tag: "two back" },
                { v: prev1, state: "result", tag: "one back" },
              ],
            });

            steps.push({
              title: `${run.label}: window starts at 0, 0`,
              tracks: [
                track(run.label, nums, nums.map((_, i) => (i < run.lo || i > run.hi ? "dim" : "idle"))),
                runCells(),
              ],
              counters: [count("pass", ri + 1, 2), count("houses in this pass", run.hi - run.lo + 1)],
              legend: LEG,
              happened: `Cut the circle to the row of house indices ${run.lo + 1} to ${run.hi + 1}.`,
              why: "The circle is broken into a line so the plain House Robber rule applies; two totals are enough to sweep it.",
              codeLine: 3,
            });

            for (let i = run.lo; i <= run.hi; i++) {
              const cur = Math.max(prev1, prev2 + nums[i]);
              const took = prev2 + nums[i] > prev1;
              const shownPrev2 = prev2, shownPrev1 = prev1;
              prev2 = prev1;
              prev1 = cur;
              steps.push({
                title: `House ${i + 1}: max(${shownPrev1}, ${shownPrev2} + ${nums[i]}) = ${cur}`,
                tracks: [
                  track(run.label, nums, nums.map((_, k) => (k < run.lo || k > run.hi ? "dim" : k === i ? (took ? "read" : "dim") : "done"))),
                  runCells(),
                ],
                counters: [count("pass", ri + 1, 2), count("house", i + 1, n), count("best in this pass", cur)],
                legend: LEG,
                happened: took
                  ? `Robbing house ${i + 1} for ${nums[i]} on top of ${shownPrev2} beats skipping: ${cur}.`
                  : `Skipping house ${i + 1} keeps ${shownPrev1}, at least as good as robbing for ${prev2 + nums[i]}.`,
                why: "Only the two most recent totals matter, so the older ones are dropped as the window slides.",
                codeLine: 5,
              });
            }

            results.push(prev1);
            steps.push({
              title: `Pass result: ${prev1}`,
              tracks: [
                track(run.label, nums, nums.map((_, i) => (i < run.lo || i > run.hi ? "dim" : "done"))),
                { label: "running totals", cells: [{ v: prev1, state: "result", tag: "best of this pass" }] },
              ],
              counters: [count("pass", ri + 1, 2), count("best in this pass", prev1)],
              legend: LEG,
              happened: `After the last house of this pass the carried total is ${prev1}.`,
              why: "The single carried value is this pass's whole answer — nothing else needs to be remembered.",
              codeLine: 7,
            });
          });

          const best = Math.max(results[0], results[1]);
          steps.push({
            title: `Answer: max(${results[0]}, ${results[1]}) = ${best}`,
            tracks: [
              track("houses", nums, fill(n, "dim")),
              {
                label: "the two cut points",
                cells: [
                  { v: results[0], state: results[0] === best ? "result" : "dim", tag: "skip last" },
                  { v: results[1], state: results[1] === best ? "result" : "dim", tag: "skip first" },
                ],
              },
            ],
            counters: [count("passes run", 2, 2), count("answer", best)],
            legend: LEG,
            happened: `The two swept totals are ${results[0]} and ${results[1]}; the better is ${best}.`,
            why: "Both cases are covered by the two sweeps, and only a handful of variables were used to find them.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------- 5. Tribonacci Number ---------------- */
  V.register({
    id: "tribonacci-number",
    title: "Tribonacci Number",
    category: "Dynamic Programming",
    difficulty: "Beginner",
    description: "Like Fibonacci, but each term adds the previous three: 0, 1, 1, 2, 4, 7, 13, ...",
    input: { label: "Which term (index)", default: "7", parse: "int" },
    approaches: [
      {
        name: "Bottom-Up Table",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Let T[i] be the i-th tribonacci number. Its definition is T[i] = T[i-1] + T[i-2] + T[i-3].",
          "The three seeds are T[0] = 0, T[1] = 1 and T[2] = 1; with those fixed, one left-to-right pass fills the row.",
          "The requested cell T[n] is the answer.",
        ],
        problem: [
          "A full row is stored even though each term only reads the previous three; the rolling-window approach shows the leaner version.",
        ],
        code: {
          c: `#include <stdio.h>

/* T[0]=0, T[1]=1, T[2]=1; then the sum of the last three. */
int trib(int n) {
    if (n == 0) return 0;
    if (n < 3) return 1;
    int T[64];
    T[0] = 0; T[1] = 1; T[2] = 1;
    for (int i = 3; i <= n; i++)
        T[i] = T[i - 1] + T[i - 2] + T[i - 3];
    return T[n];
}

int main(void) {
    printf("%d\\n", trib(7)); /* 24 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

int trib(int n) {
    if (n == 0) return 0;
    if (n < 3) return 1;
    std::vector<int> T(n + 1, 0);
    T[1] = 1;
    T[2] = 1;                              // seeds
    for (int i = 3; i <= n; i++)
        T[i] = T[i - 1] + T[i - 2] + T[i - 3];
    return T[n];
}

int main() {
    std::cout << trib(7) << '\\n';          // 24
}`,
        },
        steps(parsed) {
          const raw = Number(parsed);
          const n = Number.isFinite(raw) ? raw : 0;
          const trimmed = n > 30 || n < 0;
          const N = Math.max(0, Math.min(30, n));
          const T = new Array(N + 1).fill(null);
          const tag = new Array(N + 1).fill(undefined);
          const steps = [];
          const LEG = ["read", "result", "done", "idle"];
          const cells = (active) =>
            T.map((v, i) => ({
              v: v == null ? "—" : v,
              state: v == null ? "idle" : i === active ? "read" : "done",
              tag: tag[i],
            }));

          steps.push({
            title: `The question: term number ${N}`,
            tracks: [track("term index", Array.from({ length: N + 1 }, (_, i) => i), fill(N + 1, "idle"))],
            counters: [count("term asked", N)],
            legend: LEG,
            happened: trimmed
              ? `The input was ${n}; the row is trimmed to index ${N} for readability. Each term is the sum of the previous three.`
              : `Term ${N} of the tribonacci sequence is wanted; each term adds the previous three.`,
            why: "Directly multiplying out the recursion would be exponential, so the plan is to build the row from the start.",
            codeLine: 3,
          });

          steps.push({
            title: "Recurrence: T[i] = T[i-1] + T[i-2] + T[i-3]",
            tracks: [{ label: "T (tribonacci term)", cells: cells(-1) }],
            counters: [count("term asked", N), count("cells filled", 0)],
            legend: LEG,
            happened: "An empty row T[0..n] is ready, one slot per term.",
            why: "Three previous values appear in the rule, so the first three cells must be seeded by hand.",
            codeLine: 6,
          });

          T[0] = 0;
          tag[0] = "seed";
          steps.push({
            title: "Seed: T[0] = 0",
            tracks: [{ label: "T (tribonacci term)", cells: cells(0) }],
            counters: [count("term asked", N), count("cells filled", 1)],
            legend: LEG,
            happened: "The sequence is defined to begin at 0.",
            why: "Seeds are given, not computed; they are the floor the recurrence stands on.",
            codeLine: 7,
          });

          if (N >= 1) {
            T[1] = 1;
            tag[1] = "seed";
            steps.push({
              title: "Seed: T[1] = 1",
              tracks: [{ label: "T (tribonacci term)", cells: cells(1) }],
              counters: [count("term asked", N), count("cells filled", 2)],
              legend: LEG,
              happened: "The second seed is 1.",
              why: "With two seeds in place one more is still needed before the rule can run.",
              codeLine: 7,
            });
          }
          if (N >= 2) {
            T[2] = 1;
            tag[2] = "seed";
            steps.push({
              title: "Seed: T[2] = 1",
              tracks: [{ label: "T (tribonacci term)", cells: cells(2) }],
              counters: [count("term asked", N), count("cells filled", 3)],
              legend: LEG,
              happened: "The third seed is also 1.",
              why: "Three seeds are exactly what the three-term rule needs to start producing new values.",
              codeLine: 7,
            });
          }

          for (let i = 3; i <= N; i++) {
            T[i] = T[i - 1] + T[i - 2] + T[i - 3];
            tag[i] = `${T[i - 1]}+${T[i - 2]}+${T[i - 3]}`;
            steps.push({
              title: `T[${i}] = ${T[i - 1]} + ${T[i - 2]} + ${T[i - 3]} = ${T[i]}`,
              tracks: [{ label: "T (tribonacci term)", cells: cells(i) }],
              counters: [count("term asked", N), count("cells filled", i + 1), count("term " + i, T[i])],
              legend: LEG,
              happened: `Term ${i} sums the three before it: ${T[i - 1]} + ${T[i - 2]} + ${T[i - 3]} = ${T[i]}.`,
              why: "Each new term only needs its three predecessors, and all three are already known.",
              codeLine: 9,
            });
          }

          if (N < 3) {
            steps.push({
              title: "The seeds already answer it",
              tracks: [{ label: "T (tribonacci term)", cells: cells(N) }],
              counters: [count("term asked", N), count("cells filled", N + 1)],
              legend: LEG,
              happened: `Index ${N} is one of the seeds, so no summation step is needed.`,
              why: "The recurrence only starts once all three seeds exist; small indices are answered directly.",
              codeLine: 4,
            });
          }

          steps.push({
            title: `Answer: T[${N}] = ${T[N]}`,
            tracks: [{ label: "T (tribonacci term)", cells: cells(N).map((c, i) => (i === N ? { ...c, state: "result" } : c)) }],
            counters: [count("term asked", N), count("answer", T[N])],
            legend: LEG,
            happened: `The requested term ${N} is ${T[N]}.`,
            why: "One pass of three-way sums produced every term up to the one asked for.",
            codeLine: 10,
          });
          return steps;
        },
      },
      {
        name: "Rolling Three Variables",
        complexity: "O(n) time, O(1) space",
        idea: [
          "The rule only ever looks at the previous three terms, so keep exactly three variables: a = T[i-3], b = T[i-2], c = T[i-1].",
          "Each step computes d = a + b + c, then slides the window: a = b, b = c, c = d.",
          "After n slides c holds T[n], with no array needed.",
        ],
        problem: [
          "Sliding the window discards older terms, so you cannot later ask for, say, T[n/2] without recomputing the whole run.",
        ],
        code: {
          c: `#include <stdio.h>

int trib(int n) {
    if (n == 0) return 0;
    if (n < 3) return 1;
    int a = 0, b = 1, c = 1;              /* T[0], T[1], T[2] */
    for (int i = 3; i <= n; i++) {
        int d = a + b + c;
        a = b; b = c; c = d;              /* slide the window */
    }
    return c;
}

int main(void) {
    printf("%d\\n", trib(7)); /* 24 */
    return 0;
}`,
          cpp: `#include <iostream>

int trib(int n) {
    if (n == 0) return 0;
    if (n < 3) return 1;
    int a = 0, b = 1, c = 1;             // T[0], T[1], T[2]
    for (int i = 3; i <= n; i++) {
        int d = a + b + c;
        a = b; b = c; c = d;             // slide
    }
    return c;
}

int main() {
    std::cout << trib(7) << '\\n';         // 24
}`,
        },
        steps(parsed) {
          const raw = Number(parsed);
          const n = Number.isFinite(raw) ? raw : 0;
          const trimmed = n > 30 || n < 0;
          const N = Math.max(0, Math.min(30, n));
          let a = 0, b = 1, c = 1;
          const steps = [];
          const LEG = ["read", "result", "done", "idle"];
          const window = () => ({
            label: "the three carried terms",
            cells: [
              { v: a, state: "done", tag: "T[i-3]" },
              { v: b, state: "done", tag: "T[i-2]" },
              { v: c, state: "result", tag: "T[i-1]" },
            ],
          });

          steps.push({
            title: `Three carried terms are enough for any index`,
            tracks: [window()],
            counters: [count("term asked", N)],
            legend: LEG,
            happened: trimmed
              ? `The input was ${n}; the run is capped at index ${N}. Only the last three terms are kept at any moment.`
              : `To reach term ${N} the rule never needs more than the last three terms.`,
            why: "Because each new term is a sum of three predecessors, older terms become irrelevant immediately.",
            codeLine: 5,
          });

          steps.push({
            title: "Seed the window: 0, 1, 1",
            tracks: [{ label: "the three carried terms", cells: [{ v: 0, state: "done", tag: "T[0]" }, { v: 1, state: "done", tag: "T[1]" }, { v: 1, state: "done", tag: "T[2]" }] }],
            counters: [count("term asked", N), count("window", "0,1,1")],
            legend: LEG,
            happened: "The three seeds 0, 1, 1 fill the window.",
            why: "These are given by definition and are the only fixed values the algorithm ever needs.",
            codeLine: 5,
          });

          for (let i = 3; i <= N; i++) {
            const d = a + b + c;
            const shown = `T[${i}] = ${a} + ${b} + ${c} = ${d}`;
            const before = window();
            a = b; b = c; c = d;
            steps.push({
              title: shown,
              tracks: [window()],
              counters: [count("term", i, N), count("term " + i, d), count("window size", 3)],
              legend: LEG,
              happened: `Term ${i} is the sum of the window, and then the window slides forward by one.`,
              why: "The sum plus the slide is the whole algorithm — one addition and three assignments per term.",
              codeLine: 7,
            });
          }

          if (N < 3) {
            steps.push({
              title: "Small index: a seed is the answer",
              tracks: [window()],
              counters: [count("term asked", N)],
              legend: LEG,
              happened: `Index ${N} of the sequence is already one of the seeds.`,
              why: "The slide loop only begins at index 3, so small asks are answered from the seeds directly.",
              codeLine: 3,
            });
          }

          const ans = N === 0 ? 0 : N < 3 ? 1 : c;
          steps.push({
            title: `Answer: T[${N}] = ${ans}`,
            tracks: [{ label: "the three carried terms", cells: [{ v: ans, state: "result", tag: `T[${N}]` }] }],
            counters: [count("term asked", N), count("answer", ans)],
            legend: LEG,
            happened: `With the window slid ${Math.max(0, N - 2)} time${Math.max(0, N - 2) === 1 ? "" : "s"}, the newest term is ${ans}.`,
            why: "Only three numbers were ever stored, yet the same answer as the full table was produced.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------- 6. Longest Common Subsequence ---------------- */
  V.register({
    id: "longest-common-subsequence",
    title: "Longest Common Subsequence",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Find the length of the longest run of letters that appears in order inside both words.",
    input: { label: "Two words separated by a space", default: "abcde ace", parse: "string" },
    approaches: [
      {
        name: "Full DP Table",
        complexity: "O(m·n) time, O(m·n) space",
        idea: [
          "Lay one word along the rows and the other along the columns. Cell (r, c) asks: what is the longest common subsequence of the first r letters of the row word and the first c letters of the column word?",
          "If the two new letters match, that letter can end the subsequence, so dp[r][c] = dp[r-1][c-1] + 1. If they differ, the best must drop one of them: dp[r][c] = max(dp[r-1][c], dp[r][c-1]).",
          "Row 0 and column 0 mean 'one side is empty', so they are all zero. The bottom-right cell is the answer.",
        ],
        problem: [
          "The table costs one cell per pair of prefixes — O(m·n) memory — although only two rows are ever needed to get the length alone.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

/* dp[r][c] = LCS length of b[0..r-1] and a[0..c-1]. */
int lcs(const char *a, const char *b) {
    int n = strlen(a), m = strlen(b);
    int dp[64][64];
    for (int c = 0; c <= n; c++) dp[0][c] = 0;
    for (int r = 0; r <= m; r++) dp[r][0] = 0;
    for (int r = 1; r <= m; r++) {
        for (int c = 1; c <= n; c++) {
            if (b[r - 1] == a[c - 1])
                dp[r][c] = dp[r - 1][c - 1] + 1;
            else {
                int up = dp[r - 1][c], left = dp[r][c - 1];
                dp[r][c] = up > left ? up : left;
            }
        }
    }
    return dp[m][n];
}

int main(void) {
    printf("%d\\n", lcs("abcde", "ace")); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

int lcs(const std::string& a, const std::string& b) {
    int n = (int)a.size(), m = (int)b.size();
    std::vector<std::vector<int>> dp(m + 1, std::vector<int>(n + 1, 0));
    for (int r = 1; r <= m; r++)
        for (int c = 1; c <= n; c++)
            if (b[r - 1] == a[c - 1])
                dp[r][c] = dp[r - 1][c - 1] + 1;         // letter matches
            else
                dp[r][c] = std::max(dp[r - 1][c], dp[r][c - 1]);
    return dp[m][n];
}

int main() {
    std::cout << lcs("abcde", "ace") << '\\n'; // 3
}`,
        },
        steps(parsed) {
          const parts = tokens(parsed);
          const first = parts[0] || "";
          const second = parts[1] || "";
          if (!second) return oneToken(first, "subsequence");

          const cut = first.length > 12 || second.length > 12;
          const s1 = first.slice(0, 12);   // columns
          const s2 = second.slice(0, 12);  // rows
          const rows = s2.length + 1, cols = s1.length + 1;
          const rowHeads = [""].concat(s2.split(""));
          const colHeads = [""].concat(s1.split(""));
          const dp = Array.from({ length: rows }, () => new Array(cols).fill(null));
          const st = Array.from({ length: rows }, () => new Array(cols).fill("done"));
          const steps = [];
          const LEG = ["read", "good", "done", "idle"];
          const cells = (cur, curState) => {
            const out = [];
            for (let r = 0; r < rows; r++)
              for (let c = 0; c < cols; c++)
                if (dp[r][c] != null)
                  out.push({ r, c, v: dp[r][c], state: cur && cur.r === r && cur.c === c ? curState || "read" : st[r][c] });
            return out;
          };

          for (let c = 0; c < cols; c++) dp[0][c] = 0;
          for (let r = 0; r < rows; r++) dp[r][0] = 0;

          steps.push({
            title: "Set up: a table with a zero border",
            kind: "grid", rows, cols, rowHeads, colHeads,
            cells: cells(null),
            label: `rows = "${s2}", columns = "${s1}"`,
            counters: [count("cell", "—"), count("cells filled", rows + cols - 1)],
            legend: LEG,
            happened: cut
              ? `The words were trimmed to "${s1}" and "${s2}" so the table stays a readable size. Row 0 and column 0 are all 0.`
              : `Cell (r, c) will hold the longest common subsequence of the first r letters of "${s2}" and the first c letters of "${s1}". Row 0 and column 0 are all 0.`,
            why: "The recurrence reads a cell's up, left and diagonal neighbours, so the border must exist before the interior.",
            codeLine: 6,
          });

          let filled = rows + cols - 1;
          for (let r = 1; r < rows; r++) {
            for (let c = 1; c < cols; c++) {
              const up = dp[r - 1][c];
              const left = dp[r][c - 1];
              const matched = s2[r - 1] === s1[c - 1];
              let v, title;
              if (matched) {
                v = dp[r - 1][c - 1] + 1;
                st[r][c] = "good";
                title = `dp[${r}][${c}]: ${s2[r - 1]} = ${s1[c - 1]} → 1 + dp[${r - 1}][${c - 1}] = ${v}`;
              } else {
                v = Math.max(up, left);
                st[r][c] = "done";
                title = `dp[${r}][${c}]: ${s2[r - 1]} ≠ ${s1[c - 1]} → max(${up}, ${left}) = ${v}`;
              }
              dp[r][c] = v;
              filled++;
              steps.push({
                title,
                kind: "grid", rows, cols, rowHeads, colHeads,
                cells: cells({ r, c }, matched ? "read" : "read"),
                counters: [count("cell", `(${r}, ${c})`), count("total length", v), count("cells filled", filled)],
                legend: LEG,
                happened: matched
                  ? `Letter "${s2[r - 1]}" matches, so it extends the subsequence found for the two prefixes just before it.`
                  : `The letters differ, so the best subsequence must give up either the row letter (${up}) or the column letter (${left}).`,
                why: matched
                  ? "Matching letters can always end a common subsequence, so the diagonal is the only source to grow from."
                  : "One of the two letters cannot be used in the same subsequence, hence the larger of the two one-sided values.",
                codeLine: matched ? 10 : 12,
              });
            }
          }

          steps.push({
            title: `Answer: longest common subsequence length ${dp[rows - 1][cols - 1]}`,
            kind: "grid", rows, cols, rowHeads, colHeads,
            cells: cells({ r: rows - 1, c: cols - 1 }, "result"),
            label: "bottom-right cell holds the answer",
            counters: [count("cells filled", filled), count("answer", dp[rows - 1][cols - 1])],
            legend: LEG,
            happened: `The bottom-right cell is ${dp[rows - 1][cols - 1]} — the longest shared subsequence of both words.`,
            why: "It compares the full words, which is exactly the question; every smaller cell fed into it.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------- 7. Longest Palindromic Subsequence ---------------- */
  V.register({
    id: "longest-palindromic-subsequence",
    title: "Longest Palindromic Subsequence",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Find how long the longest chunk that reads the same forwards and backwards can be.",
    input: { label: "A word", default: "bbbab", parse: "string" },
    approaches: [
      {
        name: "Diagonal DP Table",
        complexity: "O(n²) time, O(n²) space",
        idea: [
          "Let dp[i][j] be the longest palindromic subsequence inside the slice s[i..j]. Every slice of one letter is a palindrome of length 1, so dp[i][i] = 1.",
          "If the two end letters match, they can wrap the palindrome found inside: dp[i][j] = dp[i+1][j-1] + 2. If they differ, drop one end: dp[i][j] = max(dp[i+1][j], dp[i][j-1]).",
          "Filling by increasing slice length means every smaller slice a cell depends on is already known. The whole-word cell dp[0][n-1] is the answer.",
        ],
        problem: [
          "Only the upper triangle (i ≤ j) is meaningful, and the table is O(n²) — more than a single word usually needs.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

/* dp[i][j] = longest palindromic subsequence in s[i..j]. */
int lps(const char *s) {
    int n = strlen(s);
    int dp[64][64];
    for (int i = 0; i < n; i++) dp[i][i] = 1;
    for (int len = 2; len <= n; len++) {
        for (int i = 0; i + len - 1 < n; i++) {
            int j = i + len - 1;
            if (s[i] == s[j])
                dp[i][j] = dp[i + 1][j - 1] + 2;
            else {
                int a = dp[i + 1][j], b = dp[i][j - 1];
                dp[i][j] = a > b ? a : b;
            }
        }
    }
    return n ? dp[0][n - 1] : 0;
}

int main(void) {
    printf("%d\\n", lps("bbbab")); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

int lps(const std::string& s) {
    int n = (int)s.size();
    if (!n) return 0;
    std::vector<std::vector<int>> dp(n, std::vector<int>(n, 0));
    for (int i = 0; i < n; i++) dp[i][i] = 1;
    for (int len = 2; len <= n; len++)
        for (int i = 0; i + len - 1 < n; i++) {
            int j = i + len - 1;
            if (s[i] == s[j])
                dp[i][j] = dp[i + 1][j - 1] + 2;   // wrap the inner palindrome
            else
                dp[i][j] = std::max(dp[i + 1][j], dp[i][j - 1]);
        }
    return dp[0][n - 1];
}

int main() {
    std::cout << lps("bbbab") << '\\n'; // 4
}`,
        },
        steps(parsed) {
          const word = String(parsed).trim().replace(/\s+/g, "");
          if (!word) return oneToken(String(parsed).trim(), "palindrome");
          const cut = word.length > 12;
          const s = word.slice(0, 12);
          const n = s.length;
          const heads = s.split("");
          const dp = Array.from({ length: n }, () => new Array(n).fill(null));
          const st = Array.from({ length: n }, () => new Array(n).fill("done"));
          const steps = [];
          const LEG = ["read", "good", "done", "idle"];
          const cells = (cur) => {
            const out = [];
            for (let i = 0; i < n; i++)
              for (let j = i; j < n; j++)
                if (dp[i][j] != null)
                  out.push({ r: i, c: j, v: dp[i][j], state: cur && cur.i === i && cur.j === j ? "read" : st[i][j] });
            return out;
          };

          steps.push({
            title: "Set up: every single-letter slice is a palindrome",
            kind: "grid", rows: n, cols: n, rowHeads: heads, colHeads: heads,
            cells: [],
            label: "cell (i, j) = longest palindrome inside s[i..j]; only the upper triangle matters",
            counters: [count("slice length", 1), count("cells filled", 0)],
            legend: LEG,
            happened: cut
              ? `The word was trimmed to "${s}" so the square table stays readable. Only cells with i ≤ j will be used.`
              : `The word is "${s}". Cell (i, j) will hold the longest palindromic subsequence inside the slice s[i..j].`,
            why: "Slices grow from single letters outward; using i ≤ j keeps to the meaningful half of the square.",
            codeLine: 4,
          });

          steps.push({
            title: "Recurrence: match ends, or drop one end",
            kind: "grid", rows: n, cols: n, rowHeads: heads, colHeads: heads,
            cells: [],
            label: "match → dp[i+1][j-1] + 2 ; otherwise → max(dp[i+1][j], dp[i][j-1])",
            counters: [count("slice length", 1), count("cells filled", 0)],
            legend: LEG,
            happened: "Two end letters decide each cell: equal ends can wrap the inner palindrome, unequal ends lose one letter.",
            why: "Wrapping expands a palindrome by two; dropping an end steps down to the next smaller slice, so the recursion shrinks.",
            codeLine: 7,
          });

          for (let i = 0; i < n; i++) { dp[i][i] = 1; st[i][i] = "good"; }
          steps.push({
            title: "Base: every one-letter slice is length 1",
            kind: "grid", rows: n, cols: n, rowHeads: heads, colHeads: heads,
            cells: cells(null),
            label: "the main diagonal is filled with 1",
            counters: [count("slice length", 1), count("cells filled", n)],
            legend: LEG,
            happened: "The main diagonal dp[i][i] is set to 1 for every letter.",
            why: "A single letter is trivially its own palindrome; these are the smallest slices all larger ones build on.",
            codeLine: 5,
          });

          let filled = n;
          for (let len = 2; len <= n; len++) {
            for (let i = 0; i + len - 1 < n; i++) {
              const j = i + len - 1;
              const matched = s[i] === s[j];
              let v, title;
              if (matched && len === 2) {
                v = 2;
                st[i][j] = "good";
                title = `dp[${i}][${j}]: "${s[i]}" = "${s[j]}" → two equal ends = ${v}`;
              } else if (matched) {
                v = dp[i + 1][j - 1] + 2;
                st[i][j] = "good";
                title = `dp[${i}][${j}]: "${s[i]}" = "${s[j]}" → 2 + dp[${i + 1}][${j - 1}] = ${v}`;
              } else {
                v = Math.max(dp[i + 1][j], dp[i][j - 1]);
                st[i][j] = "done";
                title = `dp[${i}][${j}]: "${s[i]}" ≠ "${s[j]}" → max(${dp[i + 1][j]}, ${dp[i][j - 1]}) = ${v}`;
              }
              dp[i][j] = v;
              filled++;
              steps.push({
                title,
                kind: "grid", rows: n, cols: n, rowHeads: heads, colHeads: heads,
                cells: cells({ i, j }),
                label: `slice "${s.slice(i, j + 1)}" of length ${len}`,
                counters: [count("slice length", len), count("cells filled", filled), count("best here", v)],
                legend: LEG,
                happened: matched
                  ? `The ends "${s[i]}" and "${s[j]}" match, so the palindrome inside the slice grows by two to ${v}.`
                  : `The ends differ, so the slice keeps whichever shorter palindrome is longer, ${v}.`,
                why: matched
                  ? "Matching ends can always be placed around an inner palindrome, gaining two letters."
                  : "Unequal ends cannot both be kept, so the search continues on the two slices that drop one end each.",
                codeLine: matched ? 9 : 12,
              });
            }
          }

          steps.push({
            title: `Answer: longest palindromic subsequence length ${dp[0][n - 1]}`,
            kind: "grid", rows: n, cols: n, rowHeads: heads, colHeads: heads,
            cells: cells({ i: 0, j: n - 1 }).map((cd) => (cd.r === 0 && cd.c === n - 1 ? { ...cd, state: "result" } : cd)),
            label: 'the top-right cell covers the whole word',
            counters: [count("cells filled", filled), count("answer", dp[0][n - 1])],
            legend: LEG,
            happened: `Cell (0, ${n - 1}) is ${dp[0][n - 1]}, the longest chunk of "${s}" that reads the same both ways.`,
            why: "Wrapping or dropping ends was decided for every slice, so the widest slice must be correct.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------- 8. Edit Distance ---------------- */
  V.register({
    id: "edit-distance",
    title: "Edit Distance",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "The fewest single-letter inserts, deletes and substitutions turning one word into another.",
    input: { label: "Two words separated by a space", default: "horse ros", parse: "string" },
    approaches: [
      {
        name: "Full DP Table",
        complexity: "O(m·n) time, O(m·n) space",
        idea: [
          "Put the target word along the rows and the source word along the columns. Cell (r, c) is the edit distance between the first r letters of the target and the first c letters of the source.",
          "If the two new letters match, nothing is spent: dp[r][c] = dp[r-1][c-1]. Otherwise take the cheapest of deleting (dp[r-1][c]), inserting (dp[r][c-1]) or substituting (dp[r-1][c-1]) and add 1.",
          "Row 0 and column 0 turn an empty prefix into a longer one, so they count 0, 1, 2, ... The bottom-right cell is the answer.",
        ],
        problem: [
          "The whole table is O(m·n) memory, but the recurrence only ever reads the previous row and the current one.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

static int min3(int a, int b, int c) {
    int m = a < b ? a : b;
    return m < c ? m : c;
}

/* dp[r][c] = edits to turn src[0..c-1] into dst[0..r-1]. */
int edit(const char *src, const char *dst) {
    int n = strlen(src), m = strlen(dst);
    int dp[64][64];
    for (int r = 0; r <= m; r++) dp[r][0] = r;
    for (int c = 0; c <= n; c++) dp[0][c] = c;
    for (int r = 1; r <= m; r++)
        for (int c = 1; c <= n; c++)
            if (dst[r - 1] == src[c - 1])
                dp[r][c] = dp[r - 1][c - 1];
            else
                dp[r][c] = 1 + min3(dp[r - 1][c], dp[r][c - 1], dp[r - 1][c - 1]);
    return dp[m][n];
}

int main(void) {
    printf("%d\\n", edit("horse", "ros")); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

int edit(const std::string& src, const std::string& dst) {
    int n = (int)src.size(), m = (int)dst.size();
    std::vector<std::vector<int>> dp(m + 1, std::vector<int>(n + 1, 0));
    for (int r = 0; r <= m; r++) dp[r][0] = r;
    for (int c = 0; c <= n; c++) dp[0][c] = c;
    for (int r = 1; r <= m; r++)
        for (int c = 1; c <= n; c++)
            if (dst[r - 1] == src[c - 1])
                dp[r][c] = dp[r - 1][c - 1];               // free match
            else
                dp[r][c] = 1 + std::min({dp[r - 1][c], dp[r][c - 1], dp[r - 1][c - 1]});
    return dp[m][n];
}

int main() {
    std::cout << edit("horse", "ros") << '\\n'; // 3
}`,
        },
        steps(parsed) {
          const parts = tokens(parsed);
          const src = parts[0] || "";
          const dst = parts[1] || "";
          if (!dst) return oneToken(src, "edit distance");

          const cut = src.length > 12 || dst.length > 12;
          const a = src.slice(0, 12);   // columns
          const b = dst.slice(0, 12);   // rows
          const rows = b.length + 1, cols = a.length + 1;
          const rowHeads = [""].concat(b.split(""));
          const colHeads = [""].concat(a.split(""));
          const dp = Array.from({ length: rows }, () => new Array(cols).fill(null));
          const st = Array.from({ length: rows }, () => new Array(cols).fill("done"));
          const steps = [];
          const LEG = ["read", "good", "done", "idle"];
          const cells = (cur) => {
            const out = [];
            for (let r = 0; r < rows; r++)
              for (let c = 0; c < cols; c++)
                if (dp[r][c] != null)
                  out.push({ r, c, v: dp[r][c], state: cur && cur.r === r && cur.c === c ? "read" : st[r][c] });
            return out;
          };

          for (let r = 0; r < rows; r++) dp[r][0] = r;
          for (let c = 0; c < cols; c++) dp[0][c] = c;

          steps.push({
            title: "Set up: the border counts inserts and deletes",
            kind: "grid", rows, cols, rowHeads, colHeads,
            cells: cells(null),
            label: `rows = "${b}", columns = "${a}"`,
            counters: [count("cell", "—"), count("cells filled", rows + cols - 1)],
            legend: LEG,
            happened: cut
              ? `The words were trimmed to "${a}" and "${b}". Turning an empty prefix into a longer one costs one edit per letter, giving the 0,1,2,... border.`
              : `Cell (r, c) will be the edit distance between the first r letters of "${b}" and the first c letters of "${a}". The border counts 0,1,2,...`,
            why: "An empty prefix needs one insert (or delete) per letter of the other side; that fixes the whole first row and column.",
            codeLine: 8,
          });

          let filled = rows + cols - 1;
          for (let r = 1; r < rows; r++) {
            for (let c = 1; c < cols; c++) {
              const sub = dp[r - 1][c - 1];
              const del = dp[r - 1][c];
              const ins = dp[r][c - 1];
              const matched = b[r - 1] === a[c - 1];
              let v, title;
              if (matched) {
                v = sub;
                st[r][c] = "good";
                title = `dp[${r}][${c}]: ${b[r - 1]} = ${a[c - 1]} → copy ${sub} (no cost)`;
              } else {
                v = 1 + Math.min(sub, del, ins);
                st[r][c] = "done";
                title = `dp[${r}][${c}]: 1 + min(replace ${sub}, delete ${del}, insert ${ins}) = ${v}`;
              }
              dp[r][c] = v;
              filled++;
              steps.push({
                title,
                kind: "grid", rows, cols, rowHeads, colHeads,
                cells: cells({ r, c }),
                counters: [count("cell", `(${r}, ${c})`), count("cost so far", v), count("cells filled", filled)],
                legend: LEG,
                happened: matched
                  ? `Letters match, so the two prefixes cost exactly what their shorter versions cost: ${v}.`
                  : `Letters differ, so the cheapest of replacing (${sub}), deleting (${del}) or inserting (${ins}) plus one edit gives ${v}.`,
                why: matched
                  ? "A free match means the new letters can be left untouched, borrowing the diagonal cost."
                  : "Every edit operation is one of those three, so the minimum over them is the true cost.",
                codeLine: matched ? 14 : 16,
              });
            }
          }

          steps.push({
            title: `Answer: edit distance ${dp[rows - 1][cols - 1]}`,
            kind: "grid", rows, cols, rowHeads, colHeads,
            cells: cells({ r: rows - 1, c: cols - 1 }).map((cd) => (cd.r === rows - 1 && cd.c === cols - 1 ? { ...cd, state: "result" } : cd)),
            label: `turn "${a}" into "${b}"`,
            counters: [count("cells filled", filled), count("answer", dp[rows - 1][cols - 1])],
            legend: LEG,
            happened: `The bottom-right cell is ${dp[rows - 1][cols - 1]}: "${a}" becomes "${b}" in that many single-letter edits.`,
            why: "It compares the two whole words, and each larger answer was assembled from the smaller ones before it.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------- 9. Distinct Subsequences ---------------- */
  V.register({
    id: "distinct-subsequences",
    title: "Distinct Subsequences",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Count how many different ways one word can be spelled as a subsequence of another.",
    input: { label: "Source and target, space separated", default: "rabbbit rabbit", parse: "string" },
    approaches: [
      {
        name: "Full DP Table",
        complexity: "O(m·n) time, O(m·n) space",
        idea: [
          "Let the target sit along the rows and the source along the columns. dp[r][c] counts the ways to spell the first r letters of the target using only the first c letters of the source.",
          "If the new target letter equals the new source letter, we may either use it (dp[r-1][c-1]) or ignore it (dp[r-1][c]); if they differ, only ignoring is possible.",
          "The empty target has exactly one spelling (use nothing), so row 0 is all 1s; the empty source can spell nothing, so column 0 is 0 apart from that corner. The bottom-right cell is the answer.",
        ],
        problem: [
          "The counts can grow fast, so the values in a big table are large even though the table itself is only O(m·n).",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

/* dp[r][c] = ways to build t[0..r-1] from s[0..c-1]. */
long count_ways(const char *s, const char *t) {
    int n = strlen(s), m = strlen(t);
    long dp[64][64];
    for (int c = 0; c <= n; c++) dp[0][c] = 1;   /* empty target: one way */
    for (int r = 1; r <= m; r++) dp[r][0] = 0;   /* empty source: none */
    for (int r = 1; r <= m; r++)
        for (int c = 1; c <= n; c++) {
            dp[r][c] = dp[r - 1][c];             /* skip s[c-1] */
            if (t[r - 1] == s[c - 1])
                dp[r][c] += dp[r - 1][c - 1];    /* use it as well */
        }
    return dp[m][n];
}

int main(void) {
    printf("%ld\\n", count_ways("rabbbit", "rabbit")); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>

long countWays(const std::string& s, const std::string& t) {
    int n = (int)s.size(), m = (int)t.size();
    std::vector<std::vector<long>> dp(m + 1, std::vector<long>(n + 1, 0));
    for (int c = 0; c <= n; c++) dp[0][c] = 1;       // empty target
    for (int r = 1; r <= m; r++)
        for (int c = 1; c <= n; c++) {
            dp[r][c] = dp[r - 1][c];                 // skip this source letter
            if (t[r - 1] == s[c - 1])
                dp[r][c] += dp[r - 1][c - 1];        // or match it
        }
    return dp[m][n];
}

int main() {
    std::cout << countWays("rabbbit", "rabbit") << '\\n'; // 3
}`,
        },
        steps(parsed) {
          const parts = tokens(parsed);
          const source = parts[0] || "";
          const target = parts[1] || "";
          if (!target) return oneToken(source, "subsequence count");

          const cut = source.length > 12 || target.length > 12;
          const s = source.slice(0, 12);   // columns
          const t = target.slice(0, 12);   // rows
          const rows = t.length + 1, cols = s.length + 1;
          const rowHeads = [""].concat(t.split(""));
          const colHeads = [""].concat(s.split(""));
          const dp = Array.from({ length: rows }, () => new Array(cols).fill(null));
          const st = Array.from({ length: rows }, () => new Array(cols).fill("done"));
          const steps = [];
          const LEG = ["read", "good", "done", "idle"];
          const cells = (cur) => {
            const out = [];
            for (let r = 0; r < rows; r++)
              for (let c = 0; c < cols; c++)
                if (dp[r][c] != null)
                  out.push({ r, c, v: dp[r][c], state: cur && cur.r === r && cur.c === c ? "read" : st[r][c] });
            return out;
          };

          for (let c = 0; c < cols; c++) dp[0][c] = 1;
          for (let r = 1; r < rows; r++) dp[r][0] = 0;

          steps.push({
            title: "Set up: an empty target has exactly one spelling",
            kind: "grid", rows, cols, rowHeads, colHeads,
            cells: cells(null),
            label: `rows = target "${t}", columns = source "${s}"`,
            counters: [count("cell", "—"), count("cells filled", rows + cols - 1)],
            legend: LEG,
            happened: cut
              ? `The words were trimmed to source "${s}" and target "${t}". Row 0 is all 1s; column 0 is 0 (except the corner).`
              : `Cell (r, c) counts how many ways the first r letters of "${t}" can be spelled from the first c letters of "${s}". Row 0 is 1; the rest of column 0 is 0.`,
            why: "Spelling nothing from anything is one way: pick no letters. Spelling something from nothing is impossible, hence the zeros.",
            codeLine: 7,
          });

          let filled = rows + cols - 1;
          for (let r = 1; r < rows; r++) {
            for (let c = 1; c < cols; c++) {
              const skip = dp[r - 1][c];
              const matched = t[r - 1] === s[c - 1];
              const use = matched ? dp[r - 1][c - 1] : 0;
              const v = skip + use;
              st[r][c] = matched ? "good" : "done";
              dp[r][c] = v;
              filled++;
              steps.push({
                title: matched
                  ? `dp[${r}][${c}]: "${t[r - 1]}" = "${s[c - 1]}" → ${skip} + ${use} = ${v}`
                  : `dp[${r}][${c}]: "${t[r - 1]}" ≠ "${s[c - 1]}" → carry ${skip}`,
                kind: "grid", rows, cols, rowHeads, colHeads,
                cells: cells({ r, c }),
                counters: [count("cell", `(${r}, ${c})`), count("ways so far", v), count("cells filled", filled)],
                legend: LEG,
                happened: matched
                  ? `The source letter "${s[c - 1]}" can be ignored (${skip} ways) or used to end the target prefix (${use} ways), giving ${v}.`
                  : `The two letters differ, so this source letter cannot end the target prefix; only the ${skip} ways that ignore it survive.`,
                why: matched
                  ? "Every spelling either uses this matching letter or skips it, and those two groups never overlap."
                  : "Without a match the letter cannot be part of this prefix, so the count simply carries over.",
                codeLine: matched ? 13 : 11,
              });
            }
          }

          steps.push({
            title: `Answer: ${dp[rows - 1][cols - 1]} distinct ways`,
            kind: "grid", rows, cols, rowHeads, colHeads,
            cells: cells({ r: rows - 1, c: cols - 1 }).map((cd) => (cd.r === rows - 1 && cd.c === cols - 1 ? { ...cd, state: "result" } : cd)),
            label: `spell "${t}" from "${s}"`,
            counters: [count("cells filled", filled), count("answer", dp[rows - 1][cols - 1])],
            legend: LEG,
            happened: `The bottom-right cell is ${dp[rows - 1][cols - 1]}: the target "${t}" can be spelled that many ways from "${s}".`,
            why: "It uses the whole target and the whole source, and every smaller cell was counted by choosing to keep or skip each letter.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------- 10. Longest Increasing Subsequence ---------------- */
  V.register({
    id: "longest-increasing-subsequence",
    title: "Longest Increasing Subsequence",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "The longest run of numbers you can pick in order while always going strictly upwards.",
    input: { label: "The numbers", default: "10, 9, 2, 5, 3, 7, 101, 18", parse: "ints" },
    approaches: [
      {
        name: "Quadratic DP Table",
        complexity: "O(n²) time, O(n) space",
        idea: [
          "Let dp[i] be the length of the longest increasing subsequence that ends exactly at position i. It starts at 1 (the single number itself).",
          "For every earlier position j with a smaller number, position i could extend whatever run ends at j, so dp[i] = max(dp[i], dp[j] + 1) over all j < i with nums[j] < nums[i].",
          "The answer is the largest value in the dp row.",
        ],
        problem: [
          "Every position looks back at every earlier one, which is O(n²) comparisons — the patience approach beats this to O(n log n).",
        ],
        code: {
          c: `#include <stdio.h>

/* dp[i] = longest increasing run ending exactly at i. */
int lis(const int *a, int n) {
    int dp[64], best = 0;
    for (int i = 0; i < n; i++) {
        dp[i] = 1;
        for (int j = 0; j < i; j++)
            if (a[j] < a[i] && dp[j] + 1 > dp[i])
                dp[i] = dp[j] + 1;
        if (dp[i] > best) best = dp[i];
    }
    return best;
}

int main(void) {
    int a[] = {10, 9, 2, 5, 3, 7, 101, 18};
    printf("%d\\n", lis(a, 8)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int lis(const std::vector<int>& a) {
    int n = (int)a.size(), best = 0;
    std::vector<int> dp(n, 1);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++)
            if (a[j] < a[i])
                dp[i] = std::max(dp[i], dp[j] + 1);
        best = std::max(best, dp[i]);
    }
    return best;
}

int main() {
    std::cout << lis({10, 9, 2, 5, 3, 7, 101, 18}) << '\\n'; // 4
}`,
        },
        steps(nums) {
          const cut = nums.length > 18;
          const a = nums.slice(0, 18);
          const n = a.length;
          const dp = new Array(n).fill(null);
          const steps = [];
          const LEG = ["read", "compare", "result", "done", "idle"];
          const numCells = (i, j) =>
            a.map((v, k) => (k === i ? "read" : k === j ? "compare" : dp[k] != null ? "done" : "idle"));
          const dpCells = (i) =>
            dp.map((v, k) => ({
              v: v == null ? "—" : v,
              state: v == null ? "idle" : k === i ? "read" : "done",
            }));

          steps.push({
            title: "Recurrence: extend a run that ends on a smaller number",
            tracks: [track("the numbers", a, fill(n, "idle")), { label: "dp (run ending here)", cells: dpCells(-1) }],
            counters: [count("numbers", n), count("pairs compared", 0)],
            legend: LEG,
            happened: cut
              ? `The input was trimmed to ${n} numbers. dp[i] will be the longest increasing run ending exactly at position i.`
              : `dp[i] is the length of the longest increasing run ending exactly at position i, starting at 1 for the bare number.`,
            why: "Ending the run at a fixed position gives every sub-problem a clean last element to compare against.",
            codeLine: 3,
          });

          let pairs = 0, best = 0, bestIdx = -1;
          for (let i = 0; i < n; i++) {
            dp[i] = 1;
            steps.push({
              title: `Position ${i}: a run can start here (dp[${i}] = 1)`,
              tracks: [track("the numbers", a, numCells(i, -1)), { label: "dp (run ending here)", cells: dpCells(i) }],
              counters: [count("numbers", n), count("pairs compared", pairs)],
              legend: LEG,
              happened: `Number ${a[i]} on its own is an increasing run of length 1.`,
              why: "Before looking for predecessors, give every position its guaranteed baseline of 1.",
              codeLine: 5,
            });
            for (let j = 0; j < i; j++) {
              pairs++;
              const smaller = a[j] < a[i];
              const cand = smaller ? dp[j] + 1 : null;
              if (smaller && cand > dp[i]) dp[i] = cand;
              steps.push({
                title: smaller
                  ? `${a[j]} < ${a[i]} → candidate run ${cand}, dp[${i}] = ${dp[i]}`
                  : `${a[j]} ≥ ${a[i]} → cannot extend, dp[${i}] stays ${dp[i]}`,
                tracks: [track("the numbers", a, numCells(i, j)), { label: "dp (run ending here)", cells: dpCells(i) }],
                counters: [count("numbers", n), count("pairs compared", pairs), count("best ending at " + i, dp[i])],
                legend: LEG,
                happened: smaller
                  ? `The earlier number ${a[j]} is smaller, so the run ending at ${j} (length ${dp[j]}) can be extended by ${a[i]}.`
                  : `The earlier number ${a[j]} is not smaller, so it cannot sit in front of ${a[i]}.`,
                why: smaller
                  ? "Strictly increasing means only smaller predecessors count; each one offers a run of its own length plus this number."
                  : "Equal or larger values would break the strictly-increasing rule, so they are skipped entirely.",
                codeLine: smaller ? 7 : 7,
              });
            }
            if (dp[i] > best) { best = dp[i]; bestIdx = i; }
          }

          steps.push({
            title: `Answer: longest increasing subsequence length ${best}`,
            tracks: [
              track("the numbers", a, a.map((_, k) => (k === bestIdx ? "result" : "dim"))),
              { label: "dp (run ending here)", cells: dpCells(-1).map((c, k) => (k === bestIdx ? { ...c, state: "result" } : c)) },
            ],
            counters: [count("numbers", n), count("pairs compared", pairs), count("answer", best)],
            legend: LEG,
            happened: `The largest dp value is ${best}, reached at position ${bestIdx} (number ${a[bestIdx]}).`,
            why: "Every increasing run ends somewhere, so the maximum over all endings is the longest run in the row.",
            codeLine: 9,
          });
          return steps;
        },
      },
      {
        name: "Patience and Binary Search",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Keep a row called tails: tails[k] is the smallest possible last number of an increasing run of length k+1 found so far. This row is always sorted.",
          "For each number, find the first tail that is at least as large as it. Replace that tail with the number — a smaller tail leaves more room for later numbers. If no tail is that large, append the number, which grows the longest run by one.",
          "The length of tails at the end is the answer. The row itself is not necessarily the subsequence, only a record of the best endpoints.",
        ],
        problem: [
          "tails no longer records the actual subsequence, so reconstructing the chosen numbers needs a second pass and extra bookkeeping.",
        ],
        code: {
          c: `#include <stdio.h>

/* tails[k] = smallest tail of an increasing run of length k+1. */
int lis(const int *a, int n) {
    int tails[64], len = 0;
    for (int i = 0; i < n; i++) {
        int lo = 0, hi = len;              /* lower_bound(a[i]) */
        while (lo < hi) {
            int mid = (lo + hi) / 2;
            if (tails[mid] < a[i]) lo = mid + 1;
            else hi = mid;
        }
        tails[lo] = a[i];
        if (lo == len) len++;
    }
    return len;
}

int main(void) {
    int a[] = {10, 9, 2, 5, 3, 7, 101, 18};
    printf("%d\\n", lis(a, 8)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int lis(const std::vector<int>& a) {
    std::vector<int> tails;                // sorted smallest-tail row
    for (int x : a) {
        auto it = std::lower_bound(tails.begin(), tails.end(), x);
        if (it == tails.end()) tails.push_back(x);   // extends the longest run
        else *it = x;                                // tighten a tail
    }
    return (int)tails.size();
}

int main() {
    std::cout << lis({10, 9, 2, 5, 3, 7, 101, 18}) << '\\n'; // 4
}`,
        },
        steps(nums) {
          const cut = nums.length > 18;
          const a = nums.slice(0, 18);
          const n = a.length;
          let tails = [];
          const steps = [];
          const LEG = ["read", "result", "done", "idle"];
          const tailsTrack = (active) => ({
            label: "tails (smallest tail per run length)",
            cells: tails.length
              ? tails.map((v, k) => ({ v, state: k === active ? "read" : "done", tag: k === active ? "tightened" : undefined }))
              : [{ v: "∅", state: "idle", empty: true }],
          });
          const numCells = (i) => a.map((v, k) => (k === i ? "read" : k < i ? "done" : "idle"));

          steps.push({
            title: "tails[k] = smallest tail of any increasing run of length k+1",
            tracks: [track("the numbers", a, fill(n, "idle")), tailsTrack(-1)],
            counters: [count("numbers placed", 0, n), count("longest run", 0)],
            legend: LEG,
            happened: cut
              ? `The input was trimmed to ${n} numbers. The tails row starts empty and stays sorted at all times.`
              : "The tails row starts empty. Because every tail is placed with binary search, the row never loses its sorted order.",
            why: "A smaller tail for the same run length is always at least as useful, so keeping the smallest endpoint is safe.",
            codeLine: 3,
          });

          for (let i = 0; i < n; i++) {
            const x = a[i];
            let lo = 0, hi = tails.length;
            while (lo < hi) {
              const mid = (lo + hi) >> 1;
              if (tails[mid] < x) lo = mid + 1;
              else hi = mid;
            }
            const appended = lo === tails.length;
            const replaced = appended ? null : tails[lo];
            if (appended) tails.push(x); else tails[lo] = x;
            steps.push({
              title: appended
                ? `${x} is larger than every tail → append, run length ${tails.length}`
                : `${x} replaces tail[${lo}] (was ${replaced}) → same run lengths`,
              tracks: [track("the numbers", a, numCells(i)), tailsTrack(appended ? -1 : lo)],
              counters: [count("numbers placed", i + 1, n), count("longest run", tails.length), count("tails row", tails.join(", "))],
              legend: LEG,
              happened: appended
                ? `No tail is at least ${x}, so appending it creates a longer increasing run: now length ${tails.length}.`
                : `The first tail not below ${x} was ${replaced}; swapping in ${x} keeps the same run lengths with a smaller endpoint.`,
              why: appended
                ? "If the number beats every endpoint, it can extend the longest run seen so far."
                : "Lowering a tail never breaks anything and only widens the options for numbers that come later.",
              codeLine: 11,
            });
          }

          steps.push({
            title: `Answer: longest increasing subsequence length ${tails.length}`,
            tracks: [
              track("the numbers", a, fill(n, "dim")),
              { label: "tails (smallest tail per run length)", cells: tails.map((v) => ({ v, state: "result" })) },
            ],
            counters: [count("numbers placed", n, n), count("answer", tails.length)],
            legend: LEG,
            happened: `The tails row ends with ${tails.length} entries, which is exactly the longest increasing run length.`,
            why: "Each entry represents a run length that is actually achievable, so the row's size is the answer.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------- 11. Number of Longest Increasing Subsequences ---------------- */
  V.register({
    id: "number-of-longest-increasing-subsequences",
    title: "Number of Longest Increasing Subsequences",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Count how many increasing runs achieve the longest possible length.",
    input: { label: "The numbers", default: "1, 3, 5, 4, 7", parse: "ints" },
    approaches: [
      {
        name: "Length and Count Together",
        complexity: "O(n²) time, O(n) space",
        idea: [
          "Keep two rows. len[i] is the longest increasing run ending at i, and cnt[i] is how many different runs reach that best length at i.",
          "While scanning earlier positions j, three cases appear: a longer run means len[i] becomes len[j]+1 and cnt[i] is reset to cnt[j]; an equal-length run means cnt[i] grows by cnt[j]; a shorter run changes nothing.",
          "A running record of the best length and its total count is enough, because any run reaching the maximum length ends at some position with that length.",
        ],
        problem: [
          "Two rows and a double loop make it O(n²) time, and the counts must be reset carefully whenever a longer run appears.",
        ],
        code: {
          c: `#include <stdio.h>

/* len[i] = longest run ending at i; cnt[i] = how many such runs. */
int count_lis(const int *a, int n) {
    int len[64], cnt[64], best = 0, total = 0;
    for (int i = 0; i < n; i++) {
        len[i] = 1;
        cnt[i] = 1;
        for (int j = 0; j < i; j++) {
            if (a[j] < a[i]) {
                if (len[j] + 1 > len[i]) { len[i] = len[j] + 1; cnt[i] = cnt[j]; }
                else if (len[j] + 1 == len[i]) { cnt[i] += cnt[j]; }
            }
        }
        if (len[i] > best) { best = len[i]; total = cnt[i]; }
        else if (len[i] == best) { total += cnt[i]; }
    }
    return total;
}

int main(void) {
    int a[] = {1, 3, 5, 4, 7};
    printf("%d\\n", count_lis(a, 5)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

int findNumberOfLIS(const std::vector<int>& a) {
    int n = (int)a.size();
    std::vector<int> len(n, 1), cnt(n, 1);
    int best = 0, total = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (a[j] < a[i]) {
                if (len[j] + 1 > len[i]) { len[i] = len[j] + 1; cnt[i] = cnt[j]; }
                else if (len[j] + 1 == len[i]) cnt[i] += cnt[j];
            }
        }
        if (len[i] > best) { best = len[i]; total = cnt[i]; }
        else if (len[i] == best) total += cnt[i];
    }
    return total;
}

int main() {
    std::cout << findNumberOfLIS({1, 3, 5, 4, 7}) << '\\n'; // 2
}`,
        },
        steps(nums) {
          const cut = nums.length > 18;
          const a = nums.slice(0, 18);
          const n = a.length;
          const len = new Array(n).fill(null);
          const cnt = new Array(n).fill(null);
          const steps = [];
          const LEG = ["read", "compare", "good", "result", "done", "idle"];
          const numCells = (i, j) =>
            a.map((v, k) => (k === i ? "read" : k === j ? "compare" : len[k] != null ? "done" : "idle"));
          const lenCells = (i) =>
            len.map((v, k) => ({ v: v == null ? "—" : v, state: v == null ? "idle" : k === i ? "read" : "done" }));
          const cntCells = (i) =>
            cnt.map((v, k) => ({ v: v == null ? "—" : v, state: v == null ? "idle" : k === i ? "read" : "done" }));

          steps.push({
            title: "Two rows: how long (len) and how many (cnt)",
            tracks: [track("the numbers", a, fill(n, "idle")), { label: "len (longest run ending here)", cells: lenCells(-1) }, { label: "cnt (how many such runs)", cells: cntCells(-1) }],
            counters: [count("numbers", n), count("record length", 0)],
            legend: LEG,
            happened: cut
              ? `The input was trimmed to ${n} numbers. len[i] and cnt[i] both start empty.`
              : "Every position will get a length row and a count row. Together they describe all increasing runs.",
            why: "Counting alone is not enough — a cleverer arrangement of a longer run would invalidate earlier counts, so length and count move together.",
            codeLine: 3,
          });

          let best = 0, total = 0;
          for (let i = 0; i < n; i++) {
            len[i] = 1; cnt[i] = 1;
            steps.push({
              title: `Position ${i}: a fresh run of length 1 (count 1)`,
              tracks: [track("the numbers", a, numCells(i, -1)), { label: "len (longest run ending here)", cells: lenCells(i) }, { label: "cnt (how many such runs)", cells: cntCells(i) }],
              counters: [count("numbers", n), count("position", i + 1, n)],
              legend: LEG,
              happened: `Number ${a[i]} alone gives one run of length 1 ending here.`,
              why: "Every position begins with the guaranteed single-number run; earlier positions will only ever improve it.",
              codeLine: 5,
            });

            for (let j = 0; j < i; j++) {
              if (a[j] >= a[i]) {
                steps.push({
                  title: `${a[j]} ≥ ${a[i]} at ${j} → skipped`,
                  tracks: [track("the numbers", a, numCells(i, j)), { label: "len (longest run ending here)", cells: lenCells(i) }, { label: "cnt (how many such runs)", cells: cntCells(i) }],
                  counters: [count("position", i + 1, n), count("previous checked", j + 1, i)],
                  legend: LEG,
                  happened: `Position ${j} holds ${a[j]}, not smaller than ${a[i]}, so no run there can lead into this one.`,
                  why: "Strictly increasing rules out equal or larger predecessors immediately.",
                  codeLine: 8,
                });
                continue;
              }
              const candidate = len[j] + 1;
              if (candidate > len[i]) {
                len[i] = candidate;
                cnt[i] = cnt[j];
                steps.push({
                  title: `Position ${j}: longer run found → len[${i}] = ${candidate}, cnt[${i}] = ${cnt[j]}`,
                  tracks: [track("the numbers", a, numCells(i, j)), { label: "len (longest run ending here)", cells: lenCells(i) }, { label: "cnt (how many such runs)", cells: cntCells(i) }],
                  counters: [count("position", i + 1, n), count("best ending at " + i, len[i]), count("ways ending at " + i, cnt[i])],
                  legend: LEG,
                  happened: `Extending a run from ${j} gives length ${candidate}, beating the previous best for ${i}; the old count is replaced by ${cnt[j]}.`,
                  why: "A strictly longer run makes every shorter arrangement irrelevant, so its count must be discarded, not added.",
                  codeLine: 10,
                });
              } else if (candidate === len[i]) {
                cnt[i] += cnt[j];
                steps.push({
                  title: `Position ${j}: equally long run → cnt[${i}] = ${cnt[i]}`,
                  tracks: [track("the numbers", a, numCells(i, j)), { label: "len (longest run ending here)", cells: lenCells(i) }, { label: "cnt (how many such runs)", cells: cntCells(i) }],
                  counters: [count("position", i + 1, n), count("best ending at " + i, len[i]), count("ways ending at " + i, cnt[i])],
                  legend: LEG,
                  happened: `Position ${j} reaches the same best length ${len[i]}, adding its ${cnt[j]} run${cnt[j] === 1 ? "" : "s"} to the total.`,
                  why: "Different predecessors give genuinely different runs of the same length, so their counts add.",
                  codeLine: 11,
                });
              } else {
                steps.push({
                  title: `Position ${j}: run too short (${candidate} < ${len[i]}) → ignored`,
                  tracks: [track("the numbers", a, numCells(i, j)), { label: "len (longest run ending here)", cells: lenCells(i) }, { label: "cnt (how many such runs)", cells: cntCells(i) }],
                  counters: [count("position", i + 1, n), count("best ending at " + i, len[i])],
                  legend: LEG,
                  happened: `Extending from ${j} would give only ${candidate}, shorter than ${len[i]}, so nothing changes.`,
                  why: "Only runs that reach the maximum length at this position are counted.",
                  codeLine: 11,
                });
              }
            }

            if (len[i] > best) { best = len[i]; total = cnt[i]; }
            else if (len[i] === best) { total += cnt[i]; }
            steps.push({
              title: `Record so far: length ${best}, count ${total}`,
              tracks: [track("the numbers", a, numCells(i, -1)), { label: "len (longest run ending here)", cells: lenCells(i) }, { label: "cnt (how many such runs)", cells: cntCells(i) }],
              counters: [count("positions done", i + 1, n), count("record length", best), count("record count", total)],
              legend: LEG,
              happened: `After position ${i} the longest run is ${best} and there are ${total} ways to achieve it so far.`,
              why: "Folding each position into a running record means the final total is ready without a second scan of the rows.",
              codeLine: 16,
            });
          }

          steps.push({
            title: `Answer: ${total} longest increasing subsequence${total === 1 ? "" : "s"}`,
            tracks: [
              track("the numbers", a, a.map((_, k) => (len[k] === best ? "result" : "dim"))),
              { label: "len (longest run ending here)", cells: lenCells(-1).map((c, k) => (len[k] === best ? { ...c, state: "result" } : c)) },
              { label: "cnt (how many such runs)", cells: cntCells(-1).map((c, k) => (len[k] === best ? { ...c, state: "result" } : c)) },
            ],
            counters: [count("positions done", n, n), count("record length", best), count("answer", total)],
            legend: LEG,
            happened: `The longest run length is ${best}, and ${total} different increasing run${total === 1 ? "" : "s"} reach it.`,
            why: "The running record summed exactly the counts of the positions whose best length equals the overall maximum.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });
})();
