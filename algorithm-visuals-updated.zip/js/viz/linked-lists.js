/* ============================================================
   DSA Visuals — Linked Lists
   Six original walkthroughs of classic singly-linked-list tasks:
     reverse-linked-list, middle-of-the-linked-list,
     linked-list-cycle, linked-list-cycle-ii,
     merge-two-sorted-lists, remove-nth-node-from-end
   Every entry follows the SPEC.md contract. A single chain is
   drawn with kind:"list" steps; when two or more chains have to
   share one step the chain is rebuilt as a cells track with
   arrows turned on (see chainTrack below).
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "active", "done", "compare", "result", "good", "bad", "dim", "idle"];
  const S = (o) => Object.assign({ legend: LEG }, o);

  /* -------- local builders -------- */

  /* A kind:"list" step body: one chain of nodes, optionally ending in null. */
  function chain(label, values, states, tags, nil) {
    return {
      kind: "list",
      label,
      nodes: values.map((v, i) => {
        const node = { v, state: (states && states[i]) || "idle" };
        if (tags && tags[i] != null) node.tag = tags[i];
        return node;
      }),
      nil: nil !== false,
    };
  }

  /* The same chain as a cells track (arrows between the cells). */
  function chainTrack(label, values, states, tags, withNull) {
    const cells = values.map((v, i) => {
      const c = { v, state: (states && states[i]) || "idle" };
      if (tags && tags[i] != null) c.tag = tags[i];
      return c;
    });
    if (withNull !== false) cells.push({ v: "null", state: "idle", empty: true });
    return { label, arrows: true, cells };
  }

  /* Pull `key=123` options out of a token list; everything else stays a value. */
  function keyedTokens(tokens, key) {
    const re = new RegExp("^" + key + "=(-?\\d+)$", "i");
    let k = null;
    const vals = [];
    for (const t of tokens) {
      const m = re.exec(String(t));
      if (m) { k = parseInt(m[1], 10); continue; }
      const num = Number(t);
      vals.push(num === num && String(t).trim() !== "" ? num : t);
    }
    return { vals, k };
  }

  /* Steps used when there is nothing to operate on. */
  function emptySteps(title, why) {
    const body = { kind: "list", label: "linked list", nodes: [], nil: true };
    return [
      S({
        title,
        ...body,
        counters: [count("nodes", 0)],
        happened: "The list is empty — there is no node at all.",
        why,
        codeLine: 5,
      }),
      S({
        title: "Answer: nothing to do",
        ...body,
        counters: [count("nodes", 0), count("answer", "empty list")],
        happened: "No node was touched, so the list simply stays empty.",
        why: "Edge cases like this must not crash the walk — there is simply no work to perform.",
        codeLine: 6,
      }),
    ];
  }

  /* ============================================================
     1. Reverse Linked List
     ============================================================ */
  V.register({
    id: "reverse-linked-list",
    title: "Reverse Linked List",
    category: "Linked Lists",
    difficulty: "Beginner",
    description: "Turn every arrow around so the chain reads backwards.",
    input: { label: "Node values", default: "1, 2, 3, 4, 5", parse: "ints" },
    approaches: [
      {
        name: "Iterative Pointer Flip",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Walk the chain once holding two pointers: prev sits on the part already reversed, curr sits on the node being rewired. Save curr's old next, point curr back at prev, then slide both pointers one node forward.",
          "When curr falls off the end, prev is standing on the new head.",
        ],
        problem: [
          "The three assignments inside the loop have to happen in the right order — if you overwrite next before you have saved it, the rest of the chain becomes unreachable and is simply lost.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int v; struct Node *next; } Node;

/* walk once, flipping every arrow; return the new head */
Node *reverse(Node *head) {
    Node *prev = NULL;
    Node *curr = head;
    while (curr) {
        Node *next = curr->next;   /* save the rest */
        curr->next = prev;         /* flip the arrow */
        prev = curr;               /* prev moves up */
        curr = next;               /* curr moves up */
    }
    return prev;
}`,
          cpp: `#include <iostream>

struct Node { int val; Node* next; Node(int v) : val(v), next(nullptr) {} };

// one pass over the chain, three pointers, no new nodes
Node* reverseList(Node* head) {
    Node* prev = nullptr;
    Node* curr = head;
    while (curr) {
        Node* nxt = curr->next;   // keep the rest of the chain
        curr->next = prev;        // turn the arrow around
        prev = curr;              // slide prev up
        curr = nxt;               // slide curr up
    }
    return prev;
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const rev = nums.slice().reverse();

          const tagsFor = (p, c, nx) =>
            nums.map((_, i) => {
              const parts = [];
              if (i === p) parts.push("prev");
              if (i === c) parts.push("curr");
              if (nx != null && i === nx) parts.push("next");
              return parts.length ? parts.join(" ") : undefined;
            });

          steps.push(S({
            title: "Plan: reverse the arrows, not the values",
            ...chain("linked list", nums, fill(n, "idle")),
            counters: [count("flips done", 0, n)],
            happened: `The chain reads ${nums.join(" → ")} → null and every arrow points forwards.`,
            why: "Nodes never move in a reverse — only the next pointers are rewritten, so no value is ever copied or swapped.",
            codeLine: 5,
          }));
          steps.push(S({
            title: `Set up: prev = null, curr = ${nums[0]}`,
            ...chain("linked list", nums, paint(fill(n, "idle"), { 0: "read" }), tagsFor(-1, 0, n > 1 ? 1 : null)),
            counters: [count("flips done", 0, n), count("prev", "null"), count("curr", nums[0])],
            happened: `prev starts empty and curr starts on the head, ${nums[0]} — nothing has been rewired yet.`,
            why: "prev marks the reversed part built so far (still nothing) and curr marks the node about to be flipped.",
            codeLine: 6,
          }));

          let prevIdx = -1;
          for (let k = 0; k < n; k++) {
            const nextIdx = k + 1 < n ? k + 1 : null;
            const states = nums.map((_, i) =>
              i < k ? "done" : i === k ? "read" : i === k + 1 ? "active" : "idle");
            steps.push(S({
              title: `Flip ${nums[k]}: its arrow now points to ${prevIdx >= 0 ? nums[prevIdx] : "null"}`,
              ...chain("linked list", nums, states, tagsFor(prevIdx, k, nextIdx)),
              counters: [
                count("flips done", k + 1, n),
                count("prev", nums[k]),
                count("curr", nextIdx == null ? "null" : nums[nextIdx]),
                count("next saved", nextIdx == null ? "null" : nums[nextIdx]),
              ],
              happened: nextIdx == null
                ? `Node ${nums[k]} turns back to ${prevIdx >= 0 ? nums[prevIdx] : "null"}; it was the last node, so nothing else has to be saved.`
                : `Node ${nums[k]} is pointed back at ${prevIdx >= 0 ? nums[prevIdx] : "null"} while its old next, ${nums[nextIdx]}, was saved in a temporary first.`,
              why: "Saving the old next before the overwrite is what keeps the untouched tail reachable — without it the rest of the chain would vanish.",
              codeLine: 10,
            }));
            prevIdx = k;
          }

          steps.push(S({
            title: "curr fell off the end → stop",
            ...chain("linked list", rev, paint(fill(n, "done"), { 0: "read" }), nums.map((_, i) => (i === 0 ? "new head" : undefined))),
            counters: [count("flips done", n, n), count("prev", rev[0])],
            happened: `curr is now null. Following the arrows from ${rev[0]} walks the chain backwards: ${rev.join(" → ")} → null.`,
            why: "The loop ends exactly one step after the last node is flipped, which is why prev (not curr) holds the answer.",
            codeLine: 8,
          }));
          steps.push(S({
            title: `Answer: ${rev.join(" → ")}`,
            ...chain("linked list", rev, fill(n, "result")),
            counters: [count("flips done", n, n), count("answer", rev.join(" → "))],
            happened: `The new head is ${rev[0]} — the node that used to be last — and ${nums[0]} is now the tail.`,
            why: "One pass, three pointer variables and no extra nodes: O(n) time and O(1) extra space.",
            codeLine: 14,
          }));
          return steps;
        },
      },
      {
        name: "Recursive Unwind",
        complexity: "O(n) time, O(n) call stack",
        idea: [
          "Ask recursion to reverse everything after the first node. When that call returns, the tail is already reversed — the first node only has to attach itself to the end of it.",
          "The base case is a one-node (or empty) chain, which is already reversed.",
        ],
        problem: [
          "Every waiting frame holds a node until the recursion bottoms out, so the call stack grows one level per node — O(n) extra space instead of O(1), and long chains risk exhausting it.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int v; struct Node *next; } Node;

/* reverse the chain after me, then hang myself off its end */
Node *reverse(Node *head) {
    if (!head || !head->next)
        return head;                    /* base: empty or one node */
    Node *newHead = reverse(head->next);
    head->next->next = head;            /* old next points back */
    head->next = NULL;                  /* I am the tail now */
    return newHead;
}`,
          cpp: `#include <iostream>

struct Node { int val; Node* next; Node(int v) : val(v), next(nullptr) {} };

// trust the recursion: assume everything after me is already reversed
Node* reverseList(Node* head) {
    if (!head || !head->next)
        return head;                    // base case
    Node* newHead = reverseList(head->next);
    head->next->next = head;            // old next points back
    head->next = nullptr;               // I become the tail
    return newHead;
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const all = nums.slice();

          const stackTrack = (st) =>
            track(
              "call stack (top last)",
              st.length ? st.map((k) => nums[k]) : ["∅"],
              st.length ? st.map((_, i) => (i === st.length - 1 ? "read" : "compare")) : ["idle"],
              st.length ? st.map((k) => `node ${k}`) : undefined
            );

          const listStates = (current, phase) =>
            all.map((_, i) => {
              if (phase === "down") return i === current ? "read" : i < current ? "compare" : "idle";
              if (i > current) return "done";
              if (i === current) return "read";
              return "idle";
            });

          const listTags = (current) =>
            all.map((_, i) => (i === current ? "current" : undefined));

          steps.push(S({
            title: "Plan: let recursion handle the tail",
            kind: "cells",
            tracks: [
              stackTrack([]),
              chainTrack("the list", all, fill(n, "idle")),
            ],
            counters: [count("nodes", n), count("frames on stack", 0)],
            happened: `The chain is ${all.join(" → ")} → null and the call stack is empty.`,
            why: "The recursive idea is simple: if everything after node k is already reversed, attaching node k behind it finishes the job.",
            codeLine: 6,
          }));

          const stack = [];
          for (let k = 0; k < n - 1; k++) {
            stack.push(k);
            steps.push(S({
              title: `Call reverse(node ${nums[k]}) — push frame ${k}`,
              kind: "cells",
              tracks: [stackTrack(stack), chainTrack("the list", all, listStates(k, "down"), listTags(k))],
              counters: [count("frames on stack", stack.length), count("call depth", stack.length)],
              happened: `Node ${nums[k]} cannot finish yet, so it stores itself and recurses on ${nums[k + 1]}.`,
              why: "Each waiting frame keeps its own node alive; that saved node is precisely what gets reattached on the way back up.",
              codeLine: 9,
            }));
          }

          const base = n - 1;
          steps.push(S({
            title: n === 1
              ? `Base case: ${nums[0]} has nothing after it`
              : `Base case: node ${nums[base]} has nothing after it`,
            kind: "cells",
            tracks: [stackTrack(stack), chainTrack("the list", all, listStates(base, "down"), listTags(base))],
            counters: [count("frames on stack", stack.length), count("call depth", stack.length)],
            happened: n === 1
              ? "A single node with no successor is already a valid reversed list, so it returns itself straight away."
              : `Node ${nums[base]} has no next node — a one-node chain is its own reverse, so it returns immediately.`,
            why: "The base case stops the recursion from running off the end of the chain and gives the frame above a head to work with.",
            codeLine: 7,
          }));

          for (let k = n - 2; k >= 0; k--) {
            stack.pop();
            const reversedNow = nums.slice(k).reverse();
            const states = all.map((_, i) => (i > k ? "done" : i === k ? "read" : "idle"));
            const tags = all.map((_, i) =>
              i === k ? "→ null (tail)" : i === k + 1 ? `→ ${nums[k]}` : undefined);
            steps.push(S({
              title: `Return to node ${nums[k]}: attach it at the end`,
              kind: "cells",
              tracks: [stackTrack(stack), chainTrack("the list", all, states, tags)],
              counters: [count("frames on stack", stack.length), count("nodes reversed", n - k), count("answer so far", reversedNow.join(" → "))],
              happened: `Frame ${k} wakes up: the chain after it is done, so ${nums[k + 1]} swings back to ${nums[k]} and ${nums[k]}'s own arrow is set to null. The reversed tail now reads ${reversedNow.join(" → ")} → null.`,
              why: "Nothing inside the deeper frames is recomputed — each frame only fixes the two arrows it owns and hands the head upwards.",
              codeLine: 10,
            }));
          }

          steps.push(S({
            title: `Answer: ${rev0(nums).join(" → ")}`,
            kind: "cells",
            tracks: [stackTrack([]), chainTrack("the list", rev0(nums), fill(n, "result"), nums.map((_, i) => (i === 0 ? "new head" : undefined)))],
            counters: [count("frames on stack", 0), count("nodes reversed", n), count("answer", rev0(nums).join(" → "))],
            happened: `Every frame has returned: the list now reads ${rev0(nums).join(" → ")} → null, exactly backwards.`,
            why: "The recursion used one stack frame per node — correct, but O(n) extra space where the iterative flip used O(1).",
            codeLine: 11,
          }));
          return steps;
        },
      },
    ],
  });

  function rev0(a) { return a.slice().reverse(); }

  /* ============================================================
     2. Middle of the Linked List
     ============================================================ */
  V.register({
    id: "middle-of-the-linked-list",
    title: "Middle of the Linked List",
    category: "Linked Lists",
    difficulty: "Beginner",
    description: "Find the middle node without knowing the length in advance.",
    input: { label: "Node values", default: "1, 2, 3, 4, 5", parse: "ints" },
    approaches: [
      {
        name: "Slow and Fast Pointers",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Start two pointers on the head. Each turn the slow one moves a single node while the fast one moves two.",
          "When fast can no longer jump (it is on the last node or already past it), slow is standing exactly on the middle. For an even-length list that is the second of the two middle nodes.",
        ],
        problem: [
          "The fast pointer reads fast->next->next, so the loop has to guard both fast and fast->next — miss either check and the walk dereferences null.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int v; struct Node *next; } Node;

/* when fast cannot jump two, slow sits on the middle */
Node *middle(Node *head) {
    Node *slow = head, *fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}`,
          cpp: `#include <iostream>

struct Node { int val; Node* next; Node(int v) : val(v), next(nullptr) {} };

// the hare runs twice as far, so the tortoise lands in the middle
Node* middleNode(Node* head) {
    Node* slow = head;
    Node* fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];

          const statesFor = (s, f) =>
            nums.map((_, i) => (i === s && i === f ? "compare" : i === s ? "read" : i === f ? "active" : "idle"));
          const tagsFor = (s, f) =>
            nums.map((_, i) => {
              const parts = [];
              if (i === s) parts.push("slow");
              if (i === f) parts.push("fast");
              return parts.length ? parts.join(" ") : undefined;
            });

          steps.push(S({
            title: "Plan: one step for slow, two for fast",
            ...chain("linked list", nums, fill(n, "idle")),
            counters: [count("nodes", n)],
            happened: `The chain holds ${nums.join(" → ")}. Both pointers will start on the head.`,
            why: "If one pointer travels twice as far in the same number of turns, it finishes just as the other reaches the halfway mark.",
            codeLine: 5,
          }));

          let s = 0, f = 0, turns = 0;
          steps.push(S({
            title: `Both pointers start at ${nums[0]}`,
            ...chain("linked list", nums, statesFor(0, 0), tagsFor(0, 0)),
            counters: [count("turns", 0), count("slow at", nums[0]), count("fast at", nums[0])],
            happened: `slow and fast both begin at index 0, the node ${nums[0]}.`,
            why: "They start level so the distance between them stays proportional to the number of turns.",
            codeLine: 6,
          }));

          while (f !== null && f + 1 < n && turns < n + 2) {
            steps.push(S({
              title: `Check: fast at ${nums[f]} can jump two`,
              ...chain("linked list", nums, statesFor(s, f), tagsFor(s, f)),
              counters: [count("turns", turns), count("slow at", nums[s]), count("fast at", nums[f])],
              happened: `fast is on ${nums[f]} and has a successor, so this turn has room for a two-node jump.`,
              why: "The loop may only run while both fast and fast->next exist — that is the guard against running off the end.",
              codeLine: 7,
            }));
            s = s + 1;
            const nf = f + 2;
            f = nf < n ? nf : null;
            turns++;
            steps.push(S({
              title: `Turn ${turns}: slow → ${nums[s]}, fast → ${f === null ? "null" : nums[f]}`,
              ...chain("linked list", nums, statesFor(s, f), tagsFor(s, f)),
              counters: [count("turns", turns), count("slow at", nums[s]), count("fast at", f === null ? "null" : nums[f])],
              happened: `slow takes one node and lands on ${nums[s]}; fast takes two and lands on ${f === null ? "null" : nums[f]}.`,
              why: `fast now stands ${turns * 2} node${turns * 2 === 1 ? "" : "s"} from the head while slow stands ${turns} — the gap keeps growing evenly.`,
              codeLine: 8,
            }));
          }

          steps.push(S({
            title: "fast cannot jump two → stop",
            ...chain("linked list", nums, statesFor(s, f), tagsFor(s, f)),
            counters: [count("turns", turns), count("slow at", nums[s]), count("fast at", f === null ? "null" : nums[f])],
            happened: f === null
              ? "fast has stepped past the last node, so the turns are over."
              : `fast is on ${nums[f]} with no successor, so a two-node jump is impossible and the turns end.`,
            why: "At that moment slow has covered exactly half of fast's journey — that is the middle.",
            codeLine: 7,
          }));

          steps.push(S({
            title: `Answer: ${nums[s]} at index ${s}`,
            ...chain("linked list", nums, nums.map((_, i) => (i === s ? "result" : "dim")), nums.map((_, i) => (i === s ? "middle" : undefined))),
            counters: [count("turns", turns), count("middle index", s), count("answer", nums[s])],
            happened: `slow stopped on index ${s}, the node ${nums[s]}.${n % 2 === 1 ? " With an odd count that is the unique middle." : " With an even count this is the second of the two middles."}`,
            why: "One pass and two pointers found the middle without ever counting the length first.",
            codeLine: 11,
          }));
          return steps;
        },
      },
      {
        name: "Count Then Walk",
        complexity: "O(n) time, O(1) space",
        idea: [
          "First pass: walk the whole chain with a counter to learn its length L.",
          "Second pass: start again at the head and take floor(L/2) steps. The node you land on is the middle.",
        ],
        problem: [
          "The chain is traversed twice. On a huge list the first pass is pure overhead compared with the slow/fast trick, which reaches the middle in a single sweep.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int v; struct Node *next; } Node;

/* measure the chain, then step half of its length */
Node *middle(Node *head) {
    int len = 0;
    for (Node *p = head; p; p = p->next)
        len++;
    Node *p = head;
    for (int i = 0; i < len / 2; i++)
        p = p->next;
    return p;
}`,
          cpp: `#include <iostream>

struct Node { int val; Node* next; Node(int v) : val(v), next(nullptr) {} };

// measure the chain, then step half of its length
Node* middleNode(Node* head) {
    int len = 0;
    for (Node* p = head; p; p = p->next) ++len;
    Node* p = head;
    for (int i = 0; i < len / 2; ++i) p = p->next;
    return p;
}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          const mid = Math.floor(n / 2);

          steps.push(S({
            title: "Plan: measure first, walk second",
            ...chain("linked list", nums, fill(n, "idle")),
            counters: [count("length so far", 0), count("steps taken", 0)],
            happened: `The chain holds ${nums.join(" → ")}; its length is not written anywhere, so it has to be counted.`,
            why: "Once the length L is known, the middle is simply the node at index floor(L/2) — no guessing required.",
            codeLine: 5,
          }));

          let len = 0;
          steps.push(S({
            title: "First pass: counter at 0",
            ...chain("linked list", nums, fill(n, "idle")),
            counters: [count("length so far", 0), count("steps taken", 0)],
            happened: "A counter starts at zero and a pointer starts on the head.",
            why: "This pass ignores values completely; it only counts how many nodes exist.",
            codeLine: 6,
          }));

          for (let i = 0; i < n; i++) {
            len = i + 1;
            steps.push(S({
              title: `Count node ${nums[i]} → length ${len}`,
              ...chain("linked list", nums, paint(fill(n, i === n - 1 ? "done" : "idle"), { [i]: "read" }), nums.map((_, k) => (k === i ? "cursor" : undefined))),
              counters: [count("length so far", len, n), count("steps taken", len)],
              happened: `The counting pointer reaches ${nums[i]}, so the length so far becomes ${len}.`,
              why: "Every visit advances exactly one node, so after the last node the counter is the true length.",
              codeLine: 7,
            }));
          }

          steps.push(S({
            title: `Length is ${n} → middle index is ${mid}`,
            ...chain("linked list", nums, fill(n, "done")),
            counters: [count("length", n), count("middle index", mid), count("steps needed", mid)],
            happened: `The first pass ends with length ${n}; halving it gives index ${mid} (integer division drops the remainder).`,
            why: "floor(L/2) picks the exact middle for odd lengths and the second middle for even ones — the same node slow/fast would find.",
            codeLine: 9,
          }));

          for (let s2 = 1; s2 <= mid; s2++) {
            steps.push(S({
              title: `Second pass: step ${s2} of ${mid} → ${nums[s2]}`,
              ...chain("linked list", nums, nums.map((_, i) => (i < s2 ? "done" : i === s2 ? "read" : "idle")), nums.map((_, i) => (i === s2 ? "cursor" : undefined))),
              counters: [count("length", n), count("steps taken", s2, mid), count("position", nums[s2])],
              happened: `The second pointer moves from ${nums[s2 - 1]} to ${nums[s2]} — that is step ${s2} of ${mid}.`,
              why: "Starting from the head, exactly floor(L/2) steps land on the middle node.",
              codeLine: 11,
            }));
          }

          steps.push(S({
            title: `Answer: ${nums[mid]} at index ${mid}`,
            ...chain("linked list", nums, nums.map((_, i) => (i === mid ? "result" : "dim")), nums.map((_, i) => (i === mid ? "middle" : undefined))),
            counters: [count("length", n), count("steps taken", mid, mid), count("answer", nums[mid])],
            happened: `After ${mid} step${mid === 1 ? "" : "s"} from the head the pointer rests on ${nums[mid]}.`,
            why: "Two clean passes: O(n) time either way, but the chain is read twice instead of once.",
            codeLine: 11,
          }));
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     3. Linked List Cycle
     ============================================================ */
  V.register({
    id: "linked-list-cycle",
    title: "Linked List Cycle",
    category: "Linked Lists",
    difficulty: "Beginner",
    description: "Decide whether the chain ever loops back on itself.",
    input: { label: "Values, then pos=k for the tail's target", default: "3, 2, 0, -4 pos=1", parse: "tokens" },
    approaches: [
      {
        name: "Tortoise and Hare (Floyd)",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Two pointers start on the head. Every turn the tortoise moves one node and the hare moves two.",
          "On a straight chain the hare reaches null and the answer is no. Inside a loop the hare keeps lapping and must eventually land on the tortoise's node — that collision is the proof of a cycle.",
        ],
        problem: [
          "The pointers must be compared node-by-node, not value-by-value: two equal values in different nodes are not a cycle. The guard also has to check fast and fast->next before jumping.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

typedef struct Node { int v; struct Node *next; } Node;

/* a hare running twice as fast as a tortoise must lap it inside a loop */
bool has_cycle(Node *head) {
    Node *slow = head, *fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast)
            return true;               /* same node, not just same value */
    }
    return false;
}`,
          cpp: `#include <iostream>

struct Node { int val; Node* next; Node(int v) : val(v), next(nullptr) {} };

bool hasCycle(Node* head) {
    Node* slow = head;
    Node* fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) return true; // same node identity
    }
    return false;
}`,
        },
        steps(parsed) {
          const { vals, k } = keyedTokens(parsed, "pos");
          const n = vals.length;
          let pos = k == null ? -1 : k;
          if (!(pos >= 0 && pos < n)) pos = -1;
          const steps = [];
          const link = (i) => (i == null ? null : i === n - 1 ? (pos >= 0 ? pos : null) : i + 1);
          const lbl = pos >= 0 ? `linked list — tail links back to #${pos}` : "linked list";
          const live = pos < 0; // draw null only when the chain really ends

          const tagsFor = (s, f) =>
            vals.map((_, i) => {
              const parts = [];
              if (i === s) parts.push("slow");
              if (i === f) parts.push("fast");
              if (pos >= 0 && i === n - 1) parts.push(`↩ #${pos}`);
              return parts.length ? parts.join(" ") : undefined;
            });
          const statesFor = (s, f, met) =>
            vals.map((_, i) => {
              if (met) return i === s ? "result" : "done";
              if (i === s && i === f) return "compare";
              if (i === s) return "read";
              if (i === f) return "active";
              return "idle";
            });

          steps.push(S({
            title: "Plan: one pointer twice as fast as the other",
            ...chain(lbl, vals, fill(n, "idle"), vals.map((_, i) => (pos >= 0 && i === n - 1 ? `↩ #${pos}` : undefined)), live),
            counters: [count("nodes", n)],
            happened: n === 0
              ? "There are no nodes at all, so nothing can loop."
              : `The chain reads ${vals.join(" → ")}${pos < 0 ? " → null" : ` and its last node points back to index ${pos} (${vals[pos]})`}.`,
            why: "A cycle means one node is reachable twice by following next — the fast/slow race detects exactly that without storing anything.",
            codeLine: 6,
          }));

          if (n > 0) {
            steps.push(S({
              title: `Both pointers start at ${vals[0]}`,
              ...chain(lbl, vals, statesFor(0, 0, false), tagsFor(0, 0), live),
              counters: [count("turns", 0), count("slow at", 0), count("fast at", 0)],
              happened: `slow and fast both begin on index 0, the node ${vals[0]}.`,
              why: "Starting level guarantees that any collision really comes from the loop, not from one pointer being ahead.",
              codeLine: 7,
            }));

            let s = 0, f = 0, turns = 0, met = -1;
            while (turns < n + 2) {
              if (f === null || link(f) === null) break;
              s = link(s);
              f = link(link(f));
              turns++;
              if (s === f) { met = s; break; }
              steps.push(S({
                title: `Turn ${turns}: slow at ${vals[s]}, fast at ${vals[f]}`,
                ...chain(lbl, vals, statesFor(s, f, false), tagsFor(s, f), live),
                counters: [count("turns", turns), count("slow at", s), count("fast at", f)],
                happened: `slow moves one node to ${vals[s]}; fast moves two and lands on ${f === null ? "null" : vals[f]}.`,
                why: "No collision yet — the two pointers are on different nodes, so keep racing.",
                codeLine: 9,
              }));
            }

            if (met >= 0) {
              steps.push(S({
                title: `Collision at ${vals[met]} → cycle!`,
                ...chain(lbl, vals, statesFor(met, met, true), tagsFor(met, met), live),
                counters: [count("turns", turns), count("slow at", met), count("fast at", met)],
                happened: `Turn ${turns} puts both pointers on index ${met} (${vals[met]}); the hare has caught the tortoise from behind.`,
                why: "On a chain with an end the hare stops at null and can never land on the tortoise, so a collision proves the chain loops.",
                codeLine: 11,
              }));
              steps.push(S({
                title: "Answer: the list has a cycle",
                ...chain(lbl, vals, vals.map((_, i) => (i === met ? "result" : "done")), tagsFor(met, met), live),
                counters: [count("turns", turns), count("answer", "cycle")],
                happened: `The pointers met after ${turns} turn${turns === 1 ? "" : "s"}, so following next eventually revisits a node.`,
                why: "Two pointers and O(1) memory settled the question in one pass.",
                codeLine: 11,
              }));
            } else {
              steps.push(S({
                title: "fast ran off the end → no cycle",
                ...chain(lbl, vals, statesFor(s, f, false), tagsFor(s, f), live),
                counters: [count("turns", turns), count("slow at", s), count("fast at", f === null ? "null" : f)],
                happened: `fast reached ${f === null ? "null" : vals[f]} and has no next node to jump to, so the race stops.`,
                why: "A chain that ends can never bring the pointers back together — reaching null is a complete proof of no cycle.",
                codeLine: 8,
              }));
              steps.push(S({
                title: "Answer: no cycle",
                ...chain(lbl, vals, fill(n, "done"), undefined, true),
                counters: [count("turns", turns), count("answer", "no cycle")],
                happened: "Every pointer step stayed on a fresh node until the chain ran out.",
                why: "The walk ended at null instead of looping, and only O(1) extra space was used.",
                codeLine: 13,
              }));
            }
          } else {
            steps.push(S({
              title: "Answer: no cycle",
              ...chain(lbl, [], [], undefined, true),
              counters: [count("nodes", 0), count("answer", "no cycle")],
              happened: "An empty chain has nothing to loop back to.",
              why: "With no nodes there are no pointers to compare.",
              codeLine: 13,
            }));
          }
          return steps;
        },
      },
      {
        name: "Seen-Set Walk",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Walk the chain from the head and remember every node you touch in a set.",
          "If the next node is already in the set, you have been here before — that is a cycle. If you reach null first, there is none.",
        ],
        problem: [
          "Remembering every node costs O(n) memory, which is exactly the cost the two-pointer trick avoids. It is easier to explain, though, and it also tells you which node was revisited.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

typedef struct Node { int v; struct Node *next; } Node;

/* remember node addresses; a repeat means a loop */
bool has_cycle(Node *head) {
    Node *seen[64];
    int count = 0;
    for (Node *p = head; p; p = p->next) {
        for (int i = 0; i < count; i++)
            if (seen[i] == p)
                return true;
        seen[count++] = p;
    }
    return false;
}`,
          cpp: `#include <iostream>
#include <unordered_set>

struct Node { int val; Node* next; Node(int v) : val(v), next(nullptr) {} };

bool hasCycle(Node* head) {
    std::unordered_set<Node*> seen;
    for (Node* p = head; p; p = p->next) {
        if (!seen.insert(p).second)   // insert failed -> seen before
            return true;
    }
    return false;
}`,
        },
        steps(parsed) {
          const { vals, k } = keyedTokens(parsed, "pos");
          const n = vals.length;
          let pos = k == null ? -1 : k;
          if (!(pos >= 0 && pos < n)) pos = -1;
          const steps = [];
          const link = (i) => (i == null ? null : i === n - 1 ? (pos >= 0 ? pos : null) : i + 1);
          const lbl = pos >= 0 ? `linked list — tail links back to #${pos}` : "linked list";
          const live = pos < 0;

          const seenTrack = (seen) => ({
            label: "nodes visited",
            cells: seen.length
              ? seen.map((i, d) => ({ v: vals[i], state: "done", tag: `#${i}` }))
              : [{ v: "∅", state: "idle", empty: true }],
          });
          const chainStates = (cur, seen) =>
            vals.map((_, i) => (i === cur ? "read" : seen.includes(i) ? "done" : "idle"));
          const chainTags = (cur) =>
            vals.map((_, i) => {
              const parts = [];
              if (i === cur) parts.push("here");
              if (pos >= 0 && i === n - 1) parts.push(`↩ #${pos}`);
              return parts.length ? parts.join(" ") : undefined;
            });

          steps.push(S({
            title: "Plan: remember every node you stand on",
            kind: "cells",
            tracks: [
              chainTrack(lbl, vals, fill(n, "idle"), vals.map((_, i) => (pos >= 0 && i === n - 1 ? `↩ #${pos}` : undefined)), live),
              seenTrack([]),
            ],
            counters: [count("nodes visited", 0, n)],
            happened: n === 0
              ? "The chain is empty; there is nothing to remember."
              : `The set starts empty. Walking ${vals.join(" → ")}${pos < 0 ? " will end at null" : " will run into a node that was already seen"}.`,
            why: "A node identity repeated in the set is the definition of a cycle — no pointer arithmetic needed.",
            codeLine: 6,
          }));

          if (n > 0) {
            const seen = [];
            let i = 0, guard = 0;
            while (i !== null && !seen.includes(i) && guard < n + 2) {
              seen.push(i);
              const nxt = link(i);
              steps.push(S({
                title: `Visit ${vals[i]} (#${i}) — remember it`,
                kind: "cells",
                tracks: [
                  chainTrack(lbl, vals, chainStates(i, seen), chainTags(i), live),
                  seenTrack(seen),
                ],
                counters: [count("nodes visited", seen.length, n), count("next", nxt === null ? "null" : `#${nxt}`)],
                happened: `Node ${vals[i]} is added to the set${nxt === null ? " and its next pointer is null" : `; next comes ${vals[nxt]} at index ${nxt}`}.`,
                why: "Recording the node now makes a later revisit detectable with one lookup.",
                codeLine: 9,
              }));
              i = nxt;
              guard++;
            }
            if (i !== null && seen.includes(i)) {
              steps.push(S({
                title: `#${i} was already visited → cycle at ${vals[i]}`,
                kind: "cells",
                tracks: [
                  chainTrack(lbl, vals, chainStates(i, seen), chainTags(i), live),
                  seenTrack(seen),
                ],
                counters: [count("nodes visited", seen.length, n), count("repeat at", `#${i}`)],
                happened: `The next pointer leads back to index ${i}, and ${vals[i]} is already in the set.`,
                why: "Revisiting a node means the chain can never end — at least one loop exists.",
                codeLine: 10,
              }));
              steps.push(S({
                title: "Answer: the list has a cycle",
                ...chain(lbl, vals, vals.map((_, d) => (d === i ? "result" : seen.includes(d) ? "done" : "dim")), chainTags(i), live),
                counters: [count("nodes visited", seen.length, n), count("answer", "cycle")],
                happened: `The walk stopped at the first repeated node, #${i}.`,
                why: "The set cost O(n) memory but made the repeat a single lookup.",
                codeLine: 10,
              }));
            } else {
              steps.push(S({
                title: "Reached null → no cycle",
                kind: "cells",
                tracks: [chainTrack(lbl, vals, fill(n, "done"), undefined, true), seenTrack(seen)],
                counters: [count("nodes visited", seen.length, n), count("answer", "no cycle")],
                happened: "The walk fell off the end of the chain without meeting a node twice.",
                why: "Every node was new, so no loop can exist.",
                codeLine: 8,
              }));
              steps.push(S({
                title: "Answer: no cycle",
                ...chain(lbl, vals, fill(n, "done"), undefined, true),
                counters: [count("nodes visited", seen.length, n), count("answer", "no cycle")],
                happened: `All ${n} node${n === 1 ? "" : "s"} were distinct and the last one pointed at null.`,
                why: "A complete walk to null is a complete proof of no cycle.",
                codeLine: 13,
              }));
            }
          } else {
            steps.push(S({
              title: "Answer: no cycle",
              ...chain(lbl, [], [], undefined, true),
              counters: [count("nodes visited", 0), count("answer", "no cycle")],
              happened: "An empty chain has nothing to revisit.",
              why: "No nodes means no pointers to follow.",
              codeLine: 13,
            }));
          }
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     4. Linked List Cycle II
     ============================================================ */
  V.register({
    id: "linked-list-cycle-ii",
    title: "Linked List Cycle II",
    category: "Linked Lists",
    difficulty: "Intermediate",
    description: "Return the exact node where the cycle begins.",
    input: { label: "Values, then pos=k for the tail's target", default: "3, 2, 0, -4 pos=1", parse: "tokens" },
    approaches: [
      {
        name: "Floyd's Two Phases",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Phase 1 is the detector: race a tortoise (one node per turn) against a hare (two) until they share a node. If the hare reaches null there is no cycle and the answer is nothing.",
          "Phase 2 exploits the spacing: reset the tortoise to the head and now move both pointers one node at a time. They meet exactly on the first node inside the loop — the place the tail points back to.",
        ],
        problem: [
          "The two phases must be identical in spirit but differ in speed: moving the hare two nodes in phase 2 slides right past the entrance. Meeting inside the loop is only half the answer.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int v; struct Node *next; } Node;

/* phase 1 finds any node inside the loop; phase 2 lands on its start */
Node *cycle_start(Node *head) {
    Node *slow = head, *fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast)
            break;
    }
    if (!fast || !fast->next)
        return NULL;                   /* no loop at all */
    slow = head;                       /* reset one pointer */
    while (slow != fast) {
        slow = slow->next;
        fast = fast->next;
    }
    return slow;                       /* both stand on the entrance */
}`,
          cpp: `#include <iostream>

struct Node { int val; Node* next; Node(int v) : val(v), next(nullptr) {} };

Node* detectCycle(Node* head) {
    Node* slow = head;
    Node* fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) break;       // phase 1: any meeting node
    }
    if (!fast || !fast->next) return nullptr;
    slow = head;                       // phase 2: both one step at a time
    while (slow != fast) {
        slow = slow->next;
        fast = fast->next;
    }
    return slow;
}`,
        },
        steps(parsed) {
          const { vals, k } = keyedTokens(parsed, "pos");
          const n = vals.length;
          let pos = k == null ? -1 : k;
          if (!(pos >= 0 && pos < n)) pos = -1;
          const steps = [];
          const link = (i) => (i == null ? null : i === n - 1 ? (pos >= 0 ? pos : null) : i + 1);
          const lbl = pos >= 0 ? `linked list — tail links back to #${pos}` : "linked list";
          const live = pos < 0;

          const tagsFor = (a, b, phase) =>
            vals.map((_, i) => {
              const parts = [];
              if (phase === 1 && i === a) parts.push("slow");
              if (phase === 1 && i === b) parts.push("fast");
              if (phase === 2 && i === a) parts.push("from head");
              if (phase === 2 && i === b) parts.push("from meeting");
              if (pos >= 0 && i === n - 1) parts.push(`↩ #${pos}`);
              return parts.length ? parts.join(" ") : undefined;
            });
          const statesFor = (a, b, mark) =>
            vals.map((_, i) => {
              if (i === a && i === b) return "result";
              if (i === a || i === b) return mark;
              return "idle";
            });

          steps.push(S({
            title: "Plan: find any loop node, then walk back to the head",
            ...chain(lbl, vals, fill(n, "idle"), vals.map((_, i) => (pos >= 0 && i === n - 1 ? `↩ #${pos}` : undefined)), live),
            counters: [count("nodes", n)],
            happened: n === 0
              ? "There are no nodes, so there is no cycle to locate."
              : `The chain reads ${vals.join(" → ")}${pos < 0 ? ` → null` : ` and its tail points back to index ${pos} (${vals[pos]})`}.`,
            why: "Detecting a loop and locating its entrance are two different questions — the second needs the extra reset step.",
            codeLine: 6,
          }));

          if (n > 0) {
            steps.push(S({
              title: `Phase 1 starts: both pointers on ${vals[0]}`,
              ...chain(lbl, vals, statesFor(0, 0, "compare"), tagsFor(0, 0, 1), live),
              counters: [count("phase", 1), count("turns", 0)],
              happened: `slow and fast sit together on index 0, the node ${vals[0]}.`,
              why: "The race only proves a loop if it begins from the same place.",
              codeLine: 7,
            }));

            let s = 0, f = 0, turns = 0, met = -1;
            while (turns < n + 2) {
              if (f === null || link(f) === null) break;
              s = link(s);
              f = link(link(f));
              turns++;
              if (s === f) { met = s; break; }
              steps.push(S({
                title: `Phase 1, turn ${turns}: slow at ${vals[s]}, fast at ${vals[f]}`,
                ...chain(lbl, vals, statesFor(s, f, "read"), tagsFor(s, f, 1), live),
                counters: [count("phase", 1), count("turns", turns), count("slow at", s), count("fast at", f)],
                happened: `slow steps one node to ${vals[s]}; fast jumps two and lands on ${vals[f]}.`,
                why: "Inside a loop the gap between them shrinks by one node per turn, so a collision is inevitable.",
                codeLine: 10,
              }));
            }

            if (met < 0) {
              steps.push(S({
                title: "fast reached the end → no cycle",
                ...chain(lbl, vals, fill(n, "done"), undefined, true),
                counters: [count("phase", 1), count("answer", "no cycle")],
                happened: "The race stopped at the end of the chain without the pointers ever sharing a node.",
                why: "Nothing to locate: without a loop there is no entrance node.",
                codeLine: 13,
              }));
              steps.push(S({
                title: "Answer: no cycle",
                ...chain(lbl, vals, fill(n, "done"), undefined, true),
                counters: [count("turns", turns), count("answer", "no cycle")],
                happened: "The answer is null — the chain simply ends.",
                why: "Both phases were guarded, so a straight chain exits cleanly instead of looping forever.",
                codeLine: 14,
              }));
              return steps;
            }

            steps.push(S({
              title: `Phase 1 ends: both on ${vals[met]} (#${met})`,
              ...chain(lbl, vals, statesFor(met, met, "result"), tagsFor(met, met, 1), live),
              counters: [count("phase", 1), count("turns", turns), count("meeting node", `#${met}`)],
              happened: `Turn ${turns} lands slow and fast on the same node, ${vals[met]} — a loop is confirmed.`,
              why: "Meeting is guaranteed inside the loop, but the meeting node is usually not its entrance; it is just a witness.",
              codeLine: 12,
            }));
            steps.push(S({
              title: "Reset slow back to the head",
              ...chain(lbl, vals, paint(fill(n, "idle"), { 0: "read", [met]: "active" }), tagsFor(0, met, 2), live),
              counters: [count("phase", 2), count("from head", 0), count("from meeting", met)],
              happened: `slow goes back to index 0 (${vals[0]}) while fast stays parked on the meeting node #${met}.`,
              why: "The distance from the head to the entrance exactly equals the distance from the meeting node around the loop — phase 2 cashes in on that.",
              codeLine: 15,
            }));

            let a = 0, b = met, moves = 0;
            while (a !== b && moves < n + 2) {
              a = link(a);
              b = link(b);
              moves++;
              steps.push(S({
                title: `Phase 2, step ${moves}: first → ${vals[a]}, second → ${vals[b]}`,
                ...chain(lbl, vals, statesFor(a, b, "compare"), tagsFor(a, b, 2), live),
                counters: [count("phase", 2), count("steps", moves), count("pointer 1 at", `#${a}`), count("pointer 2 at", `#${b}`)],
                happened: `The pointer from the head lands on ${vals[a]} (#${a}) while the one from the meeting node lands on ${vals[b]} (#${b}).`,
                why: moves === 1
                  ? "Both pointers now creep one node per turn — the same speed keeps the spacing that phase 1 created."
                  : "They started at the right spacing, so moving at the same speed can only bring them closer.",
                codeLine: 16,
              }));
            }

            steps.push(S({
              title: `Answer: the cycle starts at #${a} (${vals[a]})`,
              ...chain(lbl, vals, vals.map((_, i) => (i === a ? "result" : "done")), tagsFor(a, a, 2), live),
              counters: [count("turns", turns), count("steps in phase 2", moves), count("answer", `#${a} → ${vals[a]}`)],
              happened: `Both pointers touch index ${a} at the same time, and index ${a} is exactly where the tail links back${pos >= 0 ? ` (pos=${pos})` : ""}.`,
              why: "Comparing node identities, not values, is what makes the arrival unambiguous — the two pointers meet on one single node.",
              codeLine: 20,
            }));
          } else {
            steps.push(S({
              title: "Answer: no cycle",
              ...chain(lbl, [], [], undefined, true),
              counters: [count("nodes", 0), count("answer", "no cycle")],
              happened: "The chain is empty, so there is no entrance to report.",
              why: "An empty list has no loop and nothing to return.",
              codeLine: 20,
            }));
          }
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     5. Merge Two Sorted Lists
     ============================================================ */
  V.register({
    id: "merge-two-sorted-lists",
    title: "Merge Two Sorted Lists",
    category: "Linked Lists",
    difficulty: "Beginner",
    description: "Interleave two sorted chains into one sorted chain.",
    input: { label: "list1 | list2", default: "1, 2, 4 | 1, 3, 4", parse: "tworows" },
    approaches: [
      {
        name: "Dummy Anchor Merge",
        complexity: "O(n + m) time, O(1) space",
        idea: [
          "Keep a tail pointer on the result and a front pointer on each list. Every round, look at the two fronts, move the smaller one to the back of the result, and advance only that list.",
          "When one list runs out, the other one's remaining run is already sorted and already bigger than everything placed so far, so it can be hung on in a single link.",
        ],
        problem: [
          "The very first append is awkward because the result is still empty — a throwaway dummy node in front of it removes that special case. Ties (equal values) go to list 1 so the merge stays stable.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int v; struct Node *next; } Node;

/* stitch the two fronts together; a dummy anchors the result */
Node *merge(Node *a, Node *b) {
    Node dummy;
    Node *tail = &dummy;
    dummy.next = NULL;
    while (a && b) {
        if (a->v <= b->v) {
            tail->next = a; a = a->next;
        } else {
            tail->next = b; b = b->next;
        }
        tail = tail->next;
    }
    tail->next = a ? a : b;            /* the leftover run */
    return dummy.next;
}`,
          cpp: `#include <iostream>

struct Node { int val; Node* next; Node(int v) : val(v), next(nullptr) {} };

// repeatedly take the smaller front node
Node* mergeTwoLists(Node* a, Node* b) {
    Node dummy(0);
    Node* tail = &dummy;
    while (a && b) {
        if (a->val <= b->val) { tail->next = a; a = a->next; }
        else                  { tail->next = b; b = b->next; }
        tail = tail->next;
    }
    tail->next = a ? a : b;            // hang whatever is left
    return dummy.next;
}`,
        },
        steps(rows) {
          const A = rows[0] || [], B = rows[1] || [];
          const m = A.length, k = B.length;
          const steps = [];

          const srcStates = (ptr) => (arr) =>
            arr.map((_, i) => (i < ptr ? "done" : i === ptr ? "compare" : "idle"));
          const srcTags = (ptr) => (arr) =>
            arr.map((_, i) => (i === ptr ? "head" : undefined));

          const mergedTrack = (out, withDummy) => {
            const cells = [];
            if (withDummy !== false) cells.push({ v: "dummy", state: "dim", empty: true, tag: "anchor" });
            out.forEach((v, i) => cells.push({ v, state: i === out.length - 1 ? "read" : "result" }));
            cells.push({ v: "null", state: "idle", empty: true });
            return { label: "merged list", arrows: true, cells };
          };

          steps.push(S({
            title: "Plan: always take the smaller front",
            kind: "cells",
            tracks: [
              chainTrack("list 1", A, fill(m, "idle")),
              chainTrack("list 2", B, fill(k, "idle")),
              mergedTrack([], false),
            ],
            counters: [count("taken", 0, m + k), count("positions left", m + k)],
            happened: `list 1 holds ${A.join(" → ")} and list 2 holds ${B.join(" → ")}; the merged list is empty.`,
            why: "Both inputs are sorted, so whichever front value is smaller is the smallest value anywhere in both lists combined.",
            codeLine: 5,
          }));
          steps.push(S({
            title: "Set up a dummy anchor and a tail pointer",
            kind: "cells",
            tracks: [
              chainTrack("list 1", A, fill(m, "idle")),
              chainTrack("list 2", B, fill(k, "idle")),
              mergedTrack([], true),
            ],
            counters: [count("taken", 0, m + k), count("merged length", 0)],
            happened: "A throwaway dummy node sits at the front of the merged list and the tail pointer rests on it.",
            why: "The dummy makes the first append identical to every later one — no separate \"result was empty\" branch to get wrong.",
            codeLine: 6,
          }));

          let i = 0, j = 0;
          const out = [];
          while (i < m && j < k) {
            const a = A[i], b = B[j];
            const takeA = a <= b;
            const taken = takeA ? a : b;
            out.push(taken);
            if (takeA) i++; else j++;
            steps.push(S({
              title: `Take ${taken} from list ${takeA ? 1 : 2}`,
              kind: "cells",
              tracks: [
                chainTrack("list 1", A, srcStates(i)(A), srcTags(i)(A)),
                chainTrack("list 2", B, srcStates(j)(B), srcTags(j)(B)),
                mergedTrack(out),
              ],
              counters: [
                count("taken", out.length, m + k),
                count("front of list 1", i < m ? A[i] : "null"),
                count("front of list 2", j < k ? B[j] : "null"),
              ],
              happened: `The fronts were ${a} and ${b}; ${taken} is ${a === b ? "not larger, and ties go to list 1" : "the smaller of the two"}, so it joins the merged list and only its own list advances.`,
              why: "Just the two fronts are ever compared — the deeper nodes stay put until their turn arrives.",
              codeLine: takeA ? 10 : 12,
            }));
          }

          if (i < m || j < k) {
            const fromList1 = i < m;
            const rest = fromList1 ? A.slice(i) : B.slice(j);
            if (fromList1) i = m; else j = k;
            out.push(...rest);
            steps.push(S({
              title: `list ${fromList1 ? 2 : 1} is empty → hang the rest of list ${fromList1 ? 1 : 2}`,
              kind: "cells",
              tracks: [
                chainTrack("list 1", A, srcStates(i)(A), srcTags(i)(A)),
                chainTrack("list 2", B, srcStates(j)(B), srcTags(j)(B)),
                mergedTrack(out),
              ],
              counters: [
                count("taken", out.length, m + k),
                count("linked in one move", rest.length),
                count("merged length", out.length),
              ],
              happened: `The leftover run ${rest.join(" → ")} is still sorted and everything already placed is smaller, so one link attaches all of it.`,
              why: "This is why the merge costs n + m total: each node is examined once and never copied.",
              codeLine: 16,
            }));
          }

          steps.push(S({
            title: `Answer: ${out.join(" → ")}`,
            ...chain("merged list", out, fill(out.length, "result")),
            counters: [count("merged length", out.length), count("answer", out.join(" → "))],
            happened: `The dummy is discarded and the result reads ${out.join(" → ")} → null.`,
            why: "One pass over both lists produced a single sorted chain using only pointer writes — no array and no sorting step.",
            codeLine: 17,
          }));
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     6. Remove Nth Node from End
     ============================================================ */
  V.register({
    id: "remove-nth-node-from-end",
    title: "Remove Nth Node from End",
    category: "Linked Lists",
    difficulty: "Intermediate",
    description: "Cut out the node that sits n places behind the last one.",
    input: { label: "Values, then n=k", default: "1, 2, 3, 4, 5 n=2", parse: "tokens" },
    approaches: [
      {
        name: "Count, Then Walk",
        complexity: "O(n) time, O(1) space",
        idea: [
          "First pass: count the length L of the chain. Counting from the end is impossible, so counting from the front is the only option.",
          "The node to remove sits at index L - n counting from the head. Walk to its predecessor and relink around it. If n equals L, the head itself goes.",
        ],
        problem: [
          "Two full passes over the chain. The count also needs careful arithmetic: index L - n is the node itself, so the walk stops one node earlier at L - n - 1.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int v; struct Node *next; } Node;

/* two passes: learn the length, then cut the (len-n)th node */
Node *remove_nth(Node *head, int n) {
    int len = 0;
    for (Node *p = head; p; p = p->next)
        len++;
    if (n > len)
        return head;                   /* nothing to remove */
    if (n == len)
        return head->next;             /* the head itself goes */
    Node *p = head;
    for (int i = 0; i < len - n - 1; i++)
        p = p->next;
    p->next = p->next->next;           /* skip the node */
    return head;
}`,
          cpp: `#include <iostream>

struct Node { int val; Node* next; Node(int v) : val(v), next(nullptr) {} };

// pass 1 counts, pass 2 stops just before the victim
Node* removeNthFromEnd(Node* head, int n) {
    int len = 0;
    for (Node* p = head; p; p = p->next) ++len;
    if (n > len) return head;          // n is out of range
    if (n == len) return head->next;   // remove the head
    Node* p = head;
    for (int i = 0; i < len - n - 1; ++i) p = p->next;
    p->next = p->next->next;
    return head;
}`,
        },
        steps(parsed) {
          const { vals, k } = keyedTokens(parsed, "n");
          const n = vals.length;
          if (n === 0) return emptySteps("Nothing to remove", "An empty chain has no nth-from-end node.");
          let rem = k == null ? 1 : k;
          if (!(rem >= 1)) rem = 1;
          const steps = [];
          const target = n - rem; // index from the head, only valid when rem <= n
          const fits = rem <= n;

          const tagsFor = (idx, cursor) =>
            vals.map((_, i) => {
              const parts = [];
              if (fits && idx >= 0 && i === idx) parts.push(fits && target === 0 ? "remove (head)" : "remove");
              if (cursor != null && i === cursor) parts.push("cursor");
              return parts.length ? parts.join(" ") : undefined;
            });

          steps.push(S({
            title: "Plan: count forwards so we can cut from the back",
            ...chain("linked list", vals, fill(n, "idle")),
            counters: [count("n from the end", rem), count("length so far", 0)],
            happened: `The chain holds ${vals.join(" → ")} and we must drop the node that is ${rem} step${rem === 1 ? "" : "s"} from the last one.`,
            why: "next only points forward, so the only way to count \"from the end\" is to learn the total length first.",
            codeLine: 5,
          }));

          let len = 0;
          for (let i = 0; i < n; i++) {
            len = i + 1;
            steps.push(S({
              title: `Count node ${vals[i]} → length ${len}`,
              ...chain("linked list", vals, paint(fill(n, "idle"), { [i]: "read" }), tagsFor(-1, i)),
              counters: [count("length so far", len, n), count("n from the end", rem)],
              happened: `The counting pointer reaches ${vals[i]}, so the length so far is ${len}.`,
              why: "Once the walk ends the length is known exactly, and from-the-front indexing becomes possible.",
              codeLine: 7,
            }));
          }

          if (!fits) {
            steps.push(S({
              title: `n = ${rem} is larger than the list (${n}) → nothing removed`,
              ...chain("linked list", vals, fill(n, "done")),
              counters: [count("length", n), count("n from the end", rem)],
              happened: `There are only ${n} node${n === 1 ? "" : "s"}, so the ${rem}th from the end does not exist.`,
              why: "Checking the range before walking avoids a null dereference; the safe answer is to leave the list alone.",
              codeLine: 9,
            }));
            steps.push(S({
              title: "Answer: list unchanged",
              ...chain("linked list", vals, fill(n, "result")),
              counters: [count("length", n), count("answer", "nothing removed")],
              happened: `${vals.join(" → ")} → null exactly as before.`,
              why: "Guards like this keep a removal routine from reading past the head of a short list.",
              codeLine: 9,
            }));
            return steps;
          }

          steps.push(S({
            title: `Length is ${n} → index ${target} holds the node to cut`,
            ...chain("linked list", vals, fill(n, "done"), tagsFor(target, null)),
            counters: [count("length", n), count("n from the end", rem), count("index to cut", target)],
            happened: rem === n
              ? `Counting ${rem} back from the last node lands on index 0 — the head has to go.`
              : `Counting ${rem} back from the last node lands on index ${target} (${vals[target]}).`,
            why: "Distance from the front is length minus distance from the back — that swap is the whole trick of this approach.",
            codeLine: 9,
          }));

          if (target === 0) {
            steps.push(S({
              title: `Unlink: the new head is ${vals[1] !== undefined ? vals[1] : "null"}`,
              ...chain("linked list", vals, paint(fill(n, "done"), { 0: "bad" }), tagsFor(0, null)),
              counters: [count("predecessor", "none"), count("index to cut", 0)],
              happened: `The victim ${vals[0]} is the head, so there is nothing to relink — the caller simply receives the second node instead.`,
              why: "Special-casing the head prevents looking for a predecessor that does not exist.",
              codeLine: 11,
            }));
          } else {
            for (let c = 0; c <= target - 1; c++) {
              steps.push(S({
                title: `Walk to the predecessor: ${vals[c]}`,
                ...chain("linked list", vals, vals.map((_, i) => (i < c ? "done" : i === c ? "read" : "idle")), tagsFor(target, c)),
                counters: [count("steps taken", c + 1, target), count("predecessor", vals[c]), count("victim", vals[target])],
                happened: `The cursor stops on ${vals[c]}, the node right before ${vals[target]}.`,
                why: "To cut a node out you must hold the node that points at it — stopping one short is exactly right.",
                codeLine: 13,
              }));
            }
            const p = target - 1;
            steps.push(S({
              title: `Unlink: ${vals[p]} now points to ${target + 1 < n ? vals[target + 1] : "null"}`,
              ...chain("linked list", vals, vals.map((_, i) => (i === p ? "active" : i === target ? "bad" : "done")), tagsFor(target, p)),
              counters: [count("predecessor", vals[p]), count("skipped", vals[target]), count("length now", n - 1)],
              happened: `One write relinks ${vals[p]} straight past ${vals[target]} → ${target + 1 < n ? vals[target + 1] : "null"}.`,
              why: "The node itself is simply dropped — with no references left it stops being part of the chain.",
              codeLine: 15,
            }));
          }

          const kept = vals.filter((_, i) => i !== target);
          steps.push(S({
            title: `Answer: ${kept.join(" → ")}`,
            ...chain("linked list", kept, fill(kept.length, "result")),
            counters: [count("length", n - 1), count("removed", vals[target]), count("answer", kept.join(" → ") || "empty")],
            happened: `Node ${vals[target]} is gone; the chain now reads ${kept.join(" → ")} → null.`,
            why: "The whole job took one counting pass and one short walk — O(n) time with only a couple of pointers.",
            codeLine: 16,
          }));
          return steps;
        },
      },
      {
        name: "One Pass with a Gap",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Put a dummy node in front of the head and start two pointers on it. Run the leading pointer n + 1 steps ahead (or until it falls off the end).",
          "Then advance both together. When the leader hits null the follower is sitting on the node just before the victim, so one relink does the removal in a single sweep.",
        ],
        problem: [
          "The dummy is what lets the head be removed with no special case, and the up-front range check matters: if n is bigger than the length the gap never forms and the routine would otherwise cut the wrong node.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int v; struct Node *next; } Node;

/* open a gap of n between two pointers, then walk them together */
Node *remove_nth(Node *head, int n) {
    Node dummy;
    dummy.next = head;
    Node *first = &dummy, *second = &dummy;
    for (int i = 0; i <= n; i++)
        if (first)
            first = first->next;
    while (first) {
        first = first->next;
        second = second->next;
    }
    second->next = second->next->next; /* skip the victim */
    return dummy.next;
}`,
          cpp: `#include <iostream>

struct Node { int val; Node* next; Node(int v) : val(v), next(nullptr) {} };

// the trailing pointer stops right before the node that must go
Node* removeNthFromEnd(Node* head, int n) {
    Node dummy(0);
    dummy.next = head;
    Node* first = &dummy;
    Node* second = &dummy;
    for (int i = 0; i <= n; ++i)
        if (first) first = first->next;
    while (first) {
        first = first->next;
        second = second->next;
    }
    second->next = second->next->next;
    return dummy.next;
}`,
        },
        steps(parsed) {
          const { vals, k } = keyedTokens(parsed, "n");
          const n = vals.length;
          if (n === 0) return emptySteps("Nothing to remove", "An empty chain has no nth-from-end node.");
          let rem = k == null ? 1 : k;
          if (!(rem >= 1)) rem = 1;
          const steps = [];
          const fits = rem <= n;
          const victim = n - rem;

          const tagsFor = (second, first, showVictim) =>
            vals.map((_, i) => {
              const parts = [];
              if (second === i) parts.push("second");
              if (first === i) parts.push("first");
              if (showVictim && i === victim) parts.push("remove");
              return parts.length ? parts.join(" ") : undefined;
            });
          const statesFor = (second, first, showVictim) =>
            vals.map((_, i) => {
              if (showVictim && i === victim) return "bad";
              if (i === first || i === second) return i === first && i === second ? "compare" : "read";
              return "idle";
            });

          steps.push(S({
            title: "Plan: open a gap of n, then walk both ends",
            ...chain("linked list", vals, fill(n, "idle")),
            counters: [count("n from the end", rem), count("gap wanted", rem + 1)],
            happened: `The chain holds ${vals.join(" → ")} and the removal target is ${rem} step${rem === 1 ? "" : "s"} from the tail.`,
            why: "A fixed gap turns \"from the end\" into \"from the front\": when the leader is past the end, the follower has counted the same distance.",
            codeLine: 6,
          }));
          steps.push(S({
            title: "Set up a dummy node before the head",
            ...chain("linked list", vals, paint(fill(n, "idle"), { 0: "read" }), tagsFor(-1, 0, false)),
            counters: [count("first at", "dummy"), count("second at", "dummy"), count("gap", 1)],
            happened: `A dummy node points at ${vals[0]} and both pointers start on it.`,
            why: "Starting the follower on the dummy is what makes removing the head (n = length) work with no extra branch.",
            codeLine: 7,
          }));

          if (!fits) {
            steps.push(S({
              title: `n = ${rem} is larger than the list (${n}) → gap never forms`,
              ...chain("linked list", vals, fill(n, "done")),
              counters: [count("length", n), count("n from the end", rem)],
              happened: `The leading pointer runs out after ${n} node${n === 1 ? "" : "s"} before the gap reaches ${rem + 1}, so the removal is abandoned.`,
              why: "Detecting the short list early stops the routine from unlinking a node that was never the target.",
              codeLine: 11,
            }));
            steps.push(S({
              title: "Answer: list unchanged",
              ...chain("linked list", vals, fill(n, "result")),
              counters: [count("length", n), count("answer", "nothing removed")],
              happened: `${vals.join(" → ")} → null exactly as before.`,
              why: "One sweep would normally be enough, but only when n actually fits inside the chain.",
              codeLine: 14,
            }));
            return steps;
          }

          let first = -1; // -1 stands for the dummy node
          const gapSteps = rem + 1;
          for (let g = 1; g <= gapSteps; g++) {
            first = g <= n ? g - 1 : null;
            const at = first;
            steps.push(S({
              title: `Leader step ${g} of ${gapSteps} → ${at === null ? "null (past the end)" : at === -1 ? "dummy" : `#${at} (${vals[at]})`}`,
              ...chain("linked list", vals, statesFor(-1, at, false), tagsFor(-1, at, false)),
              counters: [
                count("gap", g, gapSteps),
                count("first at", at === null ? "null" : at === -1 ? "dummy" : `#${at}`),
                count("second at", "dummy"),
              ],
              happened: at === null
                ? "The leader steps past the last node and lands in null — the gap is complete."
                : `The leading pointer slides onto index ${at} (${vals[at]}), widening the gap to ${g}.`,
              why: "The leader travels n + 1 nodes so the follower ends up exactly one node before the victim.",
              codeLine: 9,
            }));
          }

          let second = -1;
          let moves = 0;
          while (first !== null && moves < n + 2) {
            first = first + 1 <= n - 1 ? first + 1 : null;
            second = second + 1 <= n - 1 ? second + 1 : second;
            moves++;
            steps.push(S({
              title: `Both move: follower on ${second === -1 ? "dummy" : `#${second} (${vals[second]})`}, leader ${first === null ? "off the end" : `on #${first}`}`,
              ...chain("linked list", vals, statesFor(second, first, false), tagsFor(second, first, false)),
              counters: [
                count("first at", first === null ? "null" : `#${first}`),
                count("second at", second === -1 ? "dummy" : `#${second}`),
                count("steps", moves),
              ],
              happened: first === null
                ? `The leader runs off the end, leaving the follower on ${second === -1 ? "the dummy" : `index ${second} (${vals[second]})`} — the node right before the victim.`
                : `Both pointers creep forward one node: the leader onto #${first}, the follower onto ${second === -1 ? "the dummy" : `#${second}`}.`,
              why: "The gap is already set, so moving at the same speed keeps it constant — when the leader falls into null the follower is exactly in place.",
              codeLine: 12,
            }));
            if (first === null) break;
          }

          steps.push(S({
            title: `Unlink: cut ${vals[victim]}`,
            ...chain("linked list", vals, statesFor(second, victim, true), tagsFor(second, first, true)),
            counters: [
              count("follower", second === -1 ? "dummy" : `#${second}`),
              count("victim", vals[victim]),
              count("length now", n - 1),
            ],
            happened: `The follower sits on ${second === -1 ? "the dummy" : `${vals[second]} (index ${second})`}, and its next pointer swings past ${vals[victim]} onto ${victim + 1 < n ? `${vals[victim + 1]}` : "null"}.`,
            why: "One pointer assignment removes the node — no length counting and no second pass over the chain.",
            codeLine: 14,
          }));

          const kept = vals.filter((_, i) => i !== victim);
          steps.push(S({
            title: `Answer: ${kept.join(" → ")}`,
            ...chain("linked list", kept, fill(kept.length, "result")),
            counters: [count("length", n - 1), count("removed", vals[victim]), count("answer", kept.join(" → ") || "empty")],
            happened: `Node ${vals[victim]} is out and the chain reads ${kept.join(" → ")} → null.`,
            why: "The dummy never entered the result, so the real head is returned untouched.",
            codeLine: 15,
          }));
          return steps;
        },
      },
    ],
  });
})();
