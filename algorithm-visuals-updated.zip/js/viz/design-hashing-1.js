/* ============================================================
   DSA Visuals — Design & Hashing
   Buckets, caches and counters. Each structure is shown as the
   state it keeps, not as library calls.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const nums = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number);
  const show = (a) => `[${a.join(", ")}]`;
  const ops = (text) => String(text || "").split(";").map((s) => s.trim()).filter(Boolean);

  /* ---------------------------------------------------------- */
  V.register({
    id: "continuous-subarray-sum",
    title: "Continuous Subarray Sum",
    category: "Design & Hashing",
    difficulty: "Intermediate",
    description:
      "Decide whether some subarray of length at least two sums to a multiple of k, using prefix remainders.",
    input: { label: "numbers | k", default: "23,2,4,6,7 | 6", parse: "string" },
    approaches: [
      {
        name: "First Index of Each Remainder",
        complexity: "O(n) time, O(k) space",
        idea: [
          "A subarray sum is a multiple of k exactly when two prefix sums share the same remainder modulo k.",
          "Store the earliest index for each remainder. A repeat at least two positions later proves such a subarray exists.",
        ],
        problem: [
          "The length-at-least-two rule matters: two equal remainders at adjacent indices describe a one-element multiple and must be rejected.",
        ],
        code: {
          c: `#include <stdio.h>

int has_multiple(int *a, int n, int k) {
    int first[100000];
    for (int i = 0; i < k; i++) first[i] = -2;   /* -2 = unseen, -1 = index -1 */
    first[0] = -1;

    long long prefix = 0;
    for (int i = 0; i < n; i++) {
        prefix += a[i];
        int r = (int)(prefix % k);
        if (first[r] == -2) first[r] = i;
        else if (i - first[r] >= 2) return 1;
    }
    return 0;
}

int main(void) {
    int a[] = {23, 2, 4, 6, 7};
    printf("%d\\n", has_multiple(a, 5, 6)); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

bool checkSubarraySum(vector<int> a, int k) {
    unordered_map<int, int> first;
    first[0] = -1;
    long long prefix = 0;

    for (int i = 0; i < (int)a.size(); i++) {
        prefix += a[i];
        int r = (int)(prefix % k);
        if (first.count(r)) {
            if (i - first[r] >= 2) return true;
        } else {
            first[r] = i;
        }
    }
    return false;
}

int main() {
    cout << checkSubarraySum({23,2,4,6,7}, 6) << '\\n'; // 1
}`,
        },
        steps(text) {
          const [numsRaw, kRaw] = parts(text);
          const a = nums(numsRaw);
          const k = Math.max(1, parseInt(kRaw, 10) || 1);
          if (!a.length) {
            return [{
              title: "Give numbers and k",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("k", k)],
              legend: ["idle", "result"],
              happened: "The right side is the divisor k.",
              why: "Prefix remainders repeat only when a subarray sum divides by k.",
            }];
          }
          const steps = [];
          const first = new Map([[0, -1]]);
          let prefix = 0, answer = null;
          steps.push({
            title: `Remainder 0 is recorded at index −1 before any value`,
            tracks: [track("numbers", a, fill(a.length, "idle")), chips("first index by remainder", ["0 → −1"], "dim")],
            counters: [count("prefix", 0), count("remainders", first.size)],
            legend: LEG,
            happened: "The empty prefix has remainder 0.",
            why: "Seeding index −1 lets a prefix that starts at the first element match remainder 0.",
            codeLine: 3,
          });
          for (let i = 0; i < a.length; i++) {
            prefix += a[i];
            const r = ((prefix % k) + k) % k;
            const seen = first.has(r);
            const span = seen ? i - first.get(r) : null;
            const found = seen && span >= 2;
            if (!seen) first.set(r, i);
            if (found && answer == null) answer = [first.get(r) + 1, i];
            steps.push({
              title: `Index ${i}: prefix ${prefix}, remainder ${r}${seen ? ` (first at ${first.get(r)})` : " (new)"}`,
              tracks: [
                track("numbers", a, a.map((_, j) => (j === i ? "read" : j < i ? "done" : "dim"))),
                chips("first index", [...first.entries()].map(([rem, idx]) => `${rem} → ${idx}`), (j) => ([...first.keys()][j] === r ? "active" : "dim")),
              ],
              counters: [count("prefix", prefix), count("remainder", r), count("span", span == null ? "—" : span)],
              legend: LEG,
              happened: !seen
                ? `Remainder ${r} is new, so remember index ${i}.`
                : found
                  ? `The same remainder appeared at ${first.get(r)}, and the gap is ${span} ≥ 2.`
                  : `The repeat is only ${span} index apart, which is too short.`,
              why: "Equal remainders mean the values between the two indices sum to a multiple of k.",
              codeLine: found ? 9 : seen ? 8 : 7,
            });
          }
          steps.push({
            title: answer ? `Answer: yes, subarray ${answer[0]}..${answer[1]}` : "Answer: no such subarray",
            tracks: [
              track("numbers", a, a.map((_, j) => (answer && j >= answer[0] && j <= answer[1] ? "result" : "dim"))),
              chips("answer", [answer ? "yes" : "no"], "result"),
            ],
            counters: [count("prefix", prefix), count("answer", answer ? "yes" : "no")],
            legend: LEG,
            happened: answer ? `The middle values between the repeated remainders form the subarray.` : "No remainder repeated with a gap of at least two.",
            why: "One pass with a remainder table is enough because only the earliest index per remainder matters.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "design-hashmap",
    title: "Design Hashmap",
    category: "Design & Hashing",
    difficulty: "Intermediate",
    description:
      "Build a map with put, get and remove on top of a fixed array of buckets that chain collisions.",
    input: {
      label: "put key value ; get key ; remove key",
      default: "put 1 1 ; put 2 2 ; get 1 ; get 3 ; put 2 1 ; get 2 ; remove 2 ; get 2",
      parse: "string",
    },
    approaches: [
      {
        name: "Array of Buckets With Chaining",
        complexity: "O(1) average per operation, O(n) worst case",
        idea: [
          "Hash the key to a bucket index. Each bucket holds the entries that map there, so collisions do not overwrite each other.",
          "put replaces an existing key or appends a new pair; get and remove scan only that one bucket.",
        ],
        problem: [
          "A bad hash sends every key to the same bucket, degrading each operation to a linear scan.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

#define BUCKETS 5
typedef struct Entry { int key, value; struct Entry *next; } Entry;

Entry *table[BUCKETS];

Entry *find(int key) {
    for (Entry *e = table[key % BUCKETS]; e; e = e->next)
        if (e->key == key) return e;
    return NULL;
}

void put(int key, int value) {
    Entry *e = find(key);
    if (e) { e->value = value; return; }
    e = malloc(sizeof(Entry));
    e->key = key; e->value = value;
    e->next = table[key % BUCKETS];
    table[key % BUCKETS] = e;
}

int get(int key) { Entry *e = find(key); return e ? e->value : -1; }

int main(void) {
    put(1, 1); put(2, 2);
    printf("%d %d\\n", get(1), get(3)); /* 1 -1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <list>
using namespace std;

class MyHashMap {
    static const int BUCKETS = 5;
    vector<list<pair<int,int>>> table;
public:
    MyHashMap() : table(BUCKETS) {}

    void put(int key, int value) {
        auto& bucket = table[key % BUCKETS];
        for (auto& [k, v] : bucket) if (k == key) { v = value; return; }
        bucket.push_back({key, value});
    }

    int get(int key) {
        for (auto& [k, v] : table[key % BUCKETS]) if (k == key) return v;
        return -1;
    }

    void remove(int key) {
        table[key % BUCKETS].remove_if([&](auto& p) { return p.first == key; });
    }
};

int main() {
    MyHashMap m;
    m.put(1, 1); m.put(2, 2);
    cout << m.get(1) << ' ' << m.get(3) << '\\n'; // 1 -1
    return 0;
}`,
        },
        steps(text) {
          const list = ops(text);
          const buckets = Array.from({ length: 5 }, () => []);
          const steps = [];
          const bucketOf = (key) => Math.abs(key) % 5;
          const render = (mark) =>
            grid(5, 4, (r, c) => {
              const e = buckets[r][c];
              const marked = mark && mark.row === r && mark.col === c;
              return { v: e ? `${e.key}:${e.value}` : "·", state: marked ? mark.state : e ? "idle" : "dim" };
            });
          steps.push({
            title: "Five buckets, each holding a chain",
            kind: "grid", rows: 5, cols: 4,
            cells: render(),
            rowHeads: [0, 1, 2, 3, 4],
            counters: [count("buckets", 5), count("entries", 0)],
            legend: LEG,
            happened: "A key is placed in bucket key mod 5.",
            why: "Chaining keeps colliding keys together instead of overwriting.",
            codeLine: 5,
          });
          for (const op of list) {
            const words = op.split(/\s+/);
            const name = words[0].toLowerCase();
            const key = parseInt(words[1], 10) || 0;
            const value = parseInt(words[2], 10);
            const b = bucketOf(key);
            let text2 = "";
            let at = -1;
            if (name === "put") {
              const existing = buckets[b].find((e) => e.key === key);
              if (existing) {
                existing.value = value;
                at = buckets[b].indexOf(existing);
                text2 = `Key ${key} already in bucket ${b}, value replaced by ${value}.`;
              } else {
                buckets[b].push({ key, value });
                at = buckets[b].length - 1;
                text2 = `Key ${key} hashed to bucket ${b} and joined its chain.`;
              }
            } else if (name === "get") {
              at = buckets[b].findIndex((e) => e.key === key);
              const found = at >= 0 ? buckets[b][at] : null;
              text2 = found ? `Bucket ${b} contains ${key}:${found.value}.` : `Bucket ${b} does not contain ${key} → −1.`;
            } else if (name === "remove") {
              at = buckets[b].findIndex((e) => e.key === key);
              if (at >= 0) {
                buckets[b].splice(at, 1);
                text2 = `Key ${key} was removed from bucket ${b}.`;
              } else {
                text2 = `Key ${key} was not present in bucket ${b}.`;
              }
            }
            steps.push({
              title: `${op} → ${text2}`,
              kind: "grid", rows: 5, cols: 4,
              cells: render({ row: b, col: Math.max(0, at), state: name === "remove" ? "bad" : "active" }),
              rowHeads: [0, 1, 2, 3, 4],
              counters: [count("entries", buckets.flat().length), count("bucket", b)],
              legend: LEG,
              happened: text2,
              why: "Only one bucket chain is touched per operation.",
              codeLine: name === "put" ? 12 : name === "get" ? 18 : 21,
            });
          }
          steps.push({
            title: "Final table",
            kind: "grid", rows: 5, cols: 4,
            cells: render(),
            rowHeads: [0, 1, 2, 3, 4],
            counters: [count("entries", buckets.flat().length), count("buckets", 5)],
            legend: LEG,
            happened: `The table holds ${buckets.flat().length} entries after ${list.length} operations.`,
            why: "Average cost stays constant while the chains stay short.",
            codeLine: 23,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "design-hashset",
    title: "Design Hashset",
    category: "Design & Hashing",
    difficulty: "Beginner",
    description:
      "Implement add, contains and remove with a fixed set of buckets that store keys only.",
    input: {
      label: "add key ; contains key ; remove key",
      default: "add 1 ; add 2 ; contains 1 ; contains 3 ; remove 2 ; contains 2",
      parse: "string",
    },
    approaches: [
      {
        name: "Boolean Buckets With Chaining",
        complexity: "O(1) average per operation",
        idea: [
          "A set needs only presence, so each bucket keeps a list of keys rather than key-value pairs.",
          "add ignores duplicates, contains scans one chain, and remove splices the key out of its chain.",
        ],
        problem: [
          "With a fixed bucket count, many keys inevitably share a chain, so the count must be chosen for the expected load.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

#define BUCKETS 5
typedef struct Node { int key; struct Node *next; } Node;
Node *table[BUCKETS];

int contains(int key) {
    for (Node *n = table[key % BUCKETS]; n; n = n->next)
        if (n->key == key) return 1;
    return 0;
}

void add(int key) {
    if (contains(key)) return;
    Node *n = malloc(sizeof(Node));
    n->key = key;
    n->next = table[key % BUCKETS];
    table[key % BUCKETS] = n;
}

int main(void) {
    add(1); add(2);
    printf("%d %d\\n", contains(1), contains(3)); /* 1 0 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <list>
using namespace std;

class MyHashSet {
    static const int BUCKETS = 5;
    vector<list<int>> table;
public:
    MyHashSet() : table(BUCKETS) {}

    void add(int key) {
        auto& bucket = table[key % BUCKETS];
        for (int k : bucket) if (k == key) return;
        bucket.push_back(key);
    }

    bool contains(int key) {
        for (int k : table[key % BUCKETS]) if (k == key) return true;
        return false;
    }

    void remove(int key) {
        table[key % BUCKETS].remove(key);
    }
};

int main() {
    MyHashSet s;
    s.add(1); s.add(2);
    cout << s.contains(1) << ' ' << s.contains(3) << '\\n'; // 1 0
}`,
        },
        steps(text) {
          const list = ops(text);
          const buckets = Array.from({ length: 5 }, () => []);
          const steps = [];
          const bucketOf = (key) => Math.abs(key) % 5;
          const render = (mark) =>
            grid(5, 4, (r, c) => {
              const v = buckets[r][c];
              return { v: v == null ? "·" : v, state: mark && mark.row === r && mark.col === c ? mark.state : v == null ? "dim" : "idle" };
            });
          steps.push({
            title: "Empty set with five buckets",
            kind: "grid", rows: 5, cols: 4,
            cells: render(),
            rowHeads: [0, 1, 2, 3, 4],
            counters: [count("keys", 0), count("buckets", 5)],
            legend: LEG,
            happened: "Each key belongs to bucket key mod 5.",
            why: "Presence checks only need to look inside one bucket.",
            codeLine: 4,
          });
          for (const op of list) {
            const words = op.split(/\s+/);
            const name = words[0].toLowerCase();
            const key = parseInt(words[1], 10) || 0;
            const b = bucketOf(key);
            const idx = buckets[b].indexOf(key);
            let happened = "";
            if (name === "add") {
              if (idx >= 0) happened = `Key ${key} is already present, so add changes nothing.`;
              else { buckets[b].push(key); happened = `Key ${key} joined bucket ${b}.`; }
            } else if (name === "contains") {
              happened = idx >= 0 ? `Key ${key} is in bucket ${b}, so contains is true.` : `Key ${key} is not in bucket ${b}, so contains is false.`;
            } else if (name === "remove") {
              if (idx >= 0) { buckets[b].splice(idx, 1); happened = `Key ${key} left bucket ${b}.`; }
              else happened = `Key ${key} was not present.`;
            }
            steps.push({
              title: `${op} → ${happened}`,
              kind: "grid", rows: 5, cols: 4,
              cells: render({ row: b, col: Math.max(0, idx), state: name === "remove" ? "bad" : name === "contains" && idx >= 0 ? "good" : "active" }),
              rowHeads: [0, 1, 2, 3, 4],
              counters: [count("keys", buckets.flat().length), count("bucket", b)],
              legend: LEG,
              happened,
              why: "The scan never leaves the chosen bucket.",
              codeLine: name === "add" ? 12 : name === "contains" ? 7 : 20,
            });
          }
          steps.push({
            title: "Final set",
            kind: "grid", rows: 5, cols: 4,
            cells: render(),
            rowHeads: [0, 1, 2, 3, 4],
            counters: [count("keys", buckets.flat().length), count("buckets", 5)],
            legend: LEG,
            happened: `The set holds ${buckets.flat().length} distinct keys.`,
            why: "Duplicate adds were rejected, so keys remain unique.",
            codeLine: 22,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "insert-delete-getrandom-o-1",
    title: "Insert Delete GetRandom O(1)",
    category: "Design & Hashing",
    difficulty: "Intermediate",
    description:
      "Support insert, remove and uniform random access in constant time with an array plus an index map.",
    input: {
      label: "insert value ; remove value ; random",
      default: "insert 1 ; insert 2 ; insert 3 ; random ; remove 2 ; random",
      parse: "string",
    },
    approaches: [
      {
        name: "Array With Index Map",
        complexity: "O(1) average per operation",
        idea: [
          "Keep values in a dense array so random access is just a uniform index.",
          "For removal, swap the target with the last array element, update its recorded index, then shrink. A hash map finds the target position instantly.",
        ],
        problem: [
          "The method relies on the array staying dense; leaving holes would break uniform random choice.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

int values[100], size = 0;

int index_of(int v) {
    for (int i = 0; i < size; i++) if (values[i] == v) return i;
    return -1;
}

int insert(int v) {
    if (index_of(v) >= 0) return 0;
    values[size++] = v;
    return 1;
}

int remove_value(int v) {
    int at = index_of(v);
    if (at < 0) return 0;
    values[at] = values[--size];       /* move the last value into the hole */
    return 1;
}

int get_random(void) { return values[rand() % size]; }

int main(void) {
    insert(1); insert(2); insert(3);
    remove_value(2);
    printf("%d %d\\n", size, values[0]); /* 2 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

class RandomizedSet {
    vector<int> values;
    unordered_map<int, int> index;
public:
    bool insert(int v) {
        if (index.count(v)) return false;
        index[v] = values.size();
        values.push_back(v);
        return true;
    }

    bool remove(int v) {
        if (!index.count(v)) return false;
        int at = index[v];
        int last = values.back();
        values[at] = last;
        index[last] = at;
        values.pop_back();
        index.erase(v);
        return true;
    }

    int getRandom() {
        return values[rand() % values.size()];
    }
};

int main() {
    RandomizedSet s;
    s.insert(1); s.insert(2); s.insert(3);
    s.remove(2);
    cout << s.getRandom() << '\\n';
}`,
        },
        steps(text) {
          const list = ops(text);
          const values = [];
          const index = new Map();
          const steps = [];
          steps.push({
            title: "Empty array and empty index map",
            tracks: [chips("array", ["—"], "dim"), chips("index", ["—"], "dim")],
            counters: [count("size", 0), count("map entries", 0)],
            legend: LEG,
            happened: "Random choice will pick uniformly from the array.",
            why: "The array must stay dense so every slot is equally likely.",
            codeLine: 3,
          });
          for (const op of list) {
            const [nameRaw, valRaw] = op.split(/\s+/);
            const name = nameRaw.toLowerCase();
            const v = parseInt(valRaw, 10);
            let happened = "";
            if (name === "insert") {
              if (index.has(v)) happened = `${v} already exists, insert returns false.`;
              else {
                index.set(v, values.length);
                values.push(v);
                happened = `${v} appended at index ${values.length - 1}.`;
              }
            } else if (name === "remove") {
              if (!index.has(v)) happened = `${v} is absent, remove returns false.`;
              else {
                const at = index.get(v);
                const last = values[values.length - 1];
                values[at] = last;
                index.set(last, at);
                values.pop();
                index.delete(v);
                happened = `${v} was at ${at}; the last value ${last} moved into that slot.`;
              }
            } else if (name === "random" || name === "getrandom") {
              happened = values.length ? `Any of the ${values.length} slots can be returned, all equally likely.` : "The set is empty, so random has nothing to return.";
            }
            steps.push({
              title: `${op} → ${happened}`,
              tracks: [
                chips("array", values.length ? values : ["—"], (i) => (values[i] === v ? "active" : "idle")),
                chips("index", index.size ? [...index.entries()].map(([k, i]) => `${k}@${i}`) : ["—"], (i) => ([...index.keys()][i] === v ? "read" : "dim")),
              ],
              counters: [count("size", values.length), count("map entries", index.size)],
              legend: LEG,
              happened,
              why: "Both the position lookup and the swap touch a constant number of slots.",
              codeLine: name === "insert" ? 10 : name === "remove" ? 16 : 22,
            });
          }
          steps.push({
            title: `Final set: ${values.length ? show(values) : "empty"}`,
            tracks: [chips("array", values.length ? values : ["—"], "result"), chips("index", index.size ? [...index.entries()].map(([k, i]) => `${k}@${i}`) : ["—"], "result")],
            counters: [count("size", values.length), count("answer", values.length)],
            legend: LEG,
            happened: `The array stays dense with ${values.length} value${values.length === 1 ? "" : "s"}.`,
            why: "Uniform random access works because there are no gaps.",
            codeLine: 24,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "lru-cache",
    title: "LRU Cache",
    category: "Design & Hashing",
    difficulty: "Advanced",
    description:
      "Evict the least recently used key when capacity is exceeded, keeping get and put in constant time.",
    input: {
      label: "capacity | get k ; put k v …",
      default: "2 | put 1 1 ; put 2 2 ; get 1 ; put 3 3 ; get 2 ; get 3",
      parse: "string",
    },
    approaches: [
      {
        name: "Hash Map Plus Recency List",
        complexity: "O(1) average per operation",
        idea: [
          "A hash map gives direct access to each entry, while a doubly linked list records recency from newest to oldest.",
          "get moves the entry to the front. put updates or inserts at the front, and evicts the tail when the size exceeds capacity.",
        ],
        problem: [
          "Both structures must be updated together; forgetting the map update after a list move leaves dangling entries.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CAP 2
typedef struct Entry { int key, value, used; } Entry;
Entry cache[64];
int size = 0, clock_value = 0;

int get(int key) {
    for (int i = 0; i < size; i++)
        if (cache[i].key == key) { cache[i].used = ++clock_value; return cache[i].value; }
    return -1;
}

void put(int key, int value) {
    for (int i = 0; i < size; i++)
        if (cache[i].key == key) { cache[i].value = value; cache[i].used = ++clock_value; return; }

    if (size == CAP) {                       /* evict least recently used */
        int victim = 0;
        for (int i = 1; i < size; i++) if (cache[i].used < cache[victim].used) victim = i;
        cache[victim] = cache[--size];
    }
    cache[size].key = key;
    cache[size].value = value;
    cache[size].used = ++clock_value;
    size++;
}

int main(void) {
    put(1, 1); put(2, 2);
    printf("%d\\n", get(1)); /* 1 */
    put(3, 3);
    printf("%d %d\\n", get(2), get(3)); /* -1 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <unordered_map>
#include <list>
using namespace std;

class LRUCache {
    int cap;
    list<pair<int,int>> order;                       // newest at the front
    unordered_map<int, list<pair<int,int>>::iterator> where;
public:
    explicit LRUCache(int capacity) : cap(capacity) {}

    int get(int key) {
        if (!where.count(key)) return -1;
        order.splice(order.begin(), order, where[key]);
        return where[key]->second;
    }

    void put(int key, int value) {
        if (where.count(key)) {
            where[key]->second = value;
            order.splice(order.begin(), order, where[key]);
            return;
        }
        if ((int)order.size() == cap) {
            where.erase(order.back().first);
            order.pop_back();
        }
        order.push_front({key, value});
        where[key] = order.begin();
    }
};

int main() {
    LRUCache c(2);
    c.put(1,1); c.put(2,2);
    cout << c.get(1) << '\\n';   // 1
    c.put(3,3);
    cout << c.get(2) << ' ' << c.get(3) << '\\n'; // -1 3
}`,
        },
        steps(text) {
          const [capRaw, opRaw] = parts(text);
          const cap = Math.max(1, parseInt(capRaw, 10) || 1);
          const list = ops(opRaw);
          const order = [];
          const map = new Map();
          const steps = [];
          steps.push({
            title: `Capacity ${cap}; newest entry at the front`,
            tracks: [chips("recency (new → old)", ["—"], "dim"), chips("map", ["—"], "dim")],
            counters: [count("size", 0, cap), count("capacity", cap)],
            legend: LEG,
            happened: "The list tail is always the least recently used entry.",
            why: "Eviction needs the oldest entry, and the list keeps it at one end.",
            codeLine: 5,
          });
          for (const op of list) {
            const words = op.split(/\s+/);
            const name = words[0].toLowerCase();
            const key = parseInt(words[1], 10) || 0;
            const value = parseInt(words[2], 10) || 0;
            let happened = "";
            let evicted = null;
            if (name === "get") {
              const at = order.findIndex((e) => e.key === key);
              if (at < 0) happened = `Key ${key} is missing → −1.`;
              else {
                const [entry] = order.splice(at, 1);
                order.unshift(entry);
                happened = `Key ${key} returned ${entry.value} and moved to the front.`;
              }
            } else if (name === "put") {
              const at = order.findIndex((e) => e.key === key);
              if (at >= 0) {
                order[at].value = value;
                const [entry] = order.splice(at, 1);
                order.unshift(entry);
                happened = `Key ${key} updated to ${value} and moved to the front.`;
              } else {
                if (order.length === cap) {
                  evicted = order.pop();
                  map.delete(evicted.key);
                }
                order.unshift({ key, value });
                map.set(key, value);
                happened = evicted
                  ? `Key ${key} inserted; ${evicted.key} was the least recently used and was evicted.`
                  : `Key ${key} inserted at the front.`;
              }
            }
            steps.push({
              title: `${op} → ${happened}`,
              tracks: [
                chips("recency (new → old)", order.length ? order.map((e) => `${e.key}:${e.value}`) : ["—"], (i) => (order[i] && order[i].key === key ? "active" : i === 0 ? "read" : "idle")),
                chips("map", map.size ? [...map.entries()].map(([k, v]) => `${k}:${v}`) : ["—"], "dim"),
                chips("evicted", evicted ? [`${evicted.key}:${evicted.value}`] : ["—"], evicted ? "bad" : "dim"),
              ],
              counters: [count("size", order.length, cap), count("capacity", cap)],
              legend: LEG,
              happened,
              why: "Every get and put touches only the front and, when full, the tail.",
              codeLine: name === "get" ? 9 : evicted ? 21 : 17,
            });
          }
          steps.push({
            title: `Final cache: ${order.length ? show(order.map((e) => `${e.key}:${e.value}`)) : "empty"}`,
            tracks: [chips("recency (new → old)", order.length ? order.map((e) => `${e.key}:${e.value}`) : ["—"], "result")],
            counters: [count("size", order.length, cap), count("answer", order.length)],
            legend: LEG,
            happened: `${order.length} of ${cap} slots are occupied.`,
            why: "The ordering encodes exactly which key would be evicted next.",
            codeLine: 24,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "lfu-cache",
    title: "LFU Cache",
    category: "Design & Hashing",
    difficulty: "Advanced",
    description:
      "Evict the least frequently used key, breaking ties by least recent use.",
    input: {
      label: "capacity | get k ; put k v …",
      default: "2 | put 1 1 ; put 2 2 ; get 1 ; put 3 3 ; get 2 ; get 1",
      parse: "string",
    },
    approaches: [
      {
        name: "Frequency Buckets With Recency",
        complexity: "O(1) average per operation",
        idea: [
          "Each entry stores its use count. A frequency table groups keys with the same count, ordered from most to least recent inside the group.",
          "Eviction takes a key from the smallest non-empty frequency group. Getting or updating a key promotes it to the next frequency.",
        ],
        problem: [
          "Tie-breaking needs recency, so plain frequency counters are not enough; each group must preserve insertion order.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Entry { int key, value, freq, stamp; int used; } Entry;
Entry cache[64];
int size = 0, clock_value = 0, cap = 2;

int get(int key) {
    for (int i = 0; i < size; i++)
        if (cache[i].used && cache[i].key == key) {
            cache[i].freq++;
            cache[i].stamp = ++clock_value;
            return cache[i].value;
        }
    return -1;
}

void put(int key, int value) {
    for (int i = 0; i < size; i++)
        if (cache[i].used && cache[i].key == key) {
            cache[i].value = value;
            cache[i].freq++;
            cache[i].stamp = ++clock_value;
            return;
        }

    if (size == cap) {                       /* evict lowest freq, then oldest */
        int victim = 0;
        for (int i = 1; i < size; i++) {
            if (cache[i].freq < cache[victim].freq) victim = i;
            else if (cache[i].freq == cache[victim].freq && cache[i].stamp < cache[victim].stamp) victim = i;
        }
        cache[victim] = cache[--size];
    }
    cache[size].key = key;
    cache[size].value = value;
    cache[size].freq = 1;
    cache[size].stamp = ++clock_value;
    cache[size].used = 1;
    size++;
}

int main(void) {
    put(1, 1); put(2, 2);
    printf("%d\\n", get(1));  /* 1 */
    put(3, 3);
    printf("%d %d\\n", get(2), get(1)); /* -1 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <unordered_map>
#include <list>
using namespace std;

class LFUCache {
    int cap;
    unordered_map<int, pair<int,int>> entry;   // key -> {value, freq}
    unordered_map<int, list<int>> groups;      // freq -> keys, front is most recent
    int minFreq = 0;

    void touch(int key) {
        int f = entry[key].second;
        groups[f].remove(key);
        if (groups[f].empty() && minFreq == f) minFreq++;
        entry[key].second = f + 1;
        groups[f + 1].push_front(key);
    }

public:
    explicit LFUCache(int capacity) : cap(capacity) {}

    int get(int key) {
        if (!entry.count(key)) return -1;
        touch(key);
        return entry[key].first;
    }

    void put(int key, int value) {
        if (cap == 0) return;
        if (entry.count(key)) {
            entry[key].first = value;
            touch(key);
            return;
        }
        if ((int)entry.size() == cap) {
            int victim = groups[minFreq].back();
            groups[minFreq].pop_back();
            entry.erase(victim);
        }
        entry[key] = {value, 1};
        groups[1].push_front(key);
        minFreq = 1;
    }
};

int main() {
    LFUCache c(2);
    c.put(1,1); c.put(2,2);
    cout << c.get(1) << '\\n';   // 1
    c.put(3,3);
    cout << c.get(2) << ' ' << c.get(1) << '\\n'; // -1 1
}`,
        },
        steps(text) {
          const [capRaw, opRaw] = parts(text);
          const cap = Math.max(1, parseInt(capRaw, 10) || 1);
          const list = ops(opRaw);
          const entries = new Map(); // key -> {value, freq, stamp}
          let clock = 0;
          const steps = [];
          steps.push({
            title: `Capacity ${cap}; eviction prefers the lowest frequency`,
            tracks: [chips("entries", ["—"], "dim"), chips("frequency groups", ["—"], "dim")],
            counters: [count("size", 0, cap), count("min frequency", "—")],
            legend: LEG,
            happened: "Ties in frequency are broken by least recent use.",
            why: "A key used often should survive longer than one used once.",
            codeLine: 4,
          });
          for (const op of list) {
            const words = op.split(/\s+/);
            const name = words[0].toLowerCase();
            const key = parseInt(words[1], 10) || 0;
            const value = parseInt(words[2], 10) || 0;
            let happened = "";
            let evicted = null;
            if (name === "get") {
              const e = entries.get(key);
              if (!e) happened = `Key ${key} is missing → −1.`;
              else {
                e.freq++;
                e.stamp = ++clock;
                happened = `Key ${key} returned ${e.value}; frequency is now ${e.freq}.`;
              }
            } else if (name === "put") {
              const e = entries.get(key);
              if (e) {
                e.value = value;
                e.freq++;
                e.stamp = ++clock;
                happened = `Key ${key} updated to ${value}; frequency is now ${e.freq}.`;
              } else {
                if (entries.size === cap) {
                  let victim = null;
                  for (const [k, cand] of entries) {
                    if (!victim) { victim = [k, cand]; continue; }
                    if (cand.freq < victim[1].freq || (cand.freq === victim[1].freq && cand.stamp < victim[1].stamp)) victim = [k, cand];
                  }
                  evicted = { key: victim[0], ...victim[1] };
                  entries.delete(victim[0]);
                }
                entries.set(key, { value, freq: 1, stamp: ++clock });
                happened = evicted
                  ? `Key ${key} inserted; ${evicted.key} had frequency ${evicted.freq} and was evicted.`
                  : `Key ${key} inserted with frequency 1.`;
              }
            }
            const sorted = [...entries.entries()].sort((a, b) => a[1].freq - b[1].freq || a[1].stamp - b[1].stamp);
            const minFreq = sorted.length ? sorted[0][1].freq : "—";
            const groups = new Map();
            for (const [k, e] of entries) {
              if (!groups.has(e.freq)) groups.set(e.freq, []);
              groups.get(e.freq).push(k);
            }
            steps.push({
              title: `${op} → ${happened}`,
              tracks: [
                chips("entries", sorted.length ? sorted.map(([k, e]) => `${k}:${e.value} f${e.freq}`) : ["—"], (i) => (sorted[i] && sorted[i][0] === key ? "active" : "idle")),
                chips("frequency groups", groups.size ? [...groups.entries()].map(([f, keys]) => `f${f}:${keys.join(",")}`) : ["—"], "dim"),
                chips("evicted", evicted ? [`${evicted.key} f${evicted.freq}`] : ["—"], evicted ? "bad" : "dim"),
              ],
              counters: [count("size", entries.size, cap), count("min frequency", minFreq)],
              legend: LEG,
              happened,
              why: "The victim is the smallest frequency, and recency breaks the tie.",
              codeLine: name === "get" ? 8 : evicted ? 22 : 16,
            });
          }
          const sorted = [...entries.entries()].sort((a, b) => a[1].freq - b[1].freq);
          steps.push({
            title: `Final cache: ${sorted.length ? show(sorted.map(([k, e]) => `${k}:${e.value}`)) : "empty"}`,
            tracks: [chips("entries", sorted.length ? sorted.map(([k, e]) => `${k}:${e.value} f${e.freq}`) : ["—"], "result")],
            counters: [count("size", entries.size, cap), count("answer", entries.size)],
            legend: LEG,
            happened: `The next eviction would remove ${sorted.length ? sorted[0][0] : "nothing"}.`,
            why: "Ordering by frequency exposes the weakest entry immediately.",
            codeLine: 26,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "logger-rate-limiter",
    title: "Logger Rate Limiter",
    category: "Design & Hashing",
    difficulty: "Beginner",
    description:
      "Print a message at most once every ten seconds, remembering the last printed time per message.",
    input: { label: "message:timestamp entries", default: "foo:1, bar:2, foo:3, foo:12, bar:13", parse: "string" },
    approaches: [
      {
        name: "Last Printed Time per Message",
        complexity: "O(1) average per call",
        idea: [
          "A hash map stores the last timestamp at which each message was actually printed.",
          "A new message prints immediately. A repeated message prints only when its timestamp is at least ten seconds after the stored one.",
        ],
        problem: [
          "Timestamps are assumed non-decreasing; out-of-order input would need extra care or a different policy.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

typedef struct { char message[32]; int last; } Record;
Record records[64];
int count_records = 0;

int should_print(const char *message, int timestamp) {
    for (int i = 0; i < count_records; i++)
        if (strcmp(records[i].message, message) == 0) {
            if (timestamp - records[i].last < 10) return 0;
            records[i].last = timestamp;
            return 1;
        }
    strcpy(records[count_records].message, message);
    records[count_records].last = timestamp;
    count_records++;
    return 1;
}

int main(void) {
    const char *msgs[] = {"foo","bar","foo","foo","bar"};
    int times[] = {1, 2, 3, 12, 13};
    for (int i = 0; i < 5; i++) printf("%d ", should_print(msgs[i], times[i]));
    printf("\\n"); /* 1 1 0 1 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <unordered_map>
using namespace std;

class Logger {
    unordered_map<string, int> last;
public:
    bool shouldPrintMessage(int timestamp, const string& message) {
        if (last.count(message) && timestamp - last[message] < 10) return false;
        last[message] = timestamp;
        return true;
    }
};

int main() {
    Logger log;
    cout << log.shouldPrintMessage(1, "foo") << ' ';
    cout << log.shouldPrintMessage(2, "bar") << ' ';
    cout << log.shouldPrintMessage(3, "foo") << ' ';
    cout << log.shouldPrintMessage(12, "foo") << '\\n'; // 1 1 0 1
}`,
        },
        steps(text) {
          const tokens = String(text || "").split(",").map((s) => s.trim()).filter(Boolean);
          const events = tokens.map((t) => {
            const [name, time] = t.split(":").map((x) => x.trim());
            return { name: name || "?", time: parseInt(time, 10) || 0 };
          });
          if (!events.length) {
            return [{
              title: "Give message:timestamp entries",
              tracks: [chips("log", ["—"], "idle")],
              counters: [count("printed", 0)],
              legend: ["idle", "result"],
              happened: "Messages are separated by commas.",
              why: "Each message needs its own last-printed time.",
            }];
          }
          const steps = [];
          const last = new Map();
          let printed = 0;
          steps.push({
            title: "Empty log; every message may print",
            tracks: [chips("last printed", ["—"], "dim"), chips("output", ["—"], "idle")],
            counters: [count("printed", 0), count("messages tracked", 0)],
            legend: LEG,
            happened: "The window is ten seconds.",
            why: "A missing entry means the message has never printed.",
            codeLine: 4,
          });
          for (const ev of events) {
            const prev = last.get(ev.name);
            const allowed = prev == null || ev.time - prev >= 10;
            if (allowed) {
              last.set(ev.name, ev.time);
              printed++;
            }
            steps.push({
              title: `${ev.name} at t=${ev.time} → ${allowed ? "print" : "suppress"}`,
              tracks: [
                chips("last printed", [...last.entries()].map(([m, t]) => `${m}@${t}`), (i) => ([...last.keys()][i] === ev.name ? (allowed ? "good" : "bad") : "dim")),
                chips("output", allowed ? ["printed"] : ["suppressed"], allowed ? "result" : "bad"),
              ],
              counters: [count("printed", printed, events.length), count("time", ev.time)],
              legend: LEG,
              happened: allowed
                ? prev == null
                  ? `First time for ${ev.name}, so it prints immediately.`
                  : `${ev.time} − ${prev} = ${ev.time - prev} ≥ 10, so the message prints again.`
                : `${ev.time} − ${prev} = ${ev.time - prev} < 10, so the repeat is suppressed.`,
              why: "Only the last printed time per message is needed to enforce the window.",
              codeLine: allowed ? 5 : 4,
            });
          }
          steps.push({
            title: `Answer: ${printed} of ${events.length} messages printed`,
            tracks: [chips("messages", [...last.keys()], "result"), chips("answer", [printed], "result")],
            counters: [count("printed", printed, events.length), count("messages tracked", last.size)],
            legend: LEG,
            happened: `${events.length - printed} message${events.length - printed === 1 ? " was" : "s were"} rate-limited.`,
            why: "The map keeps exactly one timestamp per distinct message.",
            codeLine: 8,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "first-unique-character",
    title: "First Unique Character",
    category: "Design & Hashing",
    difficulty: "Beginner",
    description:
      "Find the first character that occurs exactly once, with a counting pass and a lookup pass.",
    input: { label: "text", default: "loveleetcode", parse: "chars" },
    approaches: [
      {
        name: "Count Then Scan",
        complexity: "O(n) time, O(alphabet) space",
        idea: [
          "Count every character in one pass. Then scan from the left again and return the first character whose count is one.",
          "A fixed-size count table makes both passes linear and the memory independent of the text length.",
        ],
        problem: [
          "A hash map with per-character overhead costs more than a fixed alphabet array when the alphabet is small.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

int first_unique(const char *s) {
    int freq[256] = {0};
    int n = strlen(s);

    for (int i = 0; i < n; i++) freq[(unsigned char)s[i]]++;
    for (int i = 0; i < n; i++)
        if (freq[(unsigned char)s[i]] == 1) return i;
    return -1;
}

int main(void) {
    printf("%d\\n", first_unique("loveleetcode")); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
using namespace std;

int firstUniqChar(const string& s) {
    vector<int> freq(256, 0);
    for (char c : s) freq[(unsigned char)c]++;
    for (int i = 0; i < (int)s.size(); i++)
        if (freq[(unsigned char)s[i]] == 1) return i;
    return -1;
}

int main() {
    cout << firstUniqChar("loveleetcode") << '\\n'; // 2
}`,
        },
        steps(text) {
          const s = Array.from(String(text || ""));
          if (!s.length) {
            return [{
              title: "Give some text",
              tracks: [chips("text", ["—"], "idle")],
              counters: [count("characters", 0)],
              legend: ["idle", "result"],
              happened: "There is nothing to inspect.",
              why: "Uniqueness needs at least one character.",
            }];
          }
          const steps = [];
          const freq = new Map();
          for (const c of s) freq.set(c, (freq.get(c) || 0) + 1);
          steps.push({
            title: `Count all ${s.length} characters`,
            tracks: [track("text", s, fill(s.length, "idle")), chips("counts", [...freq.entries()].map(([c, n]) => `${c}×${n}`), "dim")],
            counters: [count("characters", s.length), count("distinct", freq.size)],
            legend: LEG,
            happened: `There are ${freq.size} distinct characters.`,
            why: "After counting, uniqueness is a single lookup per character.",
            codeLine: 3,
          });
          for (let i = 0; i < s.length; i++) {
            const n = freq.get(s[i]);
            const unique = n === 1;
            if (unique) {
              steps.push({
                title: `Position ${i} ('${s[i]}') appears once → answer`,
                tracks: [
                  track("text", s, s.map((_, j) => (j === i ? "result" : j < i ? "dim" : "idle"))),
                  chips("count", [`${s[i]}×${n}`], "result"),
                ],
                counters: [count("position", i, s.length), count("answer", i)],
                legend: LEG,
                happened: `No earlier character had a count of one.`,
                why: "Scanning left to right makes the first hit the leftmost unique character.",
                codeLine: 4,
              });
              steps.push({
                title: `Answer: index ${i}`,
                tracks: [track("text", s, s.map((_, j) => (j === i ? "result" : "dim"))), chips("answer", [i], "result")],
                counters: [count("characters", s.length), count("answer", i)],
                legend: LEG,
                happened: `'${s[i]}' is the first character with frequency one.`,
                why: "The count table turned an n² pair search into two linear passes.",
                codeLine: 4,
              });
              return steps;
            }
            steps.push({
              title: `Position ${i} ('${s[i]}') appears ${n} time${n === 1 ? "" : "s"} → skip`,
              tracks: [
                track("text", s, s.map((_, j) => (j === i ? "read" : j < i ? "dim" : "idle"))),
                chips("count", [`${s[i]}×${n}`], "bad"),
              ],
              counters: [count("position", i, s.length), count("checked", i + 1, s.length)],
              legend: LEG,
              happened: n === 0 ? "This character was never counted." : `The count is ${n}, so this position is not unique.`,
              why: "Only a count of exactly one qualifies.",
              codeLine: 4,
            });
          }
          steps.push({
            title: "Answer: −1, every character repeats",
            tracks: [track("text", s, fill(s.length, "bad")), chips("answer", [-1], "result")],
            counters: [count("characters", s.length), count("answer", -1)],
            legend: LEG,
            happened: "No character occurred exactly once.",
            why: "The scan finished without finding a count of one.",
            codeLine: 5,
          });
          return steps;
        },
      },
    ],
  });
})();
