/* ============================================================
   DSA Visuals — Complexity Lab
   Counting work instead of guessing: comparisons, calls, copy
   operations and the shape of growth. Each visual reports a
   measured count for the input, not a hand-wavy table.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const range = (n) => Array.from({ length: n }, (_, i) => i);

  /* ---------------------------------------------------------- */
  V.register({
    id: "analyze-binary-search",
    title: "Analyze Binary Search",
    category: "Complexity Lab",
    difficulty: "Intermediate",
    description:
      "Measure exactly how many comparisons binary search needs, and watch the search window halve.",
    input: {
      label: "row 1 = sorted numbers, row 2 = target",
      default: "1, 3, 5, 7, 9, 11, 13, 15, 17, 19 | 13",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Count the Halvings",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "Each comparison throws away half of the remaining window. After k comparisons the window can hold at most n / 2^k values.",
          "So the number of comparisons is about log₂(n), which grows very slowly: a thousand values need only ten comparisons.",
        ],
        problem: [
          "The count assumes the data is already sorted; sorting first would dominate the search cost entirely.",
        ],
        code: {
          c: `#include <stdio.h>

/* returns index, or -1; *cmp counts comparisons */
int binary_search(const int *a, int n, int target, int *cmp) {
    int lo = 0, hi = n - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        (*cmp)++;
        if (a[mid] == target) return mid;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}

int main(void) {
    int a[] = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19};
    int comparisons = 0;
    int at = binary_search(a, 10, 13, &comparisons);
    printf("index %d after %d comparisons\\n", at, comparisons);
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int binarySearch(const vector<int>& a, int target, int& comparisons) {
    int lo = 0, hi = (int)a.size() - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        comparisons++;
        if (a[mid] == target) return mid;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}

int main() {
    vector<int> a{1, 3, 5, 7, 9, 11, 13, 15, 17, 19};
    int comparisons = 0;
    int at = binarySearch(a, 13, comparisons);
    cout << "index " << at << " after " << comparisons << " comparisons\\n";
}`,
        },
        steps(rows) {
          const a = rows[0] || [];
          const target = (rows[1] || [])[0];
          if (!a.length) {
            return [{
              title: "Give a sorted row and a target",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("comparisons", 0)],
              legend: ["idle", "result"],
              happened: "The first row is the sorted data, the second row holds one target value.",
              why: "Binary search needs order; without it the halving rule points the wrong way.",
            }];
          }
          const sorted = a.slice().sort((x, y) => x - y);
          const steps = [];
          let lo = 0, hi = sorted.length - 1, cmp = 0;
          const bound = () => Math.ceil(Math.log2(Math.max(1, sorted.length)));
          steps.push({
            title: `${sorted.length} values, target ${target}`,
            tracks: [
              track("numbers", sorted, fill(sorted.length, "idle")),
              chips("window", [`lo ${lo}`, `hi ${hi}`], "read"),
            ],
            counters: [count("comparisons", 0), count("halvings needed ≈", bound())],
            legend: LEG,
            happened: `The search window is the whole row: indices 0 to ${hi}.`,
            why: "A sorted row lets one comparison decide which half cannot contain the target.",
            codeLine: 6,
          });
          let foundAt = -1;
          while (lo <= hi && sorted.length) {
            const mid = lo + Math.floor((hi - lo) / 2);
            cmp++;
            const v = sorted[mid];
            const hit = v === target;
            if (hit) foundAt = mid;
            steps.push({
              title: hit ? `Compare ${v} = target at ${mid} ✓` : `Compare ${v} at ${mid} → go ${v < target ? "right" : "left"}`,
              tracks: [
                track("numbers", sorted, sorted.map((x, i) => {
                  if (i === mid) return hit ? "good" : "read";
                  if (i < lo || i > hi) return "dim";
                  return "idle";
                })),
                chips("window", [`${lo}..${hi}`, `size ${hi - lo + 1}`], "done"),
                chips("comparisons", [cmp], "result"),
              ],
              counters: [count("comparisons", cmp), count("window size", Math.max(0, hi - lo + 1))],
              legend: LEG,
              happened: `Middle index ${mid} holds ${v}; the target ${target} is ${hit ? "exactly here" : v < target ? "greater, so drop the left half" : "smaller, so drop the right half"}.`,
              why: "Every comparison removes about half of the remaining candidates, which is the log n cost.",
              codeLine: 9,
            });
            if (hit) break;
            if (v < target) lo = mid + 1;
            else hi = mid - 1;
          }
          steps.push({
            title: `Answer: ${foundAt >= 0 ? `found at ${foundAt}` : "not present"} after ${cmp} comparison${cmp === 1 ? "" : "s"}`,
            tracks: [
              track("numbers", sorted, sorted.map((x, i) => (i === foundAt ? "good" : "dim"))),
              chips("comparisons", [cmp], "result"),
              chips("answer", [foundAt >= 0 ? foundAt : "not found"], "result"),
            ],
            counters: [count("comparisons", cmp), count("log₂ bound", bound())],
            legend: LEG,
            happened: foundAt >= 0
              ? `The target sits at index ${foundAt}.`
              : `The window emptied without meeting ${target}.`,
            why: `The measured count ${cmp} stays at or below the log₂ bound ${bound()}, which is why doubling the row costs only one extra comparison.`,
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "analyze-recursive-factorial",
    title: "Analyze Recursive Factorial",
    category: "Complexity Lab",
    difficulty: "Beginner",
    description:
      "Watch the call stack grow to n and unwind again, and see why factorial costs linear time and stack depth.",
    input: { label: "n", default: "5", parse: "int" },
    approaches: [
      {
        name: "One Call Per Level",
        complexity: "O(n) time, O(n) stack space",
        idea: [
          "factorial(n) calls factorial(n − 1) once, so the calls form a single chain rather than a tree.",
          "Each level waits for the one below it, so the stack reaches depth n and every level does one multiplication on the way back.",
        ],
        problem: [
          "The result grows far beyond a machine integer very quickly, so the algorithm is limited by the data type long before it is limited by time.",
        ],
        code: {
          c: `#include <stdio.h>

unsigned long long factorial(int n) {
    if (n <= 1) return 1;             /* base case */
    return (unsigned long long)n * factorial(n - 1);
}

int main(void) {
    int n = 5;
    printf("%d! = %llu\\n", n, factorial(n)); /* 120 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

unsigned long long factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

int main() {
    cout << factorial(5) << '\\n'; // 120
}`,
        },
        steps(n) {
          const k = Math.max(0, Math.min(12, n | 0));
          const stack = range(k + 1).map((i) => k - i);
          const steps = [];
          steps.push({
            title: `factorial(${k}) needs ${k > 0 ? k : 0} nested calls`,
            tracks: [
              chips("call stack", [], "idle"),
              chips("n", [k], "read"),
            ],
            counters: [count("calls", 0), count("stack depth", 0)],
            legend: LEG,
            happened: `The first call is factorial(${k}); it cannot finish until the call below it returns 1.`,
            why: "A recursive call pauses its own frame, so unfinished calls pile up on the stack.",
            codeLine: 3,
          });
          for (let i = k; i >= 1; i--) {
            const depth = k - i + 1;
            steps.push({
              title: `factorial(${i}) calls factorial(${i - 1})`,
              tracks: [
                chips("call stack (top first)", stack.filter((v) => v >= i), (j) => (j === depth - 1 ? "read" : "done")),
                chips("waiting products", range(depth).map((j) => `${k - j}`), "dim"),
              ],
              counters: [count("calls", depth), count("stack depth", depth)],
              legend: LEG,
              happened: `factorial(${i}) hands off to factorial(${i - 1}) and waits.`,
              why: "One call per level means the number of calls equals n, not 2^n.",
              codeLine: 4,
            });
          }
          steps.push({
            title: "Base case: factorial(1) returns 1",
            tracks: [
              chips("call stack (top first)", stack.filter((v) => v >= 1), (j) => (j === stack.filter((v) => v >= 1).length - 1 ? "good" : "done")),
              chips("returned", [1], "result"),
            ],
            counters: [count("calls", k + 1), count("stack depth", k + 1)],
            legend: LEG,
            happened: "The smallest call answers immediately, so the stack can start unwinding.",
            why: "Every recursion needs a base case; without it the chain would never stop.",
            codeLine: 3,
          });
          let acc = 1;
          for (let i = 2; i <= k; i++) {
            acc *= i;
            steps.push({
              title: `${i} × ${acc / i} = ${acc}`,
              tracks: [
                chips("call stack (top first)", stack.filter((v) => v >= i), (j) => (j === 0 ? "read" : "done")),
                chips("product", [acc], "result"),
              ],
              counters: [count("calls", k + 1), count("multiplications", i - 1, Math.max(0, k - 1))],
              legend: LEG,
              happened: `factorial(${i}) multiplies ${i} by the returned ${acc / i}.`,
              why: "The unwind does one multiplication per frame, so total work is linear.",
              codeLine: 4,
            });
          }
          steps.push({
            title: `Answer: ${k}! = ${acc}`,
            tracks: [
              chips("call stack", ["empty"], "dim"),
              chips("answer", [acc], "result"),
            ],
            counters: [count("calls", k + 1), count("multiplications", Math.max(0, k - 1))],
            legend: LEG,
            happened: `All ${k + 1} calls returned and the stack is empty again.`,
            why: "Linear calls plus linear stack is the honest cost: O(n) time and O(n) space.",
            codeLine: 7,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "analyze-fibonacci-recursion",
    title: "Analyze Fibonacci Recursion",
    category: "Complexity Lab",
    difficulty: "Intermediate",
    description:
      "Count how often the naive recursion recomputes the same Fibonacci value, then fix it with a memo table.",
    input: { label: "n", default: "7", parse: "int" },
    approaches: [
      {
        name: "Naive Recursion",
        complexity: "O(φⁿ) time, O(n) stack space",
        idea: [
          "fib(n) calls fib(n − 1) and fib(n − 2). Those two calls share almost all of their own subcalls, so the same values are computed again and again.",
          "Counting calls shows the explosion directly: fib(7) already makes far more calls than the seven distinct values it needs.",
        ],
        problem: [
          "The repeated work grows exponentially while the number of distinct answers stays linear, which is the worst possible trade.",
        ],
        code: {
          c: `#include <stdio.h>

long calls = 0;

long fib(int n) {
    calls++;
    if (n < 2) return n;
    return fib(n - 1) + fib(n - 2);
}

int main(void) {
    printf("fib(7) = %ld\\n", fib(7));
    printf("calls  = %ld\\n", calls);  /* 41 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

long long calls = 0;

long long fib(int n) {
    calls++;
    if (n < 2) return n;
    return fib(n - 1) + fib(n - 2);
}

int main() {
    cout << fib(7) << '\\n';
    cout << calls << '\\n'; // 41
}`,
        },
        steps(n) {
          const k = Math.max(0, Math.min(18, n | 0));
          const memo = new Map();
          const seen = new Map();
          let calls = 0;
          const fib = (x) => {
            calls++;
            seen.set(x, (seen.get(x) || 0) + 1);
            if (x < 2) return x;
            return fib(x - 1) + fib(x - 2);
          };
          const steps = [];
          steps.push({
            title: `fib(${k}) with no memory`,
            tracks: [
              chips("value", [k], "read"),
              chips("distinct answers needed", range(k + 1), "dim"),
            ],
            counters: [count("calls", 0), count("distinct values", k + 1)],
            legend: LEG,
            happened: `Only ${k + 1} different values exist below ${k}, but the recursion does not know that yet.`,
            why: "Without storage, every branch has to rediscover the same small answers.",
            codeLine: 4,
          });
          const total = fib(k);
          const rows = [...seen.entries()].sort((a, b) => a[0] - b[0]);
          // build a compact replay of the call counts
          let running = 0;
          rows.forEach(([v, c]) => {
            running += c;
            steps.push({
              title: `fib(${v}) was called ${c} time${c === 1 ? "" : "s"}`,
              tracks: [
                chips("arguments", rows.map(([x]) => `fib(${x})`), (i) => (rows[i][0] === v ? "read" : "dim")),
                chips("call counts", rows.map(([x, y]) => `${x}:${y}`), (i) => (rows[i][0] === v ? "result" : "dim")),
              ],
              counters: [count("calls so far", running, calls), count("distinct values", rows.length)],
              legend: LEG,
              happened: `fib(${v}) appears ${c} time${c === 1 ? "" : "s"} in the call tree even though its answer never changes.`,
              why: "Repeated arguments are exactly the wasted work a memo table removes.",
              codeLine: 5,
            });
          });
          steps.push({
            title: `fib(${k}) = ${total} after ${calls} calls`,
            tracks: [
              chips("answers", range(k + 1).map((i) => `fib(${i})=${fibValue(i)}`), "done"),
              chips("total calls", [calls], "result"),
              chips("answer", [total], "result"),
            ],
            counters: [count("calls", calls), count("distinct values", k + 1)],
            legend: LEG,
            happened: `${calls} calls produced only ${k + 1} distinct answers.`,
            why: "The ratio between calls and answers is the exponential waste the memo version fixes.",
            codeLine: 6,
          });
          return steps;
        },
      },
      {
        name: "Memoised Recursion",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Store each result the first time it is computed. A later call with the same argument returns the stored value instead of recursing.",
          "Now every value is computed once, so the call count drops from exponential to linear.",
        ],
        problem: [
          "The table costs memory proportional to n, and the first call still needs stack depth n.",
        ],
        code: {
          c: `#include <stdio.h>

static long memo[64];
static int have[64];

long fib(int n) {
    if (n < 2) return n;
    if (have[n]) return memo[n];
    have[n] = 1;
    memo[n] = fib(n - 1) + fib(n - 2);
    return memo[n];
}

int main(void) {
    printf("fib(7) = %ld\\n", fib(7)); /* 13 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

long long fib(int n, vector<long long>& memo) {
    if (n < 2) return n;
    if (memo[n] != -1) return memo[n];
    return memo[n] = fib(n - 1, memo) + fib(n - 2, memo);
}

int main() {
    vector<long long> memo(64, -1);
    cout << fib(7, memo) << '\\n'; // 13
}`,
        },
        steps(n) {
          const k = Math.max(0, Math.min(20, n | 0));
          const memo = new Map();
          let calls = 0, hits = 0;
          const fib = (x) => {
            calls++;
            if (x < 2) return x;
            if (memo.has(x)) { hits++; return memo.get(x); }
            const v = fib(x - 1) + fib(x - 2);
            memo.set(x, v);
            return v;
          };
          const steps = [];
          steps.push({
            title: `fib(${k}) with a table of n + 1 slots`,
            tracks: [
              chips("n", [k], "read"),
              chips("table", range(k + 1).map((i) => (i < 2 ? fibValue(i) : "?")), (i) => (i < 2 ? "done" : "idle")),
            ],
            counters: [count("calls", 0), count("table hits", 0)],
            legend: LEG,
            happened: "Slots 0 and 1 are already known; every other slot starts empty.",
            why: "A stored answer turns a whole subtree of calls into one lookup.",
            codeLine: 5,
          });
          const value = fib(k);
          steps.push({
            title: `All values 0..${k} filled`,
            tracks: [
              chips("table", range(k + 1).map((i) => fibValue(i)), (i) => (i === k ? "result" : "done")),
              chips("calls", [calls], "result"),
              chips("hits", [hits], "result"),
            ],
            counters: [count("calls", calls), count("table hits", hits)],
            legend: LEG,
            happened: `The table now holds every value up to ${k}, and the run needed ${calls} calls with ${hits} repeats answered from the table.`,
            why: "Linear calls for linear distinct values is the memoised cost.",
            codeLine: 8,
          });
          steps.push({
            title: `Answer: fib(${k}) = ${value}`,
            tracks: [
              chips("table", range(k + 1).map((i) => fibValue(i)), (i) => (i === k ? "good" : "done")),
              chips("answer", [value], "result"),
            ],
            counters: [count("calls", calls), count("answer", value)],
            legend: LEG,
            happened: `The last slot holds ${value}.`,
            why: "Compare the call count with the naive version to see the exponential term disappear.",
            codeLine: 8,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "analyze-merge-sort",
    title: "Analyze Merge Sort",
    category: "Complexity Lab",
    difficulty: "Intermediate",
    description:
      "Count the splits and merges in merge sort and see where the n log n work comes from.",
    input: { label: "The numbers", default: "8, 3, 5, 1, 9, 2, 7, 4", parse: "ints" },
    approaches: [
      {
        name: "Split, Then Merge",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Splitting in half takes about log₂(n) levels before every piece has one element.",
          "At each level every element is touched once while the pieces are merged, so the total is n touches per level and n log n overall.",
        ],
        problem: [
          "The merge step needs a temporary buffer of n elements, so the sorted result is not produced in place.",
        ],
        code: {
          c: `#include <stdio.h>

static long merges = 0;

void merge(int *a, int lo, int mid, int hi) {
    int tmp[64], i = lo, j = mid + 1, k = 0;
    while (i <= mid && j <= hi) {
        merges++;
        tmp[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    }
    while (i <= mid) tmp[k++] = a[i++];
    while (j <= hi) tmp[k++] = a[j++];
    for (int t = 0; t < k; t++) a[lo + t] = tmp[t];
}

void merge_sort(int *a, int lo, int hi) {
    if (lo >= hi) return;
    int mid = (lo + hi) / 2;
    merge_sort(a, lo, mid);
    merge_sort(a, mid + 1, hi);
    merge(a, lo, mid, hi);
}

int main(void) {
    int a[] = {8, 3, 5, 1, 9, 2, 7, 4};
    merge_sort(a, 0, 7);
    printf("%ld writes\\n", merges);
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

void mergeSort(vector<int>& a, int lo, int hi, long long& writes) {
    if (lo >= hi) return;
    int mid = (lo + hi) / 2;
    mergeSort(a, lo, mid, writes);
    mergeSort(a, mid + 1, hi, writes);

    vector<int> tmp;
    int i = lo, j = mid + 1;
    while (i <= mid && j <= hi) tmp.push_back(a[i] <= a[j] ? a[i++] : a[j++]);
    while (i <= mid) tmp.push_back(a[i++]);
    while (j <= hi) tmp.push_back(a[j++]);
    for (int t = 0; t < (int)tmp.size(); t++) { a[lo + t] = tmp[t]; writes++; }
}

int main() {
    vector<int> a{8, 3, 5, 1, 9, 2, 7, 4};
    long long writes = 0;
    mergeSort(a, 0, a.size() - 1, writes);
    cout << writes << " writes\\n";
}`,
        },
        steps(nums) {
          if (!nums.length) {
            return [{
              title: "Give at least one number",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("levels", 0)],
              legend: ["idle", "result"],
              happened: "There is nothing to split.",
              why: "Merge sort splits until single elements remain.",
            }];
          }
          const steps = [];
          const levels = Math.max(1, Math.ceil(Math.log2(nums.length)));
          steps.push({
            title: `${nums.length} values → about ${levels} split level${levels === 1 ? "" : "s"}`,
            tracks: [track("numbers", nums, fill(nums.length, "idle"))],
            counters: [count("levels", 0, levels), count("elements touched", 0)],
            legend: LEG,
            happened: `The row is ${nums.join(", ")}; halving it needs about log₂(${nums.length}) levels.`,
            why: "The number of levels is what turns n work per level into n log n.",
            codeLine: 12,
          });
          let level = 0;
          let width = 1;
          while (width < nums.length) {
            level++;
            const touches = nums.length;
            steps.push({
              title: `Level ${level}: ${nums.length} elements, pieces of ${width}`,
              tracks: [
                track("numbers", nums, nums.map((_, i) => (Math.floor(i / width) % 2 === 0 ? "done" : "active"))),
                chips("pieces", range(Math.ceil(nums.length / width)).map((p) => `[${p * width}..${Math.min(nums.length - 1, (p + 1) * width - 1)}]`), "dim"),
              ],
              counters: [count("levels", level, levels), count("elements touched", touches * level)],
              legend: LEG,
              happened: `After ${level} split${level === 1 ? "" : "s"} the pieces hold ${width} element${width === 1 ? "" : "s"} each, and merging them touches all ${nums.length}.`,
              why: "Every level touches each element once, so level work times level count is the total.",
              codeLine: 15,
            });
            width *= 2;
          }
          const sorted = nums.slice().sort((a, b) => a - b);
          steps.push({
            title: `Answer: ${sorted.join(", ")}`,
            tracks: [
              track("numbers", sorted, fill(sorted.length, "done")),
              chips("comparisons ≈", [nums.length * levels], "result"),
            ],
            counters: [count("levels", levels, levels), count("elements touched", nums.length * levels)],
            legend: LEG,
            happened: `The final merge produces ${sorted.join(", ")} after about ${nums.length} × ${levels} = ${nums.length * levels} element operations.`,
            why: "That product is the n log n signature: linear work repeated logarithmically many times.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "analyze-dynamic-array-growth",
    title: "Analyze Dynamic Array Growth",
    category: "Complexity Lab",
    difficulty: "Intermediate",
    description:
      "Watch a growable array double its capacity and count the copies — total work stays linear.",
    input: { label: "number of pushes", default: "12", parse: "int" },
    approaches: [
      {
        name: "Doubling Capacity",
        complexity: "O(1) amortised per push",
        idea: [
          "When the buffer is full it doubles and every old element is copied across. A single push can therefore be expensive.",
          "Doubling means copies happen at sizes 1, 2, 4, 8 …, whose total is just under 2n. Spread over n pushes, the average cost stays constant.",
        ],
        problem: [
          "The occasional copy pauses the program briefly, which matters for latency-sensitive code even though the average is fine.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { int *data; int size, cap; long copies; } Vec;

void push(Vec *v, int value) {
    if (v->size == v->cap) {
        int next = v->cap ? v->cap * 2 : 1;
        int *fresh = malloc(sizeof(int) * next);
        memcpy(fresh, v->data, sizeof(int) * v->size);
        v->copies += v->size;
        free(v->data);
        v->data = fresh;
        v->cap = next;
    }
    v->data[v->size++] = value;
}

int main(void) {
    Vec v = {0};
    for (int i = 0; i < 12; i++) push(&v, i);
    printf("size %d cap %d copies %ld\\n", v.size, v.cap, v.copies); /* 12 16 15 */
    free(v.data);
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int main() {
    vector<int> v;
    size_t cap = 0;
    long long copies = 0;
    for (int i = 0; i < 12; i++) {
        if (v.size() == v.capacity()) {
            cap = cap ? cap * 2 : 1;
            copies += v.size();
            v.reserve(cap);
        }
        v.push_back(i);
    }
    cout << "size " << v.size() << " cap " << v.capacity()
         << " copies " << copies << '\\n'; // 12 16 15
}`,
        },
        steps(n) {
          const pushes = Math.max(1, Math.min(40, n | 0));
          let cap = 0, size = 0, copies = 0;
          const steps = [];
          steps.push({
            title: `Push ${pushes} values into a growing buffer`,
            tracks: [chips("buffer", [], "idle")],
            counters: [count("pushes", 0, pushes), count("capacity", 0), count("copies", 0)],
            legend: LEG,
            happened: "The buffer starts empty with no capacity at all.",
            why: "The first push must allocate, so even that operation is not free.",
            codeLine: 7,
          });
          for (let i = 1; i <= pushes; i++) {
            const grew = size === cap;
            if (grew) {
              cap = cap ? cap * 2 : 1;
              copies += size;
            }
            size++;
            steps.push({
              title: grew ? `Push ${i} grows the buffer to ${cap} (${size} copied)` : `Push ${i} fits in capacity ${cap}`,
              tracks: [
                chips("buffer", range(cap).map((j) => (j < size ? j : "·")), (j) => (j === size - 1 ? "read" : j < size ? "done" : "idle")),
                chips("copies at this growth", grew ? [size] : [0], grew ? "bad" : "dim"),
              ],
              counters: [count("pushes", i, pushes), count("capacity", cap), count("copies", copies)],
              legend: LEG,
              happened: grew
                ? `The buffer was full, so it doubled to ${cap} slots and copied the ${size - 1} old values.`
                : `Slot ${i} was free, so the value went straight in.`,
              why: grew
                ? "A growth event is the expensive case; doubling keeps these events rare."
                : "Most pushes are cheap, which is what makes the average constant.",
              codeLine: grew ? 9 : 15,
            });
          }
          steps.push({
            title: `Answer: ${copies} copies for ${pushes} pushes (${(copies / pushes).toFixed(2)} per push)`,
            tracks: [
              chips("buffer", range(cap).map((j) => (j < size ? j : "·")), (j) => (j < size ? "done" : "dim")),
              chips("answer", [`${copies} copies`], "result"),
            ],
            counters: [count("pushes", pushes, pushes), count("capacity", cap), count("copies", copies)],
            legend: LEG,
            happened: `The total copy work is ${copies}, which is less than 2 × ${pushes}.`,
            why: "The geometric series 1 + 2 + 4 + … is bounded by twice the largest term, so the amortised cost is constant.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "compare-competing-solutions",
    title: "Compare Competing Solutions",
    category: "Complexity Lab",
    difficulty: "Beginner",
    description:
      "Put linear, n log n and quadratic work side by side and see how soon the difference matters.",
    input: { label: "input size n", default: "16", parse: "int" },
    approaches: [
      {
        name: "Measure All Three",
        complexity: "O(n) · O(n log n) · O(n²)",
        idea: [
          "The same problem can often be solved with a scan, a sort or a double loop. On small inputs they all feel instant, which hides the difference.",
          "Counting operations for one n makes the gap visible, and doubling n shows which term is winning.",
        ],
        problem: [
          "Operation counts ignore constant factors, so a very fast quadratic loop can still beat a clumsy linear one for small n.",
        ],
        code: {
          c: `#include <stdio.h>
#include <math.h>

int main(void) {
    int n = 16;
    long linear = n;
    long nlogn = (long)(n * log2(n));
    long quad = (long)n * n;

    printf("n      = %d\\n", n);
    printf("O(n)    = %ld\\n", linear);
    printf("O(nlogn)= %ld\\n", nlogn);
    printf("O(n^2)  = %ld\\n", quad);
    return 0;
}`,
          cpp: `#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int n = 16;
    long long linear = n;
    long long nlogn = (long long)(n * log2(n));
    long long quad = 1LL * n * n;

    cout << "n       = " << n << '\\n';
    cout << "O(n)    = " << linear << '\\n';
    cout << "O(nlogn)= " << nlogn << '\\n';
    cout << "O(n^2)  = " << quad << '\\n';
}`,
        },
        steps(n) {
          const base = Math.max(1, Math.min(20, n | 0));
          const steps = [];
          const rowsFor = (m) => [
            ["O(n)", m],
            ["O(n log n)", Math.round(m * Math.log2(Math.max(2, m)))],
            ["O(n²)", m * m],
          ];
          steps.push({
            title: `Start at n = ${base}`,
            tracks: [chips("operations at this n", rowsFor(base).map(([k, v]) => `${k}: ${v}`), "dim")],
            counters: [count("n", base), count("largest count", base * base)],
            legend: LEG,
            happened: `At n = ${base} the quadratic column is only ${base * base} operations, which still feels instant.`,
            why: "Small inputs hide complexity differences; the ratio is what matters.",
            codeLine: 5,
          });
          let m = base;
          for (let d = 1; d <= 3; d++) {
            m *= 2;
            const rows = rowsFor(m);
            steps.push({
              title: `Double n to ${m}: quadratic is now ${m * m}`,
              tracks: [
                chips("operations", rows.map(([k, v]) => `${k}: ${v}`), (i) => (i === 2 ? "bad" : i === 1 ? "compare" : "done")),
                chips("growth since last", rows.map(([k, v], i) => `${k} ×${(v / rowsFor(m / 2)[i][1]).toFixed(1)}`), "dim"),
              ],
              counters: [count("n", m), count("largest count", m * m)],
              legend: LEG,
              happened: `Doubling n doubled the linear work, slightly more than doubled the n log n work, and multiplied the quadratic work by four.`,
              why: "The exponent decides the multiplier: linear ×2, quadratic ×4.",
              codeLine: 8,
            });
          }
          const rows = rowsFor(m);
          steps.push({
            title: `At n = ${m}: ${rows[0][1]} vs ${rows[1][1]} vs ${rows[2][1]} operations`,
            tracks: [
              chips("operations", rows.map(([k, v]) => `${k}: ${v}`), (i) => (i === 2 ? "bad" : "result")),
              chips("winner", ["O(n)"], "result"),
            ],
            counters: [count("n", m), count("answer", `${rows[0][1]} operations`)],
            legend: LEG,
            happened: `The scan needs ${rows[0][1]} steps, the sort ${rows[1][1]} and the double loop ${rows[2][1]}.`,
            why: "Choose the lowest growth you can afford; constants matter only after the shape is settled.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "detect-hidden-extra-space",
    title: "Detect Hidden Extra Space",
    category: "Complexity Lab",
    difficulty: "Intermediate",
    description:
      "Find the allocations that do not appear in the loop: sort buffers, recursion stacks, hash maps and string copies.",
    input: { label: "The numbers", default: "4, 1, 3, 2, 5", parse: "ints" },
    approaches: [
      {
        name: "Audit the Allocations",
        complexity: "varies — inspect each line",
        idea: [
          "Space complexity counts every structure that lives alongside the input: a sorted copy, a frequency map, a queue, a recursion stack, or an implicit substring.",
          "An in-place loop that only swaps two values really is O(1), but the same loop with `sorted(a)` in front is O(n) before it starts.",
        ],
        problem: [
          "Libraries hide allocations behind friendly names, so a one-line call can quietly change an O(1) claim into O(n).",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

static int cmp(const void *a, const void *b) {
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

int main(void) {
    int a[] = {4, 1, 3, 2, 5};
    int n = 5;

    int copy[5];                    /* O(n) hidden space */
    for (int i = 0; i < n; i++) copy[i] = a[i];
    qsort(copy, n, sizeof(int), cmp);

    int freq[8] = {0};              /* O(k) where k is the value range */
    for (int i = 0; i < n; i++) freq[copy[i]]++;

    for (int i = 0; i < n; i++)     /* O(1) extra */
        printf("%d ", freq[i]);
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
using namespace std;

int main() {
    vector<int> a{4, 1, 3, 2, 5};

    vector<int> copy = a;           // O(n) extra
    sort(copy.begin(), copy.end());

    map<int, int> freq;             // O(k) nodes, k distinct values
    for (int v : copy) freq[v]++;

    for (auto& [value, times] : freq)
        cout << value << ':' << times << ' ';
    cout << '\\n';
}`,
        },
        steps(nums) {
          if (!nums.length) {
            return [{
              title: "Give some numbers to audit",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("allocations found", 0)],
              legend: ["idle", "result"],
              happened: "Nothing to inspect yet.",
              why: "The audit looks for structures that grow with the input.",
            }];
          }
          const steps = [];
          const sorted = nums.slice().sort((a, b) => a - b);
          const distinct = new Set(nums).size;
          steps.push({
            title: `${nums.length} values — what lives beside them?`,
            tracks: [
              track("input", nums, fill(nums.length, "read")),
              chips("extra space so far", ["none"], "good"),
            ],
            counters: [count("extra cells", 0), count("distinct values", distinct)],
            legend: LEG,
            happened: "The input itself never counts as extra space.",
            why: "Only the additional structures the algorithm creates are measured.",
            codeLine: 11,
          });
          steps.push({
            title: `A sorted copy costs ${nums.length} cells`,
            tracks: [
              track("input", nums, fill(nums.length, "dim")),
              track("sorted copy", sorted, fill(sorted.length, "active")),
            ],
            counters: [count("extra cells", nums.length), count("distinct values", distinct)],
            legend: LEG,
            happened: `Keeping ${nums.join(",")} unchanged while sorting means a second row of ${nums.length} cells.`,
            why: "That is linear extra space, even though the copy looks harmless.",
            codeLine: 12,
          });
          steps.push({
            title: `A frequency map costs ${distinct} slot${distinct === 1 ? "" : "s"}`,
            tracks: [
              track("input", nums, fill(nums.length, "dim")),
              track("sorted copy", sorted, fill(sorted.length, "done")),
              chips("frequency map", [...new Set(nums)].sort((a, b) => a - b).map((v) => `${v}:${nums.filter((x) => x === v).length}`), "active"),
            ],
            counters: [count("extra cells", nums.length + distinct), count("distinct values", distinct)],
            legend: LEG,
            happened: `The map has one entry per distinct value, so it is O(k), where k = ${distinct} here.`,
            why: "k can be much smaller than n, which is why the two costs are quoted separately.",
            codeLine: 16,
          });
          steps.push({
            title: `Answer: ${nums.length + distinct} extra cells, not 0`,
            tracks: [
              chips("sorted copy", [`${nums.length} cells`], "bad"),
              chips("frequency map", [`${distinct} slots`], "bad"),
              chips("total extra", [nums.length + distinct], "result"),
            ],
            counters: [count("extra cells", nums.length + distinct), count("in-place alternative", 0)],
            legend: LEG,
            happened: `The sort copy and the map together hold ${nums.length + distinct} extra cells.`,
            why: "An in-place pass using only two indices would honestly be O(1); this version is not.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  function fibValue(n) {
    let a = 0, b = 1;
    for (let i = 0; i < n; i++) { const t = a + b; a = b; b = t; }
    return a;
  }
})();
