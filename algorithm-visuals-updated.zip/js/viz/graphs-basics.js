/* ============================================================
   DSA Visuals — Graphs Basics
   Grid traversals (islands, fills, oranges, regions) and a
   graph deep-copy walkthrough. Every visualisation follows the
   contract in SPEC.md:
     { id, title, category, difficulty, description,
       input: { label, default, parse },
       approaches: [ { name, complexity, idea, problem,
                       code: { c, cpp }, steps(parsed) } ] }
   Each step: { title, kind, cells/nodes/..., counters,
                happened, why, legend?, codeLine? }
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count, grid } = window.H;
  const V = window.VIZ;

  /* ----------------------------------------------------------
     Shared grid helpers.
     Grids are written as one token per row ("110 010 111").
     Rows may differ in length: everything is trimmed to the
     shortest row so no step ever reads past an edge.
     ---------------------------------------------------------- */
  function toGrid(tokens) {
    const data = tokens.filter((t) => t.length > 0);
    const cols = data.length ? Math.min.apply(null, data.map((t) => t.length)) : 0;
    return { rows: data.length, cols, data, at: (r, c) => data[r].charAt(c) };
  }

  /* Build the cells[] array for a grid step. We list EVERY cell
     each step so values stay visible at all times. */
  function cellsOf(rows, cols, stateOf, valueOf) {
    return grid(rows, cols, (r, c) => ({
      v: valueOf(r, c),
      state: stateOf(r, c),
    }));
  }

  const inside = (rows, cols, r, c) => r >= 0 && r < rows && c >= 0 && c < cols;
  const DIRS = [[-1, 0], [1, 0], [0, -1], [0, 1]];
  const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;

  /* ============================================================
     1. Number of Islands
     ============================================================ */
  V.register({
    id: "number-of-islands",
    title: "Number of Islands",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Count the separate clumps of '1' land in a sea of '0' water.",
    input: { label: "Grid rows, one token per row", default: "11000 11000 00100", parse: "tokens" },
    approaches: [
      {
        name: "Scan and Sink with DFS",
        complexity: "O(rows x cols) time, O(rows x cols) space",
        idea: [
          "Walk every cell from top-left to bottom-right. Water ('0') is ignored; the first land cell ('1') the walk meets that has not been visited starts a brand-new island.",
          "From that seed a depth-first flood fill marks every land cell reachable in the four cardinal directions. The flood cannot cross water, so it covers exactly one island — then the scan keeps looking for the next unvisited land.",
        ],
        problem: [
          "The recursive flood fill grows the call stack with the size of the island — one very large island can overflow it. An explicit queue (breadth-first) avoids that but needs extra bookkeeping.",
          "Sinking the island (painting visited land back to '0') edits the grid in place. If the original map must survive, you need a separate visited table instead.",
        ],
        code: {
          c: `#include <stdio.h>

#define R 3
#define C 5

/* sink one island: flip every reachable '1' back to water */
void sink(char g[R][C], int r, int c) {
    if (r < 0 || r >= R || c < 0 || c >= C || g[r][c] != '1') return;
    g[r][c] = '0';
    sink(g, r + 1, c); sink(g, r - 1, c);
    sink(g, r, c + 1); sink(g, r, c - 1);
}

int count_islands(char g[R][C]) {
    int found = 0;
    for (int r = 0; r < R; r++)
        for (int c = 0; c < C; c++)
            if (g[r][c] == '1') { sink(g, r, c); found++; }
    return found;
}

int main(void) {
    char g[R][C] = {
        {'1','1','0','0','0'},
        {'1','1','0','0','0'},
        {'0','0','1','0','0'}
    };
    printf("%d\\n", count_islands(g)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

using grid_t = std::vector<std::string>;

// sink one island: turn every reachable '1' back into water
void sink(grid_t& g, int r, int c) {
    if (r < 0 || r >= (int)g.size() || c < 0 || c >= (int)g[0].size() || g[r][c] != '1') return;
    g[r][c] = '0';
    sink(g, r + 1, c); sink(g, r - 1, c);
    sink(g, r, c + 1); sink(g, r, c - 1);
}

int countIslands(grid_t g) {        // takes a copy: the input stays intact
    int found = 0;
    for (int r = 0; r < (int)g.size(); r++)
        for (int c = 0; c < (int)g[0].size(); c++)
            if (g[r][c] == '1') { sink(g, r, c); ++found; }
    return found;
}

int main() {
    std::cout << countIslands({"11000", "11000", "00100"}) << '\\n'; // 2
}`,
        },
        steps(tokens) {
          const G = toGrid(tokens);
          const R = G.rows, C = G.cols;
          const total = R * C;
          const land = (r, c) => G.at(r, c) === "1";
          const visited = [];
          for (let r = 0; r < R; r++) visited.push(new Array(C).fill(false));

          const scanState = (cur) => (r, c) => {
            if (cur && cur[0] === r && cur[1] === c) return "read";
            if (!land(r, c)) return "dim";
            return visited[r][c] ? "done" : "idle";
          };
          const board = (states) => ({
            kind: "grid", rows: R, cols: C,
            cells: cellsOf(R, C, states, (r, c) => G.at(r, c)),
          });
          let islands = 0, scanned = 0;
          const counters = () => [
            count("islands found", islands),
            count("cells visited", scanned, total),
          ];
          const steps = [];

          steps.push({
            ...board(scanState(null)),
            title: "Set up: 1 = land, 0 = water",
            counters: counters(),
            legend: ["read", "done", "dim", "idle"],
            happened: `A ${R} x ${C} grid waits to be scanned; water is greyed out, land still untouched.`,
            why: "Every cell is either sea or part of exactly one island — the scan will sort that out.",
            codeLine: 3,
          });

          /* Detailed grids (small enough) get one scan step per skipped
             cell; bigger grids summarise each row instead. */
          const detailed = total <= 25;
          const skipTitle = (r, c) =>
            `Scan (${r},${c}): ${visited[r][c] ? "land already counted" : "water"} - skip`;
          for (let r = 0; r < R; r++) {
            let rowSkip = 0;
            for (let c = 0; c < C; c++) {
              scanned++;
              if (!land(r, c) || visited[r][c]) {
                if (detailed) {
                  steps.push({
                    ...board(scanState([r, c])),
                    title: skipTitle(r, c),
                    counters: counters(),
                    legend: ["read", "done", "dim", "idle"],
                    happened: visited[r][c]
                      ? `Cell (${r},${c}) was already swallowed by an island that has been counted.`
                      : `Cell (${r},${c}) holds water, so no island can start here.`,
                    why: "A flood only ever starts from land the scan has never touched.",
                    codeLine: 17,
                  });
                } else {
                  rowSkip++;
                }
                continue;
              }

              /* discovery: unvisited land — a new island begins */
              islands++;
              steps.push({
                ...board(scanState([r, c])),
                title: `Island #${islands} starts at (${r},${c})`,
                counters: counters(),
                legend: ["read", "done", "dim", "idle"],
                happened: `Cell (${r},${c}) is unvisited land, so island #${islands} is declared and a flood fill launches from it.`,
                why: "Scanning left-to-right and top-to-bottom guarantees every island is discovered exactly once.",
                codeLine: 18,
              });
              const stack = [[r, c]];
              let size = 0;
              while (stack.length) {
                const cell = stack.pop();
                const rr = cell[0], cc = cell[1];
                if (!inside(R, C, rr, cc) || !land(rr, cc) || visited[rr][cc]) continue;
                visited[rr][cc] = true;
                size++;
                steps.push({
                  ...board(scanState([rr, cc])),
                  title: `Flood takes (${rr},${cc}) -> island #${islands} has ${plural(size, "cell")}`,
                  counters: counters().concat([count(`island #${islands} size`, size)]),
                  legend: ["read", "done", "dim", "idle"],
                  happened: `(${rr},${cc}) is land inside the flood, so it is marked visited and joins island #${islands}.`,
                  why: "Each visit queues its four neighbours, so the flood creeps outward until water blocks it.",
                  codeLine: 9,
                });
                for (const d of DIRS) stack.push([rr + d[0], cc + d[1]]);
              }
              steps.push({
                ...board(scanState(null)),
                title: `Island #${islands} finished: ${plural(size, "cell")}`,
                counters: counters(),
                legend: ["read", "done", "dim", "idle"],
                happened: `The flood met water on every side — island #${islands} holds ${plural(size, "cell")} and the scan moves on.`,
                why: "Sinking the island while counting means the scan can never count the same land twice.",
                codeLine: 19,
              });
            }
            if (!detailed && rowSkip > 0) {
              steps.push({
                ...board(scanState(null)),
                title: `Scan row ${r}: ${plural(rowSkip, "cell")} checked, no new land`,
                counters: counters(),
                legend: ["done", "dim", "idle"],
                happened: `Row ${r} held only water or already-counted land, so nothing new started there.`,
                why: "Cells inside a counted island can never seed another one — the flood already claimed them.",
                codeLine: 17,
              });
            }
          }

          steps.push({
            ...board((r, c) => (land(r, c) ? "good" : "dim")),
            title: `Answer: ${plural(islands, "island")}`,
            counters: [
              count("islands found", islands),
              count("answer", islands),
              count("cells visited", total, total),
            ],
            legend: ["good", "dim"],
            happened: `The scan covered all ${plural(total, "cell")}; the land grouped into ${plural(islands, "island")}.`,
            why: "Every land cell was flooded exactly once, so the whole grid costs O(rows x cols) work in total.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });
  /* ============================================================
     2. Flood Fill
     ============================================================ */
  V.register({
    id: "flood-fill",
    title: "Flood Fill",
    category: "Graphs",
    difficulty: "Beginner",
    description: "Repaint the whole region connected to one start cell.",
    input: {
      label: "Optional sr= sc= new=, then grid rows",
      default: "sr=1 sc=2 1111 1101 1101 0000",
      parse: "tokens",
    },
    approaches: [
      {
        name: "BFS with a Queue",
        complexity: "O(rows x cols) time, O(rows x cols) space",
        idea: [
          "Note the colour of the start cell. Put the start in a queue, then repeatedly take a cell out and repaint it. Every neighbour that still holds the old colour joins the queue, so the paint spreads outward in rings.",
          "Cells of any other colour act as walls: the flood simply stops at them. When the queue runs dry, the whole connected region has been repainted.",
        ],
        problem: [
          "Only the four cardinal directions count as neighbours — diagonals touching a corner do not connect a region.",
          "If the replacement colour equals the start colour the flood would never end, so real code must guard against that case first.",
        ],
        code: {
          c: `#include <stdio.h>

#define R 4
#define C 4

int dr[4] = {-1, 1, 0, 0};
int dc[4] = {0, 0, -1, 1};

/* repaint every cell connected to (sr, sc) that still holds oldc */
void flood(char g[R][C], int sr, int sc, char oldc, char newc) {
    if (g[sr][sc] != oldc) return;      /* wrong colour: stop here */
    g[sr][sc] = newc;
    for (int d = 0; d < 4; d++) {
        int r = sr + dr[d], c = sc + dc[d];
        if (r >= 0 && r < R && c >= 0 && c < C && g[r][c] == oldc)
            flood(g, r, c, oldc, newc);  /* the paint spreads */
    }
}

int main(void) {
    char g[R][C] = {
        {'1','1','1','1'},
        {'1','1','0','1'},
        {'1','1','0','1'},
        {'0','0','0','0'}
    };
    flood(g, 1, 2, '0', '9');           /* repaint the lake */
    for (int r = 0; r < R; r++) {
        for (int c = 0; c < C; c++) printf("%c ", g[r][c]);
        printf("\\n");
    }
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>

int dr[4] = {-1, 1, 0, 0};
int dc[4] = {0, 0, -1, 1};

// spread the paint from (sr, sc) to every matching neighbour
void flood(std::vector<std::string>& g, int sr, int sc, char oldc, char newc) {
    if (sr < 0 || sr >= (int)g.size() || sc < 0 || sc >= (int)g[0].size()) return;
    if (g[sr][sc] != oldc) return;              // wrong colour: stop
    g[sr][sc] = newc;
    for (int d = 0; d < 4; d++)
        flood(g, sr + dr[d], sc + dc[d], oldc, newc);
}

int main() {
    std::vector<std::string> g{"1111", "1101", "1101", "0000"};
    flood(g, 1, 2, '0', '9');
    for (auto& row : g) std::cout << row << '\\n';
}`,
        },
        steps(tokens) {
          /* pull the sr= / sc= / new= conventions off the front */
          let sr = 0, sc = 0, wantNew = null;
          const rowsTok = [];
          for (const t of tokens) {
            let m = /^sr=(\d+)$/.exec(t);
            if (m) { sr = parseInt(m[1], 10); continue; }
            m = /^sc=(\d+)$/.exec(t);
            if (m) { sc = parseInt(m[1], 10); continue; }
            m = /^new=(\S)$/.exec(t);
            if (m) { wantNew = m[1]; continue; }
            rowsTok.push(t);
          }
          const G = toGrid(rowsTok);
          const R = G.rows, C = G.cols;
          const steps = [];
          if (R > 0) {
            sr = Math.min(Math.max(sr, 0), R - 1);
            sc = Math.min(Math.max(sc, 0), C - 1);
          }
          const oldc = R > 0 ? G.at(sr, sc) : "";
          /* auto replacement: first digit/letter that appears nowhere in the grid */
          const used = new Set();
          for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) used.add(G.at(r, c));
          let newc = "#";
          for (const ch of "9876543210abcdefghijklmnopqrstuvwxyz#") {
            if (!used.has(ch)) { newc = ch; break; }
          }
          if (wantNew != null) newc = wantNew;

          const filled = [];
          for (let r = 0; r < R; r++) filled.push(new Array(C).fill(false));
          const stateAt = (cur) => (r, c) => {
            if (cur && cur[0] === r && cur[1] === c) return "read";
            return filled[r][c] ? "done" : "idle";
          };
          const board = (states) => ({
            kind: "grid", rows: R, cols: C,
            cells: cellsOf(R, C, states, (r, c) => G.at(r, c)),
          });
          let nfilled = 0;
          const counters = (q) => [
            count("cells filled", nfilled),
            ...(q == null ? [] : [count("queue left", q)]),
          ];

          steps.push({
            ...board((r, c) => (R > 0 && r === sr && c === sc ? "read" : "idle")),
            title: `Set up: start at (${sr},${sc}) holding '${oldc || "-"}'`,
            counters: [count("cells filled", 0), count("start colour", oldc || "-"), count("new colour", newc)],
            legend: ["read", "done", "idle"],
            happened: R > 0
              ? `A ${R} x ${C} grid; the start cell (${sr},${sc}) glows, and every '${oldc}' cell it connects to will be repainted '${newc}'.`
              : "No grid rows were given, so there is nothing to fill.",
            why: "Flood fill repaints one connected region — the region is defined by sharing the start cell's original colour.",
            codeLine: 9,
          });

          if (R === 0) {
            steps.push({
              title: "Answer: nothing to fill",
              tracks: [],
              counters: [count("cells filled", 0), count("answer", 0)],
              legend: ["idle"],
              happened: "The input contained no grid rows, so the region to fill is empty.",
              why: "An empty picture has an empty flood — the algorithm finishes without doing any work.",
              codeLine: 9,
            });
            return steps;
          }
          if (newc === oldc) {
            const guardState = (r, c) => (r === sr && c === sc ? "read" : "idle");
            steps.push({
              ...board(guardState),
              title: `Guard: new colour equals old colour ('${oldc}')`,
              counters: [count("cells filled", 0), count("answer", "blocked")],
              legend: ["read", "idle"],
              happened: `Repainting '${oldc}' with '${oldc}' would make every cell look unfilled forever, so the fill is refused.`,
              why: "Real code checks this up front — otherwise the flood would loop endlessly over the same region.",
              codeLine: 9,
            });
            steps.push({
              title: "Answer: 0 cells filled",
              tracks: [],
              counters: [count("cells filled", 0), count("answer", 0)],
              legend: ["idle"],
              happened: "Nothing was changed because the replacement colour was rejected.",
              why: "Choosing a genuinely different colour is the one precondition this algorithm needs.",
              codeLine: 9,
            });
            return steps;
          }

          const queue = [[sr, sc]];
          let head = 0;
          const seedState = (r, c) => (r === sr && c === sc ? "read" : "idle");
          steps.push({
            ...board(seedState),
            title: `Seed the queue with (${sr},${sc})`,
            counters: counters(1),
            legend: ["read", "done", "idle"],
            happened: `The start cell goes into the queue — it is the first member of the region to repaint.`,
            why: "A queue makes the paint spread evenly outward, one ring per pass, never running out of stack space.",
            codeLine: 10,
          });

          while (head < queue.length) {
            const cur = queue[head++];
            const r = cur[0], c = cur[1];
            if (filled[r][c] || G.at(r, c) !== oldc) continue;
            filled[r][c] = true;
            nfilled++;
            let matches = 0;
            for (const d of DIRS) {
              const nr = r + d[0], nc = c + d[1];
              if (inside(R, C, nr, nc) && !filled[nr][nc] && G.at(nr, nc) === oldc) {
                queue.push([nr, nc]);
                matches++;
              }
            }
            steps.push({
              ...board(stateAt([r, c])),
              title: `Fill (${r},${c}): '${oldc}' -> '${newc}'`,
              counters: counters(queue.length - head),
              legend: ["read", "done", "idle"],
              happened: `(${r},${c}) still holds '${oldc}', so it takes the new colour '${newc}'; ${plural(matches, "matching neighbour")} join${matches === 1 ? "s" : ""} the queue.`,
              why: "Queued neighbours guarantee the flood reaches every cell of the region exactly once and then stops.",
              codeLine: 12,
            });
          }

          steps.push({
            ...board((r, c) => (filled[r][c] ? "result" : "idle")),
            title: `Answer: ${plural(nfilled, "cell")} filled with '${newc}'`,
            counters: [count("cells filled", nfilled), count("answer", nfilled)],
            legend: ["result", "idle"],
            happened: `The queue emptied after ${plural(nfilled, "cell")} — the whole region around (${sr},${sc}) now reads '${newc}'.`,
            why: "Every cell of the region was painted once; every cell outside it still holds its own colour.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });
  /* ============================================================
     3. Clone Graph
     ============================================================ */
  V.register({
    id: "clone-graph",
    title: "Clone Graph",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Build a brand-new copy of an undirected graph, node by node.",
    input: { label: "Edges as a,b pairs", default: "1,2 1,3 2,4", parse: "string" },
    approaches: [
      {
        name: "Copy Nodes, Then Rewire Edges",
        complexity: "O(n + m) time, O(n) space",
        idea: [
          "A clone must hold brand-new nodes — never pointers back into the original. Pass one walks the original and creates a fresh node for every node it meets, recording original -> copy in a map.",
          "Pass two walks each edge and rewires it: edge u-v in the clone joins copy(u) to copy(v). Because every copy already exists, no edge is ever left dangling.",
        ],
        problem: [
          "Two passes plus a map are needed because an edge can point at a node that has not been copied yet — a single greedy pass would have to patch links afterwards.",
          "The map itself costs O(n) extra memory, and a graph that references itself in a cycle still works, but only because the map remembers nodes already seen.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

#define N 4

/* deep copy, one node (row) at a time: fresh storage, same shape */
void clone_graph(const int adj[N][N], int copy[N][N]) {
    for (int u = 0; u < N; u++)
        memcpy(copy[u], adj[u], sizeof(int) * N);
}

int main(void) {
    /* undirected edges 1-2, 1-3, 2-4 */
    int adj[N][N] = {{0,1,1,0}, {1,0,0,1}, {1,0,0,0}, {0,1,0,0}};
    int copy[N][N];
    clone_graph(adj, copy);
    copy[0][1] = 0;                            /* edit the clone ... */
    printf("%d %d\\n", adj[0][1], copy[0][1]);  /* 1 0 - original untouched */
    return 0;
}`,
          cpp: `#include <iostream>
#include <unordered_map>
#include <vector>

struct Node {
    int label;
    std::vector<Node*> nbrs;
};

// pass 1: copy every node; pass 2: point the copies' edges at copies
Node* cloneGraph(Node* src) {
    if (!src) return nullptr;
    std::unordered_map<Node*, Node*> seen;   // original -> brand-new copy
    std::vector<Node*> all{src};
    seen[src] = new Node{src->label, {}};
    for (std::size_t i = 0; i < all.size(); i++)
        for (Node* nb : all[i]->nbrs)
            if (!seen.count(nb)) {           // first time we meet this node
                seen[nb] = new Node{nb->label, {}};
                all.push_back(nb);
            }
    for (Node* u : all)
        for (Node* nb : u->nbrs)
            seen[u]->nbrs.push_back(seen[nb]); // rewired to the copy
    return seen[src];
}

int main() {
    Node n1{1, {}}, n2{2, {}}, n3{3, {}}, n4{4, {}};
    n1.nbrs = {&n2, &n3};   n2.nbrs = {&n1, &n4};
    n3.nbrs = {&n1};        n4.nbrs = {&n2};
    Node* c = cloneGraph(&n1);
    std::cout << c->label << " has " << c->nbrs.size() << " neighbours\\n"; // 1 has 2
}`,
        },
        steps(raw) {
          /* read the edge list ourselves: "1,2 1,3 2,4" */
          const parts = String(raw).trim().replace(/,\s+/g, ",").split(/\s+/).filter(Boolean);
          const seenEdge = new Set();
          const edges = [];
          let maxLabel = 0;
          for (const p of parts) {
            const ab = p.split(",");
            if (ab.length !== 2) continue;
            const a = Math.floor(Number(ab[0]));
            const b = Math.floor(Number(ab[1]));
            if (!Number.isFinite(a) || !Number.isFinite(b)) continue;
            if (a < 1 || b < 1 || a === b) continue;   /* skip junk and self-loops */
            maxLabel = Math.max(maxLabel, a, b);
            const key = a < b ? a + "-" + b : b + "-" + a;
            if (!seenEdge.has(key)) {
              seenEdge.add(key);
              edges.push({ u: Math.min(a, b), v: Math.max(a, b) });
            }
          }
          const n = maxLabel;                     /* nodes are labelled 1..n */
          const m = edges.length;
          /* circle layout: angle = 2*pi*i/n, radius 20, centred at (25,25) */
          const pos = (label) => {
            const a = (2 * Math.PI * (label - 1)) / Math.max(1, n);
            return {
              x: +(25 + 20 * Math.cos(a)).toFixed(1),
              y: +(25 + 20 * Math.sin(a)).toFixed(1),
            };
          };
          const origNodes = (state, cur) =>
            Array.from({ length: n }, (_, i) => {
              const k = i + 1, p = pos(k);
              return { id: "o" + k, label: String(k), x: p.x, y: p.y, state: cur === k ? "read" : state };
            });
          const cloneNodes = (copied, cur) =>
            Array.from({ length: copied }, (_, i) => {
              const k = i + 1, p = pos(k);
              return { id: "c" + k, label: k + "'", x: p.x, y: p.y, state: cur === k ? "read" : "result" };
            });
          /* edges shown while nodes are still being copied: only edges
             whose BOTH endpoints already exist in the clone */
          const cloneEdgesFiltered = (maxLabel) =>
            edges
              .filter((e) => e.u <= maxLabel && e.v <= maxLabel)
              .map((e) => ({ a: "c" + e.u, b: "c" + e.v, state: "good" }));
          const cloneEdges = (copied, cur) =>
            edges.slice(0, copied).map((e, i) => ({
              a: "c" + e.u, b: "c" + e.v,
              state: i === copied - 1 && cur ? "read" : "good",
            }));
          const steps = [];

          steps.push({
            kind: "graph",
            nodes: origNodes("idle"),
            edges: edges.map((e) => ({ a: "o" + e.u, b: "o" + e.v, state: "idle" })),
            label: "original graph - the input",
            title: "Set up: read the original graph",
            counters: [count("nodes", n), count("edges", m)],
            legend: ["read", "result", "good", "dim", "idle"],
            happened: n
              ? `The input describes ${plural(n, "node")} laid out on a circle and ${plural(m, "undirected edge")}.`
              : "No usable a,b edge pairs were found in the input.",
            why: "The clone has to mirror this exact shape — same labels, same connections — while using completely new nodes.",
            codeLine: 6,
          });

          if (n === 0) {
            steps.push({
              kind: "graph",
              nodes: [],
              edges: [],
              label: "empty graph",
              title: "Answer: nothing to clone",
              counters: [count("nodes copied", 0), count("edges copied", 0), count("answer", 0)],
              legend: ["idle"],
              happened: "With no nodes in the input, the clone is empty too.",
              why: "An empty graph is the boundary case: the copy is just as empty as the original.",
              codeLine: 12,
            });
            return steps;
          }

          for (let k = 1; k <= n; k++) {
            steps.push({
              kind: "graph",
              nodes: origNodes("dim").concat(cloneNodes(k, k)),
              edges: cloneEdgesFiltered(k),
              label: `the clone - ${k} of ${n} nodes copied`,
              title: `Copy node ${k} -> clone node ${k}'`,
              counters: [count("nodes copied", k, n), count("edges copied", 0, m)],
              legend: ["read", "result", "dim", "idle"],
              happened: `A brand-new node labelled ${k}' is created; the map now pairs original ${k} with its copy.`,
              why: "Pass one never copies edges — it only guarantees that every node a later edge could point at already exists.",
              codeLine: 15,
            });
          }

          for (let j = 0; j < m; j++) {
            const e = edges[j];
            steps.push({
              kind: "graph",
              nodes: cloneNodes(n, 0).map((nd) => {
                const k = parseInt(nd.id.slice(1), 10);
                return { ...nd, state: (k === e.u || k === e.v) ? "read" : "result" };
              }),
              edges: cloneEdges(j + 1),
              label: `the clone - ${j + 1} of ${m} edges rewired`,
              title: `Copy edge ${e.u}-${e.v} -> clone edge ${e.u}'-${e.v}'`,
              counters: [count("nodes copied", n, n), count("edges copied", j + 1, m)],
              legend: ["read", "good", "result"],
              happened: `Edge ${e.u}-${e.v} is rewired in the clone: copy(${e.u}) now links to copy(${e.v}).`,
              why: "Because pass one already created both endpoints, pointing the edge at the copies is a single wiring step.",
              codeLine: 22,
            });
          }

          steps.push({
            kind: "graph",
            nodes: cloneNodes(n, 0),
            edges: cloneEdges(m, false),
            label: "the clone - complete",
            title: `Answer: deep copy with ${plural(n, "node")} and ${plural(m, "edge")}`,
            counters: [
              count("nodes copied", n, n),
              count("edges copied", m, m),
              count("answer", "deep copy"),
            ],
            legend: ["result", "good"],
            happened: `The clone holds ${plural(n, "fresh node")} and ${plural(m, "rewired edge")} — structurally identical to the original.`,
            why: "No clone pointer refers back into the original, so editing one graph can never leak into the other.",
            codeLine: 22,
          });
          return steps;
        },
      },
    ],
  });
  /* ============================================================
     4. Max Area of Island
     ============================================================ */
  V.register({
    id: "max-area-of-island",
    title: "Max Area of Island",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Flood each island, measure it, and keep the largest measurement.",
    input: { label: "Grid rows, one token per row", default: "11000 11000 00100", parse: "tokens" },
    approaches: [
      {
        name: "Measure Every Island",
        complexity: "O(rows x cols) time, O(rows x cols) space",
        idea: [
          "This is the island scan with a tape measure attached. When the scan finds unvisited land, it starts a flood fill and counts every cell the flood swallows — that count is the area of the current island.",
          "Whenever an island finishes, its area is compared with the best area seen so far. The best one wins the contest.",
        ],
        problem: [
          "Every island is measured in full — there is no shortcut, because the biggest island can be the last one discovered.",
          "The flood edits the grid (or needs a visited table) just like plain island counting, and the recursion depth still follows the size of the largest island.",
        ],
        code: {
          c: `#include <stdio.h>

#define R 3
#define C 5

/* flood one island and report how many land cells it holds */
int sink(char g[R][C], int r, int c) {
    if (r < 0 || r >= R || c < 0 || c >= C || g[r][c] != '1') return 0;
    g[r][c] = '0';
    return 1 + sink(g, r + 1, c) + sink(g, r - 1, c)
             + sink(g, r, c + 1) + sink(g, r, c - 1);
}

int max_area(char g[R][C]) {
    int best = 0;
    for (int r = 0; r < R; r++)
        for (int c = 0; c < C; c++)
            if (g[r][c] == '1') {
                int area = sink(g, r, c);
                if (area > best) best = area;
            }
    return best;
}

int main(void) {
    char g[R][C] = {
        {'1','1','0','0','0'},
        {'1','1','0','0','0'},
        {'0','0','1','0','0'}
    };
    printf("%d\\n", max_area(g)); /* 4 */
    return 0;
}`,
          cpp: `#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

// grow the island from (r, c) and count the cells it swallows
int grow(std::vector<std::string>& g, int r, int c) {
    if (r < 0 || r >= (int)g.size() || c < 0 || c >= (int)g[0].size() || g[r][c] != '1') return 0;
    g[r][c] = '0';
    return 1 + grow(g, r + 1, c) + grow(g, r - 1, c)
             + grow(g, r, c + 1) + grow(g, r, c - 1);
}

int maxAreaOfIsland(std::vector<std::string> g) {
    int best = 0;
    for (int r = 0; r < (int)g.size(); r++)
        for (int c = 0; c < (int)g[0].size(); c++)
            if (g[r][c] == '1')
                best = std::max(best, grow(g, r, c));
    return best;
}

int main() {
    std::cout << maxAreaOfIsland({"11000", "11000", "00100"}) << '\\n'; // 4
}`,
        },
        steps(tokens) {
          const G = toGrid(tokens);
          const R = G.rows, C = G.cols;
          const total = R * C;
          const land = (r, c) => G.at(r, c) === "1";
          const visited = [];
          for (let r = 0; r < R; r++) visited.push(new Array(C).fill(false));

          const scanState = (cur) => (r, c) => {
            if (cur && cur[0] === r && cur[1] === c) return "read";
            if (!land(r, c)) return "dim";
            return visited[r][c] ? "done" : "idle";
          };
          const board = (states) => ({
            kind: "grid", rows: R, cols: C,
            cells: cellsOf(R, C, states, (r, c) => G.at(r, c)),
          });
          let scanned = 0, area = 0, best = 0, bestCells = [];
          const counters = () => [
            count("current area", area),
            count("best area", best),
            count("cells visited", scanned, total),
          ];
          const steps = [];

          steps.push({
            ...board(scanState(null)),
            title: "Set up: islands to measure",
            counters: counters(),
            legend: ["read", "done", "result", "dim", "idle"],
            happened: `A ${R} x ${C} grid of land and water; each clump of '1' is one island waiting to be measured.`,
            why: "The scan will flood each island once, and the flood's cell count is exactly that island's area.",
            codeLine: 3,
          });

          const detailed = total <= 25;
          for (let r = 0; r < R; r++) {
            let rowSkip = 0;
            for (let c = 0; c < C; c++) {
              scanned++;
              if (!land(r, c) || visited[r][c]) {
                if (detailed) {
                  steps.push({
                    ...board(scanState([r, c])),
                    title: `Scan (${r},${c}): ${visited[r][c] ? "land already measured" : "water"} - skip`,
                    counters: counters(),
                    legend: ["read", "done", "dim", "idle"],
                    happened: visited[r][c]
                      ? `Cell (${r},${c}) already belongs to a measured island.`
                      : `Cell (${r},${c}) is water — no island begins here.`,
                    why: "Only untouched land can start a new measurement.",
                    codeLine: 17,
                  });
                } else {
                  rowSkip++;
                }
                continue;
              }

              area = 0;
              const islandCells = [];
              steps.push({
                ...board(scanState([r, c])),
                title: `New island at (${r},${c}) - start measuring`,
                counters: counters(),
                legend: ["read", "done", "result", "dim", "idle"],
                happened: `(${r},${c}) is unvisited land, so the flood begins and the current area resets to 0.`,
                why: "Each island is measured from scratch; the tape measure only belongs to the island being flooded.",
                codeLine: 18,
              });
              const stack = [[r, c]];
              while (stack.length) {
                const cell = stack.pop();
                const rr = cell[0], cc = cell[1];
                if (!inside(R, C, rr, cc) || !land(rr, cc) || visited[rr][cc]) continue;
                visited[rr][cc] = true;
                area++;
                islandCells.push([rr, cc]);
                steps.push({
                  ...board(scanState([rr, cc])),
                  title: `Grow (${rr},${cc}) -> area is now ${area}`,
                  counters: counters(),
                  legend: ["read", "done", "result", "dim", "idle"],
                  happened: `(${rr},${cc}) joins the island being measured, pushing the current area to ${area}.`,
                  why: "Counting during the flood is free — the flood already visits each cell exactly once.",
                  codeLine: 10,
                });
                for (const d of DIRS) stack.push([rr + d[0], cc + d[1]]);
              }
              const prevBest = best;
              const beat = area > best;
              if (beat) { best = area; bestCells = islandCells.slice(); }
              steps.push({
                ...board(scanState(null)),
                title: beat ? `Island of area ${area} takes the lead` : `Island of area ${area} is not the biggest`,
                counters: counters(),
                legend: ["read", "done", "result", "dim", "idle"],
                happened: beat
                  ? `The island holds ${plural(area, "cell")} — bigger than the old best of ${prevBest}, so the best area becomes ${best}.`
                  : `The island holds ${plural(area, "cell")}, which does not beat the best area of ${best}.`,
                why: "Keeping only the best value means earlier islands can be forgotten; their sizes are no longer needed.",
                codeLine: 20,
              });
            }
            if (!detailed && rowSkip > 0) {
              steps.push({
                ...board(scanState(null)),
                title: `Scan row ${r}: ${plural(rowSkip, "cell")} checked, no new island`,
                counters: counters(),
                legend: ["done", "dim", "idle"],
                happened: `Row ${r} held only water or measured land, so the tape measure stayed away.`,
                why: "Measured land can never seed a second measurement.",
                codeLine: 17,
              });
            }
          }

          const bestSet = new Set(bestCells.map((p) => p[0] + "," + p[1]));
          steps.push({
            ...board((r, c) => {
              if (!land(r, c)) return "dim";
              return bestSet.has(r + "," + c) ? "result" : "done";
            }),
            title: `Answer: the largest island holds ${plural(best, "cell")}`,
            counters: [count("best area", best), count("answer", best)],
            legend: ["result", "done", "dim"],
            happened: best > 0
              ? `After measuring every island, the biggest one covers ${plural(best, "cell")} (shown in amber).`
              : "There was no land at all, so the largest island has area 0.",
            why: "Every land cell was flooded once, so the answer arrives in a single linear pass over the grid.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });
  /* ============================================================
     5. Rotting Oranges
     ============================================================ */
  V.register({
    id: "rotting-oranges",
    title: "Rotting Oranges",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Count the minutes until rot spreads through every fresh orange.",
    input: { label: "Grid rows of 0/1/2 (empty, fresh, rotted)", default: "211 110 012", parse: "tokens" },
    approaches: [
      {
        name: "BFS in Minute Waves",
        complexity: "O(rows x cols) time, O(rows x cols) space",
        idea: [
          "Every rotted orange goes into a queue. Process the queue one wave at a time: a wave is exactly the cells still waiting when the previous wave ended, and each wave takes exactly one minute.",
          "When a rotted orange is processed, each fresh neighbour rots and joins the queue. When the queue drains, the minutes counted equals the answer — if any fresh orange is left over, the answer is 'never'.",
        ],
        problem: [
          "The fresh oranges that are cut off from every rotted one can never rot; the algorithm must report that instead of hanging.",
          "The queue holds every rotted cell in the worst case, so the extra memory is proportional to the grid size.",
        ],
        code: {
          c: `#include <stdio.h>

#define R 3
#define C 3

int dr[4] = {-1, 1, 0, 0};
int dc[4] = {0, 0, -1, 1};

/* BFS in waves: one wave = one minute. -1 = fresh oranges left over */
int rot_minutes(int g[R][C]) {
    int qr[512], qc[512], head = 0, tail = 0, fresh = 0;
    for (int r = 0; r < R; r++)
        for (int c = 0; c < C; c++) {
            if (g[r][c] == 1) fresh++;
            if (g[r][c] == 2) { qr[tail] = r; qc[tail] = c; tail++; }
        }
    int minutes = 0;
    while (head < tail && fresh > 0) {
        int level = tail - head;               /* cells in this wavefront */
        while (level--) {
            int r = qr[head], c = qc[head]; head++;
            for (int d = 0; d < 4; d++) {
                int nr = r + dr[d], nc = c + dc[d];
                if (nr >= 0 && nr < R && nc >= 0 && nc < C && g[nr][nc] == 1) {
                    g[nr][nc] = 2; fresh--;
                    qr[tail] = nr; qc[tail] = nc; tail++;
                }
            }
        }
        minutes++;
    }
    return fresh > 0 ? -1 : minutes;
}

int main(void) {
    int g[R][C] = {{2,1,1}, {1,1,0}, {0,1,2}};
    int m = rot_minutes(g);
    if (m < 0) printf("never\\n");
    else printf("%d\\n", m); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <queue>
#include <string>
#include <utility>
#include <vector>

// one BFS wave per minute; -1 means some fresh oranges stay fresh
int rotMinutes(std::vector<std::vector<int>> g) {
    int fresh = 0, minutes = 0;
    std::queue<std::pair<int, int>> q;
    for (int r = 0; r < (int)g.size(); r++)
        for (int c = 0; c < (int)g[0].size(); c++) {
            if (g[r][c] == 1) ++fresh;
            if (g[r][c] == 2) q.push({r, c});
        }
    int d[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
    while (!q.empty() && fresh > 0) {
        int level = (int)q.size();          // the whole wavefront at once
        while (level--) {
            auto [r, c] = q.front(); q.pop();
            for (auto& [dr, dc] : d) {
                int nr = r + dr, nc = c + dc;
                if (nr >= 0 && nr < (int)g.size() && nc >= 0 && nc < (int)g[0].size() && g[nr][nc] == 1) {
                    g[nr][nc] = 2; --fresh;
                    q.push({nr, nc});
                }
            }
        }
        ++minutes;
    }
    return fresh > 0 ? -1 : minutes;
}

int main() {
    int m = rotMinutes({{2, 1, 1}, {1, 1, 0}, {0, 1, 2}});
    std::cout << (m < 0 ? "never" : std::to_string(m)) << '\\n'; // 2
}`,
        },
        steps(tokens) {
          const G = toGrid(tokens);
          const R = G.rows, C = G.cols;
          const rotd = [];
          for (let r = 0; r < R; r++) rotd.push(new Array(C).fill(false));
          let fresh = 0;
          const queue = [];
          for (let r = 0; r < R; r++)
            for (let c = 0; c < C; c++) {
              if (G.at(r, c) === "1") fresh++;
              if (G.at(r, c) === "2") { rotd[r][c] = true; queue.push([r, c]); }
            }
          const rottedCount = queue.length;
          let freshLeft = fresh, minutes = 0;

          const stateAt = (cur, extra) => (r, c) => {
            if (extra && extra.has(r + "," + c)) return "read";
            if (cur && cur[0] === r && cur[1] === c) return "read";
            if (rotd[r][c]) return "done";
            if (G.at(r, c) === "1") return "idle";
            return "dim";
          };
          const board = (states) => ({
            kind: "grid", rows: R, cols: C,
            cells: cellsOf(R, C, states, (r, c) => G.at(r, c)),
          });
          const counters = () => [
            count("minutes elapsed", minutes),
            count("fresh left", freshLeft),
          ];
          const steps = [];

          steps.push({
            ...board(stateAt(null)),
            title: "Set up: 0 empty, 1 fresh, 2 rotted",
            counters: [count("minutes elapsed", 0), count("fresh oranges", fresh), count("already rotted", rottedCount)],
            legend: ["done", "idle", "dim"],
            happened: `A ${R} x ${C} grid with ${plural(rottedCount, "rotted orange")} already starting the infection and ${plural(fresh, "fresh orange")} waiting.`,
            why: "Rot spreads one step per minute in every direction, so this is a breadth-first search measured in waves.",
            codeLine: 11,
          });

          steps.push({
            ...board((r, c) => (rotd[r][c] ? "read" : G.at(r, c) === "1" ? "idle" : "dim")),
            title: `Seed the queue with ${plural(rottedCount, "rotted orange")}`,
            counters: counters().concat([count("in the wavefront", rottedCount)]),
            legend: ["read", "done", "idle", "dim"],
            happened: "Every already-rotted orange joins the wavefront — they all rot at minute zero, together.",
            why: "Starting from the whole initial wavefront (not just one) makes the very first minute correct in every spot at once.",
            codeLine: 15,
          });

          if (R === 0) {
            steps.push({
              title: "Answer: 0 minutes",
              tracks: [],
              counters: [count("minutes elapsed", 0), count("answer", 0)],
              legend: ["idle"],
              happened: "No grid rows were given, so there is nothing to rot.",
              why: "An empty grid has no fresh oranges, which makes the answer zero straight away.",
              codeLine: 17,
            });
            return steps;
          }
          if (fresh === 0) {
            steps.push({
              ...board(stateAt(null)),
              title: "Check: no fresh oranges left",
              counters: counters(),
              legend: ["done", "dim"],
              happened: "There is nothing fresh to rot, so the queue drains instantly.",
              why: "Zero fresh oranges means zero minutes — the answer is already decided.",
              codeLine: 18,
            });
            steps.push({
              ...board(stateAt(null)),
              title: "Answer: 0 minutes",
              counters: [count("minutes elapsed", 0), count("answer", 0)],
              legend: ["done", "dim"],
              happened: "With no fresh oranges anywhere, the whole grid is finished at minute zero.",
              why: "The BFS loop never runs, so the counter stays at its starting value of 0.",
              codeLine: 18,
            });
            return steps;
          }

          let head = 0;
          while (head < queue.length && freshLeft > 0) {
            const levelEnd = queue.length;
            const newOnes = [];
            while (head < levelEnd) {
              const cur = queue[head++];
              const r = cur[0], c = cur[1];
              for (const d of DIRS) {
                const nr = r + d[0], nc = c + d[1];
                if (inside(R, C, nr, nc) && !rotd[nr][nc] && G.at(nr, nc) === "1") {
                  rotd[nr][nc] = true;
                  freshLeft--;
                  queue.push([nr, nc]);
                  newOnes.push([nr, nc]);
                }
              }
            }
            minutes++;
            const wave = new Set();
            newOnes.forEach((cell, i) => {
              wave.add(cell[0] + "," + cell[1]);
              steps.push({
                ...board(stateAt(cell)),
                title: `Minute ${minutes}: (${cell[0]},${cell[1]}) rots`,
                counters: counters().concat([count("new this minute", i + 1, newOnes.length)]),
                legend: ["read", "done", "idle", "dim"],
                happened: `A rotting neighbour turned (${cell[0]},${cell[1]}) rotted — it joins the queue so its own neighbours go next.`,
                why: "Only the previous wave's cells spread during this minute, which is what keeps one wave equal to one minute.",
                codeLine: 25,
              });
            });
            steps.push({
              ...board(stateAt(null, wave)),
              title: `Minute ${minutes} ends: ${plural(newOnes.length, "orange")} rotted`,
              counters: counters(),
              legend: ["read", "done", "idle", "dim"],
              happened: `The wave of minute ${minutes} is over; ${plural(freshLeft, "fresh orange")} still remain.`,
              why: "Counting one minute per wave is only safe because every wavefront is finished before the next one starts.",
              codeLine: 27,
            });
          }

          if (freshLeft > 0) {
            steps.push({
              ...board((r, c) => {
                if (rotd[r][c]) return "done";
                if (G.at(r, c) === "1") return "bad";
                return "dim";
              }),
              title: "Answer: some oranges can never rot",
              counters: [count("minutes elapsed", minutes), count("fresh left", freshLeft), count("answer", "impossible")],
              legend: ["done", "bad", "dim"],
              happened: `The queue emptied but ${plural(freshLeft, "fresh orange")} remain (marked red) — no rotted neighbour can reach them.`,
              why: "A leftover after the BFS proves those cells are cut off by walls; no amount of waiting will change that.",
              codeLine: 32,
            });
            return steps;
          }

          steps.push({
            ...board((r, c) => (rotd[r][c] ? "done" : "dim")),
            title: `Answer: ${plural(minutes, "minute")}`,
            counters: [count("minutes elapsed", minutes), count("answer", minutes)],
            legend: ["done", "dim"],
            happened: `Every orange is rotted after ${plural(minutes, "minute")} — the last wave just finished.`,
            why: "Each cell entered the queue exactly once, so the whole answer cost one linear sweep of the grid.",
            codeLine: 30,
          });
          return steps;
        },
      },
    ],
  });
  /* ============================================================
     6. Surrounded Regions
     ============================================================ */
  V.register({
    id: "surrounded-regions",
    title: "Surrounded Regions",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Capture every 'O' that a wall of 'X' has fully cut off from the border.",
    input: { label: "Grid rows: O = open, X = wall", default: "OOOOO OXXXO OXOXO OXXXO OOOOO", parse: "tokens" },
    approaches: [
      {
        name: "Mark from the Border Inward",
        complexity: "O(rows x cols) time, O(rows x cols) space",
        idea: [
          "An 'O' can only be captured if every path away from it is blocked — and any 'O' that can still reach the border is safe by definition. So start at the border instead of the middle: flood inward from every border 'O' and mark everything it touches as safe.",
          "After the border sweep, any 'O' still unmarked is provably cut off. Flip those to 'X', then put the safe markers back to 'O'.",
        ],
        problem: [
          "Attacking each interior region separately would need a second pass to decide which regions touch the border — seeding from the border folds that question into one flood.",
          "The mark-and-restore dance exists only to avoid overwriting information: flipping everything in one careless pass would lose which 'O's were the safe ones.",
        ],
        code: {
          c: `#include <stdio.h>

#define R 5
#define C 5

int dr[4] = {-1, 1, 0, 0};
int dc[4] = {0, 0, -1, 1};

/* flood every border-reachable 'O' into a safe marker 'S' */
void mark_safe(char g[R][C], int r, int c) {
    if (r < 0 || r >= R || c < 0 || c >= C || g[r][c] != 'O') return;
    g[r][c] = 'S';
    for (int d = 0; d < 4; d++) mark_safe(g, r + dr[d], c + dc[d]);
}

void solve(char g[R][C]) {
    for (int i = 0; i < R; i++) {          /* walk the whole border */
        mark_safe(g, i, 0); mark_safe(g, i, C - 1);
        mark_safe(g, 0, i); mark_safe(g, R - 1, i);
    }
    for (int r = 0; r < R; r++)
        for (int c = 0; c < C; c++) {
            if (g[r][c] == 'O') g[r][c] = 'X';       /* trapped: captured */
            else if (g[r][c] == 'S') g[r][c] = 'O';  /* safe: put back */
        }
}

int main(void) {
    char g[R][C] = {
        {'O','O','O','O','O'},
        {'O','X','X','X','O'},
        {'O','X','O','X','O'},
        {'O','X','X','X','O'},
        {'O','O','O','O','O'}
    };
    solve(g);
    for (int r = 0; r < R; r++) {
        for (int c = 0; c < C; c++) printf("%c ", g[r][c]);
        printf("\\n");
    }
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// flood every border-reachable 'O' into a safe marker 'S'
void markSafe(std::vector<std::string>& g, int r, int c) {
    if (r < 0 || r >= (int)g.size() || c < 0 || c >= (int)g[0].size() || g[r][c] != 'O') return;
    g[r][c] = 'S';
    markSafe(g, r + 1, c); markSafe(g, r - 1, c);
    markSafe(g, r, c + 1); markSafe(g, r, c - 1);
}

void solve(std::vector<std::string>& g) {
    int R = g.size(), C = g[0].size();
    for (int i = 0; i < R; i++) {          // left/right edges, then top/bottom
        markSafe(g, i, 0); markSafe(g, i, C - 1);
        markSafe(g, 0, i); markSafe(g, R - 1, i);
    }
    for (int r = 0; r < R; r++)
        for (int c = 0; c < C; c++) {
            if (g[r][c] == 'O') g[r][c] = 'X';        // trapped: captured
            else if (g[r][c] == 'S') g[r][c] = 'O';   // safe: put back
        }
}

int main() {
    std::vector<std::string> g{"OOOOO", "OXXXO", "OXOXO", "OXXXO", "OOOOO"};
    solve(g);
    for (auto& row : g) std::cout << row << '\\n';
}`,
        },
        steps(tokens) {
          const G = toGrid(tokens);
          const R = G.rows, C = G.cols;
          /* 'O' (either case) is open ground; every other char is wall */
          const open = (r, c) => G.at(r, c).toUpperCase() === "O";
          const safe = [];
          for (let r = 0; r < R; r++) safe.push(new Array(C).fill(false));
          let marked = 0, flipped = 0;

          const stateAt = (cur) => (r, c) => {
            if (cur && cur[0] === r && cur[1] === c) return "read";
            if (safe[r][c]) return "good";
            return open(r, c) ? "idle" : "dim";
          };
          const flipState = (cur) => (r, c) => {
            if (cur && cur[0] === r && cur[1] === c) return "read";
            if (safe[r][c]) return "good";
            return open(r, c) ? "bad" : "dim";
          };
          const board = (states) => ({
            kind: "grid", rows: R, cols: C,
            cells: cellsOf(R, C, states, (r, c) => (open(r, c) ? "O" : "X")),
          });
          const counters = () => [
            count("safe O's marked", marked),
            count("cells flipped", flipped),
          ];
          const steps = [];

          steps.push({
            ...board(stateAt(null)),
            title: "Set up: O = open, X = wall",
            counters: counters(),
            legend: ["read", "good", "bad", "dim", "idle"],
            happened: `A ${R} x ${C} grid; an 'O' that can still reach the border is safe, one fully boxed in by walls will be captured.`,
            why: "The border is the only place safety can be proved, so the marking will start there rather than in the middle.",
            codeLine: 16,
          });

          if (R > 0) {
            for (let r = 0; r < R; r++) {
              for (let c = 0; c < C; c++) {
                const onBorder = r === 0 || c === 0 || r === R - 1 || c === C - 1;
                if (!onBorder || !open(r, c) || safe[r][c]) continue;
                const stack = [[r, c]];
                while (stack.length) {
                  const cell = stack.pop();
                  const rr = cell[0], cc = cell[1];
                  if (!inside(R, C, rr, cc) || !open(rr, cc) || safe[rr][cc]) continue;
                  safe[rr][cc] = true;
                  marked++;
                  steps.push({
                    ...board(stateAt([rr, cc])),
                    title: `Mark (${rr},${cc}) safe - it can reach the border`,
                    counters: counters(),
                    legend: ["read", "good", "idle", "dim"],
                    happened: `(${rr},${cc}) is open ground still connected to the edge, so it joins the safe set (green).`,
                    why: "Anything reachable from the border is safe by definition — the flood claims the whole connected region at once.",
                    codeLine: 11,
                  });
                  for (const d of DIRS) stack.push([rr + d[0], cc + d[1]]);
                }
              }
            }
          }

          steps.push({
            ...board(stateAt(null)),
            title: `Border sweep done: ${plural(marked, "O")} safe`,
            counters: counters(),
            legend: ["good", "idle", "dim"],
            happened: R > 0
              ? `Every border-reachable 'O' has been marked green; whatever 'O's remain unmarked are cut off completely.`
              : "No grid rows were given, so there was nothing to sweep.",
            why: "The unmarked leftovers cannot reach any border — by construction there is no escape path left for them.",
            codeLine: 20,
          });

          flipped = 0;
          for (let r = 0; r < R; r++)
            for (let c = 0; c < C; c++)
              if (open(r, c) && !safe[r][c]) flipped++;
          steps.push({
            ...board(flipState(null)),
            title: flipped > 0 ? `Flip ${plural(flipped, "trapped O")} to X` : "Nothing trapped: no O to flip",
            counters: counters().concat([count("answer", flipped)]),
            legend: ["good", "bad", "dim"],
            happened: flipped > 0
              ? `Each unmarked 'O' (red) is surrounded on every side and becomes an 'X'.`
              : "Every 'O' could reach the border, so the picture does not change at all.",
            why: "Only unmarked cells are flipped — the green marks are what keep the safe 'O's out of this pass.",
            codeLine: 23,
          });

          steps.push({
            ...board(flipState(null)),
            title: "Put the safe markers back to O",
            counters: counters(),
            legend: ["good", "bad", "dim"],
            happened: "The green marker cells read as plain 'O' again — they were never truly changed, only tagged.",
            why: "The temporary marker existed so the flip pass could tell trapped cells from safe ones.",
            codeLine: 24,
          });

          steps.push({
            ...board(flipState(null)),
            title: `Answer: ${plural(marked, "O")} kept, ${plural(flipped, "cell")} captured`,
            counters: [count("safe O's kept", marked), count("cells flipped", flipped), count("answer", flipped)],
            legend: ["good", "bad", "dim"],
            happened: flipped > 0
              ? `${plural(marked, "border-connected O")} survived; ${plural(flipped, "boxed-in O")} became 'X'.`
              : "No 'O' was boxed in, so the whole grid is untouched.",
            why: "One border flood plus one flip pass solves the whole board in linear time without ever tracing a path twice.",
            codeLine: 25,
          });
          return steps;
        },
      },
    ],
  });
/* END-OF-MODULE */
})();
