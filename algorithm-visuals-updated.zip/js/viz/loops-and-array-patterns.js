/* ============================================================
   DSA Visuals — Loop Analysis and Array Patterns
   Original visualisations for counting loop work and for the
   classic one-pass / two-pointer array problems.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count, grid } = window.H;
  const V = window.VIZ;

  /* small local conveniences */
  function single(label, v, state, tag) {
    return { label, cells: [{ v, state, tag }] };
  }
  function seenStates(n, i) {
    const s = [];
    for (let k = 0; k < n; k++) s.push(k < i ? "done" : k === i ? "read" : "idle");
    return s;
  }
  function joinList(a) {
    return a.length ? a.join(", ") : "empty";
  }

  /* ---------------------------------------------------------- */
  V.register({
    id: "analyze-a-single-loop",
    title: "Analyze a Single Loop",
    category: "Loop Analysis",
    difficulty: "Beginner",
    description: "Walk one loop over a list and count the work it does as the input grows.",
    input: { label: "The numbers", default: "6, 4, 9, 2, 7, 5", parse: "ints" },
    approaches: [
      {
        name: "One Pass, Three Units per Item",
        complexity: "O(n) time, O(1) space",
        idea: [
          "A single loop visits every position once. Inside the body it reads the current value, folds it into a running total, then moves the index and tests the bound.",
          "Treat each of those three actions as one unit of work. The loop therefore costs about 3n units, plus one final bound test that fails and ends the loop.",
        ],
        problem: [
          "Counting units is a model, not a law: on real hardware a read and an addition can cost very different amounts. The value of the model is the shape of the growth, not the exact number.",
        ],
        code: {
          c: `#include <stdio.h>

/* one visit: read a value, add it, move on */
int total_work(const int *a, int n) {
    int total = 0;
    for (int i = 0; i < n; i++) {
        total += a[i];
    }
    return total;
}

int main(void) {
    int a[] = {6, 4, 9, 2, 7, 5};
    printf("%d\\n", total_work(a, 6));
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// each visit does the same small amount of work
int totalWork(const std::vector<int>& a) {
    int total = 0;
    for (int x : a) {
        total += x;
    }
    return total;
}

int main() {
    std::vector<int> a{6, 4, 9, 2, 7, 5};
    std::cout << totalWork(a) << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const UNITS = 3;
          const LEG = ["read", "done", "active", "result", "idle"];
          const steps = [];
          const visit = (on) => ({
            label: "one visit",
            cells: [
              { v: "read", state: on ? "active" : "idle", tag: "1 unit" },
              { v: "add", state: on ? "active" : "idle", tag: "1 unit" },
              { v: "move", state: on ? "active" : "idle", tag: "1 unit" },
            ],
          });
          const meter = (ops, visits) => ({
            label: "work meter",
            cells: [
              { v: ops, state: "result", tag: "operations" },
              { v: `${visits}/${n}`, state: visits === n ? "done" : "active", tag: "visits" },
            ],
          });

          steps.push({
            title: `One loop over ${n} ${n === 1 ? "number" : "numbers"}`,
            tracks: [track("the numbers", nums, fill(n, "idle")), visit(false), meter(0, 0)],
            counters: [count("iterations", 0, n), count("operations", 0)],
            legend: LEG,
            happened: `The row holds ${joinList(nums)}. The loop has not run yet, so the work meter is at zero.`,
            why: "A single loop has one obvious cost: the number of times its body runs. The next question is what each visit pays.",
            codeLine: 5,
          });

          steps.push({
            title: "One visit costs three units",
            tracks: [track("the numbers", nums, fill(n, "idle")), visit(true), meter(0, 0)],
            counters: [count("iterations", 0, n), count("operations", 0), count("units per visit", UNITS)],
            legend: LEG,
            happened: "Inside the body the loop reads the current value, adds it to the total, then advances the index and tests the bound.",
            why: "Every visit performs the same three actions, so the total is simply the number of visits multiplied by three.",
            codeLine: 6,
          });

          for (let i = 0; i < n; i++) {
            const ops = (i + 1) * UNITS;
            steps.push({
              title: `Visit ${i + 1}: read ${nums[i]} → ${ops} units`,
              tracks: [
                track("the numbers", nums, seenStates(n, i)),
                visit(true),
                meter(ops, i + 1),
              ],
              counters: [count("iterations", i + 1, n), count("operations", ops)],
              legend: LEG,
              happened: `Iteration ${i + 1} of ${n} reads ${nums[i]}, adds it, and moves on. The meter climbs by three to ${ops}.`,
              why: "The value being read never changes how much work the body does — one visit always costs the same three units.",
              codeLine: 6,
            });
          }

          const total = UNITS * n;
          steps.push({
            title: `The last bound test fails → ${total + 1} units`,
            tracks: [
              track("the numbers", nums, fill(n, "done")),
              visit(false),
              meter(total + 1, n),
            ],
            counters: [count("iterations", n, n), count("operations", total + 1), count("bound tests", n + 1)],
            legend: LEG,
            happened: `After visit ${n} the index reaches ${n}; the condition i < n is false, so the loop stops. That check is one extra unit.`,
            why: `The failure test adds only 1 to ${total}. Constants like that are ignored in O() notation, leaving O(n).`,
            codeLine: 5,
          });

          steps.push({
            title: `Double the list: ${n} → ${2 * n} items`,
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              {
                label: "work grows in a line",
                cells: [
                  { v: `${n} items`, state: "done", tag: `${total + 1} units` },
                  { v: `${2 * n} items`, state: "active", tag: `${2 * total + 1} units` },
                ],
              },
            ],
            counters: [count("iterations", n, n), count("operations", total + 1), count("cost class", "O(n)")],
            legend: ["done", "active", "dim"],
            happened: `Twice as many numbers means twice as many visits: ${n} items cost ${total + 1} units, ${2 * n} items cost ${2 * total + 1}.`,
            why: "When the input doubles and the work doubles with it, the growth is a straight line — O(n).",
            codeLine: 5,
          });

          steps.push({
            title: `Answer: O(n) — ${n} visits, ${total + 1} units`,
            tracks: [
              track("the numbers", nums, fill(n, "result")),
              single("work meter", total + 1, "result", "total operations"),
            ],
            counters: [count("iterations", n, n), count("operations", total + 1), count("answer", "O(n)")],
            legend: ["result"],
            happened: `Each of the ${n} numbers was visited once. The final count is ${total} body units plus the closing test.`,
            why: "A fixed cost per item, repeated n times, is linear time. No amount of clever code can avoid reading every number.",
            codeLine: 8,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "analyze-nested-independent-loops",
    title: "Analyze Nested Independent Loops",
    category: "Loop Analysis",
    difficulty: "Intermediate",
    description: "Two nested loops whose inner length never changes, so the work is a full n × n square.",
    input: { label: "The numbers", default: "3, 5, 2, 4", parse: "ints" },
    approaches: [
      {
        name: "A Fixed Inner Sweep",
        complexity: "O(n²) time, O(1) space",
        idea: [
          "The outer loop takes each position i in turn. For every i, the inner loop performs a fixed n steps, regardless of what i is or what the values are.",
          "The rows are all the same length, so the work is the area of an n by n square: n · n = n² inner steps.",
        ],
        problem: [
          "The area grows much faster than the side: 10 numbers need 100 inner steps, 40 numbers need 1,600. Even though each step is tiny, the total dominates quickly.",
        ],
        code: {
          c: `#include <stdio.h>

/* n outer rounds, each doing a fixed n inner steps */
int count_pairs(const int *a, int n) {
    int work = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            work++;
        }
    }
    return work;
}

int main(void) {
    int a[] = {3, 5, 2, 4};
    printf("%d\\n", count_pairs(a, 4));
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// the inner bound is n for every outer round
int countPairs(const std::vector<int>& a) {
    int n = (int)a.size(), work = 0;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            ++work;
        }
    }
    return work;
}

int main() {
    std::vector<int> a{3, 5, 2, 4};
    std::cout << countPairs(a) << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const total = n * n;
          const LEG = ["read", "done", "idle"];
          const steps = [];
          const heads = Array.from({ length: n }, (_, i) => String(i));
          const square = (activeRow) =>
            grid(n, n, (r, c) => ({
              v: "1",
              state: r < activeRow ? "done" : r === activeRow ? "read" : "idle",
            }));

          steps.push({
            title: `Two nested loops, ${n} × ${n} possible pairs`,
            kind: "grid",
            rows: n,
            cols: n,
            rowHeads: heads,
            colHeads: heads,
            cells: square(-1),
            label: "each square is one inner step",
            counters: [count("outer rounds", 0, n), count("inner steps", 0, total)],
            legend: LEG,
            happened: `The input has ${n} numbers. The outer loop will run ${n} times and the inner loop will run ${n} times for each of those rounds.`,
            why: "When the inner length is fixed in advance, the outer and inner choices are independent — multiply them.",
            codeLine: 5,
          });

          steps.push({
            title: "The inner loop never looks at i",
            kind: "grid",
            rows: n,
            cols: n,
            rowHeads: heads,
            colHeads: heads,
            cells: grid(n, n, (r, c) => ({ v: "1", state: r === 0 ? "read" : "idle" })),
            label: "row 0 is highlighted; every row will be just as long",
            counters: [count("outer rounds", 0, n), count("inner steps", 0, total)],
            legend: LEG,
            happened: `For i = 0 the inner loop plans all ${n} columns. If i changed to ${n - 1}, the inner loop would still plan ${n} columns.`,
            why: "Nothing in the inner condition refers to i, so no row is shorter than another. Every round contributes the same amount.",
            codeLine: 6,
          });

          for (let i = 0; i < n; i++) {
            const done = (i + 1) * n;
            steps.push({
              title: `Outer round ${i + 1}: ${n} steps → ${done} total`,
              kind: "grid",
              rows: n,
              cols: n,
              rowHeads: heads,
              colHeads: heads,
              cells: square(i),
              label: `row ${i} just swept all ${n} columns`,
              counters: [count("outer rounds", i + 1, n), count("inner steps", done, total)],
              legend: LEG,
              happened: `Round ${i} finishes ${n} inner steps. The running total is now ${done} out of ${total}.`,
              why: "Each completed row adds exactly n to the counter — identical rows, identical cost.",
              codeLine: 7,
            });
          }

          steps.push({
            title: `Both loops finish: ${n} × ${n} = ${total}`,
            kind: "grid",
            rows: n,
            cols: n,
            rowHeads: heads,
            colHeads: heads,
            cells: square(n),
            label: "the full square has been visited",
            counters: [count("outer rounds", n, n), count("inner steps", total, total)],
            legend: LEG,
            happened: `The outer loop made ${n} rounds and every round made ${n} inner steps, so all ${total} squares are done.`,
            why: "The cost is the area of the square, not the length of one side. That area is n².",
            codeLine: 10,
          });

          steps.push({
            title: `Double n → four times the work`,
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              {
                label: "square growth",
                cells: [
                  { v: `${n} items`, state: "done", tag: `${total} inner steps` },
                  { v: `${2 * n} items`, state: "active", tag: `${4 * total} inner steps` },
                ],
              },
            ],
            counters: [count("inner steps", total), count("cost class", "O(n²)")],
            legend: ["done", "active", "dim"],
            happened: `With ${n} items the loops do ${total} steps. With ${2 * n} items they would do ${4 * total}.`,
            why: "Doubling the side of a square multiplies its area by four — the signature of quadratic growth.",
            codeLine: 7,
          });

          steps.push({
            title: `Answer: O(n²) — ${total} inner steps`,
            tracks: [
              track("the numbers", nums, fill(n, "result")),
              single("inner steps", total, "result", `${n} × ${n}`),
            ],
            counters: [count("outer rounds", n, n), count("inner steps", total, total), count("answer", "O(n²)")],
            legend: ["result"],
            happened: `The two independent loops produced ${total} inner steps for ${n} numbers.`,
            why: "Independent nested loops multiply their counts. The square is the reason this pattern is called quadratic.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "analyze-dependent-nested-loops",
    title: "Analyze Dependent Nested Loops",
    category: "Loop Analysis",
    difficulty: "Intermediate",
    description: "The inner loop stops at the outer index, tracing a triangle of work instead of a square.",
    input: { label: "The numbers", default: "5, 3, 8, 2, 6", parse: "ints" },
    approaches: [
      {
        name: "Rows That Grow by One",
        complexity: "O(n²) time, O(1) space",
        idea: [
          "The outer index i sets the row and also the last column of the inner loop: j runs from 0 to i, which is i + 1 steps.",
          "The row lengths are 1, 2, 3, …, n. Their total is n(n + 1)/2 — half of a full square, but still quadratic.",
        ],
        problem: [
          "A triangle is only half the square. Doubling n still roughly quadruples the work, so the O(n²) label does not go away just because the constant is smaller.",
        ],
        code: {
          c: `#include <stdio.h>

/* row i does i + 1 inner steps */
int triangle_work(const int *a, int n) {
    int work = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j <= i; j++) {
            work++;
        }
    }
    return work;
}

int main(void) {
    int a[] = {5, 3, 8, 2, 6};
    printf("%d\\n", triangle_work(a, 5));
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// row i gets one more step than the row above it
int triangleWork(const std::vector<int>& a) {
    int n = (int)a.size(), work = 0;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j <= i; ++j) {
            ++work;
        }
    }
    return work;
}

int main() {
    std::vector<int> a{5, 3, 8, 2, 6};
    std::cout << triangleWork(a) << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const total = (n * (n + 1)) / 2;
          const LEG = ["read", "done", "idle", "dim"];
          const steps = [];
          const heads = Array.from({ length: n }, (_, i) => String(i));
          const triangle = (activeRow) =>
            grid(n, n, (r, c) => {
              if (c > r) return { v: "·", state: "dim" };
              return { v: "1", state: r < activeRow ? "done" : r === activeRow ? "read" : "idle" };
            });

          steps.push({
            title: `A triangle of ${total} steps over ${n} rows`,
            kind: "grid",
            rows: n,
            cols: n,
            rowHeads: heads,
            colHeads: heads,
            cells: triangle(-1),
            label: "only the lower triangle is ever visited",
            counters: [count("outer rounds", 0, n), count("inner steps", 0, total)],
            legend: LEG,
            happened: `The input has ${n} numbers. The dots above the diagonal are positions the inner loop will never reach.`,
            why: "The inner bound depends on the outer index, so the work is not a rectangle. Its shape is a triangle.",
            codeLine: 5,
          });

          steps.push({
            title: "Row i asks for exactly i + 1 steps",
            kind: "grid",
            rows: n,
            cols: n,
            rowHeads: heads,
            colHeads: heads,
            cells: grid(n, n, (r, c) => {
              if (c > r) return { v: "·", state: "dim" };
              return { v: "1", state: r === 0 ? "read" : "idle" };
            }),
            label: "row 0 has one cell; row 1 will have two; and so on",
            counters: [count("outer rounds", 0, n), count("inner steps", 0, total)],
            legend: LEG,
            happened: "For i = 0 the inner loop runs once. For i = 1 it would run twice, and for i = n - 1 it runs n times.",
            why: "The condition j <= i makes the row length depend on the round — this is what separates a dependent nest from an independent one.",
            codeLine: 6,
          });

          for (let i = 0; i < n; i++) {
            const done = ((i + 1) * (i + 2)) / 2;
            steps.push({
              title: `Row ${i}: ${i + 1} steps → ${done} total`,
              kind: "grid",
              rows: n,
              cols: n,
              rowHeads: heads,
              colHeads: heads,
              cells: triangle(i),
              label: `row ${i} runs ${i + 1} inner steps`,
              counters: [count("outer rounds", i + 1, n), count("inner steps", done, total)],
              legend: LEG,
              happened: `The inner loop for i = ${i} stops at j = ${i}, so it performs ${i + 1} steps. The triangle now holds ${done} of ${total}.`,
              why: "Every new row is one step longer than the row above, so the running total grows a little faster each round.",
              codeLine: 7,
            });
          }

          steps.push({
            title: `The triangle is complete: ${total} steps`,
            kind: "grid",
            rows: n,
            cols: n,
            rowHeads: heads,
            colHeads: heads,
            cells: triangle(n),
            label: `${n} rows with lengths 1 + 2 + … + ${n}`,
            counters: [count("outer rounds", n, n), count("inner steps", total, total)],
            legend: LEG,
            happened: `All ${n} rows finished. Their lengths add to ${total}, which is n(n + 1)/2 for n = ${n}.`,
            why: "The triangle fills half of the n by n square (plus a thin diagonal), so its area still grows like n².",
            codeLine: 10,
          });

          steps.push({
            title: `Double n → almost four times the work`,
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              {
                label: "triangle growth",
                cells: [
                  { v: `${n} rows`, state: "done", tag: `${total} steps` },
                  { v: `${2 * n} rows`, state: "active", tag: `${(2 * n) * (2 * n + 1) / 2} steps` },
                ],
              },
            ],
            counters: [count("inner steps", total), count("cost class", "O(n²)")],
            legend: ["done", "active", "dim"],
            happened: `With ${n} numbers the triangle holds ${total} steps. With ${2 * n} numbers it would hold ${(2 * n) * (2 * n + 1) / 2}.`,
            why: "Half of a square is still a square in growth terms: doubling the side multiplies the area by about four.",
            codeLine: 7,
          });

          steps.push({
            title: `Answer: O(n²) — ${total} steps, about half of n²`,
            tracks: [
              track("the numbers", nums, fill(n, "result")),
              single("inner steps", total, "result", "n(n + 1)/2"),
            ],
            counters: [count("outer rounds", n, n), count("inner steps", total, total), count("answer", "O(n²)")],
            legend: ["result"],
            happened: `The dependent rows did ${total} inner steps for ${n} numbers.`,
            why: "The exact count has a smaller constant than a full square, but the leading term is still n².",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "analyze-a-halving-loop",
    title: "Analyze a Halving Loop",
    category: "Loop Analysis",
    difficulty: "Beginner",
    description: "Repeatedly cut a value in half and watch the pass count grow logarithmically.",
    input: { label: "Starting value", default: "64", parse: "int" },
    approaches: [
      {
        name: "Halve Until the Value Is One",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "Start with a value x. While x is greater than 1, replace x with the integer floor of x / 2 and count one pass.",
          "Each pass discards roughly half of the remaining value, so the number of passes is the number of times n can be halved before reaching 1 — about log₂ n.",
        ],
        problem: [
          "The loop is extremely fast, but the exact pass count wobbles for values that are not powers of two because integer division floors. The logarithmic bound is what stays reliable.",
        ],
        code: {
          c: `#include <stdio.h>

/* how many times can x be halved before reaching 1? */
int halvings(int x) {
    int steps = 0;
    while (x > 1) {
        x = x / 2;
        steps++;
    }
    return steps;
}

int main(void) {
    printf("%d\\n", halvings(64));
    return 0;
}`,
          cpp: `#include <iostream>

// count the integer halvings until the value is at most 1
int halvings(int x) {
    int steps = 0;
    while (x > 1) {
        x /= 2;
        ++steps;
    }
    return steps;
}

int main() {
    std::cout << halvings(64) << '\\n';
}`,
        },
        steps(start) {
          const LEG = ["read", "done", "result", "dim"];
          const steps = [];
          const trail = [start];
          const trailTrack = () => {
            const vals = trail.length <= 12 ? trail.slice() : trail.slice(0, 2).concat(["…"], trail.slice(-9));
            const states = vals.map((v, i) => {
              if (v === "…") return "dim";
              return i === vals.length - 1 ? "result" : "done";
            });
            return track("halving trail", vals, states);
          };
          const valueTrack = (x, k) => single("the value", x, "result", `${k} ${k === 1 ? "halving" : "halvings"}`);

          if (start <= 1) {
            steps.push({
              title: `Start at ${start}`,
              tracks: [valueTrack(start, 0), trailTrack()],
              counters: [count("halvings", 0), count("value", start)],
              legend: LEG,
              happened: `The value is ${start}. The loop will only run while the value is greater than 1.`,
              why: "The loop's guard is the whole stopping rule: once the value is at most 1, there is nothing left to split.",
              codeLine: 5,
            });
            steps.push({
              title: `${start} is not above 1 — the loop is skipped`,
              tracks: [valueTrack(start, 0), trailTrack()],
              counters: [count("halvings", 0), count("value", start), count("condition checks", 1)],
              legend: LEG,
              happened: `The condition x > 1 is false on the very first test, so the body never runs.`,
              why: "Zero passes is the correct answer here: the starting value is already small enough.",
              codeLine: 5,
            });
            steps.push({
              title: "No halving trail to walk",
              tracks: [valueTrack(start, 0), trailTrack()],
              counters: [count("halvings", 0), count("value", start)],
              legend: LEG,
              happened: `The trail contains only the starting value ${start}; no new entries were produced.`,
              why: "The cost of the loop is zero, which is even better than logarithmic. The O(log n) label describes the worst case for larger n.",
              codeLine: 9,
            });
            steps.push({
              title: "Each doubling of n adds one pass",
              tracks: [
                {
                  label: "growth for powers of two",
                  cells: [
                    { v: "8", state: "done", tag: "3 halvings" },
                    { v: "16", state: "done", tag: "4 halvings" },
                    { v: "32", state: "done", tag: "5 halvings" },
                    { v: "64", state: "active", tag: "6 halvings" },
                  ],
                },
              ],
              counters: [count("halvings", 0), count("cost class", "O(log n)")],
              legend: ["done", "active"],
              happened: "The work rises by one each time the starting value doubles, not by a constant amount per value.",
              why: "A relation where doubling the input adds one step is the definition of logarithmic growth.",
              codeLine: 5,
            });
            steps.push({
              title: `Answer: 0 halvings for ${start} — O(log n) worst case`,
              tracks: [single("the value", start, "result", "already ≤ 1"), trailTrack()],
              counters: [count("halvings", 0), count("answer", "0 halvings")],
              legend: LEG,
              happened: `The loop never entered, so the pass count is 0.`,
              why: "The general bound remains O(log n): even if this particular input is trivial, doubling larger values still adds only one pass.",
              codeLine: 9,
            });
            return steps;
          }

          steps.push({
            title: `Start at ${start} and halve it`,
            tracks: [valueTrack(start, 0), trailTrack()],
            counters: [count("halvings", 0), count("value", start)],
            legend: LEG,
            happened: `The value starts at ${start}. Each pass will replace it with floor(value / 2).`,
            why: "Halving is a shrinking process: the remaining value drops rapidly, so the loop cannot run for long.",
            codeLine: 3,
          });

          steps.push({
            title: `${start} is above 1, so the loop may run`,
            tracks: [valueTrack(start, 0), trailTrack()],
            counters: [count("halvings", 0), count("value", start), count("condition checks", 1)],
            legend: LEG,
            happened: `The first test x > 1 succeeds. The body is allowed to divide ${start} by two.`,
            why: "One successful test is not yet a halving; the work counter only moves when the body runs.",
            codeLine: 5,
          });

          let x = start, k = 0;
          while (x > 1) {
            const prev = x;
            x = Math.floor(x / 2);
            k++;
            trail.push(x);
            steps.push({
              title: `Halving ${k}: ${prev} → ${x}`,
              tracks: [valueTrack(x, k), trailTrack()],
              counters: [count("halvings", k), count("value", x)],
              legend: LEG,
              happened: `Pass ${k} replaces ${prev} with ${x}, the floor of half of ${prev}.`,
              why: "The new value is at most half the old one, so the remaining distance to 1 shrinks by a constant factor every pass.",
              codeLine: 6,
            });
          }

          steps.push({
            title: `The value is ${x}, so the loop stops`,
            tracks: [valueTrack(x, k), trailTrack()],
            counters: [count("halvings", k), count("value", x), count("condition checks", k + 1)],
            legend: LEG,
            happened: `After ${k} halvings the value is ${x}. The next guard test fails and the loop ends.`,
            why: `There is one extra condition test (${k + 1} in total), but that constant is ignored next to the number of halvings.`,
            codeLine: 5,
          });

          steps.push({
            title: "Each doubling of n adds one pass",
            tracks: [
              trailTrack(),
              {
                label: "growth for powers of two",
                cells: [
                  { v: "8", state: "done", tag: "3 halvings" },
                  { v: "16", state: "done", tag: "4 halvings" },
                  { v: "32", state: "done", tag: "5 halvings" },
                  { v: "64", state: "active", tag: "6 halvings" },
                ],
              },
            ],
            counters: [count("halvings", k), count("cost class", "O(log n)")],
            legend: ["done", "active", "result", "dim"],
            happened: `The trail for ${start} needed ${k} halvings. Doubling the starting value would add at most one more.`,
            why: "That slow growth is why halving loops stay cheap even for enormous values.",
            codeLine: 5,
          });

          steps.push({
            title: `Answer: ${k} halvings — O(log n)`,
            tracks: [
              single("the value", x, "result", "stopped at ≤ 1"),
              trailTrack(),
            ],
            counters: [count("halvings", k), count("answer", `${k} halvings`)],
            legend: LEG,
            happened: `Starting from ${start}, the loop ran ${k} times before the value became ${x}.`,
            why: "A logarithmic number of passes is the whole point: doubling the value barely changes the work.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "analyze-two-pointer-traversal",
    title: "Analyze Two Pointer Traversal",
    category: "Loop Analysis",
    difficulty: "Intermediate",
    description: "One pointer at each end walks inwards, showing why a two-pointer scan stays linear.",
    input: { label: "The numbers", default: "4, 9, 2, 7, 5, 1", parse: "ints" },
    approaches: [
      {
        name: "Close the Gap from Both Ends",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Place lo at the first index and hi at the last. While lo is strictly left of hi, inspect the pair at the two ends, then move lo right and hi left.",
          "Every round removes two positions from the active window. There are about n/2 rounds, and each position is touched at most once.",
        ],
        problem: [
          "The two pointers only help when moving one of them can safely discard part of the row. If a problem needs random access to the whole row each round, this pattern does not apply.",
        ],
        code: {
          c: `#include <stdio.h>

/* pair the ends, then close the gap by two */
int pair_rounds(const int *a, int n) {
    int lo = 0, hi = n - 1, rounds = 0;
    while (lo < hi) {
        rounds++;
        lo++;
        hi--;
    }
    return rounds;
}

int main(void) {
    int a[] = {4, 9, 2, 7, 5, 1};
    printf("%d\\n", pair_rounds(a, 6));
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// each round retires both ends of the remaining window
int pairRounds(const std::vector<int>& a) {
    int lo = 0, hi = (int)a.size() - 1, rounds = 0;
    while (lo < hi) {
        ++rounds;
        ++lo;
        --hi;
    }
    return rounds;
}

int main() {
    std::vector<int> a{4, 9, 2, 7, 5, 1};
    std::cout << pairRounds(a) << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const totalRounds = Math.floor(n / 2);
          const LEG = ["read", "done", "result", "idle"];
          const steps = [];
          const ptr = (lo, hi) => ({
            label: "pointers",
            cells: [
              { v: `lo = ${lo}`, state: lo < hi ? "read" : "done", tag: "left" },
              { v: `hi = ${hi}`, state: lo < hi ? "read" : "done", tag: "right" },
            ],
          });
          const numberStates = (lo, hi) =>
            nums.map((_, k) => (k < lo || k > hi ? "done" : k === lo || k === hi ? "read" : "idle"));

          steps.push({
            title: `Pointers at ${nums[0]} and ${nums[n - 1]}`,
            tracks: [track("the numbers", nums, numberStates(0, n - 1)), ptr(0, n - 1)],
            counters: [count("rounds", 0, totalRounds), count("pointer moves", 0), count("gap", n - 1)],
            legend: LEG,
            happened: `lo starts at index 0 (${nums[0]}) and hi at index ${n - 1} (${nums[n - 1]}). The active window is the whole row.`,
            why: "Two pointers describe a window with a left edge and a right edge. The algorithm's cost is how fast that window shrinks.",
            codeLine: 4,
          });

          steps.push({
            title: n > 1 ? "A round inspects both ends" : "The pointers already meet",
            tracks: [track("the numbers", nums, numberStates(0, n - 1)), ptr(0, n - 1)],
            counters: [count("rounds", 0, totalRounds), count("pointer moves", 0), count("gap", n - 1)],
            legend: LEG,
            happened: n > 1
              ? `Because lo < hi, a round is allowed. It will look at ${nums[0]} and ${nums[n - 1]}, then close the gap by two.`
              : "With a single number lo and hi are the same index, so lo < hi is already false and no round can run.",
            why: n > 1
              ? "The guard is strict: when the pointers meet or cross, there is no pair left to inspect."
              : "A one-element window contains no pair, which is why the loop must skip immediately.",
            codeLine: 5,
          });

          let lo = 0, hi = n - 1, rounds = 0;
          while (lo < hi) {
            rounds++;
            const a = nums[lo], b = nums[hi];
            steps.push({
              title: `Round ${rounds}: inspect ${a} and ${b}`,
              tracks: [track("the numbers", nums, numberStates(lo, hi)), ptr(lo, hi)],
              counters: [count("rounds", rounds, totalRounds), count("pointer moves", 2 * rounds), count("gap", hi - lo)],
              legend: LEG,
              happened: `The ends at indices ${lo} and ${hi} are inspected. Then lo steps right and hi steps left.`,
              why: `Two positions leave the window this round, so the gap drops from ${hi - lo + 2} to ${hi - lo}.`,
              codeLine: 6,
            });
            lo++;
            hi--;
          }

          steps.push({
            title: "No position is ever visited twice",
            tracks: [
              track("the numbers", nums, nums.map((_, k) => (n % 2 === 1 && k === Math.floor(n / 2) ? "result" : "done"))),
              ptr(lo, hi),
            ],
            counters: [count("rounds", rounds, totalRounds), count("pointer moves", 2 * rounds), count("positions retired", Math.min(n, 2 * rounds))],
            legend: LEG,
            happened: n % 2 === 1
              ? `The middle position ${Math.floor(n / 2)} was never paired, but it still lies inside the original row once.`
              : "Every position belonged to exactly one pair, and each pointer visited its own side once.",
            why: "The total work is the number of pointer moves, which is at most n. A leftover middle cell adds only a constant.",
            codeLine: 6,
          });

          steps.push({
            title: "The pointers meet — the walk stops",
            tracks: [track("the numbers", nums, fill(n, "done")), ptr(lo, hi)],
            counters: [count("rounds", rounds, totalRounds), count("pointer moves", 2 * rounds), count("gap", hi - lo)],
            legend: LEG,
            happened: `After ${rounds} rounds lo is ${lo} and hi is ${hi}; the condition lo < hi fails.`,
            why: "Each round did a constant amount of work, so the total is proportional to the number of rounds — linear.",
            codeLine: 5,
          });

          steps.push({
            title: "Double the row, double the rounds",
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              {
                label: "rounds grow in a line",
                cells: [
                  { v: `${n} items`, state: "done", tag: `${totalRounds} rounds` },
                  { v: `${2 * n} items`, state: "active", tag: `${Math.floor((2 * n) / 2)} rounds` },
                ],
              },
            ],
            counters: [count("rounds", totalRounds), count("cost class", "O(n)")],
            legend: ["done", "active", "dim"],
            happened: `With ${n} numbers there are ${totalRounds} rounds. With ${2 * n} numbers there would be ${Math.floor((2 * n) / 2)}.`,
            why: "Both the rounds and the pointer moves scale directly with n, so the traversal is O(n).",
            codeLine: 5,
          });

          steps.push({
            title: `Answer: O(n) — ${rounds} rounds, ${2 * rounds} moves`,
            tracks: [
              track("the numbers", nums, fill(n, "result")),
              single("pointer moves", 2 * rounds, "result", `n = ${n}`),
            ],
            counters: [count("rounds", rounds), count("pointer moves", 2 * rounds), count("answer", "O(n)")],
            legend: ["result"],
            happened: `The two pointers retired the whole row in ${rounds} rounds.`,
            why: "Adding one item at most adds one more pointer move, which is exactly linear growth.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "two-sum",
    title: "Two Sum",
    category: "Array Patterns",
    difficulty: "Beginner",
    description: "Find two numbers that add up to a target — try every pair, or remember complements.",
    input: { label: "Target, then the numbers", default: "9, 2, 7, 11, 15", parse: "ints" },
    approaches: [
      {
        name: "Check Every Pair",
        complexity: "O(n²) time, O(1) space",
        idea: [
          "Fix a left index i, then sweep every right index j after it. If the two values add to the target, the answer is the pair of indices.",
          "Starting j at i + 1 means each pair is tested exactly once — no pair is repeated and none is skipped.",
        ],
        problem: [
          "The number of checks is n(n-1)/2, which grows quadratically: 10 numbers cost 45 checks, 40 numbers cost 780. That is why a hash table exists.",
        ],
        code: {
          c: `#include <stdio.h>

/* find two positions whose values add to target */
void two_sum(const int *a, int n, int target) {
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (a[i] + a[j] == target) {
                printf("indices %d and %d\\n", i, j);
                return;
            }
        }
    }
    printf("no pair\\n");
}

int main(void) {
    int a[] = {2, 7, 11, 15};
    two_sum(a, 4, 9);
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// every pair, checked once, stops at the first hit
std::pair<int,int> twoSum(const std::vector<int>& a, int target) {
    for (int i = 0; i < (int)a.size(); ++i) {
        for (int j = i + 1; j < (int)a.size(); ++j) {
            if (a[i] + a[j] == target)
                return {i, j};
        }
    }
    return {-1, -1};
}

int main() {
    auto [i, j] = twoSum({2, 7, 11, 15}, 9);
    std::cout << i << " " << j << '\\n';
}`,
        },
        steps(parsed) {
          const target = parsed[0];
          const nums = parsed.slice(1);
          const n = nums.length;
          const totalPairs = (n * (n - 1)) / 2;
          const LEG = ["read", "compare", "good", "bad", "done", "result", "idle"];
          const steps = [];
          const targetTrack = () => single("target", target, "result", "wanted sum");
          const pairTrack = (i, j, state) => ({
            label: "the pair",
            cells: i == null
              ? [{ v: "—", state: "idle", empty: true }]
              : [
                  { v: nums[i], state, tag: `index ${i}` },
                  { v: "+", state: "idle" },
                  { v: nums[j], state, tag: `index ${j}` },
                ],
          });
          const growth = () => ({
            label: "pair growth",
            cells: [
              { v: `${n} numbers`, state: "done", tag: `${totalPairs} pairs` },
              { v: `${2 * n} numbers`, state: "active", tag: `${(2 * n * (2 * n - 1)) / 2} pairs` },
            ],
          });

          steps.push({
            title: `Look for two numbers that add to ${target}`,
            tracks: [targetTrack(), track("the numbers", nums, fill(n, "idle"))],
            counters: [count("target", target), count("numbers to check", n), count("pairs checked", 0, totalPairs)],
            legend: LEG,
            happened: `The numbers are ${joinList(nums)}. The target to hit is ${target}, and nothing has been checked yet.`,
            why: "A pair means two different positions whose values sum to the target, so the pair's indices matter as much as its values.",
            codeLine: 4,
          });

          steps.push({
            title: "Plan: fix the left index, sweep the right one",
            tracks: [targetTrack(), track("the numbers", nums, paint(fill(n, "idle"), { 0: "read" }))],
            counters: [count("target", target), count("pairs checked", 0, totalPairs), count("worst-case checks", totalPairs)],
            legend: LEG,
            happened: `The outer loop will pin i to each position in turn; the inner loop walks every j after it, so each pair is visited once.`,
            why: "Starting j at i + 1 prevents double counting: the pair (2, 7) and the pair (7, 2) are the same pair.",
            codeLine: 5,
          });

          if (n < 2) {
            steps.push({
              title: "Fewer than two numbers — nothing to pair",
              tracks: [targetTrack(), track("the numbers", nums, fill(n, "dim"))],
              counters: [count("target", target), count("pairs checked", 0, totalPairs)],
              legend: LEG,
              happened: `With ${n} ${n === 1 ? "number" : "numbers"} there is no second index for any i, so both loops stay empty.`,
              why: "Two sum needs two positions; a row with fewer of them can never answer yes.",
              codeLine: 4,
            });
            steps.push({
              title: "A single number is the worst case for pairs",
              tracks: [targetTrack(), growth()],
              counters: [count("pairs checked", 0, totalPairs), count("cost class", "O(n²)")],
              legend: ["done", "active"],
              happened: `There are ${totalPairs} pairs here. Add ${2 * n - n} more numbers and the count jumps to ${(2 * n * (2 * n - 1)) / 2}.`,
              why: "The pair count grows with n times n, which is the quadratic shape of this approach.",
              codeLine: 5,
            });
            steps.push({
              title: "Answer: no pair adds to the target",
              tracks: [targetTrack(), track("the numbers", nums, fill(n, "dim")), pairTrack(null)],
              counters: [count("pairs checked", 0, totalPairs), count("answer", "no pair")],
              legend: LEG,
              happened: "Both loops finished without inspecting a single pair.",
              why: "An empty search still produces a correct answer: nothing can match a target when nothing exists to try.",
              codeLine: 10,
            });
            return steps;
          }

          let found = false, fi = -1, fj = -1, checked = 0;
          outer:
          for (let i = 0; i < n && !found; i++) {
            for (let j = i + 1; j < n; j++) {
              checked++;
              const sum = nums[i] + nums[j];
              const hit = sum === target;
              const states = nums.map((_, k) =>
                k < i ? "done" : k === i ? "compare" : k === j ? (hit ? "good" : "bad") : "idle"
              );
              steps.push({
                title: hit
                  ? `${nums[i]} + ${nums[j]} = ${target} ✓`
                  : `${nums[i]} + ${nums[j]} = ${sum} ≠ ${target}`,
                tracks: [targetTrack(), track("the numbers", nums, states), pairTrack(i, j, hit ? "good" : "compare")],
                counters: [count("pairs checked", checked, totalPairs), count("sum", sum), count("best match", found ? "found" : "—")],
                legend: LEG,
                happened: hit
                  ? `The pair at indices ${i} and ${j} adds to exactly ${target}.`
                  : `Indices ${i} and ${j} add to ${sum}, which misses the target by ${sum - target}.`,
                why: hit
                  ? "A match is the answer; the scan can stop because any earlier pair would already have ended it."
                  : "One more pair is retired. The inner loop only moves j forward, so no pair is lost.",
                codeLine: hit ? 6 : 5,
              });
              if (hit) { found = true; fi = i; fj = j; break outer; }
            }
          }

          if (found) {
            steps.push({
              title: `Stop early: indices ${fi} and ${fj} work`,
              tracks: [
                targetTrack(),
                track("the numbers", nums, nums.map((_, k) => (k === fi || k === fj ? "result" : "dim"))),
                pairTrack(fi, fj, "result"),
              ],
              counters: [count("pairs checked", checked, totalPairs), count("answer", `${nums[fi]} + ${nums[fj]}`)],
              legend: LEG,
              happened: `The scan stopped at pair (${fi}, ${fj}) without checking the remaining ${totalPairs - checked} pairs.`,
              why: "Early exit helps the best case, but the worst case still examines every pair — that is what O(n²) describes.",
              codeLine: 8,
            });
          } else {
            steps.push({
              title: `All ${totalPairs} pairs checked`,
              tracks: [targetTrack(), track("the numbers", nums, fill(n, "done")), pairTrack(null)],
              counters: [count("pairs checked", checked, totalPairs), count("matches", 0)],
              legend: LEG,
              happened: `The inner loop reached the end of the row for every i without finding a sum of ${target}.`,
              why: "Exhausting every pair proves absence just as firmly as a hit proves presence.",
              codeLine: 10,
            });
          }

          steps.push({
            title: "Pairs grow quadratically",
            tracks: [targetTrack(), growth()],
            counters: [count("pairs checked", checked, totalPairs), count("cost class", "O(n²)")],
            legend: ["done", "active"],
            happened: `${n} numbers allow ${totalPairs} pairs; ${2 * n} numbers allow ${(2 * n * (2 * n - 1)) / 2}.`,
            why: "The check count follows n(n-1)/2, whose leading term is n² — that is the cost class of this approach.",
            codeLine: 5,
          });

          steps.push({
            title: found
              ? `Answer: indices ${fi} and ${fj} (${nums[fi]} + ${nums[fj]} = ${target})`
              : "Answer: no pair adds to the target",
            tracks: [
              targetTrack(),
              track("the numbers", nums, nums.map((_, k) => (found && (k === fi || k === fj) ? "result" : "dim"))),
              pairTrack(found ? fi : null, found ? fj : undefined, "result"),
            ],
            counters: [count("pairs checked", checked, totalPairs), count("answer", found ? `${nums[fi]} + ${nums[fj]} = ${target}` : "no pair")],
            legend: LEG,
            happened: found
              ? `Two positions were enough: ${nums[fi]} at index ${fi} plus ${nums[fj]} at index ${fj} equals ${target}.`
              : `No two positions in ${joinList(nums)} add to ${target}.`,
            why: "The answer carries indices, not just values — the same number appearing twice only counts if it occupies two different positions.",
            codeLine: 12,
          });
          return steps;
        },
      },
      {
        name: "Remember Complements",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Read the numbers once, left to right. For each value x, ask whether its complement, target − x, has already been recorded.",
          "A map from value to index answers that question in about one step, so each number costs constant work.",
        ],
        problem: [
          "The map stores every value read so far, up to n entries. It also must not reuse the same position, which is why a number is only recorded after its complement is looked up.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

#define CAP 128   /* small demo table; real code picks a bigger one */

/* returns the index of the complement, or -1 */
int two_sum(const int *a, int n, int target) {
    int key[CAP], idx[CAP];
    bool used[CAP] = {false};
    for (int i = 0; i < n; i++) {
        int need = target - a[i];
        unsigned h = ((unsigned)need * 2654435761u) % CAP;
        while (used[h] && key[h] != need) h = (h + 1) % CAP;
        if (used[h]) return idx[h];
        h = ((unsigned)a[i] * 2654435761u) % CAP;
        while (used[h] && key[h] != a[i]) h = (h + 1) % CAP;
        key[h] = a[i]; idx[h] = i; used[h] = true;
    }
    return -1;
}

int main(void) {
    int a[] = {2, 7, 11, 15};
    printf("%d\\n", two_sum(a, 4, 9)); /* index 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_map>
#include <utility>

// one pass: look the complement up, then record this value
std::pair<int,int> twoSum(const std::vector<int>& a, int target) {
    std::unordered_map<int,int> seen;      // value -> index
    for (int i = 0; i < (int)a.size(); ++i) {
        int need = target - a[i];
        auto it = seen.find(need);
        if (it != seen.end()) return {it->second, i};
        seen[a[i]] = i;
    }
    return {-1, -1};
}

int main() {
    auto [i, j] = twoSum({2, 7, 11, 15}, 9);
    std::cout << i << " " << j << '\\n';
}`,
        },
        steps(parsed) {
          const target = parsed[0];
          const nums = parsed.slice(1);
          const n = nums.length;
          const LEG = ["read", "good", "done", "result", "idle"];
          const steps = [];
          const targetTrack = () => single("target", target, "result", "wanted sum");
          const seen = new Map();
          const seenTrack = (need) => ({
            label: "seen so far",
            cells: seen.size
              ? [...seen].map(([v, idx]) => ({ v: `${v} @${idx}`, state: v === need ? "good" : "done" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });
          const pairTrack = (i, j) => ({
            label: "the pair",
            cells: i == null
              ? [{ v: "—", state: "idle", empty: true }]
              : [
                  { v: nums[i], state: "result", tag: `index ${i}` },
                  { v: "+", state: "idle" },
                  { v: nums[j], state: "result", tag: `index ${j}` },
                ],
          });

          steps.push({
            title: `Look for two numbers that add to ${target}`,
            tracks: [targetTrack(), track("the numbers", nums, fill(n, "idle")), seenTrack(null)],
            counters: [count("numbers read", 0, n), count("map lookups", 0)],
            legend: LEG,
            happened: `The numbers are ${joinList(nums)}. The map of earlier values starts empty.`,
            why: "The map will answer one question cheaply: has the complement of today's value already appeared?",
            codeLine: 6,
          });

          steps.push({
            title: "Plan: read once, record after checking",
            tracks: [targetTrack(), track("the numbers", nums, fill(n, "idle")), seenTrack(null)],
            counters: [count("numbers read", 0, n), count("map lookups", 0)],
            legend: LEG,
            happened: `For each x the algorithm asks for target − x = ${target} − x in the map. Only if that fails does x itself get stored.`,
            why: "Checking before storing stops a number from matching itself at the same index, while still allowing two copies at different positions.",
            codeLine: 9,
          });

          let found = false, fi = -1, fj = -1, lookups = 0;
          for (let i = 0; i < n && !found; i++) {
            const x = nums[i];
            const need = target - x;
            lookups++;
            const j = seen.get(need);
            const hit = j !== undefined;
            if (hit) { fi = j; fj = i; found = true; }
            const states = nums.map((_, k) =>
              k === fi || k === fj ? "good" : k === i ? (hit ? "good" : "read") : k < i ? "done" : "idle"
            );
            steps.push({
              title: hit ? `${x} needs ${need} — found at index ${j}` : `${x} needs ${need} — not seen yet`,
              tracks: [targetTrack(), track("the numbers", nums, states), seenTrack(need)],
              counters: [count("numbers read", i + 1, n), count("map lookups", lookups), count("map size", seen.size)],
              legend: LEG,
              happened: hit
                ? `The map already holds ${need} at index ${j}, so ${nums[j]} and ${x} add to ${target}.`
                : `${need} is not in the map, so ${x} is recorded at index ${i} for a later number to match.`,
              why: hit
                ? "One lookup found the partner — no earlier number had to be re-checked."
                : "Storing each value as it is read is what makes the next complement check instant.",
              codeLine: hit ? 10 : 12,
            });
            if (!hit) seen.set(x, i);
          }

          if (found) {
            steps.push({
              title: `Stop after one pass: indices ${fi} and ${fj}`,
              tracks: [
                targetTrack(),
                track("the numbers", nums, nums.map((_, k) => (k === fi || k === fj ? "result" : "dim"))),
                pairTrack(fi, fj),
              ],
              counters: [count("numbers read", fj + 1, n), count("map lookups", lookups), count("answer", `${nums[fi]} + ${nums[fj]}`)],
              legend: LEG,
              happened: `The scan ended at index ${fj}; the remaining ${n - fj - 1} numbers never needed reading.`,
              why: "Stopping early is a bonus. Even in the worst case the loop still reads every number only once.",
              codeLine: 10,
            });
          } else {
            steps.push({
              title: "One pass complete, no complement found",
              tracks: [targetTrack(), track("the numbers", nums, fill(n, "done")), seenTrack(null)],
              counters: [count("numbers read", n, n), count("map lookups", n), count("map size", seen.size)],
              legend: LEG,
              happened: `Every number was read once and recorded. None of their complements met ${target}.`,
              why: "A finished pass with an empty result proves no pair exists, at a cost of exactly n lookups.",
              codeLine: 10,
            });
          }

          steps.push({
            title: "The lookup cost is the map's size",
            tracks: [
              targetTrack(),
              {
                label: "growth",
                cells: [
                  { v: `${n} numbers`, state: "done", tag: `${n} lookups, ≤ ${n} stored` },
                  { v: `${2 * n} numbers`, state: "active", tag: `${2 * n} lookups, ≤ ${2 * n} stored` },
                ],
              },
            ],
            counters: [count("lookups per number", 1), count("cost class", "O(n)")],
            legend: ["done", "active"],
            happened: `Reading ${n} numbers takes ${n} lookups and stores at most ${n} entries; doubling the input doubles both.`,
            why: "Time follows n in a straight line, and memory follows n too — that trade is the essence of hashing here.",
            codeLine: 6,
          });

          steps.push({
            title: found
              ? `Answer: indices ${fi} and ${fj} (${nums[fi]} + ${nums[fj]} = ${target})`
              : "Answer: no pair adds to the target",
            tracks: [
              targetTrack(),
              track("the numbers", nums, nums.map((_, k) => (found && (k === fi || k === fj) ? "result" : "dim"))),
              pairTrack(found ? fi : null, found ? fj : undefined),
            ],
            counters: [count("numbers read", found ? fj + 1 : n, n), count("answer", found ? `${nums[fi]} + ${nums[fj]} = ${target}` : "no pair")],
            legend: LEG,
            happened: found
              ? `${nums[fi]} at index ${fi} and ${nums[fj]} at index ${fj} sum to ${target}.`
              : `No two numbers in ${joinList(nums)} add to ${target}.`,
            why: "The map never had to re-scan earlier values, which is exactly what turns the quadratic pair search into a linear one.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "best-time-to-buy-and-sell-stock",
    title: "Best Time to Buy and Sell Stock",
    category: "Array Patterns",
    difficulty: "Beginner",
    description: "Pick a buy day and a later sell day so the profit is as large as possible.",
    input: { label: "Daily prices", default: "7, 1, 5, 3, 6, 4", parse: "ints" },
    approaches: [
      {
        name: "Try Every Buy and Sell Day",
        complexity: "O(n²) time, O(1) space",
        idea: [
          "A trade is one buy day i followed by a later sell day j. Try every such pair and keep the largest profit seen.",
          "Profit can be negative; doing nothing is worth 0, so the best answer never drops below zero.",
        ],
        problem: [
          "The pair count is n(n-1)/2, so the whole row is scanned over and over. With 40 days that is 780 subtractions for a single answer.",
        ],
        code: {
          c: `#include <stdio.h>

/* best profit from one buy before one later sell */
int best_profit(const int *p, int n) {
    int best = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            int profit = p[j] - p[i];
            if (profit > best) best = profit;
        }
    }
    return best;
}

int main(void) {
    int p[] = {7, 1, 5, 3, 6, 4};
    printf("%d\\n", best_profit(p, 6)); /* 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// every earlier buy against every later sell
int bestProfit(const std::vector<int>& p) {
    int best = 0;
    for (int i = 0; i < (int)p.size(); ++i) {
        for (int j = i + 1; j < (int)p.size(); ++j) {
            int profit = p[j] - p[i];
            if (profit > best) best = profit;
        }
    }
    return best;
}

int main() {
    std::cout << bestProfit({7, 1, 5, 3, 6, 4}) << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const totalPairs = (n * (n - 1)) / 2;
          const LEG = ["read", "active", "compare", "result", "done", "idle"];
          const steps = [];
          let best = 0, bestBuy = null, bestSell = null;
          const bestTrack = () => ({
            label: "best trade",
            cells: [
              { v: best, state: "result", tag: "profit" },
              {
                v: bestBuy == null ? "do nothing" : `${nums[bestBuy]} → ${nums[bestSell]}`,
                state: bestBuy == null ? "idle" : "done",
                tag: bestBuy == null ? "0 is safe" : "buy → sell",
              },
            ],
          });
          const priceStates = (i, j) =>
            nums.map((_, k) =>
              k === i ? "active" : k === j ? "read" : bestBuy != null && k >= bestBuy && k <= bestSell ? "result" : k < j ? "done" : "idle"
            );

          steps.push({
            title: `Find the largest profit across ${n} ${n === 1 ? "day" : "days"}`,
            tracks: [track("daily prices", nums, fill(n, "idle")), bestTrack()],
            counters: [count("days", n), count("pairs checked", 0, totalPairs), count("best profit", 0)],
            legend: LEG,
            happened: `The prices are ${joinList(nums)}. The best trade starts at a profit of 0, meaning no trade at all.`,
            why: "Buying and selling must happen on different days, and the buy must come first — the order in the row is the order in time.",
            codeLine: 4,
          });

          steps.push({
            title: "A trade is one earlier buy and one later sell",
            tracks: [track("daily prices", nums, fill(n, "idle")), bestTrack()],
            counters: [count("days", n), count("pairs checked", 0, totalPairs), count("best profit", 0)],
            legend: LEG,
            happened: "For every possible buy day, the inner loop will look at all later days as the sell day.",
            why: "Only n(n-1)/2 of the n² possible pairs are legal trades; the rest would sell before buying.",
            codeLine: 5,
          });

          steps.push({
            title: "Best starts at 0 — doing nothing is allowed",
            tracks: [track("daily prices", nums, fill(n, "idle")), bestTrack()],
            counters: [count("days", n), count("pairs checked", 0, totalPairs), count("best profit", 0)],
            legend: LEG,
            happened: `A best of 0 is the default answer: if every trade loses money, the smart move is not to trade.`,
            why: "Starting at 0 means the final answer can never be negative, which is what the problem requires.",
            codeLine: 4,
          });

          steps.push({
            title: "If every later price falls, 0 wins",
            tracks: [track("daily prices", nums, fill(n, "idle")), bestTrack()],
            counters: [count("days", n), count("pairs checked", 0, totalPairs), count("best profit", 0)],
            legend: LEG,
            happened: "A steadily falling row would produce only negative profits, and none of them would beat the starting 0.",
            why: "This is why the outer loop may still check every pair: a losing trade is simply ignored, not recorded.",
            codeLine: 7,
          });

          steps.push({
            title: `Outer loop fixes the buy day at index 0`,
            tracks: [track("daily prices", nums, nums.map((_, k) => (k === 0 ? "active" : "idle"))), bestTrack()],
            counters: [count("days", n), count("pairs checked", 0, totalPairs), count("best profit", 0)],
            legend: LEG,
            happened: `The buy is pinned to ${nums[0]}. The inner loop will test it against every later day as a sell day.`,
            why: "Fixing one side and sweeping the other is the classic nested-loop shape for all-pairs problems.",
            codeLine: 5,
          });

          let checked = 0;
          for (let i = 0; i < n - 1; i++) {
            for (let j = i + 1; j < n; j++) {
              checked++;
              const profit = nums[j] - nums[i];
              const better = profit > best;
              if (better) { best = profit; bestBuy = i; bestSell = j; }
              steps.push({
                title: better
                  ? `Buy ${nums[i]} → sell ${nums[j]} = ${profit}, new best`
                  : `Buy ${nums[i]} → sell ${nums[j]} = ${profit}, no change`,
                tracks: [track("daily prices", nums, priceStates(i, j)), bestTrack()],
                counters: [count("pairs checked", checked, totalPairs), count("this trade", profit), count("best profit", best)],
                legend: LEG,
                happened: better
                  ? `Selling at ${nums[j]} after buying at ${nums[i]} gives ${profit}, which beats the old best.`
                  : `The trade earns ${profit}, which does not beat the current best of ${best}.`,
                why: better
                  ? "A better trade replaces the stored pair, so the best value only ever increases."
                  : "Losing trades are skipped without touching the best pair.",
                codeLine: better ? 8 : 7,
              });
            }
          }

          steps.push({
            title: n > 1 ? `All ${totalPairs} pairs checked` : "No later day to trade against",
            tracks: [track("daily prices", nums, nums.map((_, k) => (bestBuy != null && k >= bestBuy && k <= bestSell ? "result" : "done"))), bestTrack()],
            counters: [count("pairs checked", checked, totalPairs), count("best profit", best)],
            legend: LEG,
            happened: n > 1
              ? `Every earlier-buy/later-sell pair has been compared. The best profit is ${best}.`
              : `With a single day there is no trade to make, so the best profit remains 0.`,
            why: "The exhaustive sweep is complete, so the stored pair is the true optimum for this row.",
            codeLine: 10,
          });

          steps.push({
            title: "Pair checks grow quadratically",
            tracks: [
              track("daily prices", nums, fill(n, "dim")),
              {
                label: "growth",
                cells: [
                  { v: `${n} days`, state: "done", tag: `${totalPairs} checks` },
                  { v: `${2 * n} days`, state: "active", tag: `${(2 * n * (2 * n - 1)) / 2} checks` },
                ],
              },
            ],
            counters: [count("pairs checked", checked, totalPairs), count("cost class", "O(n²)")],
            legend: ["done", "active", "dim"],
            happened: `Checking ${n} days cost ${totalPairs} comparisons; ${2 * n} days would cost ${(2 * n * (2 * n - 1)) / 2}.`,
            why: "The check count follows n(n-1)/2, whose leading term is n² — the reason this approach does not scale.",
            codeLine: 5,
          });

          steps.push({
            title: `Answer: best profit ${best}`,
            tracks: [
              track("daily prices", nums, nums.map((_, k) => (bestBuy != null && k >= bestBuy && k <= bestSell ? "result" : "dim"))),
              bestTrack(),
            ],
            counters: [count("days", n), count("pairs checked", checked, totalPairs), count("answer", best)],
            legend: LEG,
            happened: bestBuy == null
              ? "No pair produced a positive profit, so the answer is the default 0."
              : `Buying at ${nums[bestBuy]} and selling at ${nums[bestSell]} gives the top profit of ${best}.`,
            why: "All pairs were compared, so no larger profit can be hiding anywhere in the row.",
            codeLine: 10,
          });
          return steps;
        },
      },
      {
        name: "One Pass, One Minimum",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Walk the prices once, remembering the cheapest price seen so far. At each day ask: what if I sold today at this price?",
          "Today's profit is today's price minus the cheapest earlier price. Track the largest of those, never below 0.",
        ],
        problem: [
          "Keeping only the minimum hides history: you cannot later ask for the second-cheapest day or a different window. For this single answer, though, nothing else is needed.",
        ],
        code: {
          c: `#include <stdio.h>

/* remember the cheapest price seen so far */
int best_profit(const int *p, int n) {
    int cheapest = p[0], best = 0;
    for (int i = 1; i < n; i++) {
        int profit = p[i] - cheapest;
        if (profit > best) best = profit;
        if (p[i] < cheapest) cheapest = p[i];
    }
    return best;
}

int main(void) {
    int p[] = {7, 1, 5, 3, 6, 4};
    printf("%d\\n", best_profit(p, 6)); /* 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

// one walk: cheapest so far vs today's price
int bestProfit(const std::vector<int>& p) {
    int cheapest = p[0], best = 0;
    for (int i = 1; i < (int)p.size(); ++i) {
        int profit = p[i] - cheapest;
        best = std::max(best, profit);
        cheapest = std::min(cheapest, p[i]);
    }
    return best;
}

int main() {
    std::cout << bestProfit({7, 1, 5, 3, 6, 4}) << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const LEG = ["read", "active", "result", "done", "idle"];
          const steps = [];
          let cheapest = nums[0], cheapestDay = 0, best = 0, bestBuy = null, bestSell = null;
          const keepers = () => ({
            label: "keepers",
            cells: [
              { v: cheapest, state: "active", tag: "cheapest so far" },
              { v: best, state: "result", tag: "best profit" },
              {
                v: bestBuy == null ? "none" : `${nums[bestBuy]} → ${nums[bestSell]}`,
                state: bestBuy == null ? "idle" : "done",
                tag: "best trade",
              },
            ],
          });
          const dayStates = (upTo, focus) =>
            nums.map((_, k) =>
              k === focus ? "read" : k === cheapestDay ? "active" : k < upTo ? "done" : "idle"
            );

          steps.push({
            title: `Find the largest profit across ${n} ${n === 1 ? "day" : "days"}`,
            tracks: [track("daily prices", nums, fill(n, "idle")), keepers()],
            counters: [count("days seen", 0, n), count("cheapest price", cheapest), count("best profit", 0)],
            legend: LEG,
            happened: `The prices are ${joinList(nums)}. One walk will carry two keepers: the cheapest price so far and the best profit so far.`,
            why: "Both keepers update in constant time, which is what lets the whole problem collapse into a single pass.",
            codeLine: 4,
          });

          steps.push({
            title: "Plan: one walk, two keepers",
            tracks: [track("daily prices", nums, fill(n, "idle")), keepers()],
            counters: [count("days seen", 0, n), count("cheapest price", cheapest), count("best profit", 0)],
            legend: LEG,
            happened: "At each day the loop asks two questions: could today be the new cheapest buy, and would selling today beat every earlier trade?",
            why: "Every day is visited once and each visit does constant work, which already hints at O(n).",
            codeLine: 5,
          });

          steps.push({
            title: `Day 1: ${nums[0]} becomes the cheapest price`,
            tracks: [track("daily prices", nums, dayStates(1, 0)), keepers()],
            counters: [count("days seen", 1, n), count("cheapest price", nums[0]), count("best profit", 0)],
            legend: LEG,
            happened: `The first price ${nums[0]} seeds the keeper. No trade is possible yet, so the best profit is still 0.`,
            why: "The earliest day can only be a buy; there is no earlier price it could have been beaten by.",
            codeLine: 4,
          });

          steps.push({
            title: "A trade must buy before it sells",
            tracks: [track("daily prices", nums, dayStates(1, 0)), keepers()],
            counters: [count("days seen", 1, n), count("cheapest price", cheapest), count("best profit", 0)],
            legend: LEG,
            happened: `Selling on the same day as buying would earn 0, so day 1 can only be a buy so far.`,
            why: "The buy price must come from an earlier day; the loop uses the cheapest one available before today.",
            codeLine: 6,
          });

          steps.push({
            title: "Why one minimum is enough",
            tracks: [track("daily prices", nums, dayStates(1, 0)), keepers()],
            counters: [count("days seen", 1, n), count("cheapest price", cheapest), count("best profit", 0)],
            legend: LEG,
            happened: "For today's profit, only the lowest earlier price matters — any higher earlier price would give a smaller profit.",
            why: "That observation is the whole trick: the row of past prices can be compressed into a single number.",
            codeLine: 4,
          });

          for (let i = 1; i < n; i++) {
            const buyPrice = cheapest;
            const profit = nums[i] - buyPrice;
            const better = profit > best;
            if (better) { best = profit; bestBuy = cheapestDay; bestSell = i; }
            const wasCheapest = nums[i] < cheapest;
            if (wasCheapest) { cheapest = nums[i]; cheapestDay = i; }
            steps.push({
              title: better
                ? `Day ${i + 1}: sell at ${nums[i]} (cheap ${buyPrice}) = ${profit}, new best`
                : `Day ${i + 1}: sell at ${nums[i]} (cheap ${buyPrice}) = ${profit}, no change`,
              tracks: [track("daily prices", nums, dayStates(i + 1, i)), keepers()],
              counters: [count("days seen", i + 1, n), count("cheapest price", cheapest), count("best profit", best)],
              legend: LEG,
              happened: better
                ? `Selling today at ${nums[i]} after the cheapest earlier price ${buyPrice} gives ${profit}.`
                : `Selling today at ${nums[i]} after the cheapest earlier price ${buyPrice} gives ${profit}, which does not beat ${best}.`,
              why: wasCheapest
                ? `Today's price is also the new cheapest, so later days will compare against it instead.`
                : "Only the minimum and the best are kept; every earlier price can be forgotten.",
              codeLine: better ? 7 : 6,
            });
          }

          steps.push({
            title: `One pass complete — best profit ${best}`,
            tracks: [
              track("daily prices", nums, nums.map((_, k) => (bestBuy != null && k >= bestBuy && k <= bestSell ? "result" : "done"))),
              keepers(),
            ],
            counters: [count("days seen", n, n), count("cheapest price", cheapest), count("best profit", best)],
            legend: LEG,
            happened: `Every day was visited exactly once. The keepers hold the cheapest price ${cheapest} and the best profit ${best}.`,
            why: "Nothing was revisited and nothing was stored per day, which is what makes the single pass so cheap.",
            codeLine: 5,
          });

          steps.push({
            title: "One day per step, linear growth",
            tracks: [
              track("daily prices", nums, fill(n, "dim")),
              {
                label: "growth",
                cells: [
                  { v: `${n} days`, state: "done", tag: `${Math.max(0, n - 1)} updates` },
                  { v: `${2 * n} days`, state: "active", tag: `${Math.max(0, 2 * n - 1)} updates` },
                ],
              },
            ],
            counters: [count("days seen", n, n), count("cost class", "O(n)")],
            legend: ["done", "active", "dim"],
            happened: `${n} days mean one pass of ${Math.max(0, n - 1)} updates. Doubling the days merely doubles the pass.`,
            why: "Straight-line growth in time and constant space is the signature of this approach.",
            codeLine: 5,
          });

          steps.push({
            title: `Answer: best profit ${best}`,
            tracks: [
              track("daily prices", nums, nums.map((_, k) => (bestBuy != null && k >= bestBuy && k <= bestSell ? "result" : "dim"))),
              keepers(),
            ],
            counters: [count("days seen", n, n), count("answer", best)],
            legend: LEG,
            happened: bestBuy == null
              ? "No day offered a price above the cheapest earlier price, so the answer stays 0."
              : `Buying at ${nums[bestBuy]} and selling at ${nums[bestSell]} yields ${best}.`,
            why: "One pass and two keepers produced the same answer the pair sweep found, without ever comparing two arbitrary days.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-subarray",
    title: "Maximum Subarray",
    category: "Array Patterns",
    difficulty: "Intermediate",
    description: "Find the contiguous stretch with the largest sum, by Kadane's one pass or by checking every stretch.",
    input: { label: "The numbers", default: "-2, 1, -3, 4, -1, 2, 1, -5, 4", parse: "ints" },
    approaches: [
      {
        name: "Kadane: Extend or Restart",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Carry the best sum of a subarray that ends at the current position. For the next number there are only two honest choices: extend the old run, or throw it away and start fresh at this number.",
          "Take whichever is larger. Separately keep the largest run sum ever seen, because the best subarray may end before the row does.",
        ],
        problem: [
          "Kadane gives the best sum but not, by itself, its position. Keeping the start and end indices adds bookkeeping and a restart can move the start without warning.",
        ],
        code: {
          c: `#include <stdio.h>

/* best sum of a contiguous run ending at or before i */
int max_subarray(const int *a, int n) {
    int cur = a[0], best = a[0];
    for (int i = 1; i < n; i++) {
        if (cur + a[i] < a[i])
            cur = a[i];       /* restart here */
        else
            cur += a[i];      /* extend the run */
        if (cur > best) best = cur;
    }
    return best;
}

int main(void) {
    int a[] = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
    printf("%d\\n", max_subarray(a, 9)); /* 6 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

// cur = best sum ending here, best = best sum seen anywhere
int maxSubarray(const std::vector<int>& a) {
    int cur = a[0], best = a[0];
    for (int i = 1; i < (int)a.size(); ++i) {
        cur = std::max(a[i], cur + a[i]);
        best = std::max(best, cur);
    }
    return best;
}

int main() {
    std::cout << maxSubarray({-2, 1, -3, 4, -1, 2, 1, -5, 4}) << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const LEG = ["read", "active", "result", "dim", "idle"];
          const steps = [];
          let cur = nums[0], best = nums[0], start = 0, bestStart = 0, bestEnd = 0;
          const keepers = () => ({
            label: "keep",
            cells: [
              { v: cur, state: "active", tag: "run ending here" },
              { v: best, state: "result", tag: "best sum" },
            ],
          });
          const runStates = (runStart, runEnd) =>
            nums.map((_, k) => {
              if (k >= runStart && k <= runEnd) return k === runEnd ? "read" : "active";
              if (k >= bestStart && k <= bestEnd) return "result";
              return k <= runEnd ? "dim" : "idle";
            });

          steps.push({
            title: `Look for the largest-sum stretch in ${n} numbers`,
            tracks: [track("the numbers", nums, fill(n, "idle")), single("best sum", "—", "idle", "not chosen yet")],
            counters: [count("numbers seen", 0, n), count("current run", "—"), count("best sum", "—")],
            legend: LEG,
            happened: `The row is ${joinList(nums)}. A subarray must be contiguous, so the answer is one unbroken stretch, not a selection from anywhere.`,
            why: "Contiguity is the constraint that makes this problem interesting: the best stretch can cross negatives or skip them entirely.",
            codeLine: 4,
          });

          steps.push({
            title: "Plan: at each step, extend or restart",
            tracks: [track("the numbers", nums, fill(n, "idle")), single("best sum", "—", "idle", "not chosen yet")],
            counters: [count("numbers seen", 0, n), count("current run", "—"), count("best sum", "—")],
            legend: LEG,
            happened: "The running sum will describe the best stretch that ends exactly at the current index. The answer is the largest such sum ever seen.",
            why: "Any subarray has a right end. Solving the problem for every possible right end, then taking the maximum, covers all subarrays exactly once.",
            codeLine: 5,
          });

          steps.push({
            title: `Seed both sums with ${nums[0]}`,
            tracks: [track("the numbers", nums, runStates(0, 0)), keepers()],
            counters: [count("numbers seen", 1, n), count("current run", cur), count("best sum", best)],
            legend: LEG,
            happened: `The first value ${nums[0]} is both the current run and the best answer so far.`,
            why: "A single number is a legal subarray, so there is always at least one candidate from the start.",
            codeLine: 4,
          });

          steps.push({
            title: "The extend-or-restart rule",
            tracks: [track("the numbers", nums, runStates(0, 0)), keepers()],
            counters: [count("numbers seen", 1, n), count("current run", cur), count("best sum", best)],
            legend: LEG,
            happened: `Adding a number can be worse than starting at that number. Comparing the two options decides the next run.`,
            why: "If the old run is a burden, dropping it loses nothing: the new run is still contiguous and begins closer to the present.",
            codeLine: 6,
          });

          steps.push({
            title: "Best only moves when it is beaten",
            tracks: [track("the numbers", nums, runStates(0, 0)), keepers()],
            counters: [count("numbers seen", 1, n), count("current run", cur), count("best sum", best)],
            legend: LEG,
            happened: `The best answer is copied from the current run only when the current run is strictly larger.`,
            why: "A run that ends early may still be the winner, so the best value must be remembered independently of the current run.",
            codeLine: 10,
          });

          for (let i = 1; i < n; i++) {
            const x = nums[i];
            const oldCur = cur;
            const extend = oldCur + x;
            const tookRestart = x > extend;
            if (tookRestart) { cur = x; start = i; } else { cur = extend; }
            const oldBest = best;
            if (cur > best) { best = cur; bestStart = start; bestEnd = i; }
            const newBest = best > oldBest;
            steps.push({
              title: tookRestart
                ? `Restart at ${x} → run ${cur}${newBest ? " (new best)" : ""}`
                : `Extend by ${x} → run ${cur}${newBest ? " (new best)" : ""}`,
              tracks: [track("the numbers", nums, runStates(start, i)), keepers()],
              counters: [count("numbers seen", i + 1, n), count("current run", cur), count("best sum", best)],
              legend: LEG,
              happened: tookRestart
                ? `Extending the old run ${oldCur} by ${x} would give ${extend}, which is smaller than ${x} alone, so the run starts over at index ${i}.${newBest ? ` The new run also beats the old best ${oldBest}.` : ""}`
                : `The run ${oldCur} plus ${x} gives ${cur}, so the left edge stays at index ${start}.${newBest ? ` That beats the old best ${oldBest}.` : ""}`,
              why: tookRestart
                ? "A run with a negative prefix only drags the sum down; restarting is at least as good and keeps the stretch contiguous."
                : "Extending keeps the accumulated values; the best answer is updated only if this longer run is strictly better.",
              codeLine: tookRestart ? 7 : 9,
            });
          }

          steps.push({
            title: `The scan ends with best sum ${best}`,
            tracks: [
              track("the numbers", nums, nums.map((_, k) => (k >= bestStart && k <= bestEnd ? "result" : "dim"))),
              keepers(),
            ],
            counters: [count("numbers seen", n, n), count("current run", cur), count("best sum", best)],
            legend: LEG,
            happened: `The winning stretch is indices ${bestStart} through ${bestEnd}: ${nums.slice(bestStart, bestEnd + 1).join(" + ")} = ${best}.`,
            why: "The final current run may not be the winner, which is why the best value was tracked separately all along.",
            codeLine: 12,
          });

          steps.push({
            title: "One new number, one decision",
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              {
                label: "growth",
                cells: [
                  { v: `${n} numbers`, state: "done", tag: `${n} decisions` },
                  { v: `${2 * n} numbers`, state: "active", tag: `${2 * n} decisions` },
                ],
              },
            ],
            counters: [count("numbers seen", n, n), count("cost class", "O(n)")],
            legend: ["done", "active", "dim"],
            happened: `The scan made one extend-or-restart decision for each number after the first: ${n - 1} decisions here.`,
            why: "Doubling the input doubles the decisions, so Kadane is linear. The single running sum is all the extra memory needed.",
            codeLine: 5,
          });

          steps.push({
            title: `Answer: maximum subarray sum ${best}`,
            tracks: [
              track("the numbers", nums, nums.map((_, k) => (k >= bestStart && k <= bestEnd ? "result" : "dim"))),
              keepers(),
            ],
            counters: [count("numbers seen", n, n), count("best sum", best), count("answer", best)],
            legend: LEG,
            happened: `The largest contiguous sum is ${best}, from index ${bestStart} to ${bestEnd}.`,
            why: "Every possible right end was considered and the best stretch for each was computed in constant time, so no subarray was missed.",
            codeLine: 12,
          });
          return steps;
        },
      },
      {
        name: "Try Every Subarray",
        complexity: "O(n²) time, O(1) space",
        idea: [
          "Fix a start index i, then extend the end index j one position at a time while carrying the running sum.",
          "Every contiguous stretch is visited exactly once, and the largest sum is kept.",
        ],
        problem: [
          "There are n(n+1)/2 stretches. Carrying the sum forward avoids a third loop, but the number of stretches still grows quadratically.",
        ],
        code: {
          c: `#include <stdio.h>

/* every start, every end, with a running sum */
int max_subarray(const int *a, int n) {
    int best = a[0];
    for (int i = 0; i < n; i++) {
        int sum = 0;
        for (int j = i; j < n; j++) {
            sum += a[j];
            if (sum > best) best = sum;
        }
    }
    return best;
}

int main(void) {
    int a[] = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
    printf("%d\\n", max_subarray(a, 9)); /* 6 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// all O(n^2) stretches, sums built incrementally
int maxSubarray(const std::vector<int>& a) {
    int best = a[0];
    for (int i = 0; i < (int)a.size(); ++i) {
        int sum = 0;
        for (int j = i; j < (int)a.size(); ++j) {
            sum += a[j];
            if (sum > best) best = sum;
        }
    }
    return best;
}

int main() {
    std::cout << maxSubarray({-2, 1, -3, 4, -1, 2, 1, -5, 4}) << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const total = (n * (n + 1)) / 2;
          const LEG = ["read", "active", "result", "done", "dim", "idle"];
          const steps = [];
          let best = nums[0], bestStart = 0, bestEnd = 0, checked = 0;
          const bestTrack = () => single("best stretch", best, "result", `${nums.slice(bestStart, bestEnd + 1).join(", ")}`);
          const spanStates = (i, j) =>
            nums.map((_, k) => {
              if (k >= i && k <= j) return k === j ? "read" : "active";
              if (k >= bestStart && k <= bestEnd) return "result";
              return k <= j ? "done" : "idle";
            });

          steps.push({
            title: `Look for the largest-sum stretch in ${n} numbers`,
            tracks: [track("the numbers", nums, fill(n, "idle")), bestTrack()],
            counters: [count("stretches checked", 0, total), count("best sum", best)],
            legend: LEG,
            happened: `The row is ${joinList(nums)}. The first single value ${nums[0]} is the initial best, because every subarray must contain at least one number.`,
            why: "Seeding with a real element keeps the answer valid even when every number is negative.",
            codeLine: 4,
          });

          steps.push({
            title: "Plan: fix the start, grow the end",
            tracks: [track("the numbers", nums, paint(fill(n, "idle"), { 0: "read" })), bestTrack()],
            counters: [count("stretches checked", 0, total), count("best sum", best)],
            legend: LEG,
            happened: "For each start i, the inner loop will extend j from i to the end of the row, so every stretch beginning at i is seen.",
            why: "A subarray is identified by its two ends. Fixing the start and moving the end enumerates all of them without duplicates.",
            codeLine: 5,
          });

          steps.push({
            title: "A subarray is one unbroken stretch",
            tracks: [track("the numbers", nums, fill(n, "idle")), bestTrack()],
            counters: [count("stretches checked", 0, total), count("best sum", best)],
            legend: LEG,
            happened: "The numbers inside the chosen span are included even when they are negative; skipping a middle value would break contiguity.",
            why: "That is why this cannot be solved by simply adding every positive number — the negatives between them are part of the cost.",
            codeLine: 6,
          });

          steps.push({
            title: `Best starts as the single value ${nums[0]}`,
            tracks: [track("the numbers", nums, spanStates(0, 0)), bestTrack()],
            counters: [count("stretches checked", 0, total), count("best sum", best)],
            legend: LEG,
            happened: `The stretch from index 0 to 0 has sum ${best}, so it is the best before the loops officially begin.`,
            why: "Having a real candidate from the start avoids a special 'no answer yet' case inside the loop.",
            codeLine: 4,
          });

          for (let i = 0; i < n; i++) {
            let sum = 0;
            for (let j = i; j < n; j++) {
              sum += nums[j];
              checked++;
              const better = sum > best;
              if (better) { best = sum; bestStart = i; bestEnd = j; }
              steps.push({
                title: `Start ${i}, end ${j}: sum ${sum}${better ? " (new best)" : ""}`,
                tracks: [track("the numbers", nums, spanStates(i, j)), bestTrack()],
                counters: [count("stretches checked", checked, total), count("current sum", sum), count("best sum", best)],
                legend: LEG,
                happened: better
                  ? `The stretch from index ${i} to ${j} adds to ${sum}, which beats the old best.`
                  : `The stretch from index ${i} to ${j} adds to ${sum}, which does not beat ${best}.`,
                why: better
                  ? "A new best replaces the stored stretch; the answer always names a concrete pair of ends."
                  : "All stretches must be inspected because a negative number earlier may be outweighed by positives later.",
                codeLine: 8,
              });
            }
          }

          steps.push({
            title: `All ${total} stretches checked — best ${best}`,
            tracks: [
              track("the numbers", nums, nums.map((_, k) => (k >= bestStart && k <= bestEnd ? "result" : "done"))),
              bestTrack(),
            ],
            counters: [count("stretches checked", checked, total), count("best sum", best)],
            legend: LEG,
            happened: `Every start and end pair was visited. The winning stretch is indices ${bestStart} to ${bestEnd}.`,
            why: "Exhaustive enumeration leaves no possibility unchecked; the stored best is therefore exact.",
            codeLine: 10,
          });

          steps.push({
            title: "Stretch counts grow quadratically",
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              {
                label: "growth",
                cells: [
                  { v: `${n} numbers`, state: "done", tag: `${total} stretches` },
                  { v: `${2 * n} numbers`, state: "active", tag: `${(2 * n) * (2 * n + 1) / 2} stretches` },
                ],
              },
            ],
            counters: [count("stretches checked", checked, total), count("cost class", "O(n²)")],
            legend: ["done", "active", "dim"],
            happened: `${n} numbers produce ${total} stretches; ${2 * n} numbers produce ${(2 * n) * (2 * n + 1) / 2}.`,
            why: "The running sum removed a third loop, but the number of stretches is still about n²/2 — quadratic remains quadratic.",
            codeLine: 7,
          });

          steps.push({
            title: `Answer: maximum subarray sum ${best}`,
            tracks: [
              track("the numbers", nums, nums.map((_, k) => (k >= bestStart && k <= bestEnd ? "result" : "dim"))),
              bestTrack(),
            ],
            counters: [count("stretches checked", checked, total), count("answer", best)],
            legend: LEG,
            happened: `The largest contiguous sum is ${best}, taken from indices ${bestStart} through ${bestEnd}.`,
            why: "Kadane's one pass arrives at the same number with less work; this approach pays for its simplicity with a quadratic scan.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-product-subarray",
    title: "Maximum Product Subarray",
    category: "Array Patterns",
    difficulty: "Intermediate",
    description: "Find the contiguous stretch with the largest product, where negatives can flip the ranking.",
    input: { label: "The numbers", default: "2, 3, -2, 4", parse: "ints" },
    approaches: [
      {
        name: "Track Both Extremes",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Keep the largest and smallest product of any subarray ending at the current position. The smallest is needed because multiplying it by a negative number can turn it into the largest.",
          "When the next number is negative, the roles swap before extending. Then update both candidates and remember the best largest value ever seen.",
        ],
        problem: [
          "Zeros reset both products to zero, and negatives can swap them repeatedly. Missing the minimum keeper makes the algorithm fail on rows such as -2, 3, -4.",
        ],
        code: {
          c: `#include <stdio.h>

/* keep the largest and smallest product ending here */
int max_product(const int *a, int n) {
    int hi = a[0], lo = a[0], best = a[0];
    for (int i = 1; i < n; i++) {
        if (a[i] < 0) { int t = hi; hi = lo; lo = t; }
        int extend_hi = hi * a[i], extend_lo = lo * a[i];
        hi = (a[i] > extend_hi) ? a[i] : extend_hi;
        lo = (a[i] < extend_lo) ? a[i] : extend_lo;
        if (hi > best) best = hi;
    }
    return best;
}

int main(void) {
    int a[] = {2, 3, -2, 4};
    printf("%d\\n", max_product(a, 4)); /* 6 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

// both extremes are needed because negatives flip the order
int maxProduct(const std::vector<int>& a) {
    int hi = a[0], lo = a[0], best = a[0];
    for (int i = 1; i < (int)a.size(); ++i) {
        if (a[i] < 0) std::swap(hi, lo);
        int nextHi = std::max(a[i], hi * a[i]);
        int nextLo = std::min(a[i], lo * a[i]);
        hi = nextHi;
        lo = nextLo;
        best = std::max(best, hi);
    }
    return best;
}

int main() {
    std::cout << maxProduct({2, 3, -2, 4}) << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const LEG = ["read", "active", "compare", "result", "dim", "idle"];
          const steps = [];
          let hi = nums[0], lo = nums[0], best = nums[0];
          const keepers = () => ({
            label: "products ending here",
            cells: [
              { v: hi, state: "active", tag: "largest" },
              { v: lo, state: "compare", tag: "smallest" },
              { v: best, state: "result", tag: "best seen" },
            ],
          });

          steps.push({
            title: `Find the largest-product stretch in ${n} numbers`,
            tracks: [track("the numbers", nums, fill(n, "idle")), single("best product", "—", "idle", "not chosen yet")],
            counters: [count("numbers seen", 0, n), count("largest ending here", "—"), count("smallest ending here", "—")],
            legend: LEG,
            happened: `The row is ${joinList(nums)}. Products can be positive or negative, and a negative can overturn the ranking of two candidates.`,
            why: "Sum problems can forget the smallest candidate; product problems cannot, because a very negative value may become the winner after one more negative.",
            codeLine: 4,
          });

          steps.push({
            title: "Plan: carry a largest and a smallest",
            tracks: [track("the numbers", nums, fill(n, "idle")), single("best product", "—", "idle", "not chosen yet")],
            counters: [count("numbers seen", 0, n), count("largest ending here", "—"), count("smallest ending here", "—")],
            legend: LEG,
            happened: "At each position the algorithm keeps two products for stretches ending there, plus the best product seen anywhere.",
            why: "Two candidates cover both signs. One alone would lose the path that becomes the maximum after a future negative.",
            codeLine: 5,
          });

          steps.push({
            title: `Seed both extremes with ${nums[0]}`,
            tracks: [track("the numbers", nums, paint(fill(n, "idle"), { 0: "read" })), keepers()],
            counters: [count("numbers seen", 1, n), count("largest ending here", hi), count("smallest ending here", lo), count("best product", best)],
            legend: LEG,
            happened: `The first value ${nums[0]} is the largest, smallest, and best product so far.`,
            why: "A single number is a legal subarray, so the keepers can start from a real value instead of an artificial identity.",
            codeLine: 4,
          });

          steps.push({
            title: "Why the smallest candidate matters",
            tracks: [track("the numbers", nums, paint(fill(n, "idle"), { 0: "read" })), keepers()],
            counters: [count("numbers seen", 1, n), count("largest ending here", hi), count("smallest ending here", lo), count("best product", best)],
            legend: LEG,
            happened: `A smallest product of ${lo} is not a failure — a later negative number could multiply it into the new largest.`,
            why: "Keeping both extremes is what makes the one-pass method correct in the presence of negative values.",
            codeLine: 6,
          });

          steps.push({
            title: "A negative next value swaps the roles",
            tracks: [track("the numbers", nums, fill(n, "idle")), keepers()],
            counters: [count("numbers seen", 1, n), count("largest ending here", hi), count("smallest ending here", lo), count("best product", best)],
            legend: LEG,
            happened: "Before multiplying, negative input swaps the two keepers: the old smallest becomes the promising largest after the sign flip.",
            why: "Swapping is equivalent to comparing all four products at once, and avoids branching over which sign will win.",
            codeLine: 6,
          });

          for (let i = 1; i < n; i++) {
            const x = nums[i];
            const oldHi = hi, oldLo = lo;
            const flipped = x < 0;
            if (flipped) { const t = hi; hi = lo; lo = t; }
            const candHi = hi * x, candLo = lo * x;
            hi = Math.max(x, candHi);
            lo = Math.min(x, candLo);
            const oldBest = best;
            if (hi > best) best = hi;
            const newBest = best > oldBest;
            steps.push({
              title: `× ${x} → largest ${hi}, smallest ${lo}${newBest ? " (new best)" : ""}`,
              tracks: [track("the numbers", nums, nums.map((_, k) => (k === i ? "read" : k < i ? "done" : "idle"))), keepers()],
              counters: [count("numbers seen", i + 1, n), count("largest ending here", hi), count("smallest ending here", lo), count("best product", best)],
              legend: LEG,
              happened: `${flipped ? `The negative ${x} swaps the keepers first. ` : ""}The largest product ending at index ${i} becomes ${hi}, and the smallest becomes ${lo}.${newBest ? ` That beats the old best ${oldBest}.` : ""}`,
              why: "The two candidates are rebuilt from the better of extending a previous stretch or starting fresh at the current number.",
              codeLine: 8,
            });
          }

          steps.push({
            title: `One pass complete — best product ${best}`,
            tracks: [track("the numbers", nums, fill(n, "done")), keepers()],
            counters: [count("numbers seen", n, n), count("largest ending here", hi), count("smallest ending here", lo), count("best product", best)],
            legend: LEG,
            happened: `The row ended with a largest product of ${hi} ending at the last position and a best product of ${best} overall.`,
            why: "The final keeper need not be the answer; the best value was recorded whenever a larger product appeared.",
            codeLine: 10,
          });

          steps.push({
            title: "One step per number",
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              {
                label: "growth",
                cells: [
                  { v: `${n} numbers`, state: "done", tag: `${Math.max(0, n - 1)} multiplier steps` },
                  { v: `${2 * n} numbers`, state: "active", tag: `${Math.max(0, 2 * n - 1)} multiplier steps` },
                ],
              },
            ],
            counters: [count("numbers seen", n, n), count("cost class", "O(n)")],
            legend: ["done", "active", "dim"],
            happened: `Each number after the first caused one constant-time update: ${n - 1} updates for this row.`,
            why: "Doubling the row doubles the updates, and only three running values are stored — linear time, constant space.",
            codeLine: 5,
          });

          steps.push({
            title: `Answer: maximum product ${best}`,
            tracks: [track("the numbers", nums, fill(n, "result")), keepers()],
            counters: [count("numbers seen", n, n), count("best product", best), count("answer", best)],
            legend: LEG,
            happened: `The largest product of any contiguous stretch is ${best}.`,
            why: "Both sign possibilities were carried at every position, so no future negative could have been missed.",
            codeLine: 12,
          });
          return steps;
        },
      },
      {
        name: "Try Every Stretch",
        complexity: "O(n²) time, O(1) space",
        idea: [
          "Fix the start, then multiply the numbers one at a time towards the right, recording the largest product along the way.",
          "Every contiguous stretch is examined, so the answer cannot be missed — at the price of a quadratic number of stretches.",
        ],
        problem: [
          "The product can grow very quickly and overflow ordinary integer types; even in JavaScript the arithmetic stops being exact for huge values. The one-pass approach has the same issue but does less work before hitting it.",
        ],
        code: {
          c: `#include <stdio.h>

/* every start, every end, product built one factor at a time */
int max_product(const int *a, int n) {
    int best = a[0];
    for (int i = 0; i < n; i++) {
        int prod = 1;
        for (int j = i; j < n; j++) {
            prod *= a[j];
            if (prod > best) best = prod;
        }
    }
    return best;
}

int main(void) {
    int a[] = {2, 3, -2, 4};
    printf("%d\\n", max_product(a, 4)); /* 6 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// all stretches; products built incrementally
int maxProduct(const std::vector<int>& a) {
    int best = a[0];
    for (int i = 0; i < (int)a.size(); ++i) {
        int prod = 1;
        for (int j = i; j < (int)a.size(); ++j) {
            prod *= a[j];
            if (prod > best) best = prod;
        }
    }
    return best;
}

int main() {
    std::cout << maxProduct({2, 3, -2, 4}) << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const total = (n * (n + 1)) / 2;
          const LEG = ["read", "active", "result", "done", "dim", "idle"];
          const steps = [];
          let best = nums[0], bestStart = 0, bestEnd = 0, checked = 0;
          const bestTrack = () => single("best stretch", best, "result", `${nums.slice(bestStart, bestEnd + 1).join(" × ")}`);
          const spanStates = (i, j) =>
            nums.map((_, k) => {
              if (k >= i && k <= j) return k === j ? "read" : "active";
              if (k >= bestStart && k <= bestEnd) return "result";
              return k <= j ? "done" : "idle";
            });

          steps.push({
            title: `Find the largest-product stretch in ${n} numbers`,
            tracks: [track("the numbers", nums, fill(n, "idle")), bestTrack()],
            counters: [count("stretches checked", 0, total), count("best product", best)],
            legend: LEG,
            happened: `The row is ${joinList(nums)}. The first single product ${nums[0]} is the initial best.`,
            why: "Seeding with a real value keeps the answer valid when every product is negative.",
            codeLine: 4,
          });

          steps.push({
            title: "Plan: fix a start, multiply to the right",
            tracks: [track("the numbers", nums, paint(fill(n, "idle"), { 0: "read" })), bestTrack()],
            counters: [count("stretches checked", 0, total), count("best product", best)],
            legend: LEG,
            happened: "For each start i the inner loop grows the stretch one factor at a time, so the running product is always the product of the current span.",
            why: "Building the product incrementally avoids a third loop and keeps each stretch's cost constant.",
            codeLine: 5,
          });

          steps.push({
            title: "Negatives and zeros change the story",
            tracks: [track("the numbers", nums, fill(n, "idle")), bestTrack()],
            counters: [count("stretches checked", 0, total), count("best product", best)],
            legend: LEG,
            happened: "A single negative factor flips the sign of a product, and a zero wipes it out. That is why every stretch must be considered.",
            why: "Unlike sums, products have no simple monotone prefix property, so the exhaustive check is the honest baseline.",
            codeLine: 7,
          });

          steps.push({
            title: `Best starts as the single value ${nums[0]}`,
            tracks: [track("the numbers", nums, spanStates(0, 0)), bestTrack()],
            counters: [count("stretches checked", 0, total), count("best product", best)],
            legend: LEG,
            happened: `The stretch containing only index 0 has product ${best}, so it leads before the loops begin.`,
            why: "A one-element subarray is valid, and it may be the answer if all longer products are smaller.",
            codeLine: 4,
          });

          for (let i = 0; i < n; i++) {
            let prod = 1;
            for (let j = i; j < n; j++) {
              prod *= nums[j];
              checked++;
              const better = prod > best;
              if (better) { best = prod; bestStart = i; bestEnd = j; }
              steps.push({
                title: `Start ${i}, end ${j}: product ${prod}${better ? " (new best)" : ""}`,
                tracks: [track("the numbers", nums, spanStates(i, j)), bestTrack()],
                counters: [count("stretches checked", checked, total), count("current product", prod), count("best product", best)],
                legend: LEG,
                happened: better
                  ? `The stretch from ${i} to ${j} multiplies to ${prod}, a new best.`
                  : `The stretch from ${i} to ${j} multiplies to ${prod}, which does not beat ${best}.`,
                why: better
                  ? "The stored stretch is replaced, so the answer always points at concrete ends."
                  : "Even a losing stretch must be built because adding one more factor can turn it into a winner.",
                codeLine: 8,
              });
            }
          }

          steps.push({
            title: `All ${total} stretches checked — best ${best}`,
            tracks: [
              track("the numbers", nums, nums.map((_, k) => (k >= bestStart && k <= bestEnd ? "result" : "done"))),
              bestTrack(),
            ],
            counters: [count("stretches checked", checked, total), count("best product", best)],
            legend: LEG,
            happened: `Every start and end pair was multiplied out. The best stretch runs from index ${bestStart} to ${bestEnd}.`,
            why: "Exhaustive coverage makes the result exact for the values that fit in the number type.",
            codeLine: 10,
          });

          steps.push({
            title: "Stretch counts grow quadratically",
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              {
                label: "growth",
                cells: [
                  { v: `${n} numbers`, state: "done", tag: `${total} stretches` },
                  { v: `${2 * n} numbers`, state: "active", tag: `${(2 * n) * (2 * n + 1) / 2} stretches` },
                ],
              },
            ],
            counters: [count("stretches checked", checked, total), count("cost class", "O(n²)")],
            legend: ["done", "active", "dim"],
            happened: `${n} numbers produce ${total} stretches; doubling the row produces ${(2 * n) * (2 * n + 1) / 2}.`,
            why: "The incremental product saves a loop but not the pair of ends, so the growth remains quadratic.",
            codeLine: 7,
          });

          steps.push({
            title: `Answer: maximum product ${best}`,
            tracks: [
              track("the numbers", nums, nums.map((_, k) => (k >= bestStart && k <= bestEnd ? "result" : "dim"))),
              bestTrack(),
            ],
            counters: [count("stretches checked", checked, total), count("answer", best)],
            legend: LEG,
            happened: `The largest product is ${best}, from indices ${bestStart} through ${bestEnd}.`,
            why: "The two-extreme method finds the same answer in one pass; this version trades time for simpler reasoning.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "product-of-array-except-self",
    title: "Product of Array Except Self",
    category: "Array Patterns",
    difficulty: "Intermediate",
    description: "Build an output where each position holds the product of every other number.",
    input: { label: "The numbers", default: "1, 2, 3, 4", parse: "ints" },
    approaches: [
      {
        name: "Divide the Total (Mind the Zeros)",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "Multiply all non-zero values into one total, and count how many zeros the row contains. Then each output is a division, with the zero cases handled by hand.",
          "With no zeros, output i is total / a[i]. With exactly one zero, only the zero position gets the total and every other position gets 0. With two or more zeros, every output is 0.",
        ],
        problem: [
          "Division is only safe because the values are integers and the zero cases are spelled out. The method also does not generalise to a mutable product or to non-invertible values, which is why the prefix/suffix method exists.",
        ],
        code: {
          c: `#include <stdio.h>

/* total product of non-zero values, plus how many zeros */
void product_except(const int *a, int n, int *out) {
    int total = 1, zeros = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] == 0) zeros++;
        else total *= a[i];
    }
    for (int i = 0; i < n; i++) {
        if (zeros == 0) out[i] = total / a[i];
        else if (zeros == 1) out[i] = (a[i] == 0) ? total : 0;
        else out[i] = 0;
    }
}

int main(void) {
    int a[] = {1, 2, 3, 4}, out[4];
    product_except(a, 4, out);
    for (int i = 0; i < 4; i++) printf("%d ", out[i]); /* 24 12 8 6 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

std::vector<int> productExceptSelf(const std::vector<int>& a) {
    long long total = 1;
    int zeros = 0;
    for (int x : a) {
        if (x == 0) ++zeros;
        else total *= x;
    }
    std::vector<int> out(a.size());
    for (int i = 0; i < (int)a.size(); ++i) {
        if (zeros == 0) out[i] = (int)(total / a[i]);
        else if (zeros == 1) out[i] = (a[i] == 0) ? (int)total : 0;
        else out[i] = 0;
    }
    return out;
}

int main() {
    for (int x : productExceptSelf({1, 2, 3, 4}))
        std::cout << x << ' ';      // 24 12 8 6
}`,
        },
        steps(nums) {
          const n = nums.length;
          const LEG = ["read", "good", "bad", "done", "result", "idle"];
          const steps = [];
          let zeroCount = 0, total = 1;
          nums.forEach((x) => { if (x === 0) zeroCount++; else total *= x; });
          const outVals = Array(n).fill("—");
          const resultTrack = (upTo) => track("result", outVals, outVals.map((_, i) => (i < upTo ? "done" : i === upTo ? "result" : "idle")));
          const productTrack = () => ({
            label: "product facts",
            cells: [
              { v: total, state: "result", tag: "non-zero product" },
              { v: zeroCount, state: zeroCount > 0 ? "bad" : "done", tag: "zeros" },
            ],
          });

          steps.push({
            title: `Build ${n} outputs from ${n} ${n === 1 ? "number" : "numbers"}`,
            tracks: [
              track("the numbers", nums, fill(n, "idle")),
              track("result", outVals, fill(n, "idle")),
              single("non-zero product", 1, "idle", "starts at 1"),
            ],
            counters: [count("outputs written", 0, n), count("zeros", 0), count("non-zero product", 1)],
            legend: LEG,
            happened: `The input is ${joinList(nums)} and the output row is empty.`,
            why: "Each output position ignores one input number, so a single total product can only work if the ignored number can be divided out.",
            codeLine: 4,
          });

          steps.push({
            title: "Plan: one total, then divide each number out",
            tracks: [
              track("the numbers", nums, fill(n, "idle")),
              track("result", outVals, fill(n, "idle")),
              single("non-zero product", 1, "idle", "starts at 1"),
            ],
            counters: [count("outputs written", 0, n), count("zeros", 0), count("non-zero product", 1)],
            legend: LEG,
            happened: "First the row is scanned for zeros and for the product of all non-zero values. Then each output is computed from that total.",
            why: "Multiplication and division are inverses for non-zero integers, so total / a[i] is exactly the product of everything except a[i].",
            codeLine: 5,
          });

          steps.push({
            title: "The zero cases decide the shape",
            tracks: [
              track("the numbers", nums, fill(n, "idle")),
              track("result", outVals, fill(n, "idle")),
              single("zero rule", "0 → 1 or 0", "active", "see narrative"),
            ],
            counters: [count("outputs written", 0, n), count("zeros", zeroCount), count("non-zero product", total)],
            legend: LEG,
            happened: "No zeros: divide normally. One zero: only the zero position gets the non-zero product. Two or more zeros: every output is zero.",
            why: "Dividing by zero is undefined, so the zero positions must be routed around the division instead of through it.",
            codeLine: 9,
          });

          steps.push({
            title: `First scan: ${zeroCount} ${zeroCount === 1 ? "zero" : "zeros"}, non-zero product ${total}`,
            tracks: [
              track("the numbers", nums, nums.map((x) => (x === 0 ? "bad" : "done"))),
              track("result", outVals, fill(n, "idle")),
              productTrack(),
            ],
            counters: [count("outputs written", 0, n), count("zeros", zeroCount), count("non-zero product", total)],
            legend: LEG,
            happened: `The scan skipped every zero and multiplied the rest into ${total}. It counted ${zeroCount} ${zeroCount === 1 ? "zero" : "zeros"} along the way.`,
            why: "This single pass collects all the information needed to answer every output position without a second multiplication pass per position.",
            codeLine: 6,
          });

          for (let i = 0; i < n; i++) {
            const x = nums[i];
            let val, title;
            if (zeroCount === 0) {
              const raw = total / x;
              val = Number.isFinite(raw) ? Math.round(raw) : raw;
              title = `Skip index ${i} (${x}) → ${total} / ${x} = ${val}`;
            } else if (zeroCount === 1) {
              if (x === 0) {
                val = total;
                title = `The only zero at index ${i} → ${val}`;
              } else {
                val = 0;
                title = `A zero elsewhere makes index ${i} zero`;
              }
            } else {
              val = 0;
              title = `Two or more zeros → index ${i} is 0`;
            }
            outVals[i] = val;
            steps.push({
              title,
              tracks: [
                track("the numbers", nums, nums.map((_, k) => (k < i ? "done" : k === i ? "read" : "idle"))),
                resultTrack(i + 1),
                productTrack(),
              ],
              counters: [count("outputs written", i + 1, n), count("zeros", zeroCount), count("value at index " + i, val)],
              legend: LEG,
              happened:
                zeroCount === 0
                  ? `The total ${total} is divided by ${x}; the other numbers' product is ${val}.`
                  : zeroCount === 1
                    ? (x === 0
                        ? `Index ${i} is the only zero, so its output is the product of all the non-zero values, ${val}.`
                        : `A zero exists somewhere else, so the product of all other values includes that zero and is 0.`)
                    : `Two zeros remain even after skipping index ${i}, so this output must be 0.`,
              why: "Handling the zero count explicitly is what keeps division safe while preserving the single-pass ideal.",
              codeLine: zeroCount === 0 ? 10 : zeroCount === 1 ? 11 : 12,
            });
          }

          steps.push({
            title: "Every output position is written",
            tracks: [
              track("the numbers", nums, fill(n, "done")),
              track("result", outVals, fill(n, "done")),
              productTrack(),
            ],
            counters: [count("outputs written", n, n), count("zeros", zeroCount)],
            legend: LEG,
            happened: `The result row now reads ${outVals.join(", ")}.`,
            why: "One scan for the facts and one scan to write outputs is still linear work, not quadratic.",
            codeLine: 10,
          });

          steps.push({
            title: "Two linear passes, quadratic avoided",
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              {
                label: "growth",
                cells: [
                  { v: `${n} numbers`, state: "done", tag: `about ${2 * n} operations` },
                  { v: `${2 * n} numbers`, state: "active", tag: `about ${4 * n} operations` },
                ],
              },
            ],
            counters: [count("outputs written", n, n), count("cost class", "O(n)")],
            legend: ["done", "active", "dim"],
            happened: `The work is one counting scan plus one output scan: roughly ${2 * n} operations for ${n} numbers.`,
            why: "Doubling the input doubles the operations. The extra space is constant because only a total and a zero count are carried.",
            codeLine: 5,
          });

          steps.push({
            title: `Answer: ${outVals.join(", ")}`,
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              track("result", outVals, fill(n, "result")),
            ],
            counters: [count("outputs written", n, n), count("answer", outVals.join(", "))],
            legend: LEG,
            happened: `The product of everything except position i is written at position i, for all ${n} positions.`,
            why: "The division shortcut gives linear time and constant extra space, provided the zero count is handled exactly as shown.",
            codeLine: 10,
          });
          return steps;
        },
      },
      {
        name: "Prefix × Suffix",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Write into each output the product of everything to its left, using one forward pass. Then walk backwards with a running suffix product and multiply it into each position.",
          "Position i finally holds (product of the left side) × (product of the right side), which is exactly every other element.",
        ],
        problem: [
          "The prefix pass needs an extra row of n products. That is O(n) space, although the output row itself can be reused in some formulations.",
        ],
        code: {
          c: `#include <stdio.h>

void product_except(const int *a, int n, int *out) {
    int prefix = 1;
    for (int i = 0; i < n; i++) {
        out[i] = prefix;          /* product of everything left of i */
        prefix *= a[i];
    }
    int suffix = 1;
    for (int i = n - 1; i >= 0; i--) {
        out[i] *= suffix;         /* times product on the right */
        suffix *= a[i];
    }
}

int main(void) {
    int a[] = {1, 2, 3, 4}, out[4];
    product_except(a, 4, out);
    for (int i = 0; i < 4; i++) printf("%d ", out[i]); /* 24 12 8 6 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

std::vector<int> productExceptSelf(const std::vector<int>& a) {
    int n = (int)a.size();
    std::vector<int> out(n, 1);
    int prefix = 1;
    for (int i = 0; i < n; ++i) {
        out[i] = prefix;        // product strictly left of i
        prefix *= a[i];
    }
    int suffix = 1;
    for (int i = n - 1; i >= 0; --i) {
        out[i] *= suffix;       // times product strictly right of i
        suffix *= a[i];
    }
    return out;
}

int main() {
    for (int x : productExceptSelf({1, 2, 3, 4}))
        std::cout << x << ' ';      // 24 12 8 6
}`,
        },
        steps(nums) {
          const n = nums.length;
          const LEG = ["read", "active", "done", "result", "idle"];
          const steps = [];
          const prefix = Array(n).fill("—");
          const result = Array(n).fill("—");
          const prefixTrack = (upTo) => track("prefix products", prefix, prefix.map((_, i) => (i < upTo ? "done" : i === upTo ? "result" : "idle")));
          const resultTrack = (upTo) => track("result", result, result.map((_, i) => (i > upTo ? "done" : i === upTo ? "result" : "idle")));

          steps.push({
            title: `Build ${n} outputs without division`,
            tracks: [
              track("the numbers", nums, fill(n, "idle")),
              track("prefix products", prefix, fill(n, "idle")),
              track("result", result, fill(n, "idle")),
            ],
            counters: [count("prefix entries", 0, n), count("outputs finished", 0, n)],
            legend: LEG,
            happened: `The input is ${joinList(nums)}. Two rows start empty: the prefix products and the final result.`,
            why: "Avoiding division makes the method work even when the ignored value is zero, at the cost of remembering the left products.",
            codeLine: 3,
          });

          steps.push({
            title: "Plan: left products, then right products",
            tracks: [
              track("the numbers", nums, fill(n, "idle")),
              track("prefix products", prefix, fill(n, "idle")),
              track("result", result, fill(n, "idle")),
            ],
            counters: [count("prefix entries", 0, n), count("outputs finished", 0, n)],
            legend: LEG,
            happened: "The forward pass records what lies left of each position; the backward pass multiplies in what lies right of it.",
            why: "Every position needs both sides. Splitting the product into a left part and a right part avoids ever dividing.",
            codeLine: 4,
          });

          prefix[0] = 1;
          steps.push({
            title: "Prefix[0] = 1 — nothing is left of the first slot",
            tracks: [
              track("the numbers", nums, paint(fill(n, "idle"), { 0: "read" })),
              prefixTrack(0),
              track("result", result, fill(n, "idle")),
            ],
            counters: [count("prefix entries", 1, n), count("outputs finished", 0, n)],
            legend: LEG,
            happened: "The empty product is 1, so the first prefix entry is 1 even before any value is multiplied in.",
            why: "A neutral starting value is what lets the prefix chain begin without a special-case multiplication.",
            codeLine: 5,
          });

          for (let i = 1; i < n; i++) {
            prefix[i] = prefix[i - 1] * nums[i - 1];
            steps.push({
              title: `prefix[${i}] = ${prefix[i - 1]} × ${nums[i - 1]} = ${prefix[i]}`,
              tracks: [
                track("the numbers", nums, nums.map((_, k) => (k < i - 1 ? "done" : k === i - 1 ? "read" : "idle"))),
                prefixTrack(i),
                track("result", result, fill(n, "idle")),
              ],
              counters: [count("prefix entries", i + 1, n), count("outputs finished", 0, n)],
              legend: LEG,
              happened: `The product of everything left of index ${i} is ${prefix[i]}.`,
              why: "Each prefix entry reuses the one before it, so the whole row is built in a single forward pass.",
              codeLine: 6,
            });
          }

          steps.push({
            title: "Now walk from the right with a running suffix",
            tracks: [
              track("the numbers", nums, paint(fill(n, "done"), { [n - 1]: "read" })),
              prefixTrack(n),
              track("result", result, result.map((_, i) => (i === n - 1 ? "read" : "idle"))),
            ],
            counters: [count("prefix entries", n, n), count("outputs finished", 0, n), count("suffix product", 1)],
            legend: LEG,
            happened: "The suffix starts at 1 to the right of the last index, because nothing lies beyond the end of the row.",
            why: "The backward pass will fold the right side into the already-computed prefix values.",
            codeLine: 9,
          });

          let suffix = 1;
          for (let i = n - 1; i >= 0; i--) {
            result[i] = prefix[i] * suffix;
            steps.push({
              title: i === n - 1
                ? `Index ${i}: prefix ${prefix[i]} × empty right = ${result[i]}`
                : `Index ${i}: prefix ${prefix[i]} × suffix ${suffix} = ${result[i]}`,
              tracks: [
                track("the numbers", nums, nums.map((_, k) => (k > i ? "done" : k === i ? "read" : "idle"))),
                prefixTrack(i),
                resultTrack(i),
              ],
              counters: [count("prefix entries", n, n), count("outputs finished", n - i, n), count("suffix product", suffix)],
              legend: LEG,
              happened: `The left product ${prefix[i]} is multiplied by the right product ${suffix}, producing ${result[i]} at index ${i}.`,
              why: "Every other element is exactly the elements to the left times the elements to the right — no value is included twice.",
              codeLine: 10,
            });
            suffix *= nums[i];
          }

          steps.push({
            title: `All ${n} outputs finished`,
            tracks: [
              track("the numbers", nums, fill(n, "done")),
              prefixTrack(n),
              track("result", result, fill(n, "done")),
            ],
            counters: [count("prefix entries", n, n), count("outputs finished", n, n)],
            legend: LEG,
            happened: `The result row reads ${result.join(", ")}.`,
            why: "Both passes did constant work per position, and the result row holds one output per input number.",
            codeLine: 10,
          });

          steps.push({
            title: "Two linear passes, no division",
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              {
                label: "growth",
                cells: [
                  { v: `${n} numbers`, state: "done", tag: `2 × ${n} positions` },
                  { v: `${2 * n} numbers`, state: "active", tag: `2 × ${2 * n} positions` },
                ],
              },
            ],
            counters: [count("outputs finished", n, n), count("cost class", "O(n)")],
            legend: ["done", "active", "dim"],
            happened: `The forward and backward passes each touch ${n} positions, so the work is linear and the prefix row adds n stored values.`,
            why: "Avoiding division costs memory but buys a method that behaves correctly with zeros and other non-invertible values.",
            codeLine: 5,
          });

          steps.push({
            title: `Answer: ${result.join(", ")}`,
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              track("result", result, fill(n, "result")),
            ],
            counters: [count("outputs finished", n, n), count("answer", result.join(", "))],
            legend: LEG,
            happened: `Each output is the product of every input except the one at the same index.`,
            why: "The prefix/suffix split computes the same product as division, without ever assuming that a value can be divided out.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "majority-element",
    title: "Majority Element",
    category: "Array Patterns",
    difficulty: "Intermediate",
    description: "Find a value that appears more than half the time, by voting or by counting every distinct value.",
    input: { label: "The numbers", default: "2, 2, 1, 1, 1, 2, 2", parse: "ints" },
    approaches: [
      {
        name: "Boyer–Moore Voting",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Keep a candidate and a vote count. A new value that matches the candidate adds a vote; a different value cancels one vote.",
          "Whenever the count reaches zero the next value becomes the candidate. After the pass, count the candidate's real occurrences to confirm it truly has a majority.",
        ],
        problem: [
          "The survivor is not automatically a majority — a row with no majority still produces some candidate. The verification pass is mandatory, which means two linear scans instead of one.",
        ],
        code: {
          c: `#include <stdio.h>

/* candidate from cancellations, then a real count */
int majority(const int *a, int n) {
    int candidate = 0, votes = 0;
    for (int i = 0; i < n; i++) {
        if (votes == 0) {
            candidate = a[i];
            votes = 1;
        } else if (a[i] == candidate) {
            votes++;
        } else {
            votes--;
        }
    }
    int count = 0;
    for (int i = 0; i < n; i++)
        if (a[i] == candidate) count++;
    return (count > n / 2) ? candidate : -1;
}

int main(void) {
    int a[] = {2, 2, 1, 1, 1, 2, 2};
    printf("%d\\n", majority(a, 7)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// cancel different values, then verify the survivor
int majority(const std::vector<int>& a) {
    int candidate = 0, votes = 0;
    for (int x : a) {
        if (votes == 0) { candidate = x; votes = 1; }
        else if (x == candidate) ++votes;
        else --votes;
    }
    int count = 0;
    for (int x : a)
        if (x == candidate) ++count;
    return (count > (int)a.size() / 2) ? candidate : -1;
}

int main() {
    std::cout << majority({2, 2, 1, 1, 1, 2, 2}) << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const threshold = Math.floor(n / 2) + 1;
          const LEG = ["read", "active", "good", "bad", "done", "result", "idle"];
          const steps = [];
          let candidate = null, votes = 0;
          const voteTrack = () => ({
            label: "vote",
            cells: [
              { v: candidate == null ? "—" : candidate, state: candidate == null ? "idle" : "active", tag: "candidate" },
              { v: votes, state: votes > 0 ? "result" : "idle", tag: "votes" },
              { v: threshold, state: "done", tag: "need to win" },
            ],
          });

          steps.push({
            title: `Find the value that must appear at least ${threshold} times`,
            tracks: [track("the numbers", nums, fill(n, "idle")), voteTrack()],
            counters: [count("numbers read", 0, n), count("votes", 0), count("needed for majority", threshold)],
            legend: LEG,
            happened: `The row is ${joinList(nums)}. A majority needs strictly more than half of ${n}, which is ${threshold} copies.`,
            why: "The target is a frequency, not a position, so the algorithm must reason about counts across the whole row.",
            codeLine: 3,
          });

          steps.push({
            title: "What would count as a majority",
            tracks: [track("the numbers", nums, fill(n, "idle")), voteTrack()],
            counters: [count("numbers read", 0, n), count("votes", 0), count("needed for majority", threshold)],
            legend: LEG,
            happened: `With ${n} numbers, ${threshold} copies guarantee a majority. Exactly ${Math.floor(n / 2)} copies are not enough.`,
            why: "The strict comparison count > n/2 is what makes the boundary cases behave for odd and even lengths.",
            codeLine: 17,
          });

          steps.push({
            title: "Plan: pair off different values",
            tracks: [track("the numbers", nums, fill(n, "idle")), voteTrack()],
            counters: [count("numbers read", 0, n), count("votes", 0), count("needed for majority", threshold)],
            legend: LEG,
            happened: "Each matching value adds a vote, and each different value removes one. When no votes remain, the next value becomes the candidate.",
            why: "Different values cancel each other. A true majority cannot be completely cancelled, so it survives as the final candidate.",
            codeLine: 5,
          });

          for (let i = 0; i < n; i++) {
            const x = nums[i];
            let note;
            if (votes === 0) {
              candidate = x;
              votes = 1;
              note = `no votes left → ${x} becomes candidate`;
            } else if (x === candidate) {
              votes++;
              note = `${x} supports ${candidate} → ${votes} votes`;
            } else {
              votes--;
              note = `${x} cancels one vote → ${votes} left`;
            }
            steps.push({
              title: `Read ${x}: ${note}`,
              tracks: [track("the numbers", nums, nums.map((_, k) => (k === i ? "read" : k < i ? "done" : "idle"))), voteTrack()],
              counters: [count("numbers read", i + 1, n), count("candidate", candidate), count("votes", votes)],
              legend: LEG,
              happened: `At index ${i} the value ${x} ${votes === 0 && x !== candidate ? "empties the vote count" : "is processed"}: the candidate is ${candidate} with ${votes} ${votes === 1 ? "vote" : "votes"}.`,
              why: votes === 0
                ? "With no support left, the old candidate is irrelevant; a fresh one starts from this position."
                : (x === candidate
                    ? "A matching value strengthens the candidate instead of cancelling it."
                    : "A different value removes one vote, reflecting a pair that cancels out."),
              codeLine: votes === 0 ? 7 : x === candidate ? 10 : 12,
            });
          }

          steps.push({
            title: "The survivor is only a candidate",
            tracks: [track("the numbers", nums, fill(n, "idle")), voteTrack()],
            counters: [count("numbers read", n, n), count("candidate", candidate), count("votes", votes)],
            legend: LEG,
            happened: `The pass leaves ${candidate} with ${votes} ${votes === 1 ? "vote" : "votes"}, but votes are not copies — cancellations can leave a minority survivor.`,
            why: "The voting phase proves nothing about frequency on its own, so the candidate must be counted against the real row.",
            codeLine: 15,
          });

          const realCount = nums.filter((x) => x === candidate).length;
          steps.push({
            title: `Verify: ${candidate} appears ${realCount} of ${n} times`,
            tracks: [
              track("the numbers", nums, nums.map((x) => (x === candidate ? "good" : "dim"))),
              voteTrack(),
            ],
            counters: [count("numbers read", n, n), count("copies of candidate", realCount, n), count("needed for majority", threshold)],
            legend: LEG,
            happened: `A full count finds ${realCount} copies of ${candidate}. The bar for a majority is ${threshold}.`,
            why: "This second scan is the difference between a guess and a proof; skipping it gives wrong answers whenever no majority exists.",
            codeLine: 17,
          });

          steps.push({
            title: "Two linear scans, constant space",
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              {
                label: "growth",
                cells: [
                  { v: `${n} numbers`, state: "done", tag: `about ${2 * n} reads` },
                  { v: `${2 * n} numbers`, state: "active", tag: `about ${4 * n} reads` },
                ],
              },
            ],
            counters: [count("numbers read", n, n), count("cost class", "O(n)")],
            legend: ["done", "active", "dim"],
            happened: `The voting pass and the verification pass each read the row once, so ${n} numbers cost about ${2 * n} reads.`,
            why: "Doubling the row doubles the work, and the algorithm stores only a candidate and a vote count.",
            codeLine: 15,
          });

          steps.push({
            title: realCount >= threshold
              ? `Answer: ${candidate} is the majority (${realCount} of ${n})`
              : `Answer: no majority — ${candidate} has only ${realCount} of ${n}`,
            tracks: [
              track("the numbers", nums, nums.map((x) => (x === candidate && realCount >= threshold ? "result" : "dim"))),
              voteTrack(),
            ],
            counters: [count("copies of candidate", realCount, n), count("answer", realCount >= threshold ? candidate : "no majority")],
            legend: LEG,
            happened: realCount >= threshold
              ? `${candidate} appears ${realCount} times, which is more than half of ${n}.`
              : `${candidate} appears only ${realCount} times, so no value has a majority.`,
            why: "The answer is only reported after the real count confirms it, so the cancellation phase cannot produce a false majority.",
            codeLine: 18,
          });
          return steps;
        },
      },
      {
        name: "Count Every Distinct Value",
        complexity: "O(n²) time, O(1) space",
        idea: [
          "Collect the distinct values, then count how many times each one appears by scanning the row. The first value above the majority threshold is the answer.",
          "This is the straightforward definition of majority, written as nested scans.",
        ],
        problem: [
          "With many distinct values the work approaches n². It also re-reads the same positions for every candidate, which is exactly the repetition Boyer–Moore avoids.",
        ],
        code: {
          c: `#include <stdio.h>

/* count every distinct value against the whole row */
int majority(const int *a, int n) {
    for (int i = 0; i < n; i++) {
        int count = 1;
        for (int j = i + 1; j < n; j++)
            if (a[j] == a[i]) count++;
        if (count > n / 2) return a[i];
    }
    return -1;
}

int main(void) {
    int a[] = {2, 2, 1, 1, 1, 2, 2};
    printf("%d\\n", majority(a, 7)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// each starting position counts its value across the row
int majority(const std::vector<int>& a) {
    int n = (int)a.size();
    for (int i = 0; i < n; ++i) {
        int count = 1;
        for (int j = i + 1; j < n; ++j)
            if (a[j] == a[i]) ++count;
        if (count > n / 2) return a[i];
    }
    return -1;
}

int main() {
    std::cout << majority({2, 2, 1, 1, 1, 2, 2}) << '\\n';
}`,
        },
        steps(nums) {
          const n = nums.length;
          const threshold = Math.floor(n / 2) + 1;
          const distinct = [...new Set(nums)];
          const LEG = ["good", "bad", "done", "result", "dim", "idle"];
          const steps = [];
          const seen = [];
          let found = null;

          const tallyTrack = () => ({
            label: "tallies",
            cells: seen.length
              ? seen.map(([v, c]) => ({ v: `${v}×${c}`, state: c >= threshold ? "result" : "done" }))
              : [{ v: "∅", state: "idle", empty: true }],
          });

          steps.push({
            title: `Find the value that must appear at least ${threshold} times`,
            tracks: [track("the numbers", nums, fill(n, "idle")), tallyTrack()],
            counters: [count("candidates checked", 0, distinct.length), count("needed for majority", threshold)],
            legend: LEG,
            happened: `The row is ${joinList(nums)}. A majority needs strictly more than half of ${n}, which is ${threshold} copies.`,
            why: "The brute-force version starts from the definition: count each value and compare its count with the threshold.",
            codeLine: 3,
          });

          steps.push({
            title: "What would count as a majority",
            tracks: [track("the numbers", nums, fill(n, "idle")), tallyTrack()],
            counters: [count("candidates checked", 0, distinct.length), count("needed for majority", threshold)],
            legend: LEG,
            happened: `Exactly ${Math.floor(n / 2)} copies are not a majority; ${threshold} copies are.`,
            why: "The strict boundary matters for even-length rows and for rows with no majority at all.",
            codeLine: 7,
          });

          steps.push({
            title: `Plan: count each of the ${distinct.length} distinct values`,
            tracks: [track("the numbers", nums, fill(n, "idle")), tallyTrack()],
            counters: [count("candidates checked", 0, distinct.length), count("needed for majority", threshold)],
            legend: LEG,
            happened: `The distinct values are ${joinList(distinct)}. Each one will be counted across the whole row.`,
            why: "Checking only one occurrence per value avoids repeating the same count, although the inner scan still costs n each time.",
            codeLine: 4,
          });

          steps.push({
            title: "A majority may simply not exist",
            tracks: [track("the numbers", nums, fill(n, "idle")), tallyTrack()],
            counters: [count("candidates checked", 0, distinct.length), count("needed for majority", threshold)],
            legend: LEG,
            happened: "If every tally stays below the threshold, the correct answer is 'none', not the largest tally.",
            why: "The scan must therefore finish without a hit instead of automatically returning the most common value.",
            codeLine: 8,
          });

          for (let ci = 0; ci < distinct.length; ci++) {
            const v = distinct[ci];
            const countV = nums.filter((x) => x === v).length;
            seen.push([v, countV]);
            if (countV >= threshold && found == null) found = v;
            steps.push({
              title: `Value ${v} appears ${countV} ${countV === 1 ? "time" : "times"}`,
              tracks: [
                track("the numbers", nums, nums.map((x) => (x === v ? "good" : "bad"))),
                tallyTrack(),
              ],
              counters: [count("candidates checked", ci + 1, distinct.length), count("copies of " + v, countV, n), count("needed for majority", threshold)],
              legend: LEG,
              happened: `${v} has ${countV} ${countV === 1 ? "copy" : "copies"} in the row. That is ${countV >= threshold ? "enough" : "not enough"} for a majority.`,
              why: countV >= threshold
                ? "The threshold is reached, so no other value can also be a majority."
                : "The count is recorded and the scan moves to the next distinct value.",
              codeLine: 5,
            });
          }

          steps.push({
            title: `Check the tallies against ${threshold}`,
            tracks: [
              track("the numbers", nums, fill(n, "done")),
              tallyTrack(),
            ],
            counters: [count("candidates checked", distinct.length, distinct.length), count("needed for majority", threshold)],
            legend: LEG,
            happened: `The tallies are ${seen.map(([v, c]) => `${v}×${c}`).join(", ")}.`,
            why: "Comparing every tally with the same threshold turns the frequency data into a final verdict.",
            codeLine: 6,
          });

          steps.push({
            title: "Distinct × row is quadratic",
            tracks: [
              track("the numbers", nums, fill(n, "dim")),
              {
                label: "growth",
                cells: [
                  { v: `${n} numbers`, state: "done", tag: `up to ${n} scans of ${n}` },
                  { v: `${2 * n} numbers`, state: "active", tag: `up to ${2 * n} scans of ${2 * n}` },
                ],
              },
            ],
            counters: [count("candidates checked", distinct.length), count("cost class", "O(n²)")],
            legend: ["done", "active", "dim"],
            happened: `There are ${distinct.length} distinct values, and each count scans up to ${n} positions.`,
            why: "Doubling the row can roughly quadruple the comparisons, which is the quadratic behaviour Boyer–Moore removes.",
            codeLine: 4,
          });

          steps.push({
            title: found != null
              ? `Answer: ${found} is the majority (${seen.find(([v]) => v === found)[1]} of ${n})`
              : "Answer: no majority exists",
            tracks: [
              track("the numbers", nums, nums.map((x) => (found != null && x === found ? "result" : "dim"))),
              tallyTrack(),
            ],
            counters: [count("candidates checked", distinct.length, distinct.length), count("answer", found != null ? found : "no majority")],
            legend: LEG,
            happened: found != null
              ? `${found} is the only value with at least ${threshold} copies.`
              : `No value reached ${threshold} copies, so the row has no majority.`,
            why: "Counting every distinct value is exhaustive and easy to trust, but the repeated scans are why it is the slow approach.",
            codeLine: 8,
          });
          return steps;
        },
      },
    ],
  });
})();
