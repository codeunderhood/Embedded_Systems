/* ============================================================
   DSA Visuals — Backtracking II
   Grids, colours, words and sums. The same choose-explore-undo
   pattern drives all seven searches.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const nums = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number);
  const show = (a) => `[${a.join(", ")}]`;

  /* ---------------------------------------------------------- */
  V.register({
    id: "n-queens-ii",
    title: "N-Queens II",
    category: "Backtracking",
    difficulty: "Advanced",
    description:
      "Count how many ways n queens can be placed safely, without storing the boards themselves.",
    input: { label: "board size n", default: "4", parse: "int" },
    approaches: [
      {
        name: "Count With Three Blocked Sets",
        complexity: "O(n!) search, O(n) space",
        idea: [
          "Place one queen per row. Track used columns and both diagonal families.",
          "Each complete placement adds one to the count; the board itself is never stored.",
        ],
        problem: [
          "Diagonal identity needs row − col and row + col, not just row + col; one family is not enough.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint n, cols[16], d1[32], d2[32];\n\nint place(int row) {\n    if (row == n) return 1;\n\n    int total = 0;\n    for (int col = 0; col < n; col++) {\n        if (cols[col] || d1[row - col + n] || d2[row + col]) continue;\n        cols[col] = d1[row - col + n] = d2[row + col] = 1;\n        total += place(row + 1);\n        cols[col] = d1[row - col + n] = d2[row + col] = 0;\n    }\n    return total;\n}\n\nint main(void) {\n    n = 4;\n    printf(\"%d\\\\n\", place(0)); /* 2 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <unordered_set>\nusing namespace std;\n\nint n, total = 0;\nunordered_set<int> cols, diag1, diag2;\n\nvoid place(int row) {\n    if (row == n) { total++; return; }\n\n    for (int col = 0; col < n; col++) {\n        if (cols.count(col) || diag1.count(row - col) || diag2.count(row + col)) continue;\n        cols.insert(col); diag1.insert(row - col); diag2.insert(row + col);\n        place(row + 1);\n        cols.erase(col); diag1.erase(row - col); diag2.erase(row + col);\n    }\n}\n\nint main() {\n    n = 4;\n    place(0);\n    cout << total << '\\\\n'; // 2\n}`,
        },
        steps(nRaw) {
          const n = Math.max(1, Math.min(7, parseInt(nRaw, 10) || 1));
          const steps = [];
          const queens = Array(n).fill(-1);
          const cols = new Set();
          const d1 = new Set();
          const d2 = new Set();
          let solutions = 0;
          let budget = 30;
          steps.push({
            title: `Count safe ${n}-queen placements`,
            tracks: [chips("columns", Array.from({ length: n }, (_, i) => i), "dim"), chips("queens", ["—"], "dim")],
            counters: [count("row", 0, n), count("solutions", 0)],
            legend: LEG,
            happened: "Only the count is required, so no board is stored.",
            why: "The recursion returns the number of completions of each branch.",
            codeLine: 3,
          });
          const record = (st) => { if (budget > 0) { steps.push(st); budget--; } };
          const place = (row) => {
            if (row === n) { solutions++; return 1; }
            let total = 0;
            for (let col = 0; col < n; col++) {
              if (cols.has(col) || d1.has(row - col) || d2.has(row + col)) continue;
              queens[row] = col;
              cols.add(col); d1.add(row - col); d2.add(row + col);
              record({
                title: `Row ${row}: column ${col} is safe`,
                tracks: [
                  chips("queens (row:col)", queens.slice(0, row + 1).map((c, r) => `${r}:${c}`), (i) => (i === row ? "active" : "done")),
                  chips("blocked columns", [...cols].sort((x, y) => x - y), "bad"),
                  chips("diagonals", [`r−c ${row - col}`, `r+c ${row + col}`], "bad"),
                ],
                counters: [count("row", row + 1, n), count("solutions", solutions)],
                legend: LEG,
                happened: `Column ${col} and its two diagonals are now blocked.`,
                why: "A queen is safe when none of the three sets contains its position.",
                codeLine: 8,
              });
              total += place(row + 1);
              queens[row] = -1;
              cols.delete(col); d1.delete(row - col); d2.delete(row + col);
              record({
                title: `Undo row ${row}, column ${col}`,
                tracks: [chips("queens (row:col)", queens.slice(0, row).map((c, r) => `${r}:${c}`), "dim"), chips("blocked columns", [...cols].sort((x, y) => x - y), "dim")],
                counters: [count("row", row, n), count("solutions", solutions)],
                legend: LEG,
                happened: "The queen is removed so the next column can be tried.",
                why: "The count from this branch has already been added.",
                codeLine: 11,
              });
            }
            return total;
          };
          place(0);
          steps.push({
            title: `Answer: ${solutions} solution${solutions === 1 ? "" : "s"}`,
            tracks: [chips("answer", [solutions], "result")],
            counters: [count("solutions", solutions), count("size", n)],
            legend: LEG,
            happened: `The search counted ${solutions} complete placements.`,
            why: "No board was stored, only three small sets and a counter.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "sudoku-solver",
    title: "Sudoku Solver",
    category: "Backtracking",
    difficulty: "Advanced",
    description:
      "Fill a 9×9 grid so every row, column and 3×3 box contains each digit once.",
    input: {
      label: "9 rows of digits, 0 for blanks",
      default:
        "5,3,0,0,7,0,0,0,0 | 6,0,0,1,9,5,0,0,0 | 0,9,8,0,0,0,0,6,0 | 8,0,0,0,6,0,0,0,3 | 4,0,0,8,0,3,0,0,1 | 7,0,0,0,2,0,0,0,6 | 0,6,0,0,0,0,2,8,0 | 0,0,0,4,1,9,0,0,5 | 0,0,0,0,8,0,0,7,9",
      parse: "string",
    },
    approaches: [
      {
        name: "First Blank, Digits 1 to 9",
        complexity: "O(9^blanks) worst case",
        idea: [
          "Find the first empty cell and try digits 1 to 9 in order.",
          "A digit is allowed only if it is absent from its row, column and 3×3 box. Recurse on the next blank; undo if no digit works.",
        ],
        problem: [
          "Scanning the full row, column and box for every attempt is the main cost; bitsets make each check constant time.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint g[9][9] = {\n    {5,3,0,0,7,0,0,0,0}, {6,0,0,1,9,5,0,0,0}, {0,9,8,0,0,0,0,6,0},\n    {8,0,0,0,6,0,0,0,3}, {4,0,0,8,0,3,0,0,1}, {7,0,0,0,2,0,0,0,6},\n    {0,6,0,0,0,0,2,8,0}, {0,0,0,4,1,9,0,0,5}, {0,0,0,0,8,0,0,7,9}\n};\n\nint allowed(int r, int c, int v) {\n    for (int i = 0; i < 9; i++)\n        if (g[r][i] == v || g[i][c] == v) return 0;\n\n    int br = r - r % 3, bc = c - c % 3;\n    for (int i = 0; i < 3; i++)\n        for (int j = 0; j < 3; j++)\n            if (g[br + i][bc + j] == v) return 0;\n    return 1;\n}\n\nint solve(void) {\n    for (int r = 0; r < 9; r++)\n        for (int c = 0; c < 9; c++) {\n            if (g[r][c]) continue;\n            for (int v = 1; v <= 9; v++) {\n                if (!allowed(r, c, v)) continue;\n                g[r][c] = v;\n                if (solve()) return 1;\n                g[r][c] = 0;                 /* undo */\n            }\n            return 0;\n        }\n    return 1;\n}\n\nint main(void) {\n    solve();\n    printf("%d\\\\n", g[0][0]); /* 5 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nbool allowed(vector<vector<char>>& g, int r, int c, char v) {\n    for (int i = 0; i < 9; i++)\n        if (g[r][i] == v || g[i][c] == v) return false;\n\n    int br = r - r % 3, bc = c - c % 3;\n    for (int i = 0; i < 3; i++)\n        for (int j = 0; j < 3; j++)\n            if (g[br + i][bc + j] == v) return false;\n    return true;\n}\n\nbool solve(vector<vector<char>>& g) {\n    for (int r = 0; r < 9; r++)\n        for (int c = 0; c < 9; c++) {\n            if (g[r][c] != '.') continue;\n            for (char v = '1'; v <= '9'; v++) {\n                if (!allowed(g, r, c, v)) continue;\n                g[r][c] = v;\n                if (solve(g)) return true;\n                g[r][c] = '.';\n            }\n            return false;\n        }\n    return true;\n}\n\nint main() {\n    vector<vector<char>> g(9, vector<char>(9, '.'));\n    // fill the puzzle, then solve(g)\n    return 0;\n}`,
        },
        steps(text) {
          const rows = parts(text).map((r) => r.split(/[\s,]+/).filter(Boolean).map((v) => parseInt(v, 10) || 0)).filter((r) => r.length);
          const g = Array.from({ length: 9 }, (_, r) => Array.from({ length: 9 }, (_, c) => (rows[r] && rows[r][c]) || 0));
          const steps = [];
          const blanks = g.flat().filter((v) => v === 0).length;
          steps.push({
            title: `${blanks} blank cells to fill`,
            kind: "grid", rows: 9, cols: 9,
            cells: grid(9, 9, (r, c) => ({ v: g[r][c] || "·", state: g[r][c] ? "idle" : "dim" })),
            counters: [count("blanks", blanks), count("filled", 81 - blanks)],
            legend: LEG,
            happened: "Given digits are never changed.",
            why: "Only blank cells are choices for the search.",
            codeLine: 12,
          });
          const allowed = (r, c, v) => {
            for (let i = 0; i < 9; i++) if (g[r][i] === v || g[i][c] === v) return false;
            const br = r - (r % 3), bc = c - (c % 3);
            for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) if (g[br + i][bc + j] === v) return false;
            return true;
          };
          let budget = 34;
          const record = (st) => { if (budget > 0) { steps.push(st); budget--; } };
          const solve = () => {
            for (let r = 0; r < 9; r++) {
              for (let c = 0; c < 9; c++) {
                if (g[r][c]) continue;
                const tried = [];
                for (let v = 1; v <= 9; v++) {
                  if (!allowed(r, c, v)) { tried.push(`${v}✗`); continue; }
                  g[r][c] = v;
                  record({
                    title: `Set (${r}, ${c}) = ${v}`,
                    kind: "grid", rows: 9, cols: 9,
                    cells: grid(9, 9, (rr, cc) => {
                      const fixed = rows[rr] && rows[rr][cc];
                      const here = rr === r && cc === c;
                      return { v: g[rr][cc] || "·", state: here ? "active" : fixed ? "idle" : g[rr][cc] ? "done" : "dim" };
                    }),
                    counters: [count("cell", `(${r},${c})`), count("blanks left", g.flat().filter((x) => x === 0).length)],
                    legend: LEG,
                    happened: `${v} does not clash with its row, column or box.`,
                    why: "The first blank is always chosen, so the search is deterministic.",
                    codeLine: 18,
                  });
                  if (solve()) return true;
                  g[r][c] = 0;
                  record({
                    title: `Undo (${r}, ${c}) = ${v}`,
                    kind: "grid", rows: 9, cols: 9,
                    cells: grid(9, 9, (rr, cc) => {
                      const here = rr === r && cc === c;
                      return { v: g[rr][cc] || "·", state: here ? "bad" : g[rr][cc] ? "done" : "dim" };
                    }),
                    counters: [count("cell", `(${r},${c})`), count("tried", tried.join(" "))],
                    legend: LEG,
                    happened: "Every later digit led to a dead end, so this choice is reversed.",
                    why: "Backtracking guarantees earlier decisions can be revised.",
                    codeLine: 21,
                  });
                }
                return false;
              }
            }
            return true;
          };
          solve();
          steps.push({
            title: "Answer: solved grid",
            kind: "grid", rows: 9, cols: 9,
            cells: grid(9, 9, (r, c) => ({ v: g[r][c] || "·", state: g[r][c] ? "result" : "bad" })),
            counters: [count("filled", g.flat().filter((v) => v !== 0).length), count("blanks left", g.flat().filter((v) => v === 0).length)],
            legend: LEG,
            happened: "Every row, column and box contains 1 to 9 exactly once.",
            why: "The search only accepts digits that keep all three constraints true.",
            codeLine: 25,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "rat-in-a-maze",
    title: "Rat in a Maze",
    category: "Backtracking",
    difficulty: "Intermediate",
    description:
      "Find a route from the top-left to the bottom-right of a maze, moving only through open cells.",
    input: { label: "maze rows of 0/1 (1 = open)", default: "1,0,0,0 | 1,1,0,1 | 0,1,0,0 | 1,1,1,1", parse: "string" },
    approaches: [
      {
        name: "Depth-First With an Undo",
        complexity: "O(cells × 4^cells) worst case",
        idea: [
          "From the current cell, try moving down and right into open, unvisited cells.",
          "Mark the cell on the path before recursing. If neither direction reaches the goal, unmark it and let another route through.",
        ],
        problem: [
          "A visited mark that is never removed turns the maze into a one-shot path; the search must undo it on failure.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint maze[4][4] = {{1,0,0,0},{1,1,0,1},{0,1,0,0},{1,1,1,1}};\nint path[4][4];\n\nint walk(int r, int c) {\n    if (r < 0 || r > 3 || c < 0 || c > 3) return 0;\n    if (!maze[r][c] || path[r][c]) return 0;\n    if (r == 3 && c == 3) { path[r][c] = 1; return 1; }\n\n    path[r][c] = 1;\n    if (walk(r + 1, c) || walk(r, c + 1)) return 1;\n    path[r][c] = 0;                       /* backtrack */\n    return 0;\n}\n\nint main(void) {\n    printf("%d\\\\n", walk(0, 0)); /* 1 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint dr[] = {1, 0}, dc[] = {0, 1};\n\nbool walk(vector<vector<int>>& m, int r, int c, vector<vector<int>>& path) {\n    if (r < 0 || r >= (int)m.size() || c < 0 || c >= (int)m[0].size()) return false;\n    if (!m[r][c] || path[r][c]) return false;\n    path[r][c] = 1;\n    if (r == (int)m.size() - 1 && c == (int)m[0].size() - 1) return true;\n\n    for (int d = 0; d < 2; d++)\n        if (walk(m, r + dr[d], c + dc[d], path)) return true;\n\n    path[r][c] = 0;\n    return false;\n}\n\nint main() {\n    vector<vector<int>> m{{1,0,0,0},{1,1,0,1},{0,1,0,0},{1,1,1,1}};\n    vector<vector<int>> path(4, vector<int>(4, 0));\n    cout << walk(m, 0, 0, path) << '\\\\n'; // 1\n}`,
        },
        steps(text) {
          const rows = parts(text).map((r) => r.split(/[\s,]+/).filter(Boolean).map(Number)).filter((r) => r.length);
          if (!rows.length) {
            return [{
              title: "Give maze rows of 0s and 1s",
              tracks: [chips("maze", ["—"], "idle")],
              counters: [count("cells", 0)],
              legend: ["idle", "result"],
              happened: "1 marks an open cell and 0 a wall.",
              why: "The route may only pass through open cells.",
            }];
          }
          const R = Math.min(8, rows.length), C = Math.min(8, Math.max(...rows.map((r) => r.length)));
          const m = Array.from({ length: R }, (_, r) => Array.from({ length: C }, (_, c) => (rows[r] && rows[r][c] ? 1 : 0)));
          m[0][0] = 1;
          const steps = [];
          const path = Array.from({ length: R }, () => Array(C).fill(false));
          const cells = Array.from({ length: R }, () => Array(C).fill(false));
          let found = false, budget = 36;
          const render = (active, bad) =>
            grid(R, C, (r, c) => {
              const isActive = active && active[0] === r && active[1] === c;
              const isBad = bad && bad[0] === r && bad[1] === c;
              return {
                v: m[r][c] ? (path[r][c] ? "•" : "1") : "0",
                state: isBad ? "bad" : isActive ? "read" : path[r][c] ? "result" : m[r][c] ? "idle" : "dim",
              };
            });
          steps.push({
            title: `Start at (0, 0); goal is (${R - 1}, ${C - 1})`,
            kind: "grid", rows: R, cols: C,
            cells: render([0, 0]),
            counters: [count("path length", 0), count("open cells", m.flat().filter((v) => v).length)],
            legend: LEG,
            happened: "Only down and right moves are considered.",
            why: "A monotone route never needs to revisit a row or column.",
            codeLine: 6,
          });
          const record = (st) => { if (budget > 0) { steps.push(st); budget--; } };
          const walk = (r, c) => {
            if (r < 0 || r >= R || c < 0 || c >= C) return false;
            if (!m[r][c] || path[r][c]) return false;
            path[r][c] = true;
            cells[r][c] = true;
            if (r === R - 1 && c === C - 1) {
              record({
                title: `Reached the goal at (${r}, ${c})`,
                kind: "grid", rows: R, cols: C,
                cells: render([r, c]),
                counters: [count("path length", path.flat().filter((v) => v).length), count("answer", "found")],
                legend: LEG,
                happened: "The route is complete.",
                why: "Every move stayed inside an open, unvisited cell.",
                codeLine: 8,
              });
              return true;
            }
            record({
              title: `Step into (${r}, ${c})`,
              kind: "grid", rows: R, cols: C,
              cells: render([r, c]),
              counters: [count("path length", path.flat().filter((v) => v).length), count("position", `(${r},${c})`)],
              legend: LEG,
              happened: "The cell is open and not on the current path.",
              why: "Marking it prevents the route from looping.",
              codeLine: 11,
            });
            if (walk(r + 1, c) || walk(r, c + 1)) return true;
            path[r][c] = false;
            cells[r][c] = false;
            record({
              title: `Dead end at (${r}, ${c}); step back`,
              kind: "grid", rows: R, cols: C,
              cells: render(null, [r, c]),
              counters: [count("path length", path.flat().filter((v) => v).length), count("position", `(${r},${c})`)],
              legend: LEG,
              happened: "Neither down nor right continues the route.",
              why: "Unmarking lets a different route use this cell.",
              codeLine: 13,
            });
            return false;
          };
          found = walk(0, 0);
          steps.push({
            title: found ? "Answer: a route exists" : "Answer: no route exists",
            kind: "grid", rows: R, cols: C,
            cells: grid(R, C, (r, c) => ({ v: m[r][c] ? (path[r][c] ? "•" : "1") : "0", state: found && path[r][c] ? "result" : m[r][c] ? "dim" : "bad" })),
            counters: [count("answer", found ? "yes" : "no"), count("path length", path.flat().filter((v) => v).length)],
            legend: LEG,
            happened: found ? "The marked cells form the route." : "The search exhausted every reachable open cell.",
            why: "The goal is reachable only if an open chain connects it to the start.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "m-coloring-problem",
    title: "M-Coloring Problem",
    category: "Backtracking",
    difficulty: "Advanced",
    description:
      "Colour every vertex with one of m colours so that no edge joins two vertices of the same colour.",
    input: { label: "adjacency rows | m", default: "0,1,1,1 | 1,0,1,0 | 1,1,0,1 | 1,0,1,0 | 3", parse: "string" },
    approaches: [
      {
        name: "Colour One Vertex at a Time",
        complexity: "O(mⁿ) worst case",
        idea: [
          "Give vertex 0 a colour, then move to the next vertex. A colour is legal only if no coloured neighbour has it.",
          "If no colour works for some vertex, undo the previous vertex's colour and try its next colour.",
        ],
        problem: [
          "A complete assignment of all vertices is required; stopping at the last colourable vertex misses conflicts.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint adj[4][4] = {{0,1,1,1},{1,0,1,0},{1,1,0,1},{1,0,1,0}};\nint color[4], n = 4, m = 3;\n\nint safe(int v, int c) {\n    for (int u = 0; u < n; u++) if (adj[v][u] && color[u] == c) return 0;\n    return 1;\n}\n\nint assign(int v) {\n    if (v == n) return 1;\n\n    for (int c = 1; c <= m; c++) {\n        if (!safe(v, c)) continue;\n        color[v] = c;\n        if (assign(v + 1)) return 1;\n        color[v] = 0;                     /* undo */\n    }\n    return 0;\n}\n\nint main(void) {\n    printf("%d\\\\n", assign(0)); /* 1 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nbool safe(vector<vector<int>>& adj, int v, int c, vector<int>& color) {\n    for (int u = 0; u < (int)adj.size(); u++)\n        if (adj[v][u] && color[u] == c) return false;\n    return true;\n}\n\nbool assign(vector<vector<int>>& adj, int v, int m, vector<int>& color) {\n    if (v == (int)adj.size()) return true;\n\n    for (int c = 1; c <= m; c++) {\n        if (!safe(adj, v, c, color)) continue;\n        color[v] = c;\n        if (assign(adj, v + 1, m, color)) return true;\n        color[v] = 0;\n    }\n    return false;\n}\n\nint main() {\n    vector<vector<int>> adj{{0,1,1,1},{1,0,1,0},{1,1,0,1},{1,0,1,0}};\n    vector<int> color(4, 0);\n    cout << assign(adj, 0, 3, color) << '\\\\n'; // 1\n}`,
        },
        steps(text) {
          const segs = parts(text);
          const m = Math.max(1, parseInt(segs[segs.length - 1], 10) || 1);
          const rows = segs.slice(0, -1).map((r) => r.split(/[\s,]+/).filter(Boolean).map(Number)).filter((r) => r.length);
          const n = rows.length;
          if (!n) {
            return [{
              title: "Give an adjacency matrix and m",
              tracks: [chips("colours", ["—"], "idle")],
              counters: [count("vertices", 0), count("colours", m)],
              legend: ["idle", "result"],
              happened: "The last field is m, the number of colours.",
              why: "Adjacent vertices may not share a colour.",
            }];
          }
          const adj = Array.from({ length: n }, (_, r) => Array.from({ length: n }, (_, c) => (rows[r] && rows[r][c] ? 1 : 0)));
          const color = Array(n).fill(0);
          const steps = [];
          let budget = 36;
          const render = () =>
            chips(Array.from({ length: n }, (_, i) => `v${i}`), color.map((c) => (c ? `colour ${c}` : "—")), (i) => (color[i] ? "good" : "idle"));
          steps.push({
            title: `${n} vertices, ${m} colour${m === 1 ? "" : "s"}`,
            tracks: [render(), chips("edges", adj.flatMap((row, r) => row.map((v, c) => (v && c > r ? `${r}–${c}` : null))).filter(Boolean), "dim")],
            counters: [count("coloured", 0, n), count("colours", m)],
            legend: LEG,
            happened: "Each vertex receives exactly one colour.",
            why: "Every edge then needs two different colours.",
            codeLine: 4,
          });
          const record = (st) => { if (budget > 0) { steps.push(st); budget--; } };
          const safe = (v, c) => {
            for (let u = 0; u < n; u++) if (adj[v][u] && color[u] === c) return false;
            return true;
          };
          const assign = (v) => {
            if (v === n) return true;
            for (let c = 1; c <= m; c++) {
              if (!safe(v, c)) continue;
              color[v] = c;
              record({
                title: `Vertex ${v} gets colour ${c}`,
                tracks: [render(), chips("colours", color.map((x) => x || "—"), (i) => (i === v ? "result" : color[i] ? "good" : "dim"))],
                counters: [count("coloured", v + 1, n), count("colour", c)],
                legend: LEG,
                happened: `No neighbour of vertex ${v} already uses colour ${c}.`,
                why: "The safety check inspects only coloured neighbours.",
                codeLine: 10,
              });
              if (assign(v + 1)) return true;
              color[v] = 0;
              record({
                title: `Undo vertex ${v} colour ${c}`,
                tracks: [render(), chips("colours", color.map((x) => x || "—"), "bad")],
                counters: [count("coloured", v, n), count("colour", c)],
                legend: LEG,
                happened: "The rest of the graph could not be coloured from here.",
                why: "Trying the next colour may still succeed.",
                codeLine: 13,
              });
            }
            return false;
          };
          const ok = assign(0);
          steps.push({
            title: ok ? `Answer: colouring ${show(color)}` : "Answer: no colouring with these colours",
            tracks: [chips(Array.from({ length: n }, (_, i) => `v${i}`), color.map((c) => (c ? `colour ${c}` : "—")), ok ? "result" : "bad"), chips("answer", [ok ? "yes" : "no"], "result")],
            counters: [count("coloured", color.filter((c) => c).length, n), count("answer", ok ? "yes" : "no")],
            legend: LEG,
            happened: ok ? "Every edge joins two different colours." : "Some vertex had no legal colour in every branch.",
            why: "The search backtracks until either all vertices are coloured or every option is exhausted.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "word-break-ii",
    title: "Word Break II",
    category: "Backtracking",
    difficulty: "Advanced",
    description:
      "List every sentence that can be formed by splitting a string into dictionary words.",
    input: { label: "text | dictionary words", default: "catsanddog | cat, cats, and, sand, dog", parse: "string" },
    approaches: [
      {
        name: "Backtrack With Memoised Suffixes",
        complexity: "O(n² × results) time",
        idea: [
          "At position i, try every prefix that is a dictionary word and recurse from its end.",
          "Cache the sentences that a suffix can produce, so the same suffix is not rebuilt from many prefixes.",
        ],
        problem: [
          "Plain recursion repeats suffix work exponentially whenever several prefixes lead to the same position.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nconst char *dict[] = {"cat", "cats", "and", "sand", "dog"};\nint dict_n = 5;\n\nint is_word(const char *s, int len) {\n    for (int i = 0; i < dict_n; i++)\n        if ((int)strlen(dict[i]) == len && strncmp(dict[i], s, len) == 0) return 1;\n    return 0;\n}\n\nvoid split(const char *s, int at, char path[][32], int depth) {\n    if (s[at] == 0) {\n        for (int i = 0; i < depth; i++) printf("%s%s", path[i], i + 1 == depth ? "\\\\n" : " ");\n        return;\n    }\n\n    for (int end = at + 1; s[end - 1]; end++) {\n        if (!is_word(s + at, end - at)) continue;\n        int len = end - at;\n        strncpy(path[depth], s + at, len);\n        path[depth][len] = 0;\n        split(s, end, path, depth + 1);\n    }\n}\n\nint main(void) {\n    char path[16][32];\n    split("catsanddog", 0, path, 0); /* cat sand dog / cats and dog */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <string>\n#include <unordered_set>\nusing namespace std;\n\nunordered_set<string> dict = {"cat","cats","and","sand","dog"};\n\nvector<string> sentences(const string& s, int at) {\n    if (at == (int)s.size()) return {""};\n\n    vector<string> out;\n    for (int end = at + 1; end <= (int)s.size(); end++) {\n        string word = s.substr(at, end - at);\n        if (!dict.count(word)) continue;\n        for (const string& rest : sentences(s, end))\n            out.push_back(rest.empty() ? word : word + " " + rest);\n    }\n    return out;\n}\n\nint main() {\n    for (auto& line : sentences("catsanddog", 0)) cout << line << '\\\\n';\n}`,
        },
        steps(text) {
          const [sRaw, dictRaw] = parts(text);
          const s = String(sRaw || "");
          const dict = String(dictRaw || "").split(",").map((w) => w.trim()).filter(Boolean);
          if (!s.length || !dict.length) {
            return [{
              title: "Give a text and dictionary words",
              tracks: [chips("text", ["—"], "idle"), chips("dictionary", ["—"], "idle")],
              counters: [count("sentences", 0)],
              legend: ["idle", "result"],
              happened: "The left field is the text, the right the words.",
              why: "Every piece of a sentence must be a dictionary word.",
            }];
          }
          const steps = [];
          const out = [];
          const path = [];
          const memo = new Map();
          let budget = 40;
          steps.push({
            title: `Break "${s}" using ${dict.length} words`,
            tracks: [chips("text", Array.from(s), "idle"), chips("dictionary", dict, "dim")],
            counters: [count("length", s.length), count("sentences", 0)],
            legend: LEG,
            happened: "Words are matched as prefixes of the remaining text.",
            why: "A sentence is a partition of the text into dictionary words.",
            codeLine: 5,
          });
          const record = (st) => { if (budget > 0) { steps.push(st); budget--; } };
          const walk = (at) => {
            if (memo.has(at)) return memo.get(at);
            if (at === s.length) return [""];
            const found = [];
            for (let end = at + 1; end <= s.length; end++) {
              const word = s.slice(at, end);
              if (!dict.includes(word)) continue;
              path.push(word);
              record({
                title: `"${word}" is a word at ${at}..${end - 1}`,
                tracks: [
                  track("text", Array.from(s), Array.from(s).map((_, i) => (i >= at && i < end ? "result" : i < at ? "done" : "dim"))),
                  chips("path", path, "active"),
                ],
                counters: [count("position", at), count("next", end)],
                legend: LEG,
                happened: `Continue from position ${end}.`,
                why: "The next word must start immediately after this one.",
                codeLine: 8,
              });
              const tails = walk(end);
              for (const tail of tails) found.push(tail ? `${word} ${tail}` : word);
              path.pop();
              record({
                title: `Undo "${word}" at ${at}`,
                tracks: [chips("path", path.length ? path : ["—"], "dim"), chips("found", found.length ? found : ["—"], "dim")],
                counters: [count("position", at), count("found here", found.length)],
                legend: LEG,
                happened: "Return to the start position to try a longer word.",
                why: "Prefixes of different lengths are separate branches.",
                codeLine: 10,
              });
            }
            memo.set(at, found);
            return found;
          };
          const answer = walk(0);
          out.push(...answer);
          steps.push({
            title: answer.length ? `Answer: ${answer.length} sentence${answer.length === 1 ? "" : "s"}` : "Answer: no sentence",
            tracks: [chips("sentences", answer.length ? answer : ["none"], "result")],
            counters: [count("sentences", answer.length), count("memo entries", memo.size)],
            legend: LEG,
            happened: answer.length ? "Each sentence is a full partition into dictionary words." : "No prefix split covers the whole text.",
            why: "The memo returns whole suffix sentences, so shared suffixes are built once.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "expression-add-operators",
    title: "Expression Add Operators",
    category: "Backtracking",
    difficulty: "Advanced",
    description:
      "Insert +, − and × between digits so the expression evaluates to a target.",
    input: { label: "digits | target", default: "123 | 6", parse: "string" },
    approaches: [
      {
        name: "Track Value and Previous Term",
        complexity: "O(4ⁿ) expressions",
        idea: [
          "Build the expression left to right, choosing an operator before each new operand.",
          "Multiplication needs the previous term separately: adding a new multiplied operand subtracts the previous term's contribution and adds the combined product.",
        ],
        problem: [
          "Evaluating the string only at the end loses the ability to prune, and plain left-to-right values treat multiplication like addition.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n#include <stdlib.h>\n\nvoid build(const char *num, int at, long long value, long long prev,\n           long long target, char *expr) {\n    if (num[at] == 0) {\n        if (value == target) printf("%s\\\\n", expr);\n        return;\n    }\n\n    int len = strlen(expr);\n    long long operand = 0;\n    for (int i = at; num[i]; i++) {\n        if (i > at && num[at] == '0') break;      /* no leading zero */\n        operand = operand * 10 + (num[i] - '0');\n\n        if (at == 0) {\n            expr[len] = 0;\n            sprintf(expr + len, "%lld", operand);\n            build(num, i + 1, operand, operand, target, expr);\n            expr[len] = 0;\n        } else {\n            sprintf(expr + len, "+%lld", operand);\n            build(num, i + 1, value + operand, operand, target, expr);\n            sprintf(expr + len, "-%lld", operand);\n            build(num, i + 1, value - operand, -operand, target, expr);\n            sprintf(expr + len, "*%lld", operand);\n            build(num, i + 1, value - prev + prev * operand, prev * operand, target, expr);\n            expr[len] = 0;\n        }\n    }\n}\n\nint main(void) {\n    char expr[64] = "";\n    build("123", 0, 0, 0, 6, expr); /* 1+2+3, 1*2*3 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <string>\nusing namespace std;\n\nvoid build(const string& num, int at, long long value, long long prev, long long target, string& expr, vector<string>& out) {\n    if (at == (int)num.size()) {\n        if (value == target) out.push_back(expr);\n        return;\n    }\n\n    size_t len = expr.size();\n    long long operand = 0;\n    for (int i = at; i < (int)num.size(); i++) {\n        if (i > at && num[at] == '0') break;\n        operand = operand * 10 + (num[i] - '0');\n\n        if (at == 0) {\n            expr += to_string(operand);\n            build(num, i + 1, operand, operand, target, expr, out);\n            expr.resize(len);\n        } else {\n            expr += "+" + to_string(operand);\n            build(num, i + 1, value + operand, operand, target, expr, out);\n            expr.resize(len);\n            expr += "-" + to_string(operand);\n            build(num, i + 1, value - operand, -operand, target, expr, out);\n            expr.resize(len);\n            expr += "*" + to_string(operand);\n            build(num, i + 1, value - prev + prev * operand, prev * operand, target, expr, out);\n            expr.resize(len);\n        }\n    }\n}\n\nint main() {\n    vector<string> out;\n    string expr;\n    build("123", 0, 0, 0, 6, expr, out);\n    for (auto& s : out) cout << s << '\\\\n'; // 1+2+3, 1*2*3\n}`,
        },
        steps(text) {
          const [numRaw, targetRaw] = parts(text);
          const num = String(numRaw || "").replace(/[^0-9]/g, "");
          const target = parseInt(targetRaw, 10) || 0;
          if (!num.length) {
            return [{
              title: "Give digits and a target",
              tracks: [chips("digits", ["—"], "idle")],
              counters: [count("target", target)],
              legend: ["idle", "result"],
              happened: "The left field holds digits, the right the target.",
              why: "Operators may only be inserted between digits.",
            }];
          }
          const steps = [];
          const out = [];
          let budget = 40;
          steps.push({
            title: `Digits ${num}; target ${target}`,
            tracks: [chips("digits", Array.from(num), "idle"), chips("expressions", ["—"], "dim")],
            counters: [count("target", target), count("found", 0)],
            legend: LEG,
            happened: "Operands may have several digits.",
            why: "Every split point is a possible operand end.",
            codeLine: 4,
          });
          const record = (st) => { if (budget > 0) { steps.push(st); budget--; } };
          const build = (at, value, prev, expr) => {
            if (at === num.length) {
              if (value === target) {
                out.push(expr);
                record({
                  title: `Evaluates to ${value} → keep ${expr}`,
                  tracks: [chips("expression", [expr], "result"), chips("found", out, (i) => (i === out.length - 1 ? "good" : "dim"))],
                  counters: [count("found", out.length, 0), count("value", value)],
                  legend: LEG,
                  happened: "The whole digit string was consumed with this operator choice.",
                  why: "Multiplication was folded into the running value through the previous term.",
                  codeLine: 5,
                });
              }
              return;
            }
            let operand = 0;
            for (let i = at; i < num.length; i++) {
              if (i > at && num[at] === "0") break;
              operand = operand * 10 + parseInt(num[i], 10);
              if (at === 0) {
                record({
                  title: `First operand ${operand}`,
                  tracks: [track("digits", Array.from(num), Array.from(num).map((_, k) => (k >= at && k <= i ? "read" : "dim"))), chips("expression so far", [String(operand)], "active")],
                  counters: [count("value", operand), count("previous term", operand)],
                  legend: LEG,
                  happened: "The expression starts with a number, not an operator.",
                  why: "Leading zeros are only allowed for the single digit 0.",
                  codeLine: 10,
                });
                build(i + 1, operand, operand, String(operand));
              } else {
                const plus = expr + "+" + operand;
                record({
                  title: `${expr} + ${operand} = ${value + operand}`,
                  tracks: [chips("expression", [plus], "active"), chips("value", [value + operand], "compare")],
                  counters: [count("value", value + operand), count("previous term", operand)],
                  legend: LEG,
                  happened: "Addition keeps the new operand as the previous term.",
                  why: "A later multiplication may need to replace this term.",
                  codeLine: 15,
                });
                build(i + 1, value + operand, operand, plus);
                const minus = expr + "-" + operand;
                record({
                  title: `${expr} − ${operand} = ${value - operand}`,
                  tracks: [chips("expression", [minus], "active"), chips("value", [value - operand], "compare")],
                  counters: [count("value", value - operand), count("previous term", -operand)],
                  legend: LEG,
                  happened: "Subtraction stores a negative previous term.",
                  why: "The sign must travel with the term for later multiplication.",
                  codeLine: 17,
                });
                build(i + 1, value - operand, -operand, minus);
                const times = expr + "*" + operand;
                const folded = value - prev + prev * operand;
                record({
                  title: `${expr} × ${operand} → ${folded}`,
                  tracks: [
                    chips("expression", [times], "active"),
                    chips("old term", [prev], "bad"),
                    chips("new term", [prev * operand], "done"),
                    chips("value", [folded], "compare"),
                  ],
                  counters: [count("value", folded), count("previous term", prev * operand)],
                  legend: LEG,
                  happened: "The previous term is removed and replaced by its product with the new operand.",
                  why: "Multiplication binds tighter than addition, so the last term is adjusted.",
                  codeLine: 19,
                });
                build(i + 1, folded, prev * operand, times);
              }
            }
          };
          build(0, 0, 0, "");
          steps.push({
            title: out.length ? `Answer: ${out.length} expression${out.length === 1 ? "" : "s"}` : "Answer: no expression reaches the target",
            tracks: [chips("expressions", out.length ? out : ["none"], "result")],
            counters: [count("found", out.length), count("target", target)],
            legend: LEG,
            happened: out.length ? "Every expression uses all digits in order." : "No operator choice evaluates to the target.",
            why: "Each position between digits was tried with each of the three operators.",
            codeLine: 22,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "matchsticks-to-square",
    title: "Matchsticks to Square",
    category: "Backtracking",
    difficulty: "Advanced",
    description:
      "Decide whether all matchsticks can be split into four groups of equal total length.",
    input: { label: "matchstick lengths", default: "1,1,2,2,2", parse: "ints" },
    approaches: [
      {
        name: "Fill Four Sides Largest First",
        complexity: "O(4ⁿ) worst case",
        idea: [
          "The total must divide by four; that quotient is the side length. Sort the sticks longest first.",
          "Place each stick on a side that has room. Try each distinct side total once, and backtrack when a side cannot be completed.",
        ],
        problem: [
          "Without sorting longest first, the search wastes time on many small sticks before discovering a bad large one.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\nstatic int cmp_desc(const void *a, const void *b) {\n    return *(const int *)b - *(const int *)a;\n}\n\nint place(int *a, int n, int at, int *sides, int target) {\n    if (at == n) return 1;\n\n    for (int s = 0; s < 4; s++) {\n        if (sides[s] + a[at] > target) continue;\n        if (s > 0 && sides[s] == sides[s - 1]) continue;   /* same state */\n        sides[s] += a[at];\n        if (place(a, n, at + 1, sides, target)) return 1;\n        sides[s] -= a[at];\n        if (sides[s] == 0) break;                          /* symmetry */\n    }\n    return 0;\n}\n\nint main(void) {\n    int a[] = {1, 1, 2, 2, 2};\n    int sum = 8, sides[4] = {0};\n    qsort(a, 5, sizeof(int), cmp_desc);\n    printf("%d\\\\n\", place(a, 5, 0, sides, sum / 4)); /* 1 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <numeric>\n#include <algorithm>\nusing namespace std;\n\nbool place(vector<int>& a, int at, vector<int>& sides, int target) {\n    if (at == (int)a.size()) return true;\n\n    for (int s = 0; s < 4; s++) {\n        if (sides[s] + a[at] > target) continue;\n        if (s > 0 && sides[s] == sides[s - 1]) continue;\n        sides[s] += a[at];\n        if (place(a, at + 1, sides, target)) return true;\n        sides[s] -= a[at];\n        if (sides[s] == 0) break;\n    }\n    return false;\n}\n\nbool makesquare(vector<int> a) {\n    int sum = accumulate(a.begin(), a.end(), 0);\n    if (sum % 4) return false;\n    sort(a.rbegin(), a.rend());\n    vector<int> sides(4, 0);\n    return place(a, 0, sides, sum / 4);\n}\n\nint main() {\n    cout << makesquare({1,1,2,2,2}) << '\\\\n'; // 1\n}`,
        },
        steps(values) {
          const a = values.slice().sort((x, y) => y - x);
          const sum = a.reduce((s, v) => s + v, 0);
          if (!a.length) {
            return [{
              title: "Give some matchstick lengths",
              tracks: [chips("sticks", ["—"], "idle")],
              counters: [count("total", 0)],
              legend: ["idle", "result"],
              happened: "Four equal sides are required.",
              why: "The total length must divide by four.",
            }];
          }
          const target = sum / 4;
          const steps = [];
          steps.push({
            title: `Total ${sum}; each side must be ${sum % 4 === 0 ? target : "—"}`,
            tracks: [chips("sticks (longest first)", a, "idle"), chips("sides", ["—"], "dim")],
            counters: [count("total", sum), count("side target", sum % 4 === 0 ? target : "not divisible")],
            legend: LEG,
            happened: sum % 4 === 0 ? "Four equal sides are possible in principle." : "The total cannot be split into four equal integers.",
            why: "Every stick belongs to exactly one side.",
            codeLine: 4,
          });
          if (sum % 4 !== 0 || a[0] > target) {
            steps.push({
              title: "Answer: impossible",
              tracks: [chips("sides", ["—"], "bad")],
              counters: [count("total", sum), count("answer", "no")],
              legend: LEG,
              happened: sum % 4 !== 0 ? "The total is not a multiple of four." : "A single stick is longer than one side.",
              why: "Neither condition can be fixed by rearranging sticks.",
              codeLine: 6,
            });
            return steps;
          }
          const sides = [0, 0, 0, 0];
          let budget = 38, ok = false;
          const record = (st) => { if (budget > 0) { steps.push(st); budget--; } };
          const place = (at) => {
            if (at === a.length) return true;
            const tried = new Set();
            for (let s = 0; s < 4; s++) {
              if (sides[s] + a[at] > target) continue;
              if (tried.has(sides[s])) continue;
              tried.add(sides[s]);
              sides[s] += a[at];
              record({
                title: `Stick ${a[at]} → side ${s + 1} (now ${sides[s]}/${target})`,
                tracks: [
                  chips("sticks left", a.slice(at + 1), "dim"),
                  chips("sides", sides.map((v) => `${v}/${target}`), (i) => (i === s ? "active" : sides[i] === target ? "done" : "idle")),
                ],
                counters: [count("placed", at + 1, a.length), count("side", s + 1)],
                legend: LEG,
                happened: `Side ${s + 1} still has ${target - sides[s]} units free.`,
                why: "A stick must fit entirely on one side.",
                codeLine: 11,
              });
              if (place(at + 1)) return true;
              sides[s] -= a[at];
              record({
                title: `Undo stick ${a[at]} from side ${s + 1}`,
                tracks: [chips("sides", sides.map((v) => `${v}/${target}`), (i) => (i === s ? "bad" : "dim"))],
                counters: [count("placed", at, a.length), count("side", s + 1)],
                legend: LEG,
                happened: "The remaining sticks could not complete all sides.",
                why: "An equal side total is a symmetric choice and is skipped.",
                codeLine: 14,
              });
              if (sides[s] === 0) break;
            }
            return false;
          };
          ok = place(0);
          steps.push({
            title: ok ? `Answer: yes, four sides of ${target}` : "Answer: no square",
            tracks: [chips("sides", sides.map((v) => `${v}/${target}`), ok ? "result" : "bad")],
            counters: [count("side target", target), count("answer", ok ? "yes" : "no")],
            legend: LEG,
            happened: ok ? "Every side reached the target length exactly." : "No assignment of sticks fills all four sides.",
            why: "Trying each distinct side total avoids symmetric duplicates.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });
})();
