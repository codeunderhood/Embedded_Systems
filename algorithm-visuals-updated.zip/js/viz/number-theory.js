/* ============================================================
   DSA Visuals — Number Theory
   String GCD, prime counting, the sieve, modular inverses and
   the nth number divisible by either of two values.
   ============================================================ */
(function () {
  "use strict";
  const { count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const partsOf = (text) => String(text || "").split("|").map((p) => p.trim());
  const intsOf = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number).filter(Number.isFinite);
  const gcd = (a, b) => { while (b) { [a, b] = [b, a % b]; } return a; };

  /* ---------------------------------------------------------- */
  V.register({
    id: "gcd-of-strings",
    title: "GCD of Strings",
    category: "Number Theory",
    difficulty: "Intermediate",
    description: "Find the largest string that repeatedly forms both input strings.",
    input: { label: "String A | String B", default: "ABCABC | ABC", parse: "string" },
    approaches: [
      {
        name: "Common Base and Length GCD",
        complexity: "O(len(A) + len(B)) time",
        idea: [
          "If a common repeating base exists, A + B and B + A must be the same string. When they differ, no such base exists.",
          "When they agree, the base repeats gcd(len(A), len(B)) times, so its length is that gcd. The answer is the prefix of A of that length.",
        ],
        problem: [
          "Checking short candidate strings one by one repeats work and needs careful length divisibility tests.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <string.h>\\n\\nint gcd(int a, int b) { while (b) { int t = a % b; a = b; b = t; } return a; }\\n\\nint main(void) {\\n    char a[] = \\\"ABCABC\\\", b[] = \\\"ABC\\\";\\n    char ab[32], ba[32];\\n    sprintf(ab, \\\"%s%s\\\", a, b);\\n    sprintf(ba, \\\"%s%s\\\", b, a);\\n    if (strcmp(ab, ba) != 0) { printf(\\\"(none)\\\\n\\\"); return 0; }\\n\\n    int g = gcd(strlen(a), strlen(b));\\n    printf(\\\"%.*s\\\\n\\\", g, a); /* ABC */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <numeric>\\n#include <string>\\nusing namespace std;\\n\\nstring gcdOfStrings(string a, string b) {\\n    if (a + b != b + a) return \\\"\\\";\\n    return a.substr(0, gcd((int)a.size(), (int)b.size()));\\n}\\n\\nint main() {\\n    cout << gcdOfStrings(\\\"ABCABC\\\", \\\"ABC\\\") << '\\\\n'; // ABC\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const a = String(parts[0] || "").replace(/\s/g, "").slice(0, 24);
          const b = String(parts[1] || "").replace(/\s/g, "").slice(0, 24);
          if (!a || !b) return [{
            title: "Give two strings",
            tracks: [chips("A", a ? a.split("") : ["—"], "idle")],
            counters: [count("gcd length", 0)],
            legend: LEG,
            happened: "The input is incomplete.",
            why: "A common base needs both strings.",
          }];
          const swapEqual = a + b === b + a;
          const steps = [];
          const g = swapEqual ? gcd(a.length, b.length) : 0;
          const base = g ? a.slice(0, g) : "";
          steps.push({
            title: `Compare "${a}" + "${b}" with "${b}" + "${a}"`,
            tracks: [chips("A", a.split(""), "compare"), chips("B", b.split(""), "compare")],
            counters: [count("len A", a.length), count("len B", b.length)],
            legend: LEG,
            happened: swapEqual ? "Both concatenations are identical, so a common base exists." : "The concatenations differ, so there is no common base.",
            why: "A string built by repeating a base commutes with every other repetition of that base.",
            codeLine: 7,
          });
          if (!swapEqual) {
            steps.push({
              title: "Answer: no common base",
              tracks: [chips("A", a.split(""), "dim"), chips("B", b.split(""), "dim")],
              counters: [count("gcd length", 0), count("answer", 0)],
              legend: LEG,
              happened: "A and B cannot be formed from the same repeated string.",
              why: "The concatenation test fails, which rules out every possible base.",
              codeLine: 8,
            });
            return steps;
          }
          let x = a.length, y = b.length;
          const seen = [[x, y]];
          while (y) { const q = Math.floor(x / y); const r = x % y; x = y; y = r; seen.push([x, y]); }
          steps.push({
            title: `Euclid on lengths ${a.length} and ${b.length}`,
            tracks: [chips("length pairs", seen.map(([p, q]) => `${p},${q}`), (i) => (i === seen.length - 1 ? "result" : "done"))],
            counters: [count("gcd length", x), count("base repeats", a.length / x)],
            legend: LEG,
            happened: `The last nonzero remainder is ${x}, so the base repeats ${a.length / x} times in A.`,
            why: "The base must divide both lengths, and the greatest such divisor is their gcd.",
            codeLine: 10,
          });
          steps.push({
            title: g ? `Answer: "${base}"` : "Answer: no common base",
            tracks: [chips("A", a.split(""), (i) => (i < g ? "result" : "dim")), chips("base", base.split(""), "good")],
            counters: [count("base length", g), count("repeats", g ? a.length / g : 0)],
            legend: LEG,
            happened: g ? `"${base}" repeats ${a.length / g} times in A and ${b.length / g} times in B.` : "No base works.",
            why: "The prefix of length gcd is the largest string that can tile both inputs.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "count-primes",
    title: "Count Primes",
    category: "Number Theory",
    difficulty: "Intermediate",
    description: "Count the prime numbers strictly below n.",
    input: { label: "n", default: "10", parse: "int" },
    approaches: [
      {
        name: "Sieve Then Count",
        complexity: "O(n log log n) time",
        idea: [
          "Assume every number from 2 upward is prime. For each prime p, mark p², p²+p, p²+2p, … as composite.",
          "Only values up to √n need to mark multiples; larger primes have no unmarked composite multiples below n. The remaining unmarked numbers are the primes.",
        ],
        problem: [
          "Testing each number for primality separately does much more divisibility work than one sieve pass.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <stdbool.h>\\n\\nint main(void) {\\n    int n = 10, count = 0;\\n    bool prime[10];\\n    for (int i = 0; i < n; i++) prime[i] = true;\\n    prime[0] = prime[1] = false;\\n\\n    for (int p = 2; p * p < n; p++)\\n        if (prime[p])\\n            for (int m = p * p; m < n; m += p) prime[m] = false;\\n\\n    for (int i = 2; i < n; i++) if (prime[i]) count++;\\n    printf(\\\"%d\\\\n\\\", count); /* 4 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint countPrimes(int n) {\\n    if (n < 2) return 0;\\n    vector<bool> prime(n, true);\\n    prime[0] = prime[1] = false;\\n    for (int p = 2; p * p < n; p++)\\n        if (prime[p])\\n            for (int m = p * p; m < n; m += p) prime[m] = false;\\n    int cnt = 0;\\n    for (int i = 2; i < n; i++) cnt += prime[i];\\n    return cnt;\\n}\\n\\nint main() {\\n    cout << countPrimes(10) << '\\\\n'; // 4\\n}`,
        },
        steps(text) {
          const n = Math.max(2, Math.min(60, parseInt(text, 10) || 10));
          const isPrime = Array(n).fill(true);
          if (n > 0) isPrime[0] = false;
          if (n > 1) isPrime[1] = false;
          const steps = [];
          const vals = Array.from({ length: n }, (_, i) => i);
          const state = () => (i) => (i < 2 ? "bad" : isPrime[i] ? "good" : "bad");
          steps.push({
            title: `Primes strictly below ${n}`,
            tracks: [chips("numbers", vals, state())],
            counters: [count("candidates", Math.max(0, n - 2)), count("primes", 0)],
            legend: LEG,
            happened: "0 and 1 are marked non-prime; every other number starts as a candidate.",
            why: "The sieve removes composites instead of testing each candidate from scratch.",
            codeLine: 4,
          });
          for (let p = 2; p * p < n; p++) {
            if (!isPrime[p]) continue;
            const marked = [];
            for (let m = p * p; m < n; m += p) { isPrime[m] = false; marked.push(m); }
            steps.push({
              title: `Prime ${p}: strike multiples from ${p * p}`,
              tracks: [chips("numbers", vals, (i) => (i === p ? "read" : marked.includes(i) ? "bad" : i < 2 ? "bad" : isPrime[i] ? "good" : "dim"))],
              counters: [count("struck", marked.length), count("prime", p)],
              legend: LEG,
              happened: marked.length ? `Marked ${marked.join(", ")} as composite.` : `No multiples of ${p} remain below ${n}.`,
              why: "Smaller multiples were already struck by smaller primes, so marking can start at p².",
              codeLine: 9,
            });
          }
          const primes = vals.filter((i) => isPrime[i]);
          steps.push({
            title: `Answer: ${primes.length} prime${primes.length === 1 ? "" : "s"} below ${n}`,
            tracks: [chips("numbers", vals, (i) => (isPrime[i] ? "result" : "dim")), chips("primes", primes, "good")],
            counters: [count("primes", primes.length), count("limit", n)],
            legend: LEG,
            happened: `The surviving numbers are ${primes.join(", ")}.`,
            why: "Every composite below n has a prime factor at most √n, so all composites were struck.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "sieve-of-eratosthenes",
    title: "Sieve of Eratosthenes",
    category: "Number Theory",
    difficulty: "Intermediate",
    description: "List all primes up to n by repeatedly removing multiples.",
    input: { label: "n", default: "30", parse: "int" },
    approaches: [
      {
        name: "Mark Composite Multiples",
        complexity: "O(n log log n) time, O(n) space",
        idea: [
          "Write the numbers 2..n in order and treat them all as prime. Take the smallest unmarked number p; it must be prime because nothing smaller divides it.",
          "Cross out p², p²+p, p²+2p, and so on. Repeat only while p² ≤ n. Unmarked numbers are exactly the primes.",
        ],
        problem: [
          "Dividing every candidate by every smaller number repeats the same composite removals many times.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <stdbool.h>\\n\\nint main(void) {\\n    int n = 30;\\n    bool prime[31];\\n    for (int i = 0; i <= n; i++) prime[i] = true;\\n    prime[0] = prime[1] = false;\\n\\n    for (int p = 2; p * p <= n; p++)\\n        if (prime[p])\\n            for (int m = p * p; m <= n; m += p) prime[m] = false;\\n\\n    for (int i = 2; i <= n; i++) if (prime[i]) printf(\\\"%d \\\", i);\\n    printf(\\\"\\\\n\\\"); /* 2 3 5 7 11 13 17 19 23 29 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nvector<int> sieve(int n) {\\n    vector<bool> prime(n + 1, true);\\n    prime[0] = prime[1] = false;\\n    for (int p = 2; p * p <= n; p++)\\n        if (prime[p])\\n            for (int m = p * p; m <= n; m += p) prime[m] = false;\\n    vector<int> out;\\n    for (int i = 2; i <= n; i++) if (prime[i]) out.push_back(i);\\n    return out;\\n}\\n\\nint main() {\\n    for (int p : sieve(30)) cout << p << ' ';\\n    cout << '\\\\n'; // 2 3 5 7 11 13 17 19 23 29\\n}`,
        },
        steps(text) {
          const n = Math.max(2, Math.min(60, parseInt(text, 10) || 30));
          const cols = Math.min(10, n + 1);
          const rows = Math.ceil((n + 1) / cols);
          const isPrime = Array(n + 1).fill(true);
          isPrime[0] = false;
          isPrime[1] = false;
          const steps = [];
          const cells = (curP, marked) => grid(rows, cols, (r, c) => {
            const v = r * cols + c;
            if (v > n) return { v: "·", state: "dim" };
            return {
              v,
              state: v === curP ? "read" : v < 2 ? "bad" : marked.includes(v) ? "bad" : isPrime[v] ? "good" : "dim",
            };
          });
          steps.push({
            title: `Numbers 0 to ${n} in a grid`,
            kind: "grid", rows, cols,
            cells: cells(-1, []),
            counters: [count("limit", n), count("candidates", Math.max(0, n - 1))],
            legend: LEG,
            happened: "Every value starts as a prime candidate except 0 and 1.",
            why: "The sieve will cross out composites in place instead of using trial division.",
            codeLine: 4,
          });
          for (let p = 2; p * p <= n; p++) {
            if (!isPrime[p]) continue;
            const marked = [];
            for (let m = p * p; m <= n; m += p) { isPrime[m] = false; marked.push(m); }
            steps.push({
              title: `p = ${p}: cross out ${p}² and its multiples`,
              kind: "grid", rows, cols,
              cells: cells(p, marked),
              counters: [count("struck", marked.length), count("prime", p)],
              legend: LEG,
              happened: marked.length ? `Crossed out ${marked.join(", ")}.` : `Nothing left to cross out for ${p}.`,
              why: "Multiples below p² were already removed by a smaller prime factor.",
              codeLine: 9,
            });
          }
          const primes = Array.from({ length: n - 1 }, (_, i) => i + 2).filter((i) => isPrime[i]);
          steps.push({
            title: `Answer: ${primes.length} primes up to ${n}`,
            kind: "grid", rows, cols,
            cells: grid(rows, cols, (r, c) => {
              const v = r * cols + c;
              return v > n ? { v: "·", state: "dim" } : { v, state: isPrime[v] ? "result" : "dim" };
            }),
            counters: [count("primes", primes.length), count("largest", primes.length ? primes[primes.length - 1] : 0)],
            legend: LEG,
            happened: primes.join(", "),
            why: "Numbers surviving every crossing-out pass have no divisor other than 1 and themselves.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "modular-inverse",
    title: "Modular Inverse",
    category: "Number Theory",
    difficulty: "Advanced",
    description: "Find x such that a × x is congruent to 1 modulo m.",
    input: { label: "a | modulus", default: "3 | 11", parse: "string" },
    approaches: [
      {
        name: "Extended Euclidean Algorithm",
        complexity: "O(log min(a, m)) time",
        idea: [
          "The inverse exists only when gcd(a, m) = 1. Euclid's algorithm computes that gcd while also tracking how to write it as a combination of a and m.",
          "At the end, the coefficient multiplying a satisfies a × coefficient = 1 modulo m. Reducing that coefficient into 0..m−1 gives the inverse.",
        ],
        problem: [
          "Trying every x from 1 to m−1 multiplies work when the modulus is large, and fails silently when no inverse exists.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int a = 3, m = 11;\\n    int oldR = a, r = m, oldS = 1, s = 0;\\n\\n    while (r) {\\n        int q = oldR / r;\\n        int nr = oldR - q * r; oldR = r; r = nr;\\n        int ns = oldS - q * s; oldS = s; s = ns;\\n    }\\n\\n    if (oldR != 1) { printf(\\\"no inverse\\\\n\\\"); return 0; }\\n    int inv = ((oldS % m) + m) % m;\\n    printf(\\\"%d\\\\n\\\", inv); /* 4 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\nusing namespace std;\\n\\nint modInverse(int a, int m) {\\n    int oldR = a, r = m, oldS = 1, s = 0;\\n    while (r) {\\n        int q = oldR / r;\\n        int nr = oldR - q * r; oldR = r; r = nr;\\n        int ns = oldS - q * s; oldS = s; s = ns;\\n    }\\n    if (oldR != 1) return -1;\\n    return ((oldS % m) + m) % m;\\n}\\n\\nint main() {\\n    cout << modInverse(3, 11) << '\\\\n'; // 4\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          let a = Math.abs(parseInt(parts[0], 10) || 3);
          let m = Math.abs(parseInt(parts[1], 10) || 11);
          a = Math.min(a, 9999);
          m = Math.max(2, Math.min(m, 9999));
          let oldR = a % m, r = m, oldS = 1, s = 0;
          const rSeq = [oldR, r];
          const qSeq = [];
          while (r) {
            const q = Math.floor(oldR / r);
            qSeq.push(q);
            const nr = oldR - q * r; oldR = r; r = nr;
            const ns = oldS - q * s; oldS = s; s = ns;
            rSeq.push(oldR, r);
          }
          const inv = oldR === 1 ? ((oldS % m) + m) % m : -1;
          const steps = [];
          steps.push({
            title: `Solve ${a}x ≡ 1 (mod ${m})`,
            tracks: [chips("remainders", rSeq.slice(0, 2), "compare"), chips("quotients", qSeq.length ? qSeq : ["—"], "idle")],
            counters: [count("a", a), count("modulus", m)],
            legend: LEG,
            happened: "Start with remainder a and modulus m, plus coefficients 1 and 0.",
            why: "An inverse exists only when the final gcd is 1.",
            codeLine: 4,
          });
          for (let i = 0; i < qSeq.length; i++) {
            steps.push({
              title: `Step ${i + 1}: quotient ${qSeq[i]}, new remainder ${rSeq[Math.min(rSeq.length - 1, 2 * i + 3)]}`,
              tracks: [chips("remainders", rSeq.slice(0, 2 * i + 4), (k) => (k >= 2 * i + 2 ? "read" : "done")), chips("quotients", qSeq.slice(0, i + 1), (k) => (k === i ? "active" : "done"))],
              counters: [count("remainder", rSeq[Math.min(rSeq.length - 1, 2 * i + 3)]), count("step", i + 1, qSeq.length)],
              legend: LEG,
              happened: `The remainder pair narrows; the tracked coefficient now multiplies ${a}.`,
              why: "Each quotient updates both the remainder and the coefficient in the same way.",
              codeLine: 9,
            });
          }
          steps.push({
            title: inv >= 0 ? `Answer: ${inv} (since ${a} × ${inv} ≡ 1 mod ${m})` : `Answer: no inverse exists (gcd ${oldR})`,
            tracks: [chips("a", [a], "compare"), chips("inverse", [inv >= 0 ? inv : "none"], inv >= 0 ? "result" : "bad")],
            counters: [count("gcd", oldR), count("inverse", inv >= 0 ? inv : 0)],
            legend: LEG,
            happened: inv >= 0 ? `${a} × ${inv} = ${a * inv}, and ${a * inv} mod ${m} = ${(a * inv) % m}.` : `The gcd is ${oldR}, so ${a} has no inverse modulo ${m}.`,
            why: "The extended Euclid coefficient gives a valid inverse exactly when the gcd is 1.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "nth-magical-number",
    title: "Nth Magical Number",
    category: "Number Theory",
    difficulty: "Advanced",
    description: "Find the nth positive number divisible by a or b.",
    input: { label: "n | a | b", default: "5 | 2 | 3", parse: "string" },
    approaches: [
      {
        name: "Binary Search on the Value",
        complexity: "O(log(n × min(a,b))) time",
        idea: [
          "For a candidate value x, the count of magical numbers up to x is ⌊x/a⌋ + ⌊x/b⌋ − ⌊x/lcm(a,b)⌋. The subtraction removes numbers counted for both a and b.",
          "This count grows with x, so binary search finds the smallest x whose count is at least n. That x is exactly the nth magical number.",
        ],
        problem: [
          "Generating multiples and merging them uses memory proportional to n, and n may be very large.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <stdint.h>\\n\\nint64_t gcd(int64_t a, int64_t b) { while (b) { int64_t t = a % b; a = b; b = t; } return a; }\\n\\nint main(void) {\\n    int64_t n = 5, a = 2, b = 3, mod = 1000000007;\\n    int64_t l = a / gcd(a, b) * b;\\n    int64_t lo = 1, hi = (a < b ? a : b) * n;\\n\\n    while (lo < hi) {\\n        int64_t mid = lo + (hi - lo) / 2;\\n        int64_t cnt = mid/a + mid/b - mid/l;\\n        if (cnt >= n) hi = mid; else lo = mid + 1;\\n    }\\n\\n    printf(\\\"%lld\\\\n\\\", (long long)(lo % mod)); /* 8 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <numeric>\\nusing namespace std;\\n\\nint nthMagicalNumber(int n, int a, int b) {\\n    long long l = (long long)a / gcd(a, b) * b;\\n    long long lo = 1, hi = (long long)min(a, b) * n;\\n    while (lo < hi) {\\n        long long mid = lo + (hi - lo) / 2;\\n        long long cnt = mid/a + mid/b - mid/l;\\n        if (cnt >= n) hi = mid; else lo = mid + 1;\\n    }\\n    return (int)(lo % 1000000007);\\n}\\n\\nint main() {\\n    cout << nthMagicalNumber(5, 2, 3) << '\\\\n'; // 8\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const n = Math.max(1, Math.min(1000, parseInt(parts[0], 10) || 5));
          const a = Math.max(1, Math.min(1000, parseInt(parts[1], 10) || 2));
          const b = Math.max(1, Math.min(1000, parseInt(parts[2], 10) || 3));
          const lcm = (a / gcd(a, b)) * b;
          let lo = 1, hi = Math.min(a, b) * n;
          const steps = [];
          const rank = (x) => Math.floor(x / a) + Math.floor(x / b) - Math.floor(x / lcm);
          steps.push({
            title: `Find magical number ${n} for ${a} and ${b}`,
            tracks: [chips("bounds", [`lo ${lo}`, `mid —`, `hi ${hi}`], "compare"), chips("multiples", [a, a * 2, a * 3, b, b * 2, b * 3].filter((x, i, arr) => arr.indexOf(x) === i).sort((x, y) => x - y), "idle")],
            counters: [count("n", n), count("lcm", lcm)],
            legend: LEG,
            happened: `The answer cannot exceed ${hi}, since ${Math.min(a, b)} × ${n} is already magical.`,
            why: "Counting up to x subtracts multiples of the least common multiple, which were counted twice.",
            codeLine: 4,
          });
          let iterations = 0;
          while (lo < hi && iterations < 40) {
            iterations++;
            const mid = lo + Math.floor((hi - lo) / 2);
            const cnt = rank(mid);
            const goLeft = cnt >= n;
            steps.push({
              title: `x = ${mid}: count ${cnt} ${goLeft ? "≥" : "<"} ${n}`,
              tracks: [chips("bounds", [`lo ${lo}`, `mid ${mid}`, `hi ${hi}`], (i) => (i === 1 ? "read" : "done")), chips("counts", [`${Math.floor(mid / a)} by a`, `${Math.floor(mid / b)} by b`, `${Math.floor(mid / lcm)} double`], "compare")],
              counters: [count("count", cnt), count("iteration", iterations)],
              legend: LEG,
              happened: `The smallest value with count ≥ ${n} is ${goLeft ? `at most ${mid}` : `above ${mid}`}.`,
              why: goLeft ? "Enough magical numbers exist by mid, so the answer can move left." : "Too few magical numbers exist by mid, so the answer must move right.",
              codeLine: 12,
            });
            if (goLeft) hi = mid; else lo = mid + 1;
          }
          steps.push({
            title: `Answer: ${lo}`,
            tracks: [chips("bounds", [`lo ${lo}`, `hi ${hi}`], "result"), chips("multiples", [lo], "good")],
            counters: [count("magical number", lo), count("rank", rank(lo))],
            legend: LEG,
            happened: `${lo} is divisible by ${a} or ${b}, and exactly ${n} magical numbers are at most ${lo}.`,
            why: "Binary search converged on the first value whose count reaches n.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });
})();
