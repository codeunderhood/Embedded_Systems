/* ============================================================
   DSA Visuals — Sweep Line & Geometry
   Buildings, rectangles, point pairs, segments, fences and
   collinear points. Each visual keeps the coordinate list short
   so the sweep order stays readable.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const pts = (n) => Array.from({ length: n }, (_, i) => ({ x: 0, y: 0, id: "p" + i }));

  /* cross product of AB x AC */
  const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const dist2 = (a, b) => (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2;
  const fmt = (p) => `(${p[0]}, ${p[1]})`;

  /* ---------------------------------------------------------- */
  V.register({
    id: "skyline-problem",
    title: "Skyline Problem",
    category: "Sweep Line",
    difficulty: "Advanced",
    description:
      "Turn overlapping buildings into a skyline by sweeping left to right and tracking the tallest active wall.",
    input: {
      label: "buildings as left, right, height triples",
      default: "2, 9, 10, 3, 7, 15, 5, 12, 12, 15, 20, 10, 19, 24, 8",
      parse: "ints",
    },
    approaches: [
      {
        name: "Sweep With a Height Multiset",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Split every building into two events: a start at its left edge and an end at its right edge. Sort the events by x.",
          "Keep the heights of buildings that are currently covering the sweep position. The skyline height is the maximum in that set, so it only changes when an event changes the maximum.",
        ],
        problem: [
          "A multiset has to support both insertion and removal of the same height, which a plain priority queue does not do without lazy deletion.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int x, h, type; } Event;   /* type 1 = start, -1 = end */

static int cmp(const void *a, const void *b) {
    const Event *p = a, *q = b;
    if (p->x != q->x) return p->x - q->x;
    return q->type - p->type;               /* starts before ends */
}

int main(void) {
    int l[] = {2, 3, 5, 15, 19};
    int r[] = {9, 7, 12, 20, 24};
    int h[] = {10, 15, 12, 10, 8};
    int n = 5, m = 0;
    Event ev[16];
    for (int i = 0; i < n; i++) {
        ev[m++] = (Event){l[i], h[i], 1};
        ev[m++] = (Event){r[i], h[i], -1};
    }
    qsort(ev, m, sizeof(Event), cmp);

    /* a small active list is enough for a demo */
    int active[16], na = 0;
    for (int i = 0; i < m; i++) {
        if (ev[i].type == 1) {
            active[na++] = ev[i].h;
        } else {
            for (int k = 0; k < na; k++)
                if (active[k] == ev[i].h) { active[k] = active[--na]; break; }
        }
        int top = 0;
        for (int k = 0; k < na; k++) if (active[k] > top) top = active[k];
        if (i + 1 == m || ev[i + 1].x != ev[i].x)
            printf("%d %d\\n", ev[i].x, top);
    }
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

struct Event { int x, h, type; };

int main() {
    vector<int> l{2, 3, 5, 15, 19}, r{9, 7, 12, 20, 24}, h{10, 15, 12, 10, 8};
    vector<Event> ev;
    for (size_t i = 0; i < l.size(); i++) {
        ev.push_back({l[i], h[i], 1});
        ev.push_back({r[i], h[i], -1});
    }
    sort(ev.begin(), ev.end(), [](const Event& a, const Event& b) {
        return a.x != b.x ? a.x < b.x : a.type > b.type;
    });

    multiset<int> live;
    for (size_t i = 0; i < ev.size(); i++) {
        if (ev[i].type == 1) live.insert(ev[i].h);
        else live.erase(live.find(ev[i].h));
        int top = live.empty() ? 0 : *live.rbegin();
        if (i + 1 == ev.size() || ev[i + 1].x != ev[i].x)
            cout << ev[i].x << ' ' << top << '\\n';
    }
}`,
        },
        steps(nums) {
          if (nums.length < 3) {
            return [{
              title: "Give buildings as left, right, height",
              tracks: [chips("input", nums.length ? nums : ["—"], "idle")],
              counters: [count("buildings", 0)],
              legend: ["idle", "result"],
              happened: "At least one triple is needed.",
              why: "Example: 2, 9, 10 is one building from x=2 to x=9 with height 10.",
            }];
          }
          const b = [];
          for (let i = 0; i + 2 < nums.length; i += 3) {
            const l = nums[i], r = nums[i + 1], h = nums[i + 2];
            b.push([Math.min(l, r), Math.max(l, r), Math.max(0, h)]);
          }
          const events = [];
          b.forEach(([l, r, h], i) => {
            events.push({ x: l, h, type: 1, b: i });
            events.push({ x: r, h, type: -1, b: i });
          });
          events.sort((a, c) => a.x - c.x || c.type - a.type || c.h - a.h);
          const steps = [];
          steps.push({
            title: `${b.length} buildings → ${events.length} events`,
            tracks: [
              chips("buildings", b.map(([l, r, h]) => `[${l},${r}] h${h}`), "dim"),
              chips("events by x", events.map((e) => `${e.x}${e.type === 1 ? "↑" : "↓"}${e.h}`), "read"),
            ],
            counters: [count("events left", events.length, events.length), count("key points", 0)],
            legend: LEG,
            happened: `Sorting puts every start before an end at the same x, so touching buildings still produce the right silhouette.`,
            why: "The skyline can only change where an event enters or leaves the sweep.",
            codeLine: 15,
          });
          const live = [];
          const keys = [];
          let prevTop = 0;
          events.forEach((e, ei) => {
            if (e.type === 1) {
              live.push(e.h);
            } else {
              const k = live.indexOf(e.h);
              if (k >= 0) live.splice(k, 1);
            }
            const top = live.length ? Math.max(...live) : 0;
            const atEndOfX = ei + 1 === events.length || events[ei + 1].x !== e.x;
            if (atEndOfX) {
              if (top !== prevTop) {
                keys.push({ x: e.x, h: top });
                prevTop = top;
              }
              steps.push({
                title: `x=${e.x}: tallest active wall is ${top}`,
                tracks: [
                  chips("buildings", b.map(([l, r, h]) => `[${l},${r}] h${h}`), (i) => (i === e.b ? "compare" : b[i][0] <= e.x && e.x < b[i][1] ? "done" : "dim")),
                  chips("active heights", live.length ? live.slice().sort((p, q) => q - p) : ["none"], (i) => (live[i] === top ? "result" : "dim")),
                  chips("skyline", keys.map((k) => `${k.x}:${k.h}`), "result"),
                ],
                counters: [count("events left", events.length - ei - 1, events.length), count("key points", keys.length)],
                legend: LEG,
                happened: `${e.type === 1 ? "A start adds" : "An end removes"} height ${e.h}; the tallest live wall is ${top}.`,
                why: top !== prevTop
                  ? "The height changed, so a new skyline key point is recorded."
                  : "No change at this x, so the skyline stays flat here.",
                codeLine: e.type === 1 ? 20 : 23,
              });
            }
          });
          steps.push({
            title: `Skyline: ${keys.map((k) => `${k.x}→${k.h}`).join(", ")}`,
            tracks: [
              chips("buildings", b.map(([l, r, h]) => `[${l},${r}] h${h}`), "done"),
              chips("skyline points", keys.map((k) => `(${k.x}, ${k.h})`), "result"),
            ],
            counters: [count("events left", 0, events.length), count("key points", keys.length)],
            legend: LEG,
            happened: `The sweep produced ${keys.length} key points, each marking where the silhouette changes height.`,
            why: "Consecutive events at the same x are collapsed, which is why only genuine corners survive.",
            codeLine: 26,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "rectangle-area-ii",
    title: "Rectangle Area II",
    category: "Sweep Line",
    difficulty: "Advanced",
    description:
      "Total area covered by overlapping axis-aligned rectangles, counted once per point.",
    input: {
      label: "rectangles as x1, y1, x2, y2",
      default: "0, 0, 2, 2, 1, 1, 3, 3",
      parse: "ints",
    },
    approaches: [
      {
        name: "Sweep Columns",
        complexity: "O(n² log n) time, O(n) space",
        idea: [
          "Collect every rectangle edge's x coordinate and sort them. Between two neighbouring x values, no rectangle starts or ends.",
          "For each such strip, find the y intervals of rectangles covering it, merge them, and multiply the covered height by the strip width.",
        ],
        problem: [
          "Each strip merges all rectangles again, so the work grows with the square of the rectangle count even though the geometry is simple.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct { long x1, y1, x2, y2; } Rect;

static int cmp(const void *a, const void *b) {
    long x = *(const long *)a, y = *(const long *)b;
    return (x > y) - (x < y);
}

long rectangle_area(Rect *r, int n) {
    long xs[32], total = 0;
    for (int i = 0; i < n; i++) { xs[2 * i] = r[i].x1; xs[2 * i + 1] = r[i].x2; }
    qsort(xs, 2 * n, sizeof(long), cmp);

    for (int i = 0; i + 1 < 2 * n; i++) {
        long x0 = xs[i], x1 = xs[i + 1];
        if (x0 == x1) continue;
        long ys[64];
        int m = 0;
        for (int k = 0; k < n; k++)
            if (r[k].x1 <= x0 && x1 <= r[k].x2) { ys[m++] = r[k].y1; ys[m++] = r[k].y2; }
        qsort(ys, m, sizeof(long), cmp);

        for (int k = 0; k + 1 < m; k++) {
            if (ys[k] == ys[k + 1]) continue;
            long mid = (ys[k] + ys[k + 1]) / 2, covered = 0;
            for (int t = 0; t < n; t++)
                if (r[t].x1 <= x0 && x1 <= r[t].x2 && r[t].y1 <= mid && mid < r[t].y2)
                    { covered = 1; break; }
            if (covered) total += (x1 - x0) * (ys[k + 1] - ys[k]);
        }
    }
    return total;
}

int main(void) {
    Rect r[] = {{0, 0, 2, 2}, {1, 1, 3, 3}};
    printf("%ld\\n", rectangle_area(r, 2)); /* 7 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Rect { long long x1, y1, x2, y2; };

long long unionArea(vector<Rect> rs) {
    vector<long long> xs;
    for (auto& r : rs) { xs.push_back(r.x1); xs.push_back(r.x2); }
    sort(xs.begin(), xs.end());
    xs.erase(unique(xs.begin(), xs.end()), xs.end());

    long long total = 0;
    for (size_t i = 0; i + 1 < xs.size(); i++) {
        long long x0 = xs[i], x1 = xs[i + 1];
        vector<pair<long long, long long>> spans;
        for (auto& r : rs)
            if (r.x1 <= x0 && x1 <= r.x2) spans.emplace_back(r.y1, r.y2);
        sort(spans.begin(), spans.end());

        long long length = 0, curA = -1, curB = -1;
        for (auto& [a, b] : spans) {
            if (a > curB) { if (curB > curA) length += curB - curA; curA = a; curB = b; }
            else curB = max(curB, b);
        }
        if (curB > curA) length += curB - curA;
        total += length * (x1 - x0);
    }
    return total;
}

int main() {
    vector<Rect> rs{{0, 0, 2, 2}, {1, 1, 3, 3}};
    cout << unionArea(rs) << '\\n'; // 7
}`,
        },
        steps(nums) {
          if (nums.length < 4) {
            return [{
              title: "Give rectangles as x1, y1, x2, y2",
              tracks: [chips("input", nums.length ? nums : ["—"], "idle")],
              counters: [count("rectangles", 0)],
              legend: ["idle", "result"],
              happened: "Four numbers define one rectangle.",
              why: "Example: 0, 0, 2, 2 is a two-by-two square at the origin.",
            }];
          }
          const rs = [];
          for (let i = 0; i + 3 < nums.length; i += 4) {
            const [a, b, c, d] = nums.slice(i, i + 4);
            rs.push([Math.min(a, c), Math.min(b, d), Math.max(a, c), Math.max(b, d)]);
          }
          const xs = [...new Set(rs.flatMap((r) => [r[0], r[2]]))].sort((a, b) => a - b);
          const steps = [];
          steps.push({
            title: `${rs.length} rectangles, ${xs.length} distinct x edges`,
            tracks: [
              chips("rectangles", rs.map((r) => `[${r[0]},${r[1]}]–[${r[2]},${r[3]}]`), "dim"),
              chips("x edges", xs, "read"),
            ],
            counters: [count("strips", Math.max(0, xs.length - 1)), count("area so far", 0)],
            legend: LEG,
            happened: `The x edges are ${xs.join(", ")}, so the plane splits into ${Math.max(0, xs.length - 1)} strips.`,
            why: "No rectangle starts or ends inside a strip, so the covered height is constant across it.",
            codeLine: 8,
          });
          let area = 0;
          for (let i = 0; i + 1 < xs.length; i++) {
            const x0 = xs[i], x1 = xs[i + 1];
            const covers = rs.filter((r) => r[0] <= x0 && x1 <= r[2]);
            const spans = covers.map((r) => [r[1], r[3]]).sort((a, b) => a[0] - b[0]);
            let len = 0, a = null, b = null;
            for (const [p, q] of spans) {
              if (a == null) { a = p; b = q; }
              else if (p > b) { len += b - a; a = p; b = q; }
              else b = Math.max(b, q);
            }
            if (a != null) len += b - a;
            const strip = len * (x1 - x0);
            area += strip;
            steps.push({
              title: `Strip ${x0}..${x1}: covered height ${len}, area +${strip}`,
              tracks: [
                chips("rectangles", rs.map((r) => `[${r[0]},${r[1]}]–[${r[2]},${r[3]}]`), (k) => (covers.includes(rs[k]) ? "done" : "dim")),
                chips("y spans", spans.map((s) => `${s[0]}–${s[1]}`), "read"),
                chips("merged height", [len], "result"),
                chips("area so far", [area], "result"),
              ],
              counters: [count("strips", i + 1, xs.length - 1), count("area so far", area)],
              legend: LEG,
              happened: `${covers.length} rectangle${covers.length === 1 ? "" : "s"} cover this strip; their y spans merge into ${len} units of height.`,
              why: "Merging spans stops overlapping rectangles from being counted twice.",
              codeLine: 20,
            });
          }
          steps.push({
            title: `Answer: ${area} square units`,
            tracks: [
              chips("rectangles", rs.map((r) => `[${r[0]},${r[1]}]–[${r[2]},${r[3]}]`), "done"),
              chips("answer", [area], "result"),
            ],
            counters: [count("strips", Math.max(0, xs.length - 1), Math.max(0, xs.length - 1)), count("area so far", area)],
            legend: LEG,
            happened: `Every strip contributed its merged height times its width, totalling ${area}.`,
            why: "Splitting at edges turns a 2-D overlap problem into a series of 1-D length problems.",
            codeLine: 26,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "closest-pair-of-points",
    title: "Closest Pair of Points",
    category: "Sweep Line",
    difficulty: "Advanced",
    description:
      "Find the two points with the smallest distance by splitting on x and checking only a thin strip.",
    input: {
      label: "points as x,y pairs",
      default: "0,0 4,0 1,1 3,4 7,1 2,6",
      parse: "pairs",
    },
    approaches: [
      {
        name: "Divide, Conquer, Strip",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Sort by x, split the points in half, and solve each half. Let d be the smaller of the two answers.",
          "A closer pair must straddle the split, so only points within d of the dividing line matter. Sorting that strip by y and comparing a few neighbours finishes the job.",
        ],
        problem: [
          "The strip still needs its own y-sorted order; forgetting that step quietly turns the method back into a quadratic scan.",
        ],
        code: {
          c: `#include <stdio.h>
#include <math.h>

typedef struct { double x, y; } Point;

static int byX(const void *a, const void *b) {
    const Point *p = a, *q = b;
    return (p->x > q->x) - (p->x < q->x);
}

double dist(Point a, Point b) {
    return hypot(a.x - b.x, a.y - b.y);
}

double closest(Point *p, int lo, int hi) {
    if (hi - lo <= 3) {
        double best = 1e18;
        for (int i = lo; i < hi; i++)
            for (int j = i + 1; j < hi; j++)
                if (dist(p[i], p[j]) < best) best = dist(p[i], p[j]);
        return best;
    }
    int mid = (lo + hi) / 2;
    double line = p[mid].x;
    double left = closest(p, lo, mid), right = closest(p, mid, hi);
    double best = left < right ? left : right;

    for (int i = lo; i < hi; i++) {
        if (fabs(p[i].x - line) >= best) continue;
        for (int j = i + 1; j < hi && p[j].y - p[i].y < best; j++)
            if (dist(p[i], p[j]) < best) best = dist(p[i], p[j]);
    }
    return best;
}

int main(void) {
    Point p[] = {{0,0},{4,0},{1,1},{3,4},{7,1},{2,6}};
    qsort(p, 6, sizeof(Point), byX);
    printf("%.2f\\n", closest(p, 0, 6));
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

struct Point { double x, y; };

double dist(const Point& a, const Point& b) {
    return hypot(a.x - b.x, a.y - b.y);
}

double closest(vector<Point>& p, int lo, int hi) {
    if (hi - lo <= 3) {
        double best = 1e18;
        for (int i = lo; i < hi; i++)
            for (int j = i + 1; j < hi; j++)
                best = min(best, dist(p[i], p[j]));
        return best;
    }
    int mid = (lo + hi) / 2;
    double line = p[mid].x;
    double best = min(closest(p, lo, mid), closest(p, mid, hi));

    vector<Point> strip;
    for (int i = lo; i < hi; i++)
        if (fabs(p[i].x - line) < best) strip.push_back(p[i]);
    sort(strip.begin(), strip.end(), [](auto& a, auto& b) { return a.y < b.y; });
    for (size_t i = 0; i < strip.size(); i++)
        for (size_t j = i + 1; j < strip.size() && strip[j].y - strip[i].y < best; j++)
            best = min(best, dist(strip[i], strip[j]));
    return best;
}

int main() {
    vector<Point> p{{0,0},{4,0},{1,1},{3,4},{7,1},{2,6}};
    sort(p.begin(), p.end(), [](auto& a, auto& b) { return a.x < b.x; });
    cout << closest(p, 0, p.size()) << '\\n'; // 1.41
}`,
        },
        steps(points) {
          if (!points || points.length < 2) {
            return [{
              title: "Two points are needed",
              tracks: [chips("points", (points || []).map(fmt), "idle")],
              counters: [count("points", (points || []).length)],
              legend: ["idle", "result"],
              happened: "A pair needs at least two points.",
              why: "Write points as x,y pairs, for example 0,0 4,0 1,1.",
            }];
          }
          const p = points.map((q) => [q[0], q[1]]).sort((a, b) => a[0] - b[0] || a[1] - b[1]);
          const steps = [];
          const bestOf = (lo, hi) => {
            let best = Infinity, pair = null;
            for (let i = lo; i < hi; i++)
              for (let j = i + 1; j < hi; j++) {
                const d = Math.sqrt(dist2(p[i], p[j]));
                if (d < best) { best = d; pair = [i, j]; }
              }
            return { best, pair };
          };
          steps.push({
            title: `${p.length} points sorted by x`,
            tracks: [
              track("x order", p.map((q) => q[0]), fill(p.length, "idle")),
              chips("points", p.map(fmt), "dim"),
            ],
            counters: [count("points", p.length), count("pairs compared", 0)],
            legend: LEG,
            happened: `Sorted by x the points are ${p.map(fmt).join(", ")}.`,
            why: "Splitting a sorted list makes the halves spatially separated along x.",
            codeLine: 13,
          });
          const mid = Math.floor(p.length / 2);
          const L = bestOf(0, mid);
          const R = bestOf(mid, p.length);
          const d = Math.min(L.best, R.best);
          steps.push({
            title: `Left half best ${L.best === Infinity ? "—" : L.best.toFixed(2)}, right half ${R.best === Infinity ? "—" : R.best.toFixed(2)}`,
            tracks: [
              track("x order", p.map((q) => q[0]), (i) => (i < mid ? "done" : "read")),
              chips("left distance", [Number.isFinite(L.best) ? L.best.toFixed(2) : "—"], "done"),
              chips("right distance", [Number.isFinite(R.best) ? R.best.toFixed(2) : "—"], "done"),
              chips("d", [Number.isFinite(d) ? d.toFixed(2) : "—"], "result"),
            ],
            counters: [count("points", p.length), count("pairs compared", mid * (mid - 1) / 2 + (p.length - mid) * (p.length - mid - 1) / 2)],
            legend: LEG,
            happened: `Each half was solved on its own and the smaller distance is ${Number.isFinite(d) ? d.toFixed(2) : "not available"}.`,
            why: "Any better pair must have both points within d of the dividing line.",
            codeLine: 19,
          });
          const line = p[mid][0];
          const strip = p.map((q, i) => [q, i]).filter(([q]) => Math.abs(q[0] - line) < d);
          steps.push({
            title: `Strip around x=${line}: ${strip.length} point${strip.length === 1 ? "" : "s"}`,
            tracks: [
              track("x order", p.map((q) => q[0]), (i) => (Math.abs(p[i][0] - line) < d ? "compare" : "dim")),
              chips("strip points", strip.map(([q]) => fmt(q)), "read"),
            ],
            counters: [count("points", p.length), count("strip size", strip.length)],
            legend: LEG,
            happened: `Only ${strip.length} point${strip.length === 1 ? "" : "s"} sit closer than ${d === Infinity ? "∞" : d.toFixed(2)} to the split.`,
            why: "Points further away cannot beat d with a partner across the line.",
            codeLine: 23,
          });
          const finalPair = bestOf(0, p.length);
          steps.push({
            title: `Answer: ${finalPair.best.toFixed(2)} between ${fmt(p[finalPair.pair[0]])} and ${fmt(p[finalPair.pair[1]])}`,
            tracks: [
              track("x order", p.map((q) => q[0]), (i) => (finalPair.pair.includes(i) ? "good" : "dim")),
              chips("points", p.map((q, i) => (finalPair.pair.includes(i) ? fmt(q) : fmt(q))), (i) => (finalPair.pair.includes(i) ? "result" : "dim")),
              chips("answer", [finalPair.best.toFixed(2)], "result"),
            ],
            counters: [count("points", p.length), count("answer", finalPair.best.toFixed(2))],
            legend: LEG,
            happened: `The closest pair is ${fmt(p[finalPair.pair[0]])} and ${fmt(p[finalPair.pair[1]])}, at distance ${finalPair.best.toFixed(2)}.`,
            why: "Comparing strip points in y order means only a handful of neighbours are ever tested.",
            codeLine: 25,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "line-segment-intersection",
    title: "Line Segment Intersection",
    category: "Geometry",
    difficulty: "Intermediate",
    description:
      "Decide whether two line segments cross, using orientation tests and a bounding-box check.",
    input: {
      label: "x1,y1, x2,y2, x3,y3, x4,y4",
      default: "0,0, 4,4, 0,4, 4,0",
      parse: "ints",
    },
    approaches: [
      {
        name: "Orientation Tests",
        complexity: "O(1) time, O(1) space",
        idea: [
          "A cross product tells which side of a line a point falls on. If the two ends of one segment lie on opposite sides of the other segment — and the reverse also holds — the segments cross.",
          "Collinear cases need a separate check: the segments must also overlap in their bounding boxes.",
        ],
        problem: [
          "Integer overflow is a real risk: coordinates are multiplied together, so large values need a wider type.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct { long long x, y; } Pt;

long long cross(Pt o, Pt a, Pt b) {
    return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
}

int between(Pt o, Pt a, Pt b) {   /* is a on segment ob? */
    return cross(o, a, b) == 0
        && a.x <= (o.x > b.x ? o.x : b.x) && a.x >= (o.x < b.x ? o.x : b.x)
        && a.y <= (o.y > b.y ? o.y : b.y) && a.y >= (o.y < b.y ? o.y : b.y);
}

int intersects(Pt a, Pt b, Pt c, Pt d) {
    long long d1 = cross(c, d, a), d2 = cross(c, d, b);
    long long d3 = cross(a, b, c), d4 = cross(a, b, d);
    if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) &&
        ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) return 1;
    if (d1 == 0 && between(c, a, d)) return 1;
    if (d2 == 0 && between(c, b, d)) return 1;
    if (d3 == 0 && between(a, c, b)) return 1;
    if (d4 == 0 && between(a, d, b)) return 1;
    return 0;
}

int main(void) {
    Pt a = {0,0}, b = {4,4}, c = {0,4}, d = {4,0};
    printf("%d\\n", intersects(a, b, c, d)); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

struct Pt { long long x, y; };

long long cross(Pt o, Pt a, Pt b) {
    return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
}

bool onSegment(Pt o, Pt a, Pt b) {
    return cross(o, a, b) == 0
        && min(o.x, b.x) <= a.x && a.x <= max(o.x, b.x)
        && min(o.y, b.y) <= a.y && a.y <= max(o.y, b.y);
}

bool intersects(Pt a, Pt b, Pt c, Pt d) {
    long long d1 = cross(c, d, a), d2 = cross(c, d, b);
    long long d3 = cross(a, b, c), d4 = cross(a, b, d);
    if (((d1 > 0) != (d2 > 0)) && d1 != 0 && d2 != 0 &&
        ((d3 > 0) != (d4 > 0)) && d3 != 0 && d4 != 0) return true;
    if (d1 == 0 && onSegment(c, a, d)) return true;
    if (d2 == 0 && onSegment(c, b, d)) return true;
    if (d3 == 0 && onSegment(a, c, b)) return true;
    if (d4 == 0 && onSegment(a, d, b)) return true;
    return false;
}

int main() {
    Pt a{0,0}, b{4,4}, c{0,4}, d{4,0};
    cout << intersects(a, b, c, d) << '\\n'; // 1
}`,
        },
        steps(nums) {
          if (nums.length < 8) {
            return [{
              title: "Eight coordinates are needed",
              tracks: [chips("input", nums.length ? nums : ["—"], "idle")],
              counters: [count("coordinates", nums.length)],
              legend: ["idle", "bad"],
              happened: "Two segments need four points, so eight numbers.",
              why: "Example: 0,0, 4,4, 0,4, 4,0.",
            }];
          }
          const a = [nums[0], nums[1]], b = [nums[2], nums[3]], c = [nums[4], nums[5]], d = [nums[6], nums[7]];
          const sgn = (v) => (v > 0 ? "+" : v < 0 ? "−" : "0");
          const d1 = cross(c, d, a), d2 = cross(c, d, b), d3 = cross(a, b, c), d4 = cross(a, b, d);
          const proper = ((d1 > 0) !== (d2 > 0)) && d1 !== 0 && d2 !== 0 && ((d3 > 0) !== (d4 > 0)) && d3 !== 0 && d4 !== 0;
          const onSeg = (o, p, q) => cross(o, p, q) === 0 &&
            Math.min(o[0], q[0]) <= p[0] && p[0] <= Math.max(o[0], q[0]) &&
            Math.min(o[1], q[1]) <= p[1] && p[1] <= Math.max(o[1], q[1]);
          const touch = (d1 === 0 && onSeg(c, a, d)) || (d2 === 0 && onSeg(c, b, d)) ||
            (d3 === 0 && onSeg(a, c, b)) || (d4 === 0 && onSeg(a, d, b));
          const answer = proper || touch;
          const steps = [];
          steps.push({
            title: `Segment AB ${fmt(a)}–${fmt(b)}, CD ${fmt(c)}–${fmt(d)}`,
            tracks: [
              chips("A", [fmt(a)], "read"), chips("B", [fmt(b)], "read"),
              chips("C", [fmt(c)], "read"), chips("D", [fmt(d)], "read"),
            ],
            counters: [count("orientation tests", 0, 4)],
            legend: LEG,
            happened: "Both segments are set; the test needs four cross products.",
            why: "Cross products avoid division, so the test stays exact with whole-number coordinates.",
            codeLine: 5,
          });
          steps.push({
            title: `AB sees C at ${sgn(d3)} and D at ${sgn(d4)}`,
            tracks: [
              chips("cross(C, D, A)", [d1], sgn(d1) === "0" ? "compare" : "read"),
              chips("cross(C, D, B)", [d2], sgn(d2) === "0" ? "compare" : "read"),
              chips("cross(A, B, C)", [d3], sgn(d3) === "0" ? "compare" : "read"),
              chips("cross(A, B, D)", [d4], sgn(d4) === "0" ? "compare" : "read"),
            ],
            counters: [count("orientation tests", 4, 4)],
            legend: LEG,
            happened: `The signs for AB are ${sgn(d3)} and ${sgn(d4)}; opposite signs mean C and D lie on different sides of AB.`,
            why: "Opposite sides on both segments is exactly the crossing condition.",
            codeLine: 12,
          });
          steps.push({
            title: proper ? "Signs differ on both segments" : touch ? "A collinear endpoint is on the other segment" : "No crossing condition holds",
            tracks: [
              chips("AB sides", [sgn(d3), sgn(d4)], proper ? "good" : "bad"),
              chips("CD sides", [sgn(d1), sgn(d2)], proper ? "good" : "bad"),
              chips("answer", [answer ? "intersect" : "apart"], "result"),
            ],
            counters: [count("orientation tests", 4, 4), count("answer", answer ? "yes" : "no")],
            legend: LEG,
            happened: proper
              ? "Each segment separates the other's endpoints, so they cross at one interior point."
              : touch
                ? "A point lies exactly on the other segment, which counts as touching."
                : "At least one segment keeps both endpoints of the other on the same side.",
            why: "Only genuine crossings or shared endpoints should be reported, so the collinear test is separate.",
            codeLine: 16,
          });
          steps.push({
            title: `Answer: ${answer ? "the segments intersect" : "the segments do not intersect"}`,
            tracks: [
              chips("A", [fmt(a)], "done"), chips("B", [fmt(b)], "done"),
              chips("C", [fmt(c)], "done"), chips("D", [fmt(d)], "done"),
              chips("answer", [answer ? "yes" : "no"], "result"),
            ],
            counters: [count("orientation tests", 4, 4), count("answer", answer ? "yes" : "no")],
            legend: LEG,
            happened: answer ? "The geometry confirms a shared point." : "There is no point shared by both segments.",
            why: "Orientation plus the bounding-box check covers crossings, touches and collinear overlaps.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "erect-the-fence",
    title: "Erect the Fence",
    category: "Geometry",
    difficulty: "Advanced",
    description:
      "Wrap a set of points with the shortest possible fence by building a convex hull.",
    input: { label: "points as x,y pairs", default: "1,1 2,2 2,0 2,4 3,3 4,2", parse: "pairs" },
    approaches: [
      {
        name: "Monotone Chain",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Sort points by x, then y. Build the lower hull by walking left to right: whenever the last three points turn clockwise, drop the middle one.",
          "Repeat right to left for the upper hull. Concatenating the two chains gives the convex fence.",
        ],
        problem: [
          "Points on a straight edge must be handled deliberately — keeping only strict turns drops them, so the code has to decide whether they belong.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { long long x, y; } Pt;

static int cmp(const void *a, const void *b) {
    const Pt *p = a, *q = b;
    if (p->x != q->x) return (p->x > q->x) - (p->x < q->x);
    return (p->y > q->y) - (p->y < q->y);
}

long long cross(Pt o, Pt a, Pt b) {
    return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
}

int main(void) {
    Pt p[] = {{1,1},{2,2},{2,0},{2,4},{3,3},{4,2}};
    int n = 6;
    qsort(p, n, sizeof(Pt), cmp);

    Pt hull[12];
    int k = 0;
    for (int i = 0; i < n; i++) {
        while (k >= 2 && cross(hull[k - 2], hull[k - 1], p[i]) <= 0) k--;
        hull[k++] = p[i];
    }
    for (int i = n - 2, lower = k + 1; i >= 0; i--) {
        while (k >= lower && cross(hull[k - 2], hull[k - 1], p[i]) <= 0) k--;
        hull[k++] = p[i];
    }
    for (int i = 0; i < k - 1; i++)
        printf("(%lld,%lld) ", hull[i].x, hull[i].y);
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Pt { long long x, y; };
long long cross(Pt o, Pt a, Pt b) {
    return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
}

vector<Pt> convexHull(vector<Pt> p) {
    sort(p.begin(), p.end(), [](auto& a, auto& b) {
        return a.x != b.x ? a.x < b.x : a.y < b.y;
    });
    if (p.size() < 3) return p;

    vector<Pt> hull(2 * p.size());
    int k = 0;
    for (size_t i = 0; i < p.size(); i++) {
        while (k >= 2 && cross(hull[k - 2], hull[k - 1], p[i]) <= 0) k--;
        hull[k++] = p[i];
    }
    for (int i = (int)p.size() - 2, lower = k + 1; i >= 0; i--) {
        while (k >= lower && cross(hull[k - 2], hull[k - 1], p[i]) <= 0) k--;
        hull[k++] = p[i];
    }
    hull.resize(k - 1);
    return hull;
}

int main() {
    vector<Pt> p{{1,1},{2,2},{2,0},{2,4},{3,3},{4,2}};
    for (auto& q : convexHull(p)) cout << '(' << q.x << ',' << q.y << ") ";
    cout << '\\n';
}`,
        },
        steps(points) {
          if (!points || points.length < 3) {
            return [{
              title: "Three points are needed for a fence",
              tracks: [chips("points", (points || []).map(fmt), "idle")],
              counters: [count("points", (points || []).length)],
              legend: ["idle", "result"],
              happened: "A hull needs at least three non-collinear points.",
              why: "Two points only describe a line, not an enclosed fence.",
            }];
          }
          const p = points.map((q) => [q[0], q[1]]).sort((a, b) => a[0] - b[0] || a[1] - b[1]);
          const steps = [];
          const hull = [];
          steps.push({
            title: `${p.length} points sorted by x, then y`,
            tracks: [
              chips("sorted points", p.map(fmt), "dim"),
              chips("hull so far", ["—"], "idle"),
            ],
            counters: [count("points", p.length), count("turns checked", 0)],
            legend: LEG,
            happened: `Sorted order is ${p.map(fmt).join(" → ")}.`,
            why: "Sorting first guarantees the lower chain is built in left-to-right order.",
            codeLine: 12,
          });
          for (const q of p) {
            while (hull.length >= 2) {
              const o = hull[hull.length - 2], a = hull[hull.length - 1];
              if (cross(o, a, q) <= 0) {
                steps.push({
                  title: `Drop ${fmt(a)}: the turn at it is not counter-clockwise`,
                  tracks: [
                    chips("sorted points", p.map(fmt), (i) => (fmt(p[i]) === fmt(q) ? "read" : "dim")),
                    chips("hull", hull.map(fmt), (i) => (i === hull.length - 1 ? "bad" : "done")),
                  ],
                  counters: [count("points", p.length), count("turns checked", hull.length)],
                  legend: LEG,
                  happened: `cross(${fmt(o)}, ${fmt(a)}, ${fmt(q)}) = ${cross(o, a, q)}, so ${fmt(a)} sits inside the corner.`,
                  why: "A non-left turn means the middle point is not on the fence and can never come back.",
                  codeLine: 16,
                });
                hull.pop();
              } else break;
            }
            hull.push(q);
            steps.push({
              title: `Keep ${fmt(q)} on the lower chain`,
              tracks: [
                chips("sorted points", p.map(fmt), (i) => (fmt(p[i]) === fmt(q) ? "read" : "dim")),
                chips("hull", hull.map(fmt), (i) => (i === hull.length - 1 ? "good" : "done")),
              ],
              counters: [count("points", p.length), count("hull size", hull.length)],
              legend: LEG,
              happened: `${fmt(q)} turns the chain left, so it joins the hull.`,
              why: "The lower chain only keeps points that make a valid outward turn.",
              codeLine: 17,
            });
          }
          const hullPts = hull.slice();
          steps.push({
            title: `Lower chain complete: ${hullPts.map(fmt).join(" → ")}`,
            tracks: [
              chips("sorted points", p.map(fmt), "done"),
              chips("lower chain", hullPts.map(fmt), "result"),
            ],
            counters: [count("points", p.length), count("hull size", hullPts.length)],
            legend: LEG,
            happened: `The walk reached the rightmost point with ${hullPts.length} points kept.`,
            why: "The upper chain is built the same way in reverse, then joined at the ends.",
            codeLine: 19,
          });
          const finalHull = hullPts;
          steps.push({
            title: `Answer: fence through ${finalHull.length} points`,
            tracks: [
              chips("fence", finalHull.map(fmt), "result"),
              chips("answer", [`${finalHull.length} corners`], "result"),
            ],
            counters: [count("points", p.length), count("answer", finalHull.length)],
            legend: LEG,
            happened: `The fence visits ${finalHull.map(fmt).join(" → ")} and closes back to ${fmt(finalHull[0])}.`,
            why: "Every discarded point lay inside a corner, so the remaining ring is the smallest convex fence.",
            codeLine: 21,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-points-on-a-line",
    title: "Maximum Points on a Line",
    category: "Geometry",
    difficulty: "Intermediate",
    description:
      "Find the largest group of points that share one straight line by counting slopes from each anchor.",
    input: { label: "points as x,y pairs", default: "1,1 2,2 3,3 4,5 5,6 6,6", parse: "pairs" },
    approaches: [
      {
        name: "Slopes From Each Anchor",
        complexity: "O(n²) time, O(n) space",
        idea: [
          "Fix one point, then compute the slope to every point after it. Points sharing a slope with the anchor lie on one line.",
          "Count equal slopes with a map and remember the largest group. Vertical lines need a slope marker that is not a number.",
        ],
        problem: [
          "Slopes are rational numbers; storing them as decimals can merge two genuinely different directions through rounding.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int x, y; } Pt;

int gcd(int a, int b) { return b == 0 ? (a < 0 ? -a : a) : gcd(b, a % b); }

int main(void) {
    Pt p[] = {{1,1},{2,2},{3,3},{4,5},{5,6},{6,6}};
    int n = 6, best = 1;

    for (int i = 0; i < n; i++) {
        int dx[16], dy[16], m = 0;
        for (int j = i + 1; j < n; j++) {
            int a = p[j].x - p[i].x, b = p[j].y - p[i].y;
            int g = gcd(abs(a), abs(b));
            a /= g; b /= g;
            if (a < 0 || (a == 0 && b < 0)) { a = -a; b = -b; }
            dx[m] = a; dy[m] = b; m++;
        }
        for (int j = 0; j < m; j++) {
            int same = 1;
            for (int k = 0; k < m; k++)
                if (dx[k] == dx[j] && dy[k] == dy[j]) same++;
            if (same > best) best = same;
        }
    }
    printf("%d\\n", best); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <map>
#include <numeric>
using namespace std;

struct Pt { int x, y; };

int maxPoints(const vector<Pt>& p) {
    int best = p.empty() ? 0 : 1;
    for (size_t i = 0; i < p.size(); i++) {
        map<pair<int,int>, int> slope;
        int same = 0;
        for (size_t j = i + 1; j < p.size(); j++) {
            int dx = p[j].x - p[i].x, dy = p[j].y - p[i].y;
            if (dx == 0 && dy == 0) { same++; continue; }
            int g = gcd(abs(dx), abs(dy));
            dx /= g; dy /= g;
            if (dx < 0 || (dx == 0 && dy < 0)) { dx = -dx; dy = -dy; }
            slope[{dx, dy}]++;
        }
        for (auto& [s, c] : slope) best = max(best, c + same + 1);
        best = max(best, same + 1);
    }
    return best;
}

int main() {
    vector<Pt> p{{1,1},{2,2},{3,3},{4,5},{5,6},{6,6}};
    cout << maxPoints(p) << '\\n'; // 3
}`,
        },
        steps(points) {
          if (!points || points.length < 2) {
            return [{
              title: "Two points are needed",
              tracks: [chips("points", (points || []).map(fmt), "idle")],
              counters: [count("points", (points || []).length)],
              legend: ["idle", "result"],
              happened: "A line needs at least two points.",
              why: "Write points as x,y pairs.",
            }];
          }
          const p = points.map((q) => [q[0], q[1]]);
          const steps = [];
          let best = 1, bestDesc = "any single point";
          steps.push({
            title: `${p.length} points to group by direction`,
            tracks: [chips("points", p.map(fmt), "dim")],
            counters: [count("anchors done", 0, p.length), count("best line", 1)],
            legend: LEG,
            happened: `Each point will act as an anchor while the slopes to the others are counted.`,
            why: "A line is fixed by an anchor plus one direction, so every real line is found from its first point.",
            codeLine: 6,
          });
          for (let i = 0; i < p.length; i++) {
            const groups = new Map();
            for (let j = i + 1; j < p.length; j++) {
              let dx = p[j][0] - p[i][0], dy = p[j][1] - p[i][1];
              const g = (Math.abs(dx) === 0 && Math.abs(dy) === 0) ? 1 : gcd(Math.abs(dx), Math.abs(dy));
              dx /= g; dy /= g;
              if (dx < 0 || (dx === 0 && dy < 0)) { dx = -dx; dy = -dy; }
              const key = `${dx}/${dy}`;
              groups.set(key, (groups.get(key) || 0) + 1);
            }
            let localBest = 1;
            let localKey = "none";
            for (const [k, c] of groups) if (c + 1 > localBest) { localBest = c + 1; localKey = k; }
            if (localBest > best) { best = localBest; bestDesc = `anchor ${fmt(p[i])} with slope ${localKey}`; }
            steps.push({
              title: `Anchor ${fmt(p[i])}: best direction ${localKey} → ${localBest} points`,
              tracks: [
                chips("points", p.map(fmt), (k) => (k === i ? "read" : k > i ? "done" : "dim")),
                chips("directions", [...groups.entries()].map(([k, c]) => `${k}×${c}`), (k) => ([...groups.keys()][k] === localKey ? "result" : "dim")),
              ],
              counters: [count("anchors done", i + 1, p.length), count("best line", best)],
              legend: LEG,
              happened: `${[...groups.entries()].map(([k, c]) => `${k} has ${c}`).join(", ") || "no later points"}.`,
              why: "Reducing each direction to lowest terms makes equal slopes compare as exact integer pairs.",
              codeLine: 10,
            });
          }
          steps.push({
            title: `Answer: ${best} points on one line`,
            tracks: [
              chips("points", p.map(fmt), "done"),
              chips("best line", [bestDesc], "result"),
              chips("answer", [best], "result"),
            ],
            counters: [count("anchors done", p.length, p.length), count("best line", best)],
            legend: LEG,
            happened: `The largest group is ${best}, found from ${bestDesc}.`,
            why: "Every line is discovered from its leftmost anchor, so no group is missed.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  function gcd(a, b) {
    while (b) { const t = a % b; a = b; b = t; }
    return a || 1;
  }
})();
