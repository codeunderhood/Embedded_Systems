/* ============================================================
   DSA Visuals — Graphs IV
   Bridges, ratio chains, Euler trails, prerequisite reachability,
   binary lifting and maximum flow.
   ============================================================ */
(function () {
  "use strict";
  const { fill, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => `[${a.join(", ")}]`;
  const partsOf = (text) => String(text || "").split("|").map((p) => p.trim());
  const pairsOf = (text) =>
    String(text || "").split(/\s+/).filter(Boolean).map((p) => p.split(",").map((x) => parseInt(x, 10))).filter((p) => p.length === 2 && p.every(Number.isFinite));
  const triplesOf = (text) =>
    String(text || "").split(/\s+/).filter(Boolean).map((p) => p.split(",").map((x) => parseInt(x, 10))).filter((p) => p.length === 3 && p.every(Number.isFinite));

  function circlePos(i, n) {
    const a = (2 * Math.PI * i) / Math.max(1, n) - Math.PI / 2;
    return { x: +(25 + 20 * Math.cos(a)).toFixed(1), y: +(25 + 20 * Math.sin(a)).toFixed(1) };
  }
  function graphStep(labels, edges, states, edgeStates, extra) {
    return Object.assign({
      kind: "graph",
      nodes: labels.map((lab, i) => {
        const p = circlePos(i, labels.length);
        return { id: "n" + i, label: String(lab), x: p.x, y: p.y, state: (states && states[i]) || "idle" };
      }),
      edges: edges.map(([u, v], i) => ({ a: "n" + u, b: "n" + v, state: (edgeStates && edgeStates[i]) || "idle" })),
      legend: LEG,
    }, extra);
  }

  /* ---------------------------------------------------------- */
  V.register({
    id: "critical-connections",
    title: "Critical Connections",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Find the bridges whose removal disconnects the network.",
    input: { label: "nodes | edges as u,v pairs", default: "4 | 0,1 1,2 2,0 1,3", parse: "string" },
    approaches: [
      {
        name: "Tarjan Discovery and Low",
        complexity: "O(V + E) time",
        idea: [
          "Run DFS and record a discovery time for every vertex. Also track low[u], the earliest discovery time reachable from u's subtree using at most one back edge.",
          "When DFS returns from child v to parent u, the edge u–v is a bridge exactly when low[v] is greater than disc[u]: nothing in v's subtree can reach u or above without that edge.",
        ],
        problem: [
          "Removing each edge and testing connectivity costs O(E × (V + E)); Tarjan answers all bridges in one DFS.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint adj[4][4] = {{0,1,0,0},{1,0,1,1},{0,1,0,0},{0,1,0,0}};\nint disc[4] = {-1,-1,-1,-1}, low[4], timer;\n\nvoid dfs(int u, int parent) {\n    disc[u] = low[u] = timer++;\n    for (int v = 0; v < 4; v++) {\n        if (!adj[u][v] || v == parent) continue;\n        if (disc[v] == -1) {\n            dfs(v, u);\n            if (low[v] < low[u]) low[u] = low[v];\n            if (low[v] > disc[u]) printf(\"bridge %d-%d\\\\n\", u, v);\n        } else if (disc[v] < low[u]) low[u] = disc[v];\n    }\n}\n\nint main(void) {\n    dfs(0, -1);\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nvoid dfs(int u, int parent, vector<vector<int>>& adj, vector<int>& disc, vector<int>& low, int& timer, vector<vector<int>>& bridges) {\n    disc[u] = low[u] = timer++;\n    for (int v : adj[u]) {\n        if (v == parent) continue;\n        if (disc[v] == -1) {\n            dfs(v, u, adj, disc, low, timer, bridges);\n            low[u] = min(low[u], low[v]);\n            if (low[v] > disc[u]) bridges.push_back({u, v});\n        } else {\n            low[u] = min(low[u], disc[v]);\n        }\n    }\n}\n\nvector<vector<int>> criticalConnections(int n, vector<vector<int>>& edges) {\n    vector<vector<int>> adj(n);\n    for (auto& e : edges) { adj[e[0]].push_back(e[1]); adj[e[1]].push_back(e[0]); }\n\n    vector<int> disc(n, -1), low(n);\n    vector<vector<int>> bridges;\n    int timer = 0;\n    dfs(0, -1, adj, disc, low, timer, bridges);\n    return bridges;\n}\n\nint main() {\n    vector<vector<int>> edges{{0,1},{1,2},{2,0},{1,3}};\n    for (auto& b : criticalConnections(4, edges)) cout << b[0] << '-' << b[1] << ' '; // 1-3\n    cout << '\\\\n';\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const n = Math.min(10, Math.max(0, parseInt(parts[0], 10) || 0));
          const edges = pairsOf(parts[1] || "").filter(([u, v]) => u >= 0 && v >= 0 && u < n && v < n && u !== v).slice(0, 16);
          if (!n || !edges.length) return [{
            title: "Give a connected graph",
            tracks: [chips("nodes", ["—"], "idle")],
            counters: [count("bridges", 0)],
            legend: LEG,
            happened: "There are no edges to examine.",
            why: "A bridge needs at least one edge.",
          }];
          const labels = Array.from({ length: n }, (_, i) => i);
          const adj = Array.from({ length: n }, () => []);
          edges.forEach(([u, v], i) => { adj[u].push([v, i]); adj[v].push([u, i]); });
          const disc = Array(n).fill(-1);
          const low = Array(n).fill(-1);
          const edgeStates = Array(edges.length).fill("idle");
          const nodeStates = Array(n).fill("idle");
          const steps = [];
          let timer = 0;
          const bridges = [];
          const edgeIndex = (u, v) => edges.findIndex(([a, b]) => (a === u && b === v) || (a === v && b === u));
          const push = (title, extra) => {
            const m = {};
            labels.forEach((i) => { m[i] = nodeStates[i]; });
            steps.push(graphStep(labels, edges, m, edgeStates.slice(), Object.assign({
              title,
              label: `disc: ${disc.map((d) => (d < 0 ? "·" : d)).join(" ")}  low: ${low.map((d) => (d < 0 ? "·" : d)).join(" ")}`,
              counters: [count("time", timer), count("bridges", bridges.length, edges.length)],
              legend: LEG,
              happened: title,
              why: "A bridge is a tree edge with no back route around it.",
            }, extra || {})));
          };
          push(`Start DFS at vertex 0, timer ${timer}`, { codeLine: 5 });
          const dfs = (u, parent) => {
            disc[u] = low[u] = timer++;
            nodeStates[u] = "read";
            push(`Enter ${u}: disc = low = ${disc[u]}`, { codeLine: 6 });
            nodeStates[u] = "done";
            adj[u].forEach(([v, eid]) => {
              if (v === parent) return;
              if (disc[v] === -1) {
                edgeStates[eid] = "done";
                nodeStates[v] = "read";
                push(`Tree edge ${u}–${v}; descend`, { codeLine: 9 });
                dfs(v, u);
                low[u] = Math.min(low[u], low[v]);
                if (low[v] > disc[u]) {
                  bridges.push([u, v]);
                  edgeStates[eid] = "bad";
                  push(`Bridge found: ${u}–${v} (low ${low[v]} > disc ${disc[u]})`, { codeLine: 12 });
                } else {
                  edgeStates[eid] = "good";
                  push(`Edge ${u}–${v} is safe: low ${low[v]} ≤ disc ${disc[u]}`, { codeLine: 12 });
                }
              } else {
                if (edgeStates[eid] === "idle") edgeStates[eid] = "compare";
                low[u] = Math.min(low[u], disc[v]);
                push(`Back edge ${u}–${v} lowers low to ${low[u]}`, { codeLine: 14 });
              }
            });
          };
          dfs(0, -1);
          steps.push(graphStep(labels, edges, Object.fromEntries(labels.map((i) => [i, "result"])), edges.map(([u, v]) => (bridges.some(([a, b]) => (a === u && b === v) || (a === v && b === u)) ? "bad" : "done")), {
            title: `Answer: ${bridges.length ? bridges.map(([u, v]) => `${u}–${v}`).join(", ") : "no bridges"}`,
            label: `${bridges.length} critical connection${bridges.length === 1 ? "" : "s"}`,
            counters: [count("bridges", bridges.length, edges.length), count("time", timer)],
            legend: LEG,
            happened: bridges.length ? `Removing ${bridges.map(([u, v]) => `${u}–${v}`).join(", ")} splits the graph.` : "Every edge lies on a cycle, so none is critical.",
            why: "Each bridge is exactly an edge whose child subtree has no back edge to an ancestor.",
            codeLine: 12,
          }));
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "evaluate-division",
    title: "Evaluate Division",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Answer ratio queries using a graph of known division equations.",
    input: { label: "equations a/b=value | queries a/c", default: "a/b=2,b/c=3 | a/c,a/e,c/a", parse: "string" },
    approaches: [
      {
        name: "Weighted Graph Walk",
        complexity: "O((E + Q) × V) time",
        idea: [
          "Each equation a / b = k is two directed edges: a → b with weight k and b → a with weight 1/k.",
          "For a query x / y, walk from x to y multiplying weights along the path. If y is unreachable, the query has no defined answer.",
        ],
        problem: [
          "Treating ratios as ordinary unweighted edges loses the multiplication; each step must carry its factor.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\ndouble g[26][26];\nint seen[26];\n\ndouble dfs(int u, int target, double prod) {\n    if (u == target) return prod;\n    seen[u] = 1;\n    for (int v = 0; v < 26; v++)\n        if (g[u][v] > 0 && !seen[v]) {\n            double r = dfs(v, target, prod * g[u][v]);\n            if (r > 0) return r;\n        }\n    return -1;\n}\n\nint main(void) {\n    g['a'-'a']['b'-'a'] = 2.0; g['b'-'a']['a'-'a'] = 0.5;\n    g['b'-'a']['c'-'a'] = 3.0; g['c'-'a']['b'-'a'] = 1.0 / 3;\n\n    memset(seen, 0, sizeof(seen));\n    printf(\"%.2f\\\\n\", dfs('a'-'a', 'c'-'a', 1.0)); /* 6.00 */\n    memset(seen, 0, sizeof(seen));\n    printf(\"%.2f\\\\n\", dfs('a'-'a', 'e'-'a', 1.0)); /* -1.00 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <map>\n#include <set>\nusing namespace std;\n\ndouble dfs(string u, string target, map<string, vector<pair<string,double>>>& g, set<string>& seen) {\n    if (u == target) return 1.0;\n    seen.insert(u);\n    for (auto& [v, w] : g[u]) {\n        if (seen.count(v)) continue;\n        double r = dfs(v, target, g, seen);\n        if (r > 0) return w * r;\n    }\n    return -1.0;\n}\n\nvector<double> calcEquation(vector<vector<string>>& eq, vector<double>& val, vector<vector<string>>& queries) {\n    map<string, vector<pair<string,double>>> g;\n    for (int i = 0; i < (int)eq.size(); i++) {\n        g[eq[i][0]].push_back({eq[i][1], val[i]});\n        g[eq[i][1]].push_back({eq[i][0], 1.0 / val[i]});\n    }\n\n    vector<double> out;\n    for (auto& q : queries) {\n        if (!g.count(q[0]) || !g.count(q[1])) { out.push_back(-1.0); continue; }\n        set<string> seen;\n        out.push_back(dfs(q[0], q[1], g, seen));\n    }\n    return out;\n}\n\nint main() {\n    vector<vector<string>> eq{{\"a\",\"b\"},{\"b\",\"c\"}};\n    vector<double> val{2, 3};\n    vector<vector<string>> q{{\"a\",\"c\"},{\"a\",\"e\"},{\"c\",\"a\"}};\n    for (double x : calcEquation(eq, val, q)) cout << x << ' '; // 6 -1 0.5\n    cout << '\\\\n';\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const eqs = String(parts[0] || "").split(/[\s,]+/).filter(Boolean).map((s) => {
            const m = s.match(/^([A-Za-z0-9]+)\/([A-Za-z0-9]+)=(-?[\d.]+)$/);
            return m ? { a: m[1], b: m[2], k: Number(m[3]) } : null;
          }).filter(Boolean).slice(0, 12);
          const queries = String(parts[1] || "").split(/[\s,]+/).filter(Boolean).map((s) => {
            const p = s.split("/");
            return p.length === 2 ? p : null;
          }).filter(Boolean).slice(0, 10);
          if (!eqs.length) return [{
            title: "Give equations like a/b=2",
            tracks: [chips("equations", ["—"], "idle")],
            counters: [count("variables", 0)],
            legend: LEG,
            happened: "There are no ratio edges.",
            why: "Each equation contributes two directed weighted edges.",
          }];
          const vars = [...new Set(eqs.flatMap((e) => [e.a, e.b]))];
          const graph = new Map(vars.map((v) => [v, []]));
          eqs.forEach((e) => {
            graph.get(e.a).push({ to: e.b, w: e.k });
            graph.get(e.b).push({ to: e.a, w: 1 / e.k });
          });
          const steps = [];
          const edgeLabels = eqs.map((e) => `${e.a}/${e.b}=${e.k}`);
          steps.push({
            title: `${vars.length} variables, ${eqs.length} known ratios`,
            tracks: [
              chips("variables", vars, "active"),
              chips("equations", edgeLabels, "idle"),
              chips("queries", queries.map((q) => q.join("/")), "compare"),
            ],
            counters: [count("variables", vars.length), count("queries", queries.length)],
            legend: LEG,
            happened: "Each equation creates a forward factor and its reciprocal.",
            why: "Division is multiplication by the inverse, so edges are directed with weights.",
            codeLine: 6,
          });
          const answers = [];
          queries.forEach(([x, y]) => {
            if (!graph.has(x) || !graph.has(y)) {
              answers.push(-1);
              steps.push({
                title: `${x}/${y}: unknown variable`,
                tracks: [
                  chips("query", [`${x}/${y}`], "bad"),
                  chips("variables", vars, (i) => (vars[i] === x || vars[i] === y ? "bad" : "dim")),
                ],
                counters: [count("answer", -1), count("queries done", answers.length, queries.length)],
                legend: LEG,
                happened: x === y ? `${x}/${y} is 1 even without an equation, but the variable is absent here.` : `${x} or ${y} never appears in the equations.`,
                why: "A variable with no edges cannot be connected to the other side.",
                codeLine: 18,
              });
              return;
            }
            const stack = [{ v: x, prod: 1, path: [x] }];
            const seen = new Set([x]);
            let result = -1;
            let path = null;
            while (stack.length && result < 0) {
              const { v, prod, path: p } = stack.pop();
              if (v === y) { result = prod; path = p; break; }
              (graph.get(v) || []).forEach((e) => {
                if (seen.has(e.to)) return;
                seen.add(e.to);
                stack.push({ v: e.to, prod: prod * e.w, path: p.concat(e.to) });
              });
            }
            answers.push(result);
            steps.push({
              title: result >= 0 ? `${x}/${y} = ${result}` : `${x}/${y} is not connected`,
              tracks: [
                chips("query", [`${x}/${y}`], result >= 0 ? "result" : "bad"),
                chips("walk", path || [...seen], result >= 0 ? "result" : "dim"),
                chips("answers", answers.map((a) => (a < 0 ? "-1" : String(+a.toFixed(3)))), (i) => (i === answers.length - 1 ? "read" : "done")),
              ],
              counters: [count("answer", result < 0 ? -1 : +result.toFixed(3)), count("queries done", answers.length, queries.length)],
              legend: LEG,
              happened: path ? `${path.join(" → ")} multiplies to ${result}.` : `No chain of known ratios connects ${x} to ${y}.`,
              why: "Every path product is the same in a consistent ratio graph; reaching the target gives the answer.",
              codeLine: 21,
            });
          });
          steps.push({
            title: "Answer: query results are in order",
            tracks: [chips("answers", answers.map((a) => (a < 0 ? "-1" : String(+a.toFixed(3)))), "result"), chips("queries", queries.map((q) => q.join("/")), "done")],
            counters: [count("queries", queries.length), count("known", answers.filter((a) => a >= 0).length)],
            legend: LEG,
            happened: `Results: ${answers.map((a) => (a < 0 ? "-1" : String(+a.toFixed(3)))).join(", ")}.`,
            why: "Each query is independent; unreachable pairs return -1.",
            codeLine: 26,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  const eulerSteps = (raw, circuitMode) => {
    const edges = pairsOf(raw).filter(([u, v]) => u !== v).slice(0, 12);
    if (!edges.length) return [{
      title: "Give at least one edge",
      tracks: [chips("edges", ["—"], "idle")],
      counters: [count("edges", 0)],
      legend: LEG,
      happened: "There are no edges.",
      why: "An Euler trail needs edges to traverse.",
    }];
    const n = Math.min(10, Math.max(...edges.flat()) + 1);
    const labels = Array.from({ length: n }, (_, i) => i);
    const adj = Array.from({ length: n }, () => []);
    const deg = Array(n).fill(0);
    edges.forEach(([u, v], i) => { adj[u].push([v, i]); adj[v].push([u, i]); deg[u]++; deg[v]++; });
    const odd = labels.filter((i) => deg[i] % 2 === 1);
    const nonIsolated = labels.filter((i) => deg[i] > 0);
    const reach = new Set();
    if (nonIsolated.length) {
      const st = [nonIsolated[0]];
      reach.add(nonIsolated[0]);
      while (st.length) {
        const u = st.pop();
        adj[u].forEach(([v]) => { if (!reach.has(v)) { reach.add(v); st.push(v); } });
      }
    }
    const connected = nonIsolated.every((i) => reach.has(i));
    const valid = connected && (circuitMode ? odd.length === 0 : odd.length === 0 || odd.length === 2);
    const start = odd.length ? odd[0] : nonIsolated[0] || 0;
    const steps = [];
    const edgeStates = Array(edges.length).fill("idle");
    const nodeStates = Array(n).fill("idle");
    const push = (title, extra) => {
      const m = {};
      labels.forEach((i) => { m[i] = nodeStates[i]; });
      steps.push(graphStep(labels, edges, m, edgeStates.slice(), Object.assign({
        title,
        label: `degrees: ${deg.join(" ")}`,
        counters: [count("odd vertices", odd.length), count("edges", edges.length)],
        legend: LEG,
        happened: title,
        why: "An Euler trail uses every edge exactly once and changes parity at each step.",
      }, extra || {})));
    };
    push(`${edges.length} edges; odd-degree vertices: ${odd.length ? odd.join(", ") : "none"}`, { codeLine: 5 });
    if (!valid) {
      steps.push(graphStep(labels, edges, Object.fromEntries(labels.map((i) => [i, "bad"])), fill(edges.length, "bad"), {
        title: connected ? `Answer: ${circuitMode ? "no Euler circuit" : "no Euler path"}` : "Answer: the edges are disconnected",
        label: connected ? `${odd.length} odd vertices` : "some edges are in another component",
        counters: [count("odd vertices", odd.length), count("edges", edges.length)],
        legend: LEG,
        happened: connected ? (circuitMode ? "A circuit needs every degree even." : "A path needs zero or two odd-degree vertices; this graph has another number.") : "Edges in separate components cannot all be traversed in one walk.",
        why: "Euler's parity condition is necessary and sufficient only on a connected graph.",
        codeLine: 9,
      }));
      return steps;
    }
    push(`Start Hierholzer at vertex ${start}`, { codeLine: 12 });
    const used = Array(edges.length).fill(false);
    const stack = [start];
    const circuit = [];
    let guard = 0;
    while (stack.length && guard++ < 80) {
      const u = stack[stack.length - 1];
      const next = adj[u].find(([, i]) => !used[i]);
      if (next) {
        used[next[1]] = true;
        edgeStates[next[1]] = "good";
        nodeStates[u] = "read";
        nodeStates[next[0]] = "read";
        stack.push(next[0]);
        push(`Walk ${u} → ${next[0]}`, { codeLine: 15 });
      } else {
        nodeStates[u] = "done";
        circuit.push(stack.pop());
        push(`Backtrack from ${u}; append to trail`, { codeLine: 17 });
      }
    }
    let trail = circuit.slice().reverse();
    const prefix = circuitMode ? "circuit" : "path";
    steps.push({
      title: `Answer: Euler ${prefix} ${trail.join(" → ")}`,
      tracks: [chips(prefix, trail, "result"), chips("degrees", deg.map((d, i) => `${i}:${d}`), (i) => (deg[i] % 2 ? "bad" : "done"))],
      counters: [count("edges used", used.filter(Boolean).length, edges.length), count("vertices", new Set(trail).size)],
      legend: LEG,
      happened: `${trail.length - 1} edge traversals cover all ${edges.length} edges exactly once.`,
      why: "Hierholzer postpones a vertex until all its edges are used, so the reversed stack order is a valid Euler trail.",
      codeLine: 20,
    });
    steps.push(graphStep(labels, edges, Object.fromEntries(labels.map((i) => [i, "result"])), fill(edges.length, "good"), {
      title: `${circuitMode ? "Euler circuit" : "Euler path"} verified`,
      label: "every edge is used once",
      counters: [count("edges used", edges.length, edges.length), count("odd vertices", odd.length)],
      legend: LEG,
      happened: "The trail covers every edge without repetition.",
      why: circuitMode ? "All degrees are even, so the walk can end where it started." : "Exactly two odd vertices force the trail to start and end there.",
      codeLine: 22,
    }));
    return steps;
  };

  V.register({
    id: "eulerian-path",
    title: "Eulerian Path",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Find a walk that uses every edge exactly once.",
    input: { label: "Edges as u,v pairs", default: "0,1 1,2 2,0 2,3", parse: "string" },
    approaches: [
      {
        name: "Euler's Parity Check + Hierholzer",
        complexity: "O(V + E) time",
        idea: [
          "A connected graph has an Euler path exactly when it has 0 or 2 odd-degree vertices. If there are two, the path must start at one and end at the other.",
          "Hierholzer walks until stuck, records the dead-end vertex, and backtracks into earlier vertices with unused edges. Reversing the recorded vertices gives the trail.",
        ],
        problem: [
          "DFS that marks vertices visited can skip edges; Euler trails require tracking used edges, not just visited vertices.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint adj[4][4] = {{0,1,0,0},{1,0,1,0},{0,1,0,1},{0,0,1,0}};\nint used[4][4];\nint stack[16], top, trail[16], at;\n\nint main(void) {\n    int n = 4, odd = 0, start = 0;\n    for (int i = 0; i < n; i++) {\n        int d = 0;\n        for (int j = 0; j < n; j++) d += adj[i][j];\n        if (d % 2) { odd++; start = i; }\n    }\n    if (odd != 0 && odd != 2) { printf(\"no path\\\\n\"); return 0; }\n\n    stack[top++] = start;\n    while (top) {\n        int u = stack[top - 1], v = -1;\n        for (int j = 0; j < n; j++) if (adj[u][j] && !used[u][j]) { v = j; break; }\n        if (v >= 0) { used[u][v] = used[v][u] = 1; stack[top++] = v; }\n        else trail[at++] = stack[--top];\n    }\n    for (int i = at - 1; i >= 0; i--) printf(\"%d \", trail[i]);\n    printf(\"\\\\n\");\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nvector<int> eulerPath(int n, vector<vector<int>>& edges) {\n    vector<vector<pair<int,int>>> adj(n);\n    vector<int> deg(n, 0);\n    for (int i = 0; i < (int)edges.size(); i++) {\n        int u = edges[i][0], v = edges[i][1];\n        adj[u].push_back({v, i});\n        adj[v].push_back({u, i});\n        deg[u]++; deg[v]++;\n    }\n\n    int odd = 0, start = 0;\n    for (int i = 0; i < n; i++) if (deg[i] % 2) { odd++; start = i; }\n    if (odd != 0 && odd != 2) return {};\n\n    vector<bool> used(edges.size(), false);\n    vector<int> st{start}, trail;\n    while (!st.empty()) {\n        int u = st.back();\n        int pick = -1;\n        for (auto [v, id] : adj[u]) if (!used[id]) { pick = id; break; }\n        if (pick >= 0) {\n            used[pick] = true;\n            st.push_back(edges[pick][0] == u ? edges[pick][1] : edges[pick][0]);\n        } else {\n            trail.push_back(u);\n            st.pop_back();\n        }\n    }\n    reverse(trail.begin(), trail.end());\n    return trail;\n}\n\nint main() {\n    vector<vector<int>> e{{0,1},{1,2},{2,0},{2,3}};\n    for (int v : eulerPath(4, e)) cout << v << ' '; // 3 2 1 0 2\n    cout << '\\\\n';\n}`,
        },
        steps(raw) { return eulerSteps(raw, false); },
      },
    ],
  });

  V.register({
    id: "eulerian-circuit",
    title: "Eulerian Circuit",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Find a closed walk that uses every edge exactly once.",
    input: { label: "Edges as u,v pairs", default: "0,1 1,2 2,0", parse: "string" },
    approaches: [
      {
        name: "All Degrees Even + Hierholzer",
        complexity: "O(V + E) time",
        idea: [
          "An Euler circuit is an Euler path that returns to its start. Every time a walk enters a vertex it must leave it, so every degree must be even.",
          "If the graph is connected and all degrees are even, Hierholzer produces a circuit; the last vertex recorded is always the start.",
        ],
        problem: [
          "An Euler path with two odd endpoints exists even when no circuit does; the circuit check must reject any odd degree.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint adj[3][3] = {{0,1,0},{1,0,1},{0,1,0}};\nint used[3][3];\nint st[9], top, trail[9], at;\n\nint main(void) {\n    int n = 3;\n    for (int i = 0; i < n; i++) {\n        int d = 0;\n        for (int j = 0; j < n; j++) d += adj[i][j];\n        if (d % 2) { printf(\"no circuit\\\\n\"); return 0; }\n    }\n\n    st[top++] = 0;\n    while (top) {\n        int u = st[top - 1], v = -1;\n        for (int j = 0; j < n; j++) if (adj[u][j] && !used[u][j]) { v = j; break; }\n        if (v >= 0) { used[u][v] = used[v][u] = 1; st[top++] = v; }\n        else trail[at++] = st[--top];\n    }\n    for (int i = at - 1; i >= 0; i--) printf(\"%d \", trail[i]); /* 0 2 1 0 */\n    printf(\"\\\\n\");\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <algorithm>\nusing namespace std;\n\nvector<int> eulerCircuit(int n, vector<vector<int>>& edges) {\n    vector<vector<pair<int,int>>> adj(n);\n    vector<int> deg(n, 0);\n    for (int i = 0; i < (int)edges.size(); i++) {\n        int u = edges[i][0], v = edges[i][1];\n        adj[u].push_back({v, i});\n        adj[v].push_back({u, i});\n        deg[u]++; deg[v]++;\n    }\n    for (int d : deg) if (d % 2) return {};\n\n    vector<bool> used(edges.size(), false);\n    vector<int> st{0}, trail;\n    while (!st.empty()) {\n        int u = st.back();\n        int pick = -1;\n        for (auto [v, id] : adj[u]) if (!used[id]) { pick = id; break; }\n        if (pick >= 0) {\n            used[pick] = true;\n            st.push_back(edges[pick][0] == u ? edges[pick][1] : edges[pick][0]);\n        } else {\n            trail.push_back(u);\n            st.pop_back();\n        }\n    }\n    reverse(trail.begin(), trail.end());\n    return trail;\n}\n\nint main() {\n    vector<vector<int>> e{{0,1},{1,2},{2,0}};\n    for (int v : eulerCircuit(3, e)) cout << v << ' '; // 0 2 1 0\n    cout << '\\\\n';\n}`,
        },
        steps(raw) { return eulerSteps(raw, true); },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "course-prerequisite-queries",
    title: "Course Prerequisite Queries",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Answer whether one course is a direct or indirect prerequisite of another.",
    input: { label: "courses | prerequisite pairs | queries", default: "4 | 1,0 2,1 3,2 | 3,0 0,3 2,0", parse: "string" },
    approaches: [
      {
        name: "Reachability From the Prerequisite",
        complexity: "O(Q × (V + E)) time",
        idea: [
          "Direct the graph from a prerequisite to the course that needs it. Then a is a prerequisite of b exactly when b is reachable from a.",
          "For each query, run a small BFS from a and stop if b appears. Parent links show the chain of courses that proves the answer.",
        ],
        problem: [
          "Checking only direct edges misses transitive prerequisites such as 3 needing 0 through 1 and 2.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint adj[4][4] = {{0,1,0,0},{0,0,1,0},{0,0,0,1},{0,0,0,0}};\nint seen[4];\n\nint reaches(int u, int target) {\n    if (u == target) return 1;\n    seen[u] = 1;\n    for (int v = 0; v < 4; v++)\n        if (adj[u][v] && !seen[v] && reaches(v, target)) return 1;\n    return 0;\n}\n\nint main(void) {\n    printf(\"%d\\\\n\", reaches(0, 3)); /* 1 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <queue>\nusing namespace std;\n\nbool reaches(vector<vector<int>>& adj, int from, int target) {\n    vector<bool> seen(adj.size(), false);\n    queue<int> q;\n    q.push(from);\n    seen[from] = true;\n\n    while (!q.empty()) {\n        int u = q.front(); q.pop();\n        if (u == target) return true;\n        for (int v : adj[u]) if (!seen[v]) { seen[v] = true; q.push(v); }\n    }\n    return false;\n}\n\nint main() {\n    int n = 4;\n    vector<vector<int>> adj(n);\n    for (auto& e : vector<vector<int>>{{1,0},{2,1},{3,2}}) adj[e[1]].push_back(e[0]);\n    cout << reaches(adj, 0, 3) << ' ' << reaches(adj, 3, 0) << '\\\\n'; // 1 0\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const n = Math.min(9, Math.max(0, parseInt(parts[0], 10) || 0));
          const prereqs = pairsOf(parts[1] || "").filter(([c, p]) => c >= 0 && p >= 0 && c < n && p < n && c !== p);
          const queries = pairsOf(parts[2] || "").filter(([a, b]) => a >= 0 && b >= 0 && a < n && b < n);
          if (!n || !queries.length) return [{
            title: "Give courses and queries",
            tracks: [chips("queries", ["—"], "idle")],
            counters: [count("answered", 0)],
            legend: LEG,
            happened: "There are no queries to answer.",
            why: "Each query asks whether one course can reach another.",
          }];
          const adj = Array.from({ length: n }, () => []);
          prereqs.forEach(([c, p]) => adj[p].push(c));
          const labels = Array.from({ length: n }, (_, i) => i);
          const steps = [];
          steps.push({
            title: `${n} courses and ${queries.length} queries`,
            tracks: [
              chips("edges", prereqs.map(([c, p]) => `${p}→${c}`), "idle"),
              chips("queries", queries.map(([a, b]) => `${a}→${b}?`), "compare"),
            ],
            counters: [count("answered", 0, queries.length), count("edges", prereqs.length)],
            legend: LEG,
            happened: "An edge p → c means p is a direct prerequisite of c.",
            why: "A course is a prerequisite if a directed path reaches the other course.",
            codeLine: 3,
          });
          const answers = [];
          queries.forEach(([a, b]) => {
            const parent = new Map([[a, null]]);
            const queue = [a];
            let found = false;
            while (queue.length && !found) {
              const u = queue.shift();
              if (u === b) { found = true; break; }
              adj[u].forEach((v) => { if (!parent.has(v)) { parent.set(v, u); queue.push(v); } });
            }
            answers.push(found);
            let path = null;
            if (found) {
              path = [b];
              let cur = b;
              while (parent.get(cur) != null) { cur = parent.get(cur); path.unshift(cur); }
            }
            steps.push({
              title: found ? `${a} is a prerequisite of ${b}` : `${a} is not a prerequisite of ${b}`,
              tracks: [
                chips("query", [`${a}→${b}?`], found ? "good" : "bad"),
                chips("chain", path || [...parent.keys()], found ? "result" : "dim"),
                chips("answers", answers.map((x) => (x ? "yes" : "no")), (i) => (i === answers.length - 1 ? "read" : "done")),
              ],
              counters: [count("answered", answers.length, queries.length), count("yes", answers.filter(Boolean).length)],
              legend: LEG,
              happened: found ? `${path.join(" → ")} proves ${a} is needed before ${b}.` : `BFS from ${a} never reached ${b}.`,
              why: "Reachability in the prerequisite DAG is exactly the transitive prerequisite relation.",
              codeLine: 10,
            });
          });
          steps.push({
            title: "Answer: all queries evaluated",
            tracks: [chips("results", queries.map(([a, b], i) => `${a}→${b}: ${answers[i] ? "yes" : "no"}`), (i) => (answers[i] ? "good" : "bad"))],
            counters: [count("yes", answers.filter(Boolean).length), count("no", answers.filter((x) => !x).length)],
            legend: LEG,
            happened: answers.map((x, i) => `${queries[i][0]}→${queries[i][1]} ${x ? "yes" : "no"}`).join("; "),
            why: "Each query is an independent reachability test.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "kth-ancestor-of-a-tree-node",
    title: "Kth Ancestor of a Tree Node",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Answer ancestor queries by jump pointers in a binary-lifting table.",
    input: { label: "nodes | parent list | node,k queries", default: "7 | -1,0,0,1,1,2,2 | 3,1 5,2 6,3", parse: "string" },
    approaches: [
      {
        name: "Binary Lifting Table",
        complexity: "O(n log n) build, O(log k) per query",
        idea: [
          "up[k][v] is the 2^k-th ancestor of v. Row 0 is the direct parent.",
          "Higher rows reuse lower ones: up[k][v] = up[k−1][ up[k−1][v] ]. To answer a k-ancestor query, consume the set bits of k from low to high and jump accordingly.",
        ],
        problem: [
          "Walking one parent at a time is O(k) per query and can be O(n) when k is large; binary lifting reduces it to O(log k).",
        ],
        code: {
          c: `#include <stdio.h>\n\nint up[3][7];\n\nint main(void) {\n    int n = 7, K = 3;\n    int parent[7] = {-1,0,0,1,1,2,2};\n    for (int v = 0; v < n; v++) up[0][v] = parent[v];\n\n    for (int k = 1; k < K; k++)\n        for (int v = 0; v < n; v++)\n            up[k][v] = up[k-1][v] < 0 ? -1 : up[k-1][up[k-1][v]];\n\n    int q[3][2] = {{3,1},{5,2},{6,3}};\n    for (int i = 0; i < 3; i++) {\n        int v = q[i][0], k = q[i][1];\n        for (int b = 0; b < K; b++)\n            if (k & (1 << b)) v = up[b][v] < 0 ? -1 : up[b][v];\n        printf(\"%d \", v); /* 1 0 -1 */\n    }\n    printf(\"\\\\n\");\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nclass TreeAncestor {\n    vector<vector<int>> up;\npublic:\n    TreeAncestor(int n, vector<int>& parent) {\n        int K = 1;\n        while ((1 << K) <= n) K++;\n        up.assign(K, vector<int>(n, -1));\n        for (int v = 0; v < n; v++) up[0][v] = parent[v];\n\n        for (int k = 1; k < K; k++)\n            for (int v = 0; v < n; v++)\n                if (up[k-1][v] >= 0) up[k][v] = up[k-1][up[k-1][v]];\n    }\n\n    int getKthAncestor(int node, int k) {\n        for (int b = 0; b < (int)up.size(); b++)\n            if (k & (1 << b)) {\n                node = up[b][node];\n                if (node < 0) return -1;\n            }\n        return node;\n    }\n};\n\nint main() {\n    vector<int> p{-1,0,0,1,1,2,2};\n    TreeAncestor t(7, p);\n    cout << t.getKthAncestor(3,1) << ' ' << t.getKthAncestor(5,2) << ' ' << t.getKthAncestor(6,3) << '\\\\n'; // 1 0 -1\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const parents = String(parts[1] || "").split(/[\s,]+/).filter(Boolean).map(Number);
          const n = Math.min(10, parents.length);
          const queries = pairsOf(parts[2] || "").filter(([v, k]) => v >= 0 && v < n && k >= 0).slice(0, 8);
          if (!n || !queries.length) return [{
            title: "Give parents and ancestor queries",
            tracks: [chips("parents", parents.length ? parents : ["—"], "idle")],
            counters: [count("nodes", n)],
            legend: LEG,
            happened: "There is no tree or no query.",
            why: "Binary lifting needs a parent for every node and at least one query.",
          }];
          const maxK = Math.max(1, ...queries.map(([, k]) => k));
          const K = Math.max(1, Math.floor(Math.log2(maxK + 1)) + 1);
          const up = Array.from({ length: K }, () => Array(n).fill(-1));
          for (let v = 0; v < n; v++) up[0][v] = Number.isFinite(parents[v]) && parents[v] >= 0 && parents[v] < n ? parents[v] : -1;
          const steps = [];
          const table = (curRow, curCol, pathCells) => grid(K, n, (r, c) => {
            const val = up[r][c];
            const onPath = pathCells && pathCells.some(([rr, cc]) => rr === r && cc === c);
            const state = onPath ? "result" : curRow === r && curCol === c ? "read" : val >= 0 ? "done" : "dim";
            return { v: val >= 0 ? String(val) : "·", state };
          });
          steps.push({
            title: `Build ${K} rows for ${n} nodes`,
            kind: "grid", rows: K, cols: n, rowHeads: Array.from({ length: K }, (_, k) => `2^${k}`), colHeads: Array.from({ length: n }, (_, i) => String(i)),
            cells: table(-1, -1),
            counters: [count("nodes", n), count("rows", K)],
            legend: LEG,
            happened: "Row 0 already holds each direct parent; higher rows are still empty.",
            why: "The 2^k-th ancestor can be composed from two 2^(k−1) jumps.",
            codeLine: 4,
          });
          for (let k = 1; k < K; k++) {
            for (let v = 0; v < n; v++) {
              const mid = up[k - 1][v];
              up[k][v] = mid >= 0 ? up[k - 1][mid] : -1;
            }
            steps.push({
              title: `Fill row ${k}: 2^${k}-th ancestors`,
              kind: "grid", rows: K, cols: n, rowHeads: Array.from({ length: K }, (_, x) => `2^${x}`), colHeads: Array.from({ length: n }, (_, i) => String(i)),
              cells: table(k, -1),
              counters: [count("rows filled", k + 1, K), count("nodes", n)],
              legend: LEG,
              happened: `Each row-${k} entry is the row-${k - 1} ancestor of the row-${k - 1} ancestor.`,
              why: "Doubling the jump length reuses the previous row, so the table costs O(n log n).",
              codeLine: 8,
            });
          }
          queries.forEach(([v, k]) => {
            let cur = v;
            const traced = [];
            for (let b = 0; b < K && cur >= 0; b++) {
              if (k & (1 << b)) {
                traced.push([b, cur]);
                cur = up[b][cur];
              }
            }
            steps.push({
              title: `Ancestor of ${v} at distance ${k}: ${cur < 0 ? "none" : cur}`,
              tracks: [
                chips("query", [`node ${v}, k=${k}`], "read"),
                chips("jumps", traced.map(([b, node]) => `2^${b} from ${node}`), "active"),
                chips("answer", [cur < 0 ? "-1" : String(cur)], cur < 0 ? "bad" : "result"),
              ],
              counters: [count("jumps", traced.length), count("answer", cur < 0 ? -1 : cur)],
              legend: LEG,
              happened: cur < 0 ? `A jump left the tree above the root.` : `The consumed bits of ${k} walk up to node ${cur}.`,
              why: "Binary lifting turns k into its set bits and applies one precomputed jump per bit.",
              codeLine: 17,
            });
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-flow",
    title: "Maximum Flow",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Push as much flow as possible from a source to a sink through capacity-limited pipes.",
    input: { label: "source,sink | edges u,v,capacity", default: "0,5 | 0,1,16 0,2,13 1,2,10 2,1,4 1,3,12 3,2,9 2,4,14 4,3,7 3,5,20 4,5,4", parse: "string" },
    approaches: [
      {
        name: "Edmonds-Karp Augmenting Paths",
        complexity: "O(V E²) time",
        idea: [
          "Keep residual capacity on every directed edge: how much more can be pushed before the pipe is full, including the ability to cancel previous flow.",
          "BFS finds an augmenting path in the residual graph. Push the smallest residual capacity along it, add that amount to the total, and repeat until no path exists.",
        ],
        problem: [
          "Choosing arbitrary augmenting paths can be slow or cycle; shortest augmenting paths (BFS) guarantee termination in polynomial time.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint cap[6][6];\nint flow[6][6];\nint parent[6], seen[6], q[36];\n\nint bfs(int s, int t) {\n    memset(seen, 0, sizeof(seen));\n    int head = 0, tail = 0;\n    q[tail++] = s;\n    seen[s] = 1;\n\n    while (head < tail) {\n        int u = q[head++];\n        for (int v = 0; v < 6; v++)\n            if (!seen[v] && cap[u][v] - flow[u][v] > 0) {\n                parent[v] = u;\n                seen[v] = 1;\n                q[tail++] = v;\n            }\n    }\n    return seen[t];\n}\n\nint main(void) {\n    int edges[][3] = {{0,1,16},{0,2,13},{1,2,10},{2,1,4},{1,3,12},{3,2,9},{2,4,14},{4,3,7},{3,5,20},{4,5,4}};\n    for (int i = 0; i < 10; i++) cap[edges[i][0]][edges[i][1]] = edges[i][2];\n\n    int total = 0;\n    while (bfs(0, 5)) {\n        int add = 1 << 30;\n        for (int v = 5; v != 0; v = parent[v]) {\n            int u = parent[v];\n            int r = cap[u][v] - flow[u][v];\n            if (r < add) add = r;\n        }\n        for (int v = 5; v != 0; v = parent[v]) {\n            int u = parent[v];\n            flow[u][v] += add;\n            flow[v][u] -= add;\n        }\n        total += add;\n    }\n    printf(\"%d\\\\n\", total); /* 23 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <queue>\nusing namespace std;\n\nint maxFlow(vector<vector<int>>& cap, int s, int t) {\n    int n = cap.size(), total = 0;\n    vector<vector<int>> flow(n, vector<int>(n, 0));\n\n    while (true) {\n        vector<int> parent(n, -1);\n        queue<int> q;\n        q.push(s);\n        parent[s] = s;\n\n        while (!q.empty()) {\n            int u = q.front(); q.pop();\n            for (int v = 0; v < n; v++)\n                if (parent[v] == -1 && cap[u][v] - flow[u][v] > 0) {\n                    parent[v] = u;\n                    q.push(v);\n                }\n        }\n        if (parent[t] == -1) break;\n\n        int add = 1e9;\n        for (int v = t; v != s; v = parent[v]) add = min(add, cap[parent[v]][v] - flow[parent[v]][v]);\n        for (int v = t; v != s; v = parent[v]) {\n            int u = parent[v];\n            flow[u][v] += add;\n            flow[v][u] -= add;\n        }\n        total += add;\n    }\n    return total;\n}\n\nint main() {\n    vector<vector<int>> cap(6, vector<int>(6, 0));\n    vector<vector<int>> edges{{0,1,16},{0,2,13},{1,2,10},{2,1,4},{1,3,12},{3,2,9},{2,4,14},{4,3,7},{3,5,20},{4,5,4}};\n    for (auto& e : edges) cap[e[0]][e[1]] = e[2];\n    cout << maxFlow(cap, 0, 5) << '\\\\n'; // 23\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const st = (parts[0] || "").split(/[\s,]+/).map(Number);
          const s = st[0], t = st[1];
          const edges = triplesOf(parts[1] || "").filter(([u, v, c]) => u >= 0 && v >= 0 && c > 0 && u !== v).slice(0, 20);
          const maxNode = Math.max(s, t, ...edges.flatMap(([u, v]) => [u, v]));
          if (!Number.isFinite(s) || !Number.isFinite(t) || !edges.length) return [{
            title: "Give source, sink and capacities",
            tracks: [chips("edges", ["—"], "idle")],
            counters: [count("flow", 0)],
            legend: LEG,
            happened: "There are no pipes to carry flow.",
            why: "Maximum flow needs a source, a sink and capacity-limited edges.",
          }];
          const labels = Array.from({ length: maxNode + 1 }, (_, i) => i);
          const cap = Array.from({ length: labels.length }, () => Array(labels.length).fill(0));
          edges.forEach(([u, v, c]) => { cap[u][v] += c; });
          const flow = Array.from({ length: labels.length }, () => Array(labels.length).fill(0));
          const steps = [];
          let total = 0;
          const edgeStates = () => edges.map(([u, v]) => {
            if (flow[u][v] > 0 && flow[u][v] === cap[u][v]) return "bad";
            if (flow[u][v] > 0) return "good";
            return "idle";
          });
          const status = () => edges.map(([u, v]) => `${u}→${v}: ${flow[u][v]}/${cap[u][v]}`);
          steps.push(graphStep(labels, edges.map(([u, v]) => [u, v]), Object.fromEntries(labels.map((i) => [i, i === s ? "good" : i === t ? "bad" : "idle"])), edgeStates(), {
            title: `Source ${s}, sink ${t}; initial residual equals capacity`,
            label: "flow = 0 on every pipe",
            counters: [count("flow", 0), count("pipes", edges.length)],
            legend: LEG,
            happened: "No augmenting path has been used yet.",
            why: "Residual capacity is capacity minus current flow; the first BFS works on original capacities.",
            codeLine: 5,
          }));
          let guard = 0;
          while (guard++ < 12) {
            const parent = Array(labels.length).fill(-1);
            const queue = [s];
            parent[s] = s;
            while (queue.length) {
              const u = queue.shift();
              for (let v = 0; v < labels.length; v++) {
                if (parent[v] === -1 && cap[u][v] - flow[u][v] > 0) { parent[v] = u; queue.push(v); }
              }
            }
            if (parent[t] === -1) break;
            const path = [];
            let bottleneck = Infinity;
            for (let v = t; v !== s; v = parent[v]) {
              const u = parent[v];
              path.unshift([u, v]);
              bottleneck = Math.min(bottleneck, cap[u][v] - flow[u][v]);
            }
            path.forEach(([u, v]) => { flow[u][v] += bottleneck; flow[v][u] -= bottleneck; });
            total += bottleneck;
            const pathEdges = edges.map(([u, v]) => path.some(([a, b]) => a === u && b === v));
            steps.push(graphStep(labels, edges.map(([u, v]) => [u, v]), Object.fromEntries(labels.map((i) => [i, path.some(([a, b]) => a === i || b === i) ? "read" : i === s ? "good" : i === t ? "bad" : "idle"])), edges.map((e, i) => (pathEdges[i] ? "result" : edgeStates()[i])), {
              title: `Augment by ${bottleneck} along ${path.map(([u, v]) => `${u}→${v}`).join(" ")}`,
              label: status().join("   "),
              counters: [count("flow", total), count("bottleneck", bottleneck), count("augmentations", guard)],
              legend: LEG,
              happened: `The path is only as strong as its smallest residual pipe, so ${bottleneck} units move.`,
              why: "Pushing the bottleneck keeps all capacities valid; reversing the flow lets later paths undo bad choices.",
              codeLine: 16,
            }));
          }
          const reachable = new Set([s]);
          const st2 = [s];
          while (st2.length) {
            const u = st2.pop();
            for (let v = 0; v < labels.length; v++) if (!reachable.has(v) && cap[u][v] - flow[u][v] > 0) { reachable.add(v); st2.push(v); }
          }
          steps.push(graphStep(labels, edges.map(([u, v]) => [u, v]), Object.fromEntries(labels.map((i) => [i, reachable.has(i) ? "good" : "bad"])), edgeStates(), {
            title: `Answer: maximum flow is ${total}`,
            label: `source side: {${[...reachable].join(", ")}}`,
            counters: [count("flow", total), count("augmentations", guard - 1)],
            legend: LEG,
            happened: `No residual path from ${s} to ${t} remains; the source side is the minimum cut.`,
            why: "Max-flow min-cut says the flow value equals the capacity of this cut, so no larger flow is possible.",
            codeLine: 24,
          }));
          return steps;
        },
      },
    ],
  });
})();
