/* ============================================================
   DSA Visuals — Tries II
   Bit tries for maximum XOR, a dictionary trie for buildable
   words, and a reversed trie for suffix queries on a stream.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => `[${a.join(", ")}]`;
  const words = (text) => String(text || "").split(/[\s,;|]+/).filter(Boolean);

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-xor-of-two-numbers",
    title: "Maximum XOR of Two Numbers",
    category: "Tries",
    difficulty: "Advanced",
    description: "Find the pair of array values whose XOR is largest, using a bit trie.",
    input: { label: "numbers", default: "3, 10, 5, 25, 2, 8", parse: "ints" },
    approaches: [
      {
        name: "Greedy Opposite Bits in a Binary Trie",
        complexity: "O(n × bits) time",
        idea: [
          "Insert every number into a trie whose edges are bits from most significant to least significant.",
          "For each number, walk its bits and prefer the opposite child whenever it exists: that bit makes the XOR 1. If only the same bit exists, follow it and settle for 0.",
        ],
        problem: [
          "Comparing every pair is O(n²); the trie lets one lookup reuse the decisions of all earlier numbers.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int kid[2]; };
struct node trie[4096];
int used = 1;

void insert(int v, int bits) {
    int at = 0;
    for (int b = bits - 1; b >= 0; b--) {
        int bit = (v >> b) & 1;
        if (!trie[at].kid[bit]) trie[at].kid[bit] = used++;
        at = trie[at].kid[bit];
    }
}

int best_xor(int v, int bits) {
    int at = 0, out = 0;
    for (int b = bits - 1; b >= 0; b--) {
        int bit = (v >> b) & 1;
        int want = bit ^ 1;
        if (trie[at].kid[want]) {
            out |= 1 << b;                  /* this bit differs */
            at = trie[at].kid[want];
        } else {
            at = trie[at].kid[bit];
        }
    }
    return out;
}

int main(void) {
    int a[] = {3, 10, 5, 25, 2, 8}, n = 6, best = 0, bits = 6;
    for (int i = 0; i < n; i++) insert(a[i], bits);
    for (int i = 0; i < n; i++) {
        int x = best_xor(a[i], bits);
        if (x > best) best = x;
    }
    printf("%d\\n", best); /* 28: 5 xor 25 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

struct Node { Node* kid[2] = {nullptr, nullptr}; };

void insert(Node* root, int v, int bits) {
    Node* at = root;
    for (int b = bits - 1; b >= 0; b--) {
        int bit = (v >> b) & 1;
        if (!at->kid[bit]) at->kid[bit] = new Node();
        at = at->kid[bit];
    }
}

int bestXor(Node* root, int v, int bits) {
    Node* at = root;
    int out = 0;
    for (int b = bits - 1; b >= 0; b--) {
        int bit = (v >> b) & 1;
        int want = bit ^ 1;
        if (at->kid[want]) { out |= 1 << b; at = at->kid[want]; }
        else at = at->kid[bit];
    }
    return out;
}

int main() {
    vector<int> a{3,10,5,25,2,8};
    Node root;
    for (int v : a) insert(&root, v, 6);
    int best = 0;
    for (int v : a) best = max(best, bestXor(&root, v, 6));
    cout << best << '\\n'; // 28
}`,
        },
        steps(values) {
          const a = values.slice(0, 20);
          const bits = 6;
          if (!a.length) {
            return [{
              title: "Give some numbers",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("pairs", 0)],
              legend: LEG,
              happened: "A pair needs at least two values.",
              why: "XOR is computed between two distinct array positions.",
            }];
          }
          const toBits = (v) => (v >>> 0).toString(2).padStart(bits, "0").slice(-bits);
          const root = { kid: [null, null] };
          const insert = (v) => {
            let at = root;
            for (const c of toBits(v)) {
              const b = Number(c);
              if (!at.kid[b]) at.kid[b] = { kid: [null, null] };
              at = at.kid[b];
            }
          };
          a.forEach(insert);
          const bestFor = (v) => {
            let at = root, out = 0, path = "";
            for (const c of toBits(v)) {
              const b = Number(c);
              const want = b ^ 1;
              if (at.kid[want]) { out |= 1 << (bits - 1 - path.length); at = at.kid[want]; path += "1"; }
              else { at = at.kid[b]; path += "0"; }
            }
            return { out, path };
          };
          const steps = [];
          steps.push({
            title: `Insert ${a.length} numbers into a ${bits}-bit trie`,
            tracks: [chips("numbers", a, "idle"), chips("bits", Array.from(toBits(a[0])), "dim")],
            counters: [count("numbers", a.length), count("bits", bits)],
            legend: LEG,
            happened: "Every number contributes one root-to-leaf path of bits.",
            why: "The most significant bit decides the largest part of the XOR value.",
            codeLine: 5,
          });
          let best = 0, bestPair = null;
          a.forEach((v, idx) => {
            const r = bestFor(v);
            if (r.out > best) { best = r.out; bestPair = [v, a.find((x, j) => j !== idx && (x ^ v) === r.out)]; }
            steps.push({
              title: `${v} (${toBits(v)}): greedy path gives XOR ${r.out}`,
              tracks: [
                chips("numbers", a, (j) => (j === idx ? "read" : "dim")),
                chips("its bits", Array.from(toBits(v)), "compare"),
                chips("chosen XOR bits", Array.from(r.path), (j) => (r.path[j] === "1" ? "result" : "dim")),
              ],
              counters: [count("xor", r.out), count("best", best)],
              legend: LEG,
              happened: `At each bit the opposite branch ${r.path.includes("1") ? "was available where it mattered" : "was not available"}.`,
              why: "Taking the opposite bit adds that power of two to the XOR and is always at least as good.",
              codeLine: 14,
            });
          });
          steps.push({
            title: `Answer: maximum XOR ${best}${bestPair && bestPair[1] != null ? ` from ${bestPair[0]} and ${bestPair[1]}` : ""}`,
            tracks: [chips("numbers", a, "idle"), chips("answer", [best], "result")],
            counters: [count("answer", best), count("pairs checked", a.length)],
            legend: LEG,
            happened: "Every number was matched against the trie once.",
            why: "The greedy choice at the highest differing bit dominates all lower bits combined.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "longest-word-in-dictionary",
    title: "Longest Word in Dictionary",
    category: "Tries",
    difficulty: "Advanced",
    description: "Find the longest word that can be built one character at a time from other dictionary words.",
    input: { label: "dictionary words", default: "a, banana, app, appl, apple, apply, pple", parse: "tokens" },
    approaches: [
      {
        name: "Every Prefix Must Be a Word",
        complexity: "O(total characters) time",
        idea: [
          "Store all words in a trie. A word is buildable only if every node on its path is the end of some dictionary word.",
          "Sort candidates by length, then by dictionary order, and keep the best buildable one.",
        ],
        problem: [
          "Taking the longest word without checking the prefixes fails on words whose middle prefix is missing.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct node { int kid[26]; int end; };
struct node trie[4096];
int used = 1;

void insert(const char *w) {
    int at = 0;
    for (const char *p = w; *p; p++) {
        int c = *p - 'a';
        if (!trie[at].kid[c]) trie[at].kid[c] = used++;
        at = trie[at].kid[c];
    }
    trie[at].end = 1;
}

int buildable(const char *w) {
    int at = 0;
    for (const char *p = w; *p; p++) {
        at = trie[at].kid[*p - 'a'];
        if (at == 0 || !trie[at].end) return 0;   /* prefix must be a word */
    }
    return 1;
}

int main(void) {
    const char *dict[] = {"a", "banana", "app", "appl", "apple", "apply", "pple"};
    int n = 7;
    for (int i = 0; i < n; i++) insert(dict[i]);

    const char *best = "";
    for (int i = 0; i < n; i++) {
        int len = strlen(dict[i]), blen = strlen(best);
        if (!buildable(dict[i])) continue;
        if (len > blen || (len == blen && strcmp(dict[i], best) < 0)) best = dict[i];
    }
    printf("%s\\n", best); /* apple */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

struct Node { Node* kid[26] = {}; bool end = false; };

void insert(Node* root, const string& w) {
    Node* at = root;
    for (char ch : w) {
        int c = ch - 'a';
        if (!at->kid[c]) at->kid[c] = new Node();
        at = at->kid[c];
    }
    at->end = true;
}

bool buildable(Node* root, const string& w) {
    Node* at = root;
    for (char ch : w) {
        at = at->kid[ch - 'a'];
        if (!at || !at->end) return false;
    }
    return true;
}

int main() {
    vector<string> dict{"a","banana","app","appl","apple","apply","pple"};
    Node root;
    for (auto& w : dict) insert(&root, w);

    sort(dict.begin(), dict.end(), [](const string& a, const string& b) {
        return a.size() != b.size() ? a.size() < b.size() : a < b;
    });
    string best;
    for (auto& w : dict)
        if (buildable(&root, w)) best = w;
    cout << best << '\\n'; // apple
}`,
        },
        steps(tokens) {
          const dict = (tokens || []).map(String).filter(Boolean);
          if (!dict.length) {
            return [{
              title: "Give dictionary words",
              tracks: [chips("dictionary", ["—"], "idle")],
              counters: [count("words", 0)],
              legend: LEG,
              happened: "There is nothing to build.",
              why: "A buildable word needs at least one letter.",
            }];
          }
          const end = new Set();
          const prefix = new Set();
          dict.forEach((w) => {
            for (let i = 1; i <= w.length; i++) prefix.add(w.slice(0, i));
            end.add(w);
          });
          const sorted = dict.slice().sort((a, b) => a.length - b.length || (a < b ? -1 : a > b ? 1 : 0));
          const steps = [];
          const good = [];
          steps.push({
            title: `Sort ${dict.length} words by length, then alphabetically`,
            tracks: [chips("dictionary", dict, "idle"), chips("sorted order", sorted, "dim")],
            counters: [count("words", dict.length), count("prefixes", prefix.size)],
            legend: LEG,
            happened: "The smallest valid longest word wins ties.",
            why: "Every prefix of a buildable word must itself be in the dictionary.",
            codeLine: 5,
          });
          sorted.forEach((w) => {
            const missing = [];
            for (let i = 1; i <= w.length; i++) {
              const p = w.slice(0, i);
              if (!end.has(p)) missing.push(p);
            }
            const ok = missing.length === 0;
            if (ok) good.push(w);
            steps.push({
              title: ok ? `"${w}" is buildable from its prefixes` : `"${w}" breaks at "${missing[0]}"`,
              tracks: [
                chips("word", Array.from(w), (i) => (missing.some((m) => m.length === i + 1) ? "bad" : end.has(w.slice(0, i + 1)) ? "done" : "dim")),
                chips("missing prefixes", missing.length ? missing : ["none"], missing.length ? "bad" : "good"),
                chips("valid so far", good.length ? good : ["none"], (i) => (i === good.length - 1 ? "result" : "dim")),
              ],
              counters: [count("word length", w.length), count("buildable", good.length)],
              legend: LEG,
              happened: ok ? `All ${w.length} prefixes are dictionary words, so ${w} can grow one letter at a time.` : `"${missing[0]}" is not a word, so the chain breaks.`,
              why: "A longer word can only be built if every shorter step already exists.",
              codeLine: 14,
            });
          });
          const best = (() => {
            let b = "";
            good.forEach((w) => {
              if (!b || w.length > b.length || (w.length === b.length && w < b)) b = w;
            });
            return b;
          })();
          steps.push({
            title: best ? `Answer: "${best}"` : "Answer: no buildable word",
            tracks: [chips("buildable", good.length ? good : ["none"], "result"), chips("answer", [best || "—"], "result")],
            counters: [count("answer length", best.length), count("candidates", good.length)],
            legend: LEG,
            happened: best ? "The last valid word in sorted order is the longest, with the smallest tie-break." : "No word had all of its prefixes present.",
            why: "Sorting by length makes the final valid word the winner directly.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "stream-of-characters",
    title: "Stream of Characters",
    category: "Tries",
    difficulty: "Advanced",
    description: "After each new letter, decide whether the stream ends with any dictionary word.",    input: { label: "stream | dictionary words", default: "abcd | a, ab, cd, bcd, x", parse: "string" },
    approaches: [
      {
        name: "Reversed Trie and Active Suffixes",
        complexity: "O(stream length × word length) time",
        idea: [
          "Store every dictionary word in a trie and keep a pointer for each suffix start position in the stream.",
          "After a new character, advance every pointer by one edge and add a fresh pointer at the root. A pointer that falls out of the trie is dropped; a pointer on a word end means a dictionary word now ends at this character.",
        ],
        problem: [
          "Restarting the search from scratch for every suffix costs O(n²) over a long stream; carrying the active pointers keeps each step proportional to the longest word.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

struct node { int kid[26]; int end; };
struct node trie[4096];
int used = 1, active[64], active_n = 0;

void insert_word(const char *w) {
    int at = 0;
    for (const char *p = w; *p; p++) {
        int c = *p - 'a';
        if (!trie[at].kid[c]) trie[at].kid[c] = used++;
        at = trie[at].kid[c];
    }
    trie[at].end = 1;
}

int query(char ch) {
    int next[64], next_n = 0, found = 0;
    for (int i = 0; i < active_n; i++) {
        int to = trie[active[i]].kid[ch - 'a'];
        if (to) {
            next[next_n++] = to;
            if (trie[to].end) found = 1;
        }
    }
    int from_root = trie[0].kid[ch - 'a'];
    if (from_root) {
        next[next_n++] = from_root;
        if (trie[from_root].end) found = 1;
    }
    for (int i = 0; i < next_n; i++) active[i] = next[i];
    active_n = next_n;
    return found;
}

int main(void) {
    const char *dict[] = {"a", "ab", "cd", "bcd", "x"};
    for (int i = 0; i < 5; i++) insert_word(dict[i]);

    const char *s = "abcd";
    for (int i = 0; s[i]; i++) printf("%d ", query(s[i])); /* 1 1 0 1 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Node { Node* kid[26] = {}; bool end = false; };

void insertWord(Node* root, const string& w) {
    Node* at = root;
    for (char ch : w) {
        int c = ch - 'a';
        if (!at->kid[c]) at->kid[c] = new Node();
        at = at->kid[c];
    }
    at->end = true;
}

int main() {
    vector<string> dict{"a","ab","cd","bcd","x"};
    Node root;
    for (auto& w : dict) insertWord(&root, w);

    vector<Node*> active;
    string s = "abcd";
    for (char ch : s) {
        vector<Node*> next;
        bool found = false;
        for (Node* at : active) {
            Node* to = at->kid[ch - 'a'];
            if (to) { next.push_back(to); found = found || to->end; }
        }
        Node* fromRoot = root.kid[ch - 'a'];
        if (fromRoot) { next.push_back(fromRoot); found = found || fromRoot->end; }
        active = next;
        cout << found << ' '; // 1 1 0 1
    }
    cout << '\\n';
}`,
        },
        steps(text) {
          const segs = String(text || "").split("|");
          const stream = Array.from(String(segs[0] || "").replace(/[^a-z]/gi, "").toLowerCase());
          const dict = String(segs[1] || "").split(/[\s,;]+/).filter(Boolean).map((w) => w.toLowerCase());
          if (!stream.length || !dict.length) {
            return [{
              title: "Give a stream and dictionary words",
              tracks: [chips("stream", stream.length ? stream : ["—"], "idle"), chips("dictionary", dict.length ? dict : ["—"], "idle")],
              counters: [count("queries", 0)],
              legend: LEG,
              happened: "A stream query needs at least one letter and one word.",
              why: "The answer after each character is whether any suffix is a word.",
            }];
          }
          const prefix = (p) => dict.some((w) => w.startsWith(p));
          const active = new Set();
          const steps = [];
          const answers = [];
          steps.push({
            title: `Build a trie from ${dict.length} dictionary words`,
            tracks: [chips("dictionary", dict, "idle"), chips("prefixes", dict, "dim")],
            counters: [count("words", dict.length), count("stream", stream.length)],
            legend: LEG,
            happened: "Every suffix start is tracked as one trie path.",
            why: "A word ending at the current character is exactly a trie path that ends here.",
            codeLine: 5,
          });
          stream.forEach((ch, idx) => {
            const next = new Set();
            let found = false;
            const candidates = ["", ...active].map((p) => p + ch);
            candidates.forEach((cand) => {
              if (!prefix(cand)) return;
              next.add(cand);
              if (dict.includes(cand)) found = true;
            });
            active.clear();
            next.forEach((p) => active.add(p));
            answers.push(found);
            steps.push({
              title: `Read '${ch}' → ${found ? "a word ends here" : "no word ends here"}`,
              tracks: [
                chips("stream", stream, (i) => (i < idx ? "done" : i === idx ? "read" : "dim")),
                chips("active suffixes", [...active], "active"),
                chips("answers", answers.map((b) => (b ? "true" : "false")), (i) => (i === idx ? "result" : "dim")),
              ],
              counters: [count("position", idx + 1, stream.length), count("matches", answers.filter(Boolean).length)],
              legend: LEG,
              happened: found ? `"${ch}" closes a suffix that matches a dictionary word.` : "None of the surviving suffixes is a complete reversed word.",
              why: "Only suffixes whose reversed form is still a trie prefix can ever match later.",
              codeLine: 15,
            });
          });
          steps.push({
            title: `Answer: ${answers.map((b) => (b ? 1 : 0)).join(" ")}`,
            tracks: [chips("stream", stream, "done"), chips("answers", answers.map((b) => (b ? "true" : "false")), "result")],
            counters: [count("queries", answers.length), count("true answers", answers.filter(Boolean).length)],
            legend: LEG,
            happened: "One boolean was produced after each character.",
            why: "The active-suffix set carries exactly the information needed for the next character.",
            codeLine: 24,
          });
          return steps;
        },
      },
    ],
  });
})();
