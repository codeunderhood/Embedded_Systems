/* ============================================================
   DSA Visuals — Heaps & Top-K I
   Counting, bounded heaps and selection. A "heap" is shown as a
   chip list kept in priority order so the eviction is visible.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const chars = (text) => Array.from(String(text || ""));
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const show = (a) => `[${a.join(", ")}]`;
  const block = (nums, cols) => {
    const width = Math.max(1, cols || 3);
    const rows = Math.max(1, Math.ceil(nums.length / width));
    const out = [];
    for (let r = 0; r < rows; r++) {
      const row = nums.slice(r * width, r * width + width);
      while (row.length < width) row.push("");
      out.push(row);
    }
    return out;
  };

  /* ---------------------------------------------------------- */
  V.register({
    id: "sort-characters-by-frequency",
    title: "Sort Characters by Frequency",
    category: "Heaps & Top-K",
    difficulty: "Intermediate",
    description:
      "Order the characters so the most frequent come first, using counting and buckets instead of comparisons.",
    input: { label: "text", default: "tree", parse: "chars" },
    approaches: [
      {
        name: "Frequency Buckets",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Count each character, then place every character into a bucket indexed by its count.",
          "Walking buckets from the highest count down appends characters in frequency order without ever sorting.",
        ],
        problem: [
          "Bucket sort only works because counts are small integers; arbitrary keys would need a comparison sort.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

void by_frequency(const char *s, char *out) {
    int freq[256] = {0};
    int n = strlen(s);
    for (int i = 0; i < n; i++) freq[(unsigned char)s[i]]++;

    int k = 0;
    for (int f = n; f >= 1; f--)
        for (int c = 0; c < 256; c++)
            for (int t = 0; t < freq[c]; t++)
                if (freq[c] == f) out[k++] = (char)c;

    out[k] = 0;
}

int main(void) {
    char out[64];
    by_frequency("tree", out);
    printf("%s\\n", out); /* eert */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
using namespace std;

string frequencySort(const string& s) {
    unordered_map<char, int> freq;
    for (char c : s) freq[c]++;

    vector<string> buckets(s.size() + 1);
    for (auto& [c, f] : freq) buckets[f] += string(f, c);

    string out;
    for (int f = (int)buckets.size() - 1; f >= 1; f--) out += buckets[f];
    return out;
}

int main() {
    cout << frequencySort("tree") << '\\n'; // eert
}`,
        },
        steps(text) {
          const s = chars(text);
          if (!s.length) {
            return [{
              title: "Give some text",
              tracks: [chips("text", ["—"], "idle")],
              counters: [count("characters", 0)],
              legend: ["idle", "result"],
              happened: "There is nothing to order.",
              why: "Frequencies can only be counted from existing characters.",
            }];
          }
          const freq = new Map();
          for (const c of s) freq.set(c, (freq.get(c) || 0) + 1);
          const distinct = [...freq.entries()].sort((a, b) => b[1] - a[1]);
          const steps = [];
          steps.push({
            title: `Count ${distinct.length} distinct character${distinct.length === 1 ? "" : "s"}`,
            tracks: [track("text", s, fill(s.length, "idle")), chips("frequencies", distinct.map(([c, n]) => `${c}×${n}`), "dim")],
            counters: [count("characters", s.length), count("distinct", distinct.length)],
            legend: LEG,
            happened: `The highest count is ${distinct[0][1]}, so there are that many buckets.`,
            why: "Counting costs one pass and removes the need to compare characters.",
            codeLine: 3,
          });
          const buckets = Array.from({ length: s.length + 1 }, () => []);
          for (const [c, n] of distinct) {
            buckets[n].push(c);
            steps.push({
              title: `Put ${c} into bucket ${n}`,
              tracks: [
                chips("frequencies", distinct.map(([x, m]) => `${x}×${m}`), (i) => (distinct[i][0] === c ? "read" : "dim")),
                chips("buckets used", distinct.map(([, m]) => m), "active"),
              ],
              counters: [count("placed", buckets.flat().length, distinct.length), count("bucket", n)],
              legend: LEG,
              happened: `${c} appears ${n} time${n === 1 ? "" : "s"}, so it belongs in bucket ${n}.`,
              why: "Bucket index is the frequency itself, which keeps the order without comparing.",
              codeLine: 8,
            });
          }
          let out = "";
          for (let f = s.length; f >= 1; f--) {
            if (!buckets[f].length) continue;
            out += buckets[f].map((c) => c.repeat(f)).join("");
            steps.push({
              title: `Bucket ${f}: ${buckets[f].map((c) => c.repeat(f)).join("")}`,
              tracks: [
                chips("buckets", buckets.map((b, i) => (b.length ? `${b.join("")}(${i})` : "·")), (i) => (i === f ? "result" : i > f ? "done" : "dim")),
                chips("output", out.length <= 20 ? [out] : [`${out.slice(0, 20)}…`], "result"),
              ],
              counters: [count("bucket", f), count("written", out.length, s.length)],
              legend: LEG,
              happened: `Every character in this bucket repeats ${f} time${f === 1 ? "" : "s"}.`,
              why: "Reading buckets from high to low yields descending frequency.",
              codeLine: 10,
            });
          }
          steps.push({
            title: `Answer: ${out}`,
            tracks: [chips("answer", [out], "result")],
            counters: [count("written", out.length, s.length), count("answer", out)],
            legend: LEG,
            happened: `The characters are ordered ${out}.`,
            why: "Total work is proportional to the number of characters plus buckets.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "top-k-frequent-elements",
    title: "Top K Frequent Elements",
    category: "Heaps & Top-K",
    difficulty: "Intermediate",
    description:
      "Keep only the k most frequent values using a bounded min-heap keyed by count.",
    input: { label: "numbers | k", default: "1,1,1,2,2,3 | 2", parse: "string" },
    approaches: [
      {
        name: "Bounded Min-Heap",
        complexity: "O(n log k) time, O(n) space",
        idea: [
          "Count each value first. Then push values into a heap ordered by frequency, keeping its size at most k.",
          "When the heap overflows, the least frequent element is at the top and is evicted, so the survivors are the top k.",
        ],
        problem: [
          "The heap stores only k items but the count table still holds every distinct value, so memory is linear.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int value, freq; } Entry;

static int cmp(const void *a, const void *b) {
    const Entry *x = a, *y = b;
    return y->freq - x->freq;          /* descending frequency */
}

int main(void) {
    int a[] = {1, 1, 1, 2, 2, 3};
    int n = 6, k = 2;
    Entry entries[64];
    int m = 0;

    for (int i = 0; i < n; i++) {
        int j = 0;
        while (j < m && entries[j].value != a[i]) j++;
        if (j == m) { entries[m].value = a[i]; entries[m].freq = 0; m++; }
        entries[j].freq++;
    }

    /* a full sort is simpler than a heap for this small demo */
    qsort(entries, m, sizeof(Entry), cmp);
    for (int i = 0; i < k && i < m; i++) printf("%d ", entries[i].value);
    printf("\\n"); /* 1 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_map>
#include <queue>
using namespace std;

vector<int> topKFrequent(const vector<int>& nums, int k) {
    unordered_map<int, int> freq;
    for (int v : nums) freq[v]++;

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> heap;
    for (auto& [value, f] : freq) {
        heap.push({f, value});
        if ((int)heap.size() > k) heap.pop();
    }

    vector<int> out;
    while (!heap.empty()) { out.push_back(heap.top().second); heap.pop(); }
    return out;
}

int main() {
    for (int v : topKFrequent({1,1,1,2,2,3}, 2)) cout << v << ' '; // 2 1
    cout << '\\n';
}`,
        },
        steps(text) {
          const [numsRaw, kRaw] = parts(text);
          const nums = (numsRaw || "").split(/[\s,]+/).filter(Boolean).map(Number);
          const k = Math.max(1, parseInt(kRaw, 10) || 1);
          if (!nums.length) {
            return [{
              title: "Give numbers and k",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("k", k)],
              legend: ["idle", "result"],
              happened: "The left side holds the numbers, the right side k.",
              why: "Frequencies are counted before the heap starts.",
            }];
          }
          const freq = new Map();
          for (const v of nums) freq.set(v, (freq.get(v) || 0) + 1);
          const entries = [...freq.entries()];
          const steps = [];
          steps.push({
            title: `Count ${entries.length} distinct values; keep ${k}`,
            tracks: [
              track("numbers", nums, fill(nums.length, "idle")),
              chips("frequencies", entries.map(([v, n]) => `${v}×${n}`), "dim"),
            ],
            counters: [count("distinct", entries.length), count("heap size", 0, k)],
            legend: LEG,
            happened: `Counts are ${entries.map(([v, n]) => `${v}:${n}`).join(", ")}.`,
            why: "The heap is ordered by count, so the least frequent value is easiest to evict.",
            codeLine: 7,
          });
          const heap = [];
          for (const [value, f] of entries) {
            heap.push([f, value]);
            heap.sort((a, b) => a[0] - b[0]); // smallest frequency at the front
            let evicted = null;
            if (heap.length > k) evicted = heap.shift();
            steps.push({
              title: evicted ? `Push ${value} (${f}×) and evict ${evicted[1]} (${evicted[0]}×)` : `Push ${value} (${f}×) into the heap`,
              tracks: [
                chips("frequencies", entries.map(([v, n]) => `${v}×${n}`), (i) => (entries[i][0] === value ? "read" : "dim")),
                chips("heap (low → high)", heap.map(([n, v]) => `${v}×${n}`), (i) => (i === 0 ? "active" : "good")),
                chips("evicted", evicted ? [`${evicted[1]}×${evicted[0]}`] : ["—"], evicted ? "bad" : "dim"),
              ],
              counters: [count("distinct", entries.length), count("heap size", heap.length, k)],
              legend: LEG,
              happened: evicted
                ? `${evicted[1]} was the least frequent and had to leave to keep the heap at ${k}.`
                : `The heap still has room, so ${value} stays.`,
              why: "Evicting the smallest count leaves the k largest counts behind.",
              codeLine: evicted ? 12 : 11,
            });
          }
          const answer = heap.map(([, v]) => v).reverse();
          steps.push({
            title: `Answer: ${show(answer)}`,
            tracks: [
              chips("heap", heap.map(([n, v]) => `${v}×${n}`), "result"),
              chips("answer", answer, "result"),
            ],
            counters: [count("heap size", heap.length, k), count("answer", show(answer))],
            legend: LEG,
            happened: `These ${heap.length} values have the highest counts.`,
            why: "Each value entered and left the heap at most once.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "kth-largest-element",
    title: "Kth Largest Element",
    category: "Heaps & Top-K",
    difficulty: "Intermediate",
    description:
      "Select the kth largest value in place with quickselect instead of sorting everything.",
    input: { label: "numbers | k", default: "3,2,1,5,6,4 | 2", parse: "string" },
    approaches: [
      {
        name: "Quickselect",
        complexity: "O(n) average, O(n²) worst case",
        idea: [
          "Pick a pivot and partition the row so larger values sit on one side. The pivot's final index tells which side contains the kth largest.",
          "Recurse only into the side that matters. On average the candidate set halves, so the total work is linear.",
        ],
        problem: [
          "A bad pivot sequence degrades to quadratic time; randomised pivots make that unlikely but not impossible.",
        ],
        code: {
          c: `#include <stdio.h>

static void swap(int *a, int *b) { int t = *a; *a = *b; *b = t; }

int quickselect(int *a, int lo, int hi, int k) {
    if (lo == hi) return a[lo];

    int pivot = a[hi], i = lo;
    for (int j = lo; j < hi; j++)
        if (a[j] > pivot) swap(&a[i++], &a[j]);  /* descending partition */
    swap(&a[i], &a[hi]);

    if (i == k) return a[i];
    if (i < k) return quickselect(a, i + 1, hi, k);
    return quickselect(a, lo, i - 1, k);
}

int main(void) {
    int a[] = {3, 2, 1, 5, 6, 4};
    printf("%d\\n", quickselect(a, 0, 5, 1)); /* 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int quickselect(vector<int>& a, int lo, int hi, int k) {
    if (lo == hi) return a[lo];

    int pivot = a[hi], i = lo;
    for (int j = lo; j < hi; j++)
        if (a[j] > pivot) swap(a[i++], a[j]);
    swap(a[i], a[hi]);

    if (i == k) return a[i];
    if (i < k) return quickselect(a, i + 1, hi, k);
    return quickselect(a, lo, i - 1, k);
}

int findKthLargest(vector<int> a, int k) {
    return quickselect(a, 0, a.size() - 1, k - 1);
}

int main() {
    cout << findKthLargest({3,2,1,5,6,4}, 2) << '\\n'; // 5
}`,
        },
        steps(text) {
          const [numsRaw, kRaw] = parts(text);
          const a = (numsRaw || "").split(/[\s,]+/).filter(Boolean).map(Number);
          const k = Math.max(1, Math.min(a.length || 1, parseInt(kRaw, 10) || 1));
          if (!a.length) {
            return [{
              title: "Give numbers and k",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("k", k)],
              legend: ["idle", "result"],
              happened: "The left side holds the numbers, the right side k.",
              why: "The kth largest is found by position, not by sorting.",
            }];
          }
          const steps = [];
          let lo = 0, hi = a.length - 1;
          const target = k - 1;
          steps.push({
            title: `Find position ${target} after a descending partition`,
            tracks: [track("numbers", a, fill(a.length, "idle")), chips("target index", [target], "read")],
            counters: [count("window", `${lo}..${hi}`), count("partitions", 0)],
            legend: LEG,
            happened: `The kth largest sits at index ${target} once larger values are moved left.`,
            why: "Partitioning places one value in its final sorted position.",
            codeLine: 5,
          });
          let partitions = 0, answer = null;
          while (lo <= hi && answer == null) {
            const pivot = a[hi];
            let i = lo;
            for (let j = lo; j < hi; j++) {
              if (a[j] > pivot) {
                const t = a[i]; a[i] = a[j]; a[j] = t;
                i++;
              }
            }
            const t = a[i]; a[i] = a[hi]; a[hi] = t;
            partitions++;
            const at = i;
            const found = at === target;
            if (found) answer = a[at];
            steps.push({
              title: `Pivot ${pivot} lands at ${at}${found ? " — that is the answer" : at < target ? ", go right" : ", go left"}`,
              tracks: [
                track("numbers", a, a.map((_, j) => (j === at ? (found ? "result" : "active") : j >= lo && j <= hi ? (a[j] > pivot ? "done" : "read") : "dim"))),
                chips("pivot", [pivot], "compare"),
              ],
              counters: [count("window", `${lo}..${hi}`), count("partitions", partitions)],
              legend: LEG,
              happened: found
                ? `${at} values are larger than ${pivot}, so ${pivot} is exactly the kth largest.`
                : at < target
                  ? `Position ${at} is too early, so the answer is to its right.`
                  : `Position ${at} is too late, so the answer is to its left.`,
              why: "Only one side of the partition can contain the target index, so the other side is discarded.",
              codeLine: found ? 12 : at < target ? 13 : 14,
            });
            if (found) break;
            if (at < target) lo = at + 1;
            else hi = at - 1;
          }
          steps.push({
            title: `Answer: ${answer}`,
            tracks: [
              track("numbers", a, a.map((_, j) => (j === target ? "result" : "dim"))),
              chips("answer", [answer], "result"),
            ],
            counters: [count("partitions", partitions), count("answer", answer)],
            legend: LEG,
            happened: `${answer} is the ${k}${k === 1 ? "st" : k === 2 ? "nd" : k === 3 ? "rd" : "th"} largest value.`,
            why: "Average linear time comes from shrinking the window instead of sorting both sides.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "k-closest-points-to-origin",
    title: "K Closest Points to Origin",
    category: "Heaps & Top-K",
    difficulty: "Intermediate",
    description:
      "Keep the k points with the smallest squared distance from the origin using a bounded max-heap.",
    input: { label: "points x,y … | k", default: "1,3 -2,2 3,3 | 2", parse: "string" },
    approaches: [
      {
        name: "Max-Heap of Size K",
        complexity: "O(n log k) time, O(k) space",
        idea: [
          "Compare squared distances, which avoids square roots and keeps values exact.",
          "Push each point into a max-heap. When it exceeds k, remove the farthest point, so the heap always holds the k closest.",
        ],
        problem: [
          "Squared distances can overflow 32-bit integers for large coordinates, so a wider type is needed.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int x, y, d; } Point;

static int cmp(const void *a, const void *b) {
    const Point *p = a, *q = b;
    return p->d - q->d;                /* ascending distance */
}

int main(void) {
    Point pts[] = {{1,3,10},{-2,2,8},{3,3,18}};
    int n = 3, k = 2;

    /* a real solution keeps a size-k max-heap; sorting is fine here */
    qsort(pts, n, sizeof(Point), cmp);
    for (int i = 0; i < k; i++)
        printf("(%d,%d) ", pts[i].x, pts[i].y);
    printf("\\n"); /* (-2,2) (1,3) */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
using namespace std;

vector<vector<int>> kClosest(vector<vector<int>> pts, int k) {
    priority_queue<pair<int, int>> heap;   // (distance, index)
    for (int i = 0; i < (int)pts.size(); i++) {
        int d = pts[i][0]*pts[i][0] + pts[i][1]*pts[i][1];
        heap.push({d, i});
        if ((int)heap.size() > k) heap.pop();
    }

    vector<vector<int>> out;
    while (!heap.empty()) { out.push_back(pts[heap.top().second]); heap.pop(); }
    return out;
}

int main() {
    for (auto& p : kClosest({{1,3},{-2,2},{3,3}}, 2))
        cout << '(' << p[0] << ',' << p[1] << ") "; // (-2,2) (1,3)
    cout << '\\n';
}`,
        },
        steps(text) {
          const [ptsRaw, kRaw] = parts(text);
          const pts = (ptsRaw || "").split(/\s+/).filter(Boolean).map((pair) => {
            const [x, y] = pair.split(",").map(Number);
            return { x: x || 0, y: y || 0, d: (x || 0) * (x || 0) + (y || 0) * (y || 0) };
          });
          const k = Math.max(1, parseInt(kRaw, 10) || 1);
          if (!pts.length) {
            return [{
              title: "Give points and k",
              tracks: [chips("points", ["—"], "idle")],
              counters: [count("k", k)],
              legend: ["idle", "result"],
              happened: "Points are written as x,y and separated by spaces.",
              why: "Distance is compared as x² + y².",
            }];
          }
          const steps = [];
          steps.push({
            title: `${pts.length} points; keep the ${k} closest`,
            tracks: [chips("points", pts.map((p) => `(${p.x},${p.y})`), "idle"), chips("squared distance", pts.map((p) => p.d), "dim")],
            counters: [count("points", pts.length), count("heap size", 0, k)],
            legend: LEG,
            happened: `Distances are ${pts.map((p) => `${p.d}`).join(", ")}.`,
            why: "Squaring keeps the ordering and avoids floating point.",
            codeLine: 5,
          });
          const heap = [];
          for (const p of pts) {
            heap.push(p);
            heap.sort((a, b) => b.d - a.d); // farthest first
            let evicted = null;
            if (heap.length > k) evicted = heap.shift();
            steps.push({
              title: evicted ? `Add (${p.x},${p.y}); drop (${evicted.x},${evicted.y})` : `Add (${p.x},${p.y}) with d = ${p.d}`,
              tracks: [
                chips("points", pts.map((q) => `(${q.x},${q.y})`), (i) => (pts[i] === p ? "read" : "dim")),
                chips("heap far → near", heap.map((q) => `(${q.x},${q.y})`), (i) => (i === 0 && evicted ? "bad" : "good")),
                chips("dropped", evicted ? [`(${evicted.x},${evicted.y})`] : ["—"], evicted ? "bad" : "dim"),
              ],
              counters: [count("points", pts.length), count("heap size", heap.length, k)],
              legend: LEG,
              happened: evicted ? `The farthest point in the heap had distance ${evicted.d}, so it left.` : "The heap is still filling up.",
              why: "The farthest survivor is at the top of a max-heap, which makes eviction constant time apart from reheapifying.",
              codeLine: evicted ? 9 : 8,
            });
          }
          const answer = heap.slice().sort((a, b) => a.d - b.d);
          steps.push({
            title: `Answer: ${answer.map((p) => `(${p.x},${p.y})`).join(" ")}`,
            tracks: [
              chips("closest points", answer.map((p) => `(${p.x},${p.y})`), "result"),
              chips("distances", answer.map((p) => p.d), "result"),
            ],
            counters: [count("answer", answer.length), count("heap size", heap.length, k)],
            legend: LEG,
            happened: `These ${answer.length} points have the smallest squared distances.`,
            why: "The heap never held more than k points, so its operations stayed cheap.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "kth-smallest-element-in-a-sorted-matrix",
    title: "Kth Smallest Element in a Sorted Matrix",
    category: "Heaps & Top-K",
    difficulty: "Advanced",
    description:
      "Merge the sorted rows with a heap of one candidate per row, stopping at the kth value.",
    input: { label: "matrix row by row | k", default: "1,5,9 10,11,13 12,13,15 | 8", parse: "string" },
    approaches: [
      {
        name: "K-Way Merge",
        complexity: "O(k log rows) time, O(rows) space",
        idea: [
          "Each row is sorted, so the next smallest overall value must be the smallest unconsumed head among the rows.",
          "Keep one pointer per row in a heap. Pop the smallest, count it, and push the next value from that same row.",
        ],
        problem: [
          "The loop runs k times, which is worse than binary search on the value range when k is close to n².",
        ],
        code: {
          c: `#include <stdio.h>

int kth_smallest(int a[3][3], int rows, int cols, int k) {
    int pos[3] = {0};
    int answer = -1;

    for (int step = 0; step < k; step++) {
        int bestRow = -1;
        for (int r = 0; r < rows; r++) {
            if (pos[r] >= cols) continue;
            if (bestRow < 0 || a[r][pos[r]] < a[bestRow][pos[bestRow]]) bestRow = r;
        }
        answer = a[bestRow][pos[bestRow]++];
    }
    return answer;
}

int main(void) {
    int a[3][3] = {{1,5,9},{10,11,13},{12,13,15}};
    printf("%d\\n", kth_smallest(a, 3, 3, 8)); /* 13 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
using namespace std;

int kthSmallest(const vector<vector<int>>& a, int k) {
    int rows = a.size(), cols = a[0].size();
    priority_queue<tuple<int, int, int>, vector<tuple<int, int, int>>, greater<>> heap;
    for (int r = 0; r < rows; r++) heap.push({a[r][0], r, 0});

    int answer = 0;
    while (k--) {
        auto [value, r, c] = heap.top();
        heap.pop();
        answer = value;
        if (c + 1 < cols) heap.push({a[r][c + 1], r, c + 1});
    }
    return answer;
}

int main() {
    vector<vector<int>> a{{1,5,9},{10,11,13},{12,13,15}};
    cout << kthSmallest(a, 8) << '\\n'; // 13
}`,
        },
        steps(text) {
          const [matRaw, kRaw] = parts(text);
          const flat = (matRaw || "").split(/[\s,]+/).filter(Boolean).map(Number);
          const cols = 3;
          const m = block(flat, cols);
          const rows = m.length;
          const k = Math.max(1, parseInt(kRaw, 10) || 1);
          if (!flat.length) {
            return [{
              title: "Give a matrix and k",
              tracks: [chips("values", ["—"], "idle")],
              counters: [count("k", k)],
              legend: ["idle", "result"],
              happened: "The matrix is read row by row.",
              why: "Each row is sorted, so a heap can merge them.",
            }];
          }
          const steps = [];
          const pos = Array(rows).fill(0);
          const heads = () => pos.map((c, r) => (c < cols ? m[r][c] : "—"));
          steps.push({
            title: `Heap starts with the first value of each of ${rows} rows`,
            kind: "grid", rows, cols,
            cells: grid(rows, cols, (r, c) => ({ v: m[r][c], state: pos[r] === c ? "read" : "dim" })),
            counters: [count("heap size", rows), count("popped", 0, k)],
            legend: LEG,
            happened: `Heads are ${heads().join(", ")}.`,
            why: "The smallest overall value must be one of the row heads.",
            codeLine: 4,
          });
          let popped = 0, answer = null;
          while (popped < k) {
            let best = -1;
            for (let r = 0; r < rows; r++) {
              if (pos[r] >= cols) continue;
              if (best < 0 || m[r][pos[r]] < m[best][pos[best]]) best = r;
            }
            if (best < 0) break;
            const value = m[best][pos[best]];
            answer = value;
            pos[best]++;
            popped++;
            steps.push({
              title: `Pop ${value} from row ${best} (${popped}${popped === 1 ? "st" : popped === 2 ? "nd" : popped === 3 ? "rd" : "th"})`,
              kind: "grid", rows, cols,
              cells: grid(rows, cols, (r, c) => {
                if (r === best && c === pos[best] - 1) return popped === k ? "result" : "done";
                if (c === pos[r]) return "active";
                return c < pos[r] ? "dim" : "idle";
              }),
              counters: [count("heap size", rows), count("popped", popped, k)],
              legend: LEG,
              happened: popped === k ? `${value} is the kth value removed.` : `Row ${best} advances to ${pos[best] < cols ? m[best][pos[best]] : "the end"}.`,
              why: "Replacing the popped head with the next value in its own row keeps the merge correct.",
              codeLine: 9,
            });
            if (popped === k) break;
          }
          steps.push({
            title: `Answer: ${answer}`,
            tracks: [chips("answer", [answer], "result")],
            counters: [count("popped", popped, k), count("answer", answer)],
            legend: LEG,
            happened: `After ${popped} pops the last removed value is ${answer}.`,
            why: "A heap of one head per row performs the merge without ever touching the other cells.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "smallest-range-covering-k-lists",
    title: "Smallest Range Covering K Lists",
    category: "Heaps & Top-K",
    difficulty: "Advanced",
    description:
      "Slide a window over the merged lists, tracking the maximum head and the current minimum from a heap.",
    input: { label: "lists separated by | (comma values)", default: "4,10,15,24,26 | 0,9,12,20 | 5,18,22,30", parse: "string" },
    approaches: [
      {
        name: "Heap Over Row Heads",
        complexity: "O(N log k) time, O(k) space",
        idea: [
          "Any range covering all lists must include one value from each. The narrowest window starts at the smallest current head.",
          "Track the largest head seen. Repeatedly pop the smallest head, shrink the range, and push the next value from that list.",
        ],
        problem: [
          "A list that runs out stops the process; every candidate range after that point would be missing a list.",
        ],
        code: {
          c: `#include <stdio.h>

int main(void) {
    int lists[3][5] = {{4,10,15,24,26},{0,9,12,20,0},{5,18,22,30,0}};
    int sizes[3] = {5,4,4};
    int pos[3] = {0};
    int bestLo = 0, bestHi = 1000000;

    while (1) {
        int minRow = -1, maxValue = -1000000;
        for (int r = 0; r < 3; r++) {
            if (pos[r] >= sizes[r]) { minRow = -1; break; }
            if (minRow < 0 || lists[r][pos[r]] < lists[minRow][pos[minRow]]) minRow = r;
            if (lists[r][pos[r]] > maxValue) maxValue = lists[r][pos[r]];
        }
        if (minRow < 0) break;

        int lo = lists[minRow][pos[minRow]];
        if (maxValue - lo < bestHi - bestLo) { bestLo = lo; bestHi = maxValue; }
        pos[minRow]++;
    }
    printf("[%d, %d]\\n", bestLo, bestHi); /* [20, 24] */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
#include <climits>
using namespace std;

pair<int, int> smallestRange(const vector<vector<int>>& lists) {
    priority_queue<tuple<int, int, int>, vector<tuple<int, int, int>>, greater<>> heap;
    int currentMax = INT_MIN;
    for (int r = 0; r < (int)lists.size(); r++) {
        heap.push({lists[r][0], r, 0});
        currentMax = max(currentMax, lists[r][0]);
    }

    int bestLo = 0, bestHi = INT_MAX;
    while (true) {
        auto [value, r, c] = heap.top();
        if (currentMax - value < bestHi - bestLo) { bestLo = value; bestHi = currentMax; }
        heap.pop();
        if (c + 1 == (int)lists[r].size()) break;
        heap.push({lists[r][c + 1], r, c + 1});
        currentMax = max(currentMax, lists[r][c + 1]);
    }
    return {bestLo, bestHi};
}

int main() {
    auto [lo, hi] = smallestRange({{4,10,15,24,26},{0,9,12,20},{5,18,22,30}});
    cout << '[' << lo << ", " << hi << "]\\n"; // [20, 24]
}`,
        },
        steps(text) {
          const groups = parts(text).map((g) => g.split(",").filter(Boolean).map((v) => parseInt(v.trim(), 10) || 0));
          const lists = groups.filter((g) => g.length);
          if (!lists.length) {
            return [{
              title: "Give at least one list",
              tracks: [chips("lists", ["—"], "idle")],
              counters: [count("lists", 0)],
              legend: ["idle", "result"],
              happened: "Lists are separated by | and values by commas.",
              why: "Every list must contribute one value to the range.",
            }];
          }
          const steps = [];
          const pos = lists.map(() => 0);
          const heads = () => pos.map((c, r) => (c < lists[r].length ? lists[r][c] : "—"));
          const maxHead = () => Math.max(...heads().filter((v) => v !== "—"));
          let bestLo = 0, bestHi = Infinity;
          steps.push({
            title: `${lists.length} lists; start at each first value`,
            tracks: [chips("heads", heads(), "read"), chips("range", ["—"], "dim")],
            counters: [count("lists", lists.length), count("best width", "∞")],
            legend: LEG,
            happened: `The starting heads are ${heads().join(", ")}.`,
            why: "The smallest head is the left edge of the current candidate range.",
            codeLine: 5,
          });
          while (true) {
            let minRow = -1;
            for (let r = 0; r < lists.length; r++) {
              if (pos[r] >= lists[r].length) { minRow = -1; break; }
              if (minRow < 0 || lists[r][pos[r]] < lists[minRow][pos[minRow]]) minRow = r;
            }
            if (minRow < 0) break;
            const maxValue = maxHead();
            const lo = lists[minRow][pos[minRow]];
            const improved = maxValue - lo < bestHi - bestLo;
            if (improved) { bestLo = lo; bestHi = maxValue; }
            pos[minRow]++;
            steps.push({
              title: `Range [${lo}, ${maxValue}] width ${maxValue - lo}${improved ? " ✓ best" : ""}`,
              tracks: [
                chips("heads", heads(), (i) => (i === minRow ? "active" : "dim")),
                chips("range", [`[${bestLo}, ${bestHi === Infinity ? "∞" : bestHi}]`], "result"),
              ],
              counters: [count("lists", lists.length), count("best width", bestHi === Infinity ? "∞" : bestHi - bestLo)],
              legend: LEG,
              happened: improved ? "This range is narrower than every earlier candidate." : `The range is ${maxValue - lo} wide, not an improvement.`,
              why: "The left edge is fixed by the minimum head; advancing it is the only way to shrink the range.",
              codeLine: improved ? 16 : 17,
            });
            if (bestHi !== Infinity && bestHi - bestLo === 0) break;
          }
          steps.push({
            title: bestHi === Infinity ? "Answer: no range covers every list" : `Answer: [${bestLo}, ${bestHi}]`,
            tracks: [chips("answer", bestHi === Infinity ? ["—"] : [`[${bestLo}, ${bestHi}]`], "result")],
            counters: [count("answer width", bestHi === Infinity ? 0 : bestHi - bestLo), count("answer", bestHi === Infinity ? "—" : `[${bestLo}, ${bestHi}]`)],
            legend: LEG,
            happened: bestHi === Infinity ? "A list ran out before every list had a value in range." : `The narrowest covering range is ${bestHi - bestLo} wide.`,
            why: "Every value in every list was considered as exactly one left edge.",
            codeLine: 22,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "task-scheduler",
    title: "Task Scheduler",
    category: "Heaps & Top-K",
    difficulty: "Intermediate",
    description:
      "Schedule tasks with a cooling gap between repeats and compute the minimum total time, including idle slots.",
    input: { label: "tasks | cooldown", default: "A,A,A,B,B,B | 2", parse: "string" },
    approaches: [
      {
        name: "Count the Frames",
        complexity: "O(n) time, O(alphabet) space",
        idea: [
          "The most frequent task dictates the shape: it opens a frame, then needs n slots of cooling before repeating.",
          "Fill the frames with other tasks; leftover tasks simply extend the final frame. The answer is the larger of that frame total and the number of tasks.",
        ],
        problem: [
          "The closed form assumes the cooldown is uniform and the schedule may contain idle slots; a different objective would need simulation.",
        ],
        code: {
          c: `#include <stdio.h>

int least_interval(const char *tasks, int n) {
    int freq[26] = {0};
    int total = 0;
    for (int i = 0; tasks[i]; i++) { freq[tasks[i] - 'A']++; total++; }

    int maxFreq = 0, maxCount = 0;
    for (int i = 0; i < 26; i++) {
        if (freq[i] > maxFreq) { maxFreq = freq[i]; maxCount = 1; }
        else if (freq[i] == maxFreq && maxFreq > 0) maxCount++;
    }

    int frames = (maxFreq - 1) * (n + 1) + maxCount;
    return frames > total ? frames : total;
}

int main(void) {
    printf("%d\\n", least_interval("AAABBB", 2)); /* 8 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

int leastInterval(const string& tasks, int n) {
    vector<int> freq(26, 0);
    for (char c : tasks) freq[c - 'A']++;

    int maxFreq = *max_element(freq.begin(), freq.end());
    int maxCount = count(freq.begin(), freq.end(), maxFreq);
    int frames = (maxFreq - 1) * (n + 1) + maxCount;
    return max(frames, (int)tasks.size());
}

int main() {
    cout << leastInterval("AAABBB", 2) << '\\n'; // 8
}`,
        },
        steps(text) {
          const [tasksRaw, nRaw] = parts(text);
          const tasks = chars(tasksRaw);
          const n = Math.max(0, parseInt(nRaw, 10) || 0);
          if (!tasks.length) {
            return [{
              title: "Give tasks and a cooldown",
              tracks: [chips("tasks", ["—"], "idle")],
              counters: [count("time", 0)],
              legend: ["idle", "result"],
              happened: "The left side holds the task letters, the right side the cooldown.",
              why: "Identical tasks must be separated by n slots.",
            }];
          }
          const freq = new Map();
          for (const c of tasks) freq.set(c, (freq.get(c) || 0) + 1);
          const entries = [...freq.entries()].sort((a, b) => b[1] - a[1]);
          const maxFreq = entries[0][1];
          const maxCount = entries.filter(([, f]) => f === maxFreq).length;
          const frames = (maxFreq - 1) * (n + 1) + maxCount;
          const answer = Math.max(frames, tasks.length);
          const steps = [];
          steps.push({
            title: `Most frequent task appears ${maxFreq} times; cooldown ${n}`,
            tracks: [track("tasks", tasks, fill(tasks.length, "idle")), chips("counts", entries.map(([c, f]) => `${c}×${f}`), "dim")],
            counters: [count("tasks", tasks.length), count("frames", frames)],
            legend: LEG,
            happened: `${maxCount} task${maxCount === 1 ? "" : "s"} reach the maximum count.`,
            why: "The most frequent task limits how tightly the schedule can be packed.",
            codeLine: 9,
          });
          const slots = [];
          for (let f = 0; f < maxFreq - 1; f++) {
            const row = [];
            for (let slot = 0; slot < n + 1; slot++) {
              if (slot === 0) row.push(entries[0][0]);
              else row.push("idle");
            }
            slots.push(row);
            steps.push({
              title: `Frame ${f + 1}: ${entries[0][0]} then ${n} cooling slot${n === 1 ? "" : "s"}`,
              tracks: [
                chips("frame", row, (i) => (i === 0 ? "done" : "dim")),
                chips("placed so far", [`${(f + 1) * (n + 1)} slots`], "active"),
              ],
              counters: [count("frames", f + 1, maxFreq - 1), count("slots", (f + 1) * (n + 1))],
              legend: LEG,
              happened: `Each full frame costs ${n + 1} time units.`,
              why: "The cooldown forces the gap even when no other task is ready.",
              codeLine: 12,
            });
          }
          steps.push({
            title: `Last frame holds ${maxCount} task${maxCount === 1 ? "" : "s"} → ${frames} time`,
            tracks: [
              chips("frame tail", entries.filter(([, f]) => f === maxFreq).map(([c]) => c), "done"),
              chips("formula", [`(${maxFreq} − 1) × ${n + 1} + ${maxCount} = ${frames}`], "result"),
            ],
            counters: [count("frames", frames), count("tasks", tasks.length)],
            legend: LEG,
            happened: `The last frame only needs the tasks that share the maximum count.`,
            why: "No cooling is needed after the final occurrence of the busiest task.",
            codeLine: 13,
          });
          steps.push({
            title: `Answer: ${answer} time unit${answer === 1 ? "" : "s"}`,
            tracks: [track("tasks", tasks, fill(tasks.length, "done")), chips("answer", [answer], "result")],
            counters: [count("tasks", tasks.length), count("answer", answer)],
            legend: LEG,
            happened: frames > tasks.length
              ? `The frames force ${frames} slots, which is more than the ${tasks.length} tasks.`
              : `There are enough tasks to fill every cooling slot, so time equals ${tasks.length}.`,
            why: "We can never do better than one unit per task, and the frames give the other lower bound.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });
})();
