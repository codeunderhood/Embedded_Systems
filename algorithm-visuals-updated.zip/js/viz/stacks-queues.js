/* ============================================================
   DSA Visuals — Stacks & Queues
   Six visualisations of LIFO / FIFO bookkeeping:
     valid parentheses, min stack, queue from two stacks,
     stack from two queues, reverse Polish notation and a
     two-stack basic calculator.

   Convention used everywhere: a stack is written bottom first,
   top last — the rightmost cell is the top. Queues are written
   front first, back last. Every step is original work written
   for this app (see SPEC.md).
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  /* ---------- small local helpers ---------- */

  function stackCells(values, states, tags) {
    if (!values.length) return [{ v: "∅", state: "idle", empty: true }];
    return values.map((v, i) => ({
      v,
      state: (states && states[i]) || "idle",
      tag: tags ? tags[i] : undefined,
    }));
  }

  /* vertical stack: bottom first, top last */
  function stackTrack(label, values, states, tags) {
    return { label, dir: "col", cells: stackCells(values, states, tags) };
  }

  /* horizontal queue: front first, back last */
  function queueTrack(label, values, states, tags) {
    return { label, cells: stackCells(values, states, tags) };
  }

  function topStates(length, topState) {
    return Array.from({ length }, (_, i) => (i === length - 1 ? topState : "done"));
  }

  const WHOLE = /^[+-]?\d+$/;
  const OPEN = new Set(["(", "[", "{"]);
  const CLOSE = new Set([")", "]", "}"]);
  const MATCH = { ")": "(", "]": "[", "}": "{" };

  /* ============================================================
     1. Valid Parentheses
     ============================================================ */
  V.register({
    id: "valid-parentheses",
    title: "Valid Parentheses",
    category: "Stacks & Queues",
    difficulty: "Beginner",
    description: "Check that every opening bracket is closed by the matching kind, in the right order.",
    input: { label: "Bracket string", default: "{[()]}", parse: "string" },
    approaches: [
      {
        name: "One Stack of Openings",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Read the string left to right and keep a stack of opening brackets. Every opening bracket is pushed; every closing bracket must match the bracket sitting on top, or the string is invalid.",
          "When the whole string has been read the stack must be empty. The bracket row is read left to right; the stack is written bottom first, top last — the rightmost cell is the top.",
        ],
        problem: [
          "The stack can grow to the full length of the input (imagine a hundred opening brackets in a row), so the O(1) dream is gone. The payoff is that each character is visited exactly once.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* One stack holding the brackets still waiting for a partner. */
bool is_valid(const char *s) {
    char stack[256];
    int top = 0;
    for (int i = 0; s[i] != '\\0'; i++) {
        char c = s[i];
        if (c == '(' || c == '[' || c == '{') {
            stack[top++] = c;              /* opening: wait */
        } else if (c == ')' || c == ']' || c == '}') {
            if (top == 0) return false;    /* nothing to close */
            char open = stack[--top];
            if ((c == ')' && open != '(') ||
                (c == ']' && open != '[') ||
                (c == '}' && open != '{'))
                return false;              /* wrong partner */
        } else {
            return false;                  /* not a bracket */
        }
    }
    return top == 0;                       /* leftovers? invalid */
}

int main(void) {
    printf("%s\\n", is_valid("{[()]}") ? "valid" : "invalid");
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>

bool isValid(const std::string& s) {
    std::vector<char> stack;
    for (char c : s) {
        if (c == '(' || c == '[' || c == '{') {
            stack.push_back(c);
        } else if (c == ')' || c == ']' || c == '}') {
            if (stack.empty()) return false;
            char open = stack.back();
            stack.pop_back();
            if ((c == ')' && open != '(') ||
                (c == ']' && open != '[') ||
                (c == '}' && open != '{'))
                return false;
        } else {
            return false;
        }
    }
    return stack.empty();
}

int main() {
    std::cout << (isValid("{[()]}") ? "valid" : "invalid") << '\\n';
}`,
        },
        steps(text) {
          const chars = [...String(text)];
          const n = chars.length;
          const shown = chars.map((c) => (c === " " ? "␠" : c));
          const states = fill(n, "idle");
          const stack = [];
          const steps = [];
          let matched = 0;
          let bad = null;
          let badAt = -1;
          const legend = ["read", "good", "bad", "done", "idle"];

          const stackStates = () =>
            stack.map((_, k) => (k === stack.length - 1 ? "read" : "done"));

          steps.push({
            title: "Empty stack, whole string waiting",
            tracks: [
              track("brackets", shown, states),
              stackTrack("stack of openings", stack, []),
            ],
            counters: [count("characters read", 0, n), count("pairs matched", 0), count("stack depth", 0)],
            legend,
            happened: `The string has ${n} characters. The stack starts empty; a stack is written bottom first, top last.`,
            why: "Closing brackets arrive in the reverse order of their openings, which is exactly what a last-in-first-out stack remembers.",
            codeLine: 5,
          });

          for (let i = 0; i < n; i++) {
            const c = chars[i];
            if (/\s/.test(c)) {
              states[i] = "dim";
              continue;
            }
            states[i] = "read";
            if (OPEN.has(c)) {
              stack.push(c);
              steps.push({
                title: `Push ${c} → depth ${stack.length}`,
                tracks: [track("brackets", shown, states), stackTrack("stack of openings", stack, stackStates())],
                counters: [
                  count("characters read", i + 1, n),
                  count("pairs matched", matched),
                  count("stack depth", stack.length),
                ],
                legend,
                happened: `${c} opens a group, so it is pushed and waits for its partner at the top of the stack.`,
                why: "The most recent opening bracket is always the first one that must be closed — that is the stack rule.",
                codeLine: 10,
              });
            } else if (CLOSE.has(c)) {
              if (!stack.length) {
                bad = `there is a closing ${c} but the stack is empty`;
                badAt = i;
                states[i] = "bad";
                steps.push({
                  title: `Close ${c} → nothing to close`,
                  tracks: [track("brackets", shown, states), stackTrack("stack of openings", stack, [])],
                  counters: [
                    count("characters read", i + 1, n),
                    count("pairs matched", matched),
                    count("stack depth", 0),
                  ],
                  legend,
                  happened: `The closing ${c} looks for a partner, but the stack holds nothing.`,
                  why: "A closing bracket can never create a pair on its own, so the string is already invalid.",
                  codeLine: 13,
                });
                break;
              }
              const open = stack[stack.length - 1];
              if (open !== MATCH[c]) {
                bad = `a closing ${c} meets a ${open} on top of the stack`;
                badAt = i;
                states[i] = "bad";
                steps.push({
                  title: `Close ${c} ✗ expected the partner of ${open}`,
                  tracks: [
                    track("brackets", shown, states),
                    stackTrack("stack of openings", stack, stack.map((_, k) => (k === stack.length - 1 ? "compare" : "done"))),
                  ],
                  counters: [
                    count("characters read", i + 1, n),
                    count("pairs matched", matched),
                    count("stack depth", stack.length),
                  ],
                  legend,
                  happened: `${c} is the wrong kind of closing bracket for the ${open} on top.`,
                  why: "Brackets must close in matching pairs as well as in reverse order; one wrong kind settles the answer.",
                  codeLine: 15,
                });
                break;
              }
              stack.pop();
              matched++;
              states[i] = "good";
              steps.push({
                title: `${c} matches ${open} → pop, ${matched} ${matched === 1 ? "pair" : "pairs"} done`,
                tracks: [
                  track("brackets", shown, states),
                  stackTrack("stack of openings", stack, stackStates()),
                ],
                counters: [
                  count("characters read", i + 1, n),
                  count("pairs matched", matched),
                  count("stack depth", stack.length),
                ],
                legend,
                happened: `The top ${open} is the correct partner of ${c}; both are removed and the stack shrinks by one.`,
                why: "Popping restores the earlier opening bracket as the next thing that must be closed.",
                codeLine: 14,
              });
            } else {
              bad = `"${c}" is not a bracket at all`;
              badAt = i;
              states[i] = "bad";
              steps.push({
                title: `Rejected "${c}" — not a bracket`,
                tracks: [track("brackets", shown, states), stackTrack("stack of openings", stack, [])],
                counters: [count("characters read", i + 1, n), count("pairs matched", matched), count("stack depth", stack.length)],
                legend,
                happened: `The character "${c}" has no bracket meaning, so the string cannot be a valid bracket sequence.`,
                why: "The method only understands the six bracket characters; anything else must be reported honestly.",
                codeLine: 20,
              });
              break;
            }
          }

          if (!bad && stack.length) {
            bad = `${stack.length} opening ${stack.length === 1 ? "bracket was" : "brackets were"} never closed`;
            badAt = -1;
          }

          if (bad) {
            steps.push({
              title: `Answer: invalid — ${bad}`,
              tracks: [
                track("brackets", shown, states),
                stackTrack("stack of openings", stack, stack.map(() => "bad")),
              ],
              counters: [
                count("characters read", n, n),
                count("pairs matched", matched),
                count("answer", "invalid"),
              ],
              legend,
              happened: `The string cannot be valid: ${bad}.`,
              why: "Stopping at the first contradiction is enough — no later character can repair a broken bracket order.",
              codeLine: 23,
            });
            return steps;
          }

          steps.push({
            title: "Answer: valid — every bracket found a partner",
            tracks: [
              track("brackets", shown, shown.map(() => "good")),
              stackTrack("stack of openings", [], []),
            ],
            counters: [count("characters read", n, n), count("pairs matched", matched), count("answer", "valid")],
            legend,
            happened: `All ${matched} pairs closed correctly and the stack ended empty.`,
            why: "An empty stack after the final character proves that nothing is still waiting to be closed.",
            codeLine: 23,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     2. Min Stack
     ============================================================ */
  function minStackSteps(script, mode) {
    const toks = Array.isArray(script) ? script : [];
    const n = toks.length;
    const paired = mode === "pairs";
    let main = [];
    let mins = [];
    let pairs = [];
    let pushes = 0;
    let done = 0;
    const steps = [];
    const legend = ["read", "done", "result", "bad", "dim", "idle"];

    const valuesNow = () => (paired ? pairs.map((p) => p.v) : main.slice());
    const minNow = () => {
      if (paired) return pairs.length ? pairs[pairs.length - 1].m : null;
      return mins.length ? mins[mins.length - 1] : null;
    };
    const mainTrack = (topState) => {
      const vals = valuesNow();
      const states = vals.map((_, k) =>
        k === vals.length - 1 ? (topState || "read") : "done");
      const tags = paired ? pairs.map((p) => `min ${p.m}`) : undefined;
      return stackTrack("main stack", vals, states, tags);
    };
    const minTrack = (topState) => {
      if (paired) {
        const m = minNow();
        return {
          label: "min so far",
          dir: "col",
          cells: [{ v: m == null ? "∅" : m, state: m == null ? "idle" : (topState || "result"), tag: "getMin" }],
        };
      }
      const states = mins.map((_, k) =>
        k === mins.length - 1 ? (topState || "result") : "done");
      return stackTrack("min stack", mins, states);
    };
    const counters = (extra) => [
      count("tokens read", done, n),
      count("pushes", pushes),
      count("size", valuesNow().length),
      ...(extra || []),
    ];

    steps.push({
      title: paired
        ? "One stack, each cell carries its own minimum"
        : "Two stacks: values and running minima",
      tracks: [mainTrack(), minTrack()],
      counters: counters(),
      legend,
      happened: paired
        ? `The script has ${n} tokens. A stack is written bottom first, top last; every cell will also remember the smallest value at or below it.`
        : `The script has ${n} tokens. Both stacks are written bottom first, top last — the rightmost cell is the top.`,
      why: paired
        ? "If each cell already knows the minimum down to itself, popping one cell automatically restores the previous minimum."
        : "The min stack mirrors the main stack depth for depth, so its top always answers getMin without a search.",
      codeLine: paired ? 16 : 12,
    });

    let i = 0;
    while (i < n) {
      const raw = String(toks[i]);
      const op = raw.toLowerCase();

      if (op === "push") {
        const argRaw = i + 1 < n ? String(toks[i + 1]) : null;
        if (argRaw == null) {
          done = Math.min(n, i + 1);
          steps.push({
            title: "Ignored push — no value follows it",
            tracks: [mainTrack("done"), minTrack("done")],
            counters: counters(),
            legend,
            happened: `The token "push" is not followed by a number, so nothing is added.`,
            why: "A friendly player reports a broken instruction instead of guessing a value.",
            codeLine: paired ? 16 : 12,
          });
          i += 1;
          continue;
        }
        if (!WHOLE.test(argRaw)) {
          done = Math.min(n, i + 2);
          steps.push({
            title: `Ignored push — "${argRaw}" is not a whole number`,
            tracks: [mainTrack("done"), minTrack("done")],
            counters: counters(),
            legend,
            happened: `The pair "push ${argRaw}" cannot be carried out, so the stacks stay as they were.`,
            why: "The operations are read as a script; one malformed value should not crash the rest of the walk.",
            codeLine: paired ? 16 : 12,
          });
          i += 2;
          continue;
        }
        const x = Number(argRaw);
        let m;
        if (paired) {
          m = pairs.length ? Math.min(x, pairs[pairs.length - 1].m) : x;
          pairs.push({ v: x, m });
        } else {
          m = mins.length ? Math.min(x, mins[mins.length - 1]) : x;
          main.push(x);
          mins.push(m);
        }
        pushes++;
        done = Math.min(n, i + 2);
        const improved = valuesNow().length === 1 || m === x;
        steps.push({
          title: paired ? `Push ${x} → cell says min ${m}` : `Push ${x} → min stack gains ${m}`,
          tracks: [mainTrack("read"), minTrack(improved ? "result" : "read")],
          counters: counters([count("minimum", m)]),
          legend,
          happened: paired
            ? `The new cell stores ${x} together with the smallest value seen so far, ${m}.`
            : `The value ${x} joins the main stack; the min stack receives ${m}, the smallest value so far.`,
          why: paired
            ? "The old minimum is copied into the new cell, so it survives even if this cell is popped later."
            : "Writing the running minimum beside every value means getMin never has to scan the main stack.",
          codeLine: paired ? 17 : 13,
        });
        i += 2;
        continue;
      }

      if (op === "pop" || op === "peek" || op === "top" || op === "min" || op === "getmin" || op === "size" || op === "empty") {
        done = Math.min(n, i + 1);
        if (op === "pop") {
          if (!valuesNow().length) {
            steps.push({
              title: "Pop skipped — the stack is empty",
              tracks: [mainTrack(), minTrack()],
              counters: counters([count("minimum", "none")]),
              legend,
              happened: "There is nothing to remove, so the stacks stay empty.",
              why: "A well-behaved stack reports the empty case instead of reading below the bottom.",
              codeLine: paired ? 25 : 21,
            });
          } else {
            let removed;
            if (paired) {
              removed = pairs.pop().v;
            } else {
              removed = main.pop();
              mins.pop();
            }
            const m = minNow();
            steps.push({
              title: m == null ? `Pop ${removed} → stack is empty` : `Pop ${removed} → minimum is now ${m}`,
              tracks: [mainTrack("read"), minTrack("result")],
              counters: counters([count("minimum", m == null ? "none" : m)]),
              legend,
              happened: m == null
                ? `The last value ${removed} leaves the stack; there is no minimum left.`
                : paired
                  ? `${removed} leaves the stack, and the cell below already carries the restored minimum ${m}.`
                  : `${removed} leaves the main stack and its mirror leaves the min stack; the new top holds ${m}.`,
              why: paired
                ? "No recomputation happens: the surviving cell still knows the minimum of everything beneath it."
                : "Popping both stacks in step keeps their depths aligned, so the min top always matches the main top.",
              codeLine: paired ? 25 : 22,
            });
          }
        } else if (op === "peek" || op === "top") {
          const vals = valuesNow();
          if (!vals.length) {
            steps.push({
              title: "Peek skipped — the stack is empty",
              tracks: [mainTrack(), minTrack()],
              counters: counters([count("minimum", "none")]),
              legend,
              happened: "The top is requested, but the stack has no cells.",
              why: "There is no value to read, and pretending otherwise would hide the empty case.",
              codeLine: paired ? 29 : 25,
            });
          } else {
            const top = vals[vals.length - 1];
            steps.push({
              title: `Peek → top ${top}, minimum ${minNow()}`,
              tracks: [mainTrack("read"), minTrack("result")],
              counters: counters([count("top", top), count("minimum", minNow())]),
              legend,
              happened: `The top value is ${top} and the current minimum is ${minNow()}.`,
              why: "Both answers are available at the top of their stacks, so peeking is constant work.",
              codeLine: paired ? 29 : 25,
            });
          }
        } else if (op === "min" || op === "getmin") {
          const m = minNow();
          steps.push({
            title: m == null ? "getMin → stack is empty" : `getMin → ${m}`,
            tracks: [mainTrack("done"), minTrack("result")],
            counters: counters([count("minimum", m == null ? "none" : m)]),
            legend,
            happened: m == null ? "No values have been pushed, so there is no minimum." : `The minimum of every value currently on the stack is ${m}.`,
            why: "This is the whole point of the extra bookkeeping: the minimum is read, not searched for.",
            codeLine: paired ? 30 : 26,
          });
        } else if (op === "size") {
          steps.push({
            title: `Size → ${valuesNow().length}`,
            tracks: [mainTrack("done"), minTrack("done")],
            counters: counters(),
            legend,
            happened: `The stack currently holds ${valuesNow().length} values.`,
            why: "The size is just the depth of the main stack; both mirrors always agree.",
            codeLine: paired ? 11 : 7,
          });
        } else {
          const empty = valuesNow().length === 0;
          steps.push({
            title: `Empty? → ${empty ? "yes" : "no"}`,
            tracks: [mainTrack("done"), minTrack("done")],
            counters: counters([count("answer", empty ? "yes" : "no")]),
            legend,
            happened: empty ? "The stack has no values, so it is empty." : `There are ${valuesNow().length} values, so the stack is not empty.`,
            why: "An emptiness check only needs the size — no cells have to move.",
            codeLine: paired ? 11 : 7,
          });
        }
        i += 1;
        continue;
      }

      done = Math.min(n, i + 1);
      steps.push({
        title: `Ignored "${raw}" — not a stack operation`,
        tracks: [mainTrack("done"), minTrack("done")],
        counters: counters(),
        legend,
        happened: `The token "${raw}" is not push, pop, peek, getMin, size or empty, so the walk skips it.`,
        why: "The script is read generously: an unknown word is announced and the remaining instructions still run.",
        codeLine: paired ? 16 : 12,
      });
      i += 1;
    }

    const vals = valuesNow();
    const m = minNow();
    steps.push({
      title: vals.length ? `Answer: minimum is ${m}` : "Answer: no values, no minimum",
      tracks: [mainTrack("dim"), minTrack("result")],
      counters: [count("tokens read", n, n), count("pushes", pushes), count("answer", m == null ? "none" : m)],
      legend,
      happened: vals.length
        ? `The script is finished; the stack holds ${vals.join(", ")} and its minimum is ${m}.`
        : "The script is finished and the stack is empty, so no minimum exists.",
      why: paired
        ? "The top cell's stored minimum is the answer, even after every push and pop in the script."
        : "The top of the min stack is the answer — it was maintained on every single push and pop.",
      codeLine: paired ? 30 : 26,
    });
    return steps;
  }

  V.register({
    id: "min-stack",
    title: "Min Stack",
    category: "Stacks & Queues",
    difficulty: "Intermediate",
    description: "Support push, pop, peek and getMin in constant time using a stack that remembers minima.",
    input: { label: "Operation script", default: "push 5 push 2 push 7 push 1 pop peek", parse: "tokens" },
    approaches: [
      {
        name: "Parallel Min Stack",
        complexity: "O(1) per operation, O(n) space",
        idea: [
          "Keep two stacks side by side. The main stack stores values exactly as pushed. The min stack stores, at the same depth, the smallest value seen so far: push(x) adds x to the main stack and min(x, old min top) to the min stack.",
          "pop removes one cell from each stack, so getMin is always just the top of the min stack. Both stacks are written bottom first, top last.",
        ],
        problem: [
          "Every push writes two cells, so the memory roughly doubles. In exchange, every operation — including getMin — stays constant time.",
        ],
        code: {
          c: `#include <stdio.h>

#define CAP 200

typedef struct {
    int value[CAP];
    int minimums[CAP];
    int top;                 /* number of items; 0 means empty */
} MinStack;

void init(MinStack *s) { s->top = 0; }

void push(MinStack *s, int x) {
    int m = x;
    if (s->top > 0 && s->minimums[s->top - 1] < m)
        m = s->minimums[s->top - 1];
    s->value[s->top] = x;
    s->minimums[s->top] = m;
    s->top++;
}

void pop(MinStack *s) {
    if (s->top > 0) s->top--;      /* min comes back automatically */
}

int peek(const MinStack *s) { return s->value[s->top - 1]; }
int get_min(const MinStack *s) { return s->minimums[s->top - 1]; }

int main(void) {
    MinStack s;
    init(&s);
    push(&s, 5); push(&s, 2); push(&s, 7);
    printf("min %d\\n", get_min(&s));                  /* 2 */
    pop(&s);
    printf("top %d min %d\\n", peek(&s), get_min(&s)); /* 7 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

class MinStack {
    std::vector<int> values;
    std::vector<int> mins;
public:
    void push(int x) {
        values.push_back(x);
        mins.push_back(mins.empty() ? x : std::min(x, mins.back()));
    }
    void pop() {
        if (!values.empty()) { values.pop_back(); mins.pop_back(); }
    }
    int peek() const { return values.back(); }
    int getMin() const { return mins.back(); }
};

int main() {
    MinStack s;
    s.push(5); s.push(2); s.push(7);
    std::cout << "min " << s.getMin() << '\\n';   // 2
    s.pop();
    std::cout << "top " << s.peek() << " min " << s.getMin() << '\\n'; // 7 2
}`,
        },
        steps(script) {
          return minStackSteps(script, "parallel");
        },
      },
      {
        name: "Stack of Pairs",
        complexity: "O(1) per operation, O(n) space",
        idea: [
          "Store a pair in one stack: the value itself plus the minimum of everything from the bottom up to that value. A push copies forward the smaller of the new value and the previous minimum.",
          "Popping simply reveals the previous pair's minimum, so no second stack is needed. The stack is still written bottom first, top last.",
        ],
        problem: [
          "The pair stack uses one stack but wider cells — about the same total memory as two integer stacks. Reading a value and its minimum together is the appeal, at the cost of slightly more bookkeeping per cell.",
        ],
        code: {
          c: `#include <stdio.h>

#define CAP 200

typedef struct {
    int value;
    int min_so_far;
} Pair;

typedef struct {
    Pair items[CAP];
    int top;
} MinStack;

void init(MinStack *s) { s->top = 0; }

void push(MinStack *s, int x) {
    int m = x;
    if (s->top > 0 && s->items[s->top - 1].min_so_far < m)
        m = s->items[s->top - 1].min_so_far;
    s->items[s->top].value = x;
    s->items[s->top].min_so_far = m;
    s->top++;
}

void pop(MinStack *s) {
    if (s->top > 0) s->top--;
}

int peek(const MinStack *s) { return s->items[s->top - 1].value; }
int get_min(const MinStack *s) { return s->items[s->top - 1].min_so_far; }

int main(void) {
    MinStack s;
    init(&s);
    push(&s, 4); push(&s, 9); push(&s, 2);
    printf("%d\\n", get_min(&s));   /* 2 */
    pop(&s);
    printf("%d\\n", get_min(&s));   /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>

class MinStack {
    std::vector<std::pair<int, int>> items;   // value, min so far
public:
    void push(int x) {
        int m = items.empty() ? x : std::min(x, items.back().second);
        items.push_back({x, m});
    }
    void pop() {
        if (!items.empty()) items.pop_back();
    }
    int peek() const { return items.back().first; }
    int getMin() const { return items.back().second; }
};

int main() {
    MinStack s;
    s.push(4); s.push(9); s.push(2);
    std::cout << s.getMin() << '\\n';  // 2
    s.pop();
    std::cout << s.getMin() << '\\n';  // 4
}`,
        },
        steps(script) {
          return minStackSteps(script, "pairs");
        },
      },
    ],
  });

  /* ============================================================
     3. Implement Queue Using Stacks
     ============================================================ */
  function queueFromStacksSteps(script) {
    const toks = Array.isArray(script) ? script : [];
    const n = toks.length;
    const inS = [];
    const outS = [];
    const steps = [];
    const legend = ["read", "done", "result", "bad", "dim", "idle"];
    let done = 0;
    let pushes = 0;
    let transfers = 0;

    const inTrack = (topState) =>
      stackTrack("in stack", inS, topStates(inS.length, topState || "read"));
    const outTrack = (topState) =>
      stackTrack("out stack", outS, topStates(outS.length, topState || "read"));
    const counters = (extra) => [
      count("tokens read", done, n),
      count("pushes", pushes),
      count("in stack", inS.length),
      count("out stack", outS.length),
      ...(extra || []),
    ];

    steps.push({
      title: "Two stacks, one in and one out",
      tracks: [inTrack(), outTrack()],
      counters: counters(),
      legend,
      happened: `The script has ${n} tokens. New values enter the in stack; departures use the out stack. Both are written bottom first, top last.`,
      why: "A stack reverses order, so moving every value from the in stack to the out stack turns youngest-on-top into oldest-on-top.",
      codeLine: 11,
    });

    let i = 0;
    while (i < n) {
      const raw = String(toks[i]);
      const op = raw.toLowerCase();

      if (op === "push" || op === "enqueue") {
        const argRaw = i + 1 < n ? String(toks[i + 1]) : null;
        if (argRaw == null || !WHOLE.test(argRaw)) {
          done = Math.min(n, i + (argRaw == null ? 1 : 2));
          steps.push({
            title: argRaw == null ? "Ignored push — no value follows it" : `Ignored push — "${argRaw}" is not a whole number`,
            tracks: [inTrack("done"), outTrack("done")],
            counters: counters(),
            legend,
            happened: "The instruction is incomplete, so nothing is added to the queue.",
            why: "The player announces malformed input and keeps the rest of the script usable.",
            codeLine: 12,
          });
          i += argRaw == null ? 1 : 2;
          continue;
        }
        const x = Number(argRaw);
        inS.push(x);
        pushes++;
        done = Math.min(n, i + 2);
        steps.push({
          title: `Enqueue ${x} → top of the in stack`,
          tracks: [inTrack("read"), outTrack("done")],
          counters: counters([count("back", x)]),
          legend,
          happened: `${x} is pushed onto the in stack. The out stack is untouched.`,
          why: "New arrivals always go on the in stack; no shuffling is needed until someone asks for the front.",
          codeLine: 12,
        });
        i += 2;
        continue;
      }

      if (op === "pop" || op === "dequeue" || op === "peek" || op === "front") {
        const isPop = op === "pop" || op === "dequeue";
        if (!inS.length && !outS.length) {
          done = Math.min(n, i + 1);
          steps.push({
            title: isPop ? "Dequeue skipped — the queue is empty" : "Front skipped — the queue is empty",
            tracks: [inTrack(), outTrack()],
            counters: counters([count("answer", "empty")]),
            legend,
            happened: "There is nothing in either stack, so the queue has no front to show or remove.",
            why: "Empty is a valid state; the visualisation reports it instead of crashing.",
            codeLine: isPop ? 21 : 14,
          });
          i += 1;
          continue;
        }

        if (!outS.length) {
          while (inS.length) {
            const v = inS.pop();
            outS.push(v);
            transfers++;
            steps.push({
              title: `Move ${v} from the in stack to the out stack`,
              tracks: [inTrack("read"), outTrack("read")],
              counters: counters(),
              legend,
              happened: `${v} leaves the top of the in stack and becomes the top of the out stack.`,
              why: "Each move reverses one more element; after all moves the oldest value sits on top.",
              codeLine: 16,
            });
          }
          steps.push({
            title: `Transfer complete — front is ${outS[outS.length - 1]}`,
            tracks: [inTrack("dim"), outTrack("result")],
            counters: counters(),
            legend,
            happened: "The in stack is empty and the out stack is ready, with the queue front on top. No value was ever pushed twice.",
            why: "Transferring only when the out stack runs dry is what keeps the total work linear over many operations.",
            codeLine: 17,
          });
        }

        const top = outS[outS.length - 1];
        if (isPop) {
          outS.pop();
          done = Math.min(n, i + 1);
          steps.push({
            title: `Dequeue → ${top}`,
            tracks: [inTrack("done"), outTrack("read")],
            counters: counters([count("answer", top)]),
            legend,
            happened: `${top} was the oldest value in the queue, so it is removed from the top of the out stack.`,
            why: "The out stack hands back values in exactly the order they arrived — first in, first out.",
            codeLine: 21,
          });
        } else {
          done = Math.min(n, i + 1);
          steps.push({
            title: `Front → ${top}`,
            tracks: [inTrack("done"), outTrack("read")],
            counters: counters([count("answer", top)]),
            legend,
            happened: `${top} sits on top of the out stack and is the queue's front value.`,
            why: "Peeking does not move anything; the reversed out stack already exposes the oldest value.",
            codeLine: 14,
          });
        }
        i += 1;
        continue;
      }

      done = Math.min(n, i + 1);
      steps.push({
        title: `Ignored "${raw}" — not a queue operation`,
        tracks: [inTrack("done"), outTrack("done")],
        counters: counters(),
        legend,
        happened: `The token "${raw}" is not push, pop, peek or front, so it is skipped.`,
        why: "Unknown instructions are reported kindly so one typo does not ruin the whole demonstration.",
        codeLine: 11,
      });
      i += 1;
    }

    const empty = !inS.length && !outS.length;
    const front = empty ? null : outS.length ? outS[outS.length - 1] : inS[0];
    const inStates = inS.map((_, k) => (!outS.length && k === 0 ? "result" : "dim"));
    const outStates = outS.map((_, k) => (k === outS.length - 1 ? "result" : "dim"));
    steps.push({
      title: empty ? "Answer: the queue is empty" : `Answer: front is ${front}`,
      tracks: [
        stackTrack("in stack", inS, inStates),
        stackTrack("out stack", outS, outStates),
      ],
      counters: [count("tokens read", n, n), count("pushes", pushes), count("transfers", transfers), count("answer", empty ? "empty" : front)],
      legend,
      happened: empty
        ? "Every token has been handled and both stacks are empty."
        : `The script is finished; the oldest surviving value is ${front}.`,
      why: "If the out stack is empty, the bottom of the in stack is still the oldest value — no extra transfer is needed just to answer.",
      codeLine: 14,
    });
    return steps;
  }

  V.register({
    id: "implement-queue-using-stacks",
    title: "Implement Queue Using Stacks",
    category: "Stacks & Queues",
    difficulty: "Intermediate",
    description: "Build first-in-first-out behaviour from two last-in-first-out stacks.",
    input: { label: "Operation script", default: "push 1 push 2 push 3 peek pop push 4 peek", parse: "tokens" },
    approaches: [
      {
        name: "Lazy Transfer",
        complexity: "O(1) amortized per operation, O(n) space",
        idea: [
          "Keep an in stack for new arrivals and an out stack for departures. push always goes onto the in stack. When a pop or peek is needed and the out stack is empty, move every element from the in stack to the out stack one by one — the reversal puts the oldest element on top.",
          "Both stacks are written bottom first, top last. The queue front is the top of the out stack; while the out stack is empty, it is the bottom of the in stack.",
        ],
        problem: [
          "One pop can be expensive if a large transfer is waiting. Across a long sequence, though, each value moves from in to out at most once, so the total work is linear and the average per operation is constant.",
        ],
        code: {
          c: `#include <stdio.h>

#define CAP 200

typedef struct { int data[CAP]; int top; } Stack;

void push(Stack *s, int x) { s->data[s->top++] = x; }
int pop(Stack *s) { return s->data[--s->top]; }

typedef struct { Stack in, out; } MyQueue;

void init(MyQueue *q) { q->in.top = 0; q->out.top = 0; }
void enqueue(MyQueue *q, int x) { push(&q->in, x); }

int front(MyQueue *q) {
    if (q->out.top == 0)
        while (q->in.top > 0)
            push(&q->out, pop(&q->in));    /* reverse once */
    return q->out.data[q->out.top - 1];
}

int dequeue(MyQueue *q) { front(q); return pop(&q->out); }

int main(void) {
    MyQueue q;
    init(&q);
    enqueue(&q, 1); enqueue(&q, 2); enqueue(&q, 3);
    printf("%d\\n", front(&q));    /* 1 */
    printf("%d\\n", dequeue(&q));  /* 1 */
    enqueue(&q, 4);
    printf("%d\\n", dequeue(&q));  /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <stack>

class MyQueue {
    std::stack<int> in, out;
    void refill() {
        if (out.empty())
            while (!in.empty()) {
                out.push(in.top());
                in.pop();
            }
    }
public:
    void push(int x) { in.push(x); }
    int front() { refill(); return out.top(); }
    int pop() {
        refill();
        int v = out.top();
        out.pop();
        return v;
    }
    bool empty() const { return in.empty() && out.empty(); }
};

int main() {
    MyQueue q;
    q.push(1); q.push(2); q.push(3);
    std::cout << q.front() << '\\n';  // 1
    std::cout << q.pop() << '\\n';    // 1
    q.push(4);
    std::cout << q.pop() << '\\n';    // 2
}`,
        },
        steps(script) {
          return queueFromStacksSteps(script);
        },
      },
    ],
  });

  /* ============================================================
     4. Implement Stack Using Queues
     ============================================================ */
  function stackFromQueuesSteps(script) {
    const toks = Array.isArray(script) ? script : [];
    const n = toks.length;
    let q1 = [];
    let q2 = [];
    const steps = [];
    const legend = ["read", "done", "result", "bad", "dim", "idle"];
    let done = 0;
    let pushes = 0;

    const q1Track = (frontState) =>
      queueTrack("queue 1", q1, q1.map((_, k) => (k === 0 ? frontState : "done")));
    const q2Track = (backState) =>
      queueTrack("queue 2", q2, q2.map((_, k) => (k === q2.length - 1 ? backState : "done")));
    const counters = (extra) => [
      count("tokens read", done, n),
      count("pushes", pushes),
      count("queue 1", q1.length),
      count("queue 2", q2.length),
      ...(extra || []),
    ];

    steps.push({
      title: "Two queues, top lives at the front",
      tracks: [q1Track("done"), q2Track("done")],
      counters: counters(),
      legend,
      happened: `The script has ${n} tokens. queue 1 will hold the stack with its top at the front; queue 2 is the empty helper. Queues are written front first, back last.`,
      why: "A queue removes the oldest value, so reversing a queue is exactly how a new value can be promoted to the front.",
      codeLine: 12,
    });

    let i = 0;
    while (i < n) {
      const raw = String(toks[i]);
      const op = raw.toLowerCase();

      if (op === "push") {
        const argRaw = i + 1 < n ? String(toks[i + 1]) : null;
        if (argRaw == null || !WHOLE.test(argRaw)) {
          done = Math.min(n, i + (argRaw == null ? 1 : 2));
          steps.push({
            title: argRaw == null ? "Ignored push — no value follows it" : `Ignored push — "${argRaw}" is not a whole number`,
            tracks: [q1Track("done"), q2Track("done")],
            counters: counters(),
            legend,
            happened: "The instruction is incomplete, so the stack is unchanged.",
            why: "Malformed tokens are reported instead of crashing the demonstration.",
            codeLine: 17,
          });
          i += argRaw == null ? 1 : 2;
          continue;
        }
        const x = Number(argRaw);

        q2.push(x);
        steps.push({
          title: `Place ${x} in queue 2`,
          tracks: [q1Track("done"), q2Track("read")],
          counters: counters(),
          legend,
          happened: `${x} goes to the back of the empty helper queue. It will become the stack top.`,
          why: "The new value must end up in front of everything older, so it starts alone on the other queue.",
          codeLine: 18,
        });

        while (q1.length) {
          const v = q1.shift();
          q2.push(v);
          steps.push({
            title: `Move ${v} from queue 1 to queue 2`,
            tracks: [q1Track("read"), q2Track("read")],
            counters: counters(),
            legend,
            happened: `${v} leaves the front of queue 1 and joins the back of queue 2, behind ${x}.`,
            why: "Draining the old stack behind the newcomer preserves the older-to-newer order behind the new top.",
            codeLine: 19,
          });
        }

        const t = q1;
        q1 = q2;
        q2 = t;
        pushes++;
        done = Math.min(n, i + 2);
        steps.push({
          title: `Swap roles → top is ${q1[0]}`,
          tracks: [q1Track("read"), q2Track("done")],
          counters: counters([count("top", q1[0])]),
          legend,
          happened: "The queues trade names: queue 1 now holds the stack, and the empty queue becomes queue 2.",
          why: "Swapping two references is free; only the values had to move, and each one moved once.",
          codeLine: 21,
        });
        i += 2;
        continue;
      }

      if (op === "pop" || op === "peek" || op === "top" || op === "empty" || op === "size") {
        done = Math.min(n, i + 1);
        if (op === "pop") {
          if (!q1.length) {
            steps.push({
              title: "Pop skipped — the stack is empty",
              tracks: [q1Track("done"), q2Track("done")],
              counters: counters([count("answer", "empty")]),
              legend,
              happened: "queue 1 has no front, so there is no top value to remove.",
              why: "Empty input is handled as a normal outcome rather than an error.",
              codeLine: 26,
            });
          } else {
            const v = q1.shift();
            steps.push({
              title: `Pop → ${v}`,
              tracks: [q1Track("read"), q2Track("done")],
              counters: counters([count("answer", v)]),
              legend,
              happened: `${v} was at the front of queue 1, which is the top of the stack, and is removed.`,
              why: "After the push rotation, the front of queue 1 is always the most recently pushed value.",
              codeLine: 26,
            });
          }
        } else if (op === "peek" || op === "top") {
          if (!q1.length) {
            steps.push({
              title: "Peek skipped — the stack is empty",
              tracks: [q1Track("done"), q2Track("done")],
              counters: counters([count("answer", "empty")]),
              legend,
              happened: "There is no front value to read.",
              why: "The empty case must be named, not hidden.",
              codeLine: 27,
            });
          } else {
            steps.push({
              title: `Peek → ${q1[0]}`,
              tracks: [q1Track("read"), q2Track("done")],
              counters: counters([count("answer", q1[0])]),
              legend,
              happened: `${q1[0]} sits at the front of queue 1, so it is the stack top.`,
              why: "Peeking is cheap: no rotation is needed because the push step already put the top at the front.",
              codeLine: 27,
            });
          }
        } else if (op === "empty") {
          steps.push({
            title: `Empty? → ${q1.length ? "no" : "yes"}`,
            tracks: [q1Track("done"), q2Track("done")],
            counters: counters([count("answer", q1.length ? "no" : "yes")]),
            legend,
            happened: q1.length ? `queue 1 still holds ${q1.length} values.` : "queue 1 holds nothing.",
            why: "Only queue 1 ever carries values between operations, so its length decides emptiness.",
            codeLine: 12,
          });
        } else {
          steps.push({
            title: `Size → ${q1.length}`,
            tracks: [q1Track("done"), q2Track("done")],
            counters: counters([count("answer", q1.length)]),
            legend,
            happened: `The stack contains ${q1.length} values.`,
            why: "The size is the length of queue 1; queue 2 is empty between operations.",
            codeLine: 12,
          });
        }
        i += 1;
        continue;
      }

      done = Math.min(n, i + 1);
      steps.push({
        title: `Ignored "${raw}" — not a stack operation`,
        tracks: [q1Track("done"), q2Track("done")],
        counters: counters(),
        legend,
        happened: `The token "${raw}" is not push, pop, peek, empty or size, so it is skipped.`,
        why: "The script stays playable even when one token is a typo.",
        codeLine: 17,
      });
      i += 1;
    }

    const empty = q1.length === 0;
    const top = empty ? null : q1[0];
    steps.push({
      title: empty ? "Answer: the stack is empty" : `Answer: top is ${top}`,
      tracks: [
        queueTrack("queue 1", q1, q1.map((_, k) => (k === 0 ? "result" : "dim"))),
        queueTrack("queue 2", q2, q2.map(() => "dim")),
      ],
      counters: [count("tokens read", n, n), count("pushes", pushes), count("answer", empty ? "empty" : top)],
      legend,
      happened: empty
        ? "Every token has been handled and queue 1 is empty."
        : `The script is finished; ${top} is the most recently pushed value and sits at the front of queue 1.`,
      why: "The rotations paid off on every push: pop and peek only ever had to look at the front of queue 1.",
      codeLine: 27,
    });
    return steps;
  }

  V.register({
    id: "implement-stack-using-queues",
    title: "Implement Stack Using Queues",
    category: "Stacks & Queues",
    difficulty: "Intermediate",
    description: "Build last-in-first-out behaviour from two first-in-first-out queues.",
    input: { label: "Operation script", default: "push 1 push 2 peek pop push 3 peek", parse: "tokens" },
    approaches: [
      {
        name: "Rotate on Push",
        complexity: "O(n) per push, O(1) per pop, O(n) space",
        idea: [
          "queue 1 always holds the stack with its top at the front. To push x, place x alone in the empty queue 2, move every value from queue 1 behind it, and then swap the two queues' roles. The newest value is now at the front.",
          "Queues are written front first, back last. peek and pop simply take the front of queue 1; no rearrangement is needed for them.",
        ],
        problem: [
          "A push costs O(n) moves because the entire queue is shifted behind the new value. Pops are cheap, so this trade is attractive only when pushes are rare compared with reads.",
        ],
        code: {
          c: `#include <stdio.h>

#define CAP 200

typedef struct { int data[CAP]; int head, tail; } Queue;

void enqueue(Queue *q, int x) { q->data[q->tail++] = x; }
int dequeue(Queue *q) { return q->data[q->head++]; }
int qsize(const Queue *q) { return q->tail - q->head; }

typedef struct { Queue first, second; } MyStack;

void init(MyStack *s) {
    s->first.head = s->first.tail = 0;
    s->second.head = s->second.tail = 0;
}

void push(MyStack *s, int x) {
    enqueue(&s->second, x);
    while (qsize(&s->first) > 0)
        enqueue(&s->second, dequeue(&s->first));
    Queue t = s->first;          /* swap the queues */
    s->first = s->second;
    s->second = t;
}

int pop(MyStack *s) { return dequeue(&s->first); }
int top(const MyStack *s) { return s->first.data[s->first.head]; }

int main(void) {
    MyStack s;
    init(&s);
    push(&s, 1); push(&s, 2); push(&s, 3);
    printf("%d\\n", top(&s));    /* 3 */
    printf("%d\\n", pop(&s));    /* 3 */
    printf("%d\\n", top(&s));    /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <queue>

class MyStack {
    std::queue<int> q1, q2;
public:
    void push(int x) {
        q2.push(x);
        while (!q1.empty()) {
            q2.push(q1.front());
            q1.pop();
        }
        std::swap(q1, q2);        // q1 is the stack again
    }
    int pop() {
        int v = q1.front();
        q1.pop();
        return v;
    }
    int top() const { return q1.front(); }
    bool empty() const { return q1.empty(); }
};

int main() {
    MyStack s;
    s.push(1); s.push(2); s.push(3);
    std::cout << s.top() << '\\n';  // 3
    std::cout << s.pop() << '\\n';  // 3
    std::cout << s.top() << '\\n';  // 2
}`,
        },
        steps(script) {
          return stackFromQueuesSteps(script);
        },
      },
    ],
  });

  /* ============================================================
     5. Evaluate Reverse Polish Notation
     ============================================================ */
  function rpnSteps(tokens) {
    const toks = Array.isArray(tokens) ? tokens : [];
    const n = toks.length;
    const stack = [];
    const steps = [];
    const legend = ["read", "done", "result", "compare", "bad", "dim", "idle"];
    let pushes = 0;
    let reads = 0;
    let operations = 0;

    const isOp = (t) => t === "+" || t === "-" || t === "*" || t === "/";
    const valueTrack = (topState, topTag) =>
      stackTrack(
        "value stack",
        stack,
        stack.map((_, k) => (k === stack.length - 1 ? topState || "read" : "done")),
        stack.map((_, k) => (k === stack.length - 1 ? topTag : undefined))
      );
    const counters = (extra) => [
      count("tokens read", reads, n),
      count("pushes", pushes),
      count("operations", operations),
      count("value stack", stack.length),
      ...(extra || []),
    ];

    steps.push({
      title: "Empty value stack, whole expression waiting",
      tracks: [stackTrack("value stack", stack, [])],
      counters: counters(),
      legend,
      happened: `There are ${n} tokens. A number will be pushed; an operator will consume the two most recent values. The stack is written bottom first, top last.`,
      why: "Reverse Polish notation puts every operator after its operands, so the stack already has exactly the two values an operator needs.",
      codeLine: 5,
    });

    for (let i = 0; i < n; i++) {
      const t = String(toks[i]);
      reads = i + 1;

      if (WHOLE.test(t)) {
        const x = Number(t);
        stack.push(x);
        pushes++;
        steps.push({
          title: `Push ${x}`,
          tracks: [valueTrack("read")],
          counters: counters(),
          legend,
          happened: `${t} is a number, so it becomes the new top of the value stack.`,
          why: "Operands wait on the stack until a later operator claims them.",
          codeLine: 10,
        });
        continue;
      }

      if (isOp(t)) {
        if (stack.length < 2) {
          steps.push({
            title: `Answer: invalid — "${t}" needs two operands`,
            tracks: [valueTrack("bad")],
            counters: counters([count("answer", "invalid")]),
            legend,
            happened: `The operator ${t} arrives, but the stack holds ${stack.length} value${stack.length === 1 ? "" : "s"}.`,
            why: "An operator must have two operands; guessing the missing one would produce a meaningless answer.",
            codeLine: 14,
          });
          return steps;
        }
        const b = stack.pop();
        const a = stack.pop();
        if (t === "/" && b === 0) {
          steps.push({
            title: "Answer: invalid — division by zero",
            tracks: [valueTrack("bad")],
            counters: counters([count("answer", "invalid")]),
            legend,
            happened: `${a} is divided by ${b}, which has no defined integer result.`,
            why: "Integer division by zero is undefined, so the evaluator must refuse rather than invent a value.",
            codeLine: 22,
          });
          return steps;
        }
        const r = t === "+" ? a + b : t === "-" ? a - b : t === "*" ? a * b : Math.trunc(a / b);
        stack.push(r);
        operations++;
        steps.push({
          title: `${a} ${t} ${b} = ${r} → push ${r}`,
          tracks: [valueTrack("read", `${a} ${t} ${b}`)],
          counters: counters(),
          legend,
          happened: `The top two values ${b} and ${a} are taken; ${a} ${t} ${b} becomes ${r}, which is pushed back.`,
          why: "Replacing two operands with one result keeps the stack ready for the next operator.",
          codeLine: 15,
        });
        continue;
      }

      steps.push({
        title: `Ignored "${t}" — not a number or operator`,
        tracks: [valueTrack("done")],
        counters: counters(),
        legend,
        happened: `The token "${t}" has no meaning here, so the stack is left alone.`,
        why: "An unknown token is reported clearly; the evaluator refuses to treat it as zero.",
        codeLine: 4,
      });
    }

    if (stack.length === 1) {
      steps.push({
        title: `Answer: ${stack[0]}`,
        tracks: [stackTrack("value stack", stack, ["result"], ["answer"])],
        counters: [count("tokens read", n, n), count("operations", operations), count("answer", stack[0])],
        legend,
        happened: `Every token was consumed and exactly one value remains: ${stack[0]}.`,
        why: "A well-formed RPN expression always collapses to a single value on the stack.",
        codeLine: 28,
      });
      return steps;
    }

    steps.push({
      title: stack.length === 0
        ? "Answer: invalid — no value left"
        : `Answer: invalid — ${stack.length} values left on the stack`,
      tracks: [valueTrack("bad")],
      counters: [count("tokens read", n, n), count("operations", operations), count("answer", "invalid")],
      legend,
      happened: stack.length === 0
        ? "The tokens ran out without producing a value."
        : `The tokens ran out while ${stack.length} separate values were still waiting.`,
      why: "More than one surviving value means the expression never combined into a single result.",
      codeLine: 28,
    });
    return steps;
  }

  V.register({
    id: "evaluate-reverse-polish-notation",
    title: "Evaluate Reverse Polish Notation",
    category: "Stacks & Queues",
    difficulty: "Intermediate",
    description: "Evaluate a postfix expression by pushing numbers and letting operators fold the top two values.",
    input: { label: "RPN tokens", default: "4 13 5 / + 2 * 7 -", parse: "tokens" },
    approaches: [
      {
        name: "Push Numbers, Fold Operators",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Read tokens left to right. A number is pushed onto the value stack. An operator pops the top two values, applies itself, and pushes the single result back.",
          "The stack is written bottom first, top last — the rightmost cell is the current top. Because every operator consumes the two most recent values, brackets are never needed.",
        ],
        problem: [
          "The expression must be well formed: too few operands, an unknown token, division by zero, or a leftover value all make it invalid. The scan is linear, but the stack can grow to the length of the input.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/* Evaluate integer RPN; false means malformed. */
bool eval(const char **tok, int n, int *answer) {
    int stack[200], top = 0;
    for (int i = 0; i < n; i++) {
        char *end;
        long v = strtol(tok[i], &end, 10);
        if (end != tok[i] && *end == '\\0') {
            stack[top++] = (int)v;
            continue;
        }
        if (top < 2) return false;
        int b = stack[--top];
        int a = stack[--top];
        switch (tok[i][0]) {
        case '+': stack[top++] = a + b; break;
        case '-': stack[top++] = a - b; break;
        case '*': stack[top++] = a * b; break;
        case '/':
            if (b == 0) return false;
            stack[top++] = a / b;
            break;
        default: return false;
        }
    }
    if (top != 1) return false;
    *answer = stack[0];
    return true;
}

int main(void) {
    const char *tokens[] = {"4", "13", "5", "/", "+", "2", "*", "7", "-"};
    int answer;
    if (eval(tokens, 9, &answer))
        printf("%d\\n", answer);   /* 5 */
    else
        printf("invalid\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>

bool evalRpn(const std::vector<std::string>& tokens, int& answer) {
    std::vector<int> stack;
    for (const std::string& t : tokens) {
        char* end = nullptr;
        long v = std::strtol(t.c_str(), &end, 10);
        if (end != t.c_str() && *end == '\\0') {
            stack.push_back((int)v);
            continue;
        }
        if (stack.size() < 2) return false;
        int b = stack.back(); stack.pop_back();
        int a = stack.back(); stack.pop_back();
        char op = t.empty() ? '?' : t[0];
        if (op == '+') stack.push_back(a + b);
        else if (op == '-') stack.push_back(a - b);
        else if (op == '*') stack.push_back(a * b);
        else if (op == '/' && b != 0) stack.push_back(a / b);
        else return false;
    }
    if (stack.size() != 1) return false;
    answer = stack[0];
    return true;
}

int main() {
    std::vector<std::string> tokens{"4", "13", "5", "/", "+", "2", "*", "7", "-"};
    int answer = 0;
    if (evalRpn(tokens, answer)) std::cout << answer << '\\n';  // 5
    else std::cout << "invalid\\n";
}`,
        },
        steps(tokens) {
          return rpnSteps(tokens);
        },
      },
    ],
  });

  /* ============================================================
     6. Basic Calculator
     ============================================================ */
  V.register({
    id: "basic-calculator",
    title: "Basic Calculator",
    category: "Stacks & Queues",
    difficulty: "Intermediate",
    description: "Evaluate +, -, * and / with brackets using an operand stack and an operator stack.",
    input: { label: "Expression", default: "(1 + (2 * 3) - 4)", parse: "string" },
    approaches: [
      {
        name: "Two Stacks with Precedence",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Two stacks do the work: one for operands (numbers) and one for operators. Numbers are pushed as they are read. An operator is pushed only after every waiting operator that binds at least as tightly has been applied; a closing bracket forces everything back to its opening bracket to run.",
          "Both stacks are written bottom first, top last. Brackets sit only on the operator stack — they mark where a burst of applications must stop, then are discarded.",
        ],
        problem: [
          "The precedence table and the bracket handling are easy to get subtly wrong. Unary minus and multi-digit numbers need extra care because the input arrives as a character stream, and malformed brackets must end in an honest refusal.",
        ],
        code: {
          c: `#include <stdio.h>
#include <ctype.h>

#define CAP 200

/* higher number = binds tighter */
int prec(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}

/* apply the top operator to the top two operands */
int apply(int *nums, int *ntop, char *ops, int *otop, int *ok) {
    if (*ntop < 2 || *otop < 1) { *ok = 0; return 0; }
    int b = nums[*ntop - 1]; (*ntop)--;
    int a = nums[*ntop - 1]; (*ntop)--;
    char op = ops[*otop - 1]; (*otop)--;
    if (op == '/' && b == 0) { *ok = 0; return 0; }
    int r = 0;
    if (op == '+') r = a + b;
    else if (op == '-') r = a - b;
    else if (op == '*') r = a * b;
    else r = a / b;
    nums[(*ntop)++] = r;
    return r;
}

int evaluate(const char *s, int *ok) {
    int nums[CAP], ntop = 0;
    char ops[CAP], otop = 0;
    *ok = 1;
    for (int i = 0; s[i] != '\\0'; ) {
        char c = s[i];
        if (c == ' ') { i++; continue; }
        if (isdigit((unsigned char)c)) {
            int v = 0;
            while (isdigit((unsigned char)s[i]))
                v = v * 10 + (s[i++] - '0');
            nums[ntop++] = v;
        } else if (c == '(') {
            ops[otop++] = c; i++;
        } else if (c == ')') {
            while (otop > 0 && ops[otop - 1] != '(' && *ok)
                apply(nums, &ntop, ops, &otop, ok);
            if (otop == 0) { *ok = 0; return 0; }
            otop--; i++;                  /* drop '(' */
        } else {
            while (otop > 0 && ops[otop - 1] != '(' &&
                   prec(ops[otop - 1]) >= prec(c) && *ok)
                apply(nums, &ntop, ops, &otop, ok);
            ops[otop++] = c; i++;
        }
    }
    while (otop > 0 && *ok) {
        if (ops[otop - 1] == '(') { *ok = 0; return 0; }
        apply(nums, &ntop, ops, &otop, ok);
    }
    if (!*ok || ntop != 1) { *ok = 0; return 0; }
    return nums[0];
}

int main(void) {
    int ok;
    printf("%d\\n", evaluate("(1 + (2 * 3) - 4)", &ok)); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
#include <cctype>

int prec(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}

int main() {
    std::string s = "(1 + (2 * 3) - 4)";
    std::vector<int> nums;
    std::vector<char> ops;
    bool ok = true;

    auto apply = [&]() {
        if (nums.size() < 2 || ops.empty()) { ok = false; return; }
        int b = nums.back(); nums.pop_back();
        int a = nums.back(); nums.pop_back();
        char op = ops.back(); ops.pop_back();
        if (op == '/' && b == 0) { ok = false; return; }
        if (op == '+') nums.push_back(a + b);
        else if (op == '-') nums.push_back(a - b);
        else if (op == '*') nums.push_back(a * b);
        else nums.push_back(a / b);
    };

    for (size_t i = 0; i < s.size() && ok; ) {
        char c = s[i];
        if (c == ' ') { ++i; continue; }
        if (std::isdigit((unsigned char)c)) {
            int v = 0;
            while (i < s.size() && std::isdigit((unsigned char)s[i]))
                v = v * 10 + (s[i++] - '0');
            nums.push_back(v);
        } else if (c == '(') {
            ops.push_back(c); ++i;
        } else if (c == ')') {
            while (!ops.empty() && ops.back() != '(' && ok) apply();
            if (ops.empty() || ops.back() != '(') { ok = false; break; }
            ops.pop_back(); ++i;
        } else {
            while (!ops.empty() && ops.back() != '(' &&
                   prec(ops.back()) >= prec(c) && ok)
                apply();
            ops.push_back(c); ++i;
        }
    }
    while (!ops.empty() && ok) {
        if (ops.back() == '(') { ok = false; break; }
        apply();
    }
    if (ok && nums.size() == 1) std::cout << nums[0] << '\\n';  // 3
    else std::cout << "invalid\\n";
}`,
        },
        steps(text) {
          const chars = [...String(text)];
          const n = chars.length;
          const shown = chars.map((c) => (c === " " ? "␠" : c));
          const states = fill(n, "idle");
          const nums = [];
          const ops = [];
          const steps = [];
          const legend = ["read", "done", "good", "result", "bad", "dim", "idle"];
          let done = 0;
          let ok = true;
          let fail = null;
          let prevOperand = false;

          const prec = (op) => (op === "+" || op === "-" ? 1 : op === "*" || op === "/" ? 2 : 0);
          const exprTrack = () => track("expression", shown, states);
          const numTrack = (topState, tags) => {
            const st = nums.map((_, k) => (k === nums.length - 1 ? (topState || "read") : "done"));
            return stackTrack("operand stack", nums, st, tags);
          };
          const opTrack = (topState) => {
            const st = ops.map((_, k) => (k === ops.length - 1 ? (topState || "read") : "done"));
            return stackTrack("operator stack", ops, st);
          };
          const counters = (extra) => [
            count("characters read", done, n),
            count("operand stack", nums.length),
            count("operator stack", ops.length),
            ...(extra || []),
          ];

          const applyOne = (at, whyText) => {
            if (nums.length < 2 || !ops.length) {
              ok = false;
              fail = "an operator ran out of operands";
              return false;
            }
            const b = nums[nums.length - 1];
            const a = nums[nums.length - 2];
            const op = ops[ops.length - 1];
            if (op === "/" && b === 0) {
              ok = false;
              fail = "division by zero";
              return false;
            }
            nums.length -= 2;
            ops.pop();
            const r = op === "+" ? a + b : op === "-" ? a - b : op === "*" ? a * b : Math.trunc(a / b);
            nums.push(r);
            const tags = nums.map((_, k) => (k === nums.length - 1 ? `${a} ${op} ${b}` : undefined));
            steps.push({
              title: `${a} ${op} ${b} = ${r} → push ${r}`,
              tracks: [exprTrack(), numTrack("read", tags), opTrack("done")],
              counters: counters(),
              legend,
              happened: `The top operator ${op} takes ${a} and ${b} down; the single result ${r} goes back on the operand stack.`,
              why: whyText || "An operator can run as soon as the operators still waiting bind less tightly than it does.",
              codeLine: 14,
            });
            return true;
          };

          steps.push({
            title: "Two stacks: numbers and waiting operators",
            tracks: [exprTrack(), numTrack("done"), opTrack("done")],
            counters: counters(),
            legend,
            happened: `The expression "${String(text)}" will be read left to right. Both stacks are written bottom first, top last.`,
            why: "Numbers wait on the operand stack; operators wait on the operator stack until precedence or a closing bracket says it is their turn.",
            codeLine: 30,
          });

          steps.push({
            title: "Rule: * and / run before + and -",
            tracks: [exprTrack(), numTrack("done"), opTrack("done")],
            counters: counters(),
            legend,
            happened: "Multiplication and division bind tighter than addition and subtraction. A closing bracket makes every operator back to its opening bracket run first.",
            why: "Following this rule reproduces the usual order of arithmetic without ever building an expression tree.",
            codeLine: 6,
          });

          for (let i = 0; i < n && ok; ) {
            const c = chars[i];

            if (c === " ") {
              states[i] = "done";
              done = i + 1;
              i++;
              continue;
            }

            if (c >= "0" && c <= "9") {
              let j = i;
              let value = 0;
              while (j < n && chars[j] >= "0" && chars[j] <= "9") {
                value = value * 10 + (chars[j].charCodeAt(0) - 48);
                states[j] = "done";
                j++;
              }
              states[j - 1] = "read";
              nums.push(value);
              done = j;
              prevOperand = true;
              steps.push({
                title: `Read ${value} → push operand`,
                tracks: [exprTrack(), numTrack("read"), opTrack("done")],
                counters: counters(),
                legend,
                happened: `The digits form the number ${value}, which becomes the new top of the operand stack.`,
                why: "Operands can be pushed immediately; they will wait until an operator claims them.",
                codeLine: 35,
              });
              i = j;
              continue;
            }

            if (c === "(") {
              ops.push(c);
              states[i] = "read";
              done = i + 1;
              prevOperand = false;
              steps.push({
                title: "Open bracket → push (",
                tracks: [exprTrack(), numTrack("done"), opTrack("read")],
                counters: counters(),
                legend,
                happened: "The opening bracket is parked on the operator stack as a boundary marker.",
                why: "Nothing hidden inside the brackets may escape until that marker is reached.",
                codeLine: 41,
              });
              i++;
              continue;
            }

            if (c === ")") {
              states[i] = "read";
              done = i + 1;
              while (ok && ops.length && ops[ops.length - 1] !== "(") {
                applyOne(i, "The closing bracket forces every operator opened inside it to run before the bracket is discarded.");
              }
              if (ok) {
                if (!ops.length || ops[ops.length - 1] !== "(") {
                  ok = false;
                  fail = "a closing bracket has no matching opening bracket";
                } else {
                  ops.pop();
                  steps.push({
                    title: "Closing bracket → discard the matching (",
                    tracks: [exprTrack(), numTrack("done"), opTrack("done")],
                    counters: counters(),
                    legend,
                    happened: "Everything inside the brackets is reduced to one number; the boundary marker is popped.",
                    why: "The bracket has done its job, so it must not stay between later operators.",
                    codeLine: 46,
                  });
                }
              }
              prevOperand = true;
              i++;
              continue;
            }

            if (c !== "+" && c !== "-" && c !== "*" && c !== "/") {
              states[i] = "bad";
              done = i + 1;
              steps.push({
                title: `Ignored "${c}" — not part of a number or operator`,
                tracks: [exprTrack(), numTrack("done"), opTrack("done")],
                counters: counters(),
                legend,
                happened: `The character "${c}" has no arithmetic meaning here, so both stacks stay as they were.`,
                why: "The calculator announces what it skipped rather than silently pretending the character was not typed.",
                codeLine: 34,
              });
              states[i] = "dim";
              i++;
              continue;
            }

            if (!prevOperand && (c === "-" || c === "+")) {
              let j = i + 1;
              while (j < n && chars[j] === " ") j++;
              if (j < n && chars[j] >= "0" && chars[j] <= "9") {
                let value = 0;
                while (j < n && chars[j] >= "0" && chars[j] <= "9") {
                  value = value * 10 + (chars[j].charCodeAt(0) - 48);
                  states[j] = "done";
                  j++;
                }
                if (c === "-") value = -value;
                states[i] = "done";
                states[j - 1] = "read";
                nums.push(value);
                done = j;
                prevOperand = true;
                steps.push({
                  title: `Unary ${c} → push ${value}`,
                  tracks: [exprTrack(), numTrack("read"), opTrack("done")],
                  counters: counters(),
                  legend,
                  happened: `A sign directly before a number belongs to the number, so ${value} is pushed as one operand.`,
                  why: "Treating the sign as part of the number avoids an operator with only one operand.",
                  codeLine: 35,
                });
                i = j;
                continue;
              }
              nums.push(0);
              states[i] = "read";
              steps.push({
                title: `Unary ${c} before a bracket → push 0`,
                tracks: [exprTrack(), numTrack("read"), opTrack("done")],
                counters: counters(),
                legend,
                happened: `There is no number directly after the ${c}, so an implicit 0 is pushed. The sign then behaves like a normal binary operator.`,
                why: "Zero minus the bracketed value computes the negation while keeping the two-stack rules unchanged.",
                codeLine: 35,
              });
            }

            states[i] = "read";
            done = i + 1;
            while (ok && ops.length && ops[ops.length - 1] !== "(" && prec(ops[ops.length - 1]) >= prec(c)) {
              applyOne(i, `${ops[ops.length - 1]} binds at least as tightly as ${c}, so it runs before ${c} is pushed.`);
            }
            if (ok) {
              ops.push(c);
              steps.push({
                title: `Push operator ${c}`,
                tracks: [exprTrack(), numTrack("done"), opTrack("read")],
                counters: counters(),
                legend,
                happened: `No waiting operator needs to run before ${c}, so ${c} is parked on the operator stack.`,
                why: "Delaying the operator is what lets a later tighter operator take the operands first.",
                codeLine: 47,
              });
              prevOperand = false;
            }
            i++;
          }

          while (ok && ops.length) {
            if (ops[ops.length - 1] === "(") {
              ok = false;
              fail = "an opening bracket was never closed";
              break;
            }
            applyOne(Math.max(0, n - 1), "The input is exhausted, so the remaining operators run from the top of the stack downwards.");
          }

          if (!ok || nums.length !== 1) {
            if (!fail) fail = "the stacks did not reduce to one number";
            const badAt = states.indexOf("bad");
            if (badAt >= 0) states[badAt] = "bad";
            steps.push({
              title: `Answer: invalid — ${fail}`,
              tracks: [exprTrack(), numTrack("dim"), opTrack("dim")],
              counters: [count("characters read", n, n), count("operand stack", nums.length), count("answer", "invalid")],
              legend,
              happened: `The walk stopped because ${fail}.`,
              why: "A calculator must refuse to guess: a malformed expression has no honest numeric answer.",
              codeLine: 58,
            });
            return steps;
          }

          states.fill("good");
          steps.push({
            title: `Answer: ${nums[0]}`,
            tracks: [
              exprTrack(),
              stackTrack("operand stack", nums, ["result"], ["answer"]),
              stackTrack("operator stack", [], []),
            ],
            counters: [count("characters read", n, n), count("answer", nums[0])],
            legend,
            happened: `Every number folded into one value: the operand stack holds ${nums[0]} and the operator stack is empty.`,
            why: "One operand and no operators is the settled state that proves the expression has been evaluated.",
            codeLine: 58,
          });
          return steps;
        },
      },
    ],
  });
})();
