/* ============================================================
   DSA Visuals — Recursion & Sorting
   Original module: factorial, fibonacci, pow(x,n), recursive
   string reversal, merge sort, quick sort. Follows SPEC.md:
   { id, title, category, difficulty, description,
     input: { label, default, parse },
     approaches: [ { name, complexity, idea, problem,
                     code: { c, cpp }, steps(parsed) } ] }
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  /* ---------------- shared helpers ---------------- */

  // "3, 9, 10, 27, …" — cap lists used inside step titles
  function brief(list, max) {
    max = max || 4;
    if (list.length <= max) return list.join(", ");
    return list.slice(0, max).join(", ") + ", …";
  }

  // readable numbers: integers plainly, floats rounded, infinities named
  function fmt(x) {
    if (Number.isNaN(x)) return "?";
    if (!Number.isFinite(x)) return x > 0 ? "∞" : "-∞";
    if (Number.isInteger(x) && Math.abs(x) < 1e15) return String(x);
    return String(Math.round(x * 1e6) / 1e6);
  }

  // BigInt → display string; huge values become "first digits… (D digits)"
  function bigStr(bi) {
    const s = bi.toString();
    return s.length <= 40 ? s : s.slice(0, 14) + "… (" + s.length + " digits)";
  }

  function capStr(s, k) {
    s = String(s);
    return s.length > k ? s.slice(0, k) + "…" : s;
  }

  function factBig(n) {          // n >= 0
    let f = 1n;
    for (let k = 2n; k <= n; k++) f *= k;
    return f;
  }

  function fibDouble(n) {        // plain doubles, fine up to ~n = 1400
    let a = 0, b = 1;
    for (let i = 0; i < n; i++) { const t = a + b; a = b; b = t; }
    return a;
  }

  function fibBig(n) {           // fast doubling, n >= 0 BigInt
    let a = 0n, b = 1n;
    const bits = n.toString(2);
    for (let p = bits.length - 1; p >= 0; p--) {
      const c = a * (2n * b - a);
      const d = a * a + b * b;
      a = bits[p] === "1" ? d : c;
      b = bits[p] === "1" ? c + d : d;
    }
    return a;
  }

  /* =========================================================== */
  V.register({
    id: "factorial",
    title: "Factorial",
    category: "Recursion",
    difficulty: "Beginner",
    description: "Build 1×2×…×n either with a loop or with calls that unwind.",
    input: { label: "n (shown in full up to 12)", default: "10", parse: "int" },
    approaches: [
      {
        name: "Loop: Accumulate the Product",
        complexity: "O(n) time, O(1) space",
        idea: [
          "n! is 1×2×3×…×n. Keep one accumulator starting at 1 and let a loop multiply k = 2, 3, …, n into it.",
          "After the loop the accumulator itself is the answer — no extra memory is needed.",
        ],
        problem: [
          "The loop is fast but hides the shape of the problem: there is no \"smaller factorial\" being reused. Also, factorials outgrow ordinary integers quickly — 20! already needs 64 bits, and beyond that you need big integers.",
        ],
        code: {
          c: `#include <stdio.h>

/* multiply 1, 2, ... n into one accumulator */
long long factorial(int n) {
    long long f = 1;
    for (int k = 2; k <= n; k++)
        f *= k;
    return f;
}

int main(void) {
    printf("%lld\\n", factorial(10)); /* 3628800 */
    return 0;
}`,
          cpp: `#include <iostream>

// same idea in C++: one accumulator, one loop
long long factorial(int n) {
    long long f = 1;
    for (int k = 2; k <= n; ++k)
        f *= k;
    return f;
}

int main() {
    std::cout << factorial(10) << '\\n'; // 3628800
}`,
        },
        steps(n) {
          const steps = [];
          const cell = (v, state, tag) => ({ v, state, tag });
          const tracks = (k, f, chain) => [
            { label: "multiplier k", cells: [cell(k, "read", "current k")] },
            { label: "accumulator f", cells: [cell(bigStr(f), "result", "running product")] },
            { label: "products written", cells: chain.length ? chain : [cell("—", "idle", "none yet")] },
          ];
          if (n < 0) {
            steps.push({
              title: `n = ${n} — factorials stop at zero`,
              tracks: [
                { label: "n", cells: [cell(n, "read", "input")] },
                { label: "n!", cells: [cell("undefined", "bad", "not defined below 0")] },
              ],
              counters: [count("n", n), count("multiplications", 0)],
              legend: ["read", "bad", "result", "idle"],
              happened: `The input is ${n}. Factorial is only defined for whole numbers 0 and above, so the loop never even starts.`,
              why: "n! counts arrangements of n items; a negative number of items is meaningless, so there is honestly no answer.",
              codeLine: 3,
            });
            steps.push({
              title: "Answer: undefined for negative n",
              tracks: [
                { label: "n", cells: [cell(n, "dim", "out of range")] },
                { label: "n!", cells: [cell("undefined", "bad", "no value")] },
              ],
              counters: [count("n", n), count("answer", "undefined")],
              legend: ["bad", "dim", "result", "idle"],
              happened: "No number can be produced — the smallest defined case is 0! = 1.",
              why: "Being honest about out-of-domain inputs is part of writing correct code: guard the negative case instead of looping forever.",
              codeLine: 5,
            });
            return steps;
          }
          if (n > 500) {
            steps.push({
              title: `n = ${n} is far beyond what this screen can draw`,
              tracks: [
                { label: "n", cells: [cell(n, "read", "input")] },
                { label: "accumulator f", cells: [cell("too large", "dim", "would freeze the page")] },
              ],
              counters: [count("n", n), count("multiplications", "millions")],
              legend: ["read", "dim", "result", "idle"],
              happened: `Multiplying up to ${n} would produce a number with millions of digits — showing it step by step (or even building it here) would freeze the page.`,
              why: "Real programs hit this too: factorials explode, which is why big-integer libraries and modular arithmetic exist.",
              codeLine: 6,
            });
            steps.push({
              title: "Answer: not shown — far too many digits",
              tracks: [
                { label: "n", cells: [cell(n, "dim", "out of range")] },
                { label: "n!", cells: [cell("enormous", "bad", "unreadable here")] },
              ],
              counters: [count("n", n), count("answer", "too large to print")],
              legend: ["dim", "bad", "result", "idle"],
              happened: `${n}! is a real number, but printing it would take more space than this page has.`,
              why: "The algorithm is unchanged; only the size of the answer stops us. Try n ≤ 500 to see the exact value.",
              codeLine: 7,
            });
            return steps;
          }
          const DRAW = 12; // one step per multiply only while it stays readable
          let f = 1n;
          const chain = [cell(1, "done", "seed")];
          steps.push({
            title: n === 0 ? "n = 0: nothing to multiply" : `${n}! means 1 × 2 × … × ${n}`,
            tracks: [
              { label: "multiplier k", cells: [cell(1, "read", "starts at 1")] },
              { label: "accumulator f", cells: [cell(1, "result", "seeded with 1")] },
              { label: "products written", cells: [cell(1, "done", "seed")] },
            ],
            counters: [count("multiplications left", n > 0 ? n - 1 : 0), count("product so far", 1)],
            legend: ["read", "done", "result", "idle"],
            happened: n === 0
              ? "n is 0, so the loop body never runs — the seeded accumulator already holds the answer."
              : `The accumulator starts at 1 (multiplying by 0 would erase everything) and k starts at 1.`,
            why: "1 is the identity of multiplication, so seeding with it keeps the product honest from the first step.",
            codeLine: 4,
          });
          const marks = new Set();
          const chunk = Math.ceil(n / 8);
          for (let c = chunk; c < n; c += chunk) marks.add(c);
          for (let k = 2; k <= n; k++) {
            const prev = f;
            f *= BigInt(k);
            if (n > DRAW && !marks.has(k) && k !== n) continue;
            chain.push({ v: bigStr(f), state: "read", tag: "× " + k });
            for (let t = 0; t < chain.length - 1; t++) chain[t].state = "done";
            steps.push({
              title: `Multiply by ${k} → f = ${bigStr(f)}`,
              tracks: tracks(k, f, chain.slice()),
              counters: [count("multiplications done", k, n), count("product so far", bigStr(f))],
              legend: ["read", "done", "result", "idle"],
              happened: `The accumulator swallows ${k}: ${bigStr(prev)} × ${k} = ${bigStr(f)}.`,
              why: n > DRAW
                ? "Same move every round — the loop keeps folding the next k in until it reaches n."
                : "Read k, multiply, advance — each number is absorbed exactly once in ascending order.",
              codeLine: 6,
            });
          }
          steps.push({
            title: `Answer: ${n}! = ${bigStr(f)}`,
            tracks: [
              { label: "multiplier k", cells: [cell(n, "dim", "loop finished")] },
              { label: "accumulator f", cells: [cell(bigStr(f), "result", "final")] },
            ],
            counters: [count("multiplications done", Math.max(n - 1, 0)), count("answer", bigStr(f))],
            legend: ["done", "dim", "result", "idle"],
            happened: `The loop reached k = ${n}; the accumulator holds ${bigStr(f)}.`,
            why: "Every factor from 2 to n was folded in exactly once — the single variable is the whole answer.",
            codeLine: 7,
          });
          return steps;
        },
      },
      {
        name: "Recursive Calls Unwinding",
        complexity: "O(n) time, O(n) call-stack space",
        idea: [
          "The definition itself is recursive: n! = n × (n-1)!, with 0! and 1! = 1 as the base case.",
          "Each call borrows the answer of a smaller factorial. The deepest call answers immediately, and every return multiplies its own n on the way back up.",
        ],
        problem: [
          "A chain of n frames sits on the call stack before any multiplying happens — O(n) space for a job a loop does in O(1). Very deep recursion can even overflow the stack.",
        ],
        code: {
          c: `#include <stdio.h>

/* base: 0! and 1! are 1; otherwise n * (n-1)! */
long long factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

int main(void) {
    printf("%lld\\n", factorial(10)); /* 3628800 */
    return 0;
}`,
          cpp: `#include <iostream>

// the definition, translated almost literally
long long factorial(int n) {
    if (n <= 1) return 1;              // base case
    return n * factorial(n - 1);       // smaller problem
}

int main() {
    std::cout << factorial(10) << '\\n'; // 3628800
}`,
        },
        steps(n) {
          const steps = [];
          const cell = (v, state, tag) => ({ v, state, tag });
          const stackCells = (frames, topState) => {
            if (!frames.length) return [cell("empty", "idle", "all returned")];
            const wrap = (arr, offset) =>
              arr.map((k, i) => {
                const isTop = offset + i === frames.length - 1;
                return cell(k, isTop ? (topState || "read") : "active", isTop ? "top" : "waiting");
              });
            if (frames.length <= 13) return wrap(frames, 0);
            return [
              ...wrap(frames.slice(0, 6), 0),
              cell("…", "idle", "more frames"),
              ...wrap(frames.slice(-5), frames.length - 5),
            ];
          };
          const stackTrack = (frames, topState) => ({
            label: "call stack: n per frame",
            dir: "col",
            cells: stackCells(frames, topState),
          });
          const resultTrack = (v, state, tag) => ({ label: "value returned", cells: [cell(v, state, tag)] });

          if (n < 0) {
            steps.push({
              title: `factorial(${n}) has no meaning`,
              tracks: [
                stackTrack([n], "read"),
                resultTrack("undefined", "bad", "not defined below 0"),
              ],
              counters: [count("depth", 1), count("answer", "undefined")],
              legend: ["read", "active", "bad", "idle"],
              happened: `The input is ${n}; the very first call already has nothing to compute — factorials start at 0.`,
              why: "A recursive function is only as good as its domain: guard negative inputs before recursing.",
              codeLine: 4,
            });
            steps.push({
              title: "Answer: undefined for negative n",
              tracks: [stackTrack([], "idle"), resultTrack("undefined", "bad", "no value")],
              counters: [count("depth", 0), count("answer", "undefined")],
              legend: ["bad", "dim", "result", "idle"],
              happened: "The call returns nothing useful; 0! = 1 is the smallest defined factorial.",
              why: "Showing an honest 'undefined' beats inventing a number the mathematics never defined.",
              codeLine: 4,
            });
            return steps;
          }
          if (n > 500) {
            steps.push({
              title: `A stack ${n} frames deep would not fit on screen`,
              tracks: [stackTrack([n, n - 1, n - 2], "read"), resultTrack("—", "idle", "nothing yet")],
              counters: [count("depth", n), count("frames open", n)],
              legend: ["read", "active", "dim", "idle"],
              happened: `factorial(${n}) would pile ${n} frames on the call stack before a single multiplication happened.`,
              why: "This is the recursive approach's real weakness: deep input means deep stacks — and huge answers on top of that.",
              codeLine: 5,
            });
            steps.push({
              title: "Answer: not shown — stack and number are too large",
              tracks: [stackTrack([], "idle"), resultTrack("enormous", "bad", "too large to print")],
              counters: [count("depth", 0), count("answer", "too large to print")],
              legend: ["dim", "bad", "result", "idle"],
              happened: `${n}! would be written once every frame unwinds, but the value has millions of digits and the stack itself is ${n} deep.`,
              why: "Practical code uses loops or big-integer libraries here; the recursion is beautiful but expensive.",
              codeLine: 5,
            });
            return steps;
          }
          const base = n >= 1 ? 1 : 0;
          const framesTopDown = [];
          for (let k = n; k >= base; k--) framesTopDown.push(k);
          steps.push({
            title: `Call factorial(${n})`,
            tracks: [stackTrack([n]), resultTrack("—", "idle", "nothing yet")],
            counters: [count("depth", 1), count("result so far", "—")],
            legend: ["read", "active", "done", "result", "idle"],
            happened: `One frame enters the stack holding n = ${n}; it cannot answer until a smaller factorial does.`,
            why: "Every recursive frame must state what it is waiting for — here it waits on factorial(n-1).",
            codeLine: 4,
          });
          const DRAW = 12;
          const descendKs = [];
          for (let k = n; k >= 2; k--) descendKs.push(k);
          const showDescend = descendKs.slice(0, Math.min(descendKs.length, DRAW));
          for (const k of showDescend) {
            const frames = descendKs.slice(descendKs.indexOf(k));
            steps.push({
              title: `factorial(${k}) waits on factorial(${k - 1})`,
              tracks: [stackTrack(frames), resultTrack("—", "idle", "still waiting")],
              counters: [count("depth", frames.length), count("result so far", "—")],
              legend: ["read", "active", "done", "result", "idle"],
              happened: `Another frame lands on top: this one holds ${k} and asks factorial(${k - 1}) for help.`,
              why: "Nothing is multiplied yet — the recursion keeps deferring work until it reaches a base case.",
              codeLine: 5,
            });
          }
          if (descendKs.length > showDescend.length) {
            steps.push({
              title: `…${descendKs.length - showDescend.length} more frames pile on the same way`,
              tracks: [stackTrack(descendKs.concat([base])), resultTrack("—", "idle", "still waiting")],
              counters: [count("depth", descendKs.length + 1), count("result so far", "—")],
              legend: ["read", "active", "done", "result", "idle"],
              happened: `The pattern repeats until the stack holds one frame per value from ${n} down to ${base}.`,
              why: "The stack mirrors the chain of questions: each frame owns exactly one n and one promise to return n × (n-1)!",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Base case: factorial(${base}) returns 1 immediately`,
            tracks: [stackTrack(framesTopDown, "good"), resultTrack(1, "read", "first real answer")],
            counters: [count("depth", framesTopDown.length), count("result so far", 1)],
            legend: ["read", "active", "good", "result", "idle"],
            happened: `The deepest frame holds ${base}; ${base}! is defined as 1, so it answers without calling anyone.`,
            why: "The base case is what stops the chain — without it the recursion would fall forever.",
            codeLine: 4,
          });
          let f = 1n;
          const unwindKs = [];
          for (let k = 2; k <= n; k++) unwindKs.push(k);
          const chunkU = Math.ceil(unwindKs.length / 8);
          for (const k of unwindKs) {
            const prev = f;
            f *= BigInt(k);
            if (n > DRAW && (k - 2) % chunkU !== 0 && k !== n) continue;
            const frames = framesTopDown.filter((x) => x >= k);
            steps.push({
              title: `Unwind factorial(${k}) = ${k} × ${bigStr(prev)} = ${bigStr(f)}`,
              tracks: [stackTrack(frames, "done"), resultTrack(bigStr(f), "result", `k = ${k}`)],
              counters: [count("depth", frames.length), count("result so far", bigStr(f))],
              legend: ["done", "active", "result", "idle"],
              happened: `factorial(${k - 1}) handed back ${bigStr(prev)}; its caller multiplies its own ${k} in and pops off the stack.`,
              why: "This is the unwind: each returning frame does one multiplication, so the products happen on the way out.",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Answer: ${n}! = ${bigStr(f)}`,
            tracks: [stackTrack([]), resultTrack(bigStr(f), "result", "final")],
            counters: [count("depth", 0), count("answer", bigStr(f))],
            legend: ["done", "result", "idle"],
            happened: `Every frame has returned; the last one out holds ${bigStr(f)}.`,
            why: "Same product as the loop — but built by n stacked promises instead of one variable.",
            codeLine: 5,
          });
          return steps;
        },
      },
    ],
  });

  /* =========================================================== */
  V.register({
    id: "fibonacci-number",
    title: "Fibonacci Number",
    category: "Recursion",
    difficulty: "Beginner",
    description: "Get fib(n) by sliding two cells, or by walking the exponential call tree.",
    input: { label: "n", default: "10", parse: "int" },
    approaches: [
      {
        name: "Iterative: Two Rolling Cells",
        complexity: "O(n) time, O(1) space",
        idea: [
          "fib(0) = 0 and fib(1) = 1; every later value is the sum of the two before it. So keep exactly two cells and slide them: (a, b) becomes (b, a+b).",
          "After n slides, a holds fib(n). Each number is computed once and never touched again.",
        ],
        problem: [
          "The loop walks one step per index, so a huge n means a huge (if cheap) loop — and the values themselves grow exponentially, outgrowing 64-bit integers past fib(93).",
        ],
        code: {
          c: `#include <stdio.h>

/* slide a two-cell window up to fib(n) */
long long fib(int n) {
    long long a = 0, b = 1;
    for (int i = 0; i < n; i++) {
        long long next = a + b;
        a = b;
        b = next;
    }
    return a;
}

int main(void) {
    printf("%lld\\n", fib(10)); /* 55 */
    return 0;
}`,
          cpp: `#include <iostream>

// same two-cell slide, C++ flavour
long long fib(int n) {
    long long a = 0, b = 1;
    for (int i = 0; i < n; ++i) {
        long long next = a + b;
        a = b;
        b = next;
    }
    return a;
}

int main() {
    std::cout << fib(10) << '\\n'; // 55
}`,
        },
        steps(n) {
          const steps = [];
          const cell = (v, state, tag) => ({ v, state, tag });
          const pairTrack = (a, b, i) => ({
            label: "rolling cells",
            cells: [
              cell(bigStr(a), i === 0 ? "result" : "done", "fib(" + Math.max(0, n === 0 ? 0 : i - 1) + ")"),
              cell(bigStr(b), "read", "fib(" + Math.max(1, i) + ")"),
            ],
          });
          if (n < 0) {
            steps.push({
              title: `fib(${n}) is undefined`,
              tracks: [{ label: "rolling cells", cells: [cell("undefined", "bad", "n < 0")] }],
              counters: [count("n", n), count("answer", "undefined")],
              legend: ["read", "bad", "result", "idle"],
              happened: `The Fibonacci sequence is indexed from 0 upwards; ${n} is below that.`,
              why: "Definitions have edges — the honest response to an out-of-range index is to say so, not to guess.",
              codeLine: 3,
            });
            steps.push({
              title: "Answer: undefined for negative n",
              tracks: [{ label: "rolling cells", cells: [cell("undefined", "bad", "no value")] }],
              counters: [count("n", n), count("answer", "undefined")],
              legend: ["bad", "dim", "result", "idle"],
              happened: "No cells slide; fib(0) = 0 and fib(1) = 1 are the seeds of the sequence.",
              why: "Guarding the domain keeps the loop from running an unbounded number of times.",
              codeLine: 3,
            });
            return steps;
          }
          if (n > 5000) {
            steps.push({
              title: `A loop of ${n} slides is beyond this demo`,
              tracks: [{ label: "rolling cells", cells: [cell(0, "read", "fib(0)"), cell(1, "read", "fib(1)")] }],
              counters: [count("slides done", 0), count("slides left", "millions")],
              legend: ["read", "result", "dim", "idle"],
              happened: `Sliding the two cells ${n} times would take far too long to animate — and fib(${n}) has hundreds of thousands of digits.`,
              why: "The loop is O(n) with tiny constants, but n here is enormous; real code would switch to fast doubling or modular forms.",
              codeLine: 5,
            });
            const big = n <= 100000;
            steps.push({
              title: big ? `Answer: fib(${n}) has ${fibBig(BigInt(n)).toString().length} digits` : "Answer: far too large to show",
              tracks: [{ label: "rolling cells", cells: [cell("enormous", "bad", "unreadable here")] }],
              counters: [count("answer", big ? capStr(bigStr(fibBig(BigInt(n))), 40) : "too large")],
              legend: ["dim", "bad", "result", "idle"],
              happened: big
                ? `fib(${n}) was computed with a divide-and-conquer identity instead of ${n} slides; its exact value has ${fibBig(BigInt(n)).toString().length} digits.`
                : `fib(${n}) is a real number, but it is far too large for this page to print.`,
              why: "The recurrence is easy to state and hard to store — the digits grow linearly with n.",
              codeLine: 7,
            });
            return steps;
          }
          let a = 0n, b = 1n;
          steps.push({
            title: "Two cells: fib(0) = 0 and fib(1) = 1",
            tracks: [pairTrack(a, b, 0)],
            counters: [count("slides done", 0, n), count("fib(n) so far", 0)],
            legend: ["read", "done", "result", "idle"],
            happened: "The seeds of the whole sequence sit side by side; nothing has been added yet.",
            why: "Two cells are all the memory the recurrence needs — everything older is genuinely forgotten.",
            codeLine: 4,
          });
          const DRAW = 200;
          const stepLimit = Math.min(n, 6);
          for (let i = 1; i <= n; i++) {
            const next = a + b;
            a = b;
            b = next;
            if (i > stepLimit && i !== n && n > stepLimit + 2) continue;
            steps.push({
              title: `Slide ${i}: a → fib(${i}) = ${bigStr(a)}, b → fib(${i + 1}) = ${bigStr(b)}`,
              tracks: [pairTrack(a, b, i)],
              counters: [count("slides done", i, n), count("fib(n) so far", bigStr(a))],
              legend: ["read", "done", "result", "idle"],
              happened: `Add the two cells: ${bigStr(a)} and ${bigStr(b)} were ${bigStr(next - a)} + ${bigStr(next - b)}... the window shifts one place right.`,
              why: "Each slide computes exactly one new Fibonacci number; the old left cell is never needed again.",
              codeLine: 6,
            });
          }
          if (n > stepLimit + 2) {
            steps.push({
              title: `…the same slide repeats ${n - stepLimit - 1} more times`,
              tracks: [pairTrack(a, b, n)],
              counters: [count("slides done", n, n), count("fib(n) so far", bigStr(a))],
              legend: ["read", "done", "result", "idle"],
              happened: `Nothing changes between slides — the loop keeps adding the pair until i reaches ${n}.`,
              why: "Repetition with no new logic is where loops shine and where recursion would waste stack.",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Answer: fib(${n}) = ${bigStr(a)}`,
            tracks: [{
              label: "rolling cells",
              cells: [cell(bigStr(a), "result", "final"), cell(bigStr(b), "dim", "one step ahead")],
            }],
            counters: [count("slides done", n, n), count("answer", bigStr(a))],
            legend: ["dim", "result", "idle"],
            happened: `After ${n} slides the left cell holds ${bigStr(a)}; b always runs one step ahead, which is exactly the trick.`,
            why: "n additions, two cells, no recursion — the cheapest way to walk the sequence.",
            codeLine: 9,
          });
          return steps;
        },
      },
      {
        name: "Naive Recursion Tree",
        complexity: "O(φⁿ) time, O(n) stack",
        idea: [
          "The definition translates directly: fib(n) = fib(n-1) + fib(n-2), with fib(0) = 0 and fib(1) = 1. Each call spawns two more calls until the base cases answer.",
          "The calls form a binary tree. Leaves are base cases; every internal node adds its two children's answers as the stack unwinds.",
        ],
        problem: [
          "The tree repeats itself constantly: fib(3) is computed several times, fib(2) even more. The number of calls doubles-ish per level — fib(40) already means hundreds of millions of calls. No work is ever reused.",
        ],
        code: {
          c: `#include <stdio.h>

/* the textbook definition — note the repeated work */
long long fib(int n) {
    if (n <= 0) return 0;
    if (n == 1) return 1;
    return fib(n - 1) + fib(n - 2);
}

int main(void) {
    printf("%lld\\n", fib(10)); /* 55 */
    return 0;
}`,
          cpp: `#include <iostream>

// the definition as code — exponential work included
long long fib(int n) {
    if (n <= 0) return 0;          // base case
    if (n == 1) return 1;          // base case
    return fib(n - 1) + fib(n - 2);
}

int main() {
    std::cout << fib(10) << '\\n'; // 55
}`,
        },
        steps(n) {
          const steps = [];
          const cell = (v, state, tag) => ({ v, state, tag });
          if (n < 0) {
            steps.push({
              title: `fib(${n}) is undefined`,
              tracks: [{ label: "call", cells: [cell("fib(" + n + ")", "read", "out of range")] }],
              counters: [count("n", n), count("answer", "undefined")],
              legend: ["read", "bad", "result", "idle"],
              happened: `The Fibonacci sequence starts at index 0; ${n} falls off the low end.`,
              why: "Recursive functions need their guards too — the base cases only cover n ≥ 0.",
              codeLine: 4,
            });
            steps.push({
              title: "Answer: undefined for negative n",
              tracks: [{ label: "call", cells: [cell("undefined", "bad", "no value")] }],
              counters: [count("n", n), count("answer", "undefined")],
              legend: ["bad", "dim", "result", "idle"],
              happened: "No tree can grow from a negative index — the seeds are fib(0) = 0 and fib(1) = 1.",
              why: "Saying 'undefined' honestly is better than letting the recursion wander outside its definition.",
              codeLine: 4,
            });
            return steps;
          }
          const valBig = n <= 5000 ? fibBig(BigInt(n)) : null; // never stringify gigantic numbers
          if (n > 10) {
            const ansStr = valBig ? bigStr(valBig) : "far too large to show";
            // tree too big to draw — tell the truth about the blow-up instead
            steps.push({
              title: `Call fib(${n}) — the tree grows from here`,
              tracks: [{ label: "call stack", dir: "col", cells: [cell("fib(" + n + ")", "read", "top")] }],
              counters: [count("depth", 1), count("calls made", 1)],
              legend: ["read", "active", "good", "bad", "idle"],
              happened: `fib(${n}) asks for fib(${n - 1}) and fib(${n - 2}); each of those asks for two more, and so on down to the base cases.`,
              why: "Every node of this call tree is a fresh function call — nothing is shared between branches.",
              codeLine: 6,
            });
            steps.push({
              title: `The stack dives: fib(k) keeps calling fib(k-1)`,
              tracks: [{
                label: "call stack",
                dir: "col",
                cells: [n, n - 1, n - 2, n - 3].map((k, i) =>
                  cell("fib(" + k + ")", i === 3 ? "read" : "active", i === 3 ? "top" : "waiting")),
              }],
              counters: [count("depth", 4), count("calls so far", 8)],
              legend: ["read", "active", "good", "bad", "idle"],
              happened: "One long chain of calls reaches for the base case before anything is added.",
              why: "Depth is only n — but breadth is where this approach dies, as the next steps show.",
              codeLine: 6,
            });
            const calls = n + 1 <= 1400 ? (2 * fibDouble(n + 1) - 1) : Infinity;
            steps.push({
              title: "The tree fills in: every node spawns two more",
              tracks: [{
                label: "calls by size",
                cells: [1, 2, 3, 5, 8, 13].map((v, i) => cell(v, "done", "fib(" + (i + 2) + ") calls")),
              }],
              counters: [count("calls to reach fib(" + n + ")", isFinite(calls) ? calls : "astronomical")],
              legend: ["read", "done", "bad", "result", "idle"],
              happened: `By the time the small values are needed, the same fib(k) is recomputed inside many different branches — the call count follows the sequence itself.`,
              why: "This is exponential blow-up in the flesh: the tree of calls is roughly φ times wider per level.",
              codeLine: 6,
            });
            steps.push({
              title: "Unwind: the two answers finally add up",
              tracks: [{
                label: "call stack",
                dir: "col",
                cells: [cell("fib(1)", "good", "returns 1"), cell("fib(2)", "good", "returns 1"), cell("fib(3)", "read", "adds children")],
              }],
              counters: [count("answers returned", 3), count("fib(n) so far", 1)],
              legend: ["read", "good", "done", "result", "idle"],
              happened: "Base cases hand back 0 and 1; each returning frame adds its two children's values.",
              why: "The addition only happens on the way out — that is what makes every internal node real work.",
              codeLine: 6,
            });
            steps.push({
              title: `Answer: fib(${n}) = ${ansStr}`,
              tracks: [{ label: "call", cells: [cell("fib(" + n + ") = " + ansStr, "result", "final")] }],
              counters: [count("calls avoided by memoisation", isFinite(calls) ? Math.max(0, calls - n - 1) : "most"), count("answer", ansStr)],
              legend: ["good", "result", "dim", "idle"],
              happened: `The root finally gets its number: ${ansStr} — correct, but only after the whole tree was walked.`,
              why: "Correct is not the same as fast: memoising or sliding two cells turns those millions of calls into n additions.",
              codeLine: 6,
            });
            return steps;
          }
          // small n: build the actual call tree
          const val = valBig ? valBig.toString() : "?";
          let id = 0;
          const counts = {};
          const build = (k) => {
            const node = { id: "t" + id++, v: "fib(" + k + ")", l: null, r: null };
            counts[k] = (counts[k] || 0) + 1;
            if (k >= 2) { node.l = build(k - 1); node.r = build(k - 2); }
            return node;
          };
          const root = build(n);
          const allIds = [];
          const collect = (nd) => { if (!nd) return; allIds.push(nd.id); collect(nd.l); collect(nd.r); };
          collect(root);
          const baseIds = [];
          const findBase = (nd) => { if (!nd) return; if (nd.l === null) baseIds.push(nd.id); findBase(nd.l); findBase(nd.r); };
          findBase(root);
          steps.push({
            title: `The call tree of fib(${n})`,
            kind: "tree",
            tree: root,
            nodeStates: {},
            label: "each node calls fib(k-1) and fib(k-2)",
            counters: [count("nodes in the tree", allIds.length), count("base-case leaves", baseIds.length)],
            legend: ["read", "done", "good", "result", "idle"],
            happened: `One root call grows a small binary tree: ${allIds.length} nodes in total, ${baseIds.length} of them base cases.`,
            why: "Seeing the tree makes the cost obvious: the number of calls is what the algorithm really pays.",
            codeLine: 6,
          });
          // mark the deepest left path
          const pathIds = [];
          let cur = root;
          while (cur) { pathIds.push(cur.id); cur = cur.l; }
          const st = {};
          pathIds.forEach((tid) => { st[tid] = "read"; });
          steps.push({
            title: `Dive to the base case: fib(${n}) → fib(${n - 1}) → …`,
            kind: "tree",
            tree: root,
            nodeStates: st,
            label: "green = current call chain",
            counters: [count("depth", pathIds.length), count("answers ready", 0)],
            legend: ["read", "done", "good", "result", "idle"],
            happened: `The green path is one single chain of calls dropping toward a base case before any adding begins.`,
            why: "The first thing recursion does is defer: work piles up on the stack until the smallest cases answer.",
            codeLine: 6,
          });
          const st2 = {};
          allIds.forEach((tid) => { st2[tid] = "done"; });
          baseIds.forEach((tid) => { st2[tid] = "good"; });
          steps.push({
            title: "Base cases answer: fib(0) = 0, fib(1) = 1",
            kind: "tree",
            tree: root,
            nodeStates: st2,
            label: "amber = base cases returning",
            counters: [count("nodes visited", allIds.length), count("answers ready", baseIds.length)],
            legend: ["good", "done", "result", "idle"],
            happened: `Every leaf is a fib(0) or fib(1) — ${baseIds.length} tiny answers that need no further calls.`,
            why: "Base cases are the anchors of recursion; without them the tree would fall forever.",
            codeLine: 4,
          });
          const findFirst = (nd, label) => {
            if (!nd) return null;
            if (nd.v === label) return nd;
            return findFirst(nd.l, label) || findFirst(nd.r, label);
          };
          [2, 3].forEach((k) => {
            if (n < k) return;
            const node = findFirst(root, "fib(" + k + ")");
            if (!node) return;
            const stR = {};
            allIds.forEach((tid) => { stR[tid] = "done"; });
            baseIds.forEach((tid) => { stR[tid] = "good"; });
            stR[node.id] = "result";
            steps.push({
              title: `Return ${k === 2 ? "first" : "next"}: fib(${k}) = ${k === 2 ? "1" : "2"}`,
              kind: "tree",
              tree: root,
              nodeStates: stR,
              label: "amber = this parent adds its two children",
              counters: [count("answers returned", k), count("fib(n) so far", k === 2 ? 1 : 2)],
              legend: ["read", "done", "good", "result", "idle"],
              happened: `Both children of fib(${k}) have values, so this node finally adds them on the way up.`,
              why: "Returning is when the arithmetic actually happens — the descent only asked questions.",
              codeLine: 6,
            });
          });
          const dupIds = [];
          const findDup = (nd) => { if (!nd) return; if (nd.l === null && counts[parseInt(nd.v.slice(4), 10)] > 1) dupIds.push(nd.id); findDup(nd.l); findDup(nd.r); };
          if (n >= 3) {
            findDup(root);
            const st3 = {};
            dupIds.forEach((tid) => { st3[tid] = "bad"; });
            steps.push({
              title: `Red nodes repeat work: fib(3) alone is computed ${counts[3] || 1}×`,
              kind: "tree",
              tree: root,
              nodeStates: st3,
              label: "red = same value computed again",
              counters: [count("repeated nodes", dupIds.length), count("unique values", Object.keys(counts).length)],
              legend: ["bad", "done", "good", "result", "idle"],
              happened: "Several red nodes ask for exactly the same fib(k) that a red-free branch already answered.",
              why: "This is the whole problem with naive recursion: results are thrown away and recomputed instead of reused.",
              codeLine: 6,
            });
          }
          const st4 = {};
          allIds.forEach((tid) => { st4[tid] = "done"; });
          baseIds.forEach((tid) => { st4[tid] = "good"; });
          pathIds.forEach((tid) => { st4[tid] = "read"; });
          steps.push({
            title: "Unwind: each parent adds its two children",
            kind: "tree",
            tree: root,
            nodeStates: st4,
            label: "green = the frame now returning",
            counters: [count("answers returned", allIds.length - baseIds.length), count("fib(n) so far", "—")],
            legend: ["read", "done", "good", "result", "idle"],
            happened: "Answers bubble upward; every internal node is one addition of its left and right child.",
            why: "The additions happen strictly on the way out — the tree was all questions, the return path is all answers.",
            codeLine: 6,
          });
          const st5 = {};
          allIds.forEach((tid) => { st5[tid] = "done"; });
          st5[root.id] = "result";
          steps.push({
            title: `Answer: fib(${n}) = ${val}`,
            kind: "tree",
            tree: root,
            nodeStates: st5,
            label: "amber = the root finally knows",
            counters: [count("total calls", allIds.length), count("answer", val)],
            legend: ["done", "result", "good", "idle"],
            happened: `The root holds ${val} — the same number the two-cell loop finds, with far more calls spent.`,
            why: "Both approaches are correct; the tree just pays exponential prices for the same recurrence.",
            codeLine: 6,
          });
          return steps;
        },
      },
    ],
  });

  /* =========================================================== */
  V.register({
    id: "pow-x-n",
    title: "Pow(x, n)",
    category: "Recursion",
    difficulty: "Intermediate",
    description: "Raise x to the power n by squaring the base and halving the exponent.",
    input: { label: "base and exponent (e.g. 2.0 n=10)", default: "2.0 n=10", parse: "tokens" },
    approaches: [
      {
        name: "Loop: Square and Halve",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "Write the exponent in binary. Every odd exponent lets one copy of the current base fold into the result; squaring the base and halving the exponent then covers the next bit.",
          "After ⌈log₂(n+1)⌉ rounds the exponent hits 0 and the accumulated result is xⁿ. A negative n is handled once, up front, by inverting the base.",
        ],
        problem: [
          "The loop needs the exponent as a non-negative integer, so negative powers must be flipped into 1/x^|n| first — and very large exponents quickly push the result past what a double can hold.",
        ],
        code: {
          c: `#include <stdio.h>

/* exponentiation by squaring: halve n, square x */
double power(double x, int n) {
    int negative = n < 0;
    long e = negative ? -(long)n : (long)n;
    double result = 1.0, base = x;
    while (e > 0) {
        if (e & 1) result *= base;   /* odd step folds a copy in */
        base *= base;                /* square for the next bit */
        e >>= 1;                     /* drop the finished bit */
    }
    return negative ? 1.0 / result : result;
}

int main(void) {
    printf("%.4f\\n", power(2.0, 10)); /* 1024.0000 */
    return 0;
}`,
          cpp: `#include <iostream>

// same square-and-halve loop, C++ flavour
double power(double x, int n) {
    bool negative = n < 0;
    long e = negative ? -(long)n : (long)n;
    double result = 1.0, base = x;
    while (e > 0) {
        if (e & 1) result *= base;   // odd exponent: fold a copy
        base *= base;                // square the base
        e >>= 1;                     // halve the exponent
    }
    return negative ? 1.0 / result : result;
}

int main() {
    std::cout << power(2.0, 10) << '\\n'; // 1024
}`,
        },
        steps(tokens) {
          const steps = [];
          const cell = (v, state, tag) => ({ v, state, tag });
          let baseTok = null, expTok = null, base = NaN, exp = NaN;
          for (const tk of tokens) {
            if (/^n=/i.test(tk)) { expTok = tk; exp = parseFloat(tk.slice(2)); continue; }
            if (baseTok == null) { baseTok = tk; base = parseFloat(tk); continue; }
            if (expTok == null) { expTok = tk; exp = parseFloat(tk); }
          }
          const triple = (x, e, r, tags) => ({
            label: "power state",
            cells: [
              cell(fmt(x), "read", tags ? tags[0] : "base x"),
              cell(fmt(e), "compare", tags ? tags[1] : "exponent n"),
              cell(fmt(r), "result", tags ? tags[2] : "result"),
            ],
          });
          if (Number.isNaN(base)) {
            steps.push({
              title: `Base "${baseTok}" is not a number`,
              tracks: [triple("?", "?", "?", ["unreadable", "unreadable", "—"])],
              counters: [count("base token", capStr(baseTok, 12)), count("answer", "cannot compute")],
              legend: ["read", "compare", "bad", "result"],
              happened: `The token "${baseTok}" cannot be read as a decimal number, so there is nothing to multiply.`,
              why: "Exponentiation needs a numeric base; the honest outcome for garbage input is a clear message, not a crash.",
              codeLine: 4,
            });
            steps.push({
              title: "Answer: needs a numeric base like 2.0",
              tracks: [triple("?", "?", "?", ["bad", "bad", "bad"])],
              counters: [count("answer", "cannot compute")],
              legend: ["bad", "dim", "result", "idle"],
              happened: "No power can be taken of a word — try a token such as 2.0 or 0.5.",
              why: "Parsers accept text; algorithms must still check that the text means what they expect.",
              codeLine: 4,
            });
            return steps;
          }
          if (Number.isNaN(exp)) {
            steps.push({
              title: expTok == null ? "No exponent given — assuming n = 1" : `Exponent "${expTok}" is not a number`,
              tracks: [triple(base, expTok == null ? 1 : "?", 1, ["base ok", expTok == null ? "assumed" : "unreadable", "seeded"])],
              counters: [count("base", fmt(base)), count("exponent", expTok == null ? "1 (assumed)" : capStr(expTok, 12))],
              legend: ["read", "compare", "bad", "result"],
              happened: expTok == null
                ? `Only a base was given, so the exponent is taken as 1 — x¹ is just x.`
                : `The token "${expTok}" carries no readable number after "n=", so the exponent cannot be used.`,
              why: expTok == null
                ? "A missing exponent is not an error for x¹ — but the assumption is stated out loud rather than hidden."
                : "Checking each parsed token turns a confusing crash into a clear message.",
              codeLine: 4,
            });
            if (expTok != null) {
              steps.push({
                title: "Answer: needs an exponent like n=10",
                tracks: [triple(base, "?", "?", ["base ok", "bad", "bad"])],
                counters: [count("answer", "cannot compute")],
                legend: ["bad", "dim", "result", "idle"],
                happened: "Write the input as two tokens, e.g. \"2.0 n=10\".",
                why: "The parse step is part of the algorithm: garbage exponents are rejected before any squaring begins.",
                codeLine: 4,
              });
              return steps;
            }
            exp = 1;
          }
          if (!Number.isFinite(exp)) {
            steps.push({
              title: `Exponent ${fmt(exp)} is too large to walk`,
              tracks: [{ label: "power state", cells: [{ v: fmt(base), state: "read", tag: "base x" }, { v: "∞", state: "bad", tag: "exponent" }, { v: "?", state: "idle", tag: "result" }] }],
              counters: [count("base", fmt(base)), count("answer", "cannot compute")],
              legend: ["read", "compare", "bad", "result"],
              happened: `The exponent reads as infinity — there is no whole number of squaring rounds to perform.`,
              why: "Even parsing surprises deserve a step of their own: an infinite exponent cannot be halved down to zero.",
              codeLine: 8,
            });
            steps.push({
              title: "Answer: exponent must be a finite number",
              tracks: [{ label: "power state", cells: [{ v: fmt(base), state: "dim", tag: "unused" }, { v: "?", state: "bad", tag: "rejected" }, { v: "?", state: "bad", tag: "none" }] }],
              counters: [count("answer", "cannot compute")],
              legend: ["bad", "dim", "result", "idle"],
              happened: "Try a readable exponent such as n=10.",
              why: "Checking exponent finiteness up front turns a potential hang into one clear message.",
              codeLine: 8,
            });
            return steps;
          }
          let origBase = base, origExp = exp;
          steps.push({
            title: `Start: x = ${fmt(base)}, n = ${fmt(exp)}, result = 1`,
            tracks: [triple(base, exp, 1)],
            counters: [count("rounds left", Math.max(0, Math.ceil(Math.log2(Math.abs(exp) + 1)))), count("result so far", 1)],
            legend: ["read", "compare", "result", "idle"],
            happened: `The result slot starts at 1 (the multiplicative identity) and waits for copies of the base to fold in.`,
            why: "Squaring methods always begin from 1 so that multiplying by it changes nothing until an odd exponent demands a copy.",
            codeLine: 6,
          });
          if (!Number.isInteger(exp)) {
            const whole = Math.floor(Math.abs(exp)) * Math.sign(exp);
            steps.push({
              title: `n = ${fmt(exp)} is not a whole number — use ${whole}`,
              tracks: [triple(base, whole, 1, ["base ok", "rounded", "seeded"])],
              counters: [count("exponent used", whole), count("result so far", 1)],
              legend: ["read", "compare", "result", "idle"],
              happened: `Squaring only walks whole steps of the exponent, so the fractional part ${fmt(Math.abs(exp) - Math.abs(whole))} is dropped.`,
              why: "Binary exponentiation counts bits; fractional powers would need logarithms and roots instead.",
              codeLine: 8,
            });
            exp = whole;
          }
          if (exp === 0) {
            steps.push({
              title: "Anything to the power 0 is 1",
              tracks: [triple(base, 0, 1, ["dim", "done", "final"])],
              counters: [count("rounds", 0), count("answer", 1)],
              legend: ["done", "result", "dim", "idle"],
              happened: `The exponent is already 0, so the loop never runs and the seeded result stands: ${fmt(origBase)}⁰ = 1.`,
              why: "The empty product is 1 — every squaring method relies on this base case.",
              codeLine: 6,
            });
            return steps;
          }
          let negative = exp < 0;
          let e = Math.abs(exp);
          if (negative) {
            base = 1 / base;
            steps.push({
              title: `n is negative → invert the base: x = ${fmt(base)}, n = ${e}`,
              tracks: [triple(base, e, 1, ["inverted", "positive now", "seeded"])],
              counters: [count("exponent used", e), count("result so far", 1)],
              legend: ["read", "compare", "result", "idle"],
              happened: `x⁻ⁿ is 1 divided by xⁿ, so the base flips to its reciprocal ${fmt(base)} and the exponent becomes positive.`,
              why: "One small rewrite turns a new problem into one already solved — the hallmark of a good reduction.",
              codeLine: 12,
            });
          }
          let result = 1;
          let guard = 0;
          while (e > 0 && guard++ < 1200) {
            if (e % 2 === 1) {
              const prev = result;
              result *= base;
              steps.push({
                title: `n = ${e} is odd → result ×= x → ${fmt(result)}`,
                tracks: [triple(base, e, result, ["current base", "odd!", "× " + fmt(base)])],
                counters: [count("exponent left", e), count("result so far", fmt(result))],
                legend: ["read", "compare", "result", "idle"],
                happened: `An odd exponent still hides one uncollected copy of x: ${fmt(prev)} × ${fmt(base)} = ${fmt(result)}.`,
                why: "Folding the copy in now makes the exponent even, so the next squaring step can halve it cleanly.",
                codeLine: 8,
              });
              e -= 1;
              if (e === 0) break;
            }
            const prevBase = base;
            base *= base;
            e = Math.floor(e / 2);
            steps.push({
              title: `Square x → ${fmt(base)}, halve n → ${e}`,
              tracks: [triple(base, e, result, ["squared", "halved", "held"])],
              counters: [count("exponent left", e), count("result so far", fmt(result))],
              legend: ["read", "compare", "result", "idle"],
              happened: `${fmt(prevBase)} × ${fmt(prevBase)} = ${fmt(base)}; the exponent drops to ${e}, having served its low bit.`,
              why: "One squaring covers two layers of multiplication at once — this is where the log-time speed comes from.",
              codeLine: 9,
            });
          }
          if (negative) {
            result = 1 / result;
            steps.push({
              title: `Flip back: 1 / result = ${fmt(result)}`,
              tracks: [triple(base, 0, result, ["dim", "done", "inverted"])],
              counters: [count("result so far", fmt(result))],
              legend: ["done", "result", "dim", "idle"],
              happened: `The positive power is done; dividing it by 1 gives the negative-power answer ${fmt(result)}.`,
              why: "The negative case borrowed the whole loop and repaid it with a single division.",
              codeLine: 12,
            });
          }
          steps.push({
            title: `Answer: ${fmt(origBase)}^${fmt(origExp)} = ${fmt(result)}`,
            tracks: [triple(base, 0, result, ["dim", "done", "final"])],
            counters: [count("rounds used", guard), count("answer", fmt(result))],
            legend: ["done", "result", "dim", "idle"],
            happened: `The exponent hit 0 after ${guard} rounds; the result slot holds ${fmt(result)}.`,
            why: `${Math.ceil(Math.log2(Math.abs(origExp) + 1))} squarings replaced potentially millions of naive multiplications.`,
            codeLine: 12,
          });
          return steps;
        },
      },
      {
        name: "Recursive Halving",
        complexity: "O(log n) time, O(log n) stack",
        idea: [
          "Ask the same question for half the exponent: power(x, n) needs power(x, n/2). If n is even the answer is that half squared; if n is odd, one extra x tags along.",
          "The base case is n = 0 → 1, and a negative n is one wrapper call: 1 / power(x, -n).",
        ],
        problem: [
          "The recursion is short (only log₂ n frames), but each level still does multiplications at its own scale — and like the loop it needs a positive whole exponent to work with.",
        ],
        code: {
          c: `#include <stdio.h>

/* half the exponent, square the base, combine going up */
double power(double x, int n) {
    if (n == 0) return 1.0;                 /* base case */
    if (n < 0) return 1.0 / power(x, -n);   /* negative: flip after */
    double half = power(x, n / 2);
    if (n % 2 == 0) return half * half;     /* even: square it */
    return half * half * x;                 /* odd: one extra x */
}

int main(void) {
    printf("%.4f\\n", power(2.0, 10)); /* 1024.0000 */
    return 0;
}`,
          cpp: `#include <iostream>

// the same halving idea, expressed recursively
double power(double x, int n) {
    if (n == 0) return 1.0;                 // base case
    if (n < 0) return 1.0 / power(x, -n);   // borrow the positive case
    double half = power(x, n / 2);
    if (n % 2 == 0) return half * half;     // even exponent
    return half * half * x;                 // odd exponent
}

int main() {
    std::cout << power(2.0, 10) << '\\n'; // 1024
}`,
        },
        steps(tokens) {
          const steps = [];
          const cell = (v, state, tag) => ({ v, state, tag });
          let baseTok = null, expTok = null, base = NaN, exp = NaN;
          for (const tk of tokens) {
            if (/^n=/i.test(tk)) { expTok = tk; exp = parseFloat(tk.slice(2)); continue; }
            if (baseTok == null) { baseTok = tk; base = parseFloat(tk); continue; }
            if (expTok == null) { expTok = tk; exp = parseFloat(tk); }
          }
          const stackTrack = (frames) => ({
            label: "call stack: exponent per frame",
            dir: "col",
            cells: frames.length
              ? frames.map((k, i) => cell("n=" + k, i === frames.length - 1 ? "read" : "active", i === frames.length - 1 ? "top" : "waiting"))
              : [cell("empty", "idle", "all returned")],
          });
          const resultCell = (v, state, tag) => ({ label: "value returned", cells: [cell(v, state, tag)] });
          if (Number.isNaN(base) || Number.isNaN(exp)) {
            steps.push({
              title: Number.isNaN(base) ? `Base "${baseTok}" is not a number` : `Exponent "${expTok}" is not a number`,
              tracks: [stackTrack([]), resultCell("?", "bad", "cannot compute")],
              counters: [count("base token", capStr(baseTok || "?", 12)), count("exponent token", capStr(expTok || "(missing)", 12))],
              legend: ["read", "bad", "result", "idle"],
              happened: Number.isNaN(base)
                ? `The token "${baseTok}" cannot be read as a decimal number, so the first call has nothing to work with.`
                : `The token "${expTok}" carries no readable number after "n=", so the recursion cannot decide how deep to go.`,
              why: "A recursive function checks its inputs at the top level — bad arguments should fail once, loudly, not deep in the stack.",
              codeLine: 4,
            });
            steps.push({
              title: "Answer: needs tokens like 2.0 n=10",
              tracks: [stackTrack([]), resultCell("undefined", "bad", "no value")],
              counters: [count("answer", "cannot compute")],
              legend: ["bad", "dim", "result", "idle"],
              happened: "No power can be computed from unreadable tokens.",
              why: "Turning a would-be crash into one clear step is exactly what input checks are for.",
              codeLine: 4,
            });
            return steps;
          }
          if (!Number.isFinite(exp)) {
            steps.push({
              title: `Exponent ${fmt(exp)} is too large to recurse on`,
              tracks: [stackTrack([]), resultCell("?", "bad", "cannot compute")],
              counters: [count("base", fmt(base)), count("answer", "cannot compute")],
              legend: ["read", "bad", "result", "idle"],
              happened: `The exponent reads as infinity, so the halving chain would never reach the base case.`,
              why: "A recursive power needs a finite whole exponent; anything else must be rejected before the stack starts growing.",
              codeLine: 4,
            });
            steps.push({
              title: "Answer: exponent must be a finite number",
              tracks: [stackTrack([]), resultCell("undefined", "bad", "no value")],
              counters: [count("answer", "cannot compute")],
              legend: ["bad", "dim", "result", "idle"],
              happened: "Try a readable exponent such as n=10.",
              why: "One up-front check saves an infinite recursion later.",
              codeLine: 4,
            });
            return steps;
          }
          let origBase = base, origExp = exp;
          let negative = false;
          if (!Number.isInteger(exp)) {
            exp = Math.floor(Math.abs(exp)) * Math.sign(exp);
          }
          if (exp < 0) { negative = true; }
          const e0 = Math.abs(exp);
          steps.push({
            title: `Call power(${fmt(origBase)}, ${fmt(origExp)})`,
            tracks: [stackTrack([origExp]), resultCell("—", "idle", "nothing yet")],
            counters: [count("depth", 1), count("result so far", "—")],
            legend: ["read", "active", "result", "idle"],
            happened: `One frame enters holding n = ${fmt(origExp)}; it splits the exponent in half before doing any multiplying.`,
            why: "Divide and conquer: shrink the problem first, combine answers on the way back.",
            codeLine: 5,
          });
          if (e0 === 0) {
            steps.push({
              title: "Base case: n = 0 → 1",
              tracks: [stackTrack([0]), resultCell(1, "read", "x⁰ = 1")],
              counters: [count("depth", 1), count("result so far", 1)],
              legend: ["read", "good", "result", "idle"],
              happened: "The exponent is already 0, so the recursion answers immediately with 1.",
              why: "Every recursion needs a floor; x⁰ = 1 is the natural one for powers.",
              codeLine: 4,
            });
            steps.push({
              title: `Answer: ${fmt(origBase)}^${fmt(origExp)} = ${negative ? fmt(1 / 1) : 1}`,
              tracks: [stackTrack([]), resultCell(negative ? fmt(1) : 1, "result", "final")],
              counters: [count("depth", 0), count("answer", negative ? 1 : 1)],
              legend: ["done", "result", "dim", "idle"],
              happened: "The single frame returns 1 — x⁰ needs no squaring at all.",
              why: "Even the empty problem has a defined answer; that is what keeps the recursion total.",
              codeLine: 4,
            });
            return steps;
          }
          const frames = [];
          let k = e0;
          while (k > 0) { frames.push(k); k = Math.floor(k / 2); }
          frames.push(0);
          const DRAW = 9;
          const shownFrames = frames.slice(0, Math.min(frames.length, DRAW));
          for (let i = 1; i < shownFrames.length; i++) {
            const cur = frames[i - 1], nextF = frames[i];
            steps.push({
              title: `power(x, ${cur}) waits on power(x, ${nextF})`,
              tracks: [stackTrack(frames.slice(0, i + 1)), resultCell("—", "idle", "still waiting")],
              counters: [count("depth", i + 1), count("result so far", "—")],
              legend: ["read", "active", "result", "idle"],
              happened: `The frame halves the exponent: ${cur} / 2 = ${nextF}, and the smaller call goes on top of the stack.`,
              why: "Halving the exponent each level is what makes the total work logarithmic in n.",
              codeLine: 6,
            });
          }
          if (frames.length > shownFrames.length) {
            steps.push({
              title: `…halving continues down to n = 0 (${frames.length} frames total)`,
              tracks: [stackTrack(frames), resultCell("—", "idle", "still waiting")],
              counters: [count("depth", frames.length), count("result so far", "—")],
              legend: ["read", "active", "result", "idle"],
              happened: `Each level divides the exponent by 2, so only about ${frames.length} frames ever exist — no exponential tree here.`,
              why: "Compare this tiny stack with naive repeated multiplication's n steps: the exponent shrinks geometrically.",
              codeLine: 6,
            });
          }
          steps.push({
            title: "Base case: power(x, 0) returns 1",
            tracks: [stackTrack(frames), resultCell(1, "read", "x⁰ = 1")],
            counters: [count("depth", frames.length), count("result so far", 1)],
            legend: ["read", "good", "result", "idle"],
            happened: "The deepest frame hits n = 0 and answers 1 without calling anyone.",
            why: "This single value is the seed every level above will square and adjust.",
            codeLine: 4,
          });
          let result = 1;
          let half = 1;
          let shown = 0;
          const chunk = Math.max(1, Math.ceil((frames.length - 1) / DRAW));
          for (let i = frames.length - 2; i >= 0; i--) {
            const kk = frames[i];
            half = result;
            const even = kk % 2 === 0;
            result = even ? half * half : half * half * origBase;
            shown++;
            if (shown % chunk !== 0 && i !== 0) continue;
            steps.push({
              title: `power(x, ${kk}) ${even ? "even → square the half" : "odd → square then × x"} = ${fmt(result)}`,
              tracks: [
                stackTrack(frames.slice(0, i + 1)),
                resultCell(fmt(result), "result", "n = " + kk),
              ],
              counters: [count("depth", i + 1), count("result so far", fmt(result))],
              legend: ["done", "result", "idle"],
              happened: `The half-answer ${fmt(half)} comes back to this frame, which squares it${even ? "" : ` and multiplies by x once more`} to give ${fmt(result)}.`,
              why: "Every level does at most two multiplications — the whole tower costs O(log n).",
              codeLine: even ? 7 : 8,
            });
          }
          if (negative) {
            result = 1 / result;
            steps.push({
              title: `Negative exponent → 1 / result = ${fmt(result)}`,
              tracks: [stackTrack([]), resultCell(fmt(result), "result", "inverted")],
              counters: [count("result so far", fmt(result))],
              legend: ["done", "result", "dim", "idle"],
              happened: "The wrapper call divides 1 by the positive-power answer it borrowed.",
              why: "One extra frame handles every negative exponent — the recursion itself never sees a negative n.",
              codeLine: 5,
            });
          }
          steps.push({
            title: `Answer: ${fmt(origBase)}^${fmt(origExp)} = ${fmt(result)}`,
            tracks: [stackTrack([]), resultCell(fmt(result), "result", "final")],
            counters: [count("frames used", frames.length), count("answer", fmt(result))],
            legend: ["done", "result", "dim", "idle"],
            happened: `Every frame has returned; the original call holds ${fmt(result)}.`,
            why: "Halving beats walking: ⌈log₂(n)⌉ frames replaced n multiplications.",
            codeLine: 7,
          });
          return steps;
        },
      },
    ],
  });

  /* =========================================================== */
  V.register({
    id: "reverse-a-string-recursively",
    title: "Reverse a String Recursively",
    category: "Recursion",
    difficulty: "Beginner",
    description: "Peel the first character off, recurse on the tail, and let the returns rebuild the string backwards.",
    input: { label: "Text to reverse", default: "banana", parse: "string" },
    approaches: [
      {
        name: "Unwind the Calls",
        complexity: "O(n) time, O(n) stack",
        idea: [
          "reverse(s) is defined as reverse(s without its first character) plus that first character at the end. Keep calling on a shorter tail until one character is left — a single character is already reversed.",
          "Nothing is assembled while descending. The magic happens on the way out: each returning frame appends its own first character to the end of what the deeper call returned.",
        ],
        problem: [
          "Every frame holds one character of pending work, so a long string means a deep stack — and each append copies the string, making the unwind quadratic in naive implementations.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

/* print s[i..len) backwards: the deeper call prints first */
void reverse_from(const char *s, int i, int len) {
    if (i == len) return;               /* base: nothing left */
    reverse_from(s, i + 1, len);        /* dive toward the end */
    putchar(s[i]);                      /* this char comes back last */
}

int main(void) {
    const char *s = "banana";
    reverse_from(s, 0, (int)strlen(s)); /* prints ananab */
    putchar('\\n');
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>

// reverse the tail, then stick the head on the end
std::string reverseRec(const std::string& s) {
    if (s.size() <= 1) return s;             // base case
    return reverseRec(s.substr(1)) + s[0];   // head joins last
}

int main() {
    std::cout << reverseRec("banana") << '\\n'; // ananab
}`,
        },
        steps(s) {
          const steps = [];
          const chars = Array.from(s);
          const L = chars.length;
          const cell = (v, state, tag) => ({ v, state, tag });
          const briefStr = (t) => (t.length > 6 ? t.slice(0, 6) + "…" : t);
          const stackTrack = (depth, topState) => {
            const frames = [];
            for (let i = 0; i <= depth; i++) frames.push(i);
            const wrap = (arr, off) =>
              arr.map((i) => {
                const isTop = off + i === depth;
                return cell(chars[i], isTop ? (topState || "read") : "active", isTop ? "top" : "waiting");
              });
            const cells = frames.length <= 12
              ? wrap(frames, 0)
              : [...wrap(frames.slice(0, 6), 0), cell("…", "idle", "more frames"), ...wrap(frames.slice(-4), frames.length - 4)];
            return cells.length
              ? { label: "call stack: first char per frame", dir: "col", cells }
              : { label: "call stack: first char per frame", dir: "col", cells: [cell("∅", "idle", "empty")] };
          };
          const origTrack = (consumed, focus) =>
            track("original string", chars, chars.map((_, i) =>
              i < consumed ? "done" : i === focus ? "read" : "idle"));
          const resultTrack = (text, state) => ({
            label: "returned so far",
            cells: text === ""
              ? [cell("—", "idle", "nothing yet")]
              : Array.from(text).map((ch, i) => cell(ch, i === text.length - 1 ? (state || "read") : "done", i === text.length - 1 ? "just added" : undefined)),
          });
          steps.push({
            title: `Call reverse("${briefStr(s)}") on ${L} character${L === 1 ? "" : "s"}`,
            tracks: [origTrack(0, 0), stackTrack(0), resultTrack("")],
            counters: [count("depth", 1), count("chars returned", 0, L)],
            legend: ["read", "active", "done", "result", "idle"],
            happened: `One frame enters the stack holding the whole string; its first character "${chars[0]}" must wait for the rest to be reversed.`,
            why: "Recursive reversal defers all work: the head cannot move to the back until every deeper call has finished.",
            codeLine: 6,
          });
          if (L === 1) {
            steps.push({
              title: `Base case: one character "${chars[0]}" is already reversed`,
              tracks: [origTrack(0, 0), stackTrack(0, "good"), resultTrack(chars[0], "read")],
              counters: [count("depth", 1), count("chars returned", 1, L)],
              legend: ["read", "good", "done", "result", "idle"],
              happened: "A single character needs no reversing — the frame returns it straight away.",
              why: "The base case is the pivot of the whole idea: the smallest string is its own reverse.",
              codeLine: 5,
            });
            steps.push({
              title: `Answer: ${s}`,
              tracks: [track("original string", chars, fill(L, "dim")), stackTrack(-1), resultTrack(chars[0], "result")],
              counters: [count("depth", 0), count("answer", chars[0])],
              legend: ["done", "result", "dim", "idle"],
              happened: `The only frame returns "${chars[0]}" — done.`,
              why: "Even the one-character case passes through the same machinery; nothing special had to be faked.",
              codeLine: 5,
            });
            return steps;
          }
          const DRAW = 12;
          for (let d = 1; d <= Math.min(L - 1, DRAW); d++) {
            steps.push({
              title: `Strip "${chars[d - 1]}" — call reverse on the ${L - d}-char tail`,
              tracks: [origTrack(d, d), stackTrack(d), resultTrack("")],
              counters: [count("depth", d + 1), count("chars returned", 0, L)],
              legend: ["read", "active", "done", "result", "idle"],
              happened: `"${chars[d - 1]}" is parked in its frame while the call drops to "${briefStr(s.slice(d))}".`,
              why: "Each descent peels exactly one character; the pending work is literally the stack of waiting heads.",
              codeLine: 6,
            });
          }
          if (L - 1 > DRAW) {
            steps.push({
              title: `…the same peel repeats down to the last character`,
              tracks: [origTrack(L - 1, L - 1), stackTrack(L - 1), resultTrack("")],
              counters: [count("depth", L), count("chars returned", 0, L)],
              legend: ["read", "active", "done", "result", "idle"],
              happened: `The stack now holds one frame per character: ${L} heads waiting for a tail that is about to run out.`,
              why: "Depth equals length — the shape of the recursion is a simple straight line.",
              codeLine: 6,
            });
          }
          steps.push({
            title: `Base case: "${chars[L - 1]}" returns itself`,
            tracks: [origTrack(L, -1), stackTrack(L - 1, "good"), resultTrack(chars[L - 1], "read")],
            counters: [count("depth", L), count("chars returned", 1, L)],
            legend: ["read", "good", "done", "result", "idle"],
            happened: `The deepest tail is a single character "${chars[L - 1]}" — trivially reversed, so it is the first value handed back.`,
            why: "From here every step is an unwind; the descent bought the right to start appending.",
            codeLine: 5,
          });
          let done = chars[L - 1];
          const chunk = Math.ceil((L - 1) / 8);
          for (let u = 1; u <= L - 1; u++) {
            done += chars[L - 1 - u];
            if (u % chunk !== 0 && u !== L - 1) continue;
            const depthLeft = L - 1 - u;
            steps.push({
              title: `Unwind: "${chars[L - 1 - u]}" joins the end → "${briefStr(done)}"`,
              tracks: [
                track("original string", chars, chars.map((_, i) => (i <= depthLeft ? (i === depthLeft ? "read" : "done") : "dim"))),
                stackTrack(Math.max(depthLeft, -1), depthLeft >= 0 ? "done" : "idle"),
                resultTrack(done, "read"),
              ],
              counters: [count("depth", depthLeft + 1), count("chars returned", done.length, L)],
              legend: ["read", "done", "result", "dim", "idle"],
              happened: `The frame that was waiting on "${chars[L - 1 - u]}" gets its answer back and appends itself to the end: ${briefStr(done)}.`,
              why: "First in, last out — the character that waited longest is appended last, which is exactly a reversal.",
              codeLine: 7,
            });
          }
          const rev = done;
          steps.push({
            title: `Answer: ${rev}`,
            tracks: [
              track("original string", chars, fill(L, "dim")),
              stackTrack(-1),
              resultTrack(done, "result"),
            ],
            counters: [count("depth", 0), count("answer", capStr(rev, 24))],
            legend: ["done", "result", "dim", "idle"],
            happened: `Every frame has returned; the string reads "${capStr(rev, 24)}" — the original turned end to end.`,
            why: "The stack did the reversing for free: last character out of the base case, first character appended… in reverse order.",
            codeLine: 7,
          });
          return steps;
        },
      },
    ],
  });

  /* =========================================================== */
  V.register({
    id: "merge-sort",
    title: "Merge Sort",
    category: "Sorting Algorithms",
    difficulty: "Intermediate",
    description: "Split the row into single elements, then merge sorted runs back together.",
    input: { label: "The numbers", default: "38, 27, 43, 3, 9, 82, 10", parse: "ints" },
    approaches: [
      {
        name: "Split, then Merge",
        complexity: "O(n log n) time, O(n) extra space",
        idea: [
          "A one-element run is already sorted. Split the row in half, sort each half the same way, then merge the two sorted halves by repeatedly taking the smaller front element.",
          "The splitting builds a tree of halves; the merging rebuilds the sorted row from the leaves upward. Every merge touches its own values exactly once.",
        ],
        problem: [
          "Merging needs a scratch buffer as big as the range being merged — O(n) extra space, unlike quick sort. On the other hand the O(n log n) bound holds no matter how the input is ordered.",
        ],
        code: {
          c: `#include <stdio.h>

/* merge a[lo..mid) and a[mid..hi) through tmp[] */
static void merge(int *a, int lo, int mid, int hi, int *tmp) {
    int i = lo, j = mid, k = lo;
    while (i < mid && j < hi)
        tmp[k++] = (a[i] <= a[j]) ? a[i++] : a[j++];
    while (i < mid) tmp[k++] = a[i++];
    while (j < hi)  tmp[k++] = a[j++];
    for (i = lo; i < hi; i++) a[i] = tmp[i];
}

static void msort(int *a, int lo, int hi, int *tmp) {
    if (hi - lo <= 1) return;             /* 0 or 1 item: sorted */
    int mid = lo + (hi - lo) / 2;
    msort(a, lo, mid, tmp);               /* sort the left half */
    msort(a, mid, hi, tmp);               /* sort the right half */
    merge(a, lo, mid, hi, tmp);           /* glue them together */
}

void merge_sort(int *a, int n) {
    int tmp[n];                           /* scratch space (C99) */
    msort(a, 0, n, tmp);
}

int main(void) {
    int a[] = {38, 27, 43, 3, 9, 82, 10};
    merge_sort(a, 7);
    for (int i = 0; i < 7; i++) printf("%d ", a[i]); /* 3 9 10 27 38 43 82 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// glue two sorted halves into one sorted range
void mergeRuns(std::vector<int>& a, int lo, int mid, int hi) {
    std::vector<int> out;
    int i = lo, j = mid;
    while (i < mid && j < hi)
        out.push_back(a[i] <= a[j] ? a[i++] : a[j++]);
    while (i < mid) out.push_back(a[i++]);
    while (j < hi) out.push_back(a[j++]);
    for (int k = 0; k < (int)out.size(); ++k) a[lo + k] = out[k];
}

void mergeSort(std::vector<int>& a, int lo, int hi) {
    if (hi - lo <= 1) return;            // 0 or 1 item is sorted
    int mid = lo + (hi - lo) / 2;
    mergeSort(a, lo, mid);
    mergeSort(a, mid, hi);
    mergeRuns(a, lo, mid, hi);
}

int main() {
    std::vector<int> a{38, 27, 43, 3, 9, 82, 10};
    mergeSort(a, 0, (int)a.size());
    for (int x : a) std::cout << x << ' '; // 3 9 10 27 38 43 82
}`,
        },
        steps(nums) {
          const arr = nums.slice();
          const n = arr.length;
          const steps = [];
          let splits = 0, merges = 0, placed = 0;
          const cellStateFor = (i, lo, hi, kind) => {
            if (i >= lo && i < hi) return kind;
            return "idle";
          };
          const wholeTrack = (lo, hi, leftState, rightState, segMid) =>
            track("the numbers", arr.slice(), arr.map((_, i) => {
              if (i < lo || i >= hi) return "idle";
              if (segMid == null) return leftState;
              return i < segMid ? leftState : rightState;
            }));
          steps.push({
            title: `Set up: ${n} number${n === 1 ? "" : "s"} to sort`,
            tracks: [track("the numbers", arr.slice(), fill(n, "idle"))],
            counters: [count("numbers", n), count("runs", 1)],
            legend: ["read", "done", "active", "compare", "result", "idle"],
            happened: `Merge sort starts from the top: the whole row [${brief(arr, 6)}] is treated as one unsorted run.`,
            why: "The plan is to cut until every run has one element — those are sorted by definition — and then merge upward.",
            codeLine: 13,
          });
          if (n <= 1) {
            steps.push({
              title: "Answer: a single element is already sorted",
              tracks: [track("the numbers", arr.slice(), fill(n, "result"))],
              counters: [count("numbers", n), count("answer", brief(arr, 6))],
              legend: ["result", "done", "idle"],
              happened: n === 1 ? `There is only ${arr[0]} — nothing to split and nothing to merge.` : "The row is empty, so the sorted result is empty too.",
              why: "The base case of merge sort is exactly this: zero or one element needs no work.",
              codeLine: 13,
            });
            return steps;
          }
          const msort = (lo, hi) => {
            if (hi - lo <= 1) return;
            const mid = lo + ((hi - lo) >> 1);
            splits++;
            steps.push({
              title: `Split [${brief(arr.slice(lo, hi))}] → [${brief(arr.slice(lo, mid))}] | [${brief(arr.slice(mid, hi))}]`,
              tracks: [wholeTrack(lo, hi, "active", "compare", mid)],
              counters: [count("splits", splits), count("current run", arr.slice(lo, hi).length, n)],
              legend: ["read", "active", "compare", "result", "idle"],
              happened: `The run of ${hi - lo} values is cut at index ${mid}: a left half of ${mid - lo} and a right half of ${hi - mid}.`,
              why: "Halving is what keeps the depth at log₂ n — each level of the split tree is one division wider.",
              codeLine: 14,
            });
            msort(lo, mid);
            msort(mid, hi);
            const L = arr.slice(lo, mid);
            const R = arr.slice(mid, hi);
            const M = [];
            let i = 0, j = 0;
            while (i < L.length && j < R.length) {
              if (L[i] <= R[j]) M.push(L[i++]); else M.push(R[j++]);
            }
            while (i < L.length) M.push(L[i++]);
            while (j < R.length) M.push(R[j++]);
            for (let k = 0; k < M.length; k++) arr[lo + k] = M[k];
            merges++;
            placed += M.length;
            steps.push({
              title: `Merge [${brief(L)}] + [${brief(R)}] → [${brief(M)}]`,
              tracks: [
                wholeTrack(lo, hi, "result", "result", mid),
                track("left run", L, fill(L.length, "done")),
                track("right run", R, fill(R.length, "done")),
                track("merged run", M, paint(fill(M.length, "done"), { [M.length - 1]: "result" })),
              ],
              counters: [count("merges done", merges), count("values placed", placed, n)],
              legend: ["read", "done", "result", "idle"],
              happened: `Both runs are already sorted, so the merge peels the smaller front value each time until [${brief(M)}] is complete.`,
              why: "A merge of two sorted runs is linear: only the two front elements ever compete, and each value moves once.",
              codeLine: 6,
            });
          };
          msort(0, n);
          steps.push({
            title: `Answer: [${brief(arr, 6)}]`,
            tracks: [track("the numbers", arr.slice(), fill(n, "good"))],
            counters: [count("splits", splits), count("merges done", merges), count("answer", brief(arr, 6))],
            legend: ["good", "result", "done", "idle"],
            happened: `Every run has been merged back into one sorted row: ${arr.join(", ")}.`,
            why: "Split depth is log₂ n and each level merges n values total — that is the O(n log n) bound.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* =========================================================== */
  V.register({
    id: "quick-sort",
    title: "Quick Sort",
    category: "Sorting Algorithms",
    difficulty: "Intermediate",
    description: "Choose a pivot, push smaller values left and bigger ones right, then sort each side.",
    input: { label: "The numbers", default: "38, 27, 43, 3, 9, 82, 10", parse: "ints" },
    approaches: [
      {
        name: "Lomuto Partition (last pivot)",
        complexity: "O(n log n) average, O(n²) worst, O(log n) stack",
        idea: [
          "Take the last element as the pivot. Walk a scanner j across the range; whenever a value is ≤ the pivot, swap it to the front of a growing 'small values' zone (index i) and advance i.",
          "At the end, swap the pivot into slot i. Everything left of i is ≤ pivot, everything right is > pivot, so the pivot is in its final sorted position. Recurse on both sides.",
        ],
        problem: [
          "On already-sorted input the last element is the largest each time, so the split is maximally lopsided and the work degrades to O(n²). Duplicates also enlarge the 'small' side unfairly.",
        ],
        code: {
          c: `#include <stdio.h>

static void swap(int *a, int *b) { int t = *a; *a = *b; *b = t; }

/* Lomuto: pivot is the last element */
static int partition(int *a, int lo, int hi) {
    int pivot = a[hi];
    int i = lo;                     /* first slot of the "<= pivot" zone */
    for (int j = lo; j < hi; j++) {
        if (a[j] <= pivot) {
            swap(&a[i], &a[j]);
            i++;
        }
    }
    swap(&a[i], &a[hi]);            /* pivot lands in its final slot */
    return i;
}

static void quick(int *a, int lo, int hi) {
    if (lo >= hi) return;
    int p = partition(a, lo, hi);
    quick(a, lo, p - 1);            /* strictly smaller zone */
    quick(a, p + 1, hi);            /* strictly bigger zone */
}

int main(void) {
    int a[] = {38, 27, 43, 3, 9, 82, 10};
    quick(a, 0, 6);
    for (int i = 0; i < 7; i++) printf("%d ", a[i]); /* 3 9 10 27 38 43 82 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <utility>

// Lomuto partition with the last element as pivot
int partitionLomuto(std::vector<int>& a, int lo, int hi) {
    int pivot = a[hi];
    int i = lo;                     // next slot for a small value
    for (int j = lo; j < hi; ++j)
        if (a[j] <= pivot)
            std::swap(a[i++], a[j]);
    std::swap(a[i], a[hi]);         // pivot to its final place
    return i;
}

void quickSort(std::vector<int>& a, int lo, int hi) {
    if (lo >= hi) return;
    int p = partitionLomuto(a, lo, hi);
    quickSort(a, lo, p - 1);
    quickSort(a, p + 1, hi);
}

int main() {
    std::vector<int> a{38, 27, 43, 3, 9, 82, 10};
    quickSort(a, 0, (int)a.size() - 1);
    for (int x : a) std::cout << x << ' '; // 3 9 10 27 38 43 82
}`,
        },
        steps(nums) {
          const arr = nums.slice();
          const n = arr.length;
          const steps = [];
          const placed = new Array(n).fill(false);
          let swaps = 0, partitions = 0;
          const view = (segLo, segHi, i, j, pivIdx) =>
            track("the numbers", arr.slice(), arr.map((_, idx) => {
              if (placed[idx]) return "result";
              if (idx === pivIdx) return "compare";
              if (idx === j) return "read";
              if (idx === i) return "active";
              if (idx >= segLo && idx < i) return "done";
              return "idle";
            }), arr.map((_, idx) => {
              if (placed[idx]) return "final";
              if (idx === pivIdx) return "pivot";
              if (idx === j) return "j";
              if (idx === i) return "i";
              return undefined;
            }));
          steps.push({
            title: "Set up: pick a pivot, split, repeat",
            tracks: [track("the numbers", arr.slice(), fill(n, "idle"))],
            counters: [count("partitions", 0), count("swaps", 0)],
            legend: ["read", "active", "compare", "done", "result", "idle"],
            happened: `The whole row [${brief(arr, 6)}] is one unsorted range. Each round will make at least one value final.`,
            why: "Quick sort divides around a pivot instead of merging halves: after a partition, the pivot never needs to move again.",
            codeLine: 6,
          });
          const qs = (lo, hi) => {
            if (lo > hi) return;
            if (lo === hi) {
              placed[lo] = true;
              steps.push({
                title: `Single value ${arr[lo]} at index ${lo} — already final`,
                tracks: [view(lo, lo, lo, -1, -1)],
                counters: [count("partitions", partitions), count("swaps", swaps)],
                legend: ["result", "done", "idle"],
                happened: `A range with one element cannot be out of order, so ${arr[lo]} is declared finished.`,
                why: "The recursion's base case is a range of size 0 or 1 — nothing left to partition.",
                codeLine: 19,
              });
              return;
            }
            const pivIdx = hi;
            const pivot = arr[hi];
            partitions++;
            steps.push({
              title: `Partition [${brief(arr.slice(lo, hi + 1))}] around pivot ${pivot}`,
              tracks: [view(lo, hi, lo, lo, pivIdx)],
              counters: [count("partitions", partitions), count("pivot", pivot), count("swaps", swaps)],
              legend: ["read", "active", "compare", "done", "result", "idle"],
              happened: `Range ${lo}…${hi} is chosen, and its last element ${pivot} is the pivot. Scanner j starts at ${lo}, boundary i at ${lo}.`,
              why: "The zone left of i will hold values ≤ pivot; the region from i to j is still under inspection.",
              codeLine: 6,
            });
            let i = lo;
            for (let j = lo; j < hi; j++) {
              const v = arr[j];
              if (v <= pivot) {
                if (i !== j) {
                  [arr[i], arr[j]] = [arr[j], arr[i]];
                  swaps++;
                  steps.push({
                    title: `${v} ≤ ${pivot} → swap into slot ${i}`,
                    tracks: [view(lo, hi, i, j, pivIdx)],
                    counters: [count("i (≤ boundary)", i), count("j (scanner)", j), count("pivot", pivot), count("swaps", swaps)],
                    legend: ["read", "active", "compare", "done", "result", "idle"],
                    happened: `The scanner found ${v}, which belongs on the small side. It trades places with ${arr[i]} at index ${i}, and the small zone grows.`,
                    why: "Every value ≤ pivot is swept to the left in scanner order, keeping the zone sorted-by-arrival rather than by value.",
                    codeLine: 10,
                  });
                } else {
                  steps.push({
                    title: `${v} ≤ ${pivot} → extend the small zone`,
                    tracks: [view(lo, hi, i, j, pivIdx)],
                    counters: [count("i (≤ boundary)", i), count("j (scanner)", j), count("pivot", pivot), count("swaps", swaps)],
                    legend: ["read", "active", "compare", "done", "result", "idle"],
                    happened: `${v} is small and already sits at the boundary, so nothing moves — the zone simply takes it in.`,
                    why: "i and j coincide here, which means every element seen so far was small; skipping the swap saves pointless work.",
                    codeLine: 9,
                  });
                }
                i++;
              } else {
                steps.push({
                  title: `${v} > ${pivot} → leave it on the right`,
                  tracks: [view(lo, hi, i, j, pivIdx)],
                  counters: [count("i (≤ boundary)", i), count("j (scanner)", j), count("pivot", pivot), count("swaps", swaps)],
                  legend: ["read", "active", "compare", "done", "result", "idle"],
                  happened: `${v} is bigger than the pivot, so it stays where it is; only j advances.`,
                  why: "Big values need no action now — they will end up on the right of the pivot automatically.",
                  codeLine: 9,
                });
              }
            }
            if (i !== pivIdx) {
              [arr[i], arr[pivIdx]] = [arr[pivIdx], arr[i]];
              swaps++;
            }
            placed[i] = true;
            steps.push({
              title: `Pivot ${pivot} lands at index ${i} — final position`,
              tracks: [view(lo, hi, i, -1, i)],
              counters: [count("partitions", partitions), count("values final", placed.filter(Boolean).length), count("swaps", swaps)],
              legend: ["result", "compare", "done", "idle"],
              happened: `The pivot swaps with the value at slot ${i}: everything to its left is ≤ ${pivot}, everything to its right is > ${pivot}.`,
              why: "That split is the whole promise of a partition — the pivot can never move again, and both sides shrink.",
              codeLine: 14,
            });
            qs(lo, i - 1);
            qs(i + 1, hi);
          };
          qs(0, n - 1);
          steps.push({
            title: `Answer: [${brief(arr, 6)}]`,
            tracks: [track("the numbers", arr.slice(), fill(n, "good"))],
            counters: [count("partitions", partitions), count("swaps", swaps), count("answer", brief(arr, 6))],
            legend: ["good", "result", "done", "idle"],
            happened: `Every pivot has settled and every single-value range is closed — the row reads ${arr.join(", ")}.`,
            why: "Each element became a pivot once at most, so the total work per level is linear in the range size.",
            codeLine: 20,
          });
          return steps;
        },
      },
      {
        name: "Hoare Partition (middle pivot)",
        complexity: "O(n log n) average, O(n²) worst, O(log n) stack",
        idea: [
          "Pick the middle value as the pivot. Walk i right while values are smaller than it, walk j left while values are larger, then swap the two offenders and keep going.",
          "When i and j cross, the range is split at j: no value left of the split exceeds anything right of it. Recurse on (lo, j) and (j+1, hi).",
        ],
        problem: [
          "Unlike Lomuto, Hoare's version does not fix the pivot in place — the split point is between two elements, so there is no single 'done' position per partition. Correct loop bounds matter too, or the recursion can repeat forever.",
        ],
        code: {
          c: `#include <stdio.h>

static void swap(int *a, int *b) { int t = *a; *a = *b; *b = t; }

/* Hoare: scan inward from both ends around the middle value */
static int partition(int *a, int lo, int hi) {
    int pivot = a[lo + (hi - lo) / 2];
    int i = lo - 1, j = hi + 1;
    for (;;) {
        do { i++; } while (a[i] < pivot);
        do { j--; } while (a[j] > pivot);
        if (i >= j) return j;
        swap(&a[i], &a[j]);
    }
}

static void quick(int *a, int lo, int hi) {
    if (lo >= hi) return;
    int p = partition(a, lo, hi);
    quick(a, lo, p);                /* note: p stays on the left */
    quick(a, p + 1, hi);
}

int main(void) {
    int a[] = {38, 27, 43, 3, 9, 82, 10};
    quick(a, 0, 6);
    for (int i = 0; i < 7; i++) printf("%d ", a[i]); /* 3 9 10 27 38 43 82 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <utility>

// Hoare split around the middle value
int partitionHoare(std::vector<int>& a, int lo, int hi) {
    int pivot = a[lo + (hi - lo) / 2];
    int i = lo - 1, j = hi + 1;
    for (;;) {
        do { ++i; } while (a[i] < pivot);
        do { --j; } while (a[j] > pivot);
        if (i >= j) return j;
        std::swap(a[i], a[j]);
    }
}

void quickSort(std::vector<int>& a, int lo, int hi) {
    if (lo >= hi) return;
    int p = partitionHoare(a, lo, hi);
    quickSort(a, lo, p);            // p belongs to the left part
    quickSort(a, p + 1, hi);
}

int main() {
    std::vector<int> a{38, 27, 43, 3, 9, 82, 10};
    quickSort(a, 0, (int)a.size() - 1);
    for (int x : a) std::cout << x << ' '; // 3 9 10 27 38 43 82
}`,
        },
        steps(nums) {
          const arr = nums.slice();
          const n = arr.length;
          const steps = [];
          const placed = new Array(n).fill(false);
          let swaps = 0, partitions = 0;
          const view = (segLo, segHi, i, j, pivIdx) =>
            track("the numbers", arr.slice(), arr.map((_, idx) => {
              if (placed[idx]) return "result";
              if (idx === pivIdx) return "compare";
              if (idx === i) return "read";
              if (idx === j) return "active";
              if (idx >= segLo && idx < i) return "done";
              if (idx > j && idx <= segHi) return "done";
              return "idle";
            }), arr.map((_, idx) => {
              if (placed[idx]) return "final";
              if (idx === pivIdx) return "pivot slot";
              if (idx === i) return "i";
              if (idx === j) return "j";
              return undefined;
            }));
          steps.push({
            title: "Set up: two scanners move inward",
            tracks: [track("the numbers", arr.slice(), fill(n, "idle"))],
            counters: [count("partitions", 0), count("swaps", 0)],
            legend: ["read", "active", "compare", "done", "result", "idle"],
            happened: `The whole row [${brief(arr, 6)}] is one unsorted range; Hoare's partition will be applied to it first.`,
            why: "Hoare's split leaves the pivot value free to move — only the crossing point matters, which is why each round is guaranteed progress.",
            codeLine: 6,
          });
          const qs = (lo, hi) => {
            if (lo > hi) return;
            if (lo === hi) {
              placed[lo] = true;
              steps.push({
                title: `Single value ${arr[lo]} at index ${lo} — final`,
                tracks: [view(lo, lo, lo, lo, -1)],
                counters: [count("partitions", partitions), count("swaps", swaps)],
                legend: ["result", "done", "idle"],
                happened: `A one-element range is sorted by definition, so ${arr[lo]} is done.`,
                why: "Both quick-sort variants stop recursing when a range has fewer than two elements.",
                codeLine: 17,
              });
              return;
            }
            const mid = lo + ((hi - lo) >> 1);
            const pivot = arr[mid];
            partitions++;
            steps.push({
              title: `Split [${brief(arr.slice(lo, hi + 1))}] around pivot ${pivot}`,
              tracks: [view(lo, hi, lo, hi, mid)],
              counters: [count("partitions", partitions), count("pivot", pivot), count("swaps", swaps)],
              legend: ["read", "active", "compare", "done", "result", "idle"],
              happened: `Range ${lo}…${hi}: the middle slot ${mid} holds the pivot value ${pivot}. i starts at ${lo}, j at ${hi}.`,
              why: "Starting the scanners at the ends lets each side collect values that belong on the other side.",
              codeLine: 6,
            });
            let i = lo, j = hi;
            for (;;) {
              while (i < hi && arr[i] < pivot) {
                i++;
                steps.push({
                  title: `arr[${i - 1}] = ${arr[i - 1]} < ${pivot} → i moves right`,
                  tracks: [view(lo, hi, i, j, mid)],
                  counters: [count("i", i), count("j", j), count("pivot", pivot), count("swaps", swaps)],
                  legend: ["read", "active", "compare", "done", "result", "idle"],
                  happened: `Index ${i - 1} already holds a small value, so i can safely step over it to ${i}.`,
                  why: "Values below the pivot need no action from the left scanner — they are where they belong.",
                  codeLine: 9,
                });
              }
              while (j > lo && arr[j] > pivot) {
                j--;
                steps.push({
                  title: `arr[${j + 1}] = ${arr[j + 1]} > ${pivot} → j moves left`,
                  tracks: [view(lo, hi, i, j, mid)],
                  counters: [count("i", i), count("j", j), count("pivot", pivot), count("swaps", swaps)],
                  legend: ["read", "active", "compare", "done", "result", "idle"],
                  happened: `Index ${j + 1} already holds a big value, so j steps over it to ${j}.`,
                  why: "The right scanner only stops on values that are too small for the right side.",
                  codeLine: 10,
                });
              }
              if (i >= j) {
                steps.push({
                  title: `Scanners cross at ${i} / ${j} — split after index ${j}`,
                  tracks: [view(lo, hi, i, j, mid)],
                  counters: [count("i", i), count("j", j), count("split point", j), count("swaps", swaps)],
                  legend: ["read", "active", "compare", "done", "result", "idle"],
                  happened: `i = ${i} and j = ${j}; every value left of j is ≤ ${pivot} and every value right of i is ≥ ${pivot}.`,
                  why: "The crossing is the split: no element on one side can be bigger than an element on the other, so each side can be sorted independently.",
                  codeLine: 11,
                });
                break;
              }
              const aAt = arr[i], bAt = arr[j];
              [arr[i], arr[j]] = [arr[j], arr[i]];
              swaps++;
              steps.push({
                title: `Swap ${aAt} ⇄ ${bAt}: both are on the wrong side`,
                tracks: [view(lo, hi, i, j, mid)],
                counters: [count("i", i), count("j", j), count("pivot", pivot), count("swaps", swaps)],
                legend: ["read", "active", "compare", "done", "result", "idle"],
                happened: `${aAt} at index ${i} is too big for the left, ${bAt} at ${j} is too small for the right — trading them fixes both.`,
                why: "One swap can settle two misplaced values at once, which is why Hoare tends to move less data than Lomuto.",
                codeLine: 12,
              });
              i++;
              j--;
            }
            qs(lo, j);
            qs(j + 1, hi);
          };
          qs(0, n - 1);
          steps.push({
            title: `Answer: [${brief(arr, 6)}]`,
            tracks: [track("the numbers", arr.slice(), fill(n, "good"))],
            counters: [count("partitions", partitions), count("swaps", swaps), count("answer", brief(arr, 6))],
            legend: ["good", "result", "done", "idle"],
            happened: `All ranges are closed; the row reads ${arr.join(", ")}.`,
            why: "Every split shrinks both sides, so the recursion is finite — the crossing point is always at least one step in.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

})();
