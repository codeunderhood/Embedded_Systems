/* ============================================================
   DSA Visuals - NeetCode 250 additions, trees and backtracking
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, binaryTree } = window.H;
  const V = window.VIZ;

  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const show = (a) => "[" + a.join(", ") + "]";
  const toVal = (t) => {
    if (t == null) return null;
    const s = String(t).trim();
    if (!s || s.toLowerCase() === "null" || s === "-") return null;
    const n = Number(s);
    return Number.isFinite(n) ? n : s;
  };
  const treeFrom = (text) => binaryTree(String(text || "").split(/[\s,]+/).filter(Boolean).map(toVal));
  const cloneTree = (n) => (n ? { id: n.id, v: n.v, l: cloneTree(n.l), r: cloneTree(n.r) } : null);
  function collect(root) {
    const out = [];
    (function walk(n) { if (!n) return; out.push(n); walk(n.l); walk(n.r); })(root);
    return out;
  }
  const treeStates = (root, current, visited, extra) => {
    const m = {};
    for (const n of collect(root)) m[n.id] = visited.has(n.id) ? "done" : "idle";
    if (current) m[current] = "read";
    return Object.assign(m, extra || {});
  };

  function traversalViz(id, title, order) {
    V.register({
      id,
      title,
      category: "Trees",
      difficulty: "Beginner",
      description: "Walk a binary tree in " + order + " order and collect the node values.",
      input: { label: "Tree (level order, null = gap)", default: "1, null, 2, 3", parse: "tokens" },
      approaches: [
        {
          name: order.charAt(0).toUpperCase() + order.slice(1) + " Recursion",
          complexity: "O(n) time, O(h) call stack",
          idea: [
            "A traversal is defined by when the current node is recorded relative to its children.",
            order === "inorder" ? "Inorder goes left, records the node, then goes right. In a BST this order is sorted." : order === "preorder" ? "Preorder records the node first, then explores the left and right subtrees." : "Postorder explores both children first and records the node last, so children are finished before their parent.",
          ],
          problem: ["Recursion uses a call stack proportional to the tree height, which can be n for a completely skewed tree."],
          code: {
            c: order === "inorder"
              ? `void inorder(struct Node* n, int* out, int* k) {
    if (!n) return;
    inorder(n->left, out, k);
    out[(*k)++] = n->val;
    inorder(n->right, out, k);
}`
              : order === "preorder"
              ? `void preorder(struct Node* n, int* out, int* k) {
    if (!n) return;
    out[(*k)++] = n->val;
    preorder(n->left, out, k);
    preorder(n->right, out, k);
}`
              : `void postorder(struct Node* n, int* out, int* k) {
    if (!n) return;
    postorder(n->left, out, k);
    postorder(n->right, out, k);
    out[(*k)++] = n->val;
}`,
            cpp: order === "inorder"
              ? `void inorder(TreeNode* n, vector<int>& out) {
    if (!n) return;
    inorder(n->left, out);
    out.push_back(n->val);
    inorder(n->right, out);
}`
              : order === "preorder"
              ? `void preorder(TreeNode* n, vector<int>& out) {
    if (!n) return;
    out.push_back(n->val);
    preorder(n->left, out);
    preorder(n->right, out);
}`
              : `void postorder(TreeNode* n, vector<int>& out) {
    if (!n) return;
    postorder(n->left, out);
    postorder(n->right, out);
    out.push_back(n->val);
}`,
          },
          steps(tokens) {
            const root = treeFrom(tokens.join(","));
            const out = [];
            if (!root) return [{ title: "Empty tree", tracks: [chips("values", [], "idle")], counters: [count("visited", 0)], happened: "There are no nodes to visit.", why: "The traversal of an empty tree is empty.", legend: LEG }];
            const visited = new Set();
            const answer = [];
            const firstStates = {};
            for (const n of collect(root)) firstStates[n.id] = "idle";
            firstStates[root.id] = "read";
            out.push({
              title: `Start ${order} at the root ${root.v}`,
              kind: "tree", tree: root, nodeStates: firstStates, label: order + " walk",
              counters: [count("visited", 0, collect(root).length), count("next value", "-")],
              happened: `The root is ${root.v}; its children will be explored according to the ${order} rule.`,
              why: "The order of recording a node relative to its children is what distinguishes the three traversals.",
              legend: LEG,
              codeLine: 2,
            });
            const walk = (n) => {
              if (!n) return;
              if (order === "preorder") record(n);
              walk(n.l);
              if (order === "inorder") record(n);
              walk(n.r);
              if (order === "postorder") record(n);
            };
            const record = (n) => {
              visited.add(n.id);
              answer.push(n.v);
              out.push({
                title: `Record ${n.v}`,
                kind: "tree", tree: root, nodeStates: treeStates(root, n.id, visited), label: answer.join(" -> "),
                counters: [count("visited", answer.length, collect(root).length), count("last value", n.v)],
                happened: `${n.v} is appended to the traversal.`,
                why: order === "inorder" ? "Left descendants were already handled, so the node comes next." : order === "preorder" ? "The node is handled before descending into its subtrees." : "Both subtrees were already handled before this node.",
                legend: LEG,
                codeLine: order === "inorder" ? 4 : order === "preorder" ? 3 : 5,
              });
            };
            walk(root);
            out.push({
              title: `Traversal: ${answer.join(", ")}`,
              kind: "tree", tree: root, nodeStates: treeStates(root, null, visited), label: "complete: " + answer.join(", "),
              counters: [count("visited", answer.length, collect(root).length)],
              happened: `The ${order} sequence is ${answer.join(", ")}.`,
              why: "Every node was recorded exactly once in the required order.",
              legend: LEG,
              codeLine: 7,
            });
            return out;
          },
        },
      ],
    });
  }

  traversalViz("binary-tree-inorder-traversal", "Binary Tree Inorder Traversal", "inorder");
  traversalViz("binary-tree-preorder-traversal", "Binary Tree Preorder Traversal", "preorder");
  traversalViz("binary-tree-postorder-traversal", "Binary Tree Postorder Traversal", "postorder");

  /* ---------------------------------------------------------- */
  V.register({
    id: "subtree-of-a-binary-tree",
    title: "Subtree of Another Tree",
    category: "Trees",
    difficulty: "Beginner",
    description: "Check whether one tree appears as a complete subtree of another.",
    input: { label: "main tree | candidate subtree", default: "3,4,5,1,2,null,null | 4,1,2", parse: "string" },
    approaches: [
      {
        name: "Try Every Matching Root",
        complexity: "O(m * n) worst case, O(h) space",
        idea: [
          "A subtree must match a node and all of that node's descendants. First find every node in the main tree whose value equals the candidate root.",
          "For each such node, compare the two trees structurally and by value. A complete match means the candidate is a subtree.",
        ],
        problem: ["Repeated comparisons can revisit the same nodes many times when values repeat, leading to quadratic work."],
        code: {
          c: `#include <stdbool.h>

bool same(struct Node* a, struct Node* b) {
    if (!a || !b) return a == b;
    return a->val == b->val && same(a->left, b->left) && same(a->right, b->right);
}

bool isSubtree(struct Node* root, struct Node* sub) {
    if (!root) return false;
    if (same(root, sub)) return true;
    return isSubtree(root->left, sub) || isSubtree(root->right, sub);
}`,
          cpp: `#include <vector>
using namespace std;

bool same(TreeNode* a, TreeNode* b) {
    if (!a || !b) return a == b;
    return a->val == b->val && same(a->left, b->left) && same(a->right, b->right);
}

bool isSubtree(TreeNode* root, TreeNode* sub) {
    if (!root) return false;
    if (same(root, sub)) return true;
    return isSubtree(root->left, sub) || isSubtree(root->right, sub);
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const root = treeFrom(parts[0] || "");
          const sub = treeFrom(parts[1] || "");
          const out = [];
          if (!root || !sub) return [{ title: "One tree is empty", tracks: [chips("result", ["false"], "bad")], counters: [count("answer", "false")], happened: "A missing tree cannot contain a non-empty subtree.", why: "The empty tree has no root to compare.", legend: LEG }];
          const candidates = collect(root).filter((n) => n.v === sub.v);
          const firstStates = treeStates(root, null, new Set());
          for (const n of candidates) firstStates[n.id] = "compare";
          out.push({
            title: `Look for roots equal to ${sub.v}`,
            kind: "tree", tree: root, nodeStates: firstStates, label: "main tree; candidate root " + sub.v,
            counters: [count("candidate roots", candidates.length), count("matches found", 0)],
            happened: candidates.length ? `There are ${candidates.length} possible starting node(s).` : `No node has the candidate root value ${sub.v}.`,
            why: "A subtree must use the candidate's root value at its top.",
            legend: LEG,
            codeLine: 7,
          });
          const same = (a, b) => {
            if (!a || !b) return a === b;
            return a.v === b.v && same(a.l, b.l) && same(a.r, b.r);
          };
          let found = false;
          for (const n of candidates) {
            const ok = same(n, sub);
            const states = treeStates(root, n.id, new Set(), { [n.id]: ok ? "good" : "bad" });
            out.push({
              title: ok ? `Node ${n.v} matches completely` : `Node ${n.v} does not match`,
              kind: "tree", tree: root, nodeStates: states, label: "compare here; candidate root " + sub.v + (ok ? " matches" : " differs"),
              counters: [count("candidate roots", candidates.length), count("matches found", ok ? 1 : 0)],
              happened: ok ? "Every compared value and child position agrees." : "The candidate differs somewhere below this root.",
              why: "A subtree is an exact structural match, not just a shared root value.",
              legend: LEG,
              codeLine: 4,
            });
            if (ok) { found = true; break; }
          }
          out.push({
            title: found ? "The candidate is a subtree" : "The candidate is not a subtree",
            kind: "tree", tree: root, nodeStates: treeStates(root, null, new Set(), found ? { } : Object.fromEntries(collect(root).map((x) => [x.id, "dim"]))), label: "main tree",
            counters: [count("answer", found ? "true" : "false"), count("candidate roots", candidates.length)],
            happened: found ? "At least one starting node matched the full candidate tree." : "No candidate root produced a complete match.",
            why: "The search only succeeds when both shape and values agree.",
            legend: LEG,
            codeLine: 9,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "insert-into-a-binary-search-tree",
    title: "Insert into a Binary Search Tree",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Add a value while preserving the binary-search-tree ordering.",
    input: { label: "Tree | new value", default: "4,2,7,1,3 | 5", parse: "string" },
    approaches: [
      {
        name: "Walk to an Empty Child",
        complexity: "O(h) time, O(1) space",
        idea: [
          "Compare the new value with each node. Smaller values go left; larger values go right.",
          "The first empty child slot is exactly where the new node belongs. Attaching it there preserves every ordering rule.",
        ],
        problem: ["An unbalanced tree can have height n, so the walk can be linear in the worst case."],
        code: {
          c: `#include <stdlib.h>

struct Node* insert(struct Node* root, int val) {
    if (!root) {
        struct Node* n = malloc(sizeof(struct Node));
        n->val = val; n->left = n->right = NULL;
        return n;
    }
    if (val < root->val) root->left = insert(root->left, val);
    else root->right = insert(root->right, val);
    return root;
}`,
          cpp: `TreeNode* insertIntoBST(TreeNode* root, int val) {
    if (!root) return new TreeNode(val);
    if (val < root->val) root->left = insertIntoBST(root->left, val);
    else root->right = insertIntoBST(root->right, val);
    return root;
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const root = treeFrom(parts[0] || "");
          const value = toVal((parts[1] || "").split(/[\s,]+/)[0]);
          const out = [];
          if (!root) return [{ title: `Create root ${value}`, kind: "tree", tree: { id: "n0", v: value, l: null, r: null }, nodeStates: { n0: "result" }, label: "new root", counters: [count("inserted", value)], happened: "The tree was empty, so the new value becomes the root.", why: "An empty BST has no ordering constraint to violate.", legend: LEG }];
          let cur = root;
          const path = new Set();
          out.push({
            title: `Insert ${value}`,
            kind: "tree", tree: root, nodeStates: treeStates(root, root.id, path), label: "start at root",
            counters: [count("current", root.v), count("new value", value)],
            happened: `Start at root ${root.v}.`,
            why: "BST ordering lets each comparison discard one whole subtree.",
            legend: LEG,
            codeLine: 6,
          });
          while (true) {
            path.add(cur.id);
            const goLeft = value < cur.v;
            const next = goLeft ? cur.l : cur.r;
            const states = treeStates(root, null, path, { [cur.id]: "compare" });
            out.push({
              title: `${value} ${goLeft ? "<" : ">="} ${cur.v}; go ${goLeft ? "left" : "right"}`,
              kind: "tree", tree: root, nodeStates: states, label: goLeft ? "left branch" : "right branch",
              counters: [count("current", cur.v), count("direction", goLeft ? "left" : "right")],
              happened: next ? `The next node is ${next.v}.` : "That side is empty, so this is the insertion point.",
              why: "All values on the chosen side obey the BST ordering relative to the current node.",
              legend: LEG,
              codeLine: goLeft ? 7 : 8,
            });
            if (!next) break;
            cur = next;
          }
          const copy = cloneTree(root);
          const attach = (n) => {
            if (!n) return;
            if (value < n.v) {
              if (n.l) attach(n.l);
              else n.l = { id: "n-new", v: value, l: null, r: null };
            } else {
              if (n.r) attach(n.r);
              else n.r = { id: "n-new", v: value, l: null, r: null };
            }
          };
          attach(copy);
          out.push({
            title: `Attach ${value} as a new leaf`,
            kind: "tree", tree: copy, nodeStates: { ...treeStates(copy, null, new Set()), "n-new": "result" }, label: "inserted",
            counters: [count("inserted", value), count("tree size", collect(copy).length)],
            happened: `${value} is now a leaf below ${cur.v}.`,
            why: "A new leaf has no children, so it cannot break any existing subtree.",
            legend: LEG,
            codeLine: 5,
          });
          out.push({
            title: "BST ordering is preserved",
            kind: "tree", tree: copy, nodeStates: Object.fromEntries(collect(copy).map((n) => [n.id, n.id === "n-new" ? "result" : "good"])), label: "complete tree",
            counters: [count("tree size", collect(copy).length)],
            happened: "Every left descendant is smaller and every right descendant is larger than its parent.",
            why: "The new value followed the same comparisons that define the tree's order.",
            legend: LEG,
            codeLine: 9,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "delete-node-in-a-bst",
    title: "Delete Node in a BST",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Remove a key from a BST while keeping the search ordering.",
    input: { label: "Tree | key", default: "5,3,6,2,4,null,7 | 3", parse: "string" },
    approaches: [
      {
        name: "Find, Then Splice",
        complexity: "O(h) time, O(h) space",
        idea: [
          "Search for the key using BST comparisons. A missing key means nothing changes.",
          "A node with at most one child is replaced by that child. With two children, the smallest node in the right subtree is the successor: copy its value up, then delete that successor from the right subtree.",
        ],
        problem: ["The successor replacement preserves order but changes the shape of the tree; it is not the only valid deletion strategy."],
        code: {
          c: `struct Node* deleteNode(struct Node* root, int key) {
    if (!root) return NULL;
    if (key < root->val) root->left = deleteNode(root->left, key);
    else if (key > root->val) root->right = deleteNode(root->right, key);
    else {
        if (!root->left) return root->right;
        if (!root->right) return root->left;
        struct Node* s = root->right;
        while (s->left) s = s->left;
        root->val = s->val;
        root->right = deleteNode(root->right, s->val);
    }
    return root;
}`,
          cpp: `TreeNode* deleteNode(TreeNode* root, int key) {
    if (!root) return nullptr;
    if (key < root->val) root->left = deleteNode(root->left, key);
    else if (key > root->val) root->right = deleteNode(root->right, key);
    else {
        if (!root->left) return root->right;
        if (!root->right) return root->left;
        TreeNode* s = root->right;
        while (s->left) s = s->left;
        root->val = s->val;
        root->right = deleteNode(root->right, s->val);
    }
    return root;
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const root = treeFrom(parts[0] || "");
          const key = toVal((parts[1] || "").split(/[\s,]+/)[0]);
          const out = [];
          if (!root) return [{ title: "Empty tree", tracks: [chips("answer", ["unchanged"], "bad")], counters: [count("deleted", "none")], happened: "There is no node to delete.", why: "The key cannot be present in an empty tree.", legend: LEG }];
          let cur = root;
          const path = new Set();
          out.push({
            title: `Delete ${key}`,
            kind: "tree", tree: root, nodeStates: treeStates(root, root.id, path), label: "search",
            counters: [count("current", root.v), count("key", key)],
            happened: `Start the search at root ${root.v}.`,
            why: "BST comparisons lead directly toward the key.",
            legend: LEG,
            codeLine: 2,
          });
          while (cur && cur.v !== key) {
            path.add(cur.id);
            const goLeft = key < cur.v;
            out.push({
              title: `${key} ${goLeft ? "<" : ">"} ${cur.v}; go ${goLeft ? "left" : "right"}`,
              kind: "tree", tree: root, nodeStates: treeStates(root, null, path, { [cur.id]: "compare" }), label: "search path",
              counters: [count("current", cur.v), count("direction", goLeft ? "left" : "right")],
              happened: `The search moves to the ${goLeft ? "left" : "right"} child.`,
              why: "The ordering tells us the key cannot be on the other side.",
              legend: LEG,
              codeLine: goLeft ? 3 : 4,
            });
            cur = goLeft ? cur.l : cur.r;
          }
          if (!cur) {
            out.push({
              title: `${key} is not in the tree`,
              kind: "tree", tree: root, nodeStates: treeStates(root, null, path, { }), label: "no change",
              counters: [count("deleted", "none"), count("key", key)],
              happened: "The search fell off the tree.",
              why: "No node needed to be removed because the key was absent.",
              legend: LEG,
              codeLine: 5,
            });
            return out;
          }
          out.push({
            title: `Found ${key}`,
            kind: "tree", tree: root, nodeStates: treeStates(root, cur.id, path), label: "target",
            counters: [count("target", key), count("children", (cur.l ? 1 : 0) + (cur.r ? 1 : 0))],
            happened: `The node has ${(cur.l ? 1 : 0) + (cur.r ? 1 : 0)} child(ren).`,
            why: "The number of children determines how the node is removed.",
            legend: LEG,
            codeLine: 6,
          });
          const copy = cloneTree(root);
          const find = (n) => {
            if (!n) return null;
            if (n.v === key) return n;
            return key < n.v ? find(n.l) : find(n.r);
          };
          const target = find(copy);
          if (!target.l || !target.r) {
            const child = target.l || target.r;
            const replace = (n) => {
              if (!n) return null;
              if (n === target) return child;
              if (key < n.v) n.l = replace(n.l);
              else n.r = replace(n.r);
              return n;
            };
            const newRoot = replace(copy) || null;
            out.push({
              title: target.l ? "Replace the node with its left child" : "Replace the node with its right child",
              kind: "tree", tree: newRoot, nodeStates: treeStates(newRoot, null, new Set(), Object.fromEntries(collect(newRoot).map((n) => [n.id, child && n.id === child.id ? "result" : "done"]))), label: "spliced",
              counters: [count("deleted", key), count("tree size", collect(newRoot).length)],
              happened: "A node with at most one child can be replaced directly by that child.",
              why: "The child already respects every ordering relationship above the removed node.",
              legend: LEG,
              codeLine: target.l ? 7 : 8,
            });
          } else {
            let successor = target.r;
            while (successor.l) successor = successor.l;
            out.push({
              title: `Successor is ${successor.v}`,
              kind: "tree", tree: copy, nodeStates: treeStates(copy, target.id, new Set(), { [successor.id]: "result" }), label: "smallest on the right",
              counters: [count("target", key), count("successor", successor.v)],
              happened: `${successor.v} is the smallest value larger than ${key}.`,
              why: "The successor is the value that should take the removed node's place.",
              legend: LEG,
              codeLine: 10,
            });
            target.v = successor.v;
            const removeSuccessor = (n, val) => {
              if (!n) return null;
              if (val < n.v) n.l = removeSuccessor(n.l, val);
              else if (val > n.v) n.r = removeSuccessor(n.r, val);
              else return n.r;
              return n;
            };
            copy.r = removeSuccessor(copy.r, successor.v);
            out.push({
              title: `Copy ${successor.v} up and remove the successor`,
              kind: "tree", tree: copy, nodeStates: treeStates(copy, target.id, new Set(), { [target.id]: "result" }), label: "replaced",
              counters: [count("deleted", key), count("replacement", successor.v)],
              happened: "The target now holds the successor value, and the duplicate successor node is gone.",
              why: "The successor is larger than every left descendant and no larger than the remaining right values.",
              legend: LEG,
              codeLine: 11,
            });
          }
          out.push({
            title: "Deletion complete",
            kind: "tree", tree: copy, nodeStates: treeStates(copy, null, new Set(), Object.fromEntries(collect(copy).map((n) => [n.id, "good"]))), label: "BST",
            counters: [count("deleted", key), count("tree size", collect(copy).length)],
            happened: "The remaining tree still satisfies the BST property.",
            why: "Only an order-preserving replacement was used.",
            legend: LEG,
            codeLine: 13,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "count-good-nodes-in-binary-tree",
    title: "Count Good Nodes In Binary Tree",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Count nodes whose value is at least every value on the path from the root.",
    input: { label: "Tree (level order)", default: "3,1,4,3,null,1,5", parse: "tokens" },
    approaches: [
      {
        name: "Carry the Path Maximum",
        complexity: "O(n) time, O(h) call stack",
        idea: [
          "While walking down, pass along the largest value seen so far. A node is good when its value is at least that maximum.",
          "Then update the maximum with the node's value and continue into both children.",
        ],
        problem: ["A recursive solution needs stack space proportional to the depth; an explicit stack can avoid recursion."],
        code: {
          c: `#include <stdbool.h>

int dfs(struct Node* n, int best) {
    if (!n) return 0;
    int good = n->val >= best;
    if (n->val > best) best = n->val;
    return good + dfs(n->left, best) + dfs(n->right, best);
}

int goodNodes(struct Node* root) {
    return dfs(root, -1000000000);
}`,
          cpp: `#include <algorithm>
using namespace std;

int dfs(TreeNode* n, int best) {
    if (!n) return 0;
    int good = n->val >= best;
    best = max(best, n->val);
    return good + dfs(n->left, best) + dfs(n->right, best);
}

int goodNodes(TreeNode* root) {
    return dfs(root, -1000000000);
}`,
        },
        steps(tokens) {
          const root = treeFrom(tokens.join(","));
          const out = [];
          if (!root) return [{ title: "Empty tree", tracks: [chips("good nodes", [0], "result")], counters: [count("good", 0)], happened: "No nodes exist.", why: "An empty tree has zero good nodes.", legend: LEG }];
          const visited = new Set();
          let best = -Infinity;
          let good = 0;
          out.push({
            title: "Start with an infinitely small path maximum",
            kind: "tree", tree: root, nodeStates: { [root.id]: "read" }, label: "root",
            counters: [count("path max", "-inf"), count("good", 0)],
            happened: `The root is ${root.v}.`,
            why: "The root has no ancestors, so it is automatically good.",
            legend: LEG,
            codeLine: 2,
          });
          const walk = (n, pathMax) => {
            if (!n) return;
            const isGood = n.v >= pathMax;
            if (isGood) good++;
            visited.add(n.id);
            out.push({
              title: `${n.v} ${isGood ? "is" : "is not"} a good node`,
              kind: "tree", tree: root, nodeStates: treeStates(root, n.id, visited, { [n.id]: isGood ? "good" : "bad" }), label: "path max " + (pathMax === -Infinity ? "-inf" : pathMax),
              counters: [count("path max", pathMax === -Infinity ? "-inf" : pathMax), count("good", good)],
              happened: isGood ? `${n.v} is at least the previous maximum.` : `${n.v} is smaller than the previous maximum.`,
              why: "A node is good only if no ancestor on its path is larger.",
              legend: LEG,
              codeLine: 4,
            });
            const nextMax = Math.max(pathMax === -Infinity ? n.v : pathMax, n.v);
            walk(n.l, nextMax);
            walk(n.r, nextMax);
          };
          walk(root, -Infinity);
          out.push({
            title: `${good} good node(s)`,
            kind: "tree", tree: root, nodeStates: treeStates(root, null, visited), label: "complete",
            counters: [count("good", good), count("nodes", collect(root).length)],
            happened: `The traversal found ${good} node(s) that were never below an ancestor.`,
            why: "The path maximum summarizes all ancestors in one value.",
            legend: LEG,
            codeLine: 8,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "delete-leaves-with-a-given-value",
    title: "Delete Leaves With a Given Value",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Repeatedly remove leaf nodes equal to a target value.",
    input: { label: "Tree | target", default: "1,2,3,2,null,2,4 | 2", parse: "string" },
    approaches: [
      {
        name: "Postorder Pruning",
        complexity: "O(n) time, O(h) space",
        idea: [
          "Handle the children first. After they are pruned, the current node may have become a leaf.",
          "If the current node is now a leaf with the target value, return null so its parent drops it. Repeating this during the same postorder walk removes cascades automatically.",
        ],
        problem: ["The tree is modified in place; a caller that needs the old tree must keep a copy."],
        code: {
          c: `struct Node* removeLeafNodes(struct Node* n, int target) {
    if (!n) return NULL;
    n->left = removeLeafNodes(n->left, target);
    n->right = removeLeafNodes(n->right, target);
    if (!n->left && !n->right && n->val == target) return NULL;
    return n;
}`,
          cpp: `TreeNode* removeLeafNodes(TreeNode* n, int target) {
    if (!n) return nullptr;
    n->left = removeLeafNodes(n->left, target);
    n->right = removeLeafNodes(n->right, target);
    if (!n->left && !n->right && n->val == target) return nullptr;
    return n;
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const root = treeFrom(parts[0] || "");
          const target = toVal((parts[1] || "").split(/[\s,]+/)[0]);
          const out = [];
          if (!root) return [{ title: "Empty tree", tracks: [chips("answer", ["empty"], "bad")], counters: [count("removed", 0)], happened: "There are no leaves.", why: "Nothing can match the target in an empty tree.", legend: LEG }];
          let current = cloneTree(root);
          out.push({
            title: `Remove target leaves ${target}`,
            kind: "tree", tree: current, nodeStates: Object.fromEntries(collect(current).map((n) => [n.id, n.v === target && !n.l && !n.r ? "bad" : "idle"])), label: "start",
            counters: [count("removed", 0), count("target", target)],
            happened: "The deepest target leaves are the first ones that can disappear.",
            why: "A node only becomes a leaf after its children are removed.",
            legend: LEG,
            codeLine: 3,
          });
          const prune = (n) => {
            if (!n) return null;
            n.l = prune(n.l);
            n.r = prune(n.r);
            if (!n.l && !n.r && n.v === target) return null;
            return n;
          };
          let removed = 0;
          for (let pass = 0; pass < collect(root).length + 2; pass++) {
            const before = collect(current).length;
            const kept = prune(current);
            current = kept;
            const after = current ? collect(current).length : 0;
            removed += before - after;
            out.push({
              title: `Prune pass ${pass + 1}: ${before - after} node(s) removed`,
              kind: "tree", tree: current, nodeStates: current ? Object.fromEntries(collect(current).map((n) => [n.id, !n.l && !n.r && n.v === target ? "bad" : "done"])) : {}, label: current ? "after pass" : "empty tree",
              counters: [count("removed", removed), count("remaining", after)],
              happened: current ? `The tree now has ${after} node(s).` : "Every node was removed.",
              why: "Removing one layer of leaves can expose a new layer of target leaves.",
              legend: LEG,
              codeLine: 5,
            });
            if (before === after) break;
          }
          out.push({
            title: current ? "No more target leaves remain" : "The tree became empty",
            kind: "tree", tree: current || { id: "empty", v: "-", l: null, r: null }, nodeStates: current ? Object.fromEntries(collect(current).map((n) => [n.id, n.v === target ? "dim" : "result"])) : { empty: "result" }, label: "final",
            counters: [count("removed", removed), count("remaining", current ? collect(current).length : 0)],
            happened: current ? "All remaining target leaves were pruned." : "No nodes are left.",
            why: "Postorder pruning repeats until every removable leaf is gone.",
            legend: LEG,
            codeLine: 5,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "extra-characters-in-a-string",
    title: "Extra Characters in a String",
    category: "Tries",
    difficulty: "Intermediate",
    description: "Break a string into dictionary words while minimizing leftover characters.",
    input: { label: "dictionary | sentence", default: "leet code | leetcode", parse: "string" },
    approaches: [
      {
        name: "Dynamic Programming with Dictionary Checks",
        complexity: "O(n^2 * word length) time, O(n) space",
        idea: [
          "Let dp[i] be the fewest extra characters needed for the suffix starting at i. At each position, either pay one character as extra, or take any dictionary word that matches and jump past it.",
          "Working backward fills dp[0], the answer for the whole sentence. Trying every word at every position is a simple alternative to a trie.",
        ],
        problem: ["The naive transition checks every dictionary word at every suffix; a trie can share their prefixes and reduce repeated comparisons."],
        code: {
          c: `#include <string.h>

int minExtraChar(char** words, int m, char* s) {
    int n = strlen(s);
    int dp[1001];
    dp[n] = 0;
    for (int i = n - 1; i >= 0; i--) {
        dp[i] = 1 + dp[i + 1];
        for (int w = 0; w < m; w++) {
            int len = strlen(words[w]);
            if (i + len <= n && !strncmp(s + i, words[w], len)) {
                int cand = dp[i + len];
                if (cand < dp[i]) dp[i] = cand;
            }
        }
    }
    return dp[0];
}`,
          cpp: `#include <string>
#include <vector>
using namespace std;

int minExtraChar(vector<string>& words, string s) {
    int n = s.size();
    vector<int> dp(n + 1, 0);
    for (int i = n - 1; i >= 0; i--) {
        dp[i] = 1 + dp[i + 1];
        for (const string& w : words)
            if (s.compare(i, w.size(), w) == 0)
                dp[i] = min(dp[i], dp[i + w.size()]);
    }
    return dp[0];
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const words = (parts[0] || "").split(/[\s,]+/).filter(Boolean);
          const s = parts[1] || "";
          const chars = [...s];
          const dp = new Array(chars.length + 1).fill(0);
          const out = [];
          out.push({
            title: "dp[i] is the cost of the suffix from i",
            tracks: [chips("words", words, "idle"), track("sentence", chars, fill(chars.length, "idle")), chips("dp", dp.map(String), "idle")],
            counters: [count("position", chars.length, chars.length), count("answer", 0)],
            happened: "dp[n] is zero because an empty suffix needs no extra characters.",
            why: "Working from the end lets every transition look up a suffix that is already solved.",
            legend: LEG,
            codeLine: 4,
          });
          for (let i = chars.length - 1; i >= 0; i--) {
            dp[i] = 1 + dp[i + 1];
            let bestWord = null;
            for (const w of words) {
              if (w && s.slice(i, i + w.length) === w && dp[i + w.length] < dp[i]) {
                dp[i] = dp[i + w.length];
                bestWord = w;
              }
            }
            out.push({
              title: bestWord ? `Match "${bestWord}" at ${i}` : `Treat '${chars[i]}' as extra`,
              tracks: [chips("words", words, (k) => (words[k] === bestWord ? "result" : "idle")), track("sentence", chars, chars.map((x, k) => (k === i ? "read" : k < i ? "idle" : "done"))), chips("dp", dp.map((x, k) => (k === i ? "result" : k === i + 1 ? "compare" : "idle")), "idle")],
              counters: [count("position", i), count("extra so far", dp[i])],
              happened: bestWord ? `Jumping over "${bestWord}" costs ${dp[i]}.` : `The character ${chars[i]} adds one unit of cost.`,
              why: "The best option is the minimum between paying one character and taking a matching word for free.",
              legend: LEG,
              codeLine: bestWord ? 9 : 5,
            });
          }
          out.push({
            title: `${dp[0]} extra character(s)`,
            tracks: [track("sentence", chars, fill(chars.length, "done")), chips("dp", dp.map(String), (i) => (i === 0 ? "result" : "idle"))],
            counters: [count("answer", dp[0]), count("suffixes solved", chars.length)],
            happened: `The minimum number of leftover characters is ${dp[0]}.`,
            why: "Every suffix was solved from right to left, and the full sentence is the suffix at index 0.",
            legend: LEG,
            codeLine: 12,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "sum-of-all-subset-xor-totals",
    title: "Sum of All Subsets XOR Total",
    category: "Backtracking",
    difficulty: "Beginner",
    description: "Add the XOR value of every subset of an array.",
    input: { label: "The numbers", default: "1, 3", parse: "ints" },
    approaches: [
      {
        name: "Include or Exclude",
        complexity: "O(2^n) time, O(n) space",
        idea: [
          "Each element has two choices: leave it out or include it. Including an element XORs its value into the running total.",
          "A depth-first search reaches every subset exactly once and adds the final XOR value at each leaf. The number of leaves is 2^n.",
        ],
        problem: ["The search explores every subset, so the work doubles with each extra input element."],
        code: {
          c: `void dfs(int* a, int n, int i, int x, int* sum) {
    if (i == n) { *sum += x; return; }
    dfs(a, n, i + 1, x, sum);
    dfs(a, n, i + 1, x ^ a[i], sum);
}

int subsetXORSum(int* a, int n) {
    int sum = 0;
    dfs(a, n, 0, 0, &sum);
    return sum;
}`,
          cpp: `#include <vector>
using namespace std;

void dfs(vector<int>& a, int i, int x, int& sum) {
    if (i == (int)a.size()) { sum += x; return; }
    dfs(a, i + 1, x, sum);
    dfs(a, i + 1, x ^ a[i], sum);
}

int subsetXORSum(vector<int>& a) {
    int sum = 0;
    dfs(a, 0, 0, sum);
    return sum;
}`,
        },
        steps(nums) {
          const out = [];
          let sum = 0;
          const leaves = [];
          out.push({
            title: "Each element has two choices",
            tracks: [track("numbers", nums, fill(nums.length, "idle")), chips("subsets", [], "idle")],
            counters: [count("xor so far", 0), count("running sum", 0)],
            happened: "A subset is formed by deciding include or exclude for every number.",
            why: "Those binary choices generate all 2^n subsets exactly once.",
            legend: LEG,
            codeLine: 2,
          });
          const walk = (i, x, chosen) => {
            if (i === nums.length) {
              sum += x;
              leaves.push(x);
              out.push({
                title: `Subset ${show(chosen)} has XOR ${x}`,
                tracks: [track("numbers", nums, nums.map((v, k) => (chosen.includes(v) ? "result" : "dim"))), chips("subset XORs", leaves, "good")],
                counters: [count("running sum", sum), count("subsets", leaves.length, Math.pow(2, nums.length))],
                happened: `This complete subset contributes ${x} to the total.`,
                why: "A leaf of the include/exclude tree represents one finished subset.",
                legend: LEG,
                codeLine: 2,
              });
              return;
            }
            walk(i + 1, x, chosen);
            walk(i + 1, x ^ nums[i], chosen.concat(nums[i]));
          };
          walk(0, 0, []);
          out.push({
            title: `Total subset XOR sum is ${sum}`,
            tracks: [chips("subset XORs", leaves, "result")],
            counters: [count("running sum", sum), count("subsets", leaves.length)],
            happened: `Adding every leaf value gives ${sum}.`,
            why: "The DFS visited each possible include/exclude pattern once.",
            legend: LEG,
            codeLine: 6,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "partition-to-k-equal-sum-subsets",
    title: "Partition to K Equal Sum Subsets",
    category: "Backtracking",
    difficulty: "Intermediate",
    description: "Split numbers into k groups that all have the same sum.",
    input: { label: "numbers | k", default: "4, 3, 2, 3, 5, 2, 1 | 4", parse: "tworows" },
    approaches: [
      {
        name: "Fill k Buckets Backtracking",
        complexity: "O(k^n) worst case, O(n + k) space",
        idea: [
          "Every group must total sum / k. If the total is not divisible by k, the answer is immediately false.",
          "Place each number into one of k buckets. A number is skipped when it would overflow a bucket, and symmetric buckets are skipped to avoid repeating equivalent states.",
        ],
        problem: ["Backtracking can try many placements when the numbers are close to the target; sorting larger values first usually prunes much earlier."],
        code: {
          c: `#include <stdbool.h>
#include <stdlib.h>

int cmp(const void* a, const void* b) {
    return *(const int*)b - *(const int*)a;
}

bool fill(int* a, int n, int i, int* bucket, int target, int k) {
    if (i == n) return true;
    for (int b = 0; b < k; b++) {
        if (bucket[b] + a[i] > target) continue;
        bucket[b] += a[i];
        if (fill(a, n, i + 1, bucket, target, k)) return true;
        bucket[b] -= a[i];
        if (bucket[b] == 0) break;
    }
    return false;
}

bool canPartitionKSubsets(int* a, int n, int k) {
    int total = 0;
    for (int i = 0; i < n; i++) total += a[i];
    if (total % k) return false;
    qsort(a, n, sizeof(int), cmp);
    int* bucket = calloc(k, sizeof(int));
    bool ok = fill(a, n, 0, bucket, total / k, k);
    free(bucket);
    return ok;
}`,
          cpp: `#include <algorithm>
#include <numeric>
#include <vector>
using namespace std;

bool fill(vector<int>& a, int i, vector<int>& bucket, int target) {
    if (i == (int)a.size()) return true;
    for (int b = 0; b < (int)bucket.size(); b++) {
        if (bucket[b] + a[i] > target) continue;
        bucket[b] += a[i];
        if (fill(a, i + 1, bucket, target)) return true;
        bucket[b] -= a[i];
        if (bucket[b] == 0) break;
    }
    return false;
}

bool canPartitionKSubsets(vector<int>& a, int k) {
    int total = accumulate(a.begin(), a.end(), 0);
    if (total % k) return false;
    sort(a.rbegin(), a.rend());
    vector<int> bucket(k, 0);
    return fill(a, 0, bucket, total / k);
}`,
        },
        steps(parsed) {
          const nums = (parsed[0] || []).slice().sort((a, b) => b - a);
          const k = Math.max(1, (parsed[1] || [1])[0] || 1);
          const total = nums.reduce((s, x) => s + x, 0);
          const target = total / k;
          const buckets = new Array(k).fill(0);
          const out = [];
          out.push({
            title: `Each of ${k} groups needs ${target}`,
            tracks: [track("numbers (large first)", nums, fill(nums.length, "idle")), chips("buckets", buckets, "idle")],
            counters: [count("total", total), count("target", target)],
            happened: total % k === 0 ? `The total ${total} divides evenly into ${k} groups.` : `The total ${total} does not divide into ${k} equal groups.`,
            why: "Equal sums require the total to be divisible by k before any placement is tried.",
            legend: LEG,
            codeLine: 14,
          });
          if (total % k !== 0) {
            out.push({ title: "Impossible before searching", tracks: [chips("buckets", buckets, "bad")], counters: [count("answer", "false")], happened: "A remainder makes equal groups impossible.", why: "No integer bucket sum can receive a fractional share.", legend: LEG, codeLine: 16 });
            return out;
          }
          const ok = (() => {
            const used = new Array(nums.length).fill(false);
            const b = new Array(k).fill(0);
            const rec = (i) => {
              if (i === nums.length) return true;
              for (let j = 0; j < k; j++) {
                if (b[j] + nums[i] > target) continue;
                b[j] += nums[i];
                used[i] = true;
                if (rec(i + 1)) return true;
                used[i] = false;
                b[j] -= nums[i];
                if (b[j] === 0) break;
              }
              return false;
            };
            return rec(0);
          })();
          // replay a compact trace: place values greedily until the first forced backtrack,
          // then show the completed decision. This keeps the stage readable.
          let placed = 0;
          for (let i = 0; i < nums.length; i++) {
            if (placed >= target) break;
            let slot = -1;
            for (let b = 0; b < k; b++) if (buckets[b] + nums[i] <= target) { slot = b; break; }
            if (slot < 0) break;
            buckets[slot] += nums[i];
            placed += nums[i];
            out.push({
              title: `Place ${nums[i]} in bucket ${slot + 1}`,
              tracks: [track("numbers", nums, nums.map((v, j) => (j === i ? "read" : j < i ? "done" : "idle"))), chips("buckets", buckets, (b) => (b === slot ? "result" : "idle"))],
              counters: [count("bucket sum", buckets[slot], target), count("placed", i + 1, nums.length)],
              happened: `Bucket ${slot + 1} now totals ${buckets[slot]}.`,
              why: "A number is placed only when it fits without overshooting the target.",
              legend: LEG,
              codeLine: 8,
            });
          }
          out.push({
            title: ok ? "All buckets can reach the target" : "No valid partition was found",
            tracks: [chips("buckets", ok ? buckets : new Array(k).fill(0), ok ? "result" : "bad")],
            counters: [count("answer", ok ? "true" : "false"), count("target", target)],
            happened: ok ? "Backtracking found a placement for every number." : "Every explored placement eventually overflowed a bucket.",
            why: "The search undoes a choice whenever its subtree cannot complete the partition.",
            legend: LEG,
            codeLine: 11,
          });
          return out;
        },
      },
    ],
  });
})();
