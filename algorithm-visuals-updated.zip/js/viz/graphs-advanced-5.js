﻿/* ============================================================
   DSA Visuals â€” Graphs V
   Matching, cuts, disjoint paths, dynamic connectivity,
   min-cost flow and all shortest word ladders.
   ============================================================ */
(function () {
  "use strict";
  const { fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => `[${a.join(", ")}]`;
  const partsOf = (text) => String(text || "").split("|").map((p) => p.trim());
  const pairsOf = (text) =>
    String(text || "").split(/\s+/).filter(Boolean).map((p) => p.split(",").map((x) => parseInt(x, 10))).filter((p) => p.length === 2 && p.every(Number.isFinite));
  const quadsOf = (text) =>
    String(text || "").split(/\s+/).filter(Boolean).map((p) => p.split(",").map((x) => parseInt(x, 10))).filter((p) => p.length === 4 && p.every(Number.isFinite));
  const wordsOf = (text) => String(text || "").split(/[\s,]+/).filter(Boolean);

  function circlePos(i, n) {
    const a = (2 * Math.PI * i) / Math.max(1, n) - Math.PI / 2;
    return { x: +(25 + 20 * Math.cos(a)).toFixed(1), y: +(25 + 20 * Math.sin(a)).toFixed(1) };
  }
  function graphStep(labels, edges, states, edgeStates, extra) {
    return Object.assign({
      kind: "graph",
      nodes: labels.map((lab, i) => {
        const p = circlePos(i, labels.length);
        return { id: "n" + i, label: String(lab), x: p.x, y: p.y, state: (states && states[i]) || "idle" };
      }),
      edges: edges.map(([u, v], i) => ({ a: "n" + u, b: "n" + v, state: (edgeStates && edgeStates[i]) || "idle" })),
      legend: LEG,
    }, extra);
  }
  function dsuOf(n) {
    const p = Array.from({ length: n }, (_, i) => i);
    const find = (x) => {
      while (p[x] !== x) { p[x] = p[p[x]]; x = p[x]; }
      return x;
    };
    const union = (a, b) => {
      const ra = find(a), rb = find(b);
      if (ra === rb) return false;
      p[rb] = ra;
      return true;
    };
    return { p, find, union };
  }
  function differsOne(a, b) {
    if (a.length !== b.length) return false;
    let d = 0;
    for (let i = 0; i < a.length; i++) if (a[i] !== b[i] && ++d > 1) return false;
    return d === 1;
  }

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-bipartite-matching",
    title: "Maximum Bipartite Matching",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Pair as many left vertices as possible with right vertices along allowed edges.",
    input: { label: "left vertices | edges as left,right", default: "3 | 0,0 0,1 1,1 2,1 2,2", parse: "string" },
    approaches: [
      {
        name: "Kuhn's Augmenting Paths",
        complexity: "O(V Ã— E) time",
        idea: [
          "Process left vertices one at a time. Try to match each to a free right vertex.",
          "If every right neighbour is taken, ask the left vertex currently holding one of them to move elsewhere. A successful chain increases the matching by one; if no chain exists, this left vertex stays unmatched.",
        ],
        problem: [
          "Greedily taking the first free right vertex can block a later left vertex that has fewer options.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint adj[3][3] = {{1,1,0},{0,1,0},{0,1,1}};\nint matchR[3] = {-1,-1,-1}, seen[3];\n\nint tryK(int u) {\n    for (int v = 0; v < 3; v++) {\n        if (!adj[u][v] || seen[v]) continue;\n        seen[v] = 1;\n        if (matchR[v] == -1 || tryK(matchR[v])) {\n            matchR[v] = u;\n            return 1;\n        }\n    }\n    return 0;\n}\n\nint main(void) {\n    int size = 0;\n    for (int u = 0; u < 3; u++) {\n        memset(seen, 0, sizeof(seen));\n        if (tryK(u)) size++;\n    }\n    printf(\"%d\\\\n\", size); /* 3 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nbool tryK(int u, vector<vector<int>>& adj, vector<int>& matchR, vector<bool>& seen) {\n    for (int v : adj[u]) {\n        if (seen[v]) continue;\n        seen[v] = true;\n        if (matchR[v] == -1 || tryK(matchR[v], adj, matchR, seen)) {\n            matchR[v] = u;\n            return true;\n        }\n    }\n    return false;\n}\n\nint maximumMatching(int L, vector<vector<int>>& adj, int R) {\n    vector<int> matchR(R, -1);\n    int size = 0;\n    for (int u = 0; u < L; u++) {\n        vector<bool> seen(R, false);\n        if (tryK(u, adj, matchR, seen)) size++;\n    }\n    return size;\n}\n\nint main() {\n    vector<vector<int>> adj{{0,1},{1},{1,2}};\n    cout << maximumMatching(3, adj, 3) << '\\\\n'; // 3\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const L = Math.min(8, Math.max(0, parseInt(parts[0], 10) || 0));
          const edges = pairsOf(parts[1] || "").filter(([u, v]) => u >= 0 && v >= 0 && u < L && v < 12).slice(0, 18);
          if (!L || !edges.length) return [{
            title: "Give left vertices and allowed pairs",
            tracks: [chips("left", ["â€”"], "idle")],
            counters: [count("matching", 0)],
            legend: LEG,
            happened: "No allowed pair exists.",
            why: "Matching edges must come from the given bipartite edges.",
          }];
          const R = Math.max(...edges.map(([, v]) => v)) + 1;
          const adj = Array.from({ length: L }, () => []);
          edges.forEach(([u, v]) => adj[u].push(v));
          const matchR = Array(R).fill(-1);
          const matchL = Array(L).fill(-1);
          const steps = [];
          let size = 0;
          const matchingLabels = () => Array.from({ length: R }, (_, v) => (matchR[v] < 0 ? `R${v}: free` : `R${v}â†’L${matchR[v]}`));
          steps.push({
            title: `${L} left vertices, ${R} right vertices`,
            tracks: [
              chips("left", Array.from({ length: L }, (_, i) => `L${i}`), "idle"),
              chips("right", Array.from({ length: R }, (_, i) => `R${i}`), "idle"),
              chips("allowed", edges.map(([u, v]) => `L${u}-R${v}`), "dim"),
            ],
            counters: [count("matching", 0, Math.min(L, R)), count("edges", edges.length)],
            legend: LEG,
            happened: "Every right vertex starts free.",
            why: "A matching uses each vertex at most once.",
            codeLine: 4,
          });
          const tryK = (u, seen) => {
            for (const v of adj[u]) {
              if (seen[v]) continue;
              seen[v] = true;
              if (matchR[v] === -1 || tryK(matchR[v], seen)) {
                matchR[v] = u;
                matchL[u] = v;
                return true;
              }
            }
            return false;
          };
          for (let u = 0; u < L; u++) {
            const seen = Array(R).fill(false);
            const ok = tryK(u, seen);
            if (ok) size++;
            steps.push({
              title: ok ? `L${u} matched${matchL[u] >= 0 ? ` to R${matchL[u]}` : ""}` : `L${u} has no augmenting path`,
              tracks: [
                chips("left", Array.from({ length: L }, (_, i) => (matchL[i] < 0 ? `L${i}: free` : `L${i}â†’R${matchL[i]}`)), (i) => (i === u ? "read" : matchL[i] >= 0 ? "good" : "idle")),
                chips("right", matchingLabels(), (v) => (matchR[v] === u ? "result" : matchR[v] >= 0 ? "done" : "dim")),
                chips("matching", Array.from({ length: R }, (_, v) => (matchR[v] < 0 ? null : `L${matchR[v]}-R${v}`)).filter(Boolean), "good"),
              ],
              counters: [count("matching", size, Math.min(L, R)), count("left processed", u + 1, L)],
              legend: LEG,
              happened: ok ? `An augmenting path lets L${u} join without shrinking the matching.` : "Every path from this left vertex ends at an already matched right vertex with no escape.",
              why: "Adding one to the matching when an augmenting path exists is the core of Kuhn's algorithm.",
              codeLine: ok ? 9 : 12,
            });
          }
          steps.push({
            title: `Answer: maximum matching has ${size} pair${size === 1 ? "" : "s"}`,
            tracks: [
              chips("pairs", Array.from({ length: R }, (_, v) => (matchR[v] < 0 ? null : `L${matchR[v]}-R${v}`)).filter(Boolean), "result"),
              chips("unmatched left", Array.from({ length: L }, (_, i) => (matchL[i] < 0 ? `L${i}` : null)).filter(Boolean), "bad"),
            ],
            counters: [count("matching", size), count("unmatched", L - size)],
            legend: LEG,
            happened: `${size} left vertices are paired; no augmenting path remains.`,
            why: "A matching is maximum exactly when no augmenting path exists (Berge's theorem).",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  const flowSteps = (raw, wantCut) => {
    const parts = partsOf(raw);
    const st = (parts[0] || "").split(/[\s,]+/).map(Number);
    const s = st[0], t = st[1];
    const edges = quadsOf(parts[1] || "").filter(([u, v, c]) => u >= 0 && v >= 0 && c >= 0 && u !== v);
    const tripleEdges = triplesOfSafe(parts[1]);
    function triplesOfSafe(txt) {
      return String(txt || "").split(/\s+/).filter(Boolean).map((p) => p.split(",").map((x) => parseInt(x, 10))).filter((p) => p.length >= 3 && p.every(Number.isFinite));
    }
    const use = edges.length ? edges.map(([u, v, c]) => [u, v, c]) : tripleEdges.map(([u, v, c]) => [u, v, c]);
    if (!Number.isFinite(s) || !Number.isFinite(t) || !use.length) return [{
      title: "Give source, sink and capacities",
      tracks: [chips("edges", ["â€”"], "idle")],
      counters: [count("flow", 0)],
      legend: LEG,
      happened: "There is no flow network.",
      why: "A cut or flow needs a source, a sink and capacity edges.",
    }];
    const maxNode = Math.max(s, t, ...use.flatMap(([u, v]) => [u, v]));
    const labels = Array.from({ length: maxNode + 1 }, (_, i) => i);
    const cap = Array.from({ length: labels.length }, () => Array(labels.length).fill(0));
    const flow = Array.from({ length: labels.length }, () => Array(labels.length).fill(0));
    use.forEach(([u, v, c]) => { cap[u][v] += c; });
    const steps = [];
    let total = 0;
    const edgeList = use.map(([u, v]) => [u, v]);
    const edgeState = () => edgeList.map(([u, v]) => {
      if (flow[u][v] > 0 && flow[u][v] === cap[u][v]) return "bad";
      return flow[u][v] > 0 ? "good" : "idle";
    });
    steps.push(graphStep(labels, edgeList, Object.fromEntries(labels.map((i) => [i, i === s ? "good" : i === t ? "bad" : "idle"])), edgeState(), {
      title: `Source ${s}, sink ${t}; flow starts at 0`,
      label: "residual capacity equals capacity",
      counters: [count("flow", 0), count("edges", use.length)],
      legend: LEG,
      happened: "Every pipe is empty.",
      why: "An augmenting path can use any edge with positive residual capacity.",
      codeLine: 6,
    }));
    let guard = 0;
    while (guard++ < 12) {
      const parent = Array(labels.length).fill(-1);
      const queue = [s];
      parent[s] = s;
      while (queue.length) {
        const u = queue.shift();
        for (let v = 0; v < labels.length; v++) {
          if (parent[v] === -1 && cap[u][v] - flow[u][v] > 0) { parent[v] = u; queue.push(v); }
        }
      }
      if (parent[t] === -1) break;
      const path = [];
      let add = Infinity;
      for (let v = t; v !== s; v = parent[v]) {
        const u = parent[v];
        path.unshift([u, v]);
        add = Math.min(add, cap[u][v] - flow[u][v]);
      }
      path.forEach(([u, v]) => { flow[u][v] += add; flow[v][u] -= add; });
      total += add;
      const onPath = (u, v) => path.some(([a, b]) => a === u && b === v);
      steps.push(graphStep(labels, edgeList, Object.fromEntries(labels.map((i) => [i, path.some(([a, b]) => a === i || b === i) ? "read" : i === s ? "good" : i === t ? "bad" : "idle"])), edgeList.map(([u, v]) => (onPath(u, v) ? "result" : edgeState()[edgeList.findIndex(([a, b]) => a === u && b === v)])), {
        title: `Push ${add} along ${path.map(([u, v]) => `${u}â†’${v}`).join(" ")}`,
        label: use.map(([u, v, c]) => `${u}â†’${v}: ${flow[u][v]}/${c}`).join("  "),
        counters: [count("flow", total), count("added", add)],
        legend: LEG,
        happened: `The smallest residual pipe on the path limits this push to ${add}.`,
        why: "Reducing residual capacity and adding reverse capacity keeps the flow valid.",
        codeLine: 18,
      }));
    }
    const reachable = new Set([s]);
    const stack = [s];
    while (stack.length) {
      const u = stack.pop();
      for (let v = 0; v < labels.length; v++) {
        if (!reachable.has(v) && cap[u][v] - flow[u][v] > 0) { reachable.add(v); stack.push(v); }
      }
    }
    const cut = use.filter(([u, v]) => reachable.has(u) && !reachable.has(v));
    const cutCap = cut.reduce((sum, [u, v]) => sum + cap[u][v], 0);
    steps.push(graphStep(labels, edgeList, Object.fromEntries(labels.map((i) => [i, reachable.has(i) ? "good" : "bad"])), edgeList.map(([u, v]) => (reachable.has(u) && !reachable.has(v) ? "result" : edgeState()[edgeList.findIndex(([a, b]) => a === u && b === v)])), {
      title: wantCut ? `Answer: minimum cut capacity ${cutCap}` : `Answer: maximum flow ${total}`,
      label: `source side {${[...reachable].join(", ")}}`,
      counters: wantCut ? [count("cut capacity", cutCap), count("cut edges", cut.length)] : [count("flow", total), count("augmentations", guard - 1)],
      legend: LEG,
      happened: wantCut ? `Cut edges: ${cut.map(([u, v]) => `${u}â†’${v}(${cap[u][v]})`).join(", ") || "none"}.` : "No residual path remains from source to sink.",
      why: "Max-flow min-cut: the flow value equals the capacity of the reachable set's boundary.",
      codeLine: wantCut ? 27 : 25,
    }));
    return steps;
  };

  V.register({
    id: "minimum-cut",
    title: "Minimum Cut",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Find the cheapest set of pipes whose removal separates the source from the sink.",
    input: { label: "source,sink | edges u,v,capacity", default: "0,3 | 0,1,3 0,2,2 1,2,1 1,3,2 2,3,3", parse: "string" },
    approaches: [
      {
        name: "Max-Flow Min-Cut",
        complexity: "O(V EÂ²) time",
        idea: [
          "Compute a maximum flow. Then mark every vertex reachable from the source using only edges with positive residual capacity.",
          "The edges from this reachable set to the rest form a minimum cut. No augmenting path remains, so the flow already equals the cut's capacity.",
        ],
        problem: [
          "Enumerating cuts is exponential; the residual reachable set gives a minimum cut for free after max flow.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint cap[4][4] = {{0,3,2,0},{0,0,1,2},{0,0,0,3},{0,0,0,0}};\nint flow[4][4], parent[4], seen[4], q[16];\n\nint bfs(int s, int t) {\n    memset(seen, 0, sizeof(seen));\n    int head = 0, tail = 0;\n    q[tail++] = s; seen[s] = 1;\n    while (head < tail) {\n        int u = q[head++];\n        for (int v = 0; v < 4; v++)\n            if (!seen[v] && cap[u][v] - flow[u][v] > 0) { parent[v] = u; seen[v] = 1; q[tail++] = v; }\n    }\n    return seen[t];\n}\n\nint main(void) {\n    int total = 0;\n    while (bfs(0, 3)) {\n        int add = 1 << 30;\n        for (int v = 3; v != 0; v = parent[v]) {\n            int u = parent[v];\n            int r = cap[u][v] - flow[u][v];\n            if (r < add) add = r;\n        }\n        for (int v = 3; v != 0; v = parent[v]) {\n            int u = parent[v];\n            flow[u][v] += add;\n            flow[v][u] -= add;\n        }\n        total += add;\n    }\n\n    memset(seen, 0, sizeof(seen));\n    int head = 0, tail = 0;\n    q[tail++] = 0; seen[0] = 1;\n    while (head < tail) {\n        int u = q[head++];\n        for (int v = 0; v < 4; v++)\n            if (!seen[v] && cap[u][v] - flow[u][v] > 0) { seen[v] = 1; q[tail++] = v; }\n    }\n    printf(\"flow %d, cut\", total);\n    for (int u = 0; u < 4; u++) for (int v = 0; v < 4; v++)\n        if (seen[u] && !seen[v] && cap[u][v]) printf(\" %d-%d\", u, v);\n    printf(\"\\\\n\"); /* flow 5, cut 0-1 0-2 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <queue>\nusing namespace std;\n\nint main() {\n    int n = 4, s = 0, t = 3;\n    vector<vector<int>> cap(n, vector<int>(n, 0)), flow(n, vector<int>(n, 0));\n    vector<vector<int>> edges{{0,1,3},{0,2,2},{1,2,1},{1,3,2},{2,3,3}};\n    for (auto& e : edges) cap[e[0]][e[1]] = e[2];\n\n    while (true) {\n        vector<int> p(n, -1);\n        queue<int> q; q.push(s); p[s] = s;\n        while (!q.empty()) {\n            int u = q.front(); q.pop();\n            for (int v = 0; v < n; v++)\n                if (p[v] == -1 && cap[u][v] - flow[u][v] > 0) { p[v] = u; q.push(v); }\n        }\n        if (p[t] == -1) break;\n        int add = 1e9;\n        for (int v = t; v != s; v = p[v]) add = min(add, cap[p[v]][v] - flow[p[v]][v]);\n        for (int v = t; v != s; v = p[v]) { flow[p[v]][v] += add; flow[v][p[v]] -= add; }\n    }\n\n    vector<bool> side(n, false);\n    queue<int> q; q.push(s); side[s] = true;\n    while (!q.empty()) {\n        int u = q.front(); q.pop();\n        for (int v = 0; v < n; v++)\n            if (!side[v] && cap[u][v] - flow[u][v] > 0) { side[v] = true; q.push(v); }\n    }\n\n    int cut = 0;\n    for (auto& e : edges)\n        if (side[e[0]] && !side[e[1]]) { cut += e[2]; cout << e[0] << '-' << e[1] << ' '; }\n    cout << \"cut=\" << cut << '\\\\n'; // 0-1 0-2 cut=5\n}`,
        },
        steps(raw) { return flowSteps(raw, true); },
      },
    ],
  });

  V.register({
    id: "disjoint-paths",
    title: "Disjoint Paths",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Count how many source-to-sink paths can share no edge.",
    input: { label: "source,sink | directed edges u,v", default: "0,3 | 0,1 0,2 1,3 2,3 1,2", parse: "string" },
    approaches: [
      {
        name: "Unit-Capacity Max Flow",
        complexity: "O(V EÂ²) time",
        idea: [
          "Give every edge capacity 1. A flow of value k is exactly k edge-disjoint source-to-sink paths, because no edge can carry more than one unit.",
          "Run BFS augmenting paths. Each successful augmentation adds one path and saturates its edges, so it cannot be reused.",
        ],
        problem: [
          "Finding paths one by one with ordinary DFS can choose paths that block each other; residual reverse edges let the algorithm reroute.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint cap[4][4] = {{0,1,1,0},{0,0,0,1},{0,0,0,1},{0,0,0,0}};\nint flow[4][4], parent[4], seen[4], q[16];\n\nint bfs(int s, int t) {\n    memset(seen, 0, sizeof(seen));\n    int head = 0, tail = 0;\n    q[tail++] = s; seen[s] = 1;\n    while (head < tail) {\n        int u = q[head++];\n        for (int v = 0; v < 4; v++)\n            if (!seen[v] && cap[u][v] - flow[u][v] > 0) { parent[v] = u; seen[v] = 1; q[tail++] = v; }\n    }\n    return seen[t];\n}\n\nint main(void) {\n    int paths = 0;\n    while (bfs(0, 3)) {\n        for (int v = 3; v != 0; v = parent[v]) {\n            int u = parent[v];\n            flow[u][v]++;\n            flow[v][u]--;\n        }\n        paths++;\n    }\n    printf(\"%d\\\\n\", paths); /* 2 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <queue>\nusing namespace std;\n\nint main() {\n    int n = 4, s = 0, t = 3;\n    vector<vector<int>> cap(n, vector<int>(n, 0)), flow(n, vector<int>(n, 0));\n    for (auto& e : vector<vector<int>>{{0,1},{0,2},{1,3},{2,3},{1,2}}) cap[e[0]][e[1]] = 1;\n\n    int paths = 0;\n    while (true) {\n        vector<int> p(n, -1);\n        queue<int> q; q.push(s); p[s] = s;\n        while (!q.empty()) {\n            int u = q.front(); q.pop();\n            for (int v = 0; v < n; v++)\n                if (p[v] == -1 && cap[u][v] - flow[u][v] > 0) { p[v] = u; q.push(v); }\n        }\n        if (p[t] == -1) break;\n        for (int v = t; v != s; v = p[v]) { flow[p[v]][v]++; flow[v][p[v]]--; }\n        paths++;\n    }\n    cout << paths << '\\\\n'; // 2\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const st = (parts[0] || "").split(/[\s,]+/).map(Number);
          const s = st[0], t = st[1];
          const edges = pairsOf(parts[1] || "").filter(([u, v]) => u >= 0 && v >= 0 && u !== v).slice(0, 16);
          if (!Number.isFinite(s) || !Number.isFinite(t) || !edges.length) return [{
            title: "Give a source, sink and directed edges",
            tracks: [chips("edges", ["â€”"], "idle")],
            counters: [count("paths", 0)],
            legend: LEG,
            happened: "There are no edges.",
            why: "Disjoint paths need edges to share or avoid.",
          }];
          const n = Math.max(s, t, ...edges.flat()) + 1;
          const labels = Array.from({ length: n }, (_, i) => i);
          const cap = Array.from({ length: n }, () => Array(n).fill(0));
          const flow = Array.from({ length: n }, () => Array(n).fill(0));
          edges.forEach(([u, v]) => { cap[u][v] += 1; });
          const steps = [];
          let paths = 0;
          const edgeStates = (path) => edges.map(([u, v]) => (path && path.some(([a, b]) => a === u && b === v) ? "result" : flow[u][v] > 0 ? "good" : "idle"));
          steps.push(graphStep(labels, edges, Object.fromEntries(labels.map((i) => [i, i === s ? "good" : i === t ? "bad" : "idle"])), edgeStates(null), {
            title: `Every edge has capacity 1`,
            label: "one unit of flow equals one path",
            counters: [count("paths", 0), count("edges", edges.length)],
            legend: LEG,
            happened: "No path has been chosen yet.",
            why: "A unit-capacity edge can belong to at most one disjoint path.",
            codeLine: 4,
          }));
          let guard = 0;
          while (guard++ < 8) {
            const parent = Array(n).fill(-1);
            const queue = [s];
            parent[s] = s;
            while (queue.length) {
              const u = queue.shift();
              for (let v = 0; v < n; v++) {
                if (parent[v] === -1 && cap[u][v] - flow[u][v] > 0) { parent[v] = u; queue.push(v); }
              }
            }
            if (parent[t] === -1) break;
            const path = [];
            for (let v = t; v !== s; v = parent[v]) {
              path.unshift([parent[v], v]);
              flow[parent[v]][v]++;
              flow[v][parent[v]]--;
            }
            paths++;
            steps.push(graphStep(labels, edges, Object.fromEntries(labels.map((i) => [i, path.some(([a, b]) => a === i || b === i) ? "read" : i === s ? "good" : i === t ? "bad" : "idle"])), edgeStates(path), {
              title: `Path ${paths}: ${path.map(([u, v]) => `${u}â†’${v}`).join(" ")}`,
              label: `${paths} edge-disjoint path${paths === 1 ? "" : "s"} so far`,
              counters: [count("paths", paths), count("edges used", flow.flat().filter((f, i) => f > 0 && cap.flat()[i] > 0).length)],
              legend: LEG,
              happened: `All edges on this path are now saturated and cannot be reused.`,
              why: "Residual reverse edges may reroute later paths, but forward capacity 1 prevents sharing.",
              codeLine: 13,
            }));
          }
          steps.push(graphStep(labels, edges, Object.fromEntries(labels.map((i) => [i, i === s || i === t ? "result" : "done"])), edges.map(([u, v]) => (flow[u][v] > 0 ? "good" : "idle")), {
            title: `Answer: ${paths} edge-disjoint path${paths === 1 ? "" : "s"}`,
            label: "no residual augmenting path remains",
            counters: [count("paths", paths), count("edges", edges.length)],
            legend: LEG,
            happened: `The maximum number of edge-disjoint ${s}â†’${t} paths is ${paths}.`,
            why: "Unit capacities make max flow equal the maximum number of edge-disjoint paths.",
            codeLine: 18,
          }));
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "network-connectivity",
    title: "Network Connectivity",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Add links over time and answer whether two computers are currently connected.",
    input: { label: "nodes | link pairs | query pairs", default: "5 | 0,1 2,3 | 0,2 0,1 2,3 2,4", parse: "string" },
    approaches: [
      {
        name: "Incremental Union-Find",
        complexity: "O((E + Q) Î±(V)) time",
        idea: [
          "Start with every computer in its own component. Adding a link merges the components of its endpoints.",
          "A connectivity query is true exactly when both endpoints have the same root. No path search is needed after each link.",
        ],
        problem: [
          "Running BFS after every link repeats work; DSU updates connectivity in near-constant time per merge.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint parent[8];\nint find(int x) {\n    while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }\n    return x;\n}\n\nint main(void) {\n    int n = 5;\n    for (int i = 0; i < n; i++) parent[i] = i;\n\n    int links[2][2] = {{0,1},{2,3}};\n    for (int i = 0; i < 2; i++) {\n        int a = find(links[i][0]), b = find(links[i][1]);\n        if (a != b) parent[b] = a;\n    }\n\n    int queries[4][2] = {{0,2},{0,1},{2,3},{2,4}};\n    for (int i = 0; i < 4; i++)\n        printf(\"%d \", find(queries[i][0]) == find(queries[i][1]));\n    printf(\"\\\\n\"); /* 0 1 1 0 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <numeric>\nusing namespace std;\n\nint find(vector<int>& p, int x) {\n    while (p[x] != x) { p[x] = p[p[x]]; x = p[x]; }\n    return x;\n}\n\nint main() {\n    int n = 5;\n    vector<int> p(n);\n    iota(p.begin(), p.end(), 0);\n\n    for (auto& e : vector<vector<int>>{{0,1},{2,3}}) {\n        int a = find(p, e[0]), b = find(p, e[1]);\n        if (a != b) p[b] = a;\n    }\n\n    for (auto& q : vector<vector<int>>{{0,2},{0,1},{2,3},{2,4}})\n        cout << (find(p, q[0]) == find(p, q[1])) << ' '; // 0 1 1 0\n    cout << '\\\\n';\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const n = Math.min(10, Math.max(0, parseInt(parts[0], 10) || 0));
          const links = pairsOf(parts[1] || "").filter(([u, v]) => u >= 0 && v >= 0 && u < n && v < n && u !== v);
          const queries = pairsOf(parts[2] || "").filter(([u, v]) => u >= 0 && v >= 0 && u < n && v < n);
          if (!n) return [{
            title: "Give the number of computers",
            tracks: [chips("nodes", ["â€”"], "idle")],
            counters: [count("components", 0)],
            legend: LEG,
            happened: "There are no computers.",
            why: "Connectivity is defined over a set of vertices.",
          }];
          const { find, union } = dsuOf(n);
          const nodes = Array.from({ length: n }, (_, i) => i);
          const steps = [];
          let comps = n;
          const compOf = (i) => find(i);
          steps.push({
            title: `${n} isolated computers`,
            tracks: [chips("computers", nodes.map((i) => `${i}:${i}`), "idle"), chips("links", links.map(([u, v]) => `${u}-${v}`), "dim"), chips("queries", queries.map(([u, v]) => `${u}?${v}`), "compare")],
            counters: [count("components", comps, n), count("links added", 0, links.length)],
            legend: LEG,
            happened: "Every computer is its own component.",
            why: "Union-find begins with singleton sets.",
            codeLine: 3,
          });
          links.forEach(([u, v], i) => {
            const ok = union(u, v);
            if (ok) comps--;
            steps.push({
              title: ok ? `Link ${u}â€“${v} merges two components` : `Link ${u}â€“${v} is already internal`,
              tracks: [
                chips("computers", nodes.map((x) => `${x}:${compOf(x)}`), (x) => (compOf(x) === compOf(u) ? "good" : "idle")),
                chips("links", links.map(([a, b], j) => `${a}-${b}`), (j) => (j === i ? "read" : j < i ? "done" : "dim")),
              ],
              counters: [count("components", comps, n), count("links added", i + 1, links.length)],
              legend: LEG,
              happened: ok ? `${u} and ${v} now share one component.` : "Both endpoints were already connected, so nothing changes.",
              why: "Merging two roots reduces the component count by exactly one.",
              codeLine: 8,
            });
          });
          const answers = [];
          queries.forEach(([u, v], i) => {
            const yes = find(u) === find(v);
            answers.push(yes);
            steps.push({
              title: `${u} and ${v} are ${yes ? "connected" : "not connected"}`,
              tracks: [
                chips("query", [`${u}?${v}`], yes ? "good" : "bad"),
                chips("roots", nodes.map((x) => `${x}:${compOf(x)}`), (x) => (x === u || x === v ? "read" : compOf(x) === compOf(u) ? "compare" : "idle")),
                chips("answers", answers.map((x) => (x ? "yes" : "no")), (j) => (j === i ? "result" : "done")),
              ],
              counters: [count("answered", i + 1, queries.length), count("yes", answers.filter(Boolean).length)],
              legend: LEG,
              happened: yes ? `Both computers have root ${compOf(u)}.` : `Roots ${compOf(u)} and ${compOf(v)} differ.`,
              why: "Two vertices are connected exactly when their DSU roots match.",
              codeLine: 13,
            });
          });
          steps.push({
            title: "Answer: all connectivity queries evaluated",
            tracks: [chips("results", queries.map(([u, v], i) => `${u}?${v}: ${answers[i] ? "yes" : "no"}`), (i) => (answers[i] ? "good" : "bad"))],
            counters: [count("components", comps), count("queries", queries.length)],
            legend: LEG,
            happened: answers.map((x, i) => `${queries[i][0]}?${queries[i][1]} ${x ? "yes" : "no"}`).join("; "),
            why: "All queries use the final union-find structure.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "minimum-cost-maximum-flow",
    title: "Minimum Cost Maximum Flow",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Push the maximum flow while paying the least total cost per unit.",
    input: { label: "source,sink | edges u,v,capacity,cost", default: "0,3 | 0,1,2,1 0,2,2,2 1,3,2,2 2,3,2,1", parse: "string" },
    approaches: [
      {
        name: "Successive Shortest Paths",
        complexity: "O(flow Ã— V E) time",
        idea: [
          "Among all augmenting paths in the residual graph, choose the one with the smallest total cost per unit. Push its bottleneck.",
          "Repeat until no path remains. Reverse edges have negative cost, so the search may cancel earlier expensive flow and replace it with a cheaper route.",
        ],
        problem: [
          "Choosing the largest bottleneck first ignores cost and can produce maximum flow at a much higher price.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint cap[4][4], cost[4][4], flow[4][4];\nint dist[4], parent[4];\n\nint main(void) {\n    int eu[] = {0,0,1,2}, ev[] = {1,2,3,3}, ec[] = {2,2,2,2}, ew[] = {1,2,2,1};\n    for (int i = 0; i < 4; i++) { cap[eu[i]][ev[i]] = ec[i]; cost[eu[i]][ev[i]] = ew[i]; }\n\n    int totalFlow = 0, totalCost = 0;\n    while (1) {\n        for (int i = 0; i < 4; i++) { dist[i] = 1 << 30; parent[i] = -1; }\n        dist[0] = 0;\n\n        for (int round = 0; round < 3; round++)\n            for (int u = 0; u < 4; u++)\n                for (int v = 0; v < 4; v++)\n                    if (cap[u][v] - flow[u][v] > 0 && dist[u] + cost[u][v] < dist[v]) {\n                        dist[v] = dist[u] + cost[u][v];\n                        parent[v] = u;\n                    }\n\n        if (parent[3] == -1) break;\n        int add = 1 << 30;\n        for (int v = 3; v != 0; v = parent[v])\n            if (cap[parent[v]][v] - flow[parent[v]][v] < add) add = cap[parent[v]][v] - flow[parent[v]][v];\n\n        for (int v = 3; v != 0; v = parent[v]) {\n            int u = parent[v];\n            flow[u][v] += add;\n            flow[v][u] -= add;\n        }\n        totalFlow += add;\n        totalCost += add * dist[3];\n    }\n    printf(\"flow %d cost %d\\\\n\", totalFlow, totalCost); /* flow 4 cost 12 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint main() {\n    int n = 4, s = 0, t = 3;\n    vector<vector<int>> cap(n, vector<int>(n, 0)), cost(n, vector<int>(n, 0)), flow(n, vector<int>(n, 0));\n    vector<vector<int>> e{{0,1,2,1},{0,2,2,2},{1,3,2,2},{2,3,2,1}};\n    for (auto& x : e) { cap[x[0]][x[1]] = x[2]; cost[x[0]][x[1]] = x[3]; }\n\n    int totalFlow = 0, totalCost = 0;\n    while (true) {\n        vector<int> dist(n, 1e9), p(n, -1);\n        dist[s] = 0;\n        for (int round = 0; round < n - 1; round++)\n            for (int u = 0; u < n; u++)\n                for (int v = 0; v < n; v++)\n                    if (cap[u][v] - flow[u][v] > 0 && dist[u] + cost[u][v] < dist[v]) {\n                        dist[v] = dist[u] + cost[u][v];\n                        p[v] = u;\n                    }\n        if (p[t] == -1) break;\n\n        int add = 1e9;\n        for (int v = t; v != s; v = p[v]) add = min(add, cap[p[v]][v] - flow[p[v]][v]);\n        for (int v = t; v != s; v = p[v]) { flow[p[v]][v] += add; flow[v][p[v]] -= add; }\n        totalFlow += add;\n        totalCost += add * dist[t];\n    }\n    cout << \"flow \" << totalFlow << \" cost \" << totalCost << '\\\\n'; // flow 4 cost 12\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const st = (parts[0] || "").split(/[\s,]+/).map(Number);
          const s = st[0], t = st[1];
          const edges = quadsOf(parts[1] || "").filter(([u, v, c]) => u >= 0 && v >= 0 && c > 0 && u !== v).slice(0, 14);
          if (!Number.isFinite(s) || !Number.isFinite(t) || !edges.length) return [{
            title: "Give source, sink and capacity/cost edges",
            tracks: [chips("edges", ["â€”"], "idle")],
            counters: [count("flow", 0)],
            legend: LEG,
            happened: "There are no usable edges.",
            why: "Min-cost flow needs capacity and cost on every edge.",
          }];
          const n = Math.max(s, t, ...edges.flatMap(([u, v]) => [u, v])) + 1;
          const labels = Array.from({ length: n }, (_, i) => i);
          const cap = Array.from({ length: n }, () => Array(n).fill(0));
          const cost = Array.from({ length: n }, () => Array(n).fill(0));
          const flow = Array.from({ length: n }, () => Array(n).fill(0));
          edges.forEach(([u, v, c, w]) => { cap[u][v] += c; cost[u][v] = w; cost[v][u] = -w; });
          const steps = [];
          let totalFlow = 0;
          let totalCost = 0;
          const edgeStates = () => edges.map(([u, v]) => (flow[u][v] > 0 ? (flow[u][v] === cap[u][v] ? "bad" : "good") : "idle"));
          steps.push(graphStep(labels, edges.map(([u, v]) => [u, v]), Object.fromEntries(labels.map((i) => [i, i === s ? "good" : i === t ? "bad" : "idle"])), edgeStates(), {
            title: `Minimum-cost flow from ${s} to ${t}`,
            label: edges.map(([u, v, c, w]) => `${u}â†’${v} cap ${c} cost ${w}`).join("  "),
            counters: [count("flow", 0), count("cost", 0)],
            legend: LEG,
            happened: "No flow has been sent.",
            why: "Each augmentation chooses the cheapest residual path, not the fattest one.",
            codeLine: 5,
          }));
          let guard = 0;
          while (guard++ < 10) {
            const dist = Array(n).fill(Infinity);
            const parent = Array(n).fill(-1);
            dist[s] = 0;
            for (let round = 0; round < n - 1; round++) {
              let changed = false;
              for (let u = 0; u < n; u++) {
                if (!Number.isFinite(dist[u])) continue;
                for (let v = 0; v < n; v++) {
                  if (cap[u][v] - flow[u][v] <= 0) continue;
                  if (dist[u] + cost[u][v] < dist[v]) {
                    dist[v] = dist[u] + cost[u][v];
                    parent[v] = u;
                    changed = true;
                  }
                }
              }
              if (!changed) break;
            }
            if (parent[t] === -1) break;
            const path = [];
            let add = Infinity;
            for (let v = t; v !== s; v = parent[v]) {
              const u = parent[v];
              path.unshift([u, v]);
              add = Math.min(add, cap[u][v] - flow[u][v]);
            }
            path.forEach(([u, v]) => { flow[u][v] += add; flow[v][u] -= add; });
            totalFlow += add;
            totalCost += add * dist[t];
            steps.push(graphStep(labels, edges.map(([u, v]) => [u, v]), Object.fromEntries(labels.map((i) => [i, path.some(([a, b]) => a === i || b === i) ? "read" : i === s ? "good" : i === t ? "bad" : "idle"])), edges.map(([u, v]) => (path.some(([a, b]) => a === u && b === v) ? "result" : flow[u][v] > 0 ? "good" : "idle")), {
              title: `Cheapest path costs ${dist[t]} per unit; push ${add}`,
              label: `${path.map(([u, v]) => `${u}â†’${v}`).join(" ")}   total cost ${totalCost}`,
              counters: [count("flow", totalFlow), count("cost", totalCost)],
              legend: LEG,
              happened: `The residual shortest path has cost ${dist[t]}; ${add} units are pushed.`,
              why: "Successive shortest augmenting paths give the minimum cost for each achieved flow value.",
              codeLine: 20,
            }));
          }
          steps.push(graphStep(labels, edges.map(([u, v]) => [u, v]), Object.fromEntries(labels.map((i) => [i, i === s || i === t ? "result" : "done"])), edges.map(([u, v]) => (flow[u][v] > 0 ? "good" : "idle")), {
            title: `Answer: maximum flow ${totalFlow} at minimum cost ${totalCost}`,
            label: "no cheaper residual augmenting path remains",
            counters: [count("flow", totalFlow), count("cost", totalCost)],
            legend: LEG,
            happened: `${totalFlow} units move; the total price is ${totalCost}.`,
            why: "Each augmentation was the cheapest possible at its flow level, so the final flow is min-cost.",
            codeLine: 26,
          }));
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "word-ladder-ii",
    title: "Word Ladder II",
    category: "Graphs",
    difficulty: "Advanced",
    description: "List every shortest word ladder from the begin word to the end word.",
    input: { label: "begin | end | dictionary words", default: "hit | cog | hot,dot,dog,lot,log,cog", parse: "string" },
    approaches: [
      {
        name: "BFS Layers + Backtracking",
        complexity: "O(words Ã— length Ã— 26 + paths) time",
        idea: [
          "BFS records the distance of every reachable word and keeps all parents that reach it at the shortest distance.",
          "A word can have several equally short predecessors, so backtracking from the end through those parent lists enumerates every shortest ladder without duplicates or longer detours.",
        ],
        problem: [
          "Keeping only one parent reports a single path; DFS without distance limits also produces paths that are not shortest.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nchar *dict[] = {\"hot\",\"dot\",\"dog\",\"lot\",\"log\",\"cog\"};\nint dist[7], parent[7][7], pcount[7];\nint used[7];\n\nint differs1(const char *a, const char *b) {\n    int d = 0;\n    for (int i = 0; i < 3; i++) if (a[i] != b[i]) d++;\n    return d == 1;\n}\n\nvoid dfs(int id) {\n    if (id < 0) { printf(\"hit \"); return; }\n    dfs(dist[id] == 1 ? -1 : parent[id][0]);\n    printf(\"%s \", dict[id]);\n}\n\nint main(void) {\n    for (int i = 0; i < 7; i++) dist[i] = -1;\n    int q[16], head = 0, tail = 0, end = -1;\n    q[tail++] = -1;\n\n    while (head < tail) {\n        int u = q[head++];\n        const char *w = u < 0 ? \"hit\" : dict[u];\n        if (strcmp(w, \"cog\") == 0) { end = u; break; }\n        for (int i = 0; i < 6; i++)\n            if (differs1(w, dict[i])) {\n                if (dist[i] == -1) { dist[i] = (u < 0 ? 0 : dist[u]) + 1; q[tail++] = i; }\n                if (dist[i] == (u < 0 ? 1 : dist[u] + 1)) parent[i][pcount[i]++] = u;\n            }\n    }\n\n    if (end >= 0) { dfs(end); printf(\"\\\\n\"); }\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <unordered_set>\n#include <unordered_map>\nusing namespace std;\n\nbool differsOne(const string& a, const string& b) {\n    int d = 0;\n    for (int i = 0; i < (int)a.size(); i++) if (a[i] != b[i] && ++d > 1) return false;\n    return d == 1;\n}\n\nvoid dfs(string w, string begin, unordered_map<string, vector<string>>& parent, vector<string>& path, vector<vector<string>>& out) {\n    if (w == begin) {\n        vector<string> row(path.rbegin(), path.rend());\n        out.push_back(row);\n        return;\n    }\n    for (auto& p : parent[w]) { path.push_back(p); dfs(p, begin, parent, path, out); path.pop_back(); }\n}\n\nvector<vector<string>> findLadders(string begin, string end, vector<string>& words) {\n    unordered_set<string> dict(words.begin(), words.end());\n    if (!dict.count(end)) return {};\n\n    unordered_map<string, int> dist;\n    unordered_map<string, vector<string>> parent;\n    vector<string> level{begin};\n    dist[begin] = 0;\n\n    while (!level.empty()) {\n        vector<string> next;\n        for (auto& w : level) {\n            for (int i = 0; i < (int)w.size(); i++) {\n                string t = w;\n                for (char c = 'a'; c <= 'z'; c++) {\n                    if (c == w[i]) continue;\n                    t[i] = c;\n                    if (!dict.count(t)) continue;\n                    if (!dist.count(t)) { dist[t] = dist[w] + 1; next.push_back(t); }\n                    if (dist[t] == dist[w] + 1) parent[t].push_back(w);\n                }\n            }\n        }\n        level = next;\n    }\n\n    vector<vector<string>> out;\n    vector<string> path{end};\n    if (dist.count(end)) dfs(end, begin, parent, path, out);\n    return out;\n}\n\nint main() {\n    vector<string> words{\"hot\",\"dot\",\"dog\",\"lot\",\"log\",\"cog\"};\n    for (auto& p : findLadders(\"hit\", \"cog\", words)) {\n        for (auto& w : p) cout << w << ' ';\n        cout << '\\\\n';\n    }\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const begin = (parts[0] || "").split(/[\s,]+/)[0] || "";
          const end = (parts[1] || "").split(/[\s,]+/)[0] || "";
          const words = wordsOf(parts[2] || "").slice(0, 24);
          if (!begin || !end) return [{
            title: "Give begin and end words",
            tracks: [chips("words", ["â€”"], "idle")],
            counters: [count("paths", 0)],
            legend: LEG,
            happened: "Both endpoints are required.",
            why: "A ladder needs a start and a finish.",
          }];
          const dist = new Map([[begin, 0]]);
          const parents = new Map();
          let frontier = [begin];
          const steps = [];
          steps.push({
            title: `BFS starts at "${begin}"`,
            tracks: [
              chips("dictionary", [begin].concat(words).slice(0, 20), (i) => (i === 0 ? "read" : "idle")),
              chips("frontier", [begin], "active"),
            ],
            counters: [count("reached", 1, words.length + 1), count("depth", 0)],
            legend: LEG,
            happened: "The begin word has distance 0; every other word is unknown.",
            why: "BFS discovers shortest distances layer by layer.",
            codeLine: 7,
          });
          let depth = 0;
          let found = dist.has(end);
          while (frontier.length && !found && depth < 12) {
            depth++;
            const next = [];
            frontier.forEach((w) => {
              words.forEach((cand) => {
                if (!differsOne(w, cand)) return;
                if (!dist.has(cand)) { dist.set(cand, depth); next.push(cand); }
                if (dist.get(cand) === depth) {
                  if (!parents.has(cand)) parents.set(cand, []);
                  if (!parents.get(cand).includes(w)) parents.get(cand).push(w);
                }
              });
            });
            frontier = next;
            if (dist.has(end)) found = true;
            const reachedNow = [...dist.keys()].slice(0, 20);
            steps.push({
              title: next.length ? `Depth ${depth}: ${next.length} new word${next.length === 1 ? "" : "s"}` : `Depth ${depth}: no new word`,
              tracks: [
                chips("reached", reachedNow, (i) => (next.includes(reachedNow[i]) ? "active" : "done")),
                chips("frontier", next.slice(0, 10), "active"),
              ],
              counters: [count("reached", dist.size, words.length + 1), count("depth", depth)],
              legend: LEG,
              happened: next.length ? `Every word in this layer is exactly ${depth} mutations from ${begin}.` : "No unused word is one mutation away.",
              why: "Recording all parents at the new distance preserves every shortest route.",
              codeLine: 14,
            });
          }
          if (!dist.has(end)) {
            steps.push({
              title: "Answer: no ladder exists",
              tracks: [chips("reached", [...dist.keys()].slice(0, 16), "done"), chips("unreachable", words.filter((w) => !dist.has(w)).slice(0, 12), "bad")],
              counters: [count("paths", 0), count("reached", dist.size)],
              legend: LEG,
              happened: "BFS ended without assigning a distance to the target.",
              why: "The target is in another component of the one-mutation graph.",
              codeLine: 22,
            });
            return steps;
          }
          const paths = [];
          const all = [];
          const walk = (w, path) => {
            if (all.length >= 6) return;
            if (w === begin) { all.push(path.slice().reverse()); return; }
            (parents.get(w) || []).forEach((p) => { path.push(p); walk(p, path); path.pop(); });
          };
          walk(end, [end]);
          all.forEach((path, i) => {
            paths.push(path);
            steps.push({
              title: `Shortest ladder ${i + 1}: ${path.join(" â†’ ")}`,
              tracks: [
                chips("ladder", path, "result"),
                chips("other words", [...dist.keys()].filter((w) => !path.includes(w)).slice(0, 14), "done"),
              ],
              counters: [count("paths", paths.length), count("length", path.length)],
              legend: LEG,
              happened: `Backtracking through shared parents recovers ladder ${i + 1}.`,
              why: "Every prefix step stays at distance one less, so the path is shortest.",
              codeLine: 27,
            });
          });
          if (!all.length) {
            steps.push({
              title: "Answer: the end word was reached but no path was retained",
              tracks: [chips("distances", [...dist.entries()].slice(0, 12).map(([w, d]) => `${w}:${d}`), "idle")],
              counters: [count("paths", 0)],
              legend: LEG,
              happened: "The parent lists did not connect back to the begin word.",
              why: "A shortest path needs a complete chain of distance-decreasing parents.",
              codeLine: 30,
            });
          } else {
            steps.push({
              title: `Answer: ${all.length} shortest ladder${all.length === 1 ? "" : "s"}`,
              tracks: all.slice(0, 6).map((p, i) => chips(`ladder ${i + 1}`, p, "result")),
              counters: [count("paths", all.length), count("depth", dist.get(end))],
              legend: LEG,
              happened: all.map((p) => p.join(" â†’ ")).join("  |  "),
              why: "All enumerated ladders have the same BFS depth, so none is longer than another.",
              codeLine: 33,
            });
          }
          return steps;
        },
      },
    ],
  });
})();

