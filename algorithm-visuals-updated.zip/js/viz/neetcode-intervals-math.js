/* ============================================================
   DSA Visuals - NeetCode 250 additions, intervals, bits and math
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, grid } = window.H;
  const V = window.VIZ;

  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => "[" + a.join(", ") + "]";
  const ints = (s) => String(s || "").split(/[\s,;]+/).filter(Boolean).map(Number).filter(Number.isFinite);
  const pairs = (s) => String(s || "").split(/[\s;|]+/).filter(Boolean).map((p) => p.split(",").map(Number)).filter((p) => p.length >= 2 && p.every(Number.isFinite));
  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];

  /* ---------------------------------------------------------- */
  V.register({
    id: "meeting-rooms-iii",
    title: "Meeting Rooms III",
    category: "Intervals",
    difficulty: "Advanced",
    description: "Assign meetings to rooms and find the busiest room.",
    input: { label: "rooms | meetings start,end", default: "2 | 0,10 1,5 2,7 3,4", parse: "string" },
    approaches: [
      {
        name: "Earliest Free Room",
        complexity: "O(m log n) time, O(n) space",
        idea: [
          "Sort meetings by start time. Keep the end time of every room in a min-heap so the room that becomes free first is easy to find.",
          "If a room is already free, use the lowest-numbered one. Otherwise delay the meeting until the earliest room is free, preserving its duration. Count how many meetings each room hosts.",
        ],
        problem: ["Delayed meetings keep their original duration, so the new end is the current free time plus duration."],
        code: {
          c: `#include <stdlib.h>\n\nint cmp(const void* a, const void* b) {\n    int* x = *(int**)a; int* y = *(int**)b;\n    if (x[0] != y[0]) return x[0] - y[0];\n    return x[1] - y[1];\n}\n\nint mostBooked(int n, int** meetings, int m, int* returnSize) {\n    qsort(meetings, m, sizeof(int*), cmp);\n    long long* freeAt = calloc(n, sizeof(long long));\n    int* used = calloc(n, sizeof(int));\n    for (int i = 0; i < m; i++) {\n        long long start = meetings[i][0];\n        int room = -1;\n        for (int r = 0; r < n; r++)\n            if (freeAt[r] <= start) { room = r; break; }\n        if (room < 0) {\n            room = 0;\n            for (int r = 1; r < n; r++)\n                if (freeAt[r] < freeAt[room]) room = r;\n        }\n        long long begin = freeAt[room] > start ? freeAt[room] : start;\n        freeAt[room] = begin + (meetings[i][1] - meetings[i][0]);\n        used[room]++;\n    }\n    int ans = 0;\n    for (int r = 1; r < n; r++) if (used[r] > used[ans]) ans = r;\n    *returnSize = n;\n    return ans;\n}`,
          cpp: `#include <algorithm>\n#include <queue>\n#include <vector>\nusing namespace std;\n\nint mostBooked(int n, vector<vector<int>>& meetings) {\n    sort(meetings.begin(), meetings.end());\n    priority_queue<int, vector<int>, greater<>> freeRooms;\n    priority_queue<pair<long long,int>, vector<pair<long long,int>>, greater<>> used;\n    for (int r = 0; r < n; r++) freeRooms.push(r);\n    vector<int> booked(n, 0);\n    for (auto& m : meetings) {\n        while (!used.empty() && used.top().first <= m[0]) {\n            freeRooms.push(used.top().second);\n            used.pop();\n        }\n        int r;\n        long long start;\n        if (!freeRooms.empty()) {\n            r = freeRooms.top(); freeRooms.pop();\n            start = m[0];\n        } else {\n            start = used.top().first;\n            r = used.top().second;\n            used.pop();\n        }\n        used.push({start + (m[1] - m[0]), r});\n        booked[r]++;\n    }\n    int ans = 0;\n    for (int r = 1; r < n; r++) if (booked[r] > booked[ans]) ans = r;\n    return ans;\n}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const n = Math.max(1, parseInt(parts[0], 10) || 1);
          const meetings = pairs(parts[1] || "").sort((a, b) => a[0] - b[0] || a[1] - b[1]);
          const freeAt = new Array(n).fill(0);
          const used = new Array(n).fill(0);
          const freeRooms = Array.from({ length: n }, (_, i) => i);
          const busy = [];
          const out = [];
          out.push({
            title: `Assign meetings to ${n} room(s)`,
            tracks: [chips("meetings", meetings.map((m) => m[0] + "-" + m[1]), "idle"), chips("free at", freeAt, "idle")],
            counters: [count("rooms", n), count("meetings", meetings.length)],
            happened: "Every room is available at time zero.",
            why: "Sorting by start ensures a meeting never jumps ahead of an earlier request.",
            legend: LEG,
            codeLine: 5,
          });
          for (let i = 0; i < meetings.length; i++) {
            const [start, end] = meetings[i];
            for (let j = busy.length - 1; j >= 0; j--) {
              if (busy[j].end <= start) {
                freeAt[busy[j].room] = 0;
                freeRooms.push(busy[j].room);
                busy.splice(j, 1);
              }
            }
            freeRooms.sort((a, b) => a - b);
            let room, actualStart;
            if (freeRooms.length) {
              room = freeRooms.shift();
              actualStart = start;
            } else {
              busy.sort((a, b) => a.end - b.end || a.room - b.room);
              const earliest = busy.shift();
              room = earliest.room;
              actualStart = earliest.end;
            }
            const duration = end - start;
            const actualEnd = actualStart + duration;
            freeAt[room] = actualEnd;
            busy.push({ end: actualEnd, room });
            used[room]++;
            out.push({
              title: `Meeting ${start}-${end} uses room ${room + 1}`,
              tracks: [chips("meetings", meetings.map((m, k) => m[0] + "-" + m[1]), (k) => (k === i ? "read" : k < i ? "done" : "idle")), chips("busy until", freeAt.map((t, r) => "R" + (r + 1) + ":" + t), (r) => (r === room ? "result" : "idle"))],
              counters: [count("actual start", actualStart), count("room uses", used[room])],
              happened: actualStart === start ? "The lowest-numbered free room was used." : `The meeting was delayed to ${actualStart} for the earliest-free room.`,
              why: "If a room is free, the lowest-numbered one is chosen; otherwise the earliest-free room minimizes the delay.",
              legend: LEG,
              codeLine: 13,
            });
          }
          let best = 0;
          for (let r = 1; r < n; r++) if (used[r] > used[best]) best = r;
          out.push({
            title: `Room ${best + 1} is busiest with ${used[best]} meeting(s)`,
            tracks: [chips("room uses", used.map((u, r) => "R" + (r + 1) + ":" + u), (r) => (r === best ? "result" : "idle"))],
            counters: [count("max meetings", used[best]), count("room", best + 1)],
            happened: "The room with the largest count wins, with ties going to the smaller index.",
            why: "The counts were accumulated throughout the assignment.",
            legend: LEG,
            codeLine: 20,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "minimum-interval-including-query",
    title: "Minimum Interval to Include Each Query",
    category: "Intervals",
    difficulty: "Advanced",
    description: "For every query point, find the shortest interval that covers it.",
    input: { label: "intervals | queries", default: "1,4 2,5 3,6 | 2 3 5", parse: "string" },
    approaches: [
      {
        name: "Sort Intervals and Queries",
        complexity: "O((n + q) log n) time, O(n) space",
        idea: [
          "Sort intervals by left endpoint and queries by value. As a query moves right, add every interval whose left endpoint is at most the query.",
          "A min-heap keyed by interval length keeps the shortest candidate. Remove intervals that end before the query, because they cannot cover it. The heap top is the answer.",
        ],
        problem: ["Queries must be processed in sorted order and then written back to their original positions."],
        code: {
          c: `#include <stdlib.h>\n\ntypedef struct { int left, right, len; } Interval;\nint cmp(const void* a, const void* b) { return ((Interval*)a)->left - ((Interval*)b)->left; }\nint qcmp(const void* a, const void* b) { return *(int*)a - *(int*)b; }\n\nint* minInterval(int** intervals, int n, int* queries, int q, int* returnSize) {\n    Interval* a = malloc(n * sizeof(Interval));\n    for (int i = 0; i < n; i++) a[i] = (Interval){intervals[i][0], intervals[i][1], intervals[i][1]-intervals[i][0]+1};\n    qsort(a, n, sizeof(Interval), cmp);\n    int* out = malloc(q * sizeof(int));\n    int i = 0;\n    for (int k = 0; k < q; k++) {\n        int best = -1;\n        for (int j = 0; j < n; j++) {\n            if (a[j].left <= queries[k] && a[j].right >= queries[k]) {\n                if (best < 0 || a[j].len < best) best = a[j].len;\n            }\n        }\n        out[k] = best;\n    }\n    *returnSize = q;\n    return out;\n}`,
          cpp: `#include <algorithm>\n#include <queue>\n#include <vector>\nusing namespace std;\n\nvector<int> minInterval(vector<vector<int>>& intervals, vector<int>& queries) {\n    sort(intervals.begin(), intervals.end());\n    vector<int> order(queries.size());\n    for (int i = 0; i < (int)order.size(); i++) order[i] = i;\n    sort(order.begin(), order.end(), [&](int a, int b) { return queries[a] < queries[b]; });\n    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<>> pq;\n    vector<int> ans(queries.size(), -1);\n    int i = 0;\n    for (int qi : order) {\n        while (i < (int)intervals.size() && intervals[i][0] <= queries[qi]) {\n            pq.push({intervals[i][1] - intervals[i][0] + 1, intervals[i][1]});\n            i++;\n        }\n        while (!pq.empty() && pq.top().second < queries[qi]) pq.pop();\n        if (!pq.empty()) ans[qi] = pq.top().first;\n    }\n    return ans;\n}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const intervals = pairs(parts[0] || "").sort((a, b) => a[0] - b[0]);
          const queries = ints(parts[1] || "");
          const order = queries.map((q, i) => i).sort((a, b) => queries[a] - queries[b]);
          const heap = [];
          const ans = new Array(queries.length).fill(-1);
          let added = 0;
          const out = [];
          out.push({
            title: "Sort queries while keeping their positions",
            tracks: [chips("intervals", intervals.map((x) => x[0] + "-" + x[1]), "idle"), chips("queries", queries, "idle")],
            counters: [count("intervals", intervals.length), count("queries", queries.length)],
            happened: `Queries are processed in increasing value order: ${show(order.map((i) => queries[i]))}.`,
            why: "Moving only right means intervals never need to be removed for having too large a left endpoint.",
            legend: LEG,
            codeLine: 2,
          });
          for (const original of order) {
            const q = queries[original];
            while (added < intervals.length && intervals[added][0] <= q) {
              const [l, r] = intervals[added];
              heap.push({ len: r - l + 1, right: r, label: l + "-" + r });
              added++;
            }
            heap.sort((a, b) => a.len - b.len || a.right - b.right);
            while (heap.length && heap[0].right < q) heap.shift();
            const answer = heap.length ? heap[0].len : -1;
            ans[original] = answer;
            out.push({
              title: `Query ${q}: ${answer < 0 ? "no covering interval" : "shortest length " + answer}`,
              tracks: [chips("active intervals", heap.map((h) => h.label + " (len " + h.len + ")"), "active"), chips("answers", ans.map((x) => (x < 0 ? "-1" : x)), original)],
              counters: [count("active candidates", heap.length), count("answer", answer < 0 ? "none" : answer)],
              happened: answer < 0 ? "Every active interval ends before this query." : `The shortest active interval has length ${answer}.`,
              why: "The heap orders by length, while expired intervals are discarded from the front.",
              legend: LEG,
              codeLine: 12,
            });
          }
          out.push({
            title: `Answers: ${show(ans)}`,
            tracks: [chips("answers", ans.map((x) => (x < 0 ? "-1" : x)), "result")],
            counters: [count("queries answered", ans.length, queries.length)],
            happened: "Each answer was written back to the query's original index.",
            why: "Sorting was only a processing order; the output order stays aligned with the input.",
            legend: LEG,
            codeLine: 18,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "add-binary",
    title: "Add Binary",
    category: "Bit Manipulation",
    difficulty: "Beginner",
    description: "Add two binary strings and return the binary sum.",
    input: { label: "binary a | binary b", default: "11 | 1", parse: "string" },
    approaches: [
      {
        name: "Add from the Right with Carry",
        complexity: "O(max(a, b)) time, O(max(a, b)) space",
        idea: [
          "The least significant bit is at the end of each string. Add the two current bits plus any carry, then write the result bit and update the carry.",
          "When one string runs out, treat its missing bits as zero. A final carry becomes a new leading one.",
        ],
        problem: ["The result must be built backward or reversed because carries flow from right to left."],
        code: {
          c: `#include <stdlib.h>\n#include <string.h>\n\nchar* addBinary(char* a, char* b) {\n    int i = strlen(a) - 1, j = strlen(b) - 1, k = 0;\n    char* out = malloc(i + j + 3);\n    int carry = 0;\n    while (i >= 0 || j >= 0 || carry) {\n        int sum = carry;\n        if (i >= 0) sum += a[i--] - '0';\n        if (j >= 0) sum += b[j--] - '0';\n        out[k++] = '0' + (sum & 1);\n        carry = sum >> 1;\n    }\n    out[k] = '\\\\0';\n    for (int l = 0, r = k - 1; l < r; l++, r--) { char t = out[l]; out[l] = out[r]; out[r] = t; }\n    return out;\n}`,
          cpp: `#include <algorithm>\n#include <string>\nusing namespace std;\n\nstring addBinary(string a, string b) {\n    int i = a.size() - 1, j = b.size() - 1, carry = 0;\n    string out;\n    while (i >= 0 || j >= 0 || carry) {\n        int sum = carry;\n        if (i >= 0) sum += a[i--] - '0';\n        if (j >= 0) sum += b[j--] - '0';\n        out += char('0' + (sum & 1));\n        carry = sum >> 1;\n    }\n    reverse(out.begin(), out.end());\n    return out;\n}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const a = [...(parts[0] || "0")];
          const b = [...(parts[1] || "0")];
          const out = [];
          const result = [];
          let i = a.length - 1, j = b.length - 1, carry = 0;
          out.push({
            title: "Start from the least significant bits",
            tracks: [track("a", a, a.map((x, k) => (k === a.length - 1 ? "read" : "idle"))), track("b", b, b.map((x, k) => (k === b.length - 1 ? "read" : "idle"))), chips("result", [], "idle")],
            counters: [count("carry", 0), count("position from right", 0)],
            happened: "The rightmost character is the 1s place.",
            why: "Addition propagates a carry from right to left, just like decimal addition.",
            legend: LEG,
            codeLine: 5,
          });
          while (i >= 0 || j >= 0 || carry) {
            const bitA = i >= 0 ? Number(a[i]) : 0;
            const bitB = j >= 0 ? Number(b[j]) : 0;
            const total = bitA + bitB + carry;
            result.push(String(total % 2));
            const nextCarry = Math.floor(total / 2);
            out.push({
              title: `${bitA} + ${bitB} + carry ${carry} = ${total}`,
              tracks: [track("a", a, a.map((x, k) => (k === i ? "read" : k > i ? "done" : "idle"))), track("b", b, b.map((x, k) => (k === j ? "read" : k > j ? "done" : "idle"))), chips("result (reversed)", result, "active")],
              counters: [count("write bit", total % 2), count("new carry", nextCarry)],
              happened: `Write ${total % 2} and carry ${nextCarry}.`,
              why: "A sum of two or more in binary produces a carry into the next column.",
              legend: LEG,
              codeLine: 7,
            });
            carry = nextCarry;
            i--;
            j--;
          }
          const answer = result.slice().reverse().join("");
          out.push({
            title: `Sum is ${answer}`,
            tracks: [chips("answer", [answer], "result")],
            counters: [count("answer", answer), count("length", answer.length)],
            happened: "The reversed collected bits form the binary sum.",
            why: "The last carry, if any, was already included as a leading bit.",
            legend: LEG,
            codeLine: 13,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "reverse-integer",
    title: "Reverse Integer",
    category: "Bit Manipulation",
    difficulty: "Intermediate",
    description: "Reverse the digits of a signed integer, rejecting overflow.",
    input: { label: "Integer", default: "123", parse: "int" },
    approaches: [
      {
        name: "Pop and Push Digits",
        complexity: "O(number of digits) time, O(1) space",
        idea: [
          "Take the last digit with x % 10, append it to the result with result * 10 + digit, then remove that digit from x with integer division.",
          "Before appending, check whether the result would exceed the signed 32-bit range. If it would, return zero.",
        ],
        problem: ["Languages with arbitrary-precision integers will not overflow naturally, so the bounds must be checked explicitly."],
        code: {
          c: `#include <limits.h>\n\nint reverse(int x) {\n    int out = 0;\n    while (x != 0) {\n        int digit = x % 10;\n        x /= 10;\n        if (out > INT_MAX / 10 || (out == INT_MAX / 10 && digit > 7)) return 0;\n        if (out < INT_MIN / 10 || (out == INT_MIN / 10 && digit < -8)) return 0;\n        out = out * 10 + digit;\n    }\n    return out;\n}`,
          cpp: `#include <climits>\n\nint reverse(int x) {\n    int out = 0;\n    while (x != 0) {\n        int digit = x % 10;\n        x /= 10;\n        if (out > INT_MAX / 10 || (out == INT_MAX / 10 && digit > 7)) return 0;\n        if (out < INT_MIN / 10 || (out == INT_MIN / 10 && digit < -8)) return 0;\n        out = out * 10 + digit;\n    }\n    return out;\n}`,
        },
        steps(x) {
          const out = [];
          let value = x;
          let result = 0;
          let digits = String(Math.abs(x));
          out.push({
            title: `Reverse ${x}`,
            tracks: [chips("remaining number", [value], "read"), chips("reversed so far", [0], "idle")],
            counters: [count("digit", Math.abs(value) % 10), count("reversed", 0)],
            happened: "The sign is handled naturally by integer division and remainder.",
            why: "Removing the last digit and appending it to the result reverses the order.",
            legend: LEG,
            codeLine: 3,
          });
          let guard = 0;
          while (value !== 0 && guard++ < 12) {
            const digit = value % 10;
            value = Math.trunc(value / 10);
            const wouldOverflow = result > 214748364 || (result === 214748364 && digit > 7) || result < -214748364 || (result === -214748364 && digit < -8);
            if (wouldOverflow) {
              out.push({
                title: "The next digit would overflow",
                tracks: [chips("remaining number", [value], "done"), chips("reversed so far", [result], "bad")],
                counters: [count("digit", digit), count("answer", 0)],
                happened: "Appending another digit would leave the signed 32-bit range.",
                why: "The problem requires returning zero instead of a wrapped value.",
                legend: LEG,
                codeLine: 8,
              });
              return out;
            }
            result = result * 10 + digit;
            out.push({
              title: `Pop ${digit}; reversed is ${result}`,
              tracks: [chips("remaining number", [value], "active"), chips("reversed so far", [result], "result")],
              counters: [count("digit", digit), count("reversed", result)],
              happened: `The last digit moved to the front of the reversed prefix.`,
              why: "Multiplying by ten shifts existing digits left to make room.",
              legend: LEG,
              codeLine: 10,
            });
          }
          out.push({
            title: `Reversed integer is ${result}`,
            tracks: [chips("answer", [result], "result")],
            counters: [count("answer", result), count("digits", digits.length)],
            happened: "No overflow occurred during the reversal.",
            why: "Every digit was popped once and pushed once.",
            legend: LEG,
            codeLine: 12,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "minimum-array-end",
    title: "Minimum Array End",
    category: "Bit Manipulation",
    difficulty: "Intermediate",
    description: "Build a strictly increasing array whose bitwise AND equals x.",
    input: { label: "n | x", default: "3 | 4", parse: "string" },
    approaches: [
      {
        name: "Pack the Counter into Free Bits",
        complexity: "O(log n + log x) time, O(1) space",
        idea: [
          "Every element must contain every set bit of x. To keep the last element as small as possible, start with x and then fill its zero bit positions with the binary representation of n - 1.",
          "Bits already set in x never change. The remaining counter bits are inserted into the gaps from least significant to most significant.",
        ],
        problem: ["The result can exceed 32 bits, so a 64-bit accumulator is needed in languages with fixed-width integers."],
        code: {
          c: `long long minEnd(int n, int x) {\n    long long ans = x;\n    int counter = n - 1;\n    for (int bit = 0; counter > 0; bit++) {\n        if (((x >> bit) & 1LL) == 0) {\n            if (counter & 1) ans |= 1LL << bit;\n            counter >>= 1;\n        }\n    }\n    return ans;\n}`,
          cpp: `long long minEnd(int n, long long x) {\n    long long ans = x;\n    int counter = n - 1;\n    for (int bit = 0; counter > 0; bit++) {\n        if (((x >> bit) & 1LL) == 0) {\n            if (counter & 1) ans |= 1LL << bit;\n            counter >>= 1;\n        }\n    }\n    return ans;\n}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const n = Math.max(1, parseInt(parts[0], 10) || 1);
          const x = Math.max(0, parseInt(parts[1], 10) || 0);
          const out = [];
          let ans = x;
          let counter = n - 1;
          const baseBits = x.toString(2).padStart(6, "0");
          out.push({
            title: `Start from x = ${x}`,
            tracks: [chips("x bits", [...baseBits], "read"), chips("counter", [counter], "idle")],
            counters: [count("answer", ans), count("counter", counter)],
            happened: "The set bits of x are fixed in every element.",
            why: "Clearing any of those bits would change the required bitwise AND.",
            legend: LEG,
            codeLine: 2,
          });
          for (let bit = 0; counter > 0; bit++) {
            const isFree = ((x >> bit) & 1) === 0;
            if (isFree) {
              if (counter & 1) ans |= 1 << bit;
              counter >>= 1;
              out.push({
                title: `Fill bit ${bit} with ${((ans >> bit) & 1) ? 1 : 0}`,
                tracks: [chips("answer bits", ans.toString(2).padStart(8, "0").split(""), (k) => (k >= 8 - Math.max(1, Math.floor(Math.log2(ans + 1)) + 1) ? "result" : "idle")), chips("remaining counter", [counter], "active")],
                counters: [count("answer", ans), count("counter", counter)],
                happened: isFree ? "This zero bit of x was free, so it received the next counter bit." : "Set bits of x are skipped and left unchanged.",
                why: "Packing the counter into free bits gives the smallest possible final value.",
                legend: LEG,
                codeLine: 6,
              });
            }
          }
          out.push({
            title: `Smallest possible array end is ${ans}`,
            tracks: [chips("answer", [ans], "result"), chips("bits", [ans.toString(2)], "result")],
            counters: [count("answer", ans), count("n", n)],
            happened: "The last element contains x and encodes n - 1 in the remaining gaps.",
            why: "Using the lowest free bits keeps the result as small as possible.",
            legend: LEG,
            codeLine: 9,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "excel-sheet-column-title",
    title: "Excel Sheet Column Title",
    category: "Math & Geometry",
    difficulty: "Beginner",
    description: "Convert a positive column number to its Excel letter label.",
    input: { label: "Column number", default: "28", parse: "int" },
    approaches: [
      {
        name: "Bijective Base 26",
        complexity: "O(log n) time, O(log n) space",
        idea: [
          "Excel labels behave like base 26, except there is no zero digit: columns are A through Z, then AA. Subtracting one before taking the remainder maps 1..26 onto 0..25.",
          "Repeatedly take (n - 1) % 26 as the next letter and divide n - 1 by 26. The letters come out from least significant to most, so the result is reversed or prepended.",
        ],
        problem: ["Ordinary base conversion would produce a zero digit, so the off-by-one adjustment is essential."],
        code: {
          c: `#include <stdlib.h>\n\nchar* convertToTitle(int n) {\n    char* out = malloc(16);\n    int k = 0;\n    while (n > 0) {\n        n--;\n        out[k++] = 'A' + (n % 26);\n        n /= 26;\n    }\n    out[k] = '\\\\0';\n    for (int i = 0, j = k - 1; i < j; i++, j--) {\n        char t = out[i]; out[i] = out[j]; out[j] = t;\n    }\n    return out;\n}`,
          cpp: `#include <algorithm>\n#include <string>\nusing namespace std;\n\nstring convertToTitle(int n) {\n    string out;\n    while (n > 0) {\n        n--;\n        out += char('A' + n % 26);\n        n /= 26;\n    }\n    reverse(out.begin(), out.end());\n    return out;\n}`,
        },
        steps(n) {
          let value = n;
          const letters = [];
          const out = [];
          out.push({
            title: `Convert column ${n}`,
            tracks: [chips("number", [value], "read"), chips("letters (least significant first)", [], "idle")],
            counters: [count("number", value), count("letters", 0)],
            happened: "Excel columns start at A = 1, so the remainder needs a one-based adjustment.",
            why: "There is no zero letter; subtracting one turns 1..26 into 0..25.",
            legend: LEG,
            codeLine: 3,
          });
          while (value > 0) {
            value--;
            const ch = String.fromCharCode(65 + (value % 26));
            value = Math.floor(value / 26);
            letters.push(ch);
            out.push({
              title: `Next letter is ${ch}`,
              tracks: [chips("number", [value], "active"), chips("letters (least significant first)", letters, "result")],
              counters: [count("number", value), count("letters", letters.length)],
              happened: `${ch} is the next digit from the right.`,
              why: "Dividing the adjusted number by 26 removes the digit just processed.",
              legend: LEG,
              codeLine: 6,
            });
          }
          const answer = letters.slice().reverse().join("");
          out.push({
            title: `Column title is ${answer}`,
            tracks: [chips("answer", [answer], "result")],
            counters: [count("answer", answer), count("length", answer.length)],
            happened: "The collected letters reverse into normal reading order.",
            why: "The loop produces the least significant letter first.",
            legend: LEG,
            codeLine: 9,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "insert-greatest-common-divisors-in-linked-list",
    title: "Insert Greatest Common Divisors in Linked List",
    category: "Math & Geometry",
    difficulty: "Intermediate",
    description: "Insert the GCD of each adjacent pair between the two nodes.",
    input: { label: "Linked list values", default: "18, 6, 10, 3", parse: "ints" },
    approaches: [
      {
        name: "One Pass with Euclid",
        complexity: "O(n log max value) time, O(1) extra space",
        idea: [
          "Walk the list with a pointer to the current node and its next node. Compute gcd(current, next) using the Euclidean algorithm.",
          "Create a new node holding that gcd and splice it between the two. Then continue from the original next node so the newly inserted value is not paired again.",
        ],
        problem: ["The new nodes must be allocated; the list length grows to 2n - 1, so the memory cost is unavoidable."],
        code: {
          c: `#include <stdlib.h>\n\nstruct Node* insertGreatestCommonDivisors(struct Node* head) {\n    struct Node* cur = head;\n    while (cur && cur->next) {\n        int a = cur->val, b = cur->next->val;\n        while (b) { int t = a % b; a = b; b = t; }\n        struct Node* mid = malloc(sizeof(struct Node));\n        mid->val = a;\n        mid->next = cur->next;\n        cur->next = mid;\n        cur = mid->next;\n    }\n    return head;\n}`,
          cpp: `#include <numeric>\nusing namespace std;\n\nListNode* insertGreatestCommonDivisors(ListNode* head) {\n    ListNode* cur = head;\n    while (cur && cur->next) {\n        int g = gcd(cur->val, cur->next->val);\n        ListNode* mid = new ListNode(g, cur->next);\n        cur->next = mid;\n        cur = mid->next;\n    }\n    return head;\n}`,
        },
        steps(values) {
          const pairs = [];
          for (let i = 0; i + 1 < values.length; i++) pairs.push([values[i], values[i + 1]]);
          const list = values.slice();
          const out = [];
          out.push({
            title: "Walk adjacent pairs",
            tracks: [chips("linked list", list, "idle")],
            counters: [count("nodes", list.length), count("pairs", pairs.length)],
            happened: "Each original edge will gain one GCD node in the middle.",
            why: "The GCD of the two endpoint values belongs between them.",
            legend: LEG,
            codeLine: 3,
          });
          let offset = 0;
          for (let i = 0; i < pairs.length; i++) {
            const [a, b] = pairs[i];
            let x = a, y = b;
            while (y) { const t = x % y; x = y; y = t; }
            const gcd = x;
            list.splice(i * 2 + 1 + offset, 0, gcd);
            offset++;
            out.push({
              title: `gcd(${a}, ${b}) = ${gcd}`,
              tracks: [chips("linked list", list, (k) => (k === i * 2 + 1 + offset - 1 ? "result" : (list[k] === a || list[k] === b) ? "done" : "idle"))],
              counters: [count("inserted", gcd), count("length", list.length)],
              happened: `Insert ${gcd} between ${a} and ${b}.`,
              why: "Euclid repeatedly replaces the pair with the remainder until zero remains.",
              legend: LEG,
              codeLine: 5,
            });
          }
          out.push({
            title: `Final list: ${show(list)}`,
            tracks: [chips("linked list", list, "result")],
            counters: [count("nodes", list.length), count("original nodes", values.length)],
            happened: "Every original adjacent pair now has its GCD in between.",
            why: "The walk skipped over inserted nodes, so no pair was processed twice.",
            legend: LEG,
            codeLine: 10,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "transpose-matrix",
    title: "Transpose Matrix",
    category: "Math & Geometry",
    difficulty: "Beginner",
    description: "Flip a matrix across its main diagonal.",
    input: { label: "matrix rows separated by |", default: "1 2 3 | 4 5 6", parse: "string" },
    approaches: [
      {
        name: "Copy Cell (r, c) to (c, r)",
        complexity: "O(rows * cols) time, O(rows * cols) space",
        idea: [
          "The transpose has the original columns as its rows. Cell (r, c) of the input becomes cell (c, r) of the output.",
          "Visit every input cell once and write it to the swapped position. Non-square matrices change shape, so a new output matrix is needed.",
        ],
        problem: ["In-place transposition is only straightforward for square matrices; rectangular matrices require a new allocation."],
        code: {
          c: `int** transpose(int** a, int rows, int cols, int* returnRows, int* returnCols) {\n    int** out = malloc(cols * sizeof(int*));\n    for (int c = 0; c < cols; c++) {\n        out[c] = malloc(rows * sizeof(int));\n        for (int r = 0; r < rows; r++) out[c][r] = a[r][c];\n    }\n    *returnRows = cols;\n    *returnCols = rows;\n    return out;\n}`,
          cpp: `#include <vector>\nusing namespace std;\n\nvector<vector<int>> transpose(vector<vector<int>>& a) {\n    int rows = a.size(), cols = a[0].size();\n    vector<vector<int>> out(cols, vector<int>(rows));\n    for (int r = 0; r < rows; r++)\n        for (int c = 0; c < cols; c++)\n            out[c][r] = a[r][c];\n    return out;\n}`,
        },
        steps(text) {
          const rows = String(text || "").split("|").map((r) => r.trim().split(/[\s,]+/).filter(Boolean).map(Number));
          const R = rows.length, C = Math.max(1, ...rows.map((r) => r.length));
          const a = Array.from({ length: R }, (_, r) => Array.from({ length: C }, (_, c) => rows[r][c] || 0));
          const t = Array.from({ length: C }, () => new Array(R).fill(""));
          const out = [];
          const gridOf = (arr, stateFor) => ({ kind: "grid", rows: arr.length, cols: arr[0].length, cells: grid(arr.length, arr[0].length, (r, c) => ({ r, c, v: arr[r][c], state: stateFor ? stateFor(r, c) : "idle" })) });
          out.push({
            title: "Output shape swaps rows and columns",
            ...gridOf(a, () => "idle"),
            label: `input ${R}x${C}; output will be ${C}x${R}`,
            counters: [count("input rows", R), count("output rows", C)],
            happened: `The input is ${R}x${C}; the transpose will be ${C}x${R}.`,
            why: "Transposing moves every element across the diagonal, which swaps the dimensions.",
            legend: LEG,
            codeLine: 3,
          });
          for (let r = 0; r < R; r++) {
            for (let c = 0; c < C; c++) {
              t[c][r] = a[r][c];
              out.push({
                title: `Move ${a[r][c]} from (${r},${c}) to (${c},${r})`,
                ...gridOf(t, (rr, cc) => (rr === c && cc === r ? "result" : t[rr][cc] !== "" ? "done" : "idle")),
                label: `copying from row ${r}, column ${c}`,
                counters: [count("cells copied", r * C + c + 1, R * C), count("new position", c + "," + r)],
                happened: `The value moved to row ${c}, column ${r}.`,
                why: "Swapping the coordinates is the entire transpose rule.",
                legend: LEG,
                codeLine: 7,
              });
            }
          }
          out.push({
            title: "Transpose complete",
            ...gridOf(t, () => "result"),
            label: `transposed ${C}x${R} matrix`,
            counters: [count("cells copied", R * C), count("shape", C + "x" + R)],
            happened: "Every input cell has a place in the new matrix.",
            why: "The copied coordinates cover each output cell exactly once.",
            legend: LEG,
            codeLine: 9,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "plus-one",
    title: "Plus One",
    category: "Math & Geometry",
    difficulty: "Beginner",
    description: "Add one to a number represented as a digit array.",
    input: { label: "Digits", default: "1, 2, 3", parse: "ints" },
    approaches: [
      {
        name: "Carry from the Right",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "Adding one starts at the least significant digit. If it is below nine, increment it and stop.",
          "If it is nine, it becomes zero and the carry moves left. If every digit was nine, the result needs a new leading one.",
        ],
        problem: ["The array may grow by one element, which requires a new allocation in fixed-size languages."],
        code: {
          c: `#include <stdlib.h>\n\nint* plusOne(int* digits, int n, int* returnSize) {\n    for (int i = n - 1; i >= 0; i--) {\n        if (digits[i] < 9) { digits[i]++; *returnSize = n; return digits; }\n        digits[i] = 0;\n    }\n    int* out = calloc(n + 1, sizeof(int));\n    out[0] = 1;\n    *returnSize = n + 1;\n    return out;\n}`,
          cpp: `#include <vector>\nusing namespace std;\n\nvector<int> plusOne(vector<int>& digits) {\n    for (int i = (int)digits.size() - 1; i >= 0; i--) {\n        if (digits[i] < 9) { digits[i]++; return digits; }\n        digits[i] = 0;\n    }\n    digits.insert(digits.begin(), 1);\n    return digits;\n}`,
        },
        steps(digits) {
          const a = digits.slice();
          const out = [];
          out.push({
            title: "Start at the last digit",
            tracks: [track("digits", a, a.map((x, i) => (i === a.length - 1 ? "read" : "idle")))],
            counters: [count("position", a.length - 1), count("carry", 1)],
            happened: "The carry begins as one at the rightmost position.",
            why: "The 1s place is the only digit that can absorb a +1 without carrying.",
            legend: LEG,
            codeLine: 2,
          });
          for (let i = a.length - 1; i >= 0; i--) {
            if (a[i] < 9) {
              a[i]++;
              out.push({
                title: `${a[i] - 1} becomes ${a[i]}`,
                tracks: [track("digits", a, a.map((x, k) => (k === i ? "result" : k > i ? "done" : "idle")))],
                counters: [count("position", i), count("carry", 0)],
                happened: "The digit did not overflow, so the carry stops here.",
                why: "No further digit needs to change once a non-nine is incremented.",
                legend: LEG,
                codeLine: 3,
              });
              out.push({ title: `Answer: ${show(a)}`, tracks: [track("digits", a, fill(a.length, "result"))], counters: [count("answer", show(a))], happened: "The existing array is the complete result.", why: "Only a suffix of nines changed, and it was short.", legend: LEG, codeLine: 4 });
              return out;
            }
            a[i] = 0;
            out.push({
              title: "Nine becomes zero; carry left",
              tracks: [track("digits", a, a.map((x, k) => (k === i ? "bad" : k > i ? "done" : "idle")))],
              counters: [count("position", i), count("carry", 1)],
              happened: "9 + 1 is 10, so this digit is 0 and the carry continues.",
              why: "The carry must be added to the next more significant digit.",
              legend: LEG,
              codeLine: 5,
            });
          }
          a.unshift(1);
          out.push({
            title: "Add a new leading one",
            tracks: [track("digits", a, [ "result", ...fill(a.length - 1, "done") ])],
            counters: [count("answer", show(a)), count("length", a.length)],
            happened: "Every digit was nine, so the number grew by one place.",
            why: "The final carry has no existing digit to occupy, so it becomes the new most significant digit.",
            legend: LEG,
            codeLine: 7,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "count-squares",
    title: "Detect Squares",
    category: "Math & Geometry",
    difficulty: "Intermediate",
    description: "Count axis-aligned squares having a queried point as one corner.",
    input: { label: "Operations", default: "add 3 3 add 1 1 count 2 2 count 3 3", parse: "words" },
    approaches: [
      {
        name: "Point Map and Diagonal Check",
        complexity: "O(n) per count, O(n) space",
        idea: [
          "Store how many times each point has been added. For a query point, every stored point with a different x and y and equal absolute coordinate difference is a possible opposite corner.",
          "The other two corners are determined by the query and that opposite corner. If both exist in the map, the number of squares grows by the product of the point multiplicities.",
        ],
        problem: ["Scanning every stored point for every count is linear; a grid-indexed structure can be faster for dense point sets."],
        code: {
          c: `typedef struct { int x, y, count; } Point;\n\nint multiplicity(Point* pts, int n, int x, int y) {\n    for (int i = 0; i < n; i++)\n        if (pts[i].x == x && pts[i].y == y) return pts[i].count;\n    return 0;\n}\n\nint countSquares(Point* pts, int n, int qx, int qy) {\n    int total = 0;\n    for (int i = 0; i < n; i++) {\n        int dx = pts[i].x - qx, dy = pts[i].y - qy;\n        int adx = dx < 0 ? -dx : dx;\n        int ady = dy < 0 ? -dy : dy;\n        if (dx == 0 || adx != ady) continue;\n        int a = multiplicity(pts, n, qx, pts[i].y);\n        int b = multiplicity(pts, n, pts[i].x, qy);\n        total += pts[i].count * a * b;\n    }\n    return total;\n}`,
          cpp: `#include <unordered_map>\nusing namespace std;\n\nclass DetectSquares {\n    unordered_map<long long, int> count;\n    long long key(int x, int y) { return ((long long)x << 32) ^ (unsigned)y; }\npublic:\n    void add(vector<int> p) { count[key(p[0], p[1])]++; }\n    int countSquares(vector<int> q) {\n        int total = 0;\n        for (auto& [k, c] : count) {\n            int x = k >> 32, y = (int)(k & 0xffffffff);\n            int dx = x - q[0], dy = y - q[1];\n            if (dx == 0 || abs(dx) != abs(dy)) continue;\n            total += c * count[key(q[0], y)] * count[key(x, q[1])];\n        }\n        return total;\n    }\n};`,
        },
        steps(ops) {
          const points = new Map();
          const out = [];
          out.push({
            title: "Store point multiplicities",
            tracks: [chips("operations", ops, "idle"), chips("points", [], "idle")],
            counters: [count("distinct points", 0), count("answer", 0)],
            happened: "A point can be added more than once, so the map stores counts.",
            why: "Duplicate points multiply the number of squares that use them.",
            legend: LEG,
            codeLine: 2,
          });
          let i = 0;
          while (i < ops.length) {
            const op = String(ops[i]).toLowerCase();
            if (op === "add" && i + 2 < ops.length) {
              const x = parseInt(ops[i + 1], 10), y = parseInt(ops[i + 2], 10);
              const key = x + "," + y;
              points.set(key, (points.get(key) || 0) + 1);
              out.push({
                title: `Add point (${x},${y})`,
                tracks: [chips("operations", ops, (k) => (k >= i && k <= i + 2 ? "read" : k < i ? "done" : "idle")), chips("points", [...points.entries()].map(([k, c]) => k + " x" + c), (k) => ([...points.keys()][k] === key ? "result" : "idle"))],
                counters: [count("distinct points", points.size), count("total adds", [...points.values()].reduce((s, x) => s + x, 0))],
                happened: `The multiplicity of (${x},${y}) is now ${points.get(key)}.`,
                why: "Each add increases the number of ways to choose that corner.",
                legend: LEG,
                codeLine: 4,
              });
              i += 3;
            } else if (op === "count" && i + 2 < ops.length) {
              const qx = parseInt(ops[i + 1], 10), qy = parseInt(ops[i + 2], 10);
              let total = 0;
              const matches = [];
              for (const [key, c] of points) {
                const [x, y] = key.split(",").map(Number);
                const dx = x - qx, dy = y - qy;
                if (dx === 0 || Math.abs(dx) !== Math.abs(dy)) continue;
                const a = points.get(qx + "," + y) || 0;
                const b = points.get(x + "," + qy) || 0;
                if (a && b) {
                  total += c * a * b;
                  matches.push(key);
                }
              }
              out.push({
                title: `count(${qx},${qy}) = ${total}`,
                tracks: [chips("operations", ops, (k) => (k >= i && k <= i + 2 ? "read" : k < i ? "done" : "idle")), chips("opposite corners used", matches, "result"), chips("answer", [total], "result")],
                counters: [count("squares", total), count("candidate corners", matches.length)],
                happened: `The point (${qx},${qy}) is a corner of ${total} square(s).`,
                why: "For each diagonal opposite corner, the other two corners are fixed and tested in O(1).",
                legend: LEG,
                codeLine: 8,
              });
              i += 3;
            } else {
              i++;
            }
          }
          out.push({
            title: "Operations complete",
            tracks: [chips("points", [...points.entries()].map(([k, c]) => k + " x" + c), "done")],
            counters: [count("distinct points", points.size)],
            happened: "Every add updated the map and every count scanned the diagonals.",
            why: "The map makes corner existence checks constant time.",
            legend: LEG,
            codeLine: 12,
          });
          return out;
        },
      },
    ],
  });
})();
