/* ============================================================
   DSA Visuals — Greedy III
   Fractional knapsack, scheduling, partition labels, queue
   reconstruction, straight hands, triplets, trucks and Huffman.
   ============================================================ */
(function () {
  "use strict";
  const { count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => `[${a.join(", ")}]`;
  const partsOf = (text) => String(text || "").split("|").map((p) => p.trim());
  const intsOf = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number).filter(Number.isFinite);
  const pairsOf = (text) =>
    String(text || "").split(/\s+/).filter(Boolean).map((p) => p.split(",").map((x) => parseInt(x, 10))).filter((p) => p.length === 2 && p.every(Number.isFinite));
  const fmt = (x) => (Math.abs(x - Math.round(x)) < 1e-9 ? String(Math.round(x)) : x.toFixed(2));

  /* ---------------------------------------------------------- */
  V.register({
    id: "fractional-knapsack",
    title: "Fractional Knapsack",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Maximise value when items can be split and the knapsack has a weight limit.",
    input: { label: "weights | values | capacity", default: "10,20,30 | 60,100,120 | 50", parse: "string" },
    approaches: [
      {
        name: "Take the Best Value per Unit",
        complexity: "O(n log n) time",
        idea: [
          "Compute value ÷ weight for every item and sort by that ratio descending.",
          "Take whole items while they fit. At the first item that does not fit, take just enough of it to fill the remaining capacity and stop.",
        ],
        problem: [
          "Sorting by total value can fill the bag with a heavy item and miss several lighter items with a better combined value.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\ntypedef struct { int w, v; double r; } Item;\nint cmp(const void *a, const void *b) {\n    double x = ((Item*)a)->r, y = ((Item*)b)->r;\n    return (x < y) - (x > y);\n}\n\nint main(void) {\n    Item it[] = {{10,60,6.0},{20,100,5.0},{30,120,4.0}};\n    int n = 3, cap = 50;\n    qsort(it, n, sizeof(Item), cmp);\n\n    double total = 0;\n    for (int i = 0; i < n && cap > 0; i++) {\n        if (it[i].w <= cap) { total += it[i].v; cap -= it[i].w; }\n        else { total += it[i].r * cap; cap = 0; }\n    }\n    printf(\"%.2f\\\\n\", total); /* 240.00 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <algorithm>\nusing namespace std;\n\ndouble fractionalKnapsack(int cap, vector<int>& w, vector<int>& v) {\n    int n = w.size();\n    vector<int> id(n);\n    for (int i = 0; i < n; i++) id[i] = i;\n    sort(id.begin(), id.end(), [&](int a, int b) { return (double)v[a]/w[a] > (double)v[b]/w[b]; });\n\n    double total = 0;\n    for (int i : id) {\n        if (cap <= 0) break;\n        int take = min(cap, w[i]);\n        total += (double)v[i] * take / w[i];\n        cap -= take;\n    }\n    return total;\n}\n\nint main() {\n    vector<int> w{10,20,30}, v{60,100,120};\n    cout << fractionalKnapsack(50, w, v) << '\\\\n'; // 240\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const weights = intsOf(parts[0]).filter((w) => w > 0);
          const values = intsOf(parts[1]);
          const cap0 = Math.max(0, parseInt(parts[2], 10) || 0);
          const n = Math.min(10, Math.min(weights.length, values.length));
          if (!n || !cap0) return [{
            title: "Give weights, values and a capacity",
            tracks: [chips("items", ["—"], "idle")],
            counters: [count("value", 0)],
            legend: LEG,
            happened: "The knapsack inputs are incomplete.",
            why: "Each item needs a positive weight, and the bag needs capacity.",
          }];
          const items = Array.from({ length: n }, (_, i) => ({ w: weights[i], v: values[i], r: values[i] / weights[i], id: i }));
          items.sort((a, b) => b.r - a.r);
          const labels = items.map((x) => `w${x.w}/v${x.v}`);
          const steps = [];
          let cap = cap0;
          let total = 0;
          let taken = 0;
          const status = (i) => (i < taken ? "done" : i === taken ? "read" : "idle");
          steps.push({
            title: `${n} items sorted by value per unit`,
            tracks: [
              chips("items", labels, (i) => (i === 0 ? "read" : "idle")),
              chips("ratio", items.map((x) => `${fmt(x.r)}`), "compare"),
              chips("capacity", [`${cap0}`], "dim"),
            ],
            counters: [count("value", 0), count("capacity", cap0)],
            legend: LEG,
            happened: `The best ratio is ${fmt(items[0].r)}; the worst is ${fmt(items[n - 1].r)}.`,
            why: "A split item is worth its ratio per unit, so the highest ratio always wins first.",
            codeLine: 6,
          });
          for (let i = 0; i < n && cap > 0; i++) {
            const it = items[i];
            const take = Math.min(cap, it.w);
            const gain = it.r * take;
            total += gain;
            cap -= take;
            taken++;
            steps.push({
              title: take === it.w ? `Take all ${it.w} units for ${fmt(gain)}` : `Take ${take}/${it.w} units for ${fmt(gain)}`,
              tracks: [
                chips("items", labels, (j) => (j < taken ? "done" : j === taken ? "read" : "dim")),
                chips("taken", items.slice(0, taken).map((x, j) => `${x.w}×${fmt(x.r)}`), "good"),
                chips("capacity", [`${cap} left`], cap > 0 ? "active" : "result"),
              ],
              counters: [count("value", +total.toFixed(2)), count("capacity", cap, cap0)],
              legend: LEG,
              happened: take === it.w ? `The whole item fits; ${cap} capacity remains.` : "The bag is full after taking a fraction.",
              why: "Taking a fraction is only needed for the item that crosses the capacity limit.",
              codeLine: take === it.w ? 9 : 10,
            });
          }
          steps.push({
            title: `Answer: maximum value ${fmt(total)}`,
            tracks: [chips("chosen", items.slice(0, taken).map((x) => `w${x.w}/v${x.v}`), "result"), chips("remaining capacity", [`${cap}`], cap ? "active" : "done")],
            counters: [count("value", +total.toFixed(2)), count("items taken", taken, n)],
            legend: LEG,
            happened: `The greedy pick reaches value ${fmt(total)}.`,
            why: "Without the ability to split, this greedy choice would not always be optimal; with fractions, it is.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "job-sequencing",
    title: "Job Sequencing",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Schedule one job per deadline slot to maximise total profit.",
    input: { label: "profits | deadlines", default: "100,19,27,25,15 | 2,1,2,1,3", parse: "string" },
    approaches: [
      {
        name: "Highest Profit Into a Free Slot",
        complexity: "O(n²) time (or O(n α) with DSU)",
        idea: [
          "Sort jobs by profit descending. Every job wants the latest slot at or before its deadline, because earlier slots will remain available for jobs with tighter deadlines.",
          "Scan slots backwards from the deadline. Put the job in the first free slot. If none is free, skip it; the total of accepted profits is optimal.",
        ],
        problem: [
          "Scheduling in deadline order can fill an early slot with a low-profit job and block a much more valuable one.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\ntypedef struct { int p, d; } Job;\nint cmp(const void *a, const void *b) {\n    return ((Job*)b)->p - ((Job*)a)->p;\n}\n\nint main(void) {\n    Job j[] = {{100,2},{19,1},{27,2},{25,1},{15,3}};\n    int n = 5, slots[4] = {0}, total = 0;\n    qsort(j, n, sizeof(Job), cmp);\n\n    for (int i = 0; i < n; i++)\n        for (int t = j[i].d; t >= 1; t--)\n            if (!slots[t]) { slots[t] = 1; total += j[i].p; break; }\n\n    printf(\"%d\\\\n\", total); /* 142 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <algorithm>\nusing namespace std;\n\nint jobScheduling(vector<pair<int,int>>& jobs) { // profit, deadline\n    sort(jobs.begin(), jobs.end(), [](auto& a, auto& b) { return a.first > b.first; });\n    int maxD = 0;\n    for (auto& j : jobs) maxD = max(maxD, j.second);\n\n    vector<bool> slot(maxD + 1, false);\n    int total = 0;\n    for (auto& [p, d] : jobs)\n        for (int t = d; t >= 1; t--)\n            if (!slot[t]) { slot[t] = true; total += p; break; }\n    return total;\n}\n\nint main() {\n    vector<pair<int,int>> jobs{{100,2},{19,1},{27,2},{25,1},{15,3}};\n    cout << jobScheduling(jobs) << '\\\\n'; // 142\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const profits = intsOf(parts[0]);
          const deadlines = intsOf(parts[1]);
          const n = Math.min(10, Math.min(profits.length, deadlines.length));
          if (!n) return [{
            title: "Give profits and deadlines",
            tracks: [chips("jobs", ["—"], "idle")],
            counters: [count("profit", 0)],
            legend: LEG,
            happened: "There are no jobs.",
            why: "Each job needs both a profit and a deadline.",
          }];
          const jobs = Array.from({ length: n }, (_, i) => ({ p: profits[i], d: Math.max(1, deadlines[i]), id: i })).sort((a, b) => b.p - a.p);
          const maxD = Math.max(...jobs.map((j) => j.d));
          const slot = Array(maxD + 1).fill(-1);
          const steps = [];
          let total = 0;
          const jobLabels = jobs.map((j) => `P${j.p}/D${j.d}`);
          steps.push({
            title: `${n} jobs sorted by profit`,
            tracks: [
              chips("jobs", jobLabels, (i) => (i === 0 ? "read" : "idle")),
              chips("slots", Array.from({ length: maxD }, (_, i) => `t${i + 1}`), "dim"),
            ],
            counters: [count("profit", 0), count("slots", maxD)],
            legend: LEG,
            happened: `The most valuable job is worth ${jobs[0].p}.`,
            why: "Profits dominate: a high-profit job should never be blocked by a lower one.",
            codeLine: 6,
          });
          jobs.forEach((job, idx) => {
            let placed = -1;
            for (let t = job.d; t >= 1; t--) {
              if (slot[t] === -1) { slot[t] = idx; placed = t; break; }
            }
            if (placed >= 0) total += job.p;
            steps.push({
              title: placed >= 0 ? `Schedule P${job.p} at slot ${placed}` : `Skip P${job.p}: all slots ≤ ${job.d} are full`,
              tracks: [
                chips("jobs", jobLabels, (i) => (i === idx ? (placed >= 0 ? "result" : "bad") : i < idx ? "done" : "idle")),
                chips("slots", Array.from({ length: maxD }, (_, i) => (slot[i + 1] < 0 ? `t${i + 1}: free` : `t${i + 1}: P${jobs[slot[i + 1]].p}`)), (i) => (slot[i + 1] === idx ? "result" : slot[i + 1] >= 0 ? "good" : "dim")),
              ],
              counters: [count("profit", total), count("scheduled", slot.filter((x) => x >= 0).length, maxD)],
              legend: LEG,
              happened: placed >= 0 ? `The latest free slot at or before deadline ${job.d} was chosen.` : "Every legal slot is occupied by a more profitable job.",
              why: "Using the latest slot leaves earlier slots for jobs with earlier deadlines.",
              codeLine: placed >= 0 ? 12 : 10,
            });
          });
          steps.push({
            title: `Answer: maximum profit ${total}`,
            tracks: [chips("schedule", Array.from({ length: maxD }, (_, i) => `t${i + 1}: ${slot[i + 1] < 0 ? "free" : `P${jobs[slot[i + 1]].p}`}`), "result")],
            counters: [count("profit", total), count("jobs taken", slot.filter((x) => x >= 0).length, n)],
            legend: LEG,
            happened: `The accepted jobs total ${total} profit.`,
            why: "Exchanging any accepted job for a skipped one cannot increase profit, because jobs were considered in decreasing profit order.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "partition-labels",
    title: "Partition Labels",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Cut a string into the most parts so no letter appears in two parts.",
    input: { label: "A string of letters", default: "ababcbacadefegdehijhklij", parse: "string" },
    approaches: [
      {
        name: "Extend Each Part to the Last Occurrence",
        complexity: "O(n) time",
        idea: [
          "Record the last index of every letter. Start a part at the current index and initially set its end to that letter's last occurrence.",
          "Scan inside the part and push the end right whenever a letter occurs later. When the scan reaches the end, no letter inside appears outside, so cut there and start the next part.",
        ],
        problem: [
          "Cutting at the first repeated letter can split a letter across parts; the part must extend to the furthest last occurrence seen.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint main(void) {\n    char s[] = \"ababcbacadefegdehijhklij\";\n    int n = strlen(s), last[26] = {0};\n    for (int i = 0; i < n; i++) last[s[i] - \'a\'] = i;\n\n    int start = 0, end = 0;\n    for (int i = 0; i < n; i++) {\n        if (last[s[i] - \'a\'] > end) end = last[s[i] - \'a\'];\n        if (i == end) {\n            printf(\"%d \", end - start + 1);\n            start = end = i + 1;\n        }\n    }\n    printf(\"\\\\n\"); /* 9 7 8 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <string>\nusing namespace std;\n\nvector<int> partitionLabels(string s) {\n    vector<int> last(26, 0);\n    for (int i = 0; i < (int)s.size(); i++) last[s[i] - 'a'] = i;\n\n    vector<int> out;\n    int start = 0, end = 0;\n    for (int i = 0; i < (int)s.size(); i++) {\n        end = max(end, last[s[i] - 'a']);\n        if (i == end) {\n            out.push_back(end - start + 1);\n            start = end + 1;\n        }\n    }\n    return out;\n}\n\nint main() {\n    for (int x : partitionLabels(\"ababcbacadefegdehijhklij\")) cout << x << ' '; // 9 7 8\n    cout << '\\\\n';\n}`,
        },
        steps(text) {
          const s = String(text || "").replace(/[^A-Za-z]/g, "").slice(0, 60);
          if (!s.length) return [{
            title: "Give a string of letters",
            tracks: [chips("letters", ["—"], "idle")],
            counters: [count("parts", 0)],
            legend: LEG,
            happened: "The string is empty.",
            why: "Partitioning needs letters to place.",
          }];
          const chars = s.split("");
          const last = {};
          chars.forEach((ch, i) => { last[ch] = i; });
          const steps = [];
          const bounds = [];
          let start = 0;
          let end = 0;
          steps.push({
            title: `Record the last position of each letter`,
            tracks: [
              chips("string", chars, "idle"),
              chips("last", Object.entries(last).sort(([a], [b]) => a.localeCompare(b)).map(([ch, i]) => `${ch}:${i}`), "dim"),
            ],
            counters: [count("parts", 0), count("letters", Object.keys(last).length)],
            legend: LEG,
            happened: `${Object.keys(last).length} distinct letters appear in the string.`,
            why: "A part cannot end before the last occurrence of any letter inside it.",
            codeLine: 4,
          });
          for (let i = 0; i < chars.length; i++) {
            if (last[chars[i]] > end) end = last[chars[i]];
            if (i === end) {
              bounds.push([start, end]);
              steps.push({
                title: `Cut a part from ${start} to ${end} (length ${end - start + 1})`,
                tracks: [
                  chips("string", chars, (j) => (j < start ? "done" : j <= end ? (j === i ? "result" : "active") : "idle")),
                  chips("parts", bounds.map(([a, b]) => `${chars.slice(a, b + 1).join("")}`), "good"),
                ],
                counters: [count("parts", bounds.length), count("chars covered", end + 1, chars.length)],
                legend: LEG,
                happened: `The scan reached ${end}, the furthest last occurrence inside the current part.`,
                why: "No letter in this part appears later, so the cut is safe and maximal.",
                codeLine: 9,
              });
              start = end = i + 1;
            }
          }
          steps.push({
            title: `Answer: ${bounds.length} parts of sizes ${bounds.map(([a, b]) => b - a + 1).join(", ")}`,
            tracks: [chips("parts", bounds.map(([a, b]) => chars.slice(a, b + 1).join("")), "result")],
            counters: [count("parts", bounds.length), count("largest", Math.max(...bounds.map(([a, b]) => b - a + 1)))],
            legend: LEG,
            happened: bounds.map(([a, b]) => `${chars.slice(a, b + 1).join("")}(${b - a + 1})`).join(", "),
            why: "Each cut is forced by a letter's last occurrence, so the greedy partition uses the maximum possible number of parts.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "queue-reconstruction-by-height",
    title: "Queue Reconstruction by Height",
    category: "Greedy",
    difficulty: "Advanced",
    description: "Rebuild a queue from people's heights and counts of taller people in front.",
    input: { label: "People as height,count pairs", default: "7,0 4,4 7,1 5,0 6,1 5,2", parse: "string" },
    approaches: [
      {
        name: "Insert Tallest First",
        complexity: "O(n²) time",
        idea: [
          "Sort people by height descending, and for equal heights by count ascending.",
          "Insert each person at index equal to their count in the current queue. Taller people are already placed, so exactly count of them will stand in front of the new person.",
        ],
        problem: [
          "Inserting shorter people first makes later tall insertions change counts that were already fixed.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\ntypedef struct { int h, k; } Person;\nint cmp(const void *a, const void *b) {\n    Person *x = (Person*)a, *y = (Person*)b;\n    if (x->h != y->h) return y->h - x->h;\n    return x->k - y->k;\n}\n\nint main(void) {\n    Person p[] = {{7,0},{4,4},{7,1},{5,0},{6,1},{5,2}};\n    int n = 6, q[6];\n    qsort(p, n, sizeof(Person), cmp);\n\n    for (int i = 0; i < n; i++) {\n        for (int j = i; j > p[i].k; j--) q[j] = q[j-1];\n        q[p[i].k] = i;\n    }\n\n    for (int i = 0; i < n; i++) printf(\"%d,%d \", p[q[i]].h, p[q[i]].k); /* 5,0 7,0 5,2 6,1 4,4 7,1 */\n    printf(\"\\\\n\");\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <algorithm>\nusing namespace std;\n\nvector<vector<int>> reconstructQueue(vector<vector<int>>& people) {\n    sort(people.begin(), people.end(), [](auto& a, auto& b) {\n        return a[0] != b[0] ? a[0] > b[0] : a[1] < b[1];\n    });\n\n    vector<vector<int>> q;\n    for (auto& p : people) q.insert(q.begin() + p[1], p);\n    return q;\n}\n\nint main() {\n    vector<vector<int>> p{{7,0},{4,4},{7,1},{5,0},{6,1},{5,2}};\n    for (auto& x : reconstructQueue(p)) cout << x[0] << ',' << x[1] << ' '; // 5,0 7,0 5,2 6,1 4,4 7,1\n    cout << '\\\\n';\n}`,
        },
        steps(text) {
          const people = pairsOf(text).slice(0, 12);
          if (!people.length) return [{
            title: "Give height,count pairs",
            tracks: [chips("people", ["—"], "idle")],
            counters: [count("placed", 0)],
            legend: LEG,
            happened: "There are no people.",
            why: "Each person needs a height and a count.",
          }];
          const sorted = people.slice().sort((a, b) => (a[0] !== b[0] ? b[0] - a[0] : a[1] - b[1]));
          const steps = [];
          const queue = [];
          const tag = (p) => `${p[0]},${p[1]}`;
          steps.push({
            title: `${people.length} people sorted by height descending`,
            tracks: [
              chips("sorted", sorted.map(tag), (i) => (i === 0 ? "read" : "idle")),
              chips("queue", ["empty"], "dim"),
            ],
            counters: [count("placed", 0, people.length)],
            legend: LEG,
            happened: `The tall people ${sorted.slice(0, 2).map(tag).join(", ")} are processed first.`,
            why: "When a person is inserted, everyone already in the queue is at least as tall.",
            codeLine: 7,
          });
          sorted.forEach((p, i) => {
            const at = Math.min(p[1], queue.length);
            queue.splice(at, 0, p);
            steps.push({
              title: `Insert ${tag(p)} at index ${at}`,
              tracks: [
                chips("sorted", sorted.map(tag), (j) => (j < i ? "done" : j === i ? "read" : "idle")),
                chips("queue", queue.map(tag), (j) => (j === at ? "result" : j < at ? "good" : "active")),
              ],
              counters: [count("placed", queue.length, people.length), count("front", Math.min(at, queue.length - 1))],
              legend: LEG,
              happened: `Exactly ${at} already-placed people stand in front of ${tag(p)}.`,
              why: "All placed people are at least as tall, so the insertion index is exactly this person's required count.",
              codeLine: 10,
            });
          });
          steps.push({
            title: "Answer: the reconstructed queue",
            tracks: [chips("queue", queue.map(tag), "result")],
            counters: [count("people", queue.length), count("check", "valid")],
            legend: LEG,
            happened: queue.map(tag).join(", "),
            why: "Each insertion fixes that person's count without disturbing taller people already placed.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "hand-of-straights",
    title: "Hand of Straights",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Split a hand of cards into consecutive groups of equal size.",
    input: { label: "Cards | group size", default: "1,2,3,6,2,3,4,7,8 | 3", parse: "string" },
    approaches: [
      {
        name: "Grow Groups From the Smallest Card",
        complexity: "O(n log n) time",
        idea: [
          "Count every card. The smallest remaining card must start a group, because no smaller card can precede it.",
          "Consume that card and the next groupSize − 1 consecutive values. If any required card is missing, the split is impossible.",
        ],
        problem: [
          "Forming groups from arbitrary cards can leave the smallest card without consecutive partners.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\nint cmp(const void *a, const void *b) { return *(int*)a - *(int*)b; }\n\nint main(void) {\n    int a[] = {1,2,3,6,2,3,4,7,8};\n    int n = 9, group = 3;\n    if (n % group) { printf(\"false\\\\n\"); return 0; }\n    qsort(a, n, sizeof(int), cmp);\n\n    int used[9] = {0};\n    for (int i = 0; i < n; i++) {\n        if (used[i]) continue;\n        int need = a[i], picked = 0;\n        for (int j = i; j < n && picked < group; j++)\n            if (!used[j] && a[j] == need) { used[j] = 1; need++; picked++; }\n        if (picked < group) { printf(\"false\\\\n\"); return 0; }\n    }\n    printf(\"true\\\\n\");\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <map>\nusing namespace std;\n\nbool isNStraightHand(vector<int>& hand, int groupSize) {\n    if (hand.size() % groupSize) return false;\n    map<int,int> cnt;\n    for (int x : hand) cnt[x]++;\n\n    while (!cnt.empty()) {\n        int start = cnt.begin()->first;\n        for (int x = start; x < start + groupSize; x++) {\n            if (!cnt.count(x)) return false;\n            if (--cnt[x] == 0) cnt.erase(x);\n        }\n    }\n    return true;\n}\n\nint main() {\n    vector<int> h{1,2,3,6,2,3,4,7,8};\n    cout << isNStraightHand(h, 3) << '\\\\n'; // 1\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const cards = intsOf(parts[0]).slice(0, 30);
          const group = Math.max(1, parseInt(parts[1], 10) || 1);
          if (!cards.length) return [{
            title: "Give a hand of cards",
            tracks: [chips("cards", ["—"], "idle")],
            counters: [count("groups", 0)],
            legend: LEG,
            happened: "The hand is empty.",
            why: "There are no cards to group.",
          }];
          const freq = new Map();
          cards.forEach((c) => freq.set(c, (freq.get(c) || 0) + 1));
          const values = [...freq.keys()].sort((a, b) => a - b);
          const steps = [];
          let groups = 0;
          let impossible = cards.length % group !== 0;
          const stateFor = () => (c) => (freq.get(c) > 0 ? "active" : "done");
          steps.push({
            title: cards.length % group === 0 ? `${cards.length} cards, groups of ${group}` : `${cards.length} cards cannot split into groups of ${group}`,
            tracks: [
              chips("counts", values.map((v) => `${v}×${freq.get(v)}`), "idle"),
              chips("cards", cards.slice().sort((a, b) => a - b), "dim"),
            ],
            counters: [count("groups", 0, Math.floor(cards.length / group)), count("distinct", values.length)],
            legend: LEG,
            happened: cards.length % group === 0 ? "The card count divides evenly." : "The total is not divisible by the group size.",
            why: "Every group has exactly groupSize cards, so an uneven total is immediately impossible.",
            codeLine: 4,
          });
          while (!impossible && values.some((v) => freq.get(v) > 0)) {
            const start = values.find((v) => freq.get(v) > 0);
            const groupVals = [];
            for (let x = start; x < start + group; x++) {
              if (!freq.get(x)) { impossible = true; break; }
              freq.set(x, freq.get(x) - 1);
              groupVals.push(x);
            }
            if (impossible) {
              steps.push({
                title: `Cannot build a group starting at ${start}`,
                tracks: [
                  chips("counts", values.map((v) => `${v}×${freq.get(v)}`), "dim"),
                  chips("needed", Array.from({ length: group }, (_, i) => start + i), (i) => (groupVals.includes(start + i) ? "good" : "bad")),
                ],
                counters: [count("groups", groups), count("answer", "false")],
                legend: LEG,
                happened: `Card ${start + groupVals.length} is missing while building from ${start}.`,
                why: "The smallest remaining card must belong to a group, and that group needs every consecutive value.",
                codeLine: 13,
              });
              break;
            }
            groups++;
            steps.push({
              title: `Group ${groups}: ${groupVals.join(", ")}`,
              tracks: [
                chips("counts", values.map((v) => `${v}×${freq.get(v)}`), (i) => (groupVals.includes(values[i]) ? (freq.get(values[i]) > 0 ? "active" : "done") : "idle")),
                chips("groups", Array.from({ length: groups }, (_, i) => `group ${i + 1}`), "good"),
              ],
              counters: [count("groups", groups, cards.length / group), count("answer", "pending")],
              legend: LEG,
              happened: `${groupVals.join(", ")} form a consecutive group.`,
              why: "Consuming the smallest card first is forced, so the greedy choice cannot block a different valid grouping.",
              codeLine: 10,
            });
          }
          if (!impossible) {
            steps.push({
              title: `Answer: the hand splits into ${groups} group${groups === 1 ? "" : "s"}`,
              tracks: [chips("result", Array.from({ length: groups }, (_, i) => `group ${i + 1}`), "result")],
              counters: [count("groups", groups), count("answer", "true")],
              legend: LEG,
              happened: "Every card was consumed by a valid consecutive group.",
              why: "The greedy groups partition the whole hand, so the split is valid.",
              codeLine: 16,
            });
          }
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "merge-triplets",
    title: "Merge Triplets",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Decide whether some triplets can be merged into a target triplet.",
    input: { label: "Triplets as a,b,c | target a,b,c", default: "2,5,3 1,8,4 1,7,5 | 2,7,5", parse: "string" },
    approaches: [
      {
        name: "Only Use Triplets Inside the Target",
        complexity: "O(n) time",
        idea: [
          "A triplet with any coordinate larger than the target can never be used, because merging takes coordinate-wise maxima and values never decrease.",
          "For every other triplet, record which target coordinates it matches exactly. If all three coordinates are covered by some triplet, merging those triplets reaches the target.",
        ],
        problem: [
          "Taking the maximum of every coordinate independently ignores that a single triplet must supply each coordinate without exceeding the target elsewhere.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint main(void) {\n    int t[][3] = {{2,5,3},{1,8,4},{1,7,5}};\n    int n = 3, target[3] = {2,7,5}, got[3] = {0,0,0};\n\n    for (int i = 0; i < n; i++) {\n        if (t[i][0] > target[0] || t[i][1] > target[1] || t[i][2] > target[2]) continue;\n        for (int c = 0; c < 3; c++)\n            if (t[i][c] == target[c]) got[c] = 1;\n    }\n    printf(\"%d\\\\n\", got[0] && got[1] && got[2]); /* 1 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nbool mergeTriplets(vector<vector<int>>& triplets, vector<int>& target) {\n    vector<bool> got(3, false);\n    for (auto& t : triplets) {\n        if (t[0] > target[0] || t[1] > target[1] || t[2] > target[2]) continue;\n        for (int c = 0; c < 3; c++) if (t[c] == target[c]) got[c] = true;\n    }\n    return got[0] && got[1] && got[2];\n}\n\nint main() {\n    vector<vector<int>> t{{2,5,3},{1,8,4},{1,7,5}};\n    vector<int> target{2,7,5};\n    cout << mergeTriplets(t, target) << '\\\\n'; // 1\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const triplets = String(parts[0] || "").split(/\s+/).filter(Boolean).map((p) => p.split(",").map(Number)).filter((p) => p.length === 3 && p.every(Number.isFinite)).slice(0, 12);
          const target = String(parts[1] || "").split(",").map(Number);
          if (!triplets.length || target.length !== 3) return [{
            title: "Give triplets and a target",
            tracks: [chips("triplets", ["—"], "idle")],
            counters: [count("covered", 0, 3)],
            legend: LEG,
            happened: "The input is incomplete.",
            why: "Each side needs three coordinates.",
          }];
          const got = [false, false, false];
          const usable = [];
          const steps = [];
          const coverCount = () => got.filter(Boolean).length;
          steps.push({
            title: `Target ${target.join(",")}; ${triplets.length} triplets`,
            tracks: [
              chips("triplets", triplets.map((t) => t.join(",")), "idle"),
              chips("target", [target.join(",")], "compare"),
              chips("covered", ["x", "y", "z"], "dim"),
            ],
            counters: [count("covered", 0, 3), count("usable", 0, triplets.length)],
            legend: LEG,
            happened: "Only triplets whose every coordinate is at most the target can be merged.",
            why: "Merging takes coordinate-wise maxima, so an oversized coordinate can never shrink back.",
            codeLine: 5,
          });
          triplets.forEach((t, i) => {
            const ok = t.every((v, c) => v <= target[c]);
            if (ok) {
              usable.push(i);
              t.forEach((v, c) => { if (v === target[c]) got[c] = true; });
            }
            steps.push({
              title: ok ? `Triplet ${i} is usable${t.some((v, c) => v === target[c]) ? " and covers a coordinate" : ""}` : `Triplet ${i} exceeds the target`,
              tracks: [
                chips("triplets", triplets.map((x) => x.join(",")), (j) => (j === i ? (ok ? "read" : "bad") : usable.includes(j) ? "done" : "idle")),
                chips("covered", got.map((x, c) => (x ? `${"xyz"[c]}=${target[c]}` : `${"xyz"[c]}: ?`)), (c) => (got[c] ? "good" : "dim")),
              ],
              counters: [count("covered", coverCount(), 3), count("usable", usable.length, triplets.length)],
              legend: LEG,
              happened: ok ? `Every coordinate of ${t.join(",")} is at most ${target.join(",")}.` : "At least one coordinate is too large to ever be part of the merge.",
              why: "A usable triplet can be included without pushing any coordinate past the target.",
              codeLine: ok ? 8 : 6,
            });
          });
          const possible = got.every(Boolean);
          steps.push({
            title: possible ? "Answer: the target can be formed" : "Answer: the target cannot be formed",
            tracks: [chips("covered", got.map((x, c) => (x ? `${"xyz"[c]}=${target[c]}` : `${"xyz"[c]} missing`)), possible ? "result" : "bad"), chips("usable", usable.map((i) => triplets[i].join(",")), "good")],
            counters: [count("covered", coverCount(), 3), count("answer", possible ? "true" : "false")],
            legend: LEG,
            happened: possible ? "All three target coordinates are supplied by usable triplets." : "At least one target coordinate was never covered.",
            why: "The coordinate-wise maximum of the selected usable triplets equals the target exactly when every coordinate is covered without exceeding it.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-units-on-a-truck",
    title: "Maximum Units on a Truck",
    category: "Greedy",
    difficulty: "Easy",
    description: "Load the truck with the boxes that carry the most units per box.",
    input: { label: "Box types as count,units | truck size", default: "1,3 2,2 3,1 | 4", parse: "string" },
    approaches: [
      {
        name: "Take the Densest Boxes First",
        complexity: "O(n log n) time",
        idea: [
          "Each box type offers a fixed number of units per box. Sort types by units per box descending.",
          "Take as many boxes as possible from the densest type, then move on. Stop when the truck is full or the types run out.",
        ],
        problem: [
          "Loading types in input order can fill the truck with low-value boxes before the dense ones.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\ntypedef struct { int count, units; } Box;\nint cmp(const void *a, const void *b) { return ((Box*)b)->units - ((Box*)a)->units; }\n\nint main(void) {\n    Box b[] = {{1,3},{2,2},{3,1}};\n    int n = 3, truck = 4, total = 0;\n    qsort(b, n, sizeof(Box), cmp);\n\n    for (int i = 0; i < n && truck > 0; i++) {\n        int take = b[i].count < truck ? b[i].count : truck;\n        total += take * b[i].units;\n        truck -= take;\n    }\n    printf(\"%d\\\\n\", total); /* 8 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <algorithm>\nusing namespace std;\n\nint maximumUnits(vector<vector<int>>& boxTypes, int truckSize) {\n    sort(boxTypes.begin(), boxTypes.end(), [](auto& a, auto& b) { return a[1] > b[1]; });\n    int total = 0;\n    for (auto& b : boxTypes) {\n        int take = min(truckSize, b[0]);\n        total += take * b[1];\n        truckSize -= take;\n        if (!truckSize) break;\n    }\n    return total;\n}\n\nint main() {\n    vector<vector<int>> b{{1,3},{2,2},{3,1}};\n    cout << maximumUnits(b, 4) << '\\\\n'; // 8\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const boxes = pairsOf(parts[0]).map(([c, u]) => ({ c, u })).filter((b) => b.c > 0 && b.u > 0).slice(0, 10);
          let truck = Math.max(0, parseInt(parts[1], 10) || 0);
          if (!boxes.length || !truck) return [{
            title: "Give box types and truck size",
            tracks: [chips("boxes", ["—"], "idle")],
            counters: [count("units", 0)],
            legend: LEG,
            happened: "There are no boxes or no space.",
            why: "The truck needs capacity and at least one box type.",
          }];
          const sorted = boxes.slice().sort((a, b) => b.u - a.u);
          const steps = [];
          let total = 0;
          let loaded = 0;
          const labels = sorted.map((b) => `${b.c} boxes×${b.u}`);
          steps.push({
            title: `${sorted.length} box types sorted by units per box`,
            tracks: [chips("types", labels, "idle"), chips("truck", [`${truck} spaces`], "dim")],
            counters: [count("units", 0), count("space", truck)],
            legend: LEG,
            happened: `The densest type carries ${sorted[0].u} units per box.`,
            why: "Each unit of space should be spent on the highest unit count.",
            codeLine: 5,
          });
          sorted.forEach((b, i) => {
            const take = Math.min(truck, b.c);
            truck -= take;
            total += take * b.u;
            loaded += take;
            steps.push({
              title: `Load ${take} box${take === 1 ? "" : "es"} carrying ${b.u} units each`,
              tracks: [
                chips("types", labels, (j) => (j < i ? "done" : j === i ? (take ? "read" : "dim") : "idle")),
                chips("loaded", sorted.slice(0, i + 1).filter((x) => x.c > 0).map((x) => `${x.u}/box`), "good"),
                chips("space", [`${truck} left`], truck ? "active" : "result"),
              ],
              counters: [count("units", total), count("boxes loaded", loaded), count("space", truck)],
              legend: LEG,
              happened: take ? `${take * b.u} units added; the truck has ${truck} spaces left.` : "The truck is already full.",
              why: "Taking a denser type later never helps, because all boxes of a type are identical.",
              codeLine: 9,
            });
          });
          steps.push({
            title: `Answer: ${total} units loaded`,
            tracks: [chips("loaded boxes", sorted.slice(0, boxes.length).map((b) => `${b.c}×${b.u}`), "result")],
            counters: [count("units", total), count("space left", truck), count("boxes", loaded)],
            legend: LEG,
            happened: `The truck is loaded with ${loaded} boxes for ${total} units.`,
            why: "The exchange argument: replacing any loaded box with a denser one cannot lower the total.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "huffman-encoding",
    title: "Huffman Encoding",
    category: "Greedy",
    difficulty: "Advanced",
    description: "Build a prefix-free code by repeatedly merging the two least frequent symbols.",
    input: { label: "Symbols as char:frequency", default: "a:5,b:9,c:12,d:13,e:16,f:45", parse: "string" },
    approaches: [
      {
        name: "Merge Two Smallest Frequencies",
        complexity: "O(n log n) time",
        idea: [
          "Put every symbol in a min-priority queue keyed by frequency. Remove the two smallest and create a parent whose frequency is their sum.",
          "Push the parent back. After n − 1 merges one tree remains; reading left edges as 0 and right edges as 1 gives each symbol a prefix-free code.",
        ],
        problem: [
          "Assigning equal-length codes ignores frequency; the two rarest symbols should end up deepest so they add the fewest bits.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n\ntypedef struct { int f, l, r; char sym; } Node;\nNode nodes[32];\nint n = 6;\nint used[32];\n\nint takeMin(void) {\n    int best = -1;\n    for (int i = 0; i < n * 2 - 1; i++)\n        if (nodes[i].f && !used[i] && (best < 0 || nodes[i].f < nodes[best].f)) best = i;\n    used[best] = 1;\n    return best;\n}\n\nvoid code(int i, char *buf, int d) {\n    if (nodes[i].sym) { buf[d] = 0; printf(\"%c:%s \", nodes[i].sym, buf); return; }\n    buf[d] = \'0\'; code(nodes[i].l, buf, d + 1);\n    buf[d] = \'1\'; code(nodes[i].r, buf, d + 1);\n}\n\nint main(void) {\n    char s[] = \"abcdef\";\n    int f[] = {5,9,12,13,16,45};\n    for (int i = 0; i < n; i++) { nodes[i].f = f[i]; nodes[i].sym = s[i]; nodes[i].l = nodes[i].r = -1; }\n\n    int next = n;\n    for (int k = 1; k < n; k++) {\n        int a = takeMin(), b = takeMin();\n        nodes[next] = (Node){nodes[a].f + nodes[b].f, a, b, 0};\n        next++;\n    }\n    char buf[32];\n    code(next - 1, buf, 0);\n    printf(\"\\\\n\");\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <queue>\n#include <vector>\nusing namespace std;\n\nstruct Node { int f; char sym; Node *l, *r; };\nstruct Cmp { bool operator()(Node *a, Node *b) { return a->f > b->f; } };\n\nvoid codes(Node *n, string p) {\n    if (!n) return;\n    if (n->sym) { cout << n->sym << ':' << p << ' '; return; }\n    codes(n->l, p + '0');\n    codes(n->r, p + '1');\n}\n\nint main() {\n    priority_queue<Node*, vector<Node*>, Cmp> pq;\n    string sym = \"abcdef\";\n    int f[] = {5,9,12,13,16,45};\n    for (int i = 0; i < 6; i++) pq.push(new Node{f[i], sym[i], nullptr, nullptr});\n\n    while (pq.size() > 1) {\n        Node *a = pq.top(); pq.pop();\n        Node *b = pq.top(); pq.pop();\n        pq.push(new Node{a->f + b->f, 0, a, b});\n    }\n    codes(pq.top(), \"\");\n    cout << '\\\\n';\n}`,
        },
        steps(text) {
          const raw = String(text || "").split(/[\s,]+/).filter(Boolean);
          const leaves = raw.map((s) => {
            const m = s.match(/^(.+):(\d+)$/);
            return m ? { sym: m[1].slice(0, 2), f: Number(m[2]) } : null;
          }).filter(Boolean).slice(0, 10);
          if (leaves.length < 2) return [{
            title: "Give at least two char:frequency pairs",
            tracks: [chips("symbols", ["—"], "idle")],
            counters: [count("symbols", leaves.length)],
            legend: LEG,
            happened: "Huffman coding needs two or more symbols.",
            why: "A merge combines two nodes at a time.",
          }];
          const nodes = leaves.map((l, i) => ({ id: i, f: l.f, sym: l.sym, l: -1, r: -1, label: `${l.sym}:${l.f}` }));
          const steps = [];
          let nextId = nodes.length;
          const heapOf = () => nodes.filter((x) => !x.taken).sort((a, b) => a.f - b.f);
          const heapLabels = () => heapOf().map((x) => x.label);
          steps.push({
            title: `${leaves.length} symbols in a min-priority queue`,
            tracks: [
              chips("queue", heapLabels(), (i) => (i < 2 ? "read" : "idle")),
              chips("weights", leaves.map((l) => `${l.sym}:${l.f}`), "dim"),
            ],
            counters: [count("nodes", nodes.length), count("merges", 0, nodes.length - 1)],
            legend: LEG,
            happened: `The two lightest symbols are ${heapLabels().slice(0, 2).join(" and ")}.`,
            why: "Merging the two smallest frequencies keeps rare symbols deepest in the final tree.",
            codeLine: 5,
          });
          for (let k = 1; k < leaves.length; k++) {
            const heap = heapOf();
            const a = heap[0], b = heap[1];
            a.taken = true; b.taken = true;
            const parent = { id: nextId++, f: a.f + b.f, sym: "", l: a.id, r: b.id, label: `(${a.f}+${b.f})=${a.f + b.f}` };
            nodes.push(parent);
            steps.push({
              title: `Merge ${a.label} and ${b.label} into weight ${parent.f}`,
              tracks: [
                chips("merged", [`${a.label} + ${b.label} → ${parent.f}`], "result"),
                chips("queue", heapLabels(), (i) => (i === 0 ? "active" : "idle")),
              ],
              counters: [count("nodes", nodes.length), count("merges", k, leaves.length - 1)],
              legend: LEG,
              happened: `The new node has weight ${parent.f} and becomes the parent of both symbols.`,
              why: "A parent's weight is the total number of bits its subtree contributes through this merge.",
              codeLine: 9,
            });
          }
          const root = nodes[nodes.length - 1];
          const codes = [];
          const walk = (id, prefix) => {
            const nd = nodes.find((x) => x.id === id);
            if (!nd) return;
            if (nd.sym) { codes.push(`${nd.sym}:${prefix || "0"}`); return; }
            if (nd.l >= 0) walk(nd.l, prefix + "0");
            if (nd.r >= 0) walk(nd.r, prefix + "1");
          };
          walk(root.id, "");
          steps.push({
            title: "Answer: prefix-free Huffman codes",
            tracks: [chips("codes", codes, "result"), chips("weights", leaves.map((l) => `${l.sym}:${l.f}`), "done")],
            counters: [count("codes", codes.length), count("merges", leaves.length - 1)],
            legend: LEG,
            happened: codes.join(", "),
            why: "No code is a prefix of another because symbols live only at leaves, so decoding is unambiguous.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });
})();
