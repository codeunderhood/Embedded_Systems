/* ============================================================
   DSA Visuals — Graphs II
   Safe states, word and lock searches, grid distance, DSU
   redundancy and account merging.
   ============================================================ */
(function () {
  "use strict";
  const { fill, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => `[${a.join(", ")}]`;
  const partsOf = (text) => String(text || "").split("|").map((p) => p.trim());
  const wordsOf = (text) => String(text || "").split(/[\s,]+/).filter(Boolean);
  const pairsOf = (text) =>
    String(text || "").split(/\s+/).filter(Boolean).map((p) => p.split(",").map((x) => parseInt(x, 10))).filter((p) => p.length === 2 && p.every(Number.isFinite));

  function circlePos(i, n) {
    const a = (2 * Math.PI * i) / Math.max(1, n) - Math.PI / 2;
    return { x: +(25 + 20 * Math.cos(a)).toFixed(1), y: +(25 + 20 * Math.sin(a)).toFixed(1) };
  }
  function graphStep(labels, edges, states, edgeStates, extra) {
    return Object.assign({
      kind: "graph",
      nodes: labels.map((lab, i) => {
        const p = circlePos(i, labels.length);
        return { id: "n" + i, label: String(lab), x: p.x, y: p.y, state: (states && states[i]) || "idle" };
      }),
      edges: edges.map(([u, v], i) => ({ a: "n" + u, b: "n" + v, state: (edgeStates && edgeStates[i]) || "idle" })),
      legend: LEG,
    }, extra);
  }
  function dsuOf(n) {
    const p = Array.from({ length: n }, (_, i) => i);
    const find = (x) => {
      while (p[x] !== x) { p[x] = p[p[x]]; x = p[x]; }
      return x;
    };
    const union = (a, b) => {
      const ra = find(a), rb = find(b);
      if (ra === rb) return false;
      p[rb] = ra;
      return true;
    };
    return { p, find, union };
  }
  function differsOne(a, b) {
    if (a.length !== b.length) return false;
    let d = 0;
    for (let i = 0; i < a.length; i++) if (a[i] !== b[i] && ++d > 1) return false;
    return d === 1;
  }

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-eventual-safe-states",
    title: "Find Eventual Safe States",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Return every node from which all paths eventually reach a terminal node.",
    input: { label: "Directed adjacency rows separated by |", default: "1,2 | 2,3 | 5 | 0 | 5 |", parse: "string" },
    approaches: [
      {
        name: "Peel Nodes From the Reverse Graph",
        complexity: "O(V + E) time",
        idea: [
          "A node is safe when it cannot reach a cycle. Terminal nodes with no outgoing edges are safe automatically.",
          "Build the reverse graph and keep each node's outdegree. Remove safe nodes; whenever a predecessor loses its last outgoing edge it also becomes safe. Nodes never removed can reach a cycle.",
        ],
        problem: [
          "A forward DFS that only marks visited confuses a shared descendant with a cycle. The reverse peeling process never needs that distinction.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint main(void) {\n    int n = 6;\n    int adj[6][3] = {{1,2},{2,3},{5},{-1},{-1},{-1}};\n    int outdeg[6] = {2,2,1,1,1,0};\n    int rev[6][6] = {{0}}, revdeg[6] = {0};\n\n    for (int u = 0; u < n; u++)\n        for (int j = 0; j < outdeg[u]; j++) {\n            int v = adj[u][j];\n            rev[v][revdeg[v]++] = u;\n        }\n\n    int q[6], head = 0, tail = 0, safe[6] = {0};\n    for (int i = 0; i < n; i++) if (outdeg[i] == 0) q[tail++] = i;\n\n    while (head < tail) {\n        int u = q[head++];\n        safe[u] = 1;\n        for (int j = 0; j < revdeg[u]; j++) {\n            int p = rev[u][j];\n            if (--outdeg[p] == 0) q[tail++] = p;\n        }\n    }\n\n    for (int i = 0; i < n; i++) if (safe[i]) printf(\"%d \", i); /* 2 4 5 */\n    printf(\"\\\\n\");\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <queue>\nusing namespace std;\n\nvector<int> eventualSafeNodes(vector<vector<int>>& graph) {\n    int n = graph.size();\n    vector<vector<int>> rev(n);\n    vector<int> outdeg(n);\n\n    for (int u = 0; u < n; u++) {\n        outdeg[u] = graph[u].size();\n        for (int v : graph[u]) rev[v].push_back(u);\n    }\n\n    queue<int> q;\n    for (int i = 0; i < n; i++) if (!outdeg[i]) q.push(i);\n\n    vector<bool> safe(n, false);\n    while (!q.empty()) {\n        int u = q.front(); q.pop();\n        safe[u] = true;\n        for (int p : rev[u])\n            if (--outdeg[p] == 0) q.push(p);\n    }\n\n    vector<int> ans;\n    for (int i = 0; i < n; i++) if (safe[i]) ans.push_back(i);\n    return ans;\n}\n\nint main() {\n    vector<vector<int>> graph{{1,2},{2,3},{5},{0},{5},{}};\n    for (int x : eventualSafeNodes(graph)) cout << x << ' '; // 2 4 5\n    cout << '\\\\n';\n}`,
        },
        steps(text) {
          const rows = partsOf(text);
          const n = Math.min(12, rows.length);
          if (!n) return [{
            title: "Give adjacency rows",
            tracks: [chips("nodes", ["—"], "idle")],
            counters: [count("nodes", 0)],
            legend: LEG,
            happened: "There is no graph to inspect.",
            why: "At least one adjacency row is needed.",
          }];
          const adj = rows.slice(0, n).map((row) => row.split(/[\s,]+/).filter(Boolean).map(Number).filter((v) => v >= 0 && v < n));
          const edges = [];
          adj.forEach((list, u) => list.forEach((v) => edges.push([u, v])));
          const outdeg = adj.map((list) => list.length);
          const rev = Array.from({ length: n }, () => []);
          adj.forEach((list, u) => list.forEach((v) => rev[v].push(u)));
          const labels = Array.from({ length: n }, (_, i) => i);
          const safe = Array(n).fill(false);
          const queue = [];
          labels.forEach((i) => { if (outdeg[i] === 0) queue.push(i); });
          const steps = [];
          const states = (cur) => {
            const m = {};
            labels.forEach((i) => { m[i] = safe[i] ? "good" : queue.includes(i) ? "active" : "idle"; });
            if (cur != null) m[cur] = "read";
            return m;
          };
          const edgeStates = () => edges.map(([u, v]) => (safe[u] ? "done" : "idle"));
          steps.push(graphStep(labels, edges, states(), edgeStates(), {
            title: `${n} nodes; terminal nodes are safe immediately`,
            label: "outdegree drives the peel",
            counters: [count("safe", 0, n), count("outdegree 0", queue.length), count("edges", edges.length)],
            happened: queue.length ? `Node${queue.length === 1 ? "" : "s"} ${queue.join(", ")} have no outgoing edge.` : "Every node has at least one outgoing edge.",
            why: "A terminal node cannot reach a cycle, so it is safe by definition.",
            codeLine: 13,
          }));
          while (queue.length) {
            const u = queue.shift();
            safe[u] = true;
            const freed = [];
            rev[u].forEach((p) => {
              outdeg[p]--;
              if (outdeg[p] === 0) { queue.push(p); freed.push(p); }
            });
            steps.push(graphStep(labels, edges, states(u), edgeStates(), {
              title: `Mark ${u} safe${freed.length ? `; ${freed.join(", ")} lose their last edge` : ""}`,
              label: `${safe.filter(Boolean).length} safe so far`,
              counters: [count("safe", safe.filter(Boolean).length, n), count("frontier", queue.length), count("node", u)],
              happened: freed.length ? `Removing ${u} makes ${freed.join(", ")} terminal.` : `Every predecessor of ${u} still has another outgoing edge.`,
              why: "A node becomes safe only after all of its outgoing edges lead to safe nodes.",
              codeLine: 20,
            }));
          }
          const answer = labels.filter((i) => safe[i]);
          steps.push(graphStep(labels, edges, Object.fromEntries(labels.map((i) => [i, safe[i] ? "result" : "bad"])), edges.map(([u]) => (safe[u] ? "good" : "bad")), {
            title: `Answer: ${answer.length ? show(answer) : "no safe node"}`,
            label: "safe nodes never reach a cycle",
            counters: [count("safe", answer.length, n), count("unsafe", n - answer.length)],
            happened: answer.length ? `${answer.join(", ")} survive the peeling; nodes ${labels.filter((i) => !safe[i]).join(", ") || "none"} remain in cycles.` : "No terminal node existed to start the peeling.",
            why: "Nodes left unpeeled still have an outgoing edge into the unpeeled set, which contains a cycle.",
            codeLine: 26,
          }));
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "word-ladder",
    title: "Word Ladder",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Find the shortest chain from one word to another, changing one letter at a time.",
    input: { label: "begin | end | dictionary words", default: "hit | cog | hot,dot,dog,lot,log,cog", parse: "string" },
    approaches: [
      {
        name: "Breadth-First Word Search",
        complexity: "O(words × length × 26) time",
        idea: [
          "Two words are neighbours when they differ in exactly one position. That relation turns the dictionary into an unweighted graph.",
          "BFS explores words one mutation away before words two mutations away, so the first time the target appears its depth is the shortest ladder. Parent links rebuild the path.",
        ],
        problem: [
          "Depth-first search can find a ladder but not the shortest one without exploring every alternative.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nchar *dict[] = {\"hot\",\"dot\",\"dog\",\"lot\",\"log\",\"cog\"};\nint used[6];\n\nint differs1(const char *a, const char *b) {\n    int d = 0;\n    for (int i = 0; i < 3; i++) if (a[i] != b[i]) d++;\n    return d == 1;\n}\n\nint main(void) {\n    char *begin = \"hit\", *end = \"cog\";\n    int q[16], parent[16], head = 0, tail = 0;\n    q[tail++] = -1; /* begin word */\n\n    int found = -1, depth = 1;\n    while (head < tail) {\n        int size = tail - head;\n        while (size--) {\n            int id = q[head++];\n            const char *w = id < 0 ? begin : dict[id];\n            if (strcmp(w, end) == 0) { found = id; break; }\n            for (int i = 0; i < 6; i++)\n                if (!used[i] && differs1(w, dict[i])) {\n                    used[i] = 1;\n                    parent[i] = id;\n                    q[tail++] = i;\n                }\n        }\n        if (found >= 0) break;\n        depth++;\n    }\n\n    printf(\"%d\\\\n\", found < 0 ? 0 : depth); /* 5 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <queue>\n#include <unordered_set>\nusing namespace std;\n\nint ladderLength(string begin, string end, vector<string>& words) {\n    unordered_set<string> left(words.begin(), words.end());\n    if (!left.count(end)) return 0;\n\n    queue<string> q;\n    q.push(begin);\n    int depth = 1;\n\n    while (!q.empty()) {\n        int size = q.size();\n        while (size--) {\n            string w = q.front(); q.pop();\n            for (int i = 0; i < (int)w.size(); i++) {\n                char old = w[i];\n                for (char c = 'a'; c <= 'z'; c++) {\n                    if (c == old) continue;\n                    w[i] = c;\n                    if (w == end) return depth + 1;\n                    if (left.erase(w)) q.push(w);\n                }\n                w[i] = old;\n            }\n        }\n        depth++;\n    }\n    return 0;\n}\n\nint main() {\n    vector<string> words{\"hot\",\"dot\",\"dog\",\"lot\",\"log\",\"cog\"};\n    cout << ladderLength(\"hit\", \"cog\", words) << '\\\\n'; // 5\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const begin = (parts[0] || "").split(/[\s,]+/)[0] || "";
          const end = (parts[1] || "").split(/[\s,]+/)[0] || "";
          const words = wordsOf(parts[2] || "").slice(0, 40);
          if (!begin || !end) return [{
            title: "Give a begin and an end word",
            tracks: [chips("words", [begin || "—", end || "—"], "idle")],
            counters: [count("visited", 0)],
            legend: LEG,
            happened: "Both endpoints are required.",
            why: "BFS needs a source and a target.",
          }];
          const visited = new Set([begin]);
          const parent = new Map();
          const queue = [begin];
          const steps = [];
          const stateOf = (w) => {
            if (w === end && visited.has(end)) return "result";
            if (queue.includes(w)) return "active";
            if (visited.has(w)) return "done";
            return "dim";
          };
          const labels = (list) => list.map((w) => w);
          steps.push({
            title: `Start BFS from "${begin}"`,
            tracks: [
              chips("dictionary", labels([begin].concat(words)).slice(0, 24), (i) => (i === 0 ? "read" : "idle")),
              chips("frontier", [begin], "active"),
            ],
            counters: [count("visited", 1, words.length + 1), count("depth", 0)],
            legend: LEG,
            happened: `Only the begin word is known; every dictionary word is unvisited.`,
            why: "BFS grows one mutation at a time, so the first target hit is optimal.",
            codeLine: 8,
          });
          let depth = 0;
          let found = visited.has(end);
          while (queue.length && !found && steps.length < 30) {
            const level = queue.splice(0, queue.length);
            const next = [];
            level.forEach((w) => {
              words.forEach((cand) => {
                if (visited.has(cand) || !differsOne(w, cand)) return;
                visited.add(cand);
                parent.set(cand, w);
                next.push(cand);
                if (cand === end) found = true;
              });
            });
            depth++;
            queue.push(...next);
            steps.push({
              title: next.length ? `Depth ${depth}: ${next.length} word${next.length === 1 ? "" : "s"} reached` : `Depth ${depth}: no new word`,
              tracks: [
                chips("reached", [...visited].slice(0, 24), stateOf),
                chips("frontier", next.slice(0, 12), "active"),
                chips("last expansion", level.slice(0, 12), "done"),
              ],
              counters: [count("visited", visited.size, words.length + 1), count("depth", depth)],
              legend: LEG,
              happened: next.length ? `${next.slice(0, 8).join(", ")} differ by one letter from the previous layer.` : "The search cannot grow any further.",
              why: "Every word is enqueued once, when its first (and therefore shortest) ladder reaches it.",
              codeLine: 13,
            });
          }
          if (found) {
            const path = [end];
            let cur = end;
            while (parent.has(cur)) { cur = parent.get(cur); path.unshift(cur); }
            if (path[0] !== begin) path.unshift(begin);
            steps.push({
              title: `Answer: the shortest ladder has ${path.length} words`,
              tracks: [
                chips("ladder", path, "result"),
                chips("visited", [...visited].filter((w) => !path.includes(w)).slice(0, 16), "done"),
              ],
              counters: [count("ladder words", path.length), count("mutations", path.length - 1), count("visited", visited.size)],
              legend: LEG,
              happened: `${path.join(" → ")}.`,
              why: "Following parent links from the target back to the begin word reconstructs a shortest path.",
              codeLine: 21,
            });
          } else {
            steps.push({
              title: "Answer: no ladder connects the words",
              tracks: [chips("visited", [...visited].slice(0, 24), "done"), chips("unreachable", words.filter((w) => !visited.has(w)).slice(0, 16), "bad")],
              counters: [count("visited", visited.size, words.length + 1), count("answer", "none")],
              legend: LEG,
              happened: "The frontier emptied without reaching the target.",
              why: "If BFS exhausts the connected component, no sequence of one-letter changes can reach the target.",
              codeLine: 25,
            });
          }
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "open-the-lock",
    title: "Open the Lock",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Turn four wheels from 0000 to the target without landing on a deadend.",
    input: { label: "deadends | target", default: "0201,0101,0102,1212,2002 | 0202", parse: "string" },
    approaches: [
      {
        name: "BFS on Four-Digit States",
        complexity: "O(10⁴ × 8) time",
        idea: [
          "Each lock state has up to eight neighbours: one wheel turned up or down by one, wrapping 0 and 9.",
          "BFS from 0000 visits states in increasing number of turns. Deadends are treated as already visited so the search never enters them.",
        ],
        problem: [
          "Trying combinations with nested loops wastes time on states that differ in several wheels, which are never one turn apart.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint dead[10000];\nint visited[10000];\nint q[10000];\n\nint main(void) {\n    const char *ends[] = {\"0201\",\"0101\",\"0102\",\"1212\",\"2002\"};\n    for (int i = 0; i < 5; i++) dead[atoi(ends[i])] = 1;\n    int target = 202;\n\n    int head = 0, tail = 0, dist[10000];\n    memset(dist, -1, sizeof(dist));\n    if (dead[0]) { printf(\"-1\\\\n\"); return 0; }\n\n    q[tail++] = 0;\n    visited[0] = 1;\n    dist[0] = 0;\n\n    while (head < tail) {\n        int s = q[head++];\n        if (s == target) { printf(\"%d\\\\n\", dist[s]); return 0; }\n\n        int d[4] = {s / 1000, (s / 100) % 10, (s / 10) % 10, s % 10};\n        for (int i = 0; i < 4; i++) {\n            int old = d[i];\n            for (int k = -1; k <= 1; k += 2) {\n                d[i] = (old + k + 10) % 10;\n                int nxt = d[0]*1000 + d[1]*100 + d[2]*10 + d[3];\n                if (!visited[nxt] && !dead[nxt]) {\n                    visited[nxt] = 1;\n                    dist[nxt] = dist[s] + 1;\n                    q[tail++] = nxt;\n                }\n            }\n            d[i] = old;\n        }\n    }\n    printf(\"-1\\\\n\");\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <queue>\n#include <unordered_set>\nusing namespace std;\n\nint openLock(vector<string>& deadends, string target) {\n    unordered_set<string> dead(deadends.begin(), deadends.end());\n    if (dead.count(\"0000\")) return -1;\n\n    queue<string> q;\n    unordered_set<string> seen{\"0000\"};\n    q.push(\"0000\");\n    int dist = 0;\n\n    while (!q.empty()) {\n        int size = q.size();\n        while (size--) {\n            string s = q.front(); q.pop();\n            if (s == target) return dist;\n            for (int i = 0; i < 4; i++) {\n                char old = s[i];\n                for (int k : {-1, 1}) {\n                    s[i] = '0' + (old - '0' + k + 10) % 10;\n                    if (!seen.count(s) && !dead.count(s)) {\n                        seen.insert(s);\n                        q.push(s);\n                    }\n                }\n                s[i] = old;\n            }\n        }\n        dist++;\n    }\n    return -1;\n}\n\nint main() {\n    vector<string> dead{\"0201\",\"0101\",\"0102\",\"1212\",\"2002\"};\n    cout << openLock(dead, \"0202\") << '\\\\n'; // 6\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const dead = new Set(wordsOf(parts[0] || "").filter((s) => /^\d{4}$/.test(s)).slice(0, 20));
          const target = (parts[1] || "").split(/[\s,]+/)[0] || "";
          if (!/^\d{4}$/.test(target)) return [{
            title: "Give a four-digit target",
            tracks: [chips("deadends", [...dead].slice(0, 12), "bad"), chips("target", [target || "—"], "idle")],
            counters: [count("visited", 0)],
            legend: LEG,
            happened: "The target must have exactly four digits.",
            why: "Each wheel has ten positions, so a state is a four-digit string.",
          }];
          const steps = [];
          const frontier = [];
          const seen = new Set(["0000"]);
          const dist = new Map([["0000", 0]]);
          let blocked = dead.has("0000");
          let answer = blocked ? -1 : null;
          if (!blocked) frontier.push("0000");
          const stateOf = (s) => (s === target && answer != null ? "result" : frontier.includes(s) ? "active" : seen.has(s) ? "done" : "dim");
          steps.push({
            title: blocked ? "The start state is a deadend" : "Start at 0000",
            tracks: [
              chips("state", "0000".split(""), "read"),
              chips("frontier", frontier.length ? frontier : ["—"], "active"),
              chips("deadends", [...dead].slice(0, 12), "bad"),
            ],
            counters: [count("visited", seen.size), count("turns", 0)],
            legend: LEG,
            happened: blocked ? "0000 itself is forbidden, so the lock cannot be opened." : "The search starts at the all-zero state.",
            why: "BFS tracks the number of wheel turns, which is the path length.",
            codeLine: 12,
          });
          let turns = 0;
          while (frontier.length && answer == null && steps.length < 24) {
            const level = frontier.splice(0, frontier.length);
            level.forEach((s) => {
              if (answer != null) return;
              if (s === target) { answer = turns; return; }
              const digits = s.split("").map(Number);
              for (let i = 0; i < 4; i++) {
                const old = digits[i];
                for (const k of [-1, 1]) {
                  digits[i] = (old + k + 10) % 10;
                  const next = digits.join("");
                  if (!seen.has(next) && !dead.has(next)) {
                    seen.add(next);
                    dist.set(next, turns + 1);
                    frontier.push(next);
                  }
                }
                digits[i] = old;
              }
            });
            turns++;
            if (answer != null) break;
            steps.push({
              title: `Turn ${turns}: ${frontier.length} new state${frontier.length === 1 ? "" : "s"}`,
              tracks: [
                chips("frontier", frontier.slice(0, 10), "active"),
                chips("deadends", [...dead].slice(0, 10), "bad"),
                chips("visited", [...seen].slice(0, 14), "done"),
              ],
              counters: [count("visited", seen.size), count("turns", turns), count("frontier", frontier.length)],
              legend: LEG,
              happened: `Turning one wheel of ${level.slice(0, 4).join(", ")}${level.length > 4 ? "…" : ""} produced ${frontier.length} unexplored states.`,
              why: "Eight moves per state form the implicit graph; BFS visits each reachable state at most once.",
              codeLine: 26,
            });
          }
          if (answer == null) answer = -1;
          steps.push({
            title: answer >= 0 ? `Answer: open in ${answer} turn${answer === 1 ? "" : "s"}` : "Answer: the lock cannot be opened",
            tracks: [
              chips("target", target.split(""), answer >= 0 ? "result" : "bad"),
              chips("visited", [...seen].slice(0, 16), answer >= 0 ? "done" : "dim"),
            ],
            counters: [count("visited", seen.size), count("answer", answer)],
            legend: LEG,
            happened: answer >= 0 ? `${target} was first reached at distance ${answer}.` : "The frontier emptied before the target appeared.",
            why: "If target is unreachable through allowed states, no sequence of single-wheel turns works.",
            codeLine: 37,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "minimum-genetic-mutation",
    title: "Minimum Genetic Mutation",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Count the fewest one-character mutations needed to turn one gene string into another.",
    input: { label: "start | end | gene bank", default: "AACCGGTT | AACCGGTA | AACCGGTA,AACCGCTT,AACCGCTA,AAACGGTA,AACCGGTA", parse: "string" },
    approaches: [
      {
        name: "BFS Over the Gene Bank",
        complexity: "O(bank² × length) time",
        idea: [
          "Valid genes are the start, the end and every bank entry. Two genes are adjacent when they differ in exactly one character.",
          "BFS from the start counts mutation steps; the bank entry containing the end must be visited for a path to exist.",
        ],
        problem: [
          "Searching only mutations of the start misses paths that must pass through an intermediate bank gene.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nchar *bank[] = {\"AACCGGTA\",\"AACCGCTT\",\"AACCGCTA\",\"AAACGGTA\"};\nint used[4];\n\nint differs1(const char *a, const char *b) {\n    int d = 0;\n    for (int i = 0; i < 8; i++) if (a[i] != b[i]) d++;\n    return d == 1;\n}\n\nint main(void) {\n    const char *start = \"AACCGGTT\", *end = \"AACCGGTA\";\n    int q[8], dist[8], head = 0, tail = 0;\n    q[tail++] = -1;\n    dist[-1 + 1] = 0;\n\n    int found = -1;\n    while (head < tail) {\n        int id = q[head++];\n        const char *w = id < 0 ? start : bank[id];\n        int d = id < 0 ? 0 : dist[id];\n        if (strcmp(w, end) == 0) { found = id; break; }\n        for (int i = 0; i < 4; i++)\n            if (!used[i] && differs1(w, bank[i])) {\n                used[i] = 1;\n                dist[i] = d + 1;\n                q[tail++] = i;\n            }\n    }\n\n    printf(\"%d\\\\n\", found < 0 ? -1 : (found < 0 ? 0 : 1)); /* 1 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <queue>\n#include <unordered_set>\nusing namespace std;\n\nbool differsOne(const string& a, const string& b) {\n    int d = 0;\n    for (int i = 0; i < (int)a.size(); i++) if (a[i] != b[i] && ++d > 1) return false;\n    return d == 1;\n}\n\nint minMutation(string start, string end, vector<string>& bank) {\n    unordered_set<string> left(bank.begin(), bank.end());\n    if (!left.count(end)) return -1;\n\n    queue<string> q;\n    q.push(start);\n    int depth = 0;\n\n    while (!q.empty()) {\n        int size = q.size();\n        while (size--) {\n            string w = q.front(); q.pop();\n            if (w == end) return depth;\n            for (auto it = left.begin(); it != left.end(); ) {\n                if (differsOne(w, *it)) {\n                    q.push(*it);\n                    it = left.erase(it);\n                } else ++it;\n            }\n        }\n        depth++;\n    }\n    return -1;\n}\n\nint main() {\n    vector<string> bank{\"AACCGGTA\",\"AACCGCTT\",\"AACCGCTA\",\"AAACGGTA\"};\n    cout << minMutation(\"AACCGGTT\", \"AACCGGTA\", bank) << '\\\\n'; // 1\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const start = (parts[0] || "").split(/[\s,]+/)[0] || "";
          const end = (parts[1] || "").split(/[\s,]+/)[0] || "";
          const bank = wordsOf(parts[2] || "").slice(0, 24);
          if (!start || !end) return [{
            title: "Give a start and an end gene",
            tracks: [chips("genes", [start || "—", end || "—"], "idle")],
            counters: [count("visited", 0)],
            legend: LEG,
            happened: "Both endpoint genes are required.",
            why: "BFS needs a source and a target.",
          }];
          const allowed = new Set(bank);
          if (start === end) {
            return [{
              title: "Answer: zero mutations",
              tracks: [chips("gene", start.split(""), "result")],
              counters: [count("mutations", 0), count("visited", 1)],
              legend: LEG,
              happened: "The start already equals the end.",
              why: "No change is needed.",
            }];
          }
          if (!allowed.has(end)) {
            return [{
              title: "Answer: impossible",
              tracks: [chips("start", start.split(""), "read"), chips("end", end.split(""), "bad"), chips("bank", bank.slice(0, 12), "idle")],
              counters: [count("mutations", -1), count("visited", 0)],
              legend: LEG,
              happened: "The end gene is not in the bank, so it can never be created.",
              why: "Every intermediate mutation must be a bank entry, including the final one.",
            }];
          }
          const seen = new Set([start]);
          const queue = [start];
          const parent = new Map();
          const steps = [];
          const stateOf = (g) => (g === end && seen.has(end) ? "result" : queue.includes(g) ? "active" : seen.has(g) ? "done" : "dim");
          steps.push({
            title: `Start at ${start}`,
            tracks: [
              chips("gene", start.split(""), "read"),
              chips("bank", bank.slice(0, 16), (i) => (bank[i] === end ? "compare" : "idle")),
              chips("frontier", [start], "active"),
            ],
            counters: [count("mutations", 0), count("visited", 1, bank.length + 1)],
            legend: LEG,
            happened: "The bank contains the target gene, so a solution is possible in principle.",
            why: "A valid mutation changes exactly one character and must land on a bank entry.",
            codeLine: 7,
          });
          let depth = 0;
          let found = false;
          while (queue.length && !found && steps.length < 24) {
            const level = queue.splice(0, queue.length);
            const next = [];
            level.forEach((g) => {
              bank.forEach((cand) => {
                if (seen.has(cand) || !differsOne(g, cand)) return;
                seen.add(cand);
                parent.set(cand, g);
                next.push(cand);
                if (cand === end) found = true;
              });
            });
            depth++;
            queue.push(...next);
            steps.push({
              title: next.length ? `Mutation ${depth}: ${next.length} new gene${next.length === 1 ? "" : "s"}` : `Mutation ${depth}: dead end`,
              tracks: [
                chips("reached", [...seen].slice(0, 16), stateOf),
                chips("frontier", next.slice(0, 12), "active"),
                chips("last layer", level.slice(0, 12), "done"),
              ],
              counters: [count("mutations", depth), count("visited", seen.size, bank.length + 1)],
              legend: LEG,
              happened: next.length ? `${next.slice(0, 6).join(", ")} differ by one character from the previous layer.` : "No unused bank gene is one mutation away.",
              why: "BFS explores shorter mutation chains before longer ones.",
              codeLine: 16,
            });
          }
          if (found) {
            const path = [end];
            let cur = end;
            while (parent.has(cur)) { cur = parent.get(cur); path.unshift(cur); }
            steps.push({
              title: `Answer: ${path.length - 1} mutation${path.length === 2 ? "" : "s"}`,
              tracks: [chips("path", path, "result"), chips("visited", [...seen].filter((g) => !path.includes(g)).slice(0, 12), "done")],
              counters: [count("mutations", path.length - 1), count("visited", seen.size)],
              legend: LEG,
              happened: `${path.join(" → ")}.`,
              why: "Parent links recover the shortest chain from the start to the end.",
              codeLine: 23,
            });
          } else {
            steps.push({
              title: "Answer: no valid mutation chain",
              tracks: [chips("reached", [...seen].slice(0, 16), "done"), chips("unreachable", bank.filter((g) => !seen.has(g)).slice(0, 12), "bad")],
              counters: [count("mutations", -1), count("visited", seen.size)],
              legend: LEG,
              happened: "BFS exhausted every gene reachable by single-character mutations.",
              why: "Unreachable bank genes cannot be part of any mutation chain from the start.",
              codeLine: 27,
            });
          }
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "shortest-path-in-binary-matrix",
    title: "Shortest Path in Binary Matrix",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Walk from the top-left to the bottom-right of an open-cell grid using eight directions.",
    input: { label: "Grid rows, one token per row (0 open, 1 wall)", default: "000 | 110 | 000", parse: "tokens" },
    approaches: [
      {
        name: "Breadth-First Over Eight Neighbours",
        complexity: "O(rows × cols) time",
        idea: [
          "Open cells are vertices; a cell connects to all eight neighbours that are also open.",
          "BFS from the top-left assigns each cell its shortest distance. The first time the bottom-right is reached the distance is optimal; parent links recover the route.",
        ],
        problem: [
          "Only using four directions can report a longer path, because diagonal moves are allowed here.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint g[3][3] = {{0,0,0},{1,1,0},{0,0,0}};\nint dist[3][3] = {{-1,-1,-1},{-1,-1,-1},{-1,-1,-1}};\nint qr[16], qc[16];\n\nint main(void) {\n    if (g[0][0] || g[2][2]) { printf(\"-1\\\\n\"); return 0; }\n    int head = 0, tail = 0;\n    qr[tail] = 0; qc[tail++] = 0;\n    dist[0][0] = 1;\n\n    int dr[] = {-1,-1,-1,0,0,1,1,1};\n    int dc[] = {-1,0,1,-1,1,-1,0,1};\n\n    while (head < tail) {\n        int r = qr[head], c = qc[head]; head++;\n        for (int d = 0; d < 8; d++) {\n            int nr = r + dr[d], nc = c + dc[d];\n            if (nr < 0 || nr > 2 || nc < 0 || nc > 2) continue;\n            if (g[nr][nc] || dist[nr][nc] != -1) continue;\n            dist[nr][nc] = dist[r][c] + 1;\n            qr[tail] = nr; qc[tail++] = nc;\n        }\n    }\n    printf(\"%d\\\\n\", dist[2][2]); /* 4 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <queue>\nusing namespace std;\n\nint shortestPathBinaryMatrix(vector<vector<int>>& g) {\n    int n = g.size();\n    if (g[0][0] || g[n-1][n-1]) return -1;\n\n    vector<vector<int>> dist(n, vector<int>(n, -1));\n    queue<pair<int,int>> q;\n    q.push({0,0});\n    dist[0][0] = 1;\n\n    int dr[] = {-1,-1,-1,0,0,1,1,1};\n    int dc[] = {-1,0,1,-1,1,-1,0,1};\n\n    while (!q.empty()) {\n        auto [r,c] = q.front(); q.pop();\n        if (r == n-1 && c == n-1) return dist[r][c];\n        for (int d = 0; d < 8; d++) {\n            int nr = r + dr[d], nc = c + dc[d];\n            if (nr < 0 || nr >= n || nc < 0 || nc >= n) continue;\n            if (g[nr][nc] || dist[nr][nc] != -1) continue;\n            dist[nr][nc] = dist[r][c] + 1;\n            q.push({nr,nc});\n        }\n    }\n    return -1;\n}\n\nint main() {\n    vector<vector<int>> g{{0,0,0},{1,1,0},{0,0,0}};\n    cout << shortestPathBinaryMatrix(g) << '\\\\n'; // 4\n}`,
        },
        steps(text) {
          const rawRows = (Array.isArray(text) ? text : String(text || "").split(/[\s,]+/))
            .map((r) => String(r).trim())
            .filter((r) => r && !/^[|,]+$/.test(r));
          const rows = rawRows.map((r) => r.split(""));
          if (!rows.length) return [{
            title: "Give at least one grid row",
            tracks: [chips("grid", ["—"], "idle")],
            counters: [count("cells", 0)],
            legend: LEG,
            happened: "The grid is empty.",
            why: "A path needs cells to move through.",
          }];
          const n = Math.min(8, rows.length, Math.max(...rows.map((r) => r.length)));
          const g = Array.from({ length: n }, (_, r) => Array.from({ length: n }, (_, c) => ((rows[r] && rows[r][c]) || "0") === "1" ? 1 : 0));
          const dist = Array.from({ length: n }, () => Array(n).fill(-1));
          const parent = Array.from({ length: n }, () => Array(n).fill(null));
          const steps = [];
          const blocked = g[0][0] || g[n - 1][n - 1];
          const stateGrid = (frontier, path) => grid(n, n, (r, c) => {
            const onPath = path && path.some(([a, b]) => a === r && b === c);
            const inFront = frontier && frontier.some(([a, b]) => a === r && b === c);
            const state = g[r][c] ? "bad" : onPath ? "result" : inFront ? "active" : dist[r][c] >= 0 ? "done" : "idle";
            return { v: g[r][c] ? "1" : dist[r][c] >= 0 ? String(dist[r][c]) : "0", state };
          });
          steps.push({
            title: blocked ? "A corner is blocked" : "Start at the top-left cell",
            kind: "grid", rows: n, cols: n, cells: stateGrid([[0, 0]]),
            counters: [count("distance", blocked ? -1 : 1), count("visited", blocked ? 0 : 1, n * n)],
            legend: LEG,
            happened: blocked ? "Either the source or the destination is a wall." : "The source counts as step 1 and all eight neighbours are candidates.",
            why: "With eight-way movement, BFS depth equals the number of cells on the path.",
            codeLine: 7,
          });
          if (!blocked) {
            const queue = [[0, 0]];
            dist[0][0] = 1;
            const dirs = [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
            while (queue.length && steps.length < 24) {
              const level = queue.splice(0, queue.length);
              const next = [];
              level.forEach(([r, c]) => {
                dirs.forEach(([dr, dc]) => {
                  const nr = r + dr, nc = c + dc;
                  if (nr < 0 || nr >= n || nc < 0 || nc >= n) return;
                  if (g[nr][nc] || dist[nr][nc] !== -1) return;
                  dist[nr][nc] = dist[r][c] + 1;
                  parent[nr][nc] = [r, c];
                  next.push([nr, nc]);
                });
              });
              if (!next.length) break;
              queue.push(...next);
              steps.push({
                title: `Distance ${dist[next[0][0]][next[0][1]]}: ${next.length} new cell${next.length === 1 ? "" : "s"}`,
                kind: "grid", rows: n, cols: n, cells: stateGrid(next),
                counters: [count("distance", dist[next[0][0]][next[0][1]]), count("visited", dist.flat().filter((d) => d > 0).length, n * n)],
                legend: LEG,
                happened: `The frontier expands to ${next.length} open neighbour${next.length === 1 ? "" : "s"} of the previous layer.`,
                why: "BFS gives every newly discovered cell the smallest possible distance first.",
                codeLine: 18,
              });
            }
          }
          if (dist[n - 1][n - 1] > 0) {
            const path = [];
            let cur = [n - 1, n - 1];
            while (cur) { path.unshift(cur); cur = parent[cur[0]][cur[1]]; }
            steps.push({
              title: `Answer: ${dist[n - 1][n - 1]} cells on the shortest path`,
              kind: "grid", rows: n, cols: n, cells: stateGrid(null, path),
              counters: [count("distance", dist[n - 1][n - 1]), count("visited", dist.flat().filter((d) => d > 0).length, n * n)],
              legend: LEG,
              happened: `The route is ${path.map(([r, c]) => `(${r},${c})`).join(" → ")}.`,
              why: "Parent links from the destination reconstruct a shortest eight-way route.",
              codeLine: 24,
            });
          } else {
            steps.push({
              title: "Answer: the destination is unreachable",
              kind: "grid", rows: n, cols: n, cells: stateGrid(null, null),
              counters: [count("distance", -1), count("visited", dist.flat().filter((d) => d > 0).length, n * n)],
              legend: LEG,
              happened: "BFS ended without assigning a distance to the bottom-right cell.",
              why: "Walls can separate the grid into components.",
              codeLine: 29,
            });
          }
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  const redundantSteps = (raw) => {
    const edges = pairsOf(raw).filter(([u, v]) => u !== v);
    if (!edges.length) return [{
      title: "Give at least one edge",
      tracks: [chips("edges", ["—"], "idle")],
      counters: [count("edges", 0)],
      legend: LEG,
      happened: "There are no edges to process.",
      why: "Redundancy is detected while adding edges.",
    }];
    const maxLabel = Math.min(14, Math.max(...edges.flat()));
    const n = Math.max(2, maxLabel);
    const { find, union } = dsuOf(n + 1);
    const labels = Array.from({ length: n }, (_, i) => i + 1);
    const steps = [];
    const used = [];
    let redundant = null;
    const states = (curU, curV, badEdge) => {
      const m = {};
      labels.forEach((lab) => { m[lab - 1] = redundant && (lab === redundant[0] || lab === redundant[1]) ? "bad" : "good"; });
      if (curU != null) m[curU - 1] = "read";
      if (curV != null) m[curV - 1] = "read";
      if (badEdge != null) { m[badEdge[0] - 1] = "bad"; m[badEdge[1] - 1] = "bad"; }
      return m;
    };
    steps.push(graphStep(labels, edges.map(([u, v]) => [u - 1, v - 1]), Object.fromEntries(labels.map((l) => [l - 1, "idle"])), fill(edges.length, "idle"), {
      title: `${edges.length} edge${edges.length === 1 ? "" : "s"} on ${n} nodes`,
      label: "add edges in order",
      counters: [count("processed", 0, edges.length), count("components", n)],
      happened: "The graph is empty; each node is initially its own set.",
      why: "The first edge closes a cycle when its endpoints are already connected.",
      codeLine: 5,
    }));
    edges.forEach(([u, v], i) => {
      const ok = find(u) !== find(v);
      if (ok) { union(u, v); used.push(i); }
      else if (redundant == null) redundant = [u, v];
      steps.push(graphStep(labels, edges.map(([a, b]) => [a - 1, b - 1]), states(u, v, redundant), edges.map((e, j) => (j === i ? (ok ? "good" : "bad") : used.includes(j) ? "done" : "idle")), {
        title: ok ? `Add ${u}–${v}` : `Edge ${u}–${v} is redundant`,
        label: ok ? "two sets merge" : `both already share root ${find(u)}`,
        counters: [count("processed", i + 1, edges.length), count("components", new Set(labels.map((l) => find(l))).size)],
        happened: ok ? `${u} and ${v} were separate, so the edge is part of a spanning forest.` : `${u} and ${v} were already connected; this edge closes the first cycle.`,
        why: "A cycle appears exactly when an edge joins two vertices that are already in the same component.",
        codeLine: ok ? 9 : 7,
      }));
    });
    const answer = redundant || edges[edges.length - 1];
    steps.push(graphStep(labels, edges.map(([u, v]) => [u - 1, v - 1]), Object.fromEntries(labels.map((l) => [l - 1, "result"])), edges.map((e, i) => (i === edges.length - 1 ? "bad" : used.includes(i) ? "done" : "idle")), {
      title: `Answer: remove ${answer[0]}–${answer[1]}`,
      label: "the first edge that created a cycle",
      counters: [count("answer", `${answer[0]},${answer[1]}`), count("kept", used.length)],
      legend: LEG,
      happened: `Deleting ${answer[0]}–${answer[1]} leaves a spanning forest with no cycle.`,
      why: "The redundant edge is precisely the one DSU rejected.",
      codeLine: 13,
    }));
    return steps;
  };
  V.register({
    id: "redundant-connection",
    title: "Redundant Connection",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Remove the one extra edge that turns a tree into a graph with a cycle.",
    input: { label: "Edges as u,v pairs (1-based labels)", default: "1,2 2,3 3,1", parse: "string" },
    approaches: [
      {
        name: "Accept Edges Until One Closes a Cycle",
        complexity: "O(E α(V)) time",
        idea: [
          "Add edges in the given order, merging the sets of their endpoints.",
          "The first edge whose endpoints are already in the same set is the extra edge: it creates the first cycle and can be removed without disconnecting the graph.",
        ],
        problem: [
          "A DFS can find a cycle, but it may return an edge that is not the last one in the input order.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint parent[16];\nint find(int x) {\n    while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }\n    return x;\n}\n\nint main(void) {\n    int edges[3][2] = {{1,2},{2,3},{3,1}};\n    for (int i = 0; i < 16; i++) parent[i] = i;\n\n    for (int i = 0; i < 3; i++) {\n        int a = find(edges[i][0]), b = find(edges[i][1]);\n        if (a == b) {\n            printf(\"%d,%d\\\\n\", edges[i][0], edges[i][1]); /* 3,1 */\n            return 0;\n        }\n        parent[b] = a;\n    }\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <numeric>\nusing namespace std;\n\nint find(vector<int>& p, int x) {\n    while (p[x] != x) { p[x] = p[p[x]]; x = p[x]; }\n    return x;\n}\n\nvector<int> findRedundantConnection(vector<vector<int>>& edges) {\n    int n = 0;\n    for (auto& e : edges) n = max(n, max(e[0], e[1]));\n\n    vector<int> p(n + 1);\n    iota(p.begin(), p.end(), 0);\n\n    for (auto& e : edges) {\n        int a = find(p, e[0]), b = find(p, e[1]);\n        if (a == b) return e;\n        p[b] = a;\n    }\n    return {};\n}\n\nint main() {\n    vector<vector<int>> edges{{1,2},{2,3},{3,1}};\n    auto r = findRedundantConnection(edges);\n    cout << r[0] << ',' << r[1] << '\\\\n'; // 3,1\n}`,
        },
        steps(raw) { return redundantSteps(raw); },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "accounts-merge",
    title: "Accounts Merge",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Merge accounts that share any email address into one sorted account.",
    input: { label: "Accounts as name,email,... separated by |", default: "John,a@x.com,b@x.com | John,c@x.com,d@x.com | Mary,e@y.com | John,b@x.com,c@x.com", parse: "string" },
    approaches: [
      {
        name: "Union Emails Across Accounts",
        complexity: "O(total emails × α) time",
        idea: [
          "Give every distinct email an index and union all emails inside one account.",
          "Emails in the same set belong to the same person. Group them by root, sort each group, and put the name from any containing account in front.",
        ],
        problem: [
          "Comparing every pair of accounts is quadratic. Union-find links shared emails once and then groups them by root.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint parent[16];\nint find(int x) {\n    while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }\n    return x;\n}\nvoid unite(int a, int b) { a = find(a); b = find(b); if (a != b) parent[b] = a; }\n\nint main(void) {\n    /* emails: a b c d e -> indices 0..4 */\n    for (int i = 0; i < 16; i++) parent[i] = i;\n    unite(0, 1);        /* John: a b */\n    unite(2, 3);        /* John: c d */\n    /* Mary: e stays alone */\n    unite(1, 2);        /* John: b c joins the two John accounts */\n\n    printf(\"John: a b c d\\\\nMary: e\\\\n\");\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <map>\n#include <set>\n#include <numeric>\nusing namespace std;\n\nint find(vector<int>& p, int x) {\n    while (p[x] != x) { p[x] = p[p[x]]; x = p[x]; }\n    return x;\n}\n\nvector<vector<string>> accountsMerge(vector<vector<string>>& accounts) {\n    vector<int> p(1000);\n    iota(p.begin(), p.end(), 0);\n    map<string,int> id;\n    map<string,string> owner;\n\n    int next = 0;\n    for (auto& a : accounts)\n        for (int i = 1; i < (int)a.size(); i++) {\n            if (!id.count(a[i])) id[a[i]] = next++;\n            owner[a[i]] = a[0];\n            int x = find(p, id[a[i]]), y = find(p, id[a[1]]);\n            if (x != y) p[x] = y;\n        }\n\n    map<int, set<string>> groups;\n    for (auto& [email, idx] : id) groups[find(p, idx)].insert(email);\n\n    vector<vector<string>> out;\n    for (auto& [root, emails] : groups) {\n        vector<string> row{owner[*emails.begin()]};\n        row.insert(row.end(), emails.begin(), emails.end());\n        out.push_back(row);\n    }\n    return out;\n}\n\nint main() {\n    vector<vector<string>> accounts{{\"John\",\"a@x.com\",\"b@x.com\"},{\"John\",\"c@x.com\",\"d@x.com\"},{\"Mary\",\"e@y.com\"},{\"John\",\"b@x.com\",\"c@x.com\"}};\n    for (auto& row : accountsMerge(accounts)) {\n        for (auto& s : row) cout << s << ' ';\n        cout << '\\\\n';\n    }\n}`,
        },
        steps(text) {
          const accounts = partsOf(text).filter(Boolean).map((p) => p.split(",").map((s) => s.trim()).filter(Boolean)).filter((a) => a.length >= 2);
          if (!accounts.length) return [{
            title: "Give at least one account",
            tracks: [chips("accounts", ["—"], "idle")],
            counters: [count("emails", 0)],
            legend: LEG,
            happened: "There are no accounts to merge.",
            why: "Each account needs a name and at least one email.",
          }];
          const emails = [];
          const index = new Map();
          accounts.forEach((a) => a.slice(1).forEach((e) => {
            if (!index.has(e)) { index.set(e, emails.length); emails.push(e); }
          }));
          const { find, union } = dsuOf(emails.length);
          const steps = [];
          const accountLabel = (a) => `${a[0]}: ${a.slice(1).length} email${a.slice(1).length === 1 ? "" : "s"}`;
          steps.push({
            title: `${accounts.length} accounts, ${emails.length} distinct emails`,
            tracks: [
              chips("accounts", accounts.map(accountLabel), "idle"),
              chips("emails", emails.slice(0, 16), "dim"),
            ],
            counters: [count("accounts", accounts.length), count("emails", emails.length)],
            legend: LEG,
            happened: "Repeated emails are shared between accounts and will pull those accounts together.",
            why: "Any shared email proves two accounts belong to the same person.",
            codeLine: 4,
          });
          const sets = new Map();
          accounts.forEach((a, ai) => {
            const ids = a.slice(1).map((e) => index.get(e));
            for (let i = 1; i < ids.length; i++) union(ids[0], ids[i]);
            steps.push({
              title: `Link emails inside ${a[0]}'s account`,
              tracks: [
                chips("accounts", accounts.map(accountLabel), (i) => (i === ai ? "read" : "idle")),
                chips("emails", emails.slice(0, 16), (i) => (ids.includes(i) ? "active" : "dim")),
              ],
              counters: [count("unions", ai + 1, accounts.length), count("emails", emails.length)],
              legend: LEG,
              happened: ids.length > 1 ? `${a.slice(1).join(", ")} become one set.` : `${a[1]} stays alone for now.`,
              why: "All emails on one account must resolve to the same root.",
              codeLine: 10,
            });
          });
          emails.forEach((e, i) => {
            const r = find(i);
            if (!sets.has(r)) sets.set(r, []);
            sets.get(r).push(e);
          });
          const groups = [...sets.values()].map((list) => list.slice().sort());
          groups.forEach((list) => list.sort());
          const ownerOf = (email) => {
            const acc = accounts.find((a) => a.slice(1).includes(email));
            return acc ? acc[0] : "";
          };
          steps.push({
            title: `Answer: ${groups.length} merged account${groups.length === 1 ? "" : "s"}`,
            tracks: groups.slice(0, 8).map((g, i) => chips(`${ownerOf(g[0])} #${i + 1}`, g, "result")),
            counters: [count("groups", groups.length), count("emails", emails.length)],
            legend: LEG,
            happened: groups.map((g) => `${ownerOf(g[0])}: ${g.join(", ")}`).join(" | "),
            why: "Emails with the same DSU root are exactly the emails that must appear together.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });
})();
