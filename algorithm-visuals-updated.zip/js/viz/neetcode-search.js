/* ============================================================
   DSA Visuals - NeetCode 250 additions, searching and stacks
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => "[" + a.join(", ") + "]";
  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-k-closest-elements",
    title: "Find K Closest Elements",
    category: "Sliding Window",
    difficulty: "Intermediate",
    description: "Pick the k sorted values nearest to a target.",
    input: { label: "sorted numbers | k, target", default: "1, 2, 3, 4, 5 | 4, 3", parse: "tworows" },
    approaches: [
      {
        name: "Shrink the Window",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "Start with a window containing every element. While it is wider than k, compare the element just outside the left edge with the one just outside the right edge.",
          "Discard the farther element. Removing the left value moves the left edge right; removing the right value moves the right edge left. Ties discard the right value because the left values are smaller.",
        ],
        problem: ["The scan is linear. A binary-search version can find the starting index in O(log n), but the window idea is easier to see."],
        code: {
          c: `#include <stdlib.h>

int* findClosestElements(int* a, int n, int k, int x, int* returnSize) {
    int left = 0, right = n - 1;
    while (right - left + 1 > k) {
        if (abs(a[left] - x) <= abs(a[right] - x)) right--;
        else left++;
    }
    *returnSize = k;
    int* out = malloc(k * sizeof(int));
    for (int i = 0; i < k; i++) out[i] = a[left + i];
    return out;
}`,
          cpp: `#include <vector>
using namespace std;

vector<int> findClosestElements(vector<int>& a, int k, int x) {
    int left = 0, right = (int)a.size() - 1;
    while (right - left + 1 > k) {
        if (abs(a[left] - x) <= abs(a[right] - x)) right--;
        else left++;
    }
    return vector<int>(a.begin() + left, a.begin() + right + 1);
}`,
        },
        steps(parsed) {
          const a = (parsed[0] || []).slice().sort((x, y) => x - y);
          const k = Math.max(1, Math.min((parsed[1] || [1])[0] || 1, a.length || 1));
          const x = (parsed[1] || [0, 0])[1] || 0;
          const out = [];
          let left = 0, right = a.length - 1;
          out.push({
            title: `Start with all ${a.length} values`,
            tracks: [track("sorted values", a, a.map((v, i) => (i === left || i === right ? "compare" : "idle")))],
            counters: [count("window size", a.length, a.length), count("target", x)],
            happened: `The target is ${x}; the window currently spans both ends.`,
            why: "The answer must be a contiguous block in a sorted array, so only the two edges need comparing.",
            legend: LEG,
            codeLine: 3,
          });
          while (right - left + 1 > k && left <= right) {
            const dl = Math.abs(a[left] - x);
            const dr = Math.abs(a[right] - x);
            const dropRight = dl <= dr;
            const removed = dropRight ? a[right] : a[left];
            const states = a.map((v, i) => (i < left || i > right ? "dim" : i === left || i === right ? "compare" : "idle"));
            out.push({
              title: `Compare ${a[left]} and ${a[right]}`,
              tracks: [track("sorted values", a, states)],
              counters: [count("left distance", dl), count("right distance", dr)],
              happened: `|${a[left]} - ${x}| = ${dl} and |${a[right]} - ${x}| = ${dr}.`,
              why: dropRight ? "The right value is at least as far away, so it leaves the window." : "The left value is farther away, so it leaves the window.",
              legend: LEG,
              codeLine: 5,
            });
            if (dropRight) right--;
            else left++;
            out.push({
              title: `Discard ${removed}; window is ${right - left + 1} wide`,
              tracks: [track("sorted values", a, a.map((v, i) => (i < left || i > right ? "dim" : "done")))],
              counters: [count("window size", right - left + 1, k), count("removed", removed)],
              happened: `The remaining candidates are ${show(a.slice(left, right + 1))}.`,
              why: "A value outside the final contiguous block cannot be part of the closest k.",
              legend: LEG,
              codeLine: 6,
            });
          }
          out.push({
            title: `Closest ${k}: ${show(a.slice(left, right + 1))}`,
            tracks: [track("sorted values", a, a.map((v, i) => (i >= left && i <= right ? "result" : "dim")))],
            counters: [count("window size", right - left + 1, k), count("answer", show(a.slice(left, right + 1)))],
            happened: `The surviving window contains exactly ${k} values.`,
            why: "Every discarded edge was farther from the target than the edge that stayed.",
            legend: LEG,
            codeLine: 9,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "guess-number-higher-or-lower",
    title: "Guess Number Higher Or Lower",
    category: "Binary Search",
    difficulty: "Beginner",
    description: "Halve the possible range after each higher/lower hint.",
    input: { label: "n | hidden guess (for the demo)", default: "10 | 6", parse: "tworows" },
    approaches: [
      {
        name: "Binary Search the Range",
        complexity: "O(log n) guesses, O(1) space",
        idea: [
          "The allowed numbers form a sorted range 1..n. Guess the midpoint.",
          "A lower hint means the answer is below the midpoint; a higher hint means it is above. Move the matching boundary and repeat.",
        ],
        problem: ["Each guess narrows the interval by about half, but the hidden number is known here only to drive the demonstration."],
        code: {
          c: `int guessNumber(int n) {
    int lo = 1, hi = n;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        int hint = guess(mid);
        if (hint == 0) return mid;
        if (hint < 0) hi = mid - 1;
        else lo = mid + 1;
    }
    return -1;
}`,
          cpp: `int guessNumber(int n) {
    int lo = 1, hi = n;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        int hint = guess(mid);
        if (hint == 0) return mid;
        if (hint < 0) hi = mid - 1;
        else lo = mid + 1;
    }
    return -1;
}`,
        },
        steps(parsed) {
          const n = Math.max(1, (parsed[0] || [1])[0] || 1);
          const answer = Math.min(Math.max((parsed[1] || [1])[0] || 1, 1), n);
          const out = [];
          let lo = 1, hi = n;
          out.push({
            title: `Search 1 through ${n}`,
            tracks: [chips("possible range", [lo + ".." + hi], "idle")],
            counters: [count("low", lo), count("high", hi)],
            happened: `The hidden number is between 1 and ${n}.`,
            why: "A sorted range with a comparison hint is the classic binary-search setup.",
            legend: LEG,
            codeLine: 2,
          });
          while (lo <= hi) {
            const mid = Math.floor((lo + hi) / 2);
            const hint = mid === answer ? 0 : mid < answer ? 1 : -1;
            out.push({
              title: `Guess ${mid}`,
              tracks: [chips("possible range", [lo + ".." + hi], "active")],
              counters: [count("guess", mid), count("remaining", hi - lo + 1)],
              happened: hint === 0 ? "The guess matches the hidden number." : hint > 0 ? "The hidden number is higher." : "The hidden number is lower.",
              why: "The midpoint splits the remaining range into two almost equal parts.",
              legend: LEG,
              codeLine: 4,
            });
            if (hint === 0) {
              out.push({
                title: `Found ${mid}`,
                tracks: [chips("answer", [mid], "result")],
                counters: [count("answer", mid), count("remaining", 1)],
                happened: `The hidden number is ${mid}.`,
                why: "A zero hint identifies the answer immediately.",
                legend: LEG,
                codeLine: 6,
              });
              return out;
            }
            if (hint < 0) hi = mid - 1;
            else lo = mid + 1;
            out.push({
              title: `Keep ${lo}..${hi}`,
              tracks: [chips("possible range", [lo <= hi ? lo + ".." + hi : "empty"], "read")],
              counters: [count("low", lo), count("high", hi)],
              happened: `The impossible half is discarded, leaving ${lo <= hi ? lo + ".." + hi : "nothing"}.`,
              why: "One comparison removes about half of the candidates.",
              legend: LEG,
              codeLine: hint < 0 ? 7 : 8,
            });
          }
          out.push({
            title: "No number matched",
            tracks: [chips("answer", ["-1"], "bad")],
            counters: [count("answer", -1)],
            happened: "The range became empty without a match.",
            why: "An empty range means the hidden value was outside the promised bounds.",
            legend: LEG,
            codeLine: 10,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "sqrtx",
    title: "Sqrt(x)",
    category: "Binary Search",
    difficulty: "Beginner",
    description: "Find the integer square root by searching the answer space.",
    input: { label: "Non-negative integer", default: "8", parse: "int" },
    approaches: [
      {
        name: "Binary Search the Root",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "The integer square root is the largest r with r * r <= x. Search r in 0..x.",
          "When mid * mid is too small, remember mid as a candidate and move right; when it is too large, move left.",
        ],
        problem: ["Using mid * mid can overflow in fixed-width languages if the bounds are large, so a division-based check may be safer."],
        code: {
          c: `int mySqrt(int x) {
    int lo = 0, hi = x, best = 0;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        long long sq = (long long)mid * mid;
        if (sq <= x) { best = mid; lo = mid + 1; }
        else hi = mid - 1;
    }
    return best;
}`,
          cpp: `int mySqrt(int x) {
    int lo = 0, hi = x, best = 0;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        long long sq = (long long)mid * mid;
        if (sq <= x) { best = mid; lo = mid + 1; }
        else hi = mid - 1;
    }
    return best;
}`,
        },
        steps(x) {
          const n = Math.max(0, x);
          const out = [];
          let lo = 0, hi = n, best = 0;
          out.push({
            title: `Search roots from 0 to ${n}`,
            tracks: [chips("range", ["0.." + n], "idle")],
            counters: [count("low", lo), count("high", hi), count("best", best)],
            happened: `We need the largest integer whose square is at most ${n}.`,
            why: "Squares grow monotonically, so the condition is true for a prefix of the candidate roots.",
            legend: LEG,
            codeLine: 2,
          });
          while (lo <= hi) {
            const mid = Math.floor((lo + hi) / 2);
            const sq = mid * mid;
            const ok = sq <= n;
            if (ok) best = mid;
            out.push({
              title: `Test ${mid}: ${mid} * ${mid} = ${sq}`,
              tracks: [chips("candidate roots", [lo + ".." + hi], "active"), chips("best so far", [best], "result")],
              counters: [count("square", sq), count("target", n), count("best", best)],
              happened: ok ? `${sq} fits, so ${mid} is feasible.` : `${sq} is too large.`,
              why: ok ? "The answer could be this root or a larger one." : "This root and every larger one are too big.",
              legend: LEG,
              codeLine: 5,
            });
            if (ok) lo = mid + 1;
            else hi = mid - 1;
          }
          out.push({
            title: `Integer square root is ${best}`,
            tracks: [chips("answer", [best], "result")],
            counters: [count("answer", best), count("square", best * best)],
            happened: `${best} * ${best} = ${best * best}, and the next integer is already too large.`,
            why: "The best feasible candidate is the floor of the real square root.",
            legend: LEG,
            codeLine: 8,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "search-in-rotated-sorted-array-ii",
    title: "Search In Rotated Sorted Array II",
    category: "Binary Search",
    difficulty: "Intermediate",
    description: "Search a rotated sorted array that may contain duplicates.",
    input: { label: "rotated numbers | target", default: "2, 5, 6, 0, 0, 1, 2 | 0", parse: "tworows" },
    approaches: [
      {
        name: "Binary Search with Duplicate Cleanup",
        complexity: "O(log n) average, O(n) worst case, O(1) space",
        idea: [
          "In a rotated sorted array, at least one half around mid is still sorted. Compare the target with that half to choose a side.",
          "Duplicates make the sorted half ambiguous when nums[lo] == nums[mid] == nums[hi]. In that case, shrink both ends by one and retry.",
        ],
        problem: ["All-equal values force many one-step shrinks, so the worst case is linear even though the loop looks like binary search."],
        code: {
          c: `#include <stdbool.h>

bool search(int* a, int n, int target) {
    int lo = 0, hi = n - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return true;
        if (a[lo] == a[mid] && a[mid] == a[hi]) { lo++; hi--; }
        else if (a[lo] <= a[mid]) {
            if (a[lo] <= target && target < a[mid]) hi = mid - 1;
            else lo = mid + 1;
        } else {
            if (a[mid] < target && target <= a[hi]) lo = mid + 1;
            else hi = mid - 1;
        }
    }
    return false;
}`,
          cpp: `#include <vector>
using namespace std;

bool search(vector<int>& a, int target) {
    int lo = 0, hi = (int)a.size() - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return true;
        if (a[lo] == a[mid] && a[mid] == a[hi]) { lo++; hi--; }
        else if (a[lo] <= a[mid]) {
            if (a[lo] <= target && target < a[mid]) hi = mid - 1;
            else lo = mid + 1;
        } else {
            if (a[mid] < target && target <= a[hi]) lo = mid + 1;
            else hi = mid - 1;
        }
    }
    return false;
}`,
        },
        steps(parsed) {
          const a = (parsed[0] || []).slice();
          const target = (parsed[1] || [0])[0];
          const out = [];
          let lo = 0, hi = a.length - 1;
          out.push({
            title: `Search for ${target}`,
            tracks: [track("rotated values", a, a.map((v, i) => (i === lo || i === hi ? "compare" : "idle")))],
            counters: [count("low", lo), count("high", hi)],
            happened: "The array is sorted and then rotated, possibly with repeated values.",
            why: "At least one side of the midpoint must remain sorted.",
            legend: LEG,
            codeLine: 3,
          });
          while (lo <= hi) {
            const mid = Math.floor((lo + hi) / 2);
            const states = a.map((v, i) => (i === mid ? "read" : i === lo || i === hi ? "compare" : "idle"));
            out.push({
              title: `Check midpoint ${mid}`,
              tracks: [track("rotated values", a, states)],
              counters: [count("low", lo), count("high", hi), count("mid", mid)],
              happened: a[mid] === target ? `${a[mid]} matches the target.` : `${a[mid]} is not the target.`,
              why: "The midpoint is the only new position inspected on this round.",
              legend: LEG,
              codeLine: 5,
            });
            if (a[mid] === target) {
              out.push({
                title: `Found ${target} at index ${mid}`,
                tracks: [track("rotated values", a, a.map((v, i) => (i === mid ? "result" : "idle")))],
                counters: [count("answer", "true"), count("index", mid)],
                happened: "The search can stop as soon as the target is seen.",
                why: "This version only asks whether the target exists.",
                legend: LEG,
                codeLine: 5,
              });
              return out;
            }
            if (a[lo] === a[mid] && a[mid] === a[hi]) {
              out.push({
                title: "All three edges are equal; shrink",
                tracks: [track("rotated values", a, a.map((v, i) => (i === lo || i === mid || i === hi ? "bad" : "idle")))],
                counters: [count("low", lo + 1), count("high", hi - 1)],
                happened: "The repeated edge values hide which side is sorted.",
                why: "Removing one equal value from each end cannot remove the only occurrence of the target, because the middle still equals them.",
                legend: LEG,
                codeLine: 7,
              });
              lo++;
              hi--;
            } else if (a[lo] <= a[mid]) {
              const inLeft = a[lo] <= target && target < a[mid];
              out.push({
                title: inLeft ? "Target belongs in the sorted left half" : "Target is not in the sorted left half",
                tracks: [track("rotated values", a, a.map((v, i) => (i >= lo && i <= mid ? "good" : "dim")))],
                counters: [count("sorted side", "left"), count("target", target)],
                happened: `The left half ${show(a.slice(lo, mid + 1))} is sorted.`,
                why: "If the target lies inside this sorted range, the other half can be discarded.",
                legend: LEG,
                codeLine: 9,
              });
              if (inLeft) hi = mid - 1;
              else lo = mid + 1;
            } else {
              const inRight = a[mid] < target && target <= a[hi];
              out.push({
                title: inRight ? "Target belongs in the sorted right half" : "Target is not in the sorted right half",
                tracks: [track("rotated values", a, a.map((v, i) => (i >= mid && i <= hi ? "good" : "dim")))],
                counters: [count("sorted side", "right"), count("target", target)],
                happened: `The right half ${show(a.slice(mid, hi + 1))} is sorted.`,
                why: "The sorted side gives a reliable range test for the target.",
                legend: LEG,
                codeLine: 12,
              });
              if (inRight) lo = mid + 1;
              else hi = mid - 1;
            }
          }
          out.push({
            title: `${target} is not present`,
            tracks: [track("rotated values", a, fill(a.length, "dim"))],
            counters: [count("answer", "false")],
            happened: "The search interval became empty.",
            why: "Every possible sorted side was ruled out.",
            legend: LEG,
            codeLine: 17,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "time-based-key-value-store",
    title: "Time Based Key-Value Store",
    category: "Binary Search",
    difficulty: "Intermediate",
    description: "Return the newest value for a key at or before a timestamp.",
    input: { label: "Operations", default: "set foo 1 1 set foo 4 2 get foo 3", parse: "words" },
    approaches: [
      {
        name: "Per-Key Timestamp Lists",
        complexity: "O(1) set, O(log n) get, O(total operations) space",
        idea: [
          "Every key keeps two parallel lists: timestamps and values. Sets arrive in increasing time order, so each new timestamp is appended.",
          "A get binary-searches the timestamp list for the rightmost time not after the requested time, then returns the matching value.",
        ],
        problem: ["Values for many keys and times consume memory proportional to the number of set operations."],
        code: {
          c: `#include <stdlib.h>
#include <string.h>

typedef struct { int time; char value[64]; } Version;

void set(Version* list, int* n, int time, const char* value) {
    list[*n].time = time;
    strcpy(list[*n].value, value);
    (*n)++;
}

const char* get(Version* list, int n, int time) {
    int lo = 0, hi = n - 1, found = -1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (list[mid].time <= time) { found = mid; lo = mid + 1; }
        else hi = mid - 1;
    }
    return found < 0 ? "" : list[found].value;
}`,
          cpp: `#include <map>
#include <string>
#include <vector>
using namespace std;

class TimeMap {
    map<string, vector<pair<int, string>>> data;
public:
    void set(string key, string value, int time) {
        data[key].push_back({time, value});
    }
    string get(string key, int time) {
        auto it = data.find(key);
        if (it == data.end()) return "";
        auto& v = it->second;
        int lo = 0, hi = (int)v.size() - 1, found = -1;
        while (lo <= hi) {
            int mid = lo + (hi - lo) / 2;
            if (v[mid].first <= time) { found = mid; lo = mid + 1; }
            else hi = mid - 1;
        }
        return found < 0 ? "" : v[found].second;
    }
};`,
        },
        steps(tokens) {
          const ops = tokens.slice();
          const store = new Map();
          const out = [];
          out.push({
            title: "Keep an ordered history for each key",
            tracks: [chips("operations", ops, "idle")],
            counters: [count("operations", ops.length)],
            happened: "Set operations append a timestamp; get operations search backward by time.",
            why: "Timestamps are increasing, so each key's history is already sorted.",
            legend: LEG,
            codeLine: 2,
          });
          let i = 0;
          while (i < ops.length) {
            const op = String(ops[i]).toLowerCase();
            if (op === "set" && i + 3 < ops.length) {
              const key = ops[i + 1];
              const time = parseInt(ops[i + 2], 10);
              const value = ops[i + 3];
              if (!store.has(key)) store.set(key, []);
              store.get(key).push([time, value]);
              out.push({
                title: `set ${key} = ${value} at time ${time}`,
                tracks: [chips("operations", ops, (k) => (k >= i && k <= i + 3 ? "done" : "idle")), chips("history for " + key, store.get(key).map((p) => p[0] + ":" + p[1]), "active")],
                counters: [count("versions for key", store.get(key).length), count("time", time)],
                happened: `The version list for ${key} grew to ${store.get(key).length} entries.`,
                why: "Appending keeps the timestamps sorted without any later reordering.",
                legend: LEG,
                codeLine: 5,
              });
              i += 4;
            } else if (op === "get" && i + 2 < ops.length) {
              const key = ops[i + 1];
              const time = parseInt(ops[i + 2], 10);
              const list = store.get(key) || [];
              let lo = 0, hi = list.length - 1, found = -1;
              while (lo <= hi) {
                const mid = Math.floor((lo + hi) / 2);
                if (list[mid][0] <= time) { found = mid; lo = mid + 1; }
                else hi = mid - 1;
              }
              const value = found >= 0 ? list[found][1] : "";
              out.push({
                title: `get ${key} at time ${time} gives "${value}"`,
                tracks: [chips("operations", ops, (k) => (k >= i && k <= i + 2 ? "read" : "idle")), chips("history for " + key, list.map((p, k) => p[0] + ":" + p[1] + (k === found ? " <-" : "")), found >= 0 ? "result" : "bad")],
                counters: [count("versions checked", list.length), count("answer", value || "(none)")],
                happened: found >= 0 ? `The newest timestamp not after ${time} is ${list[found][0]}.` : `No version of ${key} exists at or before ${time}.`,
                why: "Binary search finds the boundary between usable and future versions.",
                legend: LEG,
                codeLine: 15,
              });
              i += 3;
            } else {
              i++;
            }
          }
          out.push({
            title: "All operations processed",
            tracks: [chips("keys", [...store.keys()], "result")],
            counters: [count("keys", store.size), count("operations", ops.length)],
            happened: `The store now has histories for ${store.size} key(s).`,
            why: "Every get used the same new set operations to keep its answer consistent.",
            legend: LEG,
            codeLine: 18,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-in-mountain-array",
    title: "Find in Mountain Array",
    category: "Binary Search",
    difficulty: "Advanced",
    description: "Locate a target by first finding the peak of a mountain array.",
    input: { label: "mountain values | target", default: "1, 2, 3, 4, 5, 3, 1 | 3", parse: "tworows" },
    approaches: [
      {
        name: "Peak Then Two Searches",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "A mountain array rises to a peak and then falls. Find the peak by comparing mid with mid + 1.",
          "The left slope is increasing, so it supports normal binary search. The right slope is decreasing, so its comparison is reversed.",
        ],
        problem: ["Three binary searches are needed: one for the peak and one on each side."],
        code: {
          c: `int peak(int* a, int n) {
    int lo = 0, hi = n - 1;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < a[mid + 1]) lo = mid + 1;
        else hi = mid;
    }
    return lo;
}

int searchMountain(int* a, int n, int target) {
    int p = peak(a, n);
    int lo = 0, hi = p;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    lo = p + 1; hi = n - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] > target) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}`,
          cpp: `#include <vector>
using namespace std;

int peak(vector<int>& a) {
    int lo = 0, hi = (int)a.size() - 1;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < a[mid + 1]) lo = mid + 1;
        else hi = mid;
    }
    return lo;
}

int searchMountain(vector<int>& a, int target) {
    int p = peak(a), n = a.size();
    int lo = 0, hi = p;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    lo = p + 1; hi = n - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] > target) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}`,
        },
        steps(parsed) {
          const a = (parsed[0] || []).slice();
          const target = (parsed[1] || [0])[0];
          const out = [];
          let lo = 0, hi = a.length - 1;
          out.push({
            title: `Find the peak before searching`,
            tracks: [track("mountain", a, a.map((v, i) => (i === 0 || i === a.length - 1 ? "compare" : "idle")))],
            counters: [count("low", lo), count("high", hi)],
            happened: `The target is ${target}; the array rises and then falls.`,
            why: "Splitting at the peak turns the two slopes into separate sorted arrays.",
            legend: LEG,
            codeLine: 2,
          });
          while (lo < hi) {
            const mid = Math.floor((lo + hi) / 2);
            const rising = a[mid] < a[mid + 1];
            out.push({
              title: rising ? `${a[mid]} < ${a[mid + 1]}; peak is to the right` : `${a[mid]} >= ${a[mid + 1]}; peak is here or left`,
              tracks: [track("mountain", a, a.map((v, i) => (i === mid || i === mid + 1 ? "compare" : "idle")))],
              counters: [count("low", lo), count("high", hi), count("mid", mid)],
              happened: "Adjacent values reveal which side of the peak the midpoint lies on.",
              why: "An increasing pair means the peak has not been reached yet.",
              legend: LEG,
              codeLine: 5,
            });
            if (rising) lo = mid + 1;
            else hi = mid;
          }
          const peak = lo;
          out.push({
            title: `Peak is ${a[peak]} at index ${peak}`,
            tracks: [track("mountain", a, a.map((v, i) => (i === peak ? "result" : "idle")))],
            counters: [count("peak", a[peak]), count("peak index", peak)],
            happened: "The pointer converged on the highest value.",
            why: "The left slope is now fully increasing and the right slope fully decreasing.",
            legend: LEG,
            codeLine: 8,
          });
          let leftLo = 0, leftHi = peak;
          while (leftLo <= leftHi) {
            const mid = Math.floor((leftLo + leftHi) / 2);
            out.push({
              title: `Left search checks ${a[mid]}`,
              tracks: [track("increasing side", a, a.map((v, i) => (i === mid ? "read" : i >= leftLo && i <= leftHi ? "compare" : "dim")))],
              counters: [count("left low", leftLo), count("left high", leftHi)],
              happened: a[mid] === target ? "The target is on the increasing side." : a[mid] < target ? "Move right on the increasing slope." : "Move left on the increasing slope.",
              why: "The left side behaves like a normal sorted array.",
              legend: LEG,
              codeLine: 14,
            });
            if (a[mid] === target) {
              out.push({
                title: `Found ${target} at index ${mid}`,
                tracks: [track("mountain", a, a.map((v, i) => (i === mid ? "result" : "dim")))],
                counters: [count("answer", mid)],
                happened: "The target was found during the increasing-side search.",
                why: "No search of the decreasing side is needed.",
                legend: LEG,
                codeLine: 14,
              });
              return out;
            }
            if (a[mid] < target) leftLo = mid + 1;
            else leftHi = mid - 1;
          }
          let rightLo = peak + 1, rightHi = a.length - 1;
          while (rightLo <= rightHi) {
            const mid = Math.floor((rightLo + rightHi) / 2);
            out.push({
              title: `Right search checks ${a[mid]}`,
              tracks: [track("decreasing side", a, a.map((v, i) => (i === mid ? "read" : i >= rightLo && i <= rightHi ? "compare" : "dim")))],
              counters: [count("right low", rightLo), count("right high", rightHi)],
              happened: a[mid] === target ? "The target is on the decreasing side." : a[mid] > target ? "Move right on the decreasing slope." : "Move left on the decreasing slope.",
              why: "The comparison is reversed because values fall as the index grows.",
              legend: LEG,
              codeLine: 21,
            });
            if (a[mid] === target) {
              out.push({
                title: `Found ${target} at index ${mid}`,
                tracks: [track("mountain", a, a.map((v, i) => (i === mid ? "result" : "dim")))],
                counters: [count("answer", mid)],
                happened: "The target was found during the decreasing-side search.",
                why: "This is the only remaining place the target could be.",
                legend: LEG,
                codeLine: 21,
              });
              return out;
            }
            if (a[mid] > target) rightLo = mid + 1;
            else rightHi = mid - 1;
          }
          out.push({
            title: `${target} is not in the mountain`,
            tracks: [track("mountain", a, fill(a.length, "dim"))],
            counters: [count("answer", -1)],
            happened: "Both slopes were searched without a match.",
            why: "Every index belongs to exactly one slope.",
            legend: LEG,
            codeLine: 25,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-duplicate-integer",
    title: "Find The Duplicate Number",
    category: "Linked List",
    difficulty: "Intermediate",
    description: "Treat array values as next pointers and use cycle detection.",
    input: { label: "Numbers (values 1..n)", default: "1, 3, 4, 2, 2", parse: "ints" },
    approaches: [
      {
        name: "Floyd's Tortoise and Hare",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Index i points to value nums[i], so the array describes a functional graph. A repeated value creates a cycle.",
          "Move a slow pointer one step and a fast pointer two steps until they meet. Then reset one pointer to the start and advance both one step at a time; they meet at the cycle entrance, which is the duplicate.",
        ],
        problem: ["The input is not modified, but the method assumes values are valid indices and that exactly one duplicate exists."],
        code: {
          c: `int findDuplicate(int* nums, int n) {
    int slow = nums[0], fast = nums[0];
    do {
        slow = nums[slow];
        fast = nums[nums[fast]];
    } while (slow != fast);
    slow = nums[0];
    while (slow != fast) {
        slow = nums[slow];
        fast = nums[fast];
    }
    return slow;
}`,
          cpp: `#include <vector>
using namespace std;

int findDuplicate(vector<int>& nums) {
    int slow = nums[0], fast = nums[0];
    do {
        slow = nums[slow];
        fast = nums[nums[fast]];
    } while (slow != fast);
    slow = nums[0];
    while (slow != fast) {
        slow = nums[slow];
        fast = nums[fast];
    }
    return slow;
}`,
        },
        steps(nums) {
          const a = nums.slice();
          const out = [];
          if (!a.length) return [{ title: "No values", tracks: [track("numbers", ["-"], ["idle"])], counters: [count("answer", "none")], happened: "The array is empty.", why: "No duplicate can exist.", legend: LEG }];
          let slow = a[0], fast = a[0];
          out.push({
            title: "Interpret each value as a next index",
            tracks: [track("numbers", a, a.map((v, i) => (i === 0 ? "compare" : "idle")))],
            counters: [count("slow", slow), count("fast", fast)],
            happened: "Both pointers start at nums[0].",
            why: "A repeated value gives two indices the same outgoing pointer, which forms a cycle.",
            legend: LEG,
            codeLine: 4,
          });
          let guard = 0;
          do {
            slow = a[slow];
            fast = a[a[fast]];
            guard++;
            out.push({
              title: "Slow takes one step, fast takes two",
              tracks: [track("numbers", a, a.map((v, i) => (i === slow || i === fast ? "read" : "idle")))],
              counters: [count("slow", slow), count("fast", fast), count("rounds", guard)],
              happened: `The pointers are now at indices ${slow} and ${fast}.`,
              why: "Inside a cycle the fast pointer gains one position per round on the slow pointer.",
              legend: LEG,
              codeLine: 6,
            });
          } while (slow !== fast && guard < a.length + 2);
          out.push({
            title: `Pointers meet at ${slow}`,
            tracks: [track("numbers", a, a.map((v, i) => (i === slow ? "result" : "idle")))],
            counters: [count("meeting value", slow), count("rounds", guard)],
            happened: "The cycle has been detected.",
            why: "The meeting point is inside the cycle, not necessarily at its entrance.",
            legend: LEG,
            codeLine: 7,
          });
          slow = a[0];
          out.push({
            title: "Reset one pointer to the start",
            tracks: [track("numbers", a, a.map((v, i) => (i === 0 ? "compare" : i === fast ? "read" : "idle")))],
            counters: [count("slow", slow), count("fast", fast)],
            happened: "Now both pointers move one step at a time.",
            why: "The distance from the start to the cycle entrance equals the distance from the meeting point to the entrance.",
            legend: LEG,
            codeLine: 9,
          });
          guard = 0;
          while (slow !== fast && guard < a.length + 2) {
            slow = a[slow];
            fast = a[fast];
            guard++;
            out.push({
              title: `Advance both: ${slow} and ${fast}`,
              tracks: [track("numbers", a, a.map((v, i) => (i === slow || i === fast ? "read" : "idle")))],
              counters: [count("slow", slow), count("fast", fast), count("rounds", guard)],
              happened: `The pointers moved to ${slow} and ${fast}.`,
              why: "They will meet exactly at the first repeated value.",
              legend: LEG,
              codeLine: 11,
            });
          }
          out.push({
            title: `Duplicate is ${slow}`,
            tracks: [track("numbers", a, a.map((v, i) => (i === slow ? "result" : "idle")))],
            counters: [count("answer", slow), count("rounds", guard)],
            happened: "The two pointers now point at the cycle entrance.",
            why: "That entrance value is the number that appears more than once.",
            legend: LEG,
            codeLine: 13,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "baseball-game",
    title: "Baseball Game",
    category: "Stack",
    difficulty: "Beginner",
    description: "Evaluate a list of score operations with a stack.",
    input: { label: "Operations", default: "5 2 C D +", parse: "tokens" },
    approaches: [
      {
        name: "Stack the Scores",
        complexity: "O(n) time, O(n) space",
        idea: [
          "A number pushes a new score. C removes the last score, D pushes twice the last score, and + pushes the sum of the last two scores.",
          "All three special operations only depend on the end of the history, which makes a stack the natural container.",
        ],
        problem: ["The stack can keep every score until the end, so memory grows with the number of operations."],
        code: {
          c: `#include <stdlib.h>
#include <string.h>

int calPoints(char** ops, int n) {
    int* st = malloc(n * sizeof(int));
    int top = 0;
    for (int i = 0; i < n; i++) {
        if (!strcmp(ops[i], "C")) top--;
        else if (!strcmp(ops[i], "D")) st[top] = 2 * st[top - 1], top++;
        else if (!strcmp(ops[i], "+")) st[top] = st[top - 1] + st[top - 2], top++;
        else st[top++] = atoi(ops[i]);
    }
    int sum = 0;
    for (int i = 0; i < top; i++) sum += st[i];
    free(st);
    return sum;
}`,
          cpp: `#include <numeric>
#include <string>
#include <vector>
using namespace std;

int calPoints(vector<string>& ops) {
    vector<int> st;
    for (const string& op : ops) {
        if (op == "C") st.pop_back();
        else if (op == "D") st.push_back(2 * st.back());
        else if (op == "+") st.push_back(st.back() + st[st.size() - 2]);
        else st.push_back(stoi(op));
    }
    return accumulate(st.begin(), st.end(), 0);
}`,
        },
        steps(ops) {
          const st = [];
          const out = [];
          out.push({
            title: "Start with an empty score stack",
            tracks: [chips("operations", ops, "idle"), chips("stack", [], "idle")],
            counters: [count("score", 0), count("stack size", 0)],
            happened: "Each operation reads only the top one or two scores.",
            why: "A stack gives constant-time access to the most recent scores.",
            legend: LEG,
            codeLine: 4,
          });
          for (let i = 0; i < ops.length; i++) {
            const op = String(ops[i]);
            let title = "";
            if (op === "C") {
              const removed = st.pop();
              title = `C removes ${removed}`;
            } else if (op === "D") {
              const v = 2 * (st[st.length - 1] ?? 0);
              st.push(v);
              title = `D pushes double the last score (${v})`;
            } else if (op === "+") {
              const v = (st[st.length - 1] ?? 0) + (st[st.length - 2] ?? 0);
              st.push(v);
              title = `+ pushes the top two sum (${v})`;
            } else {
              const v = parseInt(op, 10);
              if (Number.isFinite(v)) {
                st.push(v);
                title = `Push score ${v}`;
              } else {
                title = `Skip unknown operation ${op}`;
              }
            }
            out.push({
              title,
              tracks: [chips("operations", ops, (k) => (k === i ? "read" : k < i ? "done" : "idle")), chips("stack", st, "active")],
              counters: [count("stack size", st.length), count("score", st.reduce((s, x) => s + x, 0))],
              happened: st.length ? `The stack now holds ${show(st)}.` : "The stack is empty.",
              why: "The operation only changed the recent end of the history.",
              legend: LEG,
              codeLine: op === "C" ? 7 : op === "D" ? 8 : op === "+" ? 9 : 10,
            });
          }
          out.push({
            title: `Total score is ${st.reduce((s, x) => s + x, 0)}`,
            tracks: [chips("operations", ops, "done"), chips("final scores", st, "result")],
            counters: [count("score", st.reduce((s, x) => s + x, 0)), count("scores kept", st.length)],
            happened: `Adding the remaining stack ${show(st)} gives the answer.`,
            why: "Cancelled and combined scores are already represented by the final stack.",
            legend: LEG,
            codeLine: 12,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "car-fleet",
    title: "Car Fleet",
    category: "Stack",
    difficulty: "Intermediate",
    description: "Count how many car groups arrive at a target without passing each other.",
    input: { label: "target | positions | speeds", default: "12 | 10,8,0,5 | 0,4,5,8", parse: "string" },
    approaches: [
      {
        name: "Sort by Position and Track Arrival Times",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "A car's arrival time is (target - position) / speed. Process cars from closest to the target backward.",
          "If a car's arrival time is greater than the fleet ahead of it, it cannot catch that fleet and starts a new fleet. Otherwise it joins the fleet and is hidden behind it.",
        ],
        problem: ["Floating-point times can be avoided by comparing fractions, but the concept is the same."],
        code: {
          c: `#include <stdlib.h>

typedef struct { int pos, speed; } Car;
int cmp(const void* a, const void* b) {
    return ((Car*)b)->pos - ((Car*)a)->pos;
}

int carFleet(int target, int* position, int* speed, int n) {
    Car* cars = malloc(n * sizeof(Car));
    for (int i = 0; i < n; i++) cars[i] = (Car){position[i], speed[i]};
    qsort(cars, n, sizeof(Car), cmp);
    int fleets = 0;
    double slowest = 0;
    for (int i = 0; i < n; i++) {
        double t = (double)(target - cars[i].pos) / cars[i].speed;
        if (t > slowest) { fleets++; slowest = t; }
    }
    free(cars);
    return fleets;
}`,
          cpp: `#include <algorithm>
#include <vector>
using namespace std;

int carFleet(int target, vector<int>& position, vector<int>& speed) {
    vector<pair<int, int>> cars;
    for (int i = 0; i < (int)position.size(); i++) cars.push_back({position[i], speed[i]});
    sort(cars.rbegin(), cars.rend());
    int fleets = 0;
    double slowest = 0;
    for (auto& c : cars) {
        double t = (double)(target - c.first) / c.second;
        if (t > slowest) { fleets++; slowest = t; }
    }
    return fleets;
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((p) => p.trim());
          const target = parseInt(parts[0], 10) || 12;
          const pos = (parts[1] || "").split(/[\s,;]+/).filter(Boolean).map(Number).filter(Number.isFinite);
          const spd = (parts[2] || "").split(/[\s,;]+/).filter(Boolean).map(Number).filter(Number.isFinite);
          const cars = pos.map((p, i) => ({ p, s: spd[i] || 1 })).sort((a, b) => b.p - a.p);
          const out = [];
          let fleets = 0, slowest = 0;
          out.push({
            title: "Sort cars from closest to farthest",
            tracks: [chips("positions", cars.map((c) => c.p), "idle"), chips("speeds", cars.map((c) => c.s), "idle")],
            counters: [count("target", target), count("cars", cars.length)],
            happened: `The target is at ${target}; the nearest car is at ${cars[0]?.p ?? "-"}.`,
            why: "A car can only be blocked by a car that starts ahead of it.",
            legend: LEG,
            codeLine: 4,
          });
          for (let i = 0; i < cars.length; i++) {
            const c = cars[i];
            const time = (target - c.p) / c.s;
            const newFleet = time > slowest + 1e-9;
            if (newFleet) { fleets++; slowest = time; }
            out.push({
              title: newFleet ? `Car at ${c.p} starts a new fleet` : `Car at ${c.p} joins the fleet ahead`,
              tracks: [chips("cars (near to far)", cars.map((x) => `${x.p}@${x.s}`), (k) => (k === i ? "read" : k < i ? "done" : "idle")), chips("fleet times", [slowest.toFixed(2)], "result")],
              counters: [count("arrival time", time.toFixed(2)), count("fleets", fleets)],
              happened: `Arrival time is ${time.toFixed(2)}; the fleet ahead needs ${slowest.toFixed(2)}.`,
              why: newFleet ? "This car is slower, so it cannot catch the fleet ahead." : "This car would catch the fleet ahead and then move at its speed.",
              legend: LEG,
              codeLine: 9,
            });
          }
          out.push({
            title: `${fleets} fleet(s) reach the target`,
            tracks: [chips("positions", cars.map((c) => c.p), "done"), chips("answer", [fleets], "result")],
            counters: [count("fleets", fleets), count("cars", cars.length)],
            happened: `The cars form ${fleets} arrival group(s).`,
            why: "A new fleet is counted only when a car is slower than every fleet already ahead of it.",
            legend: LEG,
            codeLine: 11,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-frequency-stack",
    title: "Maximum Frequency Stack",
    category: "Stack",
    difficulty: "Advanced",
    description: "Pop the value that currently occurs most often, breaking ties by recency.",
    input: { label: "Operations", default: "push 5 push 7 push 5 push 7 push 4 pop pop pop pop", parse: "words" },
    approaches: [
      {
        name: "Frequency Buckets",
        complexity: "O(1) push and pop, O(n) space",
        idea: [
          "Store how many times each value has appeared. Also keep a stack for each frequency: when a value reaches frequency f, append it to bucket f.",
          "To pop, take the top of the highest non-empty bucket. That value is both most frequent and, among ties, the most recently pushed.",
        ],
        problem: ["A map of stacks can hold one reference per push, so the extra memory is linear in the number of operations."],
        code: {
          c: `#include <stdlib.h>

typedef struct { int value, freq; } Item;
typedef struct { Item* data; int size; } Stack;

void push(Stack* buckets, int* freq, int* maxf, int value) {
    freq[value]++;
    if (freq[value] > *maxf) *maxf = freq[value];
    buckets[freq[value]].data[buckets[freq[value]].size++] = (Item){value, freq[value]};
}

int pop(Stack* buckets, int* freq, int* maxf) {
    Stack* s = &buckets[*maxf];
    Item it = s->data[--s->size];
    freq[it.value]--;
    if (s->size == 0) (*maxf)--;
    return it.value;
}`,
          cpp: `#include <stack>
#include <unordered_map>
using namespace std;

class FreqStack {
    unordered_map<int, int> freq;
    unordered_map<int, stack<int>> groups;
    int maxf = 0;
public:
    void push(int value) {
        int f = ++freq[value];
        maxf = max(maxf, f);
        groups[f].push(value);
    }
    int pop() {
        int value = groups[maxf].top();
        groups[maxf].pop();
        freq[value]--;
        if (groups[maxf].empty()) maxf--;
        return value;
    }
};`,
        },
        steps(ops) {
          const freq = new Map();
          const groups = new Map();
          const out = [];
          let maxf = 0;
          out.push({
            title: "One bucket per frequency",
            tracks: [chips("operations", ops, "idle"), chips("frequency buckets", [], "idle")],
            counters: [count("max frequency", 0), count("pushes", 0)],
            happened: "Bucket f will hold values that have appeared exactly f times.",
            why: "The highest-frequency bucket is always the source of the next pop.",
            legend: LEG,
            codeLine: 2,
          });
          let i = 0;
          while (i < ops.length) {
            const op = String(ops[i]).toLowerCase();
            if (op === "push" && i + 1 < ops.length) {
              const v = parseInt(ops[i + 1], 10);
              if (Number.isFinite(v)) {
                const f = (freq.get(v) || 0) + 1;
                freq.set(v, f);
                maxf = Math.max(maxf, f);
                if (!groups.has(f)) groups.set(f, []);
                groups.get(f).push(v);
              }
              out.push({
                title: `Push ${ops[i + 1]}`,
                tracks: [chips("operations", ops, (k) => (k >= i && k <= i + 1 ? "read" : k < i ? "done" : "idle")), chips("frequency buckets", [...groups.entries()].map(([f, arr]) => f + ": " + show(arr)), "active")],
                counters: [count("max frequency", maxf), count("distinct values", freq.size)],
                happened: `The value now has frequency ${freq.get(Number(ops[i + 1])) || 0}.`,
                why: "The new occurrence is placed in its new frequency bucket.",
                legend: LEG,
                codeLine: 6,
              });
              i += 2;
            } else if (op === "pop") {
              const bucket = groups.get(maxf) || [];
              const v = bucket.pop();
              if (v != null) {
                const f = (freq.get(v) || 1) - 1;
                if (f > 0) freq.set(v, f);
                else freq.delete(v);
                if (bucket.length === 0) maxf--;
              }
              out.push({
                title: `Pop ${v == null ? "nothing" : v}`,
                tracks: [chips("operations", ops, (k) => (k === i ? "read" : k < i ? "done" : "idle")), chips("frequency buckets", [...groups.entries()].filter(([, arr]) => arr.length).map(([f, arr]) => f + ": " + show(arr)), "result")],
                counters: [count("max frequency", maxf), count("popped", v == null ? "none" : v)],
                happened: v == null ? "There was nothing to pop." : `${v} came from the highest non-empty bucket.`,
                why: "Recency within a bucket is preserved by the stack order.",
                legend: LEG,
                codeLine: 12,
              });
              i++;
            } else {
              i++;
            }
          }
          out.push({
            title: "Operations complete",
            tracks: [chips("frequency buckets", [...groups.entries()].filter(([, arr]) => arr.length).map(([f, arr]) => f + ": " + show(arr)), "done")],
            counters: [count("max frequency", maxf), count("distinct values", freq.size)],
            happened: `The remaining buckets are shown above.`,
            why: "The frequency and recency rules are both encoded by the bucket structure.",
            legend: LEG,
            codeLine: 14,
          });
          return out;
        },
      },
    ],
  });
})();
