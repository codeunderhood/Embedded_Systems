/* ============================================================
   DSA Visuals — Dynamic Programming II
   Subset sum, target sum, rod cutting, decoding, word break,
   perfect squares and ordered combination counting.
   ============================================================ */
(function () {
  "use strict";
  const { count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const partsOf = (text) => String(text || "").split("|").map((p) => p.trim());
  const intsOf = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number).filter(Number.isFinite);
  const show = (a) => `[${a.join(", ")}]`;

  /* ---------------------------------------------------------- */
  V.register({
    id: "partition-equal-subset-sum",
    title: "Partition Equal Subset Sum",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Decide whether the numbers can be split into two groups with equal totals.",
    input: { label: "Numbers", default: "1,5,11,5", parse: "string" },
    approaches: [
      {
        name: "Subset Sum to Half the Total",
        complexity: "O(numbers × half total) time",
        idea: [
          "If the total is odd, equal halves are impossible. Otherwise the question becomes: is there a subset summing to exactly half the total?",
          "dp[s] records whether some subset reaches sum s. Each number is considered once, and sums are updated downward so the same number cannot be used twice.",
        ],
        problem: [
          "Trying every partition is exponential; the reachable sums form a compact boolean table.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <stdbool.h>\\n\\nint main(void) {\\n    int a[] = {1,5,11,5}, n = 4, total = 22;\\n    if (total % 2) { printf(\\\"false\\\\n\\\"); return 0; }\\n    int target = total / 2;\\n    bool dp[23] = {true};\\n\\n    for (int i = 0; i < n; i++)\\n        for (int s = target; s >= a[i]; s--)\\n            if (dp[s - a[i]]) dp[s] = true;\\n\\n    printf(\\\"%s\\\\n\\\", dp[target] ? \\\"true\\\" : \\\"false\\\"); /* true */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <numeric>\\n#include <vector>\\nusing namespace std;\\n\\nbool canPartition(vector<int>& nums) {\\n    int total = accumulate(nums.begin(), nums.end(), 0);\\n    if (total & 1) return false;\\n    int target = total / 2;\\n    vector<bool> dp(target + 1, false);\\n    dp[0] = true;\\n    for (int x : nums)\\n        for (int s = target; s >= x; s--)\\n            if (dp[s - x]) dp[s] = true;\\n    return dp[target];\\n}\\n\\nint main() {\\n    vector<int> a{1,5,11,5};\\n    cout << (canPartition(a) ? \\\"true\\\" : \\\"false\\\") << '\\\\n'; // true\\n}`,
        },
        steps(text) {
          const nums = intsOf(text).filter((x) => x > 0).slice(0, 12);
          const total = nums.reduce((a, b) => a + b, 0);
          const target = Math.floor(total / 2);
          if (!nums.length) return [{
            title: "Give at least one number",
            tracks: [chips("numbers", ["—"], "idle")],
            counters: [count("reachable", 0)],
            legend: LEG,
            happened: "There is nothing to partition.",
            why: "A partition needs a non-empty list.",
          }];
          const possible = total % 2 === 0 && target <= 60;
          const dp = Array((possible ? target : Math.min(target, 60)) + 1).fill(false);
          dp[0] = true;
          const steps = [];
          const mark = (cur) => (i) => (i === cur ? "read" : dp[i] ? "good" : "dim");
          steps.push({
            title: `Total ${total}, so each half would be ${total % 2 ? "impossible" : target}`,
            tracks: [
              chips("numbers", nums, "compare"),
              chips("sums", dp.map((b) => (b ? "✓" : "·")), (i) => (i === 0 ? "result" : "dim")),
            ],
            counters: [count("total", total), count("target", total % 2 ? -1 : target)],
            legend: LEG,
            happened: total % 2 ? "An odd total cannot be split into two equal integers." : "Only sum 0 is reachable before considering any number.",
            why: "The empty subset has sum 0; every other sum is unknown.",
            codeLine: 4,
          });
          if (!possible) {
            steps.push({
              title: "Answer: equal halves are impossible",
              tracks: [chips("sums", dp.map((b) => (b ? "✓" : "·")), "dim")],
              counters: [count("total", total), count("reachable", 0)],
              legend: LEG,
              happened: "The sum array is not even reachable as an integer target, or it is too large to display.",
              why: "An odd total, or an out-of-range table, ends the decision immediately.",
              codeLine: 5,
            });
            return steps;
          }
          nums.forEach((x, idx) => {
            for (let s = target; s >= x; s--) if (dp[s - x]) dp[s] = true;
            steps.push({
              title: `After number ${x}: sum ${target} is ${dp[target] ? "reachable" : "still impossible"}`,
              tracks: [chips("numbers", nums, (i) => (i === idx ? "active" : i < idx ? "done" : "idle")), chips("sums", dp.map((b) => (b ? "✓" : "·")), mark(target))],
              counters: [count("reachable sums", dp.filter(Boolean).length), count("number", idx + 1, nums.length)],
              legend: LEG,
              happened: `Sums reachable with the first ${idx + 1} numbers are marked ✓.`,
              why: "Updating sums downward lets this number extend older reachable sums without being reused.",
              codeLine: 9,
            });
          });
          steps.push({
            title: dp[target] ? `Answer: yes, a subset sums to ${target}` : `Answer: no subset sums to ${target}`,
            tracks: [chips("numbers", nums, "done"), chips("sums", dp.map((b) => (b ? "✓" : "·")), (i) => (i === target ? "result" : dp[i] ? "good" : "dim"))],
            counters: [count("target", target), count("reachable", dp[target] ? 1 : 0)],
            legend: LEG,
            happened: dp[target] ? `The half-total cell is reachable, so the remaining numbers form the other half.` : "The half-total cell was never reached.",
            why: "A subset adding to half the total leaves exactly the other half for the second group.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "target-sum",
    title: "Target Sum",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Count ways to assign + or − signs to numbers so the expression equals a target.",
    input: { label: "Numbers | target", default: "1,1,1,1,1 | 3", parse: "string" },
    approaches: [
      {
        name: "Count Subsets of the Positive Side",
        complexity: "O(numbers × capacity) time",
        idea: [
          "Let P be the numbers given a plus sign and N the rest. Then P − N = target and P + N = total, so P = (total + target) / 2.",
          "Counting sign assignments is therefore the same as counting subsets that sum to P. Each number is used at most once, so capacities are updated downward.",
        ],
        problem: [
          "Enumerating all 2ⁿ sign patterns is exponential even though many patterns reach the same running sum.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int a[] = {1,1,1,1,1}, n = 5, sum = 5, target = 3;\\n    if (sum < target || (sum + target) % 2) { printf(\\\"0\\\\n\\\"); return 0; }\\n    int cap = (sum + target) / 2;\\n    int dp[6] = {1,0,0,0,0,0};\\n\\n    for (int i = 0; i < n; i++)\\n        for (int s = cap; s >= a[i]; s--)\\n            dp[s] += dp[s - a[i]];\\n\\n    printf(\\\"%d\\\\n\\\", dp[cap]); /* 5 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <numeric>\\n#include <vector>\\nusing namespace std;\\n\\nint findTargetSumWays(vector<int>& nums, int target) {\\n    int sum = accumulate(nums.begin(), nums.end(), 0);\\n    if (sum < abs(target) || ((sum + target) & 1)) return 0;\\n    int cap = (sum + target) / 2;\\n    vector<int> dp(cap + 1, 0);\\n    dp[0] = 1;\\n    for (int x : nums)\\n        for (int s = cap; s >= x; s--)\\n            dp[s] += dp[s - x];\\n    return dp[cap];\\n}\\n\\nint main() {\\n    vector<int> a{1,1,1,1,1};\\n    cout << findTargetSumWays(a, 3) << '\\\\n'; // 5\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const nums = intsOf(parts[0]).filter((x) => x > 0).slice(0, 12);
          const target = parseInt(parts[1], 10) || 0;
          const sum = nums.reduce((a, b) => a + b, 0);
          const cap = (sum + target) / 2;
          const valid = nums.length > 0 && sum >= Math.abs(target) && (sum + target) % 2 === 0 && cap >= 0 && cap <= 60;
          if (!nums.length) return [{
            title: "Give numbers and a target",
            tracks: [chips("numbers", ["—"], "idle")],
            counters: [count("ways", 0)],
            legend: LEG,
            happened: "The input is empty.",
            why: "There are no signs to assign.",
          }];
          const steps = [];
          const dp = Array(valid ? cap + 1 : 1).fill(0);
          dp[0] = 1;
          steps.push({
            title: valid ? `Positive side must sum to ${cap}` : "The target cannot match these signs",
            tracks: [chips("numbers", nums, "compare"), chips("ways", dp, (i) => (i === 0 ? "result" : "dim"))],
            counters: [count("sum", sum), count("capacity", valid ? cap : -1)],
            legend: LEG,
            happened: valid ? "The plus-signed numbers must account for the positive balance." : "An impossible capacity ends the count.",
            why: "Writing P − N = target and P + N = sum fixes P to (sum + target) / 2.",
            codeLine: 4,
          });
          if (!valid) {
            steps.push({
              title: "Answer: 0 assignments",
              tracks: [chips("numbers", nums, "dim"), chips("ways", [0], "bad")],
              counters: [count("ways", 0), count("target", target)],
              legend: LEG,
              happened: "No sign assignment can create the requested target.",
              why: "The total is too small, or the positive balance is not a whole number.",
              codeLine: 5,
            });
            return steps;
          }
          nums.forEach((x, idx) => {
            for (let s = cap; s >= x; s--) dp[s] += dp[s - x];
            steps.push({
              title: `After number ${x}: ${dp[cap]} ways to reach ${cap}`,
              tracks: [chips("numbers", nums, (i) => (i === idx ? "active" : i < idx ? "done" : "idle")), chips("ways", dp, (i) => (i === cap ? "read" : dp[i] ? "done" : "dim"))],
              counters: [count("ways", dp[cap]), count("number", idx + 1, nums.length)],
              legend: LEG,
              happened: `Subsets summing to ${cap} are counted in the ways table.`,
              why: "Descending capacities ensure this occurrence of the number is not combined with itself.",
              codeLine: 9,
            });
          });
          steps.push({
            title: `Answer: ${dp[cap]} sign assignment${dp[cap] === 1 ? "" : "s"}`,
            tracks: [chips("numbers", nums, "done"), chips("ways", dp, (i) => (i === cap ? "result" : "done"))],
            counters: [count("ways", dp[cap]), count("target", target)],
            legend: LEG,
            happened: `Exactly ${dp[cap]} subsets supply the plus side, and each determines the minus side.`,
            why: "Every subset of sum P corresponds to one valid +/− pattern.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "rod-cutting",
    title: "Rod Cutting",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Cut a rod into pieces to maximise the total selling price.",
    input: { label: "Price for lengths 1..n", default: "1,5,8,9,10,17,17,20", parse: "string" },
    approaches: [
      {
        name: "Best Price per Length",
        complexity: "O(length²) time",
        idea: [
          "best[len] is the maximum revenue for a rod of length len. The first cut leaves a piece of length cut and a remaining rod of length len − cut.",
          "Trying every first cut and reusing the best revenue for the remainder covers every partition, because the remainder is solved optimally.",
        ],
        problem: [
          "Choosing the best price-per-unit cut greedily can miss a combination with a higher total.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int price[] = {1,5,8,9,10,17,17,20};\\n    int n = 8, best[9] = {0};\\n\\n    for (int len = 1; len <= n; len++)\\n        for (int cut = 1; cut <= len; cut++)\\n            if (price[cut-1] + best[len-cut] > best[len])\\n                best[len] = price[cut-1] + best[len-cut];\\n\\n    printf(\\\"%d\\\\n\\\", best[n]); /* 22 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint cutRod(vector<int>& price) {\\n    int n = price.size();\\n    vector<int> best(n + 1, 0);\\n    for (int len = 1; len <= n; len++)\\n        for (int cut = 1; cut <= len; cut++)\\n            best[len] = max(best[len], price[cut-1] + best[len-cut]);\\n    return best[n];\\n}\\n\\nint main() {\\n    vector<int> p{1,5,8,9,10,17,17,20};\\n    cout << cutRod(p) << '\\\\n'; // 22\\n}`,
        },
        steps(text) {
          const price = intsOf(text).filter((x) => x > 0).slice(0, 12);
          if (!price.length) return [{
            title: "Give at least one price",
            tracks: [chips("prices", ["—"], "idle")],
            counters: [count("revenue", 0)],
            legend: LEG,
            happened: "There is no rod to cut.",
            why: "Each length needs a price.",
          }];
          const n = price.length;
          const best = Array(n + 1).fill(0);
          const choice = Array(n + 1).fill(0);
          const steps = [];
          const vals = (cur) => (i) => (i === cur ? "read" : i < cur ? "done" : "dim");
          steps.push({
            title: `Prices for lengths 1 to ${n}`,
            tracks: [chips("price", price, "compare"), chips("best", best, (i) => (i === 0 ? "result" : "dim"))],
            counters: [count("length", n), count("revenue", 0)],
            legend: LEG,
            happened: "A rod of length 0 earns nothing, so best[0] = 0.",
            why: "No cuts leaves no sellable piece.",
            codeLine: 4,
          });
          for (let len = 1; len <= n; len++) {
            for (let cut = 1; cut <= len; cut++) {
              const cand = price[cut - 1] + best[len - cut];
              if (cand > best[len]) { best[len] = cand; choice[len] = cut; }
            }
            steps.push({
              title: `Length ${len}: best revenue ${best[len]} with first cut ${choice[len]}`,
              tracks: [chips("best", best, vals(len)), chips("prices", price.slice(0, len), (i) => (i === choice[len] - 1 ? "active" : "idle"))],
              counters: [count("revenue", best[len]), count("length", len, n)],
              legend: LEG,
              happened: `The best first cut for length ${len} is ${choice[len]}, leaving ${len - choice[len]}.`,
              why: "The remaining rod is already solved at its full optimal revenue.",
              codeLine: 8,
            });
          }
          const cuts = [];
          let len = n;
          while (len > 0) { cuts.push(choice[len]); len -= choice[len]; }
          steps.push({
            title: `Answer: revenue ${best[n]} from pieces ${cuts.join(" + ")}`,
            tracks: [chips("best", best, (i) => (i === n ? "result" : "done")), chips("piece lengths", cuts, "good")],
            counters: [count("revenue", best[n]), count("pieces", cuts.length)],
            legend: LEG,
            happened: `The optimal rod earns ${best[n]} using piece lengths ${cuts.join(", ")}.`,
            why: "Following the stored first cut reconstructs a partition that achieves the optimal revenue.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "decode-ways",
    title: "Decode Ways",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Count the ways a digit string can be decoded using A=1 through Z=26.",
    input: { label: "Digit string", default: "226", parse: "string" },
    approaches: [
      {
        name: "Ways Ending at Each Position",
        complexity: "O(length) time",
        idea: [
          "ways[i] counts decodings of the first i digits. A single digit can end a decoding when it is 1–9; a pair can end one when it is 10–26.",
          "Adding the ways from both valid endings counts all decodings without listing them. A zero is only legal as the second digit of 10 or 20.",
        ],
        problem: [
          "Trying every split repeats work and can mis-handle zeros, which cannot stand alone.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <string.h>\\n\\nint main(void) {\\n    char s[] = \\\"226\\\";\\n    int n = strlen(s);\\n    int dp[16] = {1,0};\\n\\n    for (int i = 1; i <= n; i++) {\\n        int one = s[i-1] - '0';\\n        if (one >= 1) dp[i] += dp[i-1];\\n        int two = i >= 2 ? (s[i-2]-'0')*10 + one : 0;\\n        if (two >= 10 && two <= 26) dp[i] += dp[i-2];\\n    }\\n\\n    printf(\\\"%d\\\\n\\\", dp[n]); /* 3 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <string>\\n#include <vector>\\nusing namespace std;\\n\\nint numDecodings(string s) {\\n    int n = s.size();\\n    vector<int> dp(n + 1, 0);\\n    dp[0] = 1;\\n    for (int i = 1; i <= n; i++) {\\n        if (s[i-1] != '0') dp[i] += dp[i-1];\\n        if (i >= 2) {\\n            int two = (s[i-2]-'0')*10 + (s[i-1]-'0');\\n            if (two >= 10 && two <= 26) dp[i] += dp[i-2];\\n        }\\n    }\\n    return dp[n];\\n}\\n\\nint main() {\\n    cout << numDecodings(\\\"226\\\") << '\\\\n'; // 3\\n}`,
        },
        steps(text) {
          const s = String(text || "").replace(/[^0-9]/g, "").slice(0, 20);
          if (!s) return [{
            title: "Give a digit string",
            tracks: [chips("digits", ["—"], "idle")],
            counters: [count("ways", 0)],
            legend: LEG,
            happened: "There are no digits to decode.",
            why: "Decoding needs at least one digit.",
          }];
          const n = s.length;
          const dp = Array(n + 1).fill(0);
          dp[0] = 1;
          const steps = [];
          const mark = (cur) => (i) => (i === cur ? "read" : i < cur ? "done" : "dim");
          steps.push({
            title: `Decode "${s}" with A=1 … Z=26`,
            tracks: [chips("digits", s.split(""), "compare"), chips("ways", dp, (i) => (i === 0 ? "result" : "dim"))],
            counters: [count("ways", 1), count("digits", n)],
            legend: LEG,
            happened: "The empty prefix has one decoding: decode nothing.",
            why: "Every longer prefix extends a shorter decoded prefix.",
            codeLine: 4,
          });
          for (let i = 1; i <= n; i++) {
            const one = Number(s[i - 1]);
            let why = [];
            if (one >= 1) { dp[i] += dp[i - 1]; why.push(`${one} as a letter`); }
            const two = i >= 2 ? Number(s.slice(i - 2, i)) : 0;
            if (two >= 10 && two <= 26) { dp[i] += dp[i - 2]; why.push(`${two} as a letter`); }
            steps.push({
              title: `Position ${i} ("${s.slice(0, i)}"): ${dp[i]} way${dp[i] === 1 ? "" : "s"}`,
              tracks: [chips("digits", s.split(""), (j) => (j === i - 1 ? "active" : j < i ? "done" : "dim")), chips("ways", dp, mark(i))],
              counters: [count("ways", dp[i]), count("position", i, n)],
              legend: LEG,
              happened: why.length ? `Valid endings: ${why.join(" and ")}.` : "Neither ending is a legal letter code.",
              why: "One-digit endings must be 1–9; two-digit endings must be 10–26.",
              codeLine: 10,
            });
          }
          steps.push({
            title: `Answer: ${dp[n]} decoding${dp[n] === 1 ? "" : "s"}`,
            tracks: [chips("digits", s.split(""), "done"), chips("ways", dp, (i) => (i === n ? "result" : "done"))],
            counters: [count("ways", dp[n]), count("digits", n)],
            legend: LEG,
            happened: `The full string has ${dp[n]} valid decodings.`,
            why: "Each decoding ends with either one or two digits, and both cases were added exactly once.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "word-break",
    title: "Word Break",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Decide whether a string can be segmented into dictionary words.",
    input: { label: "String | dictionary words", default: "leetcode | leet,code", parse: "string" },
    approaches: [
      {
        name: "Reachable Prefixes",
        complexity: "O(length × dictionary × word length) time",
        idea: [
          "reachable[i] is true when the first i characters can be split into dictionary words. reachable[0] is true for the empty prefix.",
          "For each later position, look back at every dictionary word that ends there. If the word matches and its starting prefix was reachable, the longer prefix is reachable too.",
        ],
        problem: [
          "Greedily removing the first matching word can strand an unmatched suffix even when another split works.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <string.h>\\n\\nint main(void) {\\n    char s[] = \\\"leetcode\\\";\\n    const char *words[] = {\\\"leet\\\", \\\"code\\\"};\\n    int n = strlen(s), m = 2;\\n    int dp[9] = {1,0};\\n\\n    for (int i = 1; i <= n; i++)\\n        for (int w = 0; w < m; w++) {\\n            int len = strlen(words[w]);\\n            if (len <= i && strncmp(s + i - len, words[w], len) == 0 && dp[i-len])\\n                dp[i] = 1;\\n        }\\n\\n    printf(\\\"%s\\\\n\\\", dp[n] ? \\\"true\\\" : \\\"false\\\"); /* true */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <string>\\n#include <unordered_set>\\n#include <vector>\\nusing namespace std;\\n\\nbool wordBreak(string s, vector<string>& dict) {\\n    unordered_set<string> words(dict.begin(), dict.end());\\n    int n = s.size();\\n    vector<bool> dp(n + 1, false);\\n    dp[0] = true;\\n    for (int i = 1; i <= n; i++)\\n        for (int j = 0; j < i; j++)\\n            if (dp[j] && words.count(s.substr(j, i - j))) { dp[i] = true; break; }\\n    return dp[n];\\n}\\n\\nint main() {\\n    vector<string> d{\\\"leet\\\",\\\"code\\\"};\\n    cout << (wordBreak(\\\"leetcode\\\", d) ? \\\"true\\\" : \\\"false\\\") << '\\\\n'; // true\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const s = String(parts[0] || "").replace(/\s/g, "").slice(0, 20);
          const words = String(parts[1] || "").split(/[\s,]+/).filter(Boolean).slice(0, 8);
          if (!s || !words.length) return [{
            title: "Give a string and dictionary words",
            tracks: [chips("string", ["—"], "idle")],
            counters: [count("prefixes", 0)],
            legend: LEG,
            happened: "The input is incomplete.",
            why: "Segmentation needs a string and at least one word.",
          }];
          const n = s.length;
          const dp = Array(n + 1).fill(false);
          dp[0] = true;
          const steps = [];
          const mark = (cur) => (i) => (i === cur ? "read" : dp[i] ? "good" : "dim");
          steps.push({
            title: `Can "${s}" be built from ${show(words)}?`,
            tracks: [chips("string", s.split(""), "compare"), chips("prefixes", dp.map((b) => (b ? "✓" : "·")), (i) => (i === 0 ? "result" : "dim"))],
            counters: [count("length", n), count("words", words.length)],
            legend: LEG,
            happened: "The empty prefix is reachable with zero words.",
            why: "Every full segmentation starts from the empty prefix.",
            codeLine: 4,
          });
          for (let i = 1; i <= n; i++) {
            let matched = "";
            for (const w of words) {
              if (w.length <= i && s.slice(i - w.length, i) === w && dp[i - w.length]) { dp[i] = true; matched = w; break; }
            }
            steps.push({
              title: `Prefix "${s.slice(0, i)}" is ${dp[i] ? "breakable" : "not breakable"}`,
              tracks: [chips("string", s.split(""), (j) => (j === i - 1 ? "active" : j < i ? "done" : "dim")), chips("prefixes", dp.map((b) => (b ? "✓" : "·")), mark(i))],
              counters: [count("position", i, n), count("reachable", dp.filter(Boolean).length)],
              legend: LEG,
              happened: matched ? `Word "${matched}" ends here and starts from a reachable prefix.` : "No dictionary word ends here from a reachable prefix.",
              why: "A segment is valid only when the word matches and the part before it is already breakable.",
              codeLine: 9,
            });
          }
          steps.push({
            title: dp[n] ? `Answer: "${s}" can be segmented` : `Answer: "${s}" cannot be segmented`,
            tracks: [chips("string", s.split(""), "done"), chips("prefixes", dp.map((b) => (b ? "✓" : "·")), (i) => (i === n ? "result" : dp[i] ? "good" : "dim"))],
            counters: [count("breakable", dp[n] ? 1 : 0), count("length", n)],
            legend: LEG,
            happened: dp[n] ? "The entire string is covered by reachable prefixes." : "The final prefix was never reached.",
            why: "The last table cell answers the whole string, since it includes every character.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "perfect-squares",
    title: "Perfect Squares",
    category: "Dynamic Programming",
    difficulty: "Intermediate",
    description: "Write a number as the sum of as few perfect squares as possible.",
    input: { label: "Number", default: "12", parse: "int" },
    approaches: [
      {
        name: "Fewest Squares per Value",
        complexity: "O(n × √n) time",
        idea: [
          "least[v] is the smallest count of perfect squares that sums to v. For each value, try every square j² no larger than v and add one to the best count for v − j².",
          "Building upward means every remainder is already solved, so one pass over the values suffices.",
        ],
        problem: [
          "Choosing the largest square first is not always optimal; for example, 12 needs three 4s rather than 9 + 1 + 1 + 1.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int n = 12;\\n    int dp[13];\\n    dp[0] = 0;\\n    for (int v = 1; v <= n; v++) dp[v] = v;\\n\\n    for (int v = 1; v <= n; v++)\\n        for (int j = 1; j * j <= v; j++)\\n            if (dp[v - j*j] + 1 < dp[v])\\n                dp[v] = dp[v - j*j] + 1;\\n\\n    printf(\\\"%d\\\\n\\\", dp[n]); /* 3 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint numSquares(int n) {\\n    vector<int> dp(n + 1, 0);\\n    for (int v = 1; v <= n; v++) {\\n        dp[v] = v;\\n        for (int j = 1; j * j <= v; j++)\\n            dp[v] = min(dp[v], dp[v - j*j] + 1);\\n    }\\n    return dp[n];\\n}\\n\\nint main() {\\n    cout << numSquares(12) << '\\\\n'; // 3\\n}`,
        },
        steps(text) {
          const n = Math.min(30, Math.max(0, parseInt(text, 10) || 0));
          if (!n) return [{
            title: "Give a positive number",
            tracks: [chips("values", ["—"], "idle")],
            counters: [count("squares", 0)],
            legend: LEG,
            happened: "There is no target value.",
            why: "The table needs a positive number to reach.",
          }];
          const dp = Array(n + 1).fill(0);
          for (let v = 1; v <= n; v++) dp[v] = v;
          const steps = [];
          const squares = Array.from({ length: Math.floor(Math.sqrt(n)) }, (_, i) => (i + 1) * (i + 1));
          steps.push({
            title: `Fewest squares summing to ${n}`,
            tracks: [chips("values", dp, (i) => (i === 0 ? "result" : "dim")), chips("squares", squares, "compare")],
            counters: [count("target", n), count("squares", squares.length)],
            legend: LEG,
            happened: `Using only 1s needs ${n} squares, so every value starts with that upper bound.`,
            why: "The upper bound is a valid answer that later choices can improve.",
            codeLine: 4,
          });
          for (let v = 1; v <= n; v++) {
            let bestSquare = 1;
            for (let j = 1; j * j <= v; j++) {
              if (dp[v - j * j] + 1 < dp[v]) { dp[v] = dp[v - j * j] + 1; bestSquare = j * j; }
            }
            steps.push({
              title: `Value ${v}: ${dp[v]} square${dp[v] === 1 ? "" : "s"}`,
              tracks: [chips("values", dp, (i) => (i === v ? "read" : i < v ? "done" : "dim")), chips("squares", squares, (i) => (squares[i] === bestSquare ? "active" : squares[i] <= v ? "compare" : "dim"))],
              counters: [count("squares", dp[v]), count("value", v, n)],
              legend: LEG,
              happened: `The best move uses square ${bestSquare}, leaving ${v - bestSquare}.`,
              why: "Every square no larger than v is tried, and the remainder is already optimal.",
              codeLine: 8,
            });
          }
          steps.push({
            title: `Answer: ${dp[n]} perfect square${dp[n] === 1 ? "" : "s"}`,
            tracks: [chips("values", dp, (i) => (i === n ? "result" : "done")), chips("squares", squares, "done")],
            counters: [count("squares", dp[n]), count("target", n)],
            legend: LEG,
            happened: `${n} needs at least ${dp[n]} perfect squares.`,
            why: "The final cell was minimised over every possible last square.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "combination-sum-iv",
    title: "Combination Sum IV",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Count ordered sequences of numbers that add up to a target.",
    input: { label: "Numbers | target", default: "1,2,3 | 4", parse: "string" },
    approaches: [
      {
        name: "Ordered Sequences per Target",
        complexity: "O(target × numbers) time",
        idea: [
          "ways[t] counts ordered sequences that sum to t, with ways[0] = 1 for the empty sequence.",
          "For each target, append any number that fits: ways[t] += ways[t − number]. Because the target loop is outside, different orders are counted separately.",
        ],
        problem: [
          "The coin-change combination loop counts unordered multisets; this problem explicitly distinguishes 1+3 from 3+1.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int a[] = {1,2,3}, n = 3, target = 4;\\n    int dp[5] = {1,0,0,0,0};\\n\\n    for (int t = 1; t <= target; t++)\\n        for (int i = 0; i < n; i++)\\n            if (a[i] <= t) dp[t] += dp[t - a[i]];\\n\\n    printf(\\\"%d\\\\n\\\", dp[target]); /* 7 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint combinationSum4(vector<int>& nums, int target) {\\n    vector<int> dp(target + 1, 0);\\n    dp[0] = 1;\\n    for (int t = 1; t <= target; t++)\\n        for (int x : nums)\\n            if (x <= t) dp[t] += dp[t - x];\\n    return dp[target];\\n}\\n\\nint main() {\\n    vector<int> a{1,2,3};\\n    cout << combinationSum4(a, 4) << '\\\\n'; // 7\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const nums = [...new Set(intsOf(parts[0]).filter((x) => x > 0))].sort((a, b) => a - b).slice(0, 10);
          const target = Math.min(20, Math.max(0, parseInt(parts[1], 10) || 0));
          if (!nums.length || !target) return [{
            title: "Give numbers and a target",
            tracks: [chips("numbers", nums.length ? nums : ["—"], "idle")],
            counters: [count("sequences", 0)],
            legend: LEG,
            happened: "The input is incomplete.",
            why: "Counting sequences needs at least one number and a target.",
          }];
          const dp = Array(target + 1).fill(0);
          dp[0] = 1;
          const steps = [];
          steps.push({
            title: `Ordered sequences summing to ${target}`,
            tracks: [chips("numbers", nums, "compare"), chips("ways", dp, (i) => (i === 0 ? "result" : "dim"))],
            counters: [count("target", target), count("sequences", 1)],
            legend: LEG,
            happened: "The empty sequence is the only sequence for target 0.",
            why: "Every longer sequence is built by appending one number to a shorter sequence.",
            codeLine: 4,
          });
          for (let t = 1; t <= target; t++) {
            for (const x of nums) if (x <= t) dp[t] += dp[t - x];
            steps.push({
              title: `Target ${t}: ${dp[t]} ordered sequence${dp[t] === 1 ? "" : "s"}`,
              tracks: [chips("ways", dp, (i) => (i === t ? "read" : i < t ? "done" : "dim")), chips("numbers", nums, (i) => (nums[i] <= t ? "active" : "dim"))],
              counters: [count("sequences", dp[t]), count("target", t, target)],
              legend: LEG,
              happened: `Appending each usable number to the sequences for ${t} gives ${dp[t]} sequences.`,
              why: "The target loop is outer, so sequences ending in different numbers are all counted separately.",
              codeLine: 7,
            });
          }
          steps.push({
            title: `Answer: ${dp[target]} ordered sequence${dp[target] === 1 ? "" : "s"}`,
            tracks: [chips("ways", dp, (i) => (i === target ? "result" : "done")), chips("numbers", nums, "good")],
            counters: [count("sequences", dp[target]), count("target", target)],
            legend: LEG,
            happened: `${dp[target]} different orders combine to ${target}.`,
            why: "Each order is generated once by its final appended number.",
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });
})();
