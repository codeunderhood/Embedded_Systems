/* ============================================================
   DSA Visuals — Graphs: Paths, Ordering and Connectivity
   Nine visualisations built around weighted digraphs, Euler
   trails, topological order and strongly connected components.
   All inputs are tokenised in steps(): whitespace-separated
   tokens, `name=value` settings and `a,b` / `a,b,w` edges.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  /* ----------------------------------------------------------
     Shared helpers
     ---------------------------------------------------------- */
  const CX = 25, CY = 16, R = 15;   // deterministic circle layout

  function circleLayout(ids) {
    const m = new Map();
    ids.forEach((id, i) => {
      const a = -Math.PI / 2 + (2 * Math.PI * i) / Math.max(1, ids.length);
      m.set(id, {
        x: +(CX + R * Math.cos(a)).toFixed(2),
        y: +(CY + R * Math.sin(a)).toFixed(2),
      });
    });
    return m;
  }

  function tokenize(raw) {
    const s = String(raw == null ? "" : raw).trim();
    return s ? s.split(/\s+/) : [];
  }

  function isIntText(s) { return /^-?\d+$/.test(s); }

  /* Build a graph stage: node + edge objects the engine draws. */
  function gstage(layout, nodeStates, edges, edgeStates, directed) {
    return {
      kind: "graph",
      nodes: [...layout.keys()].map((id) => {
        const p = layout.get(id);
        return { id, label: id, x: p.x, y: p.y, state: (nodeStates && nodeStates[id]) || "idle" };
      }),
      edges: (edges || []).map((e, i) => ({
        a: String(e.a),
        b: String(e.b),
        directed: directed !== false,
        state: edgeStates && edgeStates[i] ? edgeStates[i] : undefined,
      })),
    };
  }

  /* Cells track listing edges as "1→2 (4)". */
  function edgeTrack(label, edges, states) {
    return {
      label,
      cells: edges.map((e, i) => ({
        v: e.a + "→" + e.b + (e.w != null ? " (" + e.w + ")" : ""),
        state: (states && states[i]) || "idle",
      })),
    };
  }

  /* A friendly step for tokens we had to skip. */
  function noteStep(tracks, notes) {
    return {
      title: "Heads up: " + notes.length + " token" + (notes.length === 1 ? "" : "s") + " skipped",
      tracks,
      counters: [count("tokens skipped", notes.length)],
      happened: "These tokens didn't match the expected shape and were left out: " + notes.join(", ") + ".",
      why: "Ignoring what can't be read keeps the algorithm working on the part of the input that does make sense.",
    };
  }

  const EDGE_LEGEND = {
    read: "edge being examined now",
    good: "edge that improved an answer",
    active: "edge kept for later",
    dim: "examined, but didn't help",
    idle: "not used yet",
  };

  /* ==========================================================
     1. Network Delay Time — Dijkstra
     ========================================================== */
  V.register({
    id: "network-delay-time",
    title: "Network Delay Time",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Start a signal at one node and time how long every other node needs to hear it.",
    input: { label: "n= k= then edges a,b,w (k = sending node)", default: "n=6 k=1 1,2,1 1,3,4 2,3,2 3,4,1 3,5,3 4,5,2", parse: "string" },
    approaches: [
      {
        name: "Dijkstra with a Finalized Set",
        complexity: "O(V² + E) time, O(V) space",
        idea: [
          "Keep a distance guess for every node: the earliest time a signal could reach it. The sender starts at 0, everyone else at ∞.",
          "Repeatedly lock the unsettled node with the smallest guess — that guess is now final — and push time along its outgoing edges: through node u, neighbour v would hear at dist[u] + weight. Keep the improvement if it beats what v already had.",
          "The network delay time is the largest final distance. Any node still at ∞ never hears the signal, so the honest answer is −1.",
        ],
        problem: [
          "Locking nodes one at a time costs a scan over every node each round — fine for small graphs, but a priority queue drops the whole thing to O((V+E) log V).",
          "Dijkstra assumes non-negative weights. A single negative edge can make a 'final' guess too big, so this method must not be used there.",
        ],
        code: {
          c: `#include <stdio.h>
#define INF 999999

/* earliest signal times from src; row/col i is node i+1 */
int main(void) {
    int w[6][6] = {
        {INF,   1,   4, INF, INF, INF},
        {INF, INF,   2, INF, INF, INF},
        {INF, INF, INF,   1,   3, INF},
        {INF, INF, INF, INF,   2, INF},
        {INF, INF, INF, INF, INF, INF},
        {INF, INF, INF, INF, INF, INF}};
    int dist[6], used[6] = {0};
    int src = 0;                        /* node 1 */
    for (int i = 0; i < 6; i++) dist[i] = w[src][i];
    dist[src] = 0;
    for (int step = 0; step < 6; step++) {
        int u = -1;                     /* closest node not yet locked */
        for (int i = 0; i < 6; i++)
            if (!used[i] && (u < 0 || dist[i] < dist[u])) u = i;
        if (u < 0 || dist[u] >= INF) break;  /* the rest are unreachable */
        used[u] = 1;                    /* u is final now */
        for (int v = 0; v < 6; v++)
            if (!used[v] && w[u][v] < INF &&
                dist[u] + w[u][v] < dist[v])
                dist[v] = dist[u] + w[u][v]; /* relax */
    }
    printf("%d\\n", dist[5] >= INF ? -1 : dist[5]);
    return 0;
}`,
          cpp: `#include <iostream>
#include <queue>
#include <utility>
#include <vector>
using namespace std;

int main() {
    int n = 6;
    vector<vector<pair<int, int>>> w(n);   // node -> (neighbour, minutes)
    auto add = [&](int u, int v, int c) { w[u].push_back({v, c}); };
    add(0,1,1); add(0,2,4); add(1,2,2);
    add(2,3,1); add(2,4,3); add(3,4,2);

    const int INF = 1e9;
    vector<int> dist(n, INF);
    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<>> pq;
    dist[0] = 0;
    pq.push({0, 0});                     // (time, node)
    while (!pq.empty()) {
        auto [t, u] = pq.top(); pq.pop();
        if (t > dist[u]) continue;      // stale entry, skip
        for (auto [v, c] : w[u])
            if (t + c < dist[v]) { dist[v] = t + c; pq.push({dist[v], v}); }
    }
    cout << (dist[5] >= INF ? -1 : dist[5]) << '\\n';
}`,
        },
        steps(raw) {
          const steps = [];
          const tokens = tokenize(raw);
          const settings = {};
          const edges = [];
          const notes = [];
          for (const tok of tokens) {
            const m = tok.match(/^([A-Za-z]+)=(\S+)$/);
            if (m) { settings[m[1].toLowerCase()] = m[2]; continue; }
            const parts = tok.split(",").map((p) => p.trim());
            if (parts.length >= 2 && parts.length <= 3 && parts[0] && parts[1] && isIntText(parts[0]) && isIntText(parts[1])) {
              if (parts.length === 3 && (!parts[2] || !Number.isFinite(Number(parts[2])))) { notes.push(tok); continue; }
              const w = parts.length === 3 ? Number(parts[2]) : 1;
              const a = Number(parts[0]), b = Number(parts[1]);
              if (a < 1 || b < 1) { notes.push(tok); continue; }
              if (w < 0) { notes.push(tok); continue; }   // Dijkstra needs w >= 0
              edges.push({ a, b, w });
            } else notes.push(tok);
          }
          const labels = new Set();
          edges.forEach((e) => { labels.add(e.a); labels.add(e.b); });
          const maxLabel = labels.size ? Math.max(...labels) : 0;
          let n = parseInt(settings.n, 10);
          if (!Number.isFinite(n) || n < 1) n = maxLabel > 0 ? maxLabel : 1;
          const ids = [];
          for (let i = 1; i <= n; i++) ids.push(i);
          labels.forEach((l) => { if (l >= 1 && l <= n && ids.indexOf(l) < 0) ids.push(l); });
          ids.sort((x, y) => x - y);
          const layout = circleLayout(ids.map(String));
          const nodeSt = {}; ids.forEach((id) => { nodeSt[id] = "idle"; });
          const eKeep = edges.map(() => undefined);
          const dist = new Map(ids.map((id) => [id, Infinity]));
          const doneSet = new Set();
          const ix = (id) => ids.indexOf(id);
          const dState = (id, activeId, finished) => {
            if (id === activeId) return "active";
            if (doneSet.has(id)) return "good";
            if (dist.get(id) === Infinity) return finished ? "bad" : "idle";
            return "done";
          };
          const dTrack = (activeId, finished) => ({
            label: "earliest signal time",
            cells: ids.map((id) => ({
              v: dist.get(id) === Infinity ? "∞" : dist.get(id),
              state: dState(id, activeId, finished),
              tag: String(id),
            })),
          });
          let src = parseInt(settings.k, 10);
          let srcNote = "";
          if (!Number.isFinite(src) || ids.indexOf(src) < 0) {
            srcNote = "No usable k= among the nodes, so the signal starts at node " + ids[0] + ".";
            src = ids[0];
          }
          const setupTracks = [
            edgeTrack("directed edges (minutes)", edges, eKeep),
            dTrack(null, false),
          ];
          const setup = {
            title: `Setup: ${ids.length} nodes, ${edges.length} directed edges, signal starts at node ${src}`,
            ...gstage(layout, nodeSt, edges, eKeep),
            tracks: setupTracks,
            counters: [count("nodes", ids.length), count("edges", edges.length), count("sender", src)],
            legend: ["read", "good", "active", "idle"],
            legendLabels: EDGE_LEGEND,
            happened: `Node ${src} is about to send; every other node's earliest hearing time is still unknown (∞).`,
            why: "Distance guesses start pessimistic so each real improvement is a genuine discovery.",
            codeLine: 15,
          };
          steps.push(setup);
          if (notes.length) steps.push({ ...noteStep(setupTracks, notes), ...gstage(layout, nodeSt, edges, eKeep) });
          dist.set(src, 0);
          steps.push({
            title: `Sender ${src} hears itself at time 0`,
            ...gstage(layout, { ...nodeSt, [src]: "read" }, edges, eKeep),
            tracks: [edgeTrack("directed edges (minutes)", edges, eKeep), dTrack(src, false)],
            counters: [count("nodes locked", 0, ids.length), count("sender time", 0)],
            legend: ["read", "good", "active", "idle"],
            legendLabels: EDGE_LEGEND,
            happened: srcNote ? `${srcNote} Its distance drops from ∞ to 0 — the signal leaves the gate.` : `Node ${src}'s guess drops from ∞ to 0 — the signal leaves the gate.`,
            why: "Zero is the one distance known for certain; every other guess will be measured from it.",
            codeLine: 16,
          });
          let relaxTries = 0;
          while (doneSet.size < ids.length) {
            let u = null;
            for (const id of ids) {
              if (doneSet.has(id) || dist.get(id) === Infinity) continue;
              if (u === null || dist.get(id) < dist.get(u)) u = id;
            }
            if (u === null) break;
            doneSet.add(u);
            const d = dist.get(u);
            steps.push({
              title: `Lock node ${u} — the signal is guaranteed there by time ${d}`,
              ...gstage(layout, { ...nodeSt, [u]: "good" }, edges, eKeep),
              tracks: [edgeTrack("directed edges (minutes)", edges, eKeep), dTrack(null, false)],
              counters: [count("nodes locked", doneSet.size, ids.length), count(`time at node ${u}`, d)],
              legend: ["read", "good", "active", "idle"],
              legendLabels: EDGE_LEGEND,
              happened: `Of the unsettled nodes, ${u} has the smallest guess (${d}), and no future detour can beat a route that already arrives that early.`,
              why: "Once the smallest guess is locked it can never get smaller — that is Dijkstra's promise.",
              codeLine: 22,
            });
            edges.forEach((e, i) => {
              if (e.a !== u) return;
              relaxTries++;
              const v = e.b;
              const prev = dist.get(v);
              const cand = d + e.w;
              const improved = cand < prev;
              if (improved) dist.set(v, cand);
              const shown = eKeep.slice();
              shown[i] = "read";
              const ns = { ...nodeSt, [u]: "read" };
              if (improved) ns[v] = "active";
              for (const id of ids) if (doneSet.has(id) && id !== u) ns[id] = "good";
              steps.push({
                title: improved
                  ? `Relax ${u}→${v}: ${d} + ${e.w} = ${cand} < ${prev === Infinity ? "∞" : prev} → node ${v} now at ${cand}`
                  : `Relax ${u}→${v}: ${d} + ${e.w} = ${cand} — no better than ${prev === Infinity ? "∞" : prev}`,
                ...gstage(layout, ns, edges, shown),
                tracks: [
                  edgeTrack("directed edges (minutes)", edges, shown),
                  dTrack(improved ? v : null, false),
                ],
                counters: [count("nodes locked", doneSet.size, ids.length), count("edge checks", relaxTries)],
                legend: ["read", "good", "active", "idle"],
                legendLabels: EDGE_LEGEND,
                happened: improved
                  ? `Going through ${u}, node ${v} hears the signal at ${cand} — better than ${prev === Infinity ? "anything known (∞)" : prev + " so far"}.`
                  : `Going through ${u} would take ${cand} minutes — at least as late as what ${v} already knows, so nothing changes.`,
                why: improved
                  ? "Each outgoing edge is one more possible route; only the earliest arrival is worth keeping."
                  : "Checking a dead end still matters: it proves the current guess is safe.",
                codeLine: 26,
              });
              eKeep[i] = improved ? "good" : "dim";
            });
          }
          const unreachable = ids.filter((id) => dist.get(id) === Infinity);
          const finite = ids.filter((id) => dist.get(id) < Infinity);
          let lastId = src, answer;
          finite.forEach((id) => { if (dist.get(id) >= dist.get(lastId)) lastId = id; });
          answer = unreachable.length ? -1 : dist.get(lastId);
          const ns = {};
          ids.forEach((id) => {
            ns[id] = unreachable.indexOf(id) >= 0 ? "bad" : id === lastId && !unreachable.length ? "result" : "good";
          });
          steps.push({
            title: unreachable.length
              ? `Answer: -1 — node ${unreachable.join(", ")} never hears the signal`
              : `Answer: ${answer} — by then every node has heard`,
            ...gstage(layout, ns, edges, eKeep),
            tracks: [edgeTrack("directed edges (minutes)", edges, eKeep), dTrack(null, true)],
            counters: [count("nodes locked", doneSet.size, ids.length), count("answer", answer)],
            legend: ["read", "good", "result", "bad"],
            legendLabels: EDGE_LEGEND,
            happened: unreachable.length
              ? `All reachable nodes are locked; ${unreachable.join(", ")} stayed at ∞, so the whole network can never be reached from ${src}.`
              : `Every node is locked; the slowest to hear is node ${lastId} at ${dist.get(lastId)} minutes, which is the network delay time.`,
            why: unreachable.length
              ? "An unreachable node makes the answer -1 — reporting a time would be a lie."
              : "The delay is set by the slowest node, and each locked guess is exact, so the maximum is exact too.",
            codeLine: 28,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     2. Cheapest Flights Within K Stops — truncated Bellman-Ford
     ========================================================== */
  V.register({
    id: "cheapest-flights-within-k-stops",
    title: "Cheapest Flights Within K Stops",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Find the cheapest price to fly from one city to another with at most K stops along the way.",
    input: { label: "n= k= src= dst= then edges a,b,w", default: "n=4 k=2 src=0 dst=3 0,1,100 1,2,100 2,3,100 0,3,500", parse: "string" },
    approaches: [
      {
        name: "Relax Every Edge, K+1 Rounds",
        complexity: "O(K · E) time, O(V) space",
        idea: [
          "A price list where dist[v] means: the cheapest way to reach v using at most as many flights as the rounds played so far. The source starts at 0, everyone else at ∞.",
          "Each round allows one more flight. Crucially every edge is relaxed against the PREVIOUS round's snapshot: an update can only add a single flight to a route that was already legal last round.",
          "After K+1 rounds every route of up to K+1 flights (i.e. at most K stops) has been considered, so dist[dst] is the answer — or ∞, honestly reported as -1.",
        ],
        problem: [
          "The stop limit is the whole difficulty: plain Dijkstra happily 'locks' a price that used too many stops and can't be corrected later. Extra rounds without the snapshot would sneak two flights into one round.",
          "The price is linear in K · E — for huge networks a BFS layered by stop count with early pruning behaves better, but the idea is the same.",
        ],
        code: {
          c: `#include <stdio.h>
#define INF 999999
typedef struct { int u, v, w; } Edge;

/* cheapest dst price using at most K stops: K+1 relax rounds */
int main(void) {
    Edge e[] = {{0,1,100},{1,2,100},{2,3,100},{0,3,500}};
    int m = 4, n = 4, src = 0, dst = 3, K = 2;
    int dist[4], prev[4];
    for (int i = 0; i < n; i++) dist[i] = INF;
    dist[src] = 0;
    for (int r = 0; r <= K; r++) {            /* r flights allowed */
        for (int i = 0; i < n; i++) prev[i] = dist[i];  /* snapshot */
        for (int i = 0; i < m; i++) {
            if (prev[e[i].u] >= INF) continue;          /* can't depart */
            int cand = prev[e[i].u] + e[i].w;
            if (cand < dist[e[i].v]) dist[e[i].v] = cand; /* one more hop */
        }
    }
    printf("%d\\n", dist[dst] >= INF ? -1 : dist[dst]);   /* 300 */
    return 0;
}`,
          cpp: `#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;

int main() {
    struct Edge { int u, v, w; };
    vector<Edge> e = {{0,1,100},{1,2,100},{2,3,100},{0,3,500}};
    int n = 4, src = 0, dst = 3, K = 2;
    const int INF = 1e9;
    vector<int> dist(n, INF);
    dist[src] = 0;
    for (int r = 0; r <= K; r++) {           // one more flight allowed
        vector<int> prev = dist;             // snapshot keeps the limit honest
        for (auto& ed : e)
            if (prev[ed.u] < INF)
                dist[ed.v] = min(dist[ed.v], prev[ed.u] + ed.w);
    }
    cout << (dist[dst] >= INF ? -1 : dist[dst]) << '\\n';
}`,
        },
        steps(raw) {
          const steps = [];
          const tokens = tokenize(raw);
          const settings = {};
          const edges = [];
          const notes = [];
          for (const tok of tokens) {
            const m = tok.match(/^([A-Za-z]+)=(\S+)$/);
            if (m) { settings[m[1].toLowerCase()] = m[2]; continue; }
            const parts = tok.split(",").map((p) => p.trim());
            if (parts.length >= 2 && parts.length <= 3 && parts.every((p) => p.length > 0 && isIntText(p))) {
              edges.push({ a: Number(parts[0]), b: Number(parts[1]), w: parts.length === 3 ? Number(parts[2]) : 1 });
            } else notes.push(tok);
          }
          const labels = new Set();
          edges.forEach((e) => { labels.add(e.a); labels.add(e.b); });
          const maxLabel = labels.size ? Math.max(...labels) : -1;
          let n = parseInt(settings.n, 10);
          if (!Number.isFinite(n) || n < 1) n = Math.max(maxLabel + 1, 1);
          const ids = [];
          for (let i = 0; i < n; i++) ids.push(i);
          const layout = circleLayout(ids.map(String));
          let k = parseInt(settings.k, 10);
          if (!Number.isFinite(k) || k < 0) { k = Math.max(0, ids.length - 1); notes.push("k= (using " + k + ")"); }
          if (k > 6) { k = 6; notes.push("k>6 (capped at 6)"); }
          let src = parseInt(settings.src, 10);
          if (!Number.isFinite(src) || ids.indexOf(src) < 0) src = ids.indexOf(0) >= 0 ? 0 : ids[0];
          let dst = parseInt(settings.dst, 10);
          if (!Number.isFinite(dst) || ids.indexOf(dst) < 0) dst = ids[ids.length - 1];
          const nodeSt = {}; ids.forEach((id) => { nodeSt[id] = "idle"; });
          const dist = new Map(ids.map((id) => [id, Infinity]));
          const dTrack = (activeId) => ({
            label: "cheapest so far",
            cells: ids.map((id) => ({
              v: dist.get(id) === Infinity ? "∞" : dist.get(id),
              state: id === activeId ? "active" : dist.get(id) === Infinity ? "idle" : "done",
              tag: String(id),
            })),
          });
          const rounds = k + 1;
          const setupTracks = [edgeTrack("directed flights (price)", edges, edges.map(() => undefined)), dTrack(null)];
          steps.push({
            title: `Setup: ${ids.length} cities, ${edges.length} flights, at most ${k} stops`,
            ...gstage(layout, nodeSt, edges, edges.map(() => undefined)),
            tracks: setupTracks,
            counters: [count("cities", ids.length), count("flights", edges.length), count("stops allowed", k)],
            legend: ["read", "good", "active", "idle"],
            legendLabels: EDGE_LEGEND,
            happened: `Flying ${src} → ${dst} with no more than ${k} stops: ${rounds} flights may be chained at most.`,
            why: "A stop limit turns a plain shortest-path question into one that must count hops, which rounds handle naturally.",
            codeLine: 10,
          });
          if (notes.length) steps.push({ ...noteStep(setupTracks, notes), ...gstage(layout, nodeSt, edges, edges.map(() => undefined)) });
          dist.set(src, 0);
          steps.push({
            title: `Origin ${src} is free — price 0`,
            ...gstage(layout, { ...nodeSt, [src]: "read" }, edges, edges.map(() => undefined)),
            tracks: [edgeTrack("directed flights (price)", edges, edges.map(() => undefined)), dTrack(src)],
            counters: [count("round", 0, rounds), count("price at origin", 0)],
            legend: ["read", "good", "active", "idle"],
            legendLabels: EDGE_LEGEND,
            happened: `Standing in ${src} costs nothing; every other city is still priceless (∞).`,
            why: "All routes grow outward from this one known price.",
            codeLine: 11,
          });
          for (let r = 1; r <= rounds; r++) {
            const keep = edges.map(() => undefined);
            steps.push({
              title: `Round ${r}: routes with up to ${r} flight${r === 1 ? "" : "s"} now allowed`,
              ...gstage(layout, nodeSt, edges, keep),
              tracks: [edgeTrack("round " + r + " — flights examined", edges, keep), dTrack(null)],
              counters: [count("round", r, rounds), count("flights allowed", r), count("cities known", [...dist].filter(([, d]) => d < Infinity).length, ids.length)],
              legend: ["read", "good", "active", "idle"],
              legendLabels: EDGE_LEGEND,
              happened: `Distances entering this round: ${ids.map((id) => id + "=" + (dist.get(id) === Infinity ? "∞" : dist.get(id))).join(", ")}. Each accepted price may now be extended by exactly one flight.`,
              why: "Relaxing against last round's snapshot is what keeps the stop limit exact — no route can grow two hops in one round.",
              codeLine: 14,
            });
            const prevDist = new Map(dist);
            edges.forEach((e, i) => {
              const u = e.a, v = e.b;
              const pu = prevDist.get(u);
              const pv = prevDist.get(v);
              const reachable = pu < Infinity;
              const cand = reachable ? pu + e.w : Infinity;
              const improved = reachable && cand < pv;
              if (improved) dist.set(v, cand);
              keep[i] = improved ? "good" : "dim";
              const ns = { ...nodeSt, [u]: "read" };
              if (improved) ns[v] = "active";
              steps.push({
                title: !reachable
                  ? `Flight ${u}→${v} (${e.w}): ${u} wasn't reachable last round — skipped`
                  : improved
                    ? `Flight ${u}→${v} (${e.w}): ${pu} + ${e.w} = ${cand} < ${pv === Infinity ? "∞" : pv} → ${v} drops to ${cand}`
                    : `Flight ${u}→${v} (${e.w}): ${pu} + ${e.w} = ${cand} — not cheaper than ${pv === Infinity ? "∞" : pv}`,
                ...gstage(layout, ns, edges, keep),
                tracks: [edgeTrack("round " + r + " — flights examined", edges, keep), dTrack(improved ? v : null)],
                counters: [count("round", r, rounds), count("price at " + dst, dist.get(dst) === Infinity ? "∞" : dist.get(dst))],
                legend: ["read", "good", "active", "idle"],
                legendLabels: EDGE_LEGEND,
                happened: !reachable
                  ? `No plane leaves ${u} at a price known before this round, so the ticket ${u}→${v} can't be bought yet.`
                  : improved
                    ? `Buying ${u}→${v} on top of last round's best trip to ${u} gives a cheaper way into ${v}.`
                    : `This ticket would cost more than what ${v} already knows, so the price list stays as it is.`,
                why: !reachable
                  ? "Only last round's prices can be extended — that is exactly what makes each round add one flight and no more."
                  : improved
                    ? "Round by round, longer and longer routes become legal without ever breaking the stop limit."
                    : "Failed checks are the audit trail: they prove the kept price is the cheapest legal one.",
                codeLine: improved ? 18 : 17,
              });
            });
          }
          const final = dist.get(dst);
          steps.push({
            title: final === Infinity
              ? `Answer: -1 — no route to ${dst} within ${k} stops`
              : `Answer: ${final} — cheapest ${src} → ${dst} with at most ${k} stops`,
            ...gstage(layout, ids.reduce((acc, id) => {
              acc[id] = id === dst && final < Infinity ? "result" : id === src ? "good" : dist.get(id) === Infinity ? "bad" : "done";
              return acc;
            }, {}),
              edges,
              edges.map(() => undefined)),
            tracks: [edgeTrack("directed flights (price)", edges, edges.map(() => undefined)), dTrack(dst)],
            counters: [count("round", rounds, rounds), count("answer", final === Infinity ? -1 : final)],
            legend: ["read", "good", "result", "bad"],
            legendLabels: EDGE_LEGEND,
            happened: final === Infinity
              ? `Every legal round has been played and ${dst} is still at ∞ — no chain of at most ${k + 1} flights connects ${src} to ${dst}.`
              : `After ${rounds} rounds the table reads ${ids.map((id) => id + "=" + (dist.get(id) === Infinity ? "∞" : dist.get(id))).join(", ")}; ${dst} holds the cheapest legal price.`,
            why: final === Infinity
              ? "The honest answer is -1: with a stop limit, some pairs simply can't be connected."
              : "Each round extended every known route by one flight, so after K+1 rounds all legal routes were priced and the minimum stands.",
            codeLine: 21,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     3. Path with Minimum Effort — Dijkstra on the worst edge
     ========================================================== */
  V.register({
    id: "path-with-minimum-effort",
    title: "Path with Minimum Effort",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Walk from one node to another keeping the largest single edge on the route as small as possible.",
    input: { label: "n= src= dst= then two-way edges a,b,w", default: "n=4 1,2,1 2,3,3 1,4,6 3,4,1", parse: "string" },
    approaches: [
      {
        name: "Dijkstra on the Largest Edge (two-way)",
        complexity: "O(V² + E) time, O(V) space",
        idea: [
          "Effort of a route is the biggest edge along it, not the sum. Keep a guess per node: the smallest effort any route has achieved so far, starting at 0 for the source (walking nowhere costs nothing).",
          "Lock the unsettled node with the smallest effort, then offer its neighbours a route whose effort is max(effort[u], edge). Keep the offer when it is smaller than the neighbour's current guess.",
          "The effort at the destination when it is locked is the answer: no route can arrive with a smaller worst edge.",
        ],
        problem: [
          "Minimising the largest edge is not the same as minimising the total: the cheapest route may have a huge single edge, so the two problems need different relax rules.",
          "The same O(V²) scan as ordinary Dijkstra is used here; a heap brings it to O((V+E) log V) but the story is unchanged.",
        ],
        code: {
          c: `#include <stdio.h>
#define INF 999999

/* smallest worst-edge route between two nodes of a two-way graph */
int main(void) {
    int w[4][4] = {{0,1,INF,6},{1,0,3,INF},{INF,3,0,1},{6,INF,1,0}};
    int dist[4], used[4] = {0};
    for (int i = 0; i < 4; i++) dist[i] = INF;
    dist[0] = 0;                       /* node 1 is the start */
    for (int step = 0; step < 4; step++) {
        int u = -1;                    /* smallest effort so far */
        for (int i = 0; i < 4; i++)
            if (!used[i] && (u < 0 || dist[i] < dist[u])) u = i;
        if (u < 0 || dist[u] >= INF) break;
        used[u] = 1;
        for (int v = 0; v < 4; v++) {
            if (used[v] || w[u][v] == 0) continue;   /* 0 = no edge */
            int cand = dist[u] > w[u][v] ? dist[u] : w[u][v];
            if (cand < dist[v]) dist[v] = cand;      /* effort improves */
        }
    }
    printf("%d\\n", dist[3]);          /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <queue>
#include <utility>
#include <vector>
using namespace std;

int main() {
    int n = 4;
    vector<vector<pair<int,int>>> g(n);
    auto add = [&](int u, int v, int c) { g[u].push_back({v, c}); g[v].push_back({u, c}); };
    add(0,1,1); add(1,2,3); add(0,3,6); add(2,3,1);

    const int INF = 1e9;
    vector<int> effort(n, INF);
    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<>> pq;
    effort[0] = 0;
    pq.push({0, 0});
    while (!pq.empty()) {
        auto [e, u] = pq.top(); pq.pop();
        if (e > effort[u]) continue;
        for (auto [v, c] : g[u]) {
            int cand = max(e, c);                // worst edge on this route
            if (cand < effort[v]) { effort[v] = cand; pq.push({cand, v}); }
        }
    }
    cout << effort[3] << '\\n';                   // 3
}`,
        },
        steps(raw) {
          const steps = [];
          const tokens = tokenize(raw);
          const settings = {};
          const edges = [];
          const notes = [];
          for (const tok of tokens) {
            const m = tok.match(/^([A-Za-z]+)=(\S+)$/);
            if (m) { settings[m[1].toLowerCase()] = m[2]; continue; }
            const parts = tok.split(",").map((p) => p.trim());
            if (parts.length >= 2 && parts.length <= 3 && parts[0] && parts[1] && isIntText(parts[0]) && isIntText(parts[1])) {
              if (parts.length === 3 && (!parts[2] || !Number.isFinite(Number(parts[2])))) { notes.push(tok); continue; }
              const w = parts.length === 3 ? Number(parts[2]) : 1;
              const a = Number(parts[0]), b = Number(parts[1]);
              if (a < 1 || b < 1) { notes.push(tok); continue; }
              edges.push({ a, b, w: Math.abs(w) });
            } else notes.push(tok);
          }
          const labels = new Set();
          edges.forEach((e) => { labels.add(e.a); labels.add(e.b); });
          const maxLabel = labels.size ? Math.max(...labels) : 0;
          let n = parseInt(settings.n, 10);
          if (!Number.isFinite(n) || n < 1) n = maxLabel > 0 ? maxLabel : 1;
          const ids = [];
          for (let i = 1; i <= n; i++) ids.push(i);
          labels.forEach((l) => { if (l >= 1 && l <= n && ids.indexOf(l) < 0) ids.push(l); });
          ids.sort((x, y) => x - y);
          const layout = circleLayout(ids.map(String));
          let src = parseInt(settings.src, 10);
          if (!Number.isFinite(src) || ids.indexOf(src) < 0) src = ids[0];
          let dst = parseInt(settings.dst, 10);
          if (!Number.isFinite(dst) || ids.indexOf(dst) < 0) dst = ids[ids.length - 1];
          const adj = ids.map(() => []);
          edges.forEach((e, i) => {
            adj[ids.indexOf(e.a)].push({ to: e.b, w: e.w, ei: i });
            adj[ids.indexOf(e.b)].push({ to: e.a, w: e.w, ei: i });
          });
          const nodeSt = {}; ids.forEach((id) => { nodeSt[id] = "idle"; });
          const eKeep = edges.map(() => undefined);
          const dist = new Map(ids.map((id) => [id, Infinity]));
          const doneSet = new Set();
          const dTrack = (activeId, finished) => ({
            label: "smallest effort known",
            cells: ids.map((id) => ({
              v: dist.get(id) === Infinity ? "∞" : dist.get(id),
              state: id === activeId ? "active" : doneSet.has(id) ? "good" : dist.get(id) === Infinity ? (finished ? "bad" : "idle") : "done",
              tag: String(id),
            })),
          });
          const directed = false;
          const setupTracks = [edgeTrack("two-way edges (effort)", edges, eKeep), dTrack(null, false)];
          steps.push({
            title: `Setup: ${ids.length} nodes, ${edges.length} two-way edges, ${src} → ${dst}`,
            ...gstage(layout, nodeSt, edges, eKeep, directed),
            tracks: setupTracks,
            counters: [count("nodes", ids.length), count("edges", edges.length), count("start", src), count("target", dst)],
            legend: ["read", "good", "active", "idle"],
            legendLabels: EDGE_LEGEND,
            happened: `Every route's effort is its single most expensive edge. Node ${src} starts free, ${dst} is the goal.`,
            why: "Taking a maximum instead of a sum is what lets a walk complain about its worst bridge rather than its length.",
            codeLine: 7,
          });
          if (notes.length) steps.push({ ...noteStep(setupTracks, notes), ...gstage(layout, nodeSt, edges, eKeep, directed) });
          dist.set(src, 0);
          steps.push({
            title: `Start at ${src} with effort 0`,
            ...gstage(layout, { ...nodeSt, [src]: "read" }, edges, eKeep, directed),
            tracks: [edgeTrack("two-way edges (effort)", edges, eKeep), dTrack(src, false)],
            counters: [count("nodes locked", 0, ids.length), count("effort at " + src, 0)],
            legend: ["read", "good", "active", "idle"],
            legendLabels: EDGE_LEGEND,
            happened: `Standing at ${src} has cost nothing so far, so its best-known effort is 0.`,
            why: "A route with no edges has no worst edge — effort 0 is the right seed.",
            codeLine: 8,
          });
          let checks = 0;
          while (doneSet.size < ids.length) {
            let u = null;
            for (const id of ids) {
              if (doneSet.has(id) || dist.get(id) === Infinity) continue;
              if (u === null || dist.get(id) < dist.get(u)) u = id;
            }
            if (u === null) break;
            doneSet.add(u);
            const du = dist.get(u);
            steps.push({
              title: `Lock node ${u} — best effort ${du}${u === dst ? " (the goal!)" : ""}`,
              ...gstage(layout, { ...nodeSt, [u]: "good" }, edges, eKeep, directed),
              tracks: [edgeTrack("two-way edges (effort)", edges, eKeep), dTrack(null, false)],
              counters: [count("nodes locked", doneSet.size, ids.length), count(`effort at ${u}`, du)],
              legend: ["read", "good", "active", "idle"],
              legendLabels: EDGE_LEGEND,
              happened: `${u} has the smallest effort among the unlocked nodes (${du}), so no other route can reach it with a gentler worst edge.`,
              why: "Locking in increasing effort order is what pin the answer down before the destination is even finished.",
              codeLine: 16,
            });
            if (u === dst) break;
            adj[ids.indexOf(u)].forEach(({ to, w, ei }) => {
              checks++;
              const prev = dist.get(to);
              const cand = Math.max(du, w);
              const improved = cand < prev;
              if (improved) dist.set(to, cand);
              eKeep[ei] = improved ? "good" : "dim";
              const shown = eKeep.slice();
              shown[ei] = "read";
              const ns = { ...nodeSt, [u]: "read" };
              if (improved) ns[to] = "active";
              for (const id of ids) if (doneSet.has(id) && id !== u) ns[id] = "good";
              steps.push({
                title: improved
                  ? `Try ${u}—${to} (${w}): max(${du}, ${w}) = ${cand} < ${prev === Infinity ? "∞" : prev} → ${to} improves to ${cand}`
                  : `Try ${u}—${to} (${w}): max(${du}, ${w}) = ${cand} — no better than ${prev === Infinity ? "∞" : prev}`,
                ...gstage(layout, ns, edges, shown, directed),
                tracks: [edgeTrack("two-way edges (effort)", edges, shown), dTrack(improved ? to : null, false)],
                counters: [count("nodes locked", doneSet.size, ids.length), count("edge checks", checks)],
                legend: ["read", "good", "active", "idle"],
                legendLabels: EDGE_LEGEND,
                happened: improved
                  ? `Continuing from ${u} adds one edge of ${w}, and the worst edge on that route is ${cand} — better than ${prev === Infinity ? "∞" : prev}.`
                  : `Reaching ${to} through ${u} would mean a worst edge of ${cand}, which is not an improvement.`,
                why: improved
                  ? "The effort follows the route's maximum, so a long detour with one huge edge is avoided automatically."
                  : "Rejecting a route is how the search keeps only the gentlest way in.",
                codeLine: 18,
              });
            });
          }
          const fin = dist.get(dst);
          steps.push({
            title: fin === Infinity
              ? `Answer: -1 — ${dst} can't be reached from ${src}`
              : `Answer: ${fin} — the gentlest route ${src} → ${dst} has a worst edge of ${fin}`,
            ...gstage(layout, ids.reduce((acc, id) => {
              acc[id] = id === dst && fin < Infinity ? "result" : doneSet.has(id) ? "good" : "bad";
              return acc;
            }, {}), edges, eKeep, directed),
            tracks: [edgeTrack("two-way edges (effort)", edges, eKeep), dTrack(dst, true)],
            counters: [count("nodes locked", doneSet.size, ids.length), count("answer", fin === Infinity ? -1 : fin)],
            legend: ["read", "good", "result", "bad"],
            legendLabels: EDGE_LEGEND,
            happened: fin === Infinity
              ? `The walk ran out of reachable nodes before ${dst}: ${src} and ${dst} sit in different parts of the graph.`
              : `The goal was locked with effort ${fin}: some route from ${src} to ${dst} keeps every edge below or at ${fin}, and none can do better.`,
            why: fin === Infinity
              ? "Reporting a number would invent a route; -1 says plainly that none exists."
              : "Because nodes were locked in effort order, the first effort at ${dst} to be locked is the true minimum.".replace("${dst}", dst),
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     4. Swim in Rising Water — raise the level, grow the region
     ========================================================== */
  V.register({
    id: "swim-in-rising-water",
    title: "Swim in Rising Water",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Water rises one level at a time; find the earliest moment you can swim from the top-left cell to the bottom-right cell.",
    input: { label: "Grid rows as digit strings, e.g. 0312 4576 9813 2605", default: "0312 4576 9813 2605", parse: "tokens" },
    approaches: [
      {
        name: "Raise the Water, Grow the Region",
        complexity: "O(H · R·C) time, O(R·C) space",
        idea: [
          "The water level is time. At level t a cell can be stood on when its height is at most t, and you may move between neighbouring cells that are both flooded.",
          "Start at cell (0,0) when the level reaches its height. Then turn the tap: each new level floods any cell whose height is exactly that level, and the reachable region spreads through them — sometimes across several cells in one go.",
          "The first level at which the bottom-right cell becomes reachable is the answer. For a grid whose tallest cell is H there are at most H levels, which is why this is a small, honest brute force.",
        ],
        problem: [
          "Standing time is wasted on levels where the region cannot grow; a binary search on the level (each check an O(R·C) flood) or a Dijkstra-style 'smallest water level' search skips those, trading the simple loop for more code.",
          "The region is recomputed by scanning the whole grid at every level, so this is O(H·R·C) — fine for small boards, wasteful for big ones.",
        ],
        code: {
          c: `#include <stdio.h>
#define N 4

/* earliest water level at which a route (0,0)->(N-1,N-1) exists */
int main(void) {
    int g[N][N] = {{0,3,1,2},{4,5,7,6},{9,8,1,3},{2,6,0,5}};
    int seen[N][N] = {{0}};
    int dr[4] = {1,-1,0,0}, dc[4] = {0,0,1,-1};
    int t = g[0][0];
    seen[0][0] = 1;
    while (!seen[N-1][N-1]) {
        t++;                            /* the water rises by one */
        int grew = 1;
        while (grew) {                  /* flood until nothing changes */
            grew = 0;
            for (int r = 0; r < N; r++)
                for (int c = 0; c < N; c++) {
                    if (!seen[r][c] || g[r][c] > t) continue;
                    for (int k = 0; k < 4; k++) {
                        int nr = r + dr[k], nc = c + dc[k];
                        if (nr < 0 || nc < 0 || nr >= N || nc >= N) continue;
                        if (!seen[nr][nc] && g[nr][nc] <= t) { seen[nr][nc] = 1; grew = 1; }
                    }
                }
        }
    }
    printf("%d\\n", t);                 /* 6 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int swim(const vector<vector<int>>& g) {
    int n = g.size();
    vector<vector<bool>> seen(n, vector<bool>(n, false));
    int dr[4] = {1,-1,0,0}, dc[4] = {0,0,1,-1};
    int t = g[0][0];
    seen[0][0] = true;
    while (!seen[n-1][n-1]) {
        t++;                                 // water rises one level
        bool grew = true;
        while (grew) {                       // spread through the region
            grew = false;
            for (int r = 0; r < n; r++)
                for (int c = 0; c < n; c++) {
                    if (!seen[r][c] || g[r][c] > t) continue;
                    for (int k = 0; k < 4; k++) {
                        int nr = r + dr[k], nc = c + dc[k];
                        if (nr < 0 || nc < 0 || nr >= n || nc >= n) continue;
                        if (!seen[nr][nc] && g[nr][nc] <= t) { seen[nr][nc] = true; grew = true; }
                    }
                }
        }
    }
    return t;
}

int main() {
    cout << swim({{0,3,1,2},{4,5,7,6},{9,8,1,3},{2,6,0,5}}) << '\\n'; // 6
}`,
        },
        steps(raw) {
          const steps = [];
          const notes = [];
          const rows = [];
          const toks = Array.isArray(raw) ? raw.map(String) : tokenize(raw);
          toks.forEach((tok) => {
            if (/^[0-9]+$/.test(tok)) {
              if (rows.length < 8) rows.push(tok.split("").map(Number));
              else notes.push(tok);
            } else notes.push(tok);
          });
          if (!rows.length) {
            steps.push({
              tracks: [{ label: "tokens seen", cells: toks.map((v) => ({ v })) }],
              title: "Answer: no readable rows — there is no board to swim through",
              counters: [count("answer", "none"), count("tokens seen", toks.length)],
              legend: ["idle"],
              happened: "Every token was skipped, so there is not a single row of digit heights to flood.",
              why: "A swim needs a board; saying so plainly beats inventing cells that were never in the input.",
            });
            return steps;
          }
          let cols = 0;
          rows.forEach((r) => { cols = Math.max(cols, r.length); });
          if (cols > 8) { notes.push("rows longer than 8 (trimmed)"); }
          cols = Math.max(1, Math.min(cols, 8));
          const g = rows.map((r) => {
            const out = r.slice(0, cols);
            while (out.length < cols) out.push(9);
            return out;
          });
          const R = g.length, C = g[0].length;
          const cellState = (states) => window.H.grid(R, C, (r, c) => ({ v: g[r][c], state: states[r][c] || "idle" }));
          const nState = () => g.map((row) => row.map(() => "idle"));
          const setupCells = cellState(nState());
          const gridStep = (extra) => Object.assign({ kind: "grid", rows: R, cols: C, rowHeads: g.map((_, r) => String(r)), colHeads: g[0].map((_, c) => String(c)) }, extra);
          steps.push({
            ...gridStep({
              cells: setupCells,
              label: "(row, column) — numbers are cell heights",
            }),
            title: `Setup: ${R}×${C} board, water starts at the corner height ${g[0][0]}`,
            counters: [count("board", R + "×" + C), count("water level", g[0][0]), count("cells reached", 1, R * C)],
            legend: ["read", "done", "result", "idle"],
            happened: `Cell (0,0) has height ${g[0][0]}, so the swim begins the moment the water reaches level ${g[0][0]}. The goal is the far corner (${R - 1},${C - 1}) with height ${g[R - 1][C - 1]}.`,
            why: "Water level and time are the same thing; a cell is standable exactly when its height is under the current level.",
            codeLine: 8,
          });
          if (notes.length) {
            steps.push({
              ...gridStep({ cells: setupCells }),
              title: "Heads up: " + notes.length + " token" + (notes.length === 1 ? "" : "s") + " skipped",
              counters: [count("tokens skipped", notes.length)],
              happened: "These tokens were not rows of digits and were left out: " + notes.join(", ") + ".",
              why: "Skipping unreadable rows keeps the flood honest about what it can actually read.",
            });
          }
          const seen = g.map((row) => row.map(() => 0));
          seen[0][0] = 1;
          const parent = g.map((row) => row.map(() => null));
          let t = g[0][0];
          const pushLevel = (newCells, level) => {
            const st = nState();
            for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) st[r][c] = seen[r][c] ? "done" : "idle";
            newCells.forEach(([r, c]) => { st[r][c] = "read"; });
            const reached = seen.flat().filter(Boolean).length;
            steps.push({
              ...gridStep({ cells: cellState(st) }),
              title: newCells.length
                ? `Water at ${level} — ${newCells.length} new cell${newCells.length === 1 ? "" : "s"} flooded: ${newCells.map(([r, c]) => `(${r},${c})`).join(", ")}`
                : `Water at ${level} — no new cell is low enough`,
              counters: [count("water level", level), count("cells reached", reached, R * C)],
              legend: ["read", "done", "idle"],
              happened: newCells.length
                ? `The region now covers ${reached} of ${R * C} cells; the newest ones are ringed in green.`
                : `Cells next to the region still poke above the water, so the swimmer has nowhere new to go.`,
              why: newCells.length
                ? "When several cells flood at once the region can jump across them, so one step may open up a lot of ground."
                : "Stalled levels are honest waiting, not progress — the answer is set by the tallest single cell on the lucky route, not by the average height.",
              codeLine: 11,
            });
          };
          while (!seen[R - 1][C - 1]) {
            t++;
            const fresh = [];
            let grew = true;
            while (grew) {
              grew = false;
              for (let r = 0; r < R; r++) {
                for (let c = 0; c < C; c++) {
                  if (!seen[r][c] || g[r][c] > t) continue;
                  const nb = [[r + 1, c], [r - 1, c], [r, c + 1], [r, c - 1]];
                  nb.forEach(([nr, nc]) => {
                    if (nr < 0 || nc < 0 || nr >= R || nc >= C) return;
                    if (!seen[nr][nc] && g[nr][nc] <= t) {
                      seen[nr][nc] = 1; grew = true;
                      parent[nr][nc] = [r, c];
                      fresh.push([nr, nc]);
                    }
                  });
                }
              }
            }
            pushLevel(fresh, t);
          }
          const path = [];
          let cur = [R - 1, C - 1];
          while (cur) {
            path.push(cur);
            cur = parent[cur[0]][cur[1]];
          }
          const pathSet = new Set(path.map(([r, c]) => r + "," + c));
          const st = nState();
          for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) st[r][c] = pathSet.has(r + "," + c) ? "result" : seen[r][c] ? "done" : "dim";
          steps.push({
            ...gridStep({ cells: cellState(st), label: "the accepted route: " + path.slice().reverse().map(([r, c]) => `(${r},${c})`).join(" → ") }),
            title: `Answer: swim at ${t} seconds — the route's tallest cell is ${t}`,
            counters: [count("answer", t), count("cells reached", seen.flat().filter(Boolean).length, R * C), count("route length", path.length)],
            legend: ["result", "done", "dim"],
            happened: `At level ${t} the far corner connects to the start. The amber route has ${path.length} cells and its highest cell is exactly ${t}.`,
            why: "The swimmer waits for the worst cell on some route — no lower level can open a way through that cell, and no higher level is needed.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     5. Find the City With Fewest Neighbours — Floyd-Warshall
     ========================================================== */
  V.register({
    id: "find-the-city-with-fewest-neighbors",
    title: "Find the City With Fewest Neighbors",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Price every shortest route first, then count how many cities sit within a distance budget.",
    input: { label: "n= threshold= then two-way edges a,b,w", default: "n=4 threshold=4 0,1,3 1,2,1 2,3,4 0,3,5", parse: "string" },
    approaches: [
      {
        name: "Floyd–Warshall, Then Count",
        complexity: "O(V³) time, O(V²) space",
        idea: [
          "Build a distance table: 0 down the diagonal, the edge weight where a direct road exists, ∞ everywhere else.",
          "Then let every city take a turn as a middle stop. For each middle city k, check every pair (i, j): going i → k → j may be shorter than the road i → j known so far, and if it is, the table is updated.",
          "After all cities have been a middle stop the table holds every shortest distance. Count, for each city, how many other cities lie within the budget; keep the city with the fewest, breaking ties towards the smaller id.",
        ],
        problem: [
          "The triple loop is a fixed V³ regardless of edges — for a long, sparse map running Dijkstra from each city is often cheaper.",
          "The table also stores V² numbers, which grows quickly; nothing here can beat that because the answer needs many pairs.",
        ],
        code: {
          c: `#include <stdio.h>
#define INF 999999

/* all-pairs shortest paths, then count cities within a threshold */
int main(void) {
    int n = 4, thr = 4;
    int d[4][4] = {{0,3,INF,5},{3,0,1,INF},{INF,1,0,4},{5,INF,4,0}};
    for (int k = 0; k < n; k++)            /* k is the middle stop */
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                if (d[i][k] + d[k][j] < d[i][j])
                    d[i][j] = d[i][k] + d[k][j];   /* cheaper via k */
    int best = -1, fewest = n + 1;
    for (int i = 0; i < n; i++) {
        int cnt = 0;
        for (int j = 0; j < n; j++)
            if (i != j && d[i][j] <= thr) cnt++;   /* inside budget */
        if (cnt <= fewest) { fewest = cnt; best = i; }  /* tie: lower id */
    }
    printf("city %d with %d neighbour(s)\\n", best, fewest); /* 3 with 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int main() {
    int n = 4, thr = 4;
    const int INF = 1e9;
    vector<vector<int>> d(n, vector<int>(n, INF));
    for (int i = 0; i < n; i++) d[i][i] = 0;
    auto road = [&](int u, int v, int w) { d[u][v] = d[v][u] = w; };
    road(0,1,3); road(1,2,1); road(2,3,4); road(0,3,5);

    for (int k = 0; k < n; k++)                 // try k as a middle city
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                d[i][j] = min(d[i][j], d[i][k] + d[k][j]);

    int best = -1, fewest = n + 1;
    for (int i = 0; i < n; i++) {
        int cnt = 0;
        for (int j = 0; j < n; j++) if (i != j && d[i][j] <= thr) cnt++;
        if (cnt <= fewest) { fewest = cnt; best = i; }   // ties: smallest id
    }
    cout << "city " << best << " with " << fewest << " neighbour(s)\\n";
}`,
        },
        steps(raw) {
          const steps = [];
          const tokens = tokenize(raw);
          const settings = {};
          const edges = [];
          const notes = [];
          for (const tok of tokens) {
            const m = tok.match(/^([A-Za-z]+)=(\S+)$/);
            if (m) { settings[m[1].toLowerCase()] = m[2]; continue; }
            const parts = tok.split(",").map((p) => p.trim());
            if (parts.length >= 2 && parts.length <= 3 && parts[0] && parts[1] && isIntText(parts[0]) && isIntText(parts[1])) {
              if (parts.length === 3 && (!parts[2] || !Number.isFinite(Number(parts[2])))) { notes.push(tok); continue; }
              const w = parts.length === 3 ? Math.abs(Number(parts[2])) : 1;
              const a = Number(parts[0]), b = Number(parts[1]);
              if (a < 0 || b < 0) { notes.push(tok); continue; }
              edges.push({ a, b, w });
            } else notes.push(tok);
          }
          const labels = new Set();
          edges.forEach((e) => { labels.add(e.a); labels.add(e.b); });
          const maxLabel = labels.size ? Math.max(...labels) : -1;
          let n = parseInt(settings.n, 10);
          if (!Number.isFinite(n) || n < 1) n = Math.max(maxLabel + 1, 1);
          if (n > 8) { n = 8; notes.push("n>8 (capped at 8)"); }
          const ids = [];
          for (let i = 0; i < n; i++) ids.push(i);
          const layout = circleLayout(ids.map(String));
          const det = edges.filter((e) => e.a < n && e.b < n);
          if (det.length !== edges.length) notes.push((edges.length - det.length) + " edge(s) outside 0.." + (n - 1));
          const good = det.slice();
          let thr = parseInt(settings.threshold, 10);
          if (!Number.isFinite(thr)) thr = parseInt(settings.thr, 10);
          const thrLabel = Number.isFinite(thr) ? thr : "∞";
          if (!Number.isFinite(thr)) thr = Infinity;
          const D = ids.map((i) => ids.map((j) => (i === j ? 0 : Infinity)));
          good.forEach((e) => {
            if (e.w < D[e.a][e.b]) { D[e.a][e.b] = e.w; D[e.b][e.a] = e.w; }
          });
          const ever = new Set();
          const INF = Infinity;
          const show = (roundSet) => window.H.grid(n, n, (i, j) => {
            const key = i + "," + j;
            let state;
            if (roundSet && roundSet.has(key)) state = "read";
            else if (ever.has(key)) state = "good";
            else if (i === j) state = "done";
            else state = D[i][j] === INF ? "idle" : "done";
            return { v: D[i][j] === INF ? "∞" : D[i][j], state };
          });
          const allEdges = ids.map(() => []);
          good.forEach((e, i) => {
            allEdges[e.a].push({ to: e.b, w: e.w, ei: i });
            allEdges[e.b].push({ to: e.a, w: e.w, ei: i });
          });
          const nodeSt = {}; ids.forEach((id) => { nodeSt[id] = "idle"; });
          const setupTracks = [edgeTrack("two-way roads (weight)", good, good.map(() => "done"))];
          steps.push({
            title: `Setup: ${n} cities, ${good.length} two-way roads, budget ${thrLabel}`,
            ...gstage(layout, nodeSt, good, good.map(() => undefined), false),
            tracks: setupTracks,
            counters: [count("cities", n), count("roads", good.length), count("budget", thrLabel)],
            legend: ["read", "done", "idle"],
            happened: `The question: from which city can you reach the fewest other cities without spending more than ${thrLabel}?`,
            why: "Shortest distances between every pair are needed before any city can be judged, which is exactly what the table below will hold.",
            codeLine: 6,
          });
          if (notes.length) steps.push({ ...noteStep(setupTracks, notes), ...gstage(layout, nodeSt, good, good.map(() => undefined), false) });
          steps.push({
            kind: "grid", rows: n, cols: n,
            rowHeads: ids.map(String), colHeads: ids.map(String),
            cells: show(null),
            title: "Distance table: 0 on the diagonal, road weights, ∞ elsewhere",
            counters: [count("cities", n), count("pairs in table", n * n)],
            legend: ["read", "good", "done", "idle"],
            happened: `Each row is a starting city and each column a destination. ∞ means "no road known yet".`,
            why: "Starting from direct roads only, the table will be improved step by step until every entry is a true shortest distance.",
            codeLine: 7,
          });
          for (let k = 0; k < n; k++) {
            const rset = new Set();
            for (let i = 0; i < n; i++) {
              for (let j = 0; j < n; j++) {
                if (i === k || j === k || i === j) continue;
                const cand = D[i][k] + D[k][j];
                if (cand < D[i][j]) {
                  D[i][j] = cand;
                  rset.add(i + "," + j);
                  ever.add(i + "," + j);
                }
              }
            }
            const improved = [...rset].map((key) => {
              const [i, j] = key.split(",").map(Number);
              return `${i}→${j} = ${D[i][j]}`;
            });
            steps.push({
              kind: "grid", rows: n, cols: n,
              rowHeads: ids.map(String), colHeads: ids.map(String),
              cells: show(rset),
              title: improved.length
                ? `Route through city ${k}: ${improved.length} pair${improved.length === 1 ? "" : "s"} get cheaper (${improved.join(", ")})`
                : `Route through city ${k}: nothing gets cheaper`,
              counters: [count("middle cities tried", k + 1, n), count("pairs improved so far", ever.size)],
              legend: ["read", "good", "done", "idle"],
              happened: improved.length
                ? `Going via ${k} shortens ${improved.join(", ")} — those pairs are the green cells.`
                : `Every route that passes through ${k} already had a shorter alternative, so the table stands pat.`,
              why: "Trying every city as a middle stop explores all routes of the form i → … → k → … → j in a fixed, provably complete order.",
              codeLine: 8,
            });
          }
          const counts = ids.map(() => 0);
          ids.forEach((i) => {
            const inside = [];
            ids.forEach((j) => {
              if (i !== j && D[i][j] <= thr) { counts[i]++; inside.push(j); }
            });
            const st = window.H.grid(n, n, (r, c) => {
              if (r !== i) return { v: D[r][c] === INF ? "∞" : D[r][c], state: "done" };
              if (c === i) return { v: 0, state: "done" };
              return { v: D[r][c] === INF ? "∞" : D[r][c], state: D[r][c] <= thr ? "good" : "dim" };
            });
            steps.push({
              kind: "grid", rows: n, cols: n,
              rowHeads: ids.map(String), colHeads: ids.map(String),
              cells: st,
              title: `City ${i}: ${counts[i]} neighbour${counts[i] === 1 ? "" : "s"} within ${thrLabel}` + (inside.length ? ` — {${inside.join(", ")}}` : ""),
              counters: [count("cities counted", i + 1, n), count("neighbours of city " + i, counts[i])],
              legend: ["good", "dim", "done"],
              happened: inside.length
                ? `Row ${i} is green wherever the distance is at most ${thrLabel}: ${inside.map((j) => `${i}→${j} (${D[i][j]})`).join(", ")}.`
                : `No other city is within ${thrLabel} of city ${i}.`,
              why: "Counting the finished table is cheap and exact — no search is needed per city any more.",
              codeLine: 16,
            });
          });
          let best = 0;
          for (let i = 1; i < n; i++) if (counts[i] <= counts[best]) best = i;
          steps.push({
            title: `Answer: city ${best} with ${counts[best]} neighbour${counts[best] === 1 ? "" : "s"} within ${thrLabel}`,
            ...gstage(layout, ids.reduce((acc, id) => {
              acc[id] = id === best ? "result" : counts[id] === counts[best] ? "good" : "done";
              return acc;
            }, {}), good, good.map(() => undefined), false),
            tracks: [{ label: "neighbours within budget", cells: ids.map((id) => ({ v: counts[id], state: id === best ? "result" : "done", tag: String(id) })) }],
            counters: [count("cities", n), count("answer", "city " + best + " (" + counts[best] + ")")],
            legend: ["result", "good", "done"],
            happened: `Every city has been counted; city ${best} reaches the fewest others (${counts[best]}) inside a budget of ${thrLabel}.${ids.some((id) => id < best && counts[id] === counts[best]) ? " Ties were broken towards the smallest city id." : ""}`,
            why: "Because the table holds true shortest distances, the counts are trustworthy counts of reachable neighbours, not guesses.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     6. Reconstruct Itinerary — Hierholzer's walk
     ========================================================== */
  V.register({
    id: "reconstruct-itinerary",
    title: "Reconstruct Itinerary",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Use every ticket exactly once and spell out the trip, always preferring the smallest destination.",
    input: { label: "tickets like JFK,SFO ATL,ORD", default: "JFK,SFO JFK,ATL ATL,ORD SFO,ORD ORD,JFK", parse: "string" },
    approaches: [
      {
        name: "Hierholzer's Greedy Walk",
        complexity: "O(E log E) time (sorting), O(E) space",
        idea: [
          "Every ticket is an edge; using them all exactly once means finding an Eulerian trail. Sort each airport's departures alphabetically and always take the smallest unused ticket from where you currently stand — that yields the smallest itinerary among all valid ones.",
          "Keep a stack of the walk. When you land somewhere with no unused tickets, you have found a dead end: record that airport and step back one. Both moves only ever move a ticket or an airport between two lists.",
          "When the stack empties, the recorded dead ends, read backwards, are exactly the itinerary.",
        ],
        problem: [
          "The greedy smallest-first walk only produces a complete itinerary when one exists. If some airport has more departures than arrivals (or the tickets split into disconnected groups) the walk runs out of tickets early — which is the honest signal that no single itinerary is possible.",
          "Sorting all departures costs time up front even though most of them are never compared again.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

/* airports numbered alphabetically; 0=ATL 1=JFK 2=ORD 3=SFO.
   Out-lists are stored in reverse so the tail is the smallest. */
int main(void) {
    const char *name[4] = {"ATL", "JFK", "ORD", "SFO"};
    int out[4][4] = {{0},{3,0},{2},{1}}, cnt[4] = {0,2,1,1};
    int walk[8], sp = 0, route[8], rp = 0;
    walk[sp++] = 1;                       /* start at JFK */
    while (sp > 0) {
        int u = walk[sp - 1];
        if (cnt[u] > 0)
            walk[sp++] = out[u][--cnt[u]];
        else
            route[rp++] = walk[--sp];     /* dead end: record it */
    }
    for (int i = rp - 1; i >= 0; i--)     /* read the dead ends back */
        printf("%s ", name[route[i]]);
    printf("\\n");                         /* JFK ATL ORD JFK SFO ORD */
    return 0;
}`,
          cpp: `#include <algorithm>
#include <iostream>
#include <map>
#include <set>
#include <stack>
#include <string>
#include <vector>
using namespace std;

int main() {
    vector<vector<string>> t = {{"JFK","SFO"},{"JFK","ATL"},{"ATL","ORD"},{"SFO","ORD"},{"ORD","JFK"}};
    map<string, multiset<string>> dep;
    for (auto& p : t) dep[p[0]].insert(p[1]);   // sorted departures

    stack<string> walk;
    vector<string> route;
    walk.push("JFK");
    while (!walk.empty()) {
        string u = walk.top();
        if (!dep[u].empty()) {
            string v = *dep[u].begin();           // smallest ticket first
            dep[u].erase(dep[u].begin());
            walk.push(v);
        } else {
            route.push_back(u);                   // dead end
            walk.pop();
        }
    }
    reverse(route.begin(), route.end());          // read back-to-front
    for (auto& a : route) cout << a << ' ';
    cout << '\\n';
}`,
        },
        steps(raw) {
          const steps = [];
          const tokens = tokenize(raw);
          let edges = [];
          const notes = [];
          for (const tok of tokens) {
            const parts = tok.split(",").map((p) => p.trim());
            if (parts.length === 2 && /^[A-Za-z0-9]{1,4}$/.test(parts[0]) && /^[A-Za-z0-9]{1,4}$/.test(parts[1])) {
              edges.push({ a: parts[0], b: parts[1] });
            } else notes.push(tok);
          }
          const ids = [...new Set(edges.flatMap((e) => [e.a, e.b]))].sort();
          if (ids.length > 12) {
            notes.push("more than 12 airports (kept the first 12)");
            const keep = new Set(ids.slice(0, 12));
            edges = edges.filter((e) => keep.has(e.a) && keep.has(e.b));
          }
          const layout = circleLayout(ids);
          const start = ids.indexOf("JFK") >= 0 ? "JFK" : ids[0];
          const ticketCells = (states) => ({
            label: "tickets (origin → destination)",
            cells: edges.length
              ? edges.map((e, i) => ({ v: e.a + "→" + e.b, state: (states && states[i]) || "idle" }))
              : [{ v: "no tickets", state: "idle", empty: true }],
          });
          const stackCells = (st) => ({
            label: "walk (stack, last on top)",
            cells: st.length ? st.map((x, i) => ({ v: x, state: i === st.length - 1 ? "read" : "active", tag: String(i) })) : [{ v: "empty", state: "idle", empty: true }],
          });
          const routeCells = (rt) => ({
            label: "recorded dead ends (read back-to-front at the end)",
            cells: rt.length ? rt.map((x) => ({ v: x, state: "done" })) : [{ v: "empty", state: "idle", empty: true }],
          });
          if (!edges.length) {
            steps.push({
              title: "No tickets at all",
              ...gstage(circleLayout(["JFK"]), { JFK: "idle" }, [], [], true),
              tracks: [ticketCells([])],
              counters: [count("tickets", 0)],
              legend: ["good", "idle"],
              happened: "The input had no usable a,b ticket tokens, so there is nothing to arrange into a trip.",
              why: "An empty list of tickets has exactly one itinerary: the empty one — no algorithm needed.",
            });
            steps.push({
              title: "Answer: nothing to reconstruct — give tickets like JFK,SFO ATL,ORD",
              ...gstage(circleLayout(["JFK"]), { JFK: "bad" }, [], [], true),
              tracks: [{ label: "tickets", cells: [{ v: "none", state: "bad", empty: true }] }],
              counters: [count("answer", "no tickets")],
              legend: ["bad", "idle"],
              happened: "No ticket was read, so no itinerary exists to report.",
              why: "Failing loudly beats inventing airports.",
            });
            return steps;
          }
          const eKeep = edges.map(() => undefined);
          const nodeSt = {}; ids.forEach((id) => { nodeSt[id] = "idle"; });
          const setupTracks = [ticketCells(eKeep), stackCells([]), routeCells([])];
          steps.push({
            title: `Setup: ${edges.length} ticket${edges.length === 1 ? "" : "s"}, ${ids.length} airports, start at ${start}`,
            ...gstage(layout, nodeSt, edges, eKeep),
            tracks: setupTracks,
            counters: [count("tickets", edges.length), count("airports", ids.length)],
            legend: ["read", "active", "good", "idle"],
            happened: ids.indexOf("JFK") >= 0
              ? "Each ticket is a directed edge: departure → arrival. The trip must use all of them exactly once, starting at JFK."
              : `No JFK ticket found, so the trip starts at ${start}; each ticket must still be used exactly once.`,
            why: "Using every edge once is precisely an Eulerian trail, which is why the ticket count decides everything.",
            codeLine: 6,
          });
          if (notes.length) steps.push({ ...noteStep(setupTracks, notes), ...gstage(layout, nodeSt, edges, eKeep) });
          edges = edges.slice().sort((x, y) => (x.a === y.a ? (x.b < y.b ? -1 : x.b > y.b ? 1 : 0) : x.a < y.a ? -1 : 1));
          const ptr = {}; ids.forEach((id) => { ptr[id] = 0; });
          const buckets = {}; ids.forEach((id) => { buckets[id] = []; });
          edges.forEach((e, i) => { buckets[e.a].push({ to: e.b, ei: i }); });
          Object.keys(buckets).forEach((k) => buckets[k].sort((x, y) => (x.to < y.to ? -1 : x.to > y.to ? 1 : x.ei - y.ei)));
          steps.push({
            title: "Sort every airport's departures — smallest destination first",
            ...gstage(layout, nodeSt, edges, eKeep),
            tracks: [ticketCells(edges.map(() => "done")), stackCells([]), routeCells([])],
            counters: [count("tickets", edges.length), count("airports", ids.length)],
            legend: ["read", "active", "good", "idle"],
            happened: "Departures now sit in alphabetical order: " + ids.filter((id) => buckets[id].length).map((id) => `${id} → [${buckets[id].map((b) => b.to).join(", ")}]`).join("; ") + ".",
            why: "Taking the smallest remaining departure at each airport is what makes the final itinerary the smallest one possible.",
            codeLine: 8,
          });
          const walk = [start];
          const route = [];
          nodeSt[start] = "read";
          let guard = 0;
          while (walk.length && guard++ < edges.length * 4 + 20) {
            const u = walk[walk.length - 1];
            const list = buckets[u];
            if (ptr[u] < list.length) {
              const nx = list[ptr[u]++];
              const v = nx.to;
              eKeep[nx.ei] = "good";
              walk.push(v);
              const ns = {}; ids.forEach((id) => { ns[id] = walk.indexOf(id) >= 0 ? "active" : eKeep.some((s, i) => s === "good" && (edges[i].a === id || edges[i].b === id)) ? "done" : "idle"; });
              ns[v] = "read";
              steps.push({
                title: `At ${u}: take the smallest unused ticket ${u}→${v}`,
                ...gstage(layout, ns, edges, eKeep),
                tracks: [ticketCells(eKeep), stackCells(walk), routeCells(route)],
                counters: [count("tickets used", eKeep.filter((s) => s === "good").length, edges.length), count("steps walked", walk.length - 1)],
                legend: ["read", "active", "good", "idle"],
                happened: `Land in ${v}. The walk so far reads ${walk.join(" → ")}.`,
                why: "Always taking the smallest departure is safe: an Eulerian trail is still possible from any point that isn't a dead end.",
                codeLine: 10,
              });
            } else {
              walk.pop();
              route.push(u);
              const ns = {}; ids.forEach((id) => { ns[id] = walk.indexOf(id) >= 0 ? "active" : "done"; });
              ns[u] = "read";
              steps.push({
                title: `${u} has no unused tickets left — record ${u} and step back`,
                ...gstage(layout, ns, edges, eKeep),
                tracks: [ticketCells(eKeep), stackCells(walk), routeCells(route)],
                counters: [count("tickets used", eKeep.filter((s) => s === "good").length, edges.length), count("airports recorded", route.length)],
                legend: ["read", "active", "good", "idle"],
                happened: walk.length
                  ? `${u} is a dead end for now, so it joins the record; the walk resumes at ${walk[walk.length - 1]}.`
                  : `${u} is the last airport — the walk is finished.`,
                why: "Recording dead ends in the order they run out, then reversing at the end, is Hierholzer's trick for stitching the trail together.",
                codeLine: 13,
              });
            }
          }
          const complete = route.length === edges.length + 1;
          if (complete) {
            const itinerary = route.slice().reverse();
            steps.push({
              title: `Answer: ${itinerary.join(" → ")}`,
              ...gstage(layout, ids.reduce((acc, id) => { acc[id] = "good"; return acc; }, {}), edges, edges.map(() => "good")),
              tracks: [{ label: "itinerary (all tickets used once)", cells: itinerary.map((x, i) => ({ v: x, state: "result", tag: i === 0 ? "start" : i === itinerary.length - 1 ? "end" : undefined })) }, ticketCells(edges.map(() => "good"))],
              counters: [count("tickets used", edges.length, edges.length), count("airports in trip", itinerary.length), count("answer", itinerary.join(" "))],
              legend: ["result", "good"],
              happened: `Reading the ${route.length} recorded airports back-to-front gives ${itinerary.length} stops and uses every ticket exactly once.`,
              why: "Greedy smallest-first plus Hierholzer's backtracking is why this itinerary is both valid and the smallest one.",
              codeLine: 16,
            });
          } else {
            const unused = eKeep.filter((s) => s !== "good").length;
            steps.push({
              title: `Answer: no single itinerary is possible — ${unused} ticket${unused === 1 ? "" : "s"} left unused`,
              ...gstage(layout, ids.reduce((acc, id) => { acc[id] = "bad"; return acc; }, {}), edges, eKeep),
              tracks: [ticketCells(eKeep), stackCells(walk), routeCells(route)],
              counters: [count("tickets used", edges.length - unused, edges.length), count("answer", "impossible")],
              legend: ["read", "active", "good", "bad"],
              happened: `The walk stranded ${unused} ticket${unused === 1 ? "" : "s"} because it could not leave an airport that had departures waiting: the departures and arrivals don't line up.`,
              why: "A single trail needs arrivals and departures to balance at every airport except the trip's two ends; when that breaks, the greedy walk hits a wall with tickets still in hand.",
              codeLine: 13,
            });
          }
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     7. Alien Dictionary — first differences, then Kahn
     ========================================================== */
  V.register({
    id: "alien-dictionary",
    title: "Alien Dictionary",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Recover the alien alphabet's letter order from a list of words that are already sorted.",
    input: { label: "Words in alien order", default: "wrt wrf ete rttt at", parse: "string" },
    approaches: [
      {
        name: "First-Difference Rules + Kahn's Order",
        complexity: "O(L + V + E) time, O(V + E) space",
        idea: [
          "Compare neighbouring words. Everything they share up to the first differing letter tells nothing new; the very first differing pair (a, b) is a rule: a comes before b in the alien alphabet.",
          "Collect the rules as a graph of letters. A legal letter order is a topological order of that graph: repeatedly take a letter that no remaining rule keeps waiting, place it, and delete its rules.",
          "If two rules force a letter to wait on itself (a cycle), the word list can't come from any alphabet — say so plainly instead of guessing. When several letters are free at once, any of them works; picking the smallest keeps the answer tidy.",
        ],
        problem: [
          "The order is often not unique: the graph only records rules the words actually imply, so ties are real. The answer is one valid order, not the order.",
          "A prefix pair such as \"ab\" appearing after \"abc\" is an instant contradiction — no alphabet can make the longer word sort first.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>
#include <stdbool.h>

/* recover a letter order from adjacent word pairs */
int main(void) {
    const char *w[] = {"wrt", "wrf", "ete", "rttt", "at"};
    int n = 5, indeg[26] = {0}, rule[26][26] = {{0}};
    bool present[26] = {false};
    for (int i = 0; i < n; i++)
        for (const char *p = w[i]; *p; p++) present[*p - 'a'] = true;
    for (int i = 0; i + 1 < n; i++) {          /* one rule per pair */
        const char *a = w[i], *b = w[i + 1];
        int j = 0;
        while (a[j] && a[j] == b[j]) j++;      /* skip the shared part */
        if (!a[j]) continue;                   /* a is a prefix: fine */
        if (!b[j]) return 1;                   /* b is a prefix: broken */
        if (!rule[a[j]-'a'][b[j]-'a']) { rule[a[j]-'a'][b[j]-'a'] = 1; indeg[b[j]-'a']++; }
    }
    char order[27]; int len = 0;
    for (int placed = 0; placed < 26; placed++) {
        int pick = -1;
        for (int c = 0; c < 26; c++)
            if (present[c] && indeg[c] == 0) { pick = c; break; }
        if (pick < 0) break;                   /* cycle or done */
        present[pick] = false; order[len++] = (char)('a' + pick);
        for (int c = 0; c < 26; c++)
            if (rule[pick][c]) indeg[c]--;
    }
    order[len] = 0;
    printf("%s\\n", order);                     /* twfear */
    return 0;
}`,
          cpp: `#include <algorithm>
#include <iostream>
#include <set>
#include <string>
#include <vector>
using namespace std;

int main() {
    vector<string> w = {"wrt", "wrf", "ete", "rttt", "at"};
    set<char> letters;
    for (auto& s : w) for (char c : s) letters.insert(c);
    auto before = [](char a, char b) { return make_pair(a, b); };
    vector<pair<char, char>> rules;
    bool broken = false;
    for (size_t i = 0; i + 1 < w.size(); i++) {
        size_t j = 0;
        while (j < w[i].size() && j < w[i+1].size() && w[i][j] == w[i+1][j]) j++;
        if (j == w[i].size()) continue;                  // prefix: fine
        if (j == w[i+1].size()) { broken = true; break; } // out of order
        rules.push_back(before(w[i][j], w[i+1][j]));
    }
    string order;
    set<char> left = letters;
    while (!left.empty() && !broken) {
        char pick = 0;
        for (char c : left)
            if (none_of(rules.begin(), rules.end(), [&](auto& r) {
                    return r.second == c && left.count(r.first);
                })) { pick = c; break; }                 // nothing blocks c
        if (!pick) break;                                // cycle
        order += pick;
        left.erase(pick);
    }
    if (left.empty()) cout << order << '\\n';            // twfear
    else cout << "no valid order\\n";
}`,
        },
        steps(raw) {
          const steps = [];
          const notes = [];
          let words = tokenize(raw).slice(0, 20);
          if (tokenize(raw).length > 20) notes.push("more than 20 words (kept the first 20)");
          words = words.filter((w) => /^[A-Za-z]{1,16}$/.test(w));
          const letters = [...new Set(words.join("").split(""))].sort();
          const layout = circleLayout(letters);
          const nodeSt = {}; letters.forEach((c) => { nodeSt[c] = "idle"; });
          const wordTrack = (hl) => ({
            label: "words (alien order)",
            cells: words.length
              ? words.map((w, i) => ({ v: w, state: hl && hl.indexOf(i) >= 0 ? "read" : "done" }))
              : [{ v: "none", state: "idle", empty: true }],
          });
          const orderTrack = (order, hl) => ({
            label: "alphabet so far",
            cells: order.length
              ? order.map((c, i) => ({ v: c, state: i === order.length - 1 && hl ? "read" : "result", tag: String(i) }))
              : [{ v: "empty", state: "idle", empty: true }],
          });
          const rules = [];
          const ruleKeys = new Set();
          const eKeep = [];
          if (!words.length || !letters.length) {
            steps.push({
              title: "No usable words in the input",
              ...gstage(circleLayout([]), {}, [], []),
              tracks: [{ label: "words (alien order)", cells: [{ v: "none", state: "idle", empty: true }] }],
              counters: [count("words", 0)],
              legend: ["read", "done", "idle"],
              happened: "Nothing that looks like a word was found, so there are no rules to extract.",
              why: "The letter order comes only from comparing words — no words, no clues.",
              codeLine: 3,
            });
            steps.push({
              title: "Answer: no order can be derived — give words like wrt wrf ete rttt at",
              tracks: [{ label: "answer", cells: [{ v: "—", state: "bad", empty: true }] }],
              counters: [count("answer", "none")],
              legend: ["bad", "idle"],
              happened: "With no word list there is nothing to compare, so no alphabet can be reconstructed.",
              why: "Saying 'not enough information' is the honest result here.",
              codeLine: 3,
            });
            return steps;
          }
          steps.push({
            title: `Setup: ${words.length} words over ${letters.length} letters — the order must be recovered`,
            ...gstage(layout, nodeSt, [], []),
            tracks: [wordTrack(null), orderTrack([], false)],
            counters: [count("words", words.length), count("letters", letters.length), count("rules found", 0)],
            legend: ["read", "done", "result", "idle"],
            happened: `The words ${words.join(", ")} are sorted in an alphabet we can't see. Every clue will come from neighbouring pairs.`,
            why: "Non-neighbouring pairs add nothing: sortedness of neighbours already implies everything they chain together.",
            codeLine: 3,
          });
          if (notes.length) steps.push({ ...noteStep([wordTrack(null)], notes), ...gstage(layout, nodeSt, [], []) });
          let invalid = false;
          for (let i = 0; i + 1 < words.length && !invalid; i++) {
            const a = words[i], b = words[i + 1];
            let j = 0;
            while (j < a.length && j < b.length && a[j] === b[j]) j++;
            if (j === a.length) {
              steps.push({
                title: `"${a}" then "${b}": the first is a prefix — fine, no new rule`,
                ...gstage(layout, nodeSt, rules, eKeep),
                tracks: [wordTrack([i, i + 1]), orderTrack([], false)],
                counters: [count("pairs compared", i + 1, words.length - 1), count("rules found", rules.length)],
                legend: ["read", "done", "result", "idle"],
                happened: `"${a}" is a prefix of "${b}", and a shorter word may sort first — nothing to add.`,
                why: "Prefixes carry no letter rule; only a genuine differing position tells the letters apart.",
                codeLine: 9,
              });
              continue;
            }
            if (j === b.length) {
              invalid = true;
              steps.push({
                title: `"${a}" then "${b}": the longer word comes first — contradiction!`,
                ...gstage(layout, letters.reduce((acc, c) => { acc[c] = "idle"; return acc; }, {}), rules, eKeep),
                tracks: [wordTrack([i, i + 1]), orderTrack([], false)],
                counters: [count("pairs compared", i + 1, words.length - 1), count("rules found", rules.length)],
                legend: ["bad", "read", "done", "idle"],
                happened: `"${b}" is a prefix of "${a}", so "${a}" would have to sort before a word it starts with — impossible in any alphabet.`,
                why: "One out-of-order prefix pair poisons the whole list; no letter order can repair it.",
                codeLine: 10,
              });
              break;
            }
            const x = a[j], y = b[j];
            const key = x + y;
            const isNew = !ruleKeys.has(key);
            if (isNew) { ruleKeys.add(key); rules.push({ a: x, b: y }); eKeep.push("read"); }
            else eKeep[rules.findIndex((r) => r.a === x && r.b === y)] = "read";
            const shown = rules.map((r, i2) => (r.a === x && r.b === y ? "read" : eKeep[i2] === "read" ? "good" : eKeep[i2]));
            steps.push({
              title: isNew
                ? `Words "${a}" / "${b}" differ at position ${j + 1}: ${x} comes before ${y}`
                : `Words "${a}" / "${b}" agree with the known rule ${x} before ${y}`,
              ...gstage(layout, { ...nodeSt, [x]: "compare", [y]: "read" }, rules, shown),
              tracks: [wordTrack([i, i + 1]), orderTrack([], false)],
              counters: [count("pairs compared", i + 1, words.length - 1), count("rules found", rules.length)],
              legend: ["read", "compare", "done", "idle"],
              happened: isNew
                ? `Up to letter ${j} the words match; the first mismatch (${x}, ${y}) is a new rule for the graph.`
                : `The same rule was derived again — it's already recorded, so nothing changes.`,
              why: isNew
                ? "A sorted list promises order only at the first mismatch; that single pair is all a rule needs."
                : "Duplicate rules are ignored so the final count reflects real, distinct constraints.",
              codeLine: 12,
            });
            rules.forEach((r, i2) => { if (eKeep[i2] === "read" && !(r.a === x && r.b === y)) eKeep[i2] = "good"; });
          }
          if (invalid) {
            steps.push({
              title: "Answer: no valid order — the word list is inconsistent",
              ...gstage(layout, letters.reduce((acc, c) => { acc[c] = "bad"; return acc; }, {}), rules, eKeep),
              tracks: [wordTrack(null), orderTrack([], false)],
              counters: [count("rules found", rules.length), count("answer", "impossible")],
              legend: ["bad", "read", "done"],
              happened: "The prefix contradiction means these words cannot be sorted in any alphabet, alien or otherwise.",
              why: "Refusing to guess is the correct output; a fabricated order would be silently wrong.",
              codeLine: 10,
            });
            return steps;
          }
          const indeg = {}; letters.forEach((c) => { indeg[c] = 0; });
          rules.forEach((r) => { indeg[r.b]++; });
          const order = [];
          const placed = new Set();
          let picked = 0;
          while (picked < letters.length) {
            const ready = letters.filter((c) => !placed.has(c) && indeg[c] === 0);
            if (!ready.length) break;
            const pick = ready[0];
            placed.add(pick);
            order.push(pick);
            picked++;
            rules.forEach((r, i2) => {
              if (r.a !== pick) return;
              indeg[r.b]--;
              if (indeg[r.b] === 0) eKeep[i2] = "good";
            });
            rules.forEach((r, i2) => { if (eKeep[i2] === "read") eKeep[i2] = "good"; });
            const ns = {}; letters.forEach((c) => { ns[c] = placed.has(c) ? (c === pick ? "read" : "done") : indeg[c] === 0 ? "active" : "idle"; });
            steps.push({
              title: `Place "${pick}" — no rule keeps it waiting`,
              ...gstage(layout, ns, rules, eKeep),
              tracks: [wordTrack(null), orderTrack(order, true)],
              counters: [count("letters placed", placed.size, letters.length), count("rules left", rules.filter((r, i2) => eKeep[i2] !== "good").length)],
              legend: ["read", "active", "done", "idle"],
              happened: `"${pick}" joins the alphabet at position ${order.length - 1}. ` + (ready.length > 1 ? `"${ready[1]}" was also free — ties are broken smallest-first.` : `No other letter was free at this moment.`),
              why: "A letter with no unsatisfied rule can be placed safely; removing its outgoing rules may free the next letter.",
              codeLine: 18,
            });
          }
          if (placed.size < letters.length) {
            const stuck = letters.filter((c) => !placed.has(c));
            steps.push({
              title: `Answer: no valid order — ${stuck.join(", ")} wait on each other in a cycle`,
              ...gstage(layout, letters.reduce((acc, c) => { acc[c] = placed.has(c) ? "done" : "bad"; return acc; }, {}), rules, eKeep),
              tracks: [wordTrack(null), orderTrack(order, false)],
              counters: [count("letters placed", placed.size, letters.length), count("answer", "impossible")],
              legend: ["bad", "done", "idle"],
              happened: `Every remaining letter is blocked by another remaining letter, so the placement loop can never pick again.`,
              why: "A cycle in the rules means each letter must come before another in the cycle — no alphabet satisfies that.",
              codeLine: 22,
            });
            return steps;
          }
          steps.push({
            title: `Answer: ${order.join(" ")} — one valid alien alphabet order`,
            ...gstage(layout, letters.reduce((acc, c) => { acc[c] = "good"; return acc; }, {}), rules, eKeep),
            tracks: [{ label: "alphabet (one valid order)", cells: order.map((c, i) => ({ v: c, state: "result", tag: String(i) })) }],
            counters: [count("letters", letters.length), count("rules used", rules.length), count("answer", order.join(""))],
            legend: ["result", "good"],
            happened: `All ${letters.length} letters were placed: ${order.join(", ")}. It respects every rule pulled from neighbouring words.`,
            why: "The words imply only some rules, so other valid orders may exist — this is one that obeys them all, smallest-first on ties.",
            codeLine: 24,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     8. Strongly Connected Components — Kosaraju, two phases
     ========================================================== */
  V.register({
    id: "strongly-connected-components",
    title: "Strongly Connected Components",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Split a directed graph into the groups of nodes that can all reach each other.",
    input: { label: "n= then directed edges a,b", default: "n=5 1,2 2,3 3,1 3,4 4,5 5,4", parse: "string" },
    approaches: [
      {
        name: "Kosaraju: Finish Order, Then the Reverse",
        complexity: "O(V + E) time, O(V + E) space",
        idea: [
          "First walk the graph depth-first and note each node at the moment its subtree is finished. Finishing order has a special property: the last finished node is guaranteed to sit in a component that no later component can reach backwards.",
          "Then flip every edge and walk again, this time taking the finished nodes in reverse order. Each walk on the flipped graph collects exactly one component: nodes the original edges can't lead out of.",
          "Two clean phases, each a plain DFS — no clever bookkeeping needed beyond the finish list and the reversed edge list.",
        ],
        problem: [
          "The algorithm touches the whole graph twice and needs a second, reversed copy of every edge — cheap in big-O terms but real memory.",
          "Components come out in an order tied to the finish times, not in any natural size or numbering order, so callers usually re-sort the groups.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* phase 1 records a finish order, phase 2 peels components off it */
static bool g[8][8], rg[8][8], vis[8];
static int n = 5, order[8], oc = 0, comp[8], ncomp = 0;

static void dfs1(int u) {
    vis[u] = true;
    for (int v = 0; v < n; v++) if (g[u][v] && !vis[v]) dfs1(v);
    order[oc++] = u;                 /* recorded when u is finished */
}
static void dfs2(int u, int id) {
    vis[u] = true; comp[u] = id;
    for (int v = 0; v < n; v++) if (rg[u][v] && !vis[v]) dfs2(v, id);
}

int main(void) {
    int e[][2] = {{1,2},{2,3},{3,1},{3,4},{4,5},{5,4}}, m = 6;
    for (int i = 0; i < m; i++) { g[e[i][0]-1][e[i][1]-1] = true; rg[e[i][1]-1][e[i][0]-1] = true; }
    for (int u = 0; u < n; u++) if (!vis[u]) dfs1(u);
    for (int u = 0; u < n; u++) vis[u] = false;
    for (int i = oc - 1; i >= 0; i--) {        /* reverse finish order */
        int u = order[i];
        if (!vis[u]) dfs2(u, ncomp++);
    }
    printf("%d components\\n", ncomp);         /* 2 */
    return 0;
}`,
          cpp: `#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;

vector<vector<int>> g, rg;
vector<bool> vis;
vector<int> order, comp;

void dfs1(int u) {
    vis[u] = true;
    for (int v : g[u]) if (!vis[v]) dfs1(v);
    order.push_back(u);                // recorded when u is finished
}
void dfs2(int u, int id) {
    vis[u] = true; comp[u] = id;
    for (int v : rg[u]) if (!vis[v]) dfs2(v, id);
}

int main() {
    int n = 5, e[6][2] = {{1,2},{2,3},{3,1},{3,4},{4,5},{5,4}};
    g.assign(n, {}); rg.assign(n, {}); vis.assign(n, false);
    for (auto& x : e) { g[x[0]-1].push_back(x[1]-1); rg[x[1]-1].push_back(x[0]-1); }
    for (int u = 0; u < n; u++) if (!vis[u]) dfs1(u);
    fill(vis.begin(), vis.end(), false);
    comp.assign(n, -1);
    int ncomp = 0;
    for (int i = n - 1; i >= 0; i--) {         // reverse finish order
        int u = order[i];
        if (!vis[u]) dfs2(u, ncomp++);
    }
    cout << ncomp << " components\\n";         // 2
}`,
        },
        steps(raw) {
          const steps = [];
          const tokens = tokenize(raw);
          const settings = {};
          const edges = [];
          const notes = [];
          for (const tok of tokens) {
            const m = tok.match(/^([A-Za-z]+)=(\S+)$/);
            if (m) { settings[m[1].toLowerCase()] = m[2]; continue; }
            const parts = tok.split(",").map((p) => p.trim());
            if (parts.length === 2 && isIntText(parts[0]) && isIntText(parts[1]) && Number(parts[0]) >= 1 && Number(parts[1]) >= 1) {
              edges.push({ a: Number(parts[0]), b: Number(parts[1]) });
            } else notes.push(tok);
          }
          const labels = new Set();
          edges.forEach((e) => { labels.add(e.a); labels.add(e.b); });
          const maxLabel = labels.size ? Math.max(...labels) : 0;
          let n = parseInt(settings.n, 10);
          if (!Number.isFinite(n) || n < 1) n = maxLabel > 0 ? maxLabel : 1;
          if (n > 12) { n = 12; notes.push("n>12 (capped at 12)"); }
          const ids = [];
          for (let i = 1; i <= n; i++) ids.push(i);
          const layout = circleLayout(ids.map(String));
          const nodeSt = {}; ids.forEach((id) => { nodeSt[id] = "idle"; });
          const eKeep = edges.map(() => undefined);
          const outE = ids.map(() => []);
          const inE = ids.map(() => []);
          edges.forEach((e, i) => { outE[e.a - 1].push(i); inE[e.b - 1].push(i); });
          const orderTrack = (order) => ({
            label: "finish order (last finished is popped first)",
            cells: order.length ? order.map((u, i) => ({ v: u, state: "done", tag: "#" + (i + 1) })) : [{ v: "empty", state: "idle", empty: true }],
          });
          const compsTrack = (comps) => ({
            label: "components found",
            cells: comps.length ? comps.map((c, i) => ({ v: c.join("-"), state: "result", tag: "C" + (i + 1) })) : [{ v: "none yet", state: "idle", empty: true }],
          });
          const pal = ["good", "result", "active", "compare"];
          const setupTracks = [orderTrack([]), compsTrack([])];
          steps.push({
            title: `Setup: ${n} nodes, ${edges.length} directed edges — two depth-first passes ahead`,
            ...gstage(layout, nodeSt, edges, eKeep),
            tracks: setupTracks,
            counters: [count("nodes", n), count("edges", edges.length), count("phase", "1 of 2")],
            legend: ["read", "active", "done", "idle"],
            happened: `A strongly connected component is a group where every node reaches every other. The plan: a finish-order pass on the original edges, then one pass on the reversed edges.`,
            why: "The two-phase split is what makes the component boundaries detectable with nothing but plain DFS.",
            codeLine: 2,
          });
          if (notes.length) steps.push({ ...noteStep(setupTracks, notes), ...gstage(layout, nodeSt, edges, eKeep) });
          const visited = {};
          const order = [];
          const stateOf = (focus, path) => {
            const ns = {};
            ids.forEach((id) => {
              ns[id] = id === focus ? "read" : path.indexOf(id) >= 0 ? "active" : visited[id] ? "done" : "idle";
            });
            return ns;
          };
          const dfs1 = (u, via, path) => {
            visited[u] = true;
            path.push(u);
            const shown = eKeep.slice();
            if (via != null) shown[via] = "read";
            steps.push({
              title: `Phase 1: enter node ${u}${via != null ? ` via ${edges[via].a}→${u}` : " — a fresh walk"}`,
              ...gstage(layout, stateOf(u, path), edges, shown),
              tracks: [orderTrack(order), { label: "current walk", cells: path.map((x) => ({ v: x, state: "active", tag: String(x) })) }],
              counters: [count("nodes visited", Object.keys(visited).length, n), count("finished", order.length, n)],
              legend: ["read", "active", "done", "idle"],
              happened: via != null
                ? `Node ${u} is unvisited, so the walk dives into it; nodes ${path.join(" → ")} are now on the call stack.`
                : `Starting a fresh walk at ${u}; nothing deeper has been visited from here yet.`,
              why: "Nodes are noted only when they are left behind, and that timing is what the second phase will rely on.",
              codeLine: 7,
            });
            outE[u - 1].forEach((ei) => {
              const v = edges[ei].b;
              if (!visited[v]) { eKeep[ei] = "good"; dfs1(v, ei, path); }
              else eKeep[ei] = eKeep[ei] || "dim";
            });
            path.pop();
            order.push(u);
            steps.push({
              title: `Node ${u} finished — recorded ${order.length}${order.length === 1 ? "st" : order.length === 2 ? "nd" : order.length === 3 ? "rd" : "th"} in the finish list`,
              ...gstage(layout, stateOf(null, path), edges, eKeep),
              tracks: [orderTrack(order), { label: "current walk", cells: path.length ? path.map((x) => ({ v: x, state: "active" })) : [{ v: "empty", state: "idle", empty: true }] }],
              counters: [count("nodes visited", Object.keys(visited).length, n), count("finished", order.length, n)],
              legend: ["read", "active", "done", "idle"],
              happened: `Every route out of ${u} has been explored, so it is written down — ${n - order.length} node${n - order.length === 1 ? "" : "s"} still to go.`,
              why: "The moment a node is recorded marks that all its descendants are recorded too — the key property phase 2 exploits.",
              codeLine: 9,
            });
          };
          ids.forEach((u) => { if (!visited[u]) dfs1(u, null, []); });
          const rEdges = edges.map((e) => ({ a: e.b, b: e.a }));
          const rKeep = rEdges.map(() => undefined);
          steps.push({
            title: `Phase 1 done — finish order ${order.join(", ")}; now flip every edge`,
            ...gstage(layout, nodeSt, rEdges, rKeep),
            tracks: [orderTrack(order), compsTrack([])],
            counters: [count("nodes", n), count("edges flipped", edges.length), count("phase", "2 of 2")],
            legend: ["read", "done", "idle"],
            happened: `The last recorded node is ${order[order.length - 1]}, which begins phase 2. The graph above shows every arrow reversed.`,
            why: "On the flipped graph, nodes reachable from a node are exactly those that could reach it in the original — turning 'who can reach me' into a forward walk.",
            codeLine: 13,
          });
          const visited2 = {};
          const comps = [];
          const compColor = {};
          const colored = (focus, path) => {
            const ns = {};
            ids.forEach((id) => {
              ns[id] = id === focus ? "read" : path.indexOf(id) >= 0 ? "active" : compColor[id] || "idle";
            });
            return ns;
          };
          for (let i = order.length - 1; i >= 0; i--) {
            const u = order[i];
            if (visited2[u]) continue;
            const cid = comps.length;
            const rec = [];
            const dfs2rec = (x) => {
              visited2[x] = true;
              compColor[x] = pal[cid % pal.length];
              rec.push(x);
              steps.push({
                title: `Phase 2: node ${x} joins component C${cid + 1}`,
                ...gstage(layout, colored(x, rec), rEdges, rKeep),
                tracks: [orderTrack(order.slice().reverse()), compsTrack(comps.concat([rec.slice()]))],
                counters: [count("components", comps.length + 1), count("in C" + (cid + 1), rec.length), count("nodes assigned", Object.keys(visited2).length, n)],
                legend: ["read", "active", "done", "idle"],
                happened: `From ${x} the flipped edges reach ${rec.join(", ")} — all of them belong to this component.`,
                why: "Nodes collected here cannot be split apart: the walk would have been able to hop between them using reversed (i.e. original forward) edges.",
                codeLine: 17,
              });
              inE[x - 1].forEach((ei) => {
                const v = edges[ei].a;
                if (!visited2[v]) { rKeep[ei] = "good"; dfs2rec(v); }
              });
            };
            dfs2rec(u);
            comps.push(rec.slice());
            steps.push({
              title: `Component C${comps.length} complete: ${comps[comps.length - 1].join(", ")}`,
              ...gstage(layout, ids.reduce((acc, id) => { acc[id] = compColor[id] || "idle"; return acc; }, {}), rEdges, rKeep),
              tracks: [orderTrack(order.slice().reverse()), compsTrack(comps)],
              counters: [count("components", comps.length), count("largest so far", Math.max(...comps.map((c) => c.length))), count("nodes assigned", Object.keys(visited2).length, n)],
              legend: ["read", "good", "result", "idle"],
              happened: `The walk closed without leaving the group: ${comps[comps.length - 1].join(", ")} are mutually reachable in the original graph.`,
              why: "Finishing order guarantees no edge of the original graph leaves this group backwards into an unassigned node.",
              codeLine: 21,
            });
          }
          const legend = ["result", "good"];
          const legendLabels = { result: "first component(s)", good: "other components" };
          steps.push({
            title: `Answer: ${comps.length} strongly connected component${comps.length === 1 ? "" : "s"} — ${comps.map((c) => "{" + c.join(",") + "}").join(" ")}`,
            ...gstage(layout, ids.reduce((acc, id) => { acc[id] = compColor[id] || "result"; return acc; }, {}), [], []),
            tracks: [compsTrack(comps), orderTrack(order)],
            counters: [count("nodes", n), count("answer", comps.length + " component" + (comps.length === 1 ? "" : "s"))],
            legend,
            legendLabels,
            happened: `Every node now wears its component's colour: ${comps.map((c) => "{" + c.join(",") + "}").join(", ")}. Inside each colour every node reaches every other.`,
            why: "Two DFS passes and one reversed edge list — the components fall out without ever comparing nodes pairwise.",
            codeLine: 22,
          });
          return steps;
        },
      },
    ],
  });

  /* ==========================================================
     9. Minimum Edges to Strongly Connect — Tarjan + condensation
     ========================================================== */
  V.register({
    id: "minimum-edges-to-strongly-connect-a-graph",
    title: "Minimum Edges to Strongly Connect a Graph",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Shrink each mutual-reachability group to a single dot, then count how few extra arrows glue everything into one.",
    input: { label: "n= then directed edges a,b", default: "n=4 1,2 2,1 3,4 4,3", parse: "string" },
    approaches: [
      {
        name: "Tarjan, Then Count Sources and Sinks",
        complexity: "O(V + E) time, O(V + E) space",
        idea: [
          "Tarjan finds every strongly connected component in one DFS. Each node carries an index (visit order) and a low-link: the smallest index reachable from its subtree. When a node's low-link equals its own index, its subtree is a complete component and can be popped off the stack.",
          "Collapse each component to one dot: this condensation is always a DAG. What remains is a small forest of arrows between components.",
          "To make the whole thing strongly connected, every component with no incoming arrow (a source) must gain one, and every component with no outgoing arrow (a sink) must gain one. Sinks can be chained into sources, so the answer is max(sources, sinks) — and 0 when the graph already is one component.",
        ],
        problem: [
          "The formula max(sources, sinks) only holds because the condensation is acyclic; on the original graph no such shortcut exists.",
          "Tarjan's low-link bookkeeping is notoriously easy to get subtly wrong — one missed case and components merge or split incorrectly.",
        ],
        code: {
          c: `#include <stdio.h>

/* Tarjan components, then sources/sinks of the condensation */
#define MAXV 12
static int g[MAXV][MAXV], n;
static int idx[MAXV], low[MAXV], stk[MAXV], sp, timer, ncomp;
static int on[MAXV], comp[MAXV];

static void tarjan(int u) {
    idx[u] = low[u] = timer++;
    stk[sp++] = u; on[u] = 1;
    for (int v = 0; v < n; v++) {
        if (!g[u][v]) continue;
        if (idx[v] < 0) {                     /* tree edge */
            tarjan(v);
            if (low[v] < low[u]) low[u] = low[v];
        } else if (on[v] && idx[v] < low[u]) {
            low[u] = idx[v];                  /* back edge */
        }
    }
    if (low[u] == idx[u]) {                   /* u roots a component */
        int v;
        do { v = stk[--sp]; on[v] = 0; comp[v] = ncomp; } while (v != u);
        ncomp++;
    }
}

int main(void) {
    int e[][2] = {{1,2},{2,1},{3,4},{4,3}}, m = 4;
    n = 4;
    for (int i = 0; i < MAXV; i++) idx[i] = -1;
    for (int i = 0; i < m; i++) g[e[i][0]-1][e[i][1]-1] = 1;
    for (int u = 0; u < n; u++) if (idx[u] < 0) tarjan(u);
    int src[MAXV] = {0}, sink[MAXV] = {0};
    for (int u = 0; u < n; u++)
        for (int v = 0; v < n; v++)
            if (g[u][v] && comp[u] != comp[v]) { sink[comp[u]] = 1; src[comp[v]] = 1; }
    int ns = 0, nk = 0;
    for (int c = 0; c < ncomp; c++) { if (src[c]) ns++; if (sink[c]) nk++; }
    printf("%d\\n", ncomp > 1 ? (ns > nk ? ns : nk) : 0);   /* 2 */
    return 0;
}`,
          cpp: `#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;

vector<vector<int>> g;
vector<int> idx, low, stk, comp;
vector<char> onStack;
int timer = 0, ncomp = 0;

void tarjan(int u) {
    idx[u] = low[u] = timer++;
    stk.push_back(u); onStack[u] = 1;
    for (int v : g[u]) {
        if (idx[v] < 0) {                     // tree edge
            tarjan(v);
            low[u] = min(low[u], low[v]);
        } else if (onStack[v]) {
            low[u] = min(low[u], idx[v]);     // back edge
        }
    }
    if (low[u] == idx[u]) {                   // u roots a component
        int v;
        do { v = stk.back(); stk.pop_back(); onStack[v] = 0; comp[v] = ncomp; } while (v != u);
        ncomp++;
    }
}

int main() {
    int n = 4, e[4][2] = {{1,2},{2,1},{3,4},{4,3}};
    g.assign(n, {}); idx.assign(n, -1); low.assign(n, 0);
    comp.assign(n, -1); onStack.assign(n, 0);
    for (auto& x : e) g[x[0]-1].push_back(x[1]-1);
    for (int u = 0; u < n; u++) if (idx[u] < 0) tarjan(u);
    vector<char> hasIn(ncomp, 0), hasOut(ncomp, 0);
    for (int u = 0; u < n; u++)
        for (int v : g[u])
            if (comp[u] != comp[v]) { hasOut[comp[u]] = 1; hasIn[comp[v]] = 1; }
    int ns = 0, nk = 0;
    for (int c = 0; c < ncomp; c++) { if (!hasIn[c]) ns++; if (!hasOut[c]) nk++; }
    cout << (ncomp > 1 ? max(ns, nk) : 0) << '\\n';   // 2
}`,
        },
        steps(raw) {
          const steps = [];
          const tokens = tokenize(raw);
          const settings = {};
          const edges = [];
          const notes = [];
          for (const tok of tokens) {
            const m = tok.match(/^([A-Za-z]+)=(\S+)$/);
            if (m) { settings[m[1].toLowerCase()] = m[2]; continue; }
            const parts = tok.split(",").map((p) => p.trim());
            if (parts.length === 2 && isIntText(parts[0]) && isIntText(parts[1]) && Number(parts[0]) >= 1 && Number(parts[1]) >= 1) {
              edges.push({ a: Number(parts[0]), b: Number(parts[1]) });
            } else notes.push(tok);
          }
          const labels = new Set();
          edges.forEach((e) => { labels.add(e.a); labels.add(e.b); });
          const maxLabel = labels.size ? Math.max(...labels) : 0;
          let n = parseInt(settings.n, 10);
          if (!Number.isFinite(n) || n < 1) n = maxLabel > 0 ? maxLabel : 1;
          if (n > 12) { n = 12; notes.push("n>12 (capped at 12)"); }
          const ids = [];
          for (let i = 1; i <= n; i++) ids.push(i);
          const layout = circleLayout(ids.map(String));
          const outE = ids.map(() => []);
          edges.forEach((e, i) => { outE[e.a - 1].push(i); });
          const eKeep = edges.map(() => undefined);
          const idxOf = {}, lowOf = {};
          ids.forEach((id) => { idxOf[id] = null; lowOf[id] = null; });
          const stk = [];
          const onStack = new Set();
          const compOf = {};
          let timer = 0;
          const comps = [];
          const stackTrack = () => ({
            label: "Tarjan stack (candidates)",
            cells: stk.length ? stk.map((x) => ({ v: x, state: "active", tag: String(x) })) : [{ v: "empty", state: "idle", empty: true }],
          });
          const dlTrack = () => ({
            label: "index / low-link",
            cells: ids.map((id) => ({
              v: idxOf[id] == null ? "—" : idxOf[id] + "/" + lowOf[id],
              state: onStack.has(id) ? "active" : compOf[id] != null ? "done" : "idle",
              tag: String(id),
            })),
          });
          const compsTrack = () => ({
            label: "components popped",
            cells: comps.length ? comps.map((c, i) => ({ v: c.join("-"), state: "result", tag: "C" + (i + 1) })) : [{ v: "none yet", state: "idle", empty: true }],
          });
          const nodeSt = () => {
            const ns = {};
            ids.forEach((id) => { ns[id] = compOf[id] != null ? "good" : onStack.has(id) ? "active" : idxOf[id] != null ? "done" : "idle"; });
            return ns;
          };
          const setupTracks = [dlTrack(), stackTrack(), compsTrack()];
          steps.push({
            title: `Setup: ${n} nodes, ${edges.length} directed edges — make it one strongly connected piece`,
            ...gstage(layout, nodeSt(), edges, eKeep),
            tracks: setupTracks,
            counters: [count("nodes", n), count("edges", edges.length), count("components", 0)],
            legend: ["read", "active", "done", "idle"],
            happened: `The graph must end up where every node reaches every other. Extra arrows may be added; each one is counted.`,
            why: "First the components must be known — inside one, nodes are already mutually reachable, so only the spaces between components matter.",
            codeLine: 2,
          });
          if (notes.length) steps.push({ ...noteStep(setupTracks, notes), ...gstage(layout, nodeSt(), edges, eKeep) });
          const dfs = (u, via) => {
            idxOf[u] = lowOf[u] = timer++;
            stk.push(u);
            onStack.add(u);
            const shown = eKeep.slice();
            if (via != null) shown[via] = "read";
            const ns = nodeSt();
            ns[u] = "read";
            steps.push({
              title: `Enter ${u}: index ${idxOf[u]}, low-link ${lowOf[u]}, pushed on the stack`,
              ...gstage(layout, ns, edges, shown),
              tracks: [dlTrack(), stackTrack(), compsTrack()],
              counters: [count("nodes visited", Object.keys(idxOf).filter((k) => idxOf[k] != null).length, n), count("components", comps.length)],
              legend: ["read", "active", "done", "idle"],
              happened: via != null
                ? `The edge ${edges[via].a}→${u} leads into a new node, which becomes number ${idxOf[u]} in visit order.`
                : `Starting a fresh DFS at ${u}, number ${idxOf[u]} in visit order.`,
              why: "The low-link tracks the earliest visit the subtree can reach — it is what will decide where components end.",
              codeLine: 9,
            });
            outE[u - 1].forEach((ei) => {
              const v = edges[ei].b;
              if (idxOf[v] == null) {
                eKeep[ei] = "good";
                dfs(v, ei);
                const before = lowOf[u];
                if (lowOf[v] < lowOf[u]) lowOf[u] = lowOf[v];
                const ns2 = nodeSt();
                ns2[u] = "read";
                steps.push({
                  title: lowOf[u] < before
                    ? `Back from ${v}: low[${u}] drops ${before} → ${lowOf[u]} (reaches index ${lowOf[v]})`
                    : `Back from ${v}: low[${u}] stays ${lowOf[u]}`,
                  ...gstage(layout, ns2, edges, eKeep),
                  tracks: [dlTrack(), stackTrack(), compsTrack()],
                  counters: [count("nodes visited", Object.keys(idxOf).filter((k) => idxOf[k] != null).length, n), count("components", comps.length)],
                  legend: ["read", "active", "done", "idle"],
                  happened: lowOf[u] < before
                    ? `From ${u}'s subtree the walk can now reach back to index ${lowOf[u]}, which is older than before.`
                    : `Nothing deeper than ${lowOf[u]} was reachable through ${v}.`,
                  why: "A low-link that can't reach past u's own index is the signature of a component boundary.",
                  codeLine: 12,
                });
              } else if (onStack.has(v)) {
                const before = lowOf[u];
                if (idxOf[v] < lowOf[u]) lowOf[u] = idxOf[v];
                const ns2 = nodeSt();
                ns2[u] = "read";
                shown[ei] = "active";
                steps.push({
                  title: `Back edge ${u}→${v} (v still on the stack): low[${u}] ${before} → ${lowOf[u]}`,
                  ...gstage(layout, ns2, edges, shown),
                  tracks: [dlTrack(), stackTrack(), compsTrack()],
                  counters: [count("nodes visited", Object.keys(idxOf).filter((k) => idxOf[k] != null).length, n), count("components", comps.length)],
                  legend: ["read", "active", "done", "idle"],
                  happened: `${v} is an unfinished ancestor, so ${u}'s subtree is part of the same cycle and can reach back to index ${idxOf[v]}.`,
                  why: "Back edges into the live stack are what weld nodes together into one component.",
                  codeLine: 15,
                });
              } else {
                eKeep[ei] = "dim";
              }
            });
            if (lowOf[u] === idxOf[u]) {
              const pop = [];
              let v;
              do {
                v = stk.pop();
                onStack.delete(v);
                compOf[v] = comps.length;
                pop.push(v);
              } while (v !== u);
              comps.push(pop.slice());
              const ns2 = nodeSt();
              ns2[u] = "read";
              steps.push({
                title: `low[${u}] = index ${idxOf[u]} — pop component C${comps.length}: ${pop.join(", ")}`,
                ...gstage(layout, ns2, edges, eKeep),
                tracks: [dlTrack(), stackTrack(), compsTrack()],
                counters: [count("components", comps.length), count("just popped", pop.length)],
                legend: ["read", "good", "active", "idle"],
                happened: `Everything from ${u} upward on the stack can only reach back to ${idxOf[u]}, so ${pop.join(", ")} is exactly one mutually reachable group.`,
                why: "Equality of low-link and index means the group has no way out to older nodes — it is complete on its own.",
                codeLine: 19,
              });
            } else {
              steps.push({
                title: `Node ${u} finishes: low ${lowOf[u]} < index ${idxOf[u]} — stays on the stack`,
                ...gstage(layout, nodeSt(), edges, eKeep),
                tracks: [dlTrack(), stackTrack(), compsTrack()],
                counters: [count("components", comps.length), count("stack size", stk.length)],
                legend: ["read", "active", "done", "idle"],
                happened: `${u} can still reach something older than itself, so it keeps waiting — its component is not closed yet.`,
                why: "Only the deepest node whose low-link equals its index closes a component; its whole waiting group pops with it.",
                codeLine: 21,
              });
            }
          };
          ids.forEach((u) => { if (idxOf[u] == null) dfs(u, null); });
          const hasIn = comps.map(() => false);
          const hasOut = comps.map(() => false);
          const between = [];
          edges.forEach((e) => {
            const cu = compOf[e.a], cv = compOf[e.b];
            if (cu !== cv) { hasOut[cu] = true; hasIn[cv] = true; between.push(e); }
          });
          const sources = comps.map((c, i) => i).filter((i) => !hasIn[i]);
          const sinks = comps.map((c, i) => i).filter((i) => !hasOut[i]);
          const pal = ["good", "result", "active", "compare"];
          const cSt = {};
          ids.forEach((id) => { cSt[id] = pal[compOf[id] % pal.length]; });
          const cLayout = circleLayout(comps.map((c, i) => "C" + (i + 1)));
          const cNodes = comps.map((c, i) => ({
            id: "C" + (i + 1),
            label: "C" + (i + 1),
            x: cLayout.get("C" + (i + 1)).x,
            y: cLayout.get("C" + (i + 1)).y,
            state: sources.indexOf(i) >= 0 || sinks.indexOf(i) >= 0 ? "read" : "good",
          }));
          steps.push({
            kind: "graph",
            nodes: cNodes,
            edges: between.map((e) => ({ a: "C" + (compOf[e.a] + 1), b: "C" + (compOf[e.b] + 1), directed: true, state: "good" })),
            title: `Condensation: ${comps.length} component${comps.length === 1 ? "" : "s"}, ${sources.length} source${sources.length === 1 ? "" : "s"}, ${sinks.length} sink${sinks.length === 1 ? "" : "s"}`,
            tracks: [compsTrack(), { label: "sources (nothing points in)", cells: sources.length ? sources.map((i) => ({ v: "C" + (i + 1), state: "read" })) : [{ v: "none", state: "idle", empty: true }] }, { label: "sinks (nothing points out)", cells: sinks.length ? sinks.map((i) => ({ v: "C" + (i + 1), state: "active" })) : [{ v: "none", state: "idle", empty: true }] }],
            counters: [count("components", comps.length), count("sources", sources.length), count("sinks", sinks.length)],
            legend: ["read", "active", "good"],
            happened: `Collapsing each component to one dot leaves ${between.length} arrow${between.length === 1 ? "" : "s"} between the dots — a picture with no cycles. Sources ${sources.length ? sources.map((i) => "C" + (i + 1)).join(", ") : "—"} have nothing pointing in; sinks ${sinks.length ? sinks.map((i) => "C" + (i + 1)).join(", ") : "—"} have nothing pointing out.`,
            why: "Arrows can be added anywhere, so the only structural shortage is between components: each source needs an arrival, each sink needs a departure.",
            codeLine: 30,
          });
          const answer = comps.length > 1 ? Math.max(sources.length, sinks.length) : 0;
          steps.push({
            title: comps.length > 1
              ? `Answer: ${answer} new edge${answer === 1 ? "" : "s"} — chain the sinks into the sources`
              : "Answer: 0 — the graph is already strongly connected",
            ...gstage(layout, cSt, [], []),
            tracks: [{ label: "components (collapse each to one dot)", cells: comps.map((c, i) => ({ v: c.join(","), state: pal[i % pal.length], tag: "C" + (i + 1) })) }],
            counters: [count("components", comps.length), count("sources", sources.length), count("sinks", sinks.length), count("answer", answer)],
            legend: ["good", "result", "active", "compare"],
            legendLabels: { good: "component group", result: "component group", active: "component group", compare: "component group" },
            happened: comps.length > 1
              ? `Each sink needs one outgoing arrow and each source one incoming arrow, and one arrow can serve both jobs — so ${Math.max(sources.length, sinks.length)} is enough: ${sources.length >= sinks.length ? "sources outnumber sinks, so every extra source simply gets an arrival" : "sinks outnumber sources, so every extra sink simply gets a departure"}.`
              : "Every node already reaches every other, so the graph needs no repair at all.",
            why: "Turning the DAG of components into one cycle is the whole task: walk through sinks into sources until everything is a single loop.",
            codeLine: 33,
          });
          return steps;
        },
      },
    ],
  });
})();
