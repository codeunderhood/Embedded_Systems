/* ============================================================
   DSA Visuals - NeetCode 250 additions, DP and greedy
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, grid } = window.H;
  const V = window.VIZ;

  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => "[" + a.join(", ") + "]";
  const ints = (s) => String(s || "").split(/[\s,;]+/).filter(Boolean).map(Number).filter(Number.isFinite);
  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];

  /* ---------------------------------------------------------- */
  V.register({
    id: "integer-break",
    title: "Integer Break",
    category: "1-D Dynamic Programming",
    difficulty: "Intermediate",
    description: "Split an integer into at least two positive parts with the largest product.",
    input: { label: "The integer", default: "10", parse: "int" },
    approaches: [
      {
        name: "Best Product Per Value",
        complexity: "O(n^2) time, O(n) space",
        idea: [
          "Let dp[x] be the largest product obtainable by breaking x into at least two parts. For each split x = first + rest, the product is first * max(rest, dp[rest]).",
          "Using max(rest, dp[rest]) allows the rest to stay whole or be broken further. Trying every first part gives the best value for x.",
        ],
        problem: ["The table stores only the best product, so the actual partition must be reconstructed separately if it is needed."],
        code: {
          c: `int integerBreak(int n) {
    int dp[60] = {0};
    dp[1] = 1;
    for (int x = 2; x <= n; x++) {
        for (int first = 1; first < x; first++) {
            int rest = x - first;
            int bestRest = rest > dp[rest] ? rest : dp[rest];
            int candidate = first * bestRest;
            if (candidate > dp[x]) dp[x] = candidate;
        }
    }
    return dp[n];
}`,
          cpp: `#include <algorithm>\n#include <vector>\nusing namespace std;\n\nint integerBreak(int n) {\n    vector<int> dp(n + 1, 0);\n    dp[1] = 1;\n    for (int x = 2; x <= n; x++)\n        for (int first = 1; first < x; first++)\n            dp[x] = max(dp[x], first * max(x - first, dp[x - first]));\n    return dp[n];\n}`,
        },
        steps(n) {
          const N = Math.max(2, n);
          const dp = new Array(N + 1).fill(0);
          dp[1] = 1;
          const out = [];
          out.push({
            title: "dp[x] is the best product for x",
            tracks: [chips("dp", dp.map((v, i) => (i ? i + ":" + v : "0")), "idle")],
            counters: [count("target", N), count("dp filled", 1, N)],
            happened: "dp[1] is 1, the only way to break the smallest value.",
            why: "Each larger value can reuse the best products of smaller values.",
            legend: LEG,
            codeLine: 2,
          });
          for (let x = 2; x <= N; x++) {
            let bestFirst = 1;
            for (let first = 1; first < x; first++) {
              const rest = x - first;
              const candidate = first * Math.max(rest, dp[rest]);
              if (candidate > dp[x]) {
                dp[x] = candidate;
                bestFirst = first;
              }
            }
            out.push({
              title: `dp[${x}] = ${dp[x]} using ${bestFirst} + ${x - bestFirst}`,
              tracks: [chips("dp", dp.map((v, i) => (i ? i + ":" + v : "0")), (i) => (i === x ? "result" : i < x ? "done" : "idle"))],
              counters: [count("best product", dp[x]), count("split", bestFirst + " + " + (x - bestFirst))],
              happened: `The best split found for ${x} gives product ${dp[x]}.`,
              why: "Trying every first part guarantees the best split is not missed.",
              legend: LEG,
              codeLine: 7,
            });
          }
          out.push({
            title: `Maximum product for ${N} is ${dp[N]}`,
            tracks: [chips("dp", [dp[N]], "result")],
            counters: [count("answer", dp[N]), count("target", N)],
            happened: `Breaking ${N} optimally gives ${dp[N]}.`,
            why: "The final table entry contains the best product for the requested integer.",
            legend: LEG,
            codeLine: 11,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "stone-game-iii",
    title: "Stone Game III",
    category: "1-D Dynamic Programming",
    difficulty: "Advanced",
    description: "Compare the best score Alice can guarantee against Bob's.",
    input: { label: "Stone values", default: "1, 2, 3, 7", parse: "ints" },
    approaches: [
      {
        name: "Suffix Difference DP",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Let dp[i] be the best score difference the player to move can achieve from pile i onward. Taking piles i..i+k gives stones plus the opponent's future difference subtracted.",
          "The current player chooses among taking one, two or three piles. dp[0] tells whether Alice finishes ahead, behind or tied.",
        ],
        problem: ["The DP assumes both players play optimally; it does not enumerate their actual choices."],
        code: {
          c: `#include <string.h>\n\nchar* stoneGameIII(int* stones, int n) {\n    int dp[50005];\n    dp[n] = 0;\n    for (int i = n - 1; i >= 0; i--) {\n        int take = 0, best = -1000000000;\n        for (int k = 0; k < 3 && i + k < n; k++) {\n            take += stones[i + k];\n            int score = take - dp[i + k + 1];\n            if (score > best) best = score;\n        }\n        dp[i] = best;\n    }\n    if (dp[0] > 0) return \"Alice\";\n    if (dp[0] < 0) return \"Bob\";\n    return \"Tie\";\n}`,
          cpp: `#include <algorithm>\n#include <string>\n#include <vector>\nusing namespace std;\n\nstring stoneGameIII(vector<int>& stones) {\n    int n = stones.size();\n    vector<int> dp(n + 1, 0);\n    for (int i = n - 1; i >= 0; i--) {\n        int take = 0, best = -1e9;\n        for (int k = 0; k < 3 && i + k < n; k++) {\n            take += stones[i + k];\n            best = max(best, take - dp[i + k + 1]);\n        }\n        dp[i] = best;\n    }\n    if (dp[0] > 0) return "Alice";\n    if (dp[0] < 0) return "Bob";\n    return "Tie";\n}`,
        },
        steps(stones) {
          const n = stones.length;
          const dp = new Array(n + 1).fill(0);
          const out = [];
          out.push({
            title: "Work backward from the end",
            tracks: [track("stones", stones, fill(n, "idle")), chips("dp difference", dp.map(String), "idle")],
            counters: [count("position", n), count("difference", 0)],
            happened: "With no piles left, neither player can gain more points.",
            why: "A suffix DP lets each decision look at the already-solved remainder.",
            legend: LEG,
            codeLine: 5,
          });
          for (let i = n - 1; i >= 0; i--) {
            let take = 0, best = -Infinity, bestK = 0;
            for (let k = 0; k < 3 && i + k < n; k++) {
              take += stones[i + k];
              const score = take - dp[i + k + 1];
              if (score > best) { best = score; bestK = k + 1; }
            }
            dp[i] = best;
            out.push({
              title: `At ${i}, take ${bestK} pile(s) for difference ${best}`,
              tracks: [track("stones", stones, stones.map((v, k) => (k === i ? "read" : k < i ? "idle" : "done"))), chips("dp difference", dp.map((v, k) => (k === i ? "result" : k < i ? "idle" : "done")), "idle")],
              counters: [count("taken", bestK), count("difference", best)],
              happened: `Taking ${bestK} pile(s) gives the current player a net advantage of ${best}.`,
              why: "The opponent's best future difference is subtracted from the current haul.",
              legend: LEG,
              codeLine: 8,
            });
          }
          const winner = dp[0] > 0 ? "Alice" : dp[0] < 0 ? "Bob" : "Tie";
          out.push({
            title: `${winner} wins or draws (difference ${dp[0]})`,
            tracks: [chips("dp difference", [dp[0]], "result"), chips("winner", [winner], winner === "Bob" ? "bad" : "good")],
            counters: [count("difference", dp[0]), count("winner", winner)],
            happened: dp[0] > 0 ? "Alice can force a positive score difference." : dp[0] < 0 ? "Bob can force a positive difference for himself." : "Both players can force an equal score.",
            why: "dp[0] compares Alice's total against Bob's under optimal play.",
            legend: LEG,
            codeLine: 15,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "last-stone-weight-ii",
    title: "Last Stone Weight II",
    category: "2-D Dynamic Programming",
    difficulty: "Intermediate",
    description: "Minimize the remaining stone weight after repeatedly smashing pairs.",
    input: { label: "Stone weights", default: "2, 7, 4, 1, 8, 1", parse: "ints" },
    approaches: [
      {
        name: "Closest Subset Sum",
        complexity: "O(n * total) time, O(total) space",
        idea: [
          "Each smash subtracts the smaller stone from the larger. The final result is the difference between the total weight of two opposing groups.",
          "So the goal is to split the stones into two groups whose sums are as close as possible. A subset-sum DP records reachable group sums up to half the total.",
        ],
        problem: ["The DP tracks only sums, so the actual grouping is not reconstructed."],
        code: {
          c: `int lastStoneWeightII(int* stones, int n) {\n    int total = 0;\n    for (int i = 0; i < n; i++) total += stones[i];\n    int half = total / 2;\n    char* dp = calloc(half + 1, 1);\n    dp[0] = 1;\n    for (int i = 0; i < n; i++)\n        for (int s = half; s >= stones[i]; s--)\n            if (dp[s - stones[i]]) dp[s] = 1;\n    int best = 0;\n    for (int s = half; s >= 0; s--) if (dp[s]) { best = s; break; }\n    free(dp);\n    return total - 2 * best;\n}`,
          cpp: `#include <numeric>\n#include <vector>\nusing namespace std;\n\nint lastStoneWeightII(vector<int>& stones) {\n    int total = accumulate(stones.begin(), stones.end(), 0);\n    int half = total / 2;\n    vector<char> dp(half + 1, 0);\n    dp[0] = 1;\n    for (int w : stones)\n        for (int s = half; s >= w; s--)\n            if (dp[s - w]) dp[s] = 1;\n    for (int s = half; s >= 0; s--) if (dp[s]) return total - 2 * s;\n    return total;\n}`,
        },
        steps(stones) {
          const total = stones.reduce((s, x) => s + x, 0);
          const half = Math.floor(total / 2);
          const dp = new Array(half + 1).fill(false);
          dp[0] = true;
          const out = [];
          out.push({
            title: `Aim for a subset sum near ${half}`,
            tracks: [track("stones", stones, fill(stones.length, "idle")), chips("reachable sums", [0], "good")],
            counters: [count("total", total), count("target half", half)],
            happened: "The best split puts one group as close as possible to half the total.",
            why: "Two groups with sums A and B leave |A - B|, which is total - 2 * min(A, B).",
            legend: LEG,
            codeLine: 5,
          });
          for (let i = 0; i < stones.length; i++) {
            const w = stones[i];
            for (let s = half; s >= w; s--) if (dp[s - w]) dp[s] = true;
            const reachable = [];
            for (let s = 0; s <= half; s++) if (dp[s]) reachable.push(s);
            out.push({
              title: `Use stone ${w}; reachable sums extend`,
              tracks: [track("stones", stones, stones.map((v, k) => (k === i ? "read" : k < i ? "done" : "idle"))), chips("reachable sums", reachable, "active")],
              counters: [count("reachable sums", reachable.length), count("stone weight", w)],
              happened: `After stone ${w}, sums up to ${half} that can be formed are ${show(reachable)}.`,
              why: "Descending the sum loop prevents using the same stone more than once.",
              legend: LEG,
              codeLine: 8,
            });
          }
          let best = 0;
          for (let s = half; s >= 0; s--) if (dp[s]) { best = s; break; }
          out.push({
            title: `Closest half sum is ${best}; answer ${total - 2 * best}`,
            tracks: [chips("reachable sums", [best], "result"), chips("remaining weight", [total - 2 * best], "result")],
            counters: [count("best half", best), count("answer", total - 2 * best)],
            happened: `The two groups can differ by ${total - 2 * best}.`,
            why: "That difference is exactly the smallest possible final stone weight.",
            legend: LEG,
            codeLine: 12,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "buy-and-sell-crypto-with-cooldown",
    title: "Best Time to Buy And Sell Stock With Cooldown",
    category: "2-D Dynamic Programming",
    difficulty: "Intermediate",
    description: "Maximize trading profit when a cooldown follows every sale.",
    input: { label: "Daily prices", default: "1, 2, 3, 0, 2", parse: "ints" },
    approaches: [
      {
        name: "Hold, Sold, Rest States",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Track three balances: holding a stock, having just sold today, and being in the cooldown/rest state.",
          "A buy comes from rest and decreases cash; a sell comes from hold and adds the price; rest is the best of the previous rest or sold states.",
        ],
        problem: ["The recurrence assumes one stock at a time and a one-day cooldown, exactly as stated by the problem."],
        code: {
          c: `int maxProfit(int* p, int n) {\n    int hold = -1000000000, sold = 0, rest = 0;\n    for (int i = 0; i < n; i++) {\n        int prevSold = sold;\n        sold = hold + p[i];\n        hold = hold > rest - p[i] ? hold : rest - p[i];\n        rest = rest > prevSold ? rest : prevSold;\n    }\n    return sold > rest ? sold : rest;\n}`,
          cpp: `#include <algorithm>\n#include <vector>\nusing namespace std;\n\nint maxProfit(vector<int>& p) {\n    int hold = -1e9, sold = 0, rest = 0;\n    for (int x : p) {\n        int prevSold = sold;\n        sold = hold + x;\n        hold = max(hold, rest - x);\n        rest = max(rest, prevSold);\n    }\n    return max(sold, rest);\n}`,
        },
        steps(prices) {
          const out = [];
          let hold = -Infinity, sold = 0, rest = 0;
          out.push({
            title: "Three cash states",
            tracks: [track("prices", prices, fill(prices.length, "idle")), chips("hold / sold / rest", ["-inf", "0", "0"], "idle")],
            counters: [count("hold", "-inf"), count("profit", 0)],
            happened: "Before trading, holding is impossible while sold and rest both have zero profit.",
            why: "Separating the states makes the cooldown rule explicit.",
            legend: LEG,
            codeLine: 2,
          });
          for (let i = 0; i < prices.length; i++) {
            const prevSold = sold;
            sold = hold + prices[i];
            hold = Math.max(hold, rest - prices[i]);
            rest = Math.max(rest, prevSold);
            out.push({
              title: `Day ${i + 1} at price ${prices[i]}`,
              tracks: [track("prices", prices, prices.map((v, k) => (k === i ? "read" : k < i ? "done" : "idle"))), chips("hold / sold / rest", [hold === -Infinity ? "-inf" : hold, sold, rest], "active")],
              counters: [count("hold", hold === -Infinity ? "-inf" : hold), count("best cash", Math.max(sold, rest))],
              happened: `Holding is ${hold === -Infinity ? "impossible" : hold}, sold today is ${sold}, resting is ${rest}.`,
              why: "A sale cannot be followed immediately by a buy because the rest state is required first.",
              legend: LEG,
              codeLine: 5,
            });
          }
          const answer = Math.max(sold, rest);
          out.push({
            title: `Maximum profit is ${answer}`,
            tracks: [chips("final states", ["sold:" + sold, "rest:" + rest], "result")],
            counters: [count("answer", answer)],
            happened: "Ending while holding a stock is never better than having sold it.",
            why: "The best final cash is the larger of the sold and rest states.",
            legend: LEG,
            codeLine: 10,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "stone-game",
    title: "Stone Game",
    category: "2-D Dynamic Programming",
    difficulty: "Intermediate",
    description: "Decide whether the first player can win by taking piles from either end.",
    input: { label: "Piles", default: "5, 3, 4, 5", parse: "ints" },
    approaches: [
      {
        name: "Interval Score Difference",
        complexity: "O(n^2) time, O(n^2) space",
        idea: [
          "dp[l][r] is the best score difference the player to move can obtain from the interval l..r.",
          "Taking the left pile gives piles[l] minus the opponent's best result on l+1..r. Taking the right pile is symmetric. The current player picks the larger option.",
        ],
        problem: ["The interval table is quadratic in memory; the problem's even-pile constraint has a simpler parity argument, but the DP is more general."],
        code: {
          c: `#include <stdbool.h>\n\nbool stoneGame(int* p, int n) {\n    int dp[100][100] = {0};\n    for (int i = 0; i < n; i++) dp[i][i] = p[i];\n    for (int len = 2; len <= n; len++)\n        for (int l = 0; l + len - 1 < n; l++) {\n            int r = l + len - 1;\n            int left = p[l] - dp[l+1][r];\n            int right = p[r] - dp[l][r-1];\n            dp[l][r] = left > right ? left : right;\n        }\n    return dp[0][n-1] > 0;\n}`,
          cpp: `#include <algorithm>\n#include <vector>\nusing namespace std;\n\nbool stoneGame(vector<int>& p) {\n    int n = p.size();\n    vector<vector<int>> dp(n, vector<int>(n, 0));\n    for (int i = 0; i < n; i++) dp[i][i] = p[i];\n    for (int len = 2; len <= n; len++)\n        for (int l = 0; l + len - 1 < n; l++) {\n            int r = l + len - 1;\n            dp[l][r] = max(p[l] - dp[l+1][r], p[r] - dp[l][r-1]);\n        }\n    return dp[0][n-1] > 0;\n}`,
        },
        steps(p) {
          const n = p.length;
          const dp = Array.from({ length: n }, () => new Array(n).fill(0));
          for (let i = 0; i < n; i++) dp[i][i] = p[i];
          const out = [];
          out.push({
            title: "One-pile intervals are trivial",
            kind: "grid", rows: n, cols: n, cells: grid(n, n, (r, c) => ({ r, c, v: r === c ? dp[r][c] : "", state: r === c ? "read" : "idle" })), rowHeads: p.map((_, i) => "L" + i), colHeads: p.map((_, i) => "R" + i),
            counters: [count("intervals solved", n), count("difference", p[0])],
            happened: "A single pile simply gives its value to the player who takes it.",
            why: "The interval DP builds larger ranges from these one-pile ranges.",
            legend: LEG,
            codeLine: 4,
          });
          for (let len = 2; len <= n; len++) {
            for (let l = 0; l + len - 1 < n; l++) {
              const r = l + len - 1;
              const takeLeft = p[l] - dp[l + 1][r];
              const takeRight = p[r] - dp[l][r - 1];
              dp[l][r] = Math.max(takeLeft, takeRight);
            }
            const rowHint = len;
            out.push({
              title: `Solve intervals of length ${len}`,
              kind: "grid", rows: n, cols: n, cells: grid(n, n, (r, c) => ({ r, c, v: r <= c && c - r + 1 <= len ? dp[r][c] : "", state: r <= c && c - r + 1 === len ? "result" : r <= c && c - r + 1 < len ? "done" : "idle" })),
              counters: [count("length", len), count("best difference", dp[0][n - 1])],
              happened: `All intervals with ${len} piles now have their best difference.`,
              why: "A player takes one end and leaves the opponent the corresponding smaller interval.",
              legend: LEG,
              codeLine: 7,
            });
          }
          const win = dp[0][n - 1] > 0;
          out.push({
            title: win ? "The first player can win" : "The first player cannot force a win",
            tracks: [chips("score difference", [dp[0][n - 1]], win ? "result" : "bad")],
            counters: [count("difference", dp[0][n - 1]), count("answer", win ? "true" : "false")],
            happened: `The optimal difference from the full interval is ${dp[0][n - 1]}.`,
            why: "A positive difference means the first player scores more than the second.",
            legend: LEG,
            codeLine: 10,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "stone-game-ii",
    title: "Stone Game II",
    category: "2-D Dynamic Programming",
    difficulty: "Intermediate",
    description: "Maximize the first player's stones when M grows with each move.",
    input: { label: "Piles", default: "2, 7, 9, 4, 4", parse: "ints" },
    approaches: [
      {
        name: "Suffix DP with M",
        complexity: "O(n^2) time, O(n^2) space",
        idea: [
          "Let dp[i][m] be the maximum stones the current player can collect from index i with current limit m. They may take 1 through 2m piles.",
          "Use suffix sums to score a take quickly. The opponent then plays from the new index with the larger m, so the current player's result is the remaining suffix minus the opponent's best.",
        ],
        problem: ["The state includes both the current index and m, so the table is quadratic even though the input is only one-dimensional."],
        code: {
          c: `#include <string.h>\n\nint dp[101][101];\nint* suffix;\nint solve(int i, int m, int n) {\n    if (i >= n) return 0;\n    if (dp[i][m] >= 0) return dp[i][m];\n    int best = 0;\n    for (int take = 1; take <= 2 * m && i + take <= n; take++) {\n        int nextM = take > m ? take : m;\n        int opponent = solve(i + take, nextM, n);\n        int value = suffix[i] - opponent;\n        if (value > best) best = value;\n    }\n    return dp[i][m] = best;\n}`,
          cpp: `#include <algorithm>\n#include <vector>\nusing namespace std;\n\nint stoneGameII(vector<int>& piles) {\n    int n = piles.size();\n    vector<int> suffix(n + 1, 0);\n    for (int i = n - 1; i >= 0; i--) suffix[i] = suffix[i + 1] + piles[i];\n    vector<vector<int>> dp(n + 1, vector<int>(n + 1, -1));\n    function<int(int,int)> solve = [&](int i, int m) -> int {\n        if (i >= n) return 0;\n        if (dp[i][m] >= 0) return dp[i][m];\n        int best = 0;\n        for (int take = 1; take <= 2 * m && i + take <= n; take++) {\n            int nextM = max(m, take);\n            best = max(best, suffix[i] - solve(i + take, nextM));\n        }\n        return dp[i][m] = best;\n    };\n    return solve(0, 1);\n}`,
        },
        steps(piles) {
          const n = piles.length;
          const suffix = new Array(n + 1).fill(0);
          for (let i = n - 1; i >= 0; i--) suffix[i] = suffix[i + 1] + piles[i];
          const memo = new Map();
          const out = [];
          out.push({
            title: "Suffix sums show what is left",
            tracks: [track("piles", piles, fill(n, "idle")), chips("suffix totals", suffix.slice(0, n), "idle")],
            counters: [count("remaining stones", suffix[0]), count("M", 1)],
            happened: "The current player starts with M = 1 and may take one or two piles.",
            why: "A suffix total makes the value of taking a prefix easy to compute.",
            legend: LEG,
            codeLine: 4,
          });
          const solve = (i, m) => {
            if (i >= n) return 0;
            const key = i + "," + m;
            if (memo.has(key)) return memo.get(key);
            let best = 0, bestTake = 0;
            for (let take = 1; take <= 2 * m && i + take <= n; take++) {
              const value = suffix[i] - solve(i + take, Math.max(m, take));
              if (value > best) { best = value; bestTake = take; }
            }
            memo.set(key, best);
            out.push({
              title: `From index ${i} with M=${m}, take ${bestTake}`,
              tracks: [track("piles", piles, piles.map((v, k) => (k < i ? "done" : k < i + bestTake ? "result" : "idle"))), chips("best stones", [best], "active")],
              counters: [count("M", m), count("best stones", best)],
              happened: `Taking ${bestTake} pile(s) guarantees ${best} stones from this suffix.`,
              why: "The opponent's optimal reply is already included in the remaining suffix value.",
              legend: LEG,
              codeLine: 11,
            });
            return best;
          };
          const answer = solve(0, 1);
          out.push({
            title: `Alice can collect ${answer} stones`,
            tracks: [chips("answer", [answer], "result")],
            counters: [count("answer", answer), count("states solved", memo.size)],
            happened: "The DP returns the best total the first player can secure.",
            why: "Each state assumes both players maximize their own final stone count.",
            legend: LEG,
            codeLine: 16,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "longest-increasing-path-in-matrix",
    title: "Longest Increasing Path In a Matrix",
    category: "2-D Dynamic Programming",
    difficulty: "Advanced",
    description: "Find the longest strictly increasing path through a grid.",
    input: { label: "grid rows separated by |", default: "9 9 4 | 6 6 8 | 2 1 1", parse: "string" },
    approaches: [
      {
        name: "DFS with Memoization",
        complexity: "O(rows * cols) time, O(rows * cols) space",
        idea: [
          "From a cell, a path can only move to a neighbor with a larger value. That makes the directed graph acyclic.",
          "Memoize the longest path starting at each cell. The answer is the maximum over all starting cells, and each cell's result is computed once.",
        ],
        problem: ["The recursion depth can be the number of cells, so an explicit stack may be safer for very large grids."],
        code: {
          c: `int dfs(int** a, int rows, int cols, int r, int c, int** memo) {\n    if (memo[r][c]) return memo[r][c];\n    int best = 1;\n    int dr[4] = {-1,1,0,0}, dc[4] = {0,0,-1,1};\n    for (int k = 0; k < 4; k++) {\n        int nr = r + dr[k], nc = c + dc[k];\n        if (nr < 0 || nc < 0 || nr >= rows || nc >= cols) continue;\n        if (a[nr][nc] <= a[r][c]) continue;\n        int cand = 1 + dfs(a, rows, cols, nr, nc, memo);\n        if (cand > best) best = cand;\n    }\n    return memo[r][c] = best;\n}`,
          cpp: `#include <algorithm>\n#include <vector>\nusing namespace std;\n\nint dfs(vector<vector<int>>& a, int r, int c, vector<vector<int>>& memo) {\n    if (memo[r][c]) return memo[r][c];\n    int best = 1;\n    int dr[4] = {-1,1,0,0}, dc[4] = {0,0,-1,1};\n    for (int k = 0; k < 4; k++) {\n        int nr = r + dr[k], nc = c + dc[k];\n        if (nr < 0 || nc < 0 || nr >= (int)a.size() || nc >= (int)a[0].size()) continue;\n        if (a[nr][nc] <= a[r][c]) continue;\n        best = max(best, 1 + dfs(a, nr, nc, memo));\n    }\n    return memo[r][c] = best;\n}`,
        },
        steps(text) {
          const rows = String(text || "").split("|").map((r) => r.trim().split(/[\s,]+/).filter(Boolean).map(Number));
          const R = rows.length, C = Math.max(1, ...rows.map((r) => r.length));
          const a = Array.from({ length: R }, (_, r) => Array.from({ length: C }, (_, c) => rows[r][c] || 0));
          const memo = Array.from({ length: R }, () => new Array(C).fill(0));
          const out = [];
          let longest = 0;
          out.push({
            title: "Only move to larger neighbors",
            kind: "grid", rows: R, cols: C, cells: grid(R, C, (r, c) => ({ r, c, v: a[r][c], state: "idle" })),
            counters: [count("longest", 0), count("cells", R * C)],
            happened: "Each edge goes from a smaller value to a larger one.",
            why: "Strictly increasing moves cannot cycle, so memoized DFS is safe.",
            legend: LEG,
            codeLine: 2,
          });
          const walk = (r, c) => {
            if (memo[r][c]) return memo[r][c];
            let best = 1;
            for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]]) {
              const nr = r + dr, nc = c + dc;
              if (nr < 0 || nc < 0 || nr >= R || nc >= C || a[nr][nc] <= a[r][c]) continue;
              best = Math.max(best, 1 + walk(nr, nc));
            }
            memo[r][c] = best;
            longest = Math.max(longest, best);
            out.push({
              title: `Path from ${r},${c} has length ${best}`,
              kind: "grid", rows: R, cols: C, cells: grid(R, C, (rr, cc) => ({ r: rr, c: cc, v: a[rr][cc], state: rr === r && cc === c ? "result" : memo[rr][cc] ? "done" : "idle" })),
              counters: [count("longest", longest), count("cell value", a[r][c])],
              happened: `The best increasing path starting here visits ${best} cell(s).`,
              why: "The best continuation is the largest memoized child path plus the current cell.",
              legend: LEG,
              codeLine: 11,
            });
            return best;
          };
          for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) walk(r, c);
          out.push({
            title: `Longest increasing path length is ${longest}`,
            kind: "grid", rows: R, cols: C, cells: grid(R, C, (r, c) => ({ r, c, v: a[r][c], state: memo[r][c] === longest ? "result" : memo[r][c] ? "done" : "idle" })),
            counters: [count("answer", longest), count("cells solved", R * C)],
            happened: "Every cell contributed its longest outgoing chain.",
            why: "The maximum of all memoized path lengths is the global answer.",
            legend: LEG,
            codeLine: 13,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-sum-circular-subarray",
    title: "Maximum Sum Circular Subarray",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Find the best subarray when the array may wrap around.",
    input: { label: "The numbers", default: "1, -2, 3, -2", parse: "ints" },
    approaches: [
      {
        name: "Kadane on Both Extremes",
        complexity: "O(n) time, O(1) space",
        idea: [
          "The best circular subarray either does not wrap, or it wraps and is the total sum minus the worst non-wrapping middle subarray.",
          "Run Kadane for the maximum and for the minimum. If every value is negative, the wrapped case would be empty, so return the ordinary maximum instead.",
        ],
        problem: ["The all-negative guard is essential; otherwise total minus the minimum would incorrectly select an empty wrap-around subarray."],
        code: {
          c: `int maxSubarraySumCircular(int* a, int n) {\n    int total = 0;\n    int curMax = 0, bestMax = -1000000000;\n    int curMin = 0, bestMin = 1000000000;\n    for (int i = 0; i < n; i++) {\n        total += a[i];\n        curMax = curMax > 0 ? curMax + a[i] : a[i];\n        bestMax = curMax > bestMax ? curMax : bestMax;\n        curMin = curMin < 0 ? curMin + a[i] : a[i];\n        bestMin = curMin < bestMin ? curMin : bestMin;\n    }\n    if (bestMax < 0) return bestMax;\n    int wrapped = total - bestMin;\n    return wrapped > bestMax ? wrapped : bestMax;\n}`,
          cpp: `#include <algorithm>\n#include <numeric>\n#include <vector>\nusing namespace std;\n\nint maxSubarraySumCircular(vector<int>& a) {\n    int total = accumulate(a.begin(), a.end(), 0);\n    int curMax = 0, bestMax = INT_MIN, curMin = 0, bestMin = INT_MAX;\n    for (int x : a) {\n        curMax = max(x, curMax + x);\n        bestMax = max(bestMax, curMax);\n        curMin = min(x, curMin + x);\n        bestMin = min(bestMin, curMin);\n    }\n    if (bestMax < 0) return bestMax;\n    return max(bestMax, total - bestMin);\n}`,
        },
        steps(nums) {
          const out = [];
          let total = 0, curMax = 0, bestMax = -Infinity, curMin = 0, bestMin = Infinity;
          out.push({
            title: "Run Kadane twice",
            tracks: [track("numbers", nums, fill(nums.length, "idle")), chips("max / min / total", ["-inf", "inf", "0"], "idle")],
            counters: [count("best max", 0), count("best min", 0)],
            happened: "One pass tracks the best normal subarray and the worst normal subarray.",
            why: "A wrapped maximum is total minus the worst middle segment.",
            legend: LEG,
            codeLine: 3,
          });
          for (let i = 0; i < nums.length; i++) {
            const x = nums[i];
            total += x;
            curMax = Math.max(x, curMax + x);
            bestMax = Math.max(bestMax, curMax);
            curMin = Math.min(x, curMin + x);
            bestMin = Math.min(bestMin, curMin);
            out.push({
              title: `Read ${x}; best normal sum ${bestMax}`,
              tracks: [track("numbers", nums, nums.map((v, k) => (k === i ? "read" : k < i ? "done" : "idle"))), chips("max / min / total", [bestMax, bestMin, total], "active")],
              counters: [count("best max", bestMax), count("best min", bestMin)],
              happened: `The normal maximum is ${bestMax}; excluding the worst middle segment leaves ${total - bestMin}.`,
              why: "Kadane keeps the best contiguous segment ending at the current position.",
              legend: LEG,
              codeLine: 7,
            });
          }
          const answer = bestMax < 0 ? bestMax : Math.max(bestMax, total - bestMin);
          out.push({
            title: `Maximum circular sum is ${answer}`,
            tracks: [chips("normal", [bestMax], "good"), chips("wrapped", [total - bestMin], "good"), chips("answer", [answer], "result")],
            counters: [count("answer", answer), count("total", total)],
            happened: bestMax < 0 ? "All values are negative, so wrapping would select an empty subarray." : "The better of the normal and wrapped candidates is chosen.",
            why: "Subtracting the minimum middle segment leaves the maximum wrapped prefix plus suffix.",
            legend: LEG,
            codeLine: 13,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "longest-turbulent-subarray",
    title: "Longest Turbulent Subarray",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Find the longest subarray whose comparisons alternate up and down.",
    input: { label: "The numbers", default: "9, 4, 2, 10, 7, 8, 8, 1, 9", parse: "ints" },
    approaches: [
      {
        name: "Track the Last Comparison",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Compare each adjacent pair and record whether it goes up, down or is equal. A turbulent run continues only when the direction flips.",
          "Equal values break the run, and a new run can still start at that pair. Keeping the current length gives the maximum in one pass.",
        ],
        problem: ["The greedy run length assumes the best subarray ends at the current index, which is exactly what the alternating condition allows."],
        code: {
          c: `int maxTurbulenceSize(int* a, int n) {\n    if (n == 1) return 1;\n    int best = 1, curr = 1, prev = 0;\n    for (int i = 1; i < n; i++) {\n        int dir = a[i] > a[i-1] ? 1 : a[i] < a[i-1] ? -1 : 0;\n        if (dir == 0) curr = 1;\n        else if (dir == -prev) curr++;\n        else curr = 2;\n        prev = dir;\n        if (curr > best) best = curr;\n    }\n    return best;\n}`,
          cpp: `#include <algorithm>\n#include <vector>\nusing namespace std;\n\nint maxTurbulenceSize(vector<int>& a) {\n    int best = 1, curr = 1, prev = 0;\n    for (int i = 1; i < (int)a.size(); i++) {\n        int dir = a[i] > a[i-1] ? 1 : a[i] < a[i-1] ? -1 : 0;\n        if (dir == 0) curr = 1;\n        else if (dir == -prev) curr++;\n        else curr = 2;\n        prev = dir;\n        best = max(best, curr);\n    }\n    return best;\n}`,
        },
        steps(nums) {
          let best = 1, curr = 1, prev = 0;
          const out = [];
          out.push({
            title: "Start with one element",
            tracks: [track("numbers", nums, fill(nums.length, "idle")), chips("run", [1], "active")],
            counters: [count("best", 1), count("current", 1)],
            happened: "A single element is always turbulent.",
            why: "The condition is about comparisons, so one value has no violating pair.",
            legend: LEG,
            codeLine: 2,
          });
          for (let i = 1; i < nums.length; i++) {
            const dir = nums[i] > nums[i - 1] ? 1 : nums[i] < nums[i - 1] ? -1 : 0;
            if (dir === 0) curr = 1;
            else if (dir === -prev) curr++;
            else curr = 2;
            prev = dir;
            best = Math.max(best, curr);
            out.push({
              title: dir === 0 ? "Equal pair breaks the run" : `Direction ${dir > 0 ? "up" : "down"}; run length ${curr}`,
              tracks: [track("numbers", nums, nums.map((v, k) => (k === i - 1 || k === i ? "compare" : k < i ? "done" : "idle"))), chips("run", [curr], curr === best ? "result" : "active")],
              counters: [count("best", best), count("current", curr)],
              happened: dir === 0 ? "Equal neighbors cannot be part of a strict alternating subarray." : dir === -prev ? "The comparison flipped, so the run extended by one." : "The run restarted with this pair.",
              why: "Turbulence requires every adjacent comparison to alternate.",
              legend: LEG,
              codeLine: 6,
            });
          }
          out.push({
            title: `Longest turbulent length is ${best}`,
            tracks: [track("numbers", nums, fill(nums.length, "done")), chips("answer", [best], "result")],
            counters: [count("answer", best)],
            happened: "The largest run seen during the scan is the answer.",
            why: "Every possible ending position was considered exactly once.",
            legend: LEG,
            codeLine: 11,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "jump-game-vii",
    title: "Jump Game VII",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Check whether the last position is reachable using jumps in a range.",
    input: { label: "binary string | minJump maxJump", default: "011010 | 2 3", parse: "string" },
    approaches: [
      {
        name: "Reachability with a Sliding Window",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Maintain prefix counts of reachable positions. Position i is reachable if it contains 0 and some reachable position lies in [i - maxJump, i - minJump].",
          "The prefix count answers that range query in O(1), giving a linear scan. The start position 0 is reachable by definition.",
        ],
        problem: ["The prefix array uses O(n) memory; a deque of reachable indices can reduce it."],
        code: {
          c: `#include <stdbool.h>\n#include <string.h>\n\nbool canReach(char* s, int minJump, int maxJump) {\n    int n = strlen(s);\n    int* prefix = calloc(n + 1, sizeof(int));\n    prefix[1] = 1;\n    for (int i = 1; i < n; i++) {\n        int lo = i - maxJump < 0 ? 0 : i - maxJump;\n        int hi = i - minJump;\n        int reachable = 0;\n        if (hi >= 0) reachable = prefix[hi + 1] - prefix[lo];\n        if (s[i] == '0' && reachable > 0) prefix[i + 1] = prefix[i] + 1;\n        else prefix[i + 1] = prefix[i];\n    }\n    return s[n-1] == '0' && prefix[n] > prefix[n-1];\n}`,
          cpp: `#include <string>\n#include <vector>\nusing namespace std;\n\nbool canReach(string s, int minJump, int maxJump) {\n    int n = s.size();\n    vector<int> prefix(n + 1, 0);\n    prefix[1] = 1;\n    for (int i = 1; i < n; i++) {\n        int lo = max(0, i - maxJump);\n        int hi = i - minJump;\n        bool reachable = hi >= 0 && prefix[hi + 1] - prefix[lo] > 0;\n        prefix[i + 1] = prefix[i] + (s[i] == '0' && reachable ? 1 : 0);\n    }\n    return s.back() == '0' && prefix[n] > prefix[n - 1];\n}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const s = parts[0] || "";
          const jumps = ints(parts[1] || "").slice(0, 2);
          const minJump = Math.max(1, jumps[0] || 1);
          const maxJump = Math.max(minJump, jumps[1] || minJump);
          const chars = [...s];
          const prefix = new Array(chars.length + 1).fill(0);
          prefix[1] = 1;
          const out = [];
          out.push({
            title: `Jumps must be between ${minJump} and ${maxJump}`,
            tracks: [track("string", chars, chars.map((c, i) => (i === 0 ? "result" : "idle")))],
            counters: [count("reachable", 1), count("position", 0)],
            happened: "Index 0 is the start and is reachable without a jump.",
            why: "Only positions holding '0' may be landed on.",
            legend: LEG,
            codeLine: 4,
          });
          for (let i = 1; i < chars.length; i++) {
            const lo = Math.max(0, i - maxJump);
            const hi = i - minJump;
            const reachable = hi >= 0 && prefix[hi + 1] - prefix[lo] > 0;
            const canStand = chars[i] === "0";
            if (canStand && reachable) prefix[i + 1] = prefix[i] + 1;
            else prefix[i + 1] = prefix[i];
            out.push({
              title: `Position ${i} is ${canStand && reachable ? "reachable" : "not reachable"}`,
              tracks: [track("string", chars, chars.map((c, k) => (k === i ? (canStand && reachable ? "result" : "bad") : k < i ? "done" : "idle")))],
              counters: [count("reachable positions", prefix[i + 1]), count("range", lo + ".." + (hi >= 0 ? hi : "none"))],
              happened: canStand ? (reachable ? "A reachable position can jump into this window." : "No reachable position lies inside the allowed jump window.") : "This position is blocked by a '1'.",
              why: "The prefix count tells whether the jump interval contains a reachable index.",
              legend: LEG,
              codeLine: 9,
            });
          }
          const ok = chars[chars.length - 1] === "0" && prefix[chars.length] > prefix[chars.length - 1];
          out.push({
            title: ok ? "The end is reachable" : "The end cannot be reached",
            tracks: [chips("answer", [ok ? "true" : "false"], ok ? "result" : "bad")],
            counters: [count("answer", ok ? "true" : "false"), count("reachable positions", prefix[chars.length])],
            happened: ok ? "A valid sequence of jumps lands on the last index." : "No combination of allowed jumps reaches the last index.",
            why: "The last index must be reachable as a landing position, not merely inside the string.",
            legend: LEG,
            codeLine: 13,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "dota2-senate",
    title: "Dota2 Senate",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Simulate senators banning the next opponent until one party wins.",
    input: { label: "Senate string", default: "RDD", parse: "string" },
    approaches: [
      {
        name: "Two Queues of Indices",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Each senator wants to ban the earliest opponent who would otherwise act. Queues of indices preserve that cyclic order.",
          "Compare the front indices: the smaller index acts first, bans the other, and re-enters the queue at index + n for the next round.",
        ],
        problem: ["The queues can be replaced by counters in one special case, but the queue simulation is clearer for arbitrary strings."],
        code: {
          c: `#include <string.h>\n\nchar* predictPartyVictory(char* senate) {\n    int n = strlen(senate);\n    int* r = malloc(n * sizeof(int));\n    int* d = malloc(n * sizeof(int));\n    int rn = 0, dn = 0;\n    for (int i = 0; i < n; i++) (senate[i] == 'R' ? r[rn++] : d[dn++]) = i;\n    int rh = 0, dh = 0;\n    while (rn - rh > 0 && dn - dh > 0) {\n        int ri = r[rh++], di = d[dh++];\n        if (ri < di) r[rn++] = ri + n;\n        else d[dn++] = di + n;\n    }\n    return rn - rh > 0 ? \"Radiant\" : \"Dire\";\n}`,
          cpp: `#include <queue>\n#include <string>\nusing namespace std;\n\nstring predictPartyVictory(string senate) {\n    int n = senate.size();\n    queue<int> r, d;\n    for (int i = 0; i < n; i++) (senate[i] == 'R' ? r : d).push(i);\n    while (!r.empty() && !d.empty()) {\n        int ri = r.front(); r.pop();\n        int di = d.front(); d.pop();\n        if (ri < di) r.push(ri + n);\n        else d.push(di + n);\n    }\n    return r.empty() ? "Dire" : "Radiant";\n}`,
        },
        steps(text) {
          const chars = [...String(text || "").toUpperCase()].filter((c) => c === "R" || c === "D");
          const r = [], d = [];
          chars.forEach((c, i) => (c === "R" ? r : d).push(i));
          const out = [];
          out.push({
            title: "Queue both parties in order",
            tracks: [chips("senate", chars, (i) => (chars[i] === "R" ? "good" : "bad")), chips("R queue", r, "good"), chips("D queue", d, "bad")],
            counters: [count("R", r.length), count("D", d.length)],
            happened: `Radiant has ${r.length} senator(s), Dire has ${d.length}.`,
            why: "The leftmost senator acts before later senators, so index order matters.",
            legend: LEG,
            codeLine: 4,
          });
          const rq = r.slice(), dq = d.slice();
          let rh = 0, dh = 0;
          while (rq.length - rh > 0 && dq.length - dh > 0) {
            const ri = rq[rh++], di = dq[dh++];
            if (ri < di) rq.push(ri + chars.length);
            else dq.push(di + chars.length);
            out.push({
              title: ri < di ? `R at ${ri} bans D at ${di}` : `D at ${di} bans R at ${ri}`,
              tracks: [chips("R queue", rq.slice(rh), "good"), chips("D queue", dq.slice(dh), "bad")],
              counters: [count("R left", rq.length - rh), count("D left", dq.length - dh)],
              happened: `The earlier senator acts first and removes the opponent's turn.`,
              why: "A banned senator cannot ban anyone, so removing the earliest opponent is optimal.",
              legend: LEG,
              codeLine: 9,
            });
          }
          const winner = rq.length - rh > 0 ? "Radiant" : "Dire";
          out.push({
            title: `${winner} wins`,
            tracks: [chips("winner", [winner], "result")],
            counters: [count("winner", winner)],
            happened: "One party has no senators left to act.",
            why: "The surviving party can keep banning until the other queue is empty.",
            legend: LEG,
            codeLine: 12,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "valid-parenthesis-string",
    title: "Valid Parenthesis String",
    category: "Greedy",
    difficulty: "Intermediate",
    description: "Check parentheses when stars may be left, right, or empty.",
    input: { label: "Parenthesis string", default: "(*)", parse: "string" },
    approaches: [
      {
        name: "Track a Range of Open Counts",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Keep the minimum and maximum possible number of unmatched opening brackets. A left bracket increases both, a right decreases both, and a star increases the maximum while decreasing the minimum.",
          "The range captures every choice of star. If the maximum ever goes negative, too many closers have appeared; if the minimum drops below zero, clamp it to zero because extra closers can have been matched by stars.",
        ],
        problem: ["The range is a compressed summary; it proves feasibility without listing the actual star assignments."],
        code: {
          c: `#include <stdbool.h>\n\nbool checkValidString(char* s) {\n    int low = 0, high = 0;\n    for (int i = 0; s[i]; i++) {\n        if (s[i] == '(') { low++; high++; }\n        else if (s[i] == ')') { low--; high--; }\n        else { low--; high++; }\n        if (high < 0) return false;\n        if (low < 0) low = 0;\n    }\n    return low == 0;\n}`,
          cpp: `#include <string>\nusing namespace std;\n\nbool checkValidString(string s) {\n    int low = 0, high = 0;\n    for (char c : s) {\n        if (c == '(') { low++; high++; }\n        else if (c == ')') { low--; high--; }\n        else { low--; high++; }\n        if (high < 0) return false;\n        if (low < 0) low = 0;\n    }\n    return low == 0;\n}`,
        },
        steps(text) {
          const chars = [...String(text || "")];
          let low = 0, high = 0;
          const out = [];
          out.push({
            title: "Track a range of possible open counts",
            tracks: [track("string", chars, fill(chars.length, "idle")), chips("open count range", ["0..0"], "idle")],
            counters: [count("low", 0), count("high", 0)],
            happened: "Before reading anything, the only possible open count is zero.",
            why: "Star choices can create several valid open counts at once.",
            legend: LEG,
            codeLine: 2,
          });
          for (let i = 0; i < chars.length; i++) {
            const c = chars[i];
            if (c === "(") { low++; high++; }
            else if (c === ")") { low--; high--; }
            else { low--; high++; }
            const dead = high < 0;
            if (low < 0) low = 0;
            out.push({
              title: dead ? "Too many closing brackets" : `Range is now ${low}..${high}`,
              tracks: [track("string", chars, chars.map((x, k) => (k === i ? (dead ? "bad" : "read") : k < i ? "done" : "idle"))), chips("open count range", [low + ".." + high], dead ? "bad" : "active")],
              counters: [count("low", low), count("high", high)],
              happened: dead ? "Even using every star as a left bracket cannot save this prefix." : `The star choices allow between ${low} and ${high} unmatched left brackets.`,
              why: dead ? "The maximum possible open count became negative." : "A star can be empty, opening, or closing, expanding the range.",
              legend: LEG,
              codeLine: 6,
            });
            if (dead) return out;
          }
          const ok = low === 0;
          out.push({
            title: ok ? "A valid assignment exists" : "Some opening bracket cannot close",
            tracks: [chips("answer", [ok ? "true" : "false"], ok ? "result" : "bad")],
            counters: [count("low", low), count("high", high)],
            happened: ok ? "Zero is inside the final possible-open range." : "The minimum open count is still above zero.",
            why: "A valid string must be able to finish with no unmatched opening brackets.",
            legend: LEG,
            codeLine: 9,
          });
          return out;
        },
      },
    ],
  });
})();
