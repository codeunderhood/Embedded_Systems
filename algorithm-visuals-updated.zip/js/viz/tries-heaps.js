/* ============================================================
   DSA Visuals — Tries & Heaps
   Six trie visualisations and two heap ones. All original work
   following the contract in SPEC.md:
     { id, title, category, difficulty, description,
       input: { label, default, parse },
       approaches: [ { name, complexity, idea, problem,
                       code: { c, cpp }, steps(parsed) } ] }
   Trie scheme: the trie is drawn as a PATH track — each cell is
   one node walked from the root, its tag is the full letter path
   so far. Heaps are drawn as one cells track sorted so the most
   extreme value sits at the left.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count, grid } = window.H;
  const V = window.VIZ;

  /* ---------- shared bits ---------- */
  function tn() { return { kids: {}, end: false, val: 0, word: null }; }
  function splitWords(s) { return String(s == null ? "" : s).split(/\s+/).filter(Boolean); }
  function blankCell(tag) { return { v: "—", state: "idle", empty: true, tag: tag }; }

  /* ============================================================
     1. Implement Trie
     ============================================================ */
  V.register({
    id: "implement-trie",
    title: "Implement Trie",
    category: "Tries",
    difficulty: "Intermediate",
    description: "Store words as letter paths so insert and lookup walk the tree once.",
    input: { label: "Commands: insert X / search X / startsWith X", default: "insert apple insert app search apple search app search ab", parse: "tokens" },
    approaches: [
      {
        name: "One Node per Letter",
        complexity: "O(L) per command, alphabet × nodes space",
        idea: [
          "A trie stores words as paths: the root is empty, each step down consumes one letter, and a node flagged 'word ends here' marks a complete word. Shared prefixes (the 'app' inside 'apple') share their nodes.",
          "On screen the trie is drawn as a PATH track: each cell is one node on the walk from the root and its tag is the full letter path so far. Letters that already existed are shown as handled; freshly created ones light up. A second track lists the command script with the current token highlighted.",
          "Commands: 'insert X' walks (creating missing nodes) and flags the last one; 'search X' walks and then checks the end flag; 'startsWith X' only needs the path to exist. Unknown tokens are skipped with a friendly note.",
        ],
        problem: [
          "Every command costs time proportional to the word length — very fast — but each node keeps one pointer slot per letter of the alphabet (26 here), so a trie of n characters can burn far more memory than a plain list of the same words.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* one node per letter; children indexed by a-z */
typedef struct Node {
    struct Node *kids[26];
    bool end; /* a word finishes here */
} Node;

static Node pool[4096];
static int used = 0;
static Node *new_node(void) { return &pool[used++]; }

void trie_insert(Node *root, const char *w) {
    Node *cur = root;
    for (; *w; w++) {
        int i = *w - 'a';
        if (!cur->kids[i])
            cur->kids[i] = new_node();
        cur = cur->kids[i];
    }
    cur->end = true;         /* word complete */
}

bool trie_search(Node *root, const char *w) {
    Node *cur = root;
    for (; *w; w++) {
        int i = *w - 'a';
        if (!cur->kids[i])
            return false;    /* path breaks */
        cur = cur->kids[i];
    }
    return cur->end;         /* path alone is not enough */
}

bool trie_starts_with(Node *root, const char *p) {
    Node *cur = root;
    for (; *p; p++) {
        int i = *p - 'a';
        if (!cur->kids[i])
            return false;
        cur = cur->kids[i];
    }
    return true;             /* any node along the way will do */
}

int main(void) {
    Node root = {{0}, false};
    trie_insert(&root, "apple");
    trie_insert(&root, "app");
    printf("%d %d %d\\n", trie_search(&root, "apple"),
           trie_search(&root, "app"), trie_search(&root, "ab")); /* 1 1 0 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>

// one node per letter; children indexed by a-z
struct Node {
    Node* kids[26] = {};
    bool end = false;
};

class Trie {
    Node root;
    Node* walk(const std::string& s, bool create) {
        Node* cur = &root;
        for (char c : s) {
            int i = c - 'a';
            if (!cur->kids[i]) {
                if (!create) return nullptr;   // path breaks
                cur->kids[i] = new Node();     // demo skips cleanup
            }
            cur = cur->kids[i];
        }
        return cur;
    }
public:
    void insert(const std::string& w) { walk(w, true)->end = true; }
    bool search(const std::string& w) {
        Node* n = walk(w, false);
        return n && n->end;                    // end flag required
    }
    bool startsWith(const std::string& p) {
        return walk(p, false) != nullptr;      // path is enough
    }
};

int main() {
    Trie t;
    t.insert("apple");
    t.insert("app");
    std::cout << t.search("apple") << ' ' << t.search("app")
              << ' ' << t.search("ab") << '\\n'; // 1 1 0
}`,
        },
        steps(tokens) {
          const root = tn();
          const ops = [];
          for (let i = 0; i < tokens.length; ) {
            const op = tokens[i].toLowerCase();
            if (op === "insert" || op === "search" || op === "startswith") {
              const arg = tokens[i + 1] != null ? tokens[i + 1] : null;
              ops.push({ op, arg, from: i, to: arg != null ? i + 1 : i });
              i += arg != null ? 2 : 1;
            } else {
              ops.push({ op: "skip", arg: tokens[i], from: i, to: i });
              i += 1;
            }
          }
          let nodes = 0, taken = 0, opDone = 0;
          const results = [];
          const steps = [];
          const cmdTrack = (op) =>
            track("commands", tokens, tokens.map((_, i) => (i < op.from ? "done" : i <= op.to ? "read" : "idle")));
          const trieCell = () => ({ label: "trie so far", cells: [{ v: "root", state: "done", tag: nodes + " nodes" }] });
          const pathTrack = (shown, states) => ({
            label: "trie path (root → node)",
            cells: shown.length
              ? shown.map((c, j) => ({ v: c, state: states[j], tag: shown.slice(0, j + 1).join("") }))
              : [{ v: "root", state: "read", tag: "start here" }],
          });

          steps.push({
            title: "Set up: an empty trie and the command script",
            showIdx: false,
            tracks: [
              track("commands", tokens, fill(tokens.length, "idle")),
              { label: "trie so far", cells: [{ v: "root", state: "idle", tag: "0 nodes" }] },
            ],
            counters: [count("commands", 0, ops.length), count("nodes created", 0), count("steps taken", 0)],
            legend: ["read", "done", "result", "bad", "idle"],
            happened: `${ops.length} command${ops.length === 1 ? "" : "s"} to run against a trie that is currently just a bare root node.`,
            why: "Everything in a trie is built by hanging letter nodes off the root, so starting empty keeps every later walk honest.",
            codeLine: 10,
          });

          for (const op of ops) {
            const base = [count("commands", opDone, ops.length), count("nodes created", nodes), count("steps taken", taken)];

            if (op.op === "skip") {
              steps.push({
                title: `Unrecognised token '${op.arg}' — skipped politely`,
                showIdx: false,
                tracks: [cmdTrack(op), trieCell()],
                counters: base,
                legend: ["read", "done", "idle"],
                happened: `'${op.arg}' is not one of insert / search / startsWith, so the trie is left untouched and the script moves on.`,
                why: "A command loop should survive junk input: ignoring unknown tokens keeps the rest of the script running instead of crashing.",
                codeLine: 36,
              });
              opDone++;
              continue;
            }

            if (op.arg == null) {
              steps.push({
                title: `'${op.op}' appears with no word after it — nothing to do`,
                showIdx: false,
                tracks: [cmdTrack(op), trieCell()],
                counters: base,
                legend: ["read", "done", "idle"],
                happened: `The script ends right after '${op.op}', so there is no argument to work with.`,
                why: "Checking for a missing argument up front is cheaper and friendlier than dereferencing nothing later.",
                codeLine: 16,
              });
              opDone++;
              continue;
            }

            const letters = op.arg.split("");
            const opLabel = op.op === "insert" ? "insert" : op.op === "search" ? "search" : "startsWith";

            if (op.op === "insert") {
              let node = root;
              for (let k = 0; k < letters.length; k++) {
                const ch = letters[k];
                const existed = !!node.kids[ch];
                if (!existed) { node.kids[ch] = tn(); nodes++; }
                node = node.kids[ch];
                const isLast = k === letters.length - 1;
                if (isLast) node.end = true;
                taken++;
                const shown = letters.slice(0, k + 1);
                const states = shown.map((_, j) => (j === k ? (existed ? "done" : "read") : "done"));
                steps.push({
                  title: isLast
                    ? existed
                      ? `insert ${op.arg}: '${op.arg}' was already stored — end flag stays`
                      : `insert ${op.arg}: create node '${ch}' and flag '${op.arg}' as a complete word`
                    : `insert ${op.arg}: ${existed ? "follow existing node" : "create node"} '${ch}'`,
                  showIdx: false,
                  tracks: [
                    cmdTrack(op),
                    pathTrack(shown, states),
                    { label: "this node", cells: [{ v: ch, state: existed ? "done" : "read", tag: existed ? "already there" : "new node" + (isLast ? " · word end" : "") }] },
                  ],
                  counters: [count("commands", opDone, ops.length), count("nodes created", nodes), count("steps taken", taken)],
                  legend: ["read", "done", "result", "idle"],
                  happened: existed
                    ? `The node for '${ch}' already hangs below the path, so the walk simply follows it.`
                    : `No '${ch}' node existed below the path, so a fresh one is created and linked in.`,
                  why: isLast
                    ? "Flagging the last node is what later lets 'search' tell 'app' (a word) from 'ap' (just a path)."
                    : "Insert walks letter by letter, creating only the missing pieces — shared prefixes are reused, never rebuilt.",
                  codeLine: existed ? 16 : 18,
                });
              }
              opDone++;
              continue;
            }

            /* search or startsWith: walk as far as the path allows */
            let node = root;
            let dead = -1;
            for (let k = 0; k < letters.length; k++) {
              const ch = letters[k];
              if (!node.kids[ch]) { dead = k; break; }
              node = node.kids[ch];
              taken++;
            }
            const last = dead >= 0 ? dead : letters.length - 1;
            for (let k = 0; k <= last; k++) {
              const ch = letters[k];
              const missing = k === dead;
              const shown = letters.slice(0, missing ? k : k + 1);
              steps.push({
                title: missing
                  ? `${opLabel} ${op.arg}: no '${ch}' node below the path — the walk stops`
                  : `${opLabel} ${op.arg}: '${ch}' node exists — keep walking`,
                showIdx: false,
                tracks: [
                  cmdTrack(op),
                  pathTrack(shown, shown.map((_, j) => (j === (missing ? shown.length - 1 : k) ? (missing ? "bad" : "read") : "done"))),
                  { label: "this node", cells: [{ v: ch, state: missing ? "bad" : "read", tag: missing ? "no such node" : "on the path" }] },
                ],
                counters: [count("commands", opDone, ops.length), count("nodes created", nodes), count("steps taken", taken)],
                legend: missing ? ["read", "done", "bad", "idle"] : ["read", "done", "bad", "idle"],
                happened: missing
                  ? `The path has no child labelled '${ch}', so no word or prefix can begin with '${op.arg.slice(0, k + 1)}'.`
                  : `A node labelled '${ch}' sits below the current path, so the walk continues from there.`,
                why: missing
                  ? "A missing letter breaks the path for good — no amount of later letters can repair it."
                  : "Lookup never scans the whole trie: it follows exactly one chain of letters, one node per character.",
                codeLine: missing ? 29 : 27,
              });
            }

            let ok, verdict, resultState, line;
            if (dead >= 0) {
              ok = false;
              verdict = op.op === "search" ? "missing" : "no such prefix";
              line = 29;
            } else if (op.op === "search") {
              ok = node.end;
              verdict = ok ? "found" : "path only — no word ends here";
              line = 33;
            } else {
              ok = true;
              verdict = "prefix exists";
              line = 43;
            }
            results.push({ arg: op.arg, verdict, ok });
            steps.push({
              title: ok
                ? `${opLabel} ${op.arg}: ${verdict}`
                : `${opLabel} ${op.arg}: ${verdict}`,
              showIdx: false,
              tracks: [
                cmdTrack(op),
                pathTrack(letters.slice(0, last + 1), fill(Math.min(last + 1, letters.length), ok ? "result" : "bad")),
                { label: "answer for this command", cells: [{ v: verdict, state: ok ? "good" : "bad", tag: opLabel + " " + op.arg }] },
              ],
              counters: [count("commands", opDone + 1, ops.length), count("nodes created", nodes), count("steps taken", taken), count("answer", verdict)],
              legend: ["read", "done", "good", "bad", "result", "idle"],
              happened: op.op === "search"
                ? ok
                  ? `Every letter matched and the final node carries the word-end flag — '${op.arg}' is in the trie.`
                  : dead >= 0
                    ? `The path broke before the word ran out — '${op.arg}' was never inserted.`
                    : `All letters exist but the last node has no word-end flag — '${op.arg}' is only a prefix of stored words.`
                : ok
                  ? `Every letter of '${op.arg}' exists along one path, so longer words starting with it may be stored.`
                  : `The path broke — nothing in the trie begins with '${op.arg}'.`,
              why: op.op === "search"
                ? "The end flag is the difference between a word and a fragment — that two-part check is the whole of 'search'."
                : "'startsWith' skips the end-flag check entirely: any node along a complete path is enough to answer yes.",
              codeLine: line,
            });
            opDone++;
          }

          steps.push({
            title: results.length ? `Answer: ${results.map((r) => r.verdict).join(" · ")}` : "Answer: no searches in this script",
            showIdx: false,
            tracks: [
              track("commands", tokens, fill(tokens.length, "done")),
              {
                label: "search results",
                cells: results.length
                  ? results.map((r) => ({ v: `${r.arg}: ${r.verdict}`, state: r.ok ? "good" : "bad" }))
                  : [blankCell("nothing to answer")],
              },
            ],
            counters: [count("commands", ops.length, ops.length), count("nodes created", nodes), count("steps taken", taken), count("answer", results.length)],
            legend: ["done", "good", "bad", "result"],
            happened: results.length
              ? `The script finished: ${results.length} question${results.length === 1 ? "" : "s"} answered from the same tree of ${nodes} letter nodes.`
              : "The script finished without a single search — the trie was built but never queried.",
            why: "Every answer cost one walk from the root: no word list was ever scanned, which is exactly why tries earn their keep.",
            codeLine: 33,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     2. Design Add and Search Words
     ============================================================ */
  V.register({
    id: "design-add-and-search-words",
    title: "Design Add and Search Words",
    category: "Tries",
    difficulty: "Intermediate",
    description: "Add words to a trie, then search patterns where '.' stands for any letter.",
    input: { label: "Commands: add word / search pattern ('.' = any letter)", default: "add app add ape search .pp search app search ..e", parse: "tokens" },
    approaches: [
      {
        name: "Trie Walk with Wildcard Branching",
        complexity: "add O(L); search O(26^k) worst with k dots, typical far less",
        idea: [
          "The dictionary lives in a trie exactly like 'Implement Trie'. The twist is the search pattern: a '.' may be any letter, so wherever the pattern shows '.', the walk cannot pick one child — it must try EVERY child the current node has.",
          "On screen the trie is a PATH track (one cell per node, tag = the letter path so far) and the pattern gets its own track with the current position highlighted; the '.' cell is shown in the 'comparing' colour because it stands for many letters at once.",
          "The search runs as an explicit depth-first walk: each queued branch is (node, position in pattern). A branch dies as soon as the pattern asks for a letter the node lacks; the first branch that consumes the whole pattern on a word-end node answers 'found'.",
        ],
        problem: [
          "A pattern made of dots can fan out at every level — k dots against a node with 26 children means up to 26^k branches. In practice tries prune almost all of them instantly, but a dot-heavy pattern on a dense trie is the honest worst case.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

typedef struct Node {
    struct Node *kids[26];
    bool end;
} Node;

static Node pool[4096];
static int used = 0;
static Node *new_node(void) { return &pool[used++]; }

void add_word(Node *root, const char *w) {
    Node *cur = root;
    for (; *w; w++) {
        int i = *w - 'a';
        if (!cur->kids[i])
            cur->kids[i] = new_node();
        cur = cur->kids[i];
    }
    cur->end = true;
}

/* walk the pattern; '.' branches into every existing child */
bool dfs(Node *node, const char *p) {
    if (!*p)
        return node->end;
    if (*p != '.') {
        int i = *p - 'a';
        return node->kids[i] && dfs(node->kids[i], p + 1);
    }
    for (int i = 0; i < 26; i++)
        if (node->kids[i] && dfs(node->kids[i], p + 1))
            return true;
    return false;            /* no child led to a word */
}

int main(void) {
    Node root = {{0}, false};
    add_word(&root, "app");
    add_word(&root, "ape");
    printf("%d %d %d\\n", dfs(&root, ".pp"),
           dfs(&root, "app"), dfs(&root, "..e")); /* 1 1 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>

struct Node {
    Node* kids[26] = {};
    bool end = false;
};

// '.' means "any letter": at a dot the search forks over all children
bool dfs(Node* node, const std::string& p, int pos) {
    if (pos == (int)p.size()) return node->end;
    if (p[pos] != '.') {
        int i = p[pos] - 'a';
        return node->kids[i] && dfs(node->kids[i], p, pos + 1);
    }
    for (int i = 0; i < 26; ++i)
        if (node->kids[i] && dfs(node->kids[i], p, pos + 1))
            return true;                 // one match is enough
    return false;
}

class WordDictionary {
    Node root;
public:
    void addWord(const std::string& w) {
        Node* cur = &root;
        for (char c : w) {
            int i = c - 'a';
            if (!cur->kids[i]) cur->kids[i] = new Node(); // demo: no cleanup
            cur = cur->kids[i];
        }
        cur->end = true;
    }
    bool search(const std::string& p) { return dfs(&root, p, 0); }
};

int main() {
    WordDictionary d;
    d.addWord("app");
    d.addWord("ape");
    std::cout << d.search(".pp") << ' ' << d.search("app")
              << ' ' << d.search("..e") << '\\n'; // 1 1 1
}`,
        },
        steps(tokens) {
          const root = tn();
          const ops = [];
          for (let i = 0; i < tokens.length; ) {
            const op = tokens[i].toLowerCase();
            if (op === "add" || op === "search") {
              const arg = tokens[i + 1] != null ? tokens[i + 1] : null;
              ops.push({ op, arg, from: i, to: arg != null ? i + 1 : i });
              i += arg != null ? 2 : 1;
            } else {
              ops.push({ op: "skip", arg: tokens[i], from: i, to: i });
              i += 1;
            }
          }
          let nodes = 0, branches = 0, answered = 0, opDone = 0;
          const results = [];
          const steps = [];
          const cmdTrack = (op) =>
            track("commands", tokens, tokens.map((_, i) => (i < op.from ? "done" : i <= op.to ? "read" : "idle")));
          const trieCell = () => ({ label: "trie so far", cells: [{ v: "root", state: "done", tag: nodes + " nodes" }] });
          const pathTrack = (path, hot, hotState) => ({
            label: "trie path (root → node)",
            cells: path.length
              ? path.map((c, j) => ({ v: c, state: j === hot ? hotState || "read" : "done", tag: path.slice(0, j + 1).join("") }))
              : [{ v: "root", state: "read", tag: "start here" }],
          });
          const patTrack = (pat, pos) =>
            track("pattern", pat.split(""), pat.split("").map((_, i) => (i < pos ? "done" : i === pos ? (pat[i] === "." ? "compare" : "read") : "idle")), pat.split("").map((c) => (c === "." ? "any letter" : undefined)));

          steps.push({
            title: "Set up: an empty dictionary trie and the command script",
            showIdx: false,
            tracks: [
              track("commands", tokens, fill(tokens.length, "idle")),
              { label: "dictionary trie", cells: [{ v: "root", state: "idle", tag: "0 nodes" }] },
            ],
            counters: [count("commands", 0, ops.length), count("nodes created", 0), count("branches tried", 0)],
            legend: ["read", "done", "compare", "idle"],
            happened: `${ops.length} command${ops.length === 1 ? "" : "s"} against a dictionary that starts empty. The '.' in any pattern stands for a single arbitrary letter.`,
            why: "Keeping adds and wildcard searches on one trie means the expensive part of every search is paid for once, at insert time.",
            codeLine: 9,
          });

          for (const op of ops) {
            const base = [count("commands", opDone, ops.length), count("nodes created", nodes), count("branches tried", branches)];

            if (op.op === "skip") {
              steps.push({
                title: `Unrecognised token '${op.arg}' — skipped politely`,
                showIdx: false,
                tracks: [cmdTrack(op), trieCell()],
                counters: base,
                legend: ["read", "done", "idle"],
                happened: `'${op.arg}' is not an add or search command, so the dictionary is left alone.`,
                why: "An unknown token should cost one shrug, not a crash — the rest of the script carries on.",
                codeLine: 16,
              });
              opDone++;
              continue;
            }

            if (op.arg == null) {
              steps.push({
                title: `'${op.op}' appears with no argument — nothing to do`,
                showIdx: false,
                tracks: [cmdTrack(op), trieCell()],
                counters: base,
                legend: ["read", "done", "idle"],
                happened: `The script ends right after '${op.op}', so there is no word or pattern to process.`,
                why: "Checking for the missing argument before touching the trie keeps the command loop crash-free.",
                codeLine: 13,
              });
              opDone++;
              continue;
            }

            const letters = op.arg.split("");

            if (op.op === "add") {
              let node = root;
              for (let k = 0; k < letters.length; k++) {
                const ch = letters[k];
                const existed = !!node.kids[ch];
                if (!existed) { node.kids[ch] = tn(); nodes++; }
                node = node.kids[ch];
                const isLast = k === letters.length - 1;
                if (isLast) node.end = true;
                const shown = letters.slice(0, k + 1);
                steps.push({
                  title: isLast
                    ? existed
                      ? `add ${op.arg}: '${op.arg}' was already in the dictionary`
                      : `add ${op.arg}: create node '${ch}' and flag '${op.arg}' as a word`
                    : `add ${op.arg}: ${existed ? "follow existing node" : "create node"} '${ch}'`,
                  showIdx: false,
                  tracks: [
                    cmdTrack(op),
                    pathTrack(shown, k, existed ? "done" : "read"),
                    { label: "this node", cells: [{ v: ch, state: existed ? "done" : "read", tag: existed ? "already there" : "new node" + (isLast ? " · word end" : "") }] },
                  ],
                  counters: [count("commands", opDone, ops.length), count("nodes created", nodes), count("branches tried", branches)],
                  legend: ["read", "done", "result", "idle"],
                  happened: existed
                    ? `A node for '${ch}' already hangs below the path, so the add reuses it.`
                    : `No '${ch}' node existed, so one is created and linked in.`,
                  why: isLast
                    ? "The word-end flag is what later lets a search distinguish a stored word from a bare path."
                    : "Adds walk one letter per step and share any prefix already in the dictionary.",
                  codeLine: existed ? 14 : 16,
                });
              }
              opDone++;
              continue;
            }

            /* search pattern: depth-first with wildcard forks */
            const pat = op.arg;
            steps.push({
              title: `search '${pat}': start at the root, pattern position 0`,
              showIdx: false,
              tracks: [cmdTrack(op), pathTrack([], 0), patTrack(pat, 0)],
              counters: base,
              legend: ["read", "done", "compare", "bad", "idle"],
              happened: pat.includes(".")
                ? `The pattern contains ${pat.split(".").length - 1} dot${pat.split(".").length - 1 === 1 ? "" : "s"}; each one may match any letter, so the walk can fork.`
                : "This pattern has no dots, so it walks a single path just like a plain search.",
              why: "Setting the starting state (root node, position 0) before exploring keeps every later branch easy to follow.",
              codeLine: 24,
            });

            const stack = [{ node: root, pos: 0, path: [] }];
            let done = false, guard = 0;
            while (stack.length && !done) {
              if (guard++ > 60) {
                steps.push({
                  title: "Search budget reached — the pattern is too branchy to animate",
                  showIdx: false,
                  tracks: [cmdTrack(op), patTrack(pat, pat.length)],
                  counters: [count("commands", opDone + 1, ops.length), count("nodes created", nodes), count("branches tried", branches)],
                  legend: ["read", "done", "compare", "idle"],
                  happened: "The dot-forks multiplied past the readable limit, so the animation stops exploring this pattern.",
                  why: "This is the wildcard worst case in the flesh: many dots on a dense trie fan out fast. The real search would keep going; the animation stays readable by stopping.",
                  codeLine: 31,
                });
                results.push({ arg: pat, verdict: "gave up (too many branches)", ok: false });
                done = true;
                break;
              }
              const cur = stack.pop();
              if (cur.pos === pat.length) {
                if (cur.node.end) {
                  results.push({ arg: pat, verdict: `found as "${cur.path.join("")}"`, ok: true });
                  branches++;
                  steps.push({
                    title: `search '${pat}': pattern consumed and a word ends here → found!`,
                    showIdx: false,
                    tracks: [
                      cmdTrack(op),
                      pathTrack(cur.path, cur.path.length - 1, "result"),
                      patTrack(pat, pat.length),
                      { label: "matching word", cells: [{ v: cur.path.join(""), state: "good", tag: "wildcard match" }] },
                    ],
                    counters: [count("commands", opDone + 1, ops.length), count("nodes created", nodes), count("branches tried", branches), count("answer", "found")],
                    legend: ["read", "done", "good", "result", "compare", "idle"],
                    happened: `The branch "${cur.path.join("")}" used up the whole pattern and lands on a node flagged as a complete word.`,
                    why: "One confirmed match answers the whole search — no other branch needs exploring.",
                    codeLine: 27,
                  });
                  done = true;
                  break;
                }
                branches++;
                steps.push({
                  title: `search '${pat}': path "${cur.path.join("")}" ends here but no word was added at it — backtrack`,
                  showIdx: false,
                  tracks: [cmdTrack(op), pathTrack(cur.path, cur.path.length - 1, "bad"), patTrack(pat, pat.length)],
                  counters: [count("commands", opDone + 1, ops.length), count("nodes created", nodes), count("branches tried", branches), count("answer", "not yet")],
                  legend: ["read", "done", "bad", "compare", "idle"],
                  happened: `All pattern positions were consumed on the path "${cur.path.join("")}", but that node only sits mid-word — it is not a word end.`,
                  why: "Consuming the pattern is not enough: just like plain search, the end flag must be set too.",
                  codeLine: 28,
                });
                continue;
              }
              const ch = pat[cur.pos];
              if (ch === ".") {
                const kids = Object.keys(cur.node.kids).sort();
                branches++;
                if (!kids.length) {
                  steps.push({
                    title: `search '${pat}': '.' at position ${cur.pos} but this node has no children — dead end`,
                    showIdx: false,
                    tracks: [cmdTrack(op), pathTrack(cur.path, cur.path.length - 1, "bad"), patTrack(pat, cur.pos)],
                    counters: [count("commands", opDone + 1, ops.length), count("nodes created", nodes), count("branches tried", branches)],
                    legend: ["read", "done", "bad", "compare", "idle"],
                    happened: "A dot can only stand for letters that actually continue below this node — there are none, so the branch dies.",
                    why: "Pruning an empty node instantly is what keeps wildcard search from wandering over impossible paths.",
                    codeLine: 34,
                  });
                  continue;
                }
                steps.push({
                  title: `search '${pat}': '.' at position ${cur.pos} forks — try each of the ${kids.length} children (${kids.join(", ")})`,
                  showIdx: false,
                  tracks: [
                    cmdTrack(op),
                    pathTrack(cur.path, cur.path.length - 1, "done"),
                    patTrack(pat, cur.pos),
                    { label: "children to try", cells: kids.map((k) => ({ v: k, state: "active" })) },
                  ],
                  counters: [count("commands", opDone + 1, ops.length), count("nodes created", nodes), count("branches tried", branches)],
                  legend: ["read", "done", "active", "compare", "idle"],
                  happened: `The dot refuses to pick a letter, so every child (${kids.join(", ")}) is queued as its own branch, alphabetically.`,
                  why: "This fork IS the wildcard: one pattern position becomes several parallel walks, each continuing with a concrete letter.",
                  codeLine: 31,
                });
                for (let i = kids.length - 1; i >= 0; i--)
                  stack.push({ node: cur.node.kids[kids[i]], pos: cur.pos + 1, path: cur.path.concat(kids[i]) });
                continue;
              }
              const child = cur.node.kids[ch];
              if (!child) {
                branches++;
                steps.push({
                  title: `search '${pat}': no '${ch}' child at position ${cur.pos} — dead end, backtrack`,
                  showIdx: false,
                  tracks: [cmdTrack(op), pathTrack(cur.path.concat(ch), cur.path.length, "bad"), patTrack(pat, cur.pos)],
                  counters: [count("commands", opDone + 1, ops.length), count("nodes created", nodes), count("branches tried", branches)],
                  legend: ["read", "done", "bad", "compare", "idle"],
                  happened: `The pattern demands '${ch}' here, but the node has no such child, so this branch cannot spell any stored word.`,
                  why: "Concrete letters kill branches in one lookup — only the dots ever pay for branching.",
                  codeLine: 29,
                });
                continue;
              }
              steps.push({
                title: `search '${pat}': pattern letter '${ch}' matches a child node — keep walking`,
                showIdx: false,
                tracks: [cmdTrack(op), pathTrack(cur.path.concat(ch), cur.path.length, "read"), patTrack(pat, cur.pos)],
                counters: [count("commands", opDone + 1, ops.length), count("nodes created", nodes), count("branches tried", branches)],
                legend: ["read", "done", "compare", "idle"],
                happened: `A node labelled '${ch}' exists below "${cur.path.join("")}", so this branch advances to position ${cur.pos + 1}.`,
                why: "Every non-dot character is a single deterministic step — the trie answers 'is there a child for this letter?' in O(1).",
                codeLine: 29,
              });
              stack.push({ node: child, pos: cur.pos + 1, path: cur.path.concat(ch) });
            }
            if (!done) {
              results.push({ arg: pat, verdict: "no match", ok: false });
              steps.push({
                title: `search '${pat}': every branch is exhausted → no match`,
                showIdx: false,
                tracks: [
                  cmdTrack(op),
                  patTrack(pat, pat.length),
                  { label: "answer for this search", cells: [{ v: "no word matches", state: "bad", tag: "'" + pat + "'" }] },
                ],
                counters: [count("commands", opDone + 1, ops.length), count("nodes created", nodes), count("branches tried", branches), count("answer", "no match")],
                legend: ["read", "done", "bad", "compare", "idle"],
                happened: "The queue of pending branches ran dry without a single word-end hit.",
                why: "Exhausting every reachable branch is a real proof of absence, not a guess — the trie contains no matching word.",
                codeLine: 34,
              });
            }
            answered++;
            opDone++;
          }

          steps.push({
            title: results.length ? `Answer: ${results.map((r) => r.verdict).join(" · ")}` : "Answer: no searches in this script",
            showIdx: false,
            tracks: [
              track("commands", tokens, fill(tokens.length, "done")),
              {
                label: "search results",
                cells: results.length
                  ? results.map((r) => ({ v: `${r.arg}: ${r.verdict}`, state: r.ok ? "good" : "bad" }))
                  : [blankCell("nothing to answer")],
              },
            ],
            counters: [count("commands", ops.length, ops.length), count("nodes created", nodes), count("branches tried", branches), count("searches answered", answered)],
            legend: ["done", "good", "bad", "result"],
            happened: results.length
              ? `All ${results.length} search${results.length === 1 ? "" : "es"} resolved against a trie of ${nodes} nodes.`
              : "The script finished without asking a single search question.",
            why: "Dots multiply the work, but concrete letters prune it straight back — the trie pays for both directions.",
            codeLine: 27,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     3. Replace Words
     ============================================================ */
  V.register({
    id: "replace-words",
    title: "Replace Words",
    category: "Tries",
    difficulty: "Intermediate",
    description: "Swap each sentence word for the shortest dictionary word that prefixes it.",
    input: { label: "Dictionary words | sentence", default: "cat bat rat | the cattle was ratted", parse: "string" },
    approaches: [
      {
        name: "Shortest Root via Trie Walk",
        complexity: "O(total dictionary letters) build, O(word length) per replacement",
        idea: [
          "All the dictionary words go into one trie. To rewrite a sentence word, walk its letters from the root and stop at the FIRST node flagged as a word — because the walk consumes letters one at a time, the first flag on the path is automatically the shortest dictionary prefix (the root of that word).",
          "On screen the dictionary and the sentence sit as two tracks, and the trie is drawn as a PATH track whose cell tags show the letter path so far. Walking a sentence word lights up one path cell per letter; the output track fills left to right as words are swapped or kept.",
          "If the walk hits a letter with no child, the word has no root at all and stays exactly as written. The text before the '|' is the dictionary, after it the sentence.",
        ],
        problem: [
          "Building the trie costs space proportional to all dictionary letters, and words that share nothing share no nodes. For a one-shot replacement, sorting the dictionary and binary-searching each word can use less memory — the trie wins when many words are rewritten against the same dictionary.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

typedef struct Node {
    struct Node *kids[26];
    bool end;                /* a dictionary word ends here */
} Node;

static Node pool[4096];
static int used = 0;
static Node *new_node(void) { return &pool[used++]; }

void insert(Node *root, const char *w) {
    Node *cur = root;
    for (; *w; w++) {
        int i = *w - 'a';
        if (!cur->kids[i])
            cur->kids[i] = new_node();
        cur = cur->kids[i];
    }
    cur->end = true;
}

/* length of the shortest dictionary prefix, 0 = keep the word */
int root_len(Node *root, const char *w) {
    Node *cur = root;
    for (int k = 0; w[k]; k++) {
        int i = w[k] - 'a';
        if (!cur->kids[i])
            return 0;        /* no such path in the dictionary */
        cur = cur->kids[i];
        if (cur->end)
            return k + 1;    /* first flag on the path = shortest */
    }
    return 0;
}

int main(void) {
    Node root = {{0}, false};
    const char *dict[] = {"cat", "bat", "rat"};
    const char *sent[] = {"the", "cattle", "was", "ratted"};
    for (int i = 0; i < 3; i++) insert(&root, dict[i]);
    for (int i = 0; i < 4; i++) {
        int k = root_len(&root, sent[i]);
        if (k) printf("%.*s ", k, sent[i]);
        else   printf("%s ", sent[i]);
    }
    printf("\\n");           /* the cat was rat */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>

struct Node {
    Node* kids[26] = {};
    bool end = false;
};

// shortest dictionary prefix of w, or the whole word when there is none
std::string shortestRoot(Node* root, const std::string& w) {
    Node* cur = root;
    for (size_t i = 0; i < w.size(); ++i) {
        int k = w[i] - 'a';
        if (!cur->kids[k]) return w;      // path breaks -> keep word
        cur = cur->kids[k];
        if (cur->end) return w.substr(0, i + 1);  // first flag wins
    }
    return w;
}

int main() {
    Node root;
    for (const std::string& w : {"cat", "bat", "rat"}) {
        Node* cur = &root;
        for (char c : w) {
            int i = c - 'a';
            if (!cur->kids[i]) cur->kids[i] = new Node(); // demo: no cleanup
            cur = cur->kids[i];
        }
        cur->end = true;
    }
    for (const std::string& w : {"the", "cattle", "was", "ratted"})
        std::cout << shortestRoot(&root, w) << ' '; // the cat was rat
    std::cout << '\\n';
}`,
        },
        steps(raw) {
          const parts = String(raw).split("|");
          const dict = splitWords(parts[0]);
          const sentence = splitWords(parts.slice(1).join(" "));
          const root = tn();
          let nodes = 0, built = 0, replaced = 0;
          const out = [];
          const steps = [];
          const dictTrack = (states) => track("dictionary", dict, states || fill(dict.length, "idle"));
          const sentTrack = () => track("sentence", sentence, fill(sentence.length, "idle"));
          const outTrack = (hotIdx) => ({
            label: "replaced sentence",
            cells: out.length
              ? out.map((w, i) => ({ v: w, state: i === hotIdx ? "result" : "done" })).concat(
                  sentence.slice(out.length).map(() => blankCell("pending")),
                )
              : [blankCell("nothing replaced yet")],
          });

          steps.push({
            title: "Set up: dictionary on the left of '|', sentence on the right",
            showIdx: false,
            tracks: [dictTrack(), sentTrack()],
            counters: [count("dictionary words", dict.length), count("sentence words", 0, sentence.length), count("roots found", 0)],
            legend: ["read", "done", "result", "idle"],
            happened: parts.length > 1
              ? `Dictionary: ${dict.length ? dict.join(", ") : "(empty)"}. Sentence: ${sentence.length ? sentence.join(", ") : "(empty)"}.`
              : `No '|' separator was given, so everything was read as the dictionary and the sentence is empty.`,
            why: "One trie holds the whole dictionary, so each sentence word is rewritten by a single short walk instead of a dictionary scan.",
            codeLine: 11,
          });

          dict.forEach((w, i) => {
            let node = root;
            for (const ch of w) {
              if (!node.kids[ch]) { node.kids[ch] = tn(); nodes++; }
              node = node.kids[ch];
            }
            node.end = true;
            built++;
            steps.push({
              title: `Add "${w}" to the dictionary trie`,
              showIdx: false,
              tracks: [
                dictTrack(dict.map((_, j) => (j < i ? "done" : j === i ? "read" : "idle"))),
                sentTrack(),
                { label: "trie path", cells: w.split("").map((c, j) => ({ v: c, state: "done", tag: w.slice(0, j + 1) })) },
              ],
              counters: [count("dictionary words added", built, dict.length), count("nodes created", nodes), count("sentence words done", 0, sentence.length)],
              legend: ["read", "done", "result", "idle"],
              happened: `"${w}" becomes a path of ${w.length} node${w.length === 1 ? "" : "s"}; letters shared with earlier words reuse their nodes.`,
              why: "Packing every root into one trie is what makes the lookup step later a single walk rather than a loop over the dictionary.",
              codeLine: 12,
            });
          });

          if (!dict.length) {
            steps.push({
              title: "Empty dictionary — every sentence word will stand as written",
              showIdx: false,
              tracks: [dictTrack(), sentTrack()],
              counters: [count("dictionary words", 0), count("roots found", 0), count("sentence words", 0, sentence.length)],
              legend: ["read", "done", "result", "idle"],
              happened: "There are no dictionary words on the left of '|', so the trie stays a bare root.",
              why: "With no roots to look for, the walk fails at the very first letter of every word — a safe, well-defined outcome.",
              codeLine: 26,
            });
          }

          sentence.forEach((w, si) => {
            let node = root, dead = -1, hit = -1;
            for (let k = 0; k < w.length; k++) {
              const ch = w[k];
              if (!node.kids[ch]) { dead = k; break; }
              node = node.kids[ch];
              if (node.end) { hit = k; break; }
            }
            const stop = dead >= 0 ? dead : hit >= 0 ? hit : w.length - 1;
            for (let k = 0; k <= stop; k++) {
              const ch = w[k];
              const missing = k === dead;
              const rooted = k === hit;
              const shown = w.slice(0, missing ? k : k + 1).split("");
              steps.push({
                title: missing
                  ? `Look up "${w}": no '${ch}' child — the dictionary has no matching root`
                  : rooted
                    ? `Look up "${w}": '${ch}' lands on a word end — root "${w.slice(0, k + 1)}" found`
                    : `Look up "${w}": follow '${ch}' — no complete root yet`,
                showIdx: false,
                tracks: [
                  dictTrack(dict.map((d) => (d[0] === w[0] ? "done" : "dim"))),
                  track("sentence", sentence, sentence.map((_, j) => (j < si ? "done" : j === si ? "read" : "idle"))),
                  {
                    label: "trie path",
                    cells: shown.length
                      ? shown.map((c, j) => ({ v: c, state: j === (missing ? shown.length - 1 : k) ? (missing ? "bad" : rooted ? "result" : "read") : "done", tag: shown.slice(0, j + 1).join("") }))
                      : [{ v: "root", state: "read" }],
                  },
                ],
                counters: [count("roots found", replaced, sentence.length), count("sentence words done", si, sentence.length), count("nodes created", nodes)],
                legend: ["read", "done", "bad", "result", "dim", "idle"],
                happened: missing
                  ? `The path breaks at '${ch}', so "${w}" shares no prefix with any dictionary word.`
                  : rooted
                    ? `The node for "${w.slice(0, k + 1)}" carries a word-end flag — and it appeared after only ${k + 1} letter${k + 1 === 1 ? "" : "s"}.`
                    : `A '${ch}' node exists below "${shown.slice(0, -1)}", but no dictionary word ends here yet.`,
                why: missing
                  ? "One missing letter is proof of absence: the walk can stop early instead of trying every dictionary entry."
                  : rooted
                    ? "Stopping at the FIRST flagged node is precisely what guarantees the SHORTEST root — a longer one would sit deeper on the same path."
                    : "Each letter keeps the walk inside the shared prefix structure — the sentence word never leaves the trie.",
                codeLine: missing ? 30 : rooted ? 34 : 28,
              });
            }

            const rooted = hit >= 0;
            const replacement = rooted ? w.slice(0, hit + 1) : w;
            if (rooted) replaced++;
            out.push(replacement);
            steps.push({
              title: rooted ? `Replace "${w}" with "${replacement}"` : `Keep "${w}" exactly as it is`,
              showIdx: false,
              tracks: [
                dictTrack(dict.map((d) => (d[0] === w[0] ? "done" : "dim"))),
                track("sentence", sentence, sentence.map((_, j) => (j < si ? "done" : j === si ? "read" : "idle"))),
                outTrack(out.length - 1),
              ],
              counters: [count("roots found", replaced, sentence.length), count("sentence words done", si + 1, sentence.length), count("nodes created", nodes)],
              legend: ["read", "done", "result", "dim", "idle"],
              happened: rooted
                ? `"${w}" is now written as its root "${replacement}" in the output line.`
                : `"${w}" has no dictionary root, so the output line keeps it unchanged.`,
              why: rooted
                ? "The replacement happens after the walk, never during it — the original word stays intact until a root is confirmed."
                : "Passing unknown words through untouched is part of the contract: only words with roots are rewritten.",
              codeLine: 36,
            });
          });

          steps.push({
            title: `Answer: ${out.length ? out.join(" ") : "(empty sentence)"}`,
            showIdx: false,
            tracks: [
              dictTrack(fill(dict.length, "dim")),
              out.length ? outTrack(-1) : { label: "replaced sentence", cells: [blankCell("nothing to write")] },
            ],
            counters: [count("roots found", replaced, sentence.length), count("sentence words", sentence.length), count("answer", out.join(" "))],
            legend: ["done", "result", "dim", "idle"],
            happened: `The rewritten sentence is: ${out.length ? out.join(" ") : "(nothing)"}. ${replaced} of ${sentence.length} word${sentence.length === 1 ? "" : "s"} found a root.`,
            why: "Every word was decided by one bounded walk — the whole sentence was rewritten without ever looping over the dictionary.",
            codeLine: 39,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     4. Map Sum Pairs
     ============================================================ */
  V.register({
    id: "map-sum-pairs",
    title: "Map Sum Pairs",
    category: "Tries",
    difficulty: "Intermediate",
    description: "Insert key/value pairs and sum every value whose key starts with a prefix.",
    input: { label: "Commands: insert key value / sum prefix", default: "insert abc 3 insert xyz 5 sum ab", parse: "tokens" },
    approaches: [
      {
        name: "Prefix Trie with Subtree Totals",
        complexity: "insert O(L); sum O(L + keys under the prefix)",
        idea: [
          "Keys go into a trie and each word-end node remembers its value. A prefix query walks its letters once and then adds up every flagged node hanging below where the walk stopped — everything under that node starts with the prefix by definition.",
          "On screen the trie is a PATH track (cell tags show the letter path so far) and the command script gets a highlighted track. The final sum is shown with a 'keys in the map' track where keys under the prefix glow green and the rest fade out.",
          "Token parsing: after 'insert' come two tokens (key and value); after 'sum' comes one (the prefix). Anything else is skipped with a friendly note, including an insert whose value is not a number.",
        ],
        problem: [
          "Collecting the sum still visits every key under the prefix, so a very short prefix over many keys is genuinely expensive. If queries were far more common than inserts, caching a total at every node (recomputed on insert) would trade memory for speed.",
        ],
        code: {
          c: `#include <stdio.h>

/* trie node holding the value stored at word ends (0 elsewhere) */
typedef struct Node {
    struct Node *kids[26];
    int val;
} Node;

static Node pool[4096];
static int used = 0;
static Node *new_node(void) { return &pool[used++]; }

void insert(Node *root, const char *k, int v) {
    Node *cur = root;
    for (; *k; k++) {
        int i = *k - 'a';
        if (!cur->kids[i])
            cur->kids[i] = new_node();
        cur = cur->kids[i];
    }
    cur->val = v;            /* re-inserting overwrites */
}

/* add up every key value hanging under this node */
int collect(Node *n) {
    if (!n) return 0;
    int s = n->val;
    for (int i = 0; i < 26; i++)
        s += collect(n->kids[i]);
    return s;
}

int sum_prefix(Node *root, const char *p) {
    Node *cur = root;
    for (; *p; p++) {
        int i = *p - 'a';
        if (!cur->kids[i])
            return 0;        /* nothing starts with this */
        cur = cur->kids[i];
    }
    return collect(cur);     /* whole subtree belongs to the prefix */
}

int main(void) {
    Node root = {{0}, 0};
    insert(&root, "abc", 3);
    insert(&root, "xyz", 5);
    printf("%d\\n", sum_prefix(&root, "ab")); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>

// trie node: word ends carry a value, middles stay 0
struct Node {
    Node* kids[26] = {};
    int val = 0;
};

class MapSum {
    Node root;
    Node* walk(const std::string& key) {
        Node* cur = &root;
        for (char c : key) {
            int i = c - 'a';
            if (!cur->kids[i]) cur->kids[i] = new Node(); // demo: no cleanup
            cur = cur->kids[i];
        }
        return cur;
    }
    int collect(Node* n) {                   // everything under a prefix
        if (!n) return 0;
        int s = n->val;
        for (Node* k : n->kids) s += collect(k);
        return s;
    }
public:
    void insert(const std::string& key, int val) { walk(key)->val = val; }
    int sum(const std::string& prefix) { return collect(walk(prefix)); }
};

int main() {
    MapSum m;
    m.insert("abc", 3);
    m.insert("xyz", 5);
    std::cout << m.sum("ab") << '\\n'; // 3
}`,
        },
        steps(tokens) {
          const root = tn();
          const ops = [];
          for (let i = 0; i < tokens.length; ) {
            const t = tokens[i].toLowerCase();
            if (t === "insert") {
              const key = tokens[i + 1], valRaw = tokens[i + 2];
              if (key == null) {
                ops.push({ op: "skip", note: "'insert' with nothing after it", from: i, to: i }); i += 1; continue;
              }
              if (valRaw == null) {
                ops.push({ op: "skip", note: `'insert ${key}' has no value`, from: i, to: i + 1 }); i += 2; continue;
              }
              const val = Number(valRaw);
              if (!Number.isFinite(val)) {
                ops.push({ op: "skip", note: `'${valRaw}' is not a number, insert ${key} skipped`, from: i, to: i + 2 }); i += 3; continue;
              }
              ops.push({ op: "insert", key, val, from: i, to: i + 2 }); i += 3;
            } else if (t === "sum") {
              const prefix = tokens[i + 1];
              if (prefix == null) {
                ops.push({ op: "skip", note: "'sum' with no prefix", from: i, to: i }); i += 1; continue;
              }
              ops.push({ op: "sum", prefix, from: i, to: i + 1 }); i += 2;
            } else {
              ops.push({ op: "skip", note: `'${tokens[i]}' is not an insert or sum command`, from: i, to: i }); i += 1;
            }
          }
          let nodes = 0, opDone = 0;
          const vals = new Map();
          const results = [];
          const steps = [];
          const cmdTrack = (op) =>
            track("commands", tokens, tokens.map((_, i) => (i < op.from ? "done" : i >= op.from && i <= op.to ? "read" : "idle")));
          const mapTrack = (hotKey) => ({
            label: "map contents",
            cells: vals.size
              ? [...vals].map(([k, v]) => ({ v: `${k} = ${v}`, state: k === hotKey ? "result" : "done", tag: k.length + " letters" }))
              : [blankCell("map is empty")],
          });
          const pathTrack = (shown, states) => ({
            label: "trie path (root → node)",
            cells: shown.length
              ? shown.map((c, j) => ({ v: c, state: states[j], tag: shown.slice(0, j + 1).join("") }))
              : [{ v: "root", state: "read", tag: "start here" }],
          });

          steps.push({
            title: "Set up: an empty map, an empty trie, the command script",
            showIdx: false,
            tracks: [
              track("commands", tokens, fill(tokens.length, "idle")),
              { label: "map contents", cells: [blankCell("map is empty")] },
            ],
            counters: [count("commands", 0, ops.length), count("keys stored", 0), count("nodes created", 0)],
            legend: ["read", "done", "result", "idle"],
            happened: `${ops.length} command${ops.length === 1 ? "" : "s"} to run; no key has been inserted yet.`,
            why: "The trie and the key/value map work as a pair: the trie finds prefixes, the map (via word-end nodes) remembers values.",
            codeLine: 9,
          });

          for (const op of ops) {
            const base = [count("commands", opDone, ops.length), count("keys stored", vals.size), count("nodes created", nodes)];

            if (op.op === "skip") {
              steps.push({
                title: `Skipped: ${op.note}`,
                showIdx: false,
                tracks: [cmdTrack(op), mapTrack(null)],
                counters: base,
                legend: ["read", "done", "idle"],
                happened: `The command did not have the shape 'insert key value' or 'sum prefix', so it was ignored with a note.`,
                why: "Validating arguments before touching the trie keeps the stored map exactly as consistent as the script promised.",
                codeLine: 11,
              });
              opDone++;
              continue;
            }

            if (op.op === "insert") {
              const existed = vals.has(op.key);
              const oldVal = vals.get(op.key);
              let node = root;
              const letters = op.key.split("");
              for (let k = 0; k < letters.length; k++) {
                const ch = letters[k];
                const had = !!node.kids[ch];
                if (!had) { node.kids[ch] = tn(); nodes++; }
                node = node.kids[ch];
                const shown = letters.slice(0, k + 1);
                const isLast = k === letters.length - 1;
                steps.push({
                  title: isLast
                    ? `insert ${op.key} ${op.val}: ${existed ? `overwrite ${oldVal} with ${op.val}` : `store value ${op.val} at the end node`}`
                    : `insert ${op.key} ${op.val}: ${had ? "follow existing node" : "create node"} '${ch}'`,
                  showIdx: false,
                  tracks: [
                    cmdTrack(op),
                    pathTrack(shown, shown.map((_, j) => (j === k ? (had ? "done" : "read") : "done"))),
                    mapTrack(null),
                  ],
                  counters: [count("commands", opDone, ops.length), count("keys stored", vals.size), count("nodes created", nodes)],
                  legend: ["read", "done", "result", "idle"],
                  happened: isLast
                    ? existed
                      ? `Key '${op.key}' already existed — its value changes from ${oldVal} to ${op.val}.`
                      : `The walk ends at node '${ch}', which now stores the value ${op.val}.`
                    : had
                      ? `A node for '${ch}' already existed, so the key shares that prefix.`
                      : `No '${ch}' node existed, so one is created for this key's path.`,
                  why: isLast
                    ? "Values live only at word-end nodes — that is what lets a prefix sum ignore every mid-word node."
                    : "One node per letter means 'abc' and 'abandon' share their first two nodes instead of duplicating them.",
                  codeLine: isLast ? 20 : had ? 14 : 16,
                });
              }
              vals.set(op.key, op.val);
              opDone++;
              continue;
            }

            /* sum prefix */
            const letters = op.prefix.split("");
            let node = root, dead = -1;
            for (let k = 0; k < letters.length; k++) {
              const ch = letters[k];
              if (!node.kids[ch]) { dead = k; break; }
              node = node.kids[ch];
            }
            const walkLast = dead >= 0 ? dead : letters.length - 1;
            for (let k = 0; k <= walkLast; k++) {
              const ch = letters[k];
              const missing = k === dead;
              const shown = letters.slice(0, missing ? k : k + 1);
              steps.push({
                title: missing
                  ? `sum ${op.prefix}: no '${ch}' child — no key can start with '${op.prefix.slice(0, k + 1)}'`
                  : `sum ${op.prefix}: follow '${ch}' — prefix so far '${shown.join("")}'`,
                showIdx: false,
                tracks: [
                  cmdTrack(op),
                  pathTrack(shown, shown.map((_, j) => (j === (missing ? shown.length - 1 : k) ? (missing ? "bad" : "read") : "done"))),
                  mapTrack(null),
                ],
                counters: [count("commands", opDone, ops.length), count("keys stored", vals.size), count("nodes created", nodes)],
                legend: ["read", "done", "bad", "result", "idle"],
                happened: missing
                  ? `The prefix path breaks at '${ch}', so no stored key begins with '${op.prefix}'.`
                  : `A '${ch}' node continues the path, so keys under it all begin with '${shown.join("")}'.`,
                why: missing
                  ? "A broken prefix path answers the query immediately with 0 — no map key needs to be examined."
                  : "The walk only costs one step per prefix letter, whatever the map holds.",
                codeLine: missing ? 37 : 35,
              });
            }

            if (dead >= 0) {
              results.push({ prefix: op.prefix, total: 0 });
              steps.push({
                title: `sum ${op.prefix} = 0 — nothing shares that prefix`,
                showIdx: false,
                tracks: [
                  cmdTrack(op),
                  pathTrack(letters.slice(0, dead), fill(dead, "bad")),
                  mapTrack(null),
                  { label: "answer", cells: [{ v: 0, state: "result", tag: "sum " + op.prefix }] },
                ],
                counters: [count("commands", opDone + 1, ops.length), count("keys stored", vals.size), count("answer", 0)],
                legend: ["read", "done", "bad", "result", "idle"],
                happened: "No key in the map begins with this prefix, so the total is zero.",
                why: "The trie proved absence without touching a single stored key — the failed walk was the whole search.",
                codeLine: 38,
              });
              opDone++;
              continue;
            }

            /* collect: DFS the subtree under the prefix node */
            const matches = [];
            let total = 0;
            const walkDown = (n, pref) => {
              if (vals.has(pref)) { matches.push({ k: pref, v: vals.get(pref) }); total += vals.get(pref); }
              const kids = Object.keys(n.kids).sort();
              for (const kk of kids) walkDown(n.kids[kk], pref + kk);
            };
            walkDown(node, op.prefix);
            results.push({ prefix: op.prefix, total });
            steps.push({
              title: `sum ${op.prefix} = ${total} — collect every key under "${op.prefix}"`,
              showIdx: false,
              tracks: [
                cmdTrack(op),
                {
                  label: "keys in the map",
                  cells: vals.size
                    ? [...vals].map(([k, v]) => ({
                        v: `${k} = ${v}`,
                        state: k.startsWith(op.prefix) ? "good" : "dim",
                        tag: k.startsWith(op.prefix) ? "counts" : "wrong prefix",
                      }))
                    : [blankCell("map is empty")],
                },
                {
                  label: "subtree total",
                  cells: [
                    { v: total, state: "result", tag: "sum(" + op.prefix + ")" },
                    ...(matches.length ? matches.map((m) => ({ v: `${m.k} → ${m.v}`, state: "good" })) : [{ v: "no keys under " + op.prefix, state: "bad" }]),
                  ],
                },
              ],
              counters: [count("commands", opDone + 1, ops.length), count("keys stored", vals.size), count("keys counted", matches.length), count("answer", total)],
              legend: ["read", "done", "good", "bad", "dim", "result", "idle"],
              happened: matches.length
                ? `Under "${op.prefix}" hang ${matches.map((m) => `${m.k}=${m.v}`).join(", ")} — together ${total}.`
                : `The node for "${op.prefix}" exists but no key ends below it, so the total is 0.`,
              why: "Everything hanging below the prefix node starts with the prefix by construction — collecting the subtree answers the query without scanning the map.",
              codeLine: 26,
            });
            opDone++;
          }

          steps.push({
            title: results.length ? `Answer: last sum = ${results[results.length - 1].total}` : "Answer: no sum command in this script",
            showIdx: false,
            tracks: [
              track("commands", tokens, fill(tokens.length, "done")),
              {
                label: "sum results in order",
                cells: results.length
                  ? results.map((r) => ({ v: `sum(${r.prefix}) = ${r.total}`, state: "result" }))
                  : [blankCell("no sums asked")],
              },
            ],
            counters: [count("commands", ops.length, ops.length), count("keys stored", vals.size), count("nodes created", nodes), count("answer", results.length ? results[results.length - 1].total : 0)],
            legend: ["done", "result", "good", "idle"],
            happened: results.length
              ? `The script finished with ${results.length} sum quer${results.length === 1 ? "y" : "ies"} over ${vals.size} stored key${vals.size === 1 ? "" : "s"}.`
              : "The script inserted keys but never asked for a sum.",
            why: "Inserts and queries share one structure: letters build the paths, and a single walk down them answers every prefix question.",
            codeLine: 42,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     5. Search Suggestions System
     ============================================================ */
  V.register({
    id: "search-suggestions-system",
    title: "Search Suggestions System",
    category: "Tries",
    difficulty: "Intermediate",
    description: "Fill three autocomplete slots as each character of a prefix is typed.",
    input: { label: "Words | prefix", default: "mobile mouse mask mona monty m | mo", parse: "string" },
    approaches: [
      {
        name: "Sorted List, First Three Matches",
        complexity: "sort once O(n log n); O(n) per typed character",
        idea: [
          "Sort the dictionary once. Because the list is ordered, the words starting with any prefix form one contiguous run inside it, and the three smallest suggestions are simply the first three members of that run — scan from the front and stop at three.",
          "On screen three tracks stay in view: the sorted word list (green = still matches the current prefix, faded = already ruled out), the prefix typed so far (one cell per character), and the three suggestion slots. Each typed character gets a filter step and a slots step.",
          "The input is 'words | prefix': everything left of the '|' is the dictionary, everything right is the typed prefix. The implementation sorts the words itself, so the input order does not matter.",
        ],
        problem: [
          "Scanning the whole list per character is fine for a demo list but grows linearly with dictionary size; a trie of the dictionary would descend only along the typed prefix and touch nothing else. Sorting also means suggestions are ready only after the initial O(n log n) pass.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>
#include <stdbool.h>

/* words arrive sorted; a prefix owns a contiguous slice of them */
bool starts_with(const char *w, const char *pre) {
    return strncmp(w, pre, strlen(pre)) == 0;
}

/* print up to 3 words beginning with the typed prefix */
void suggest(char words[][16], int n, const char *pre) {
    int shown = 0;
    for (int i = 0; i < n && shown < 3; i++) {
        if (starts_with(words[i], pre)) {
            printf("%s ", words[i]);
            shown++;
        }
    }
    printf("\\n");
}

int main(void) {
    char words[][16] = {"mask", "mobile", "mona", "monty", "mouse"};
    int n = (int)(sizeof words / sizeof words[0]);
    suggest(words, n, "mo");   /* mobile mouse */
    suggest(words, n, "m");    /* mask mobile mona */
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>

// after one sort, every prefix owns a contiguous slice — take its first 3
std::vector<std::string> suggest(std::vector<std::string>& words,
                                 const std::string& prefix) {
    auto it = std::lower_bound(words.begin(), words.end(), prefix);
    std::vector<std::string> out;
    for (; it != words.end() && out.size() < 3; ++it) {
        if (it->compare(0, prefix.size(), prefix) != 0) break; // left the slice
        out.push_back(*it);
    }
    return out;
}

int main() {
    std::vector<std::string> words{"mobile", "mouse", "mask", "mona", "monty"};
    std::sort(words.begin(), words.end());       // done once, up front
    for (const std::string& w : suggest(words, "mo"))
        std::cout << w << ' ';                   // mask? no: mobile mouse
    std::cout << '\\n';
    for (const std::string& w : suggest(words, "m"))
        std::cout << w << ' ';                   // mask mobile mona
    std::cout << '\\n';
}`,
        },
        steps(raw) {
          const parts = String(raw).split("|");
          const words = splitWords(parts[0]);
          const typed = splitWords(parts.slice(1).join(" ")).join("");
          const sorted = words.slice().sort();
          const steps = [];
          let slots = ["", "", ""];
          const slotsTrack = () => ({
            label: "suggestion slots",
            cells: slots.map((s, i) => (s ? { v: s, state: "result", tag: "slot " + (i + 1) } : blankCell("slot " + (i + 1)))),
          });
          const prefixTrack = (upto) =>
            track("prefix typed", typed.split(""), typed.split("").map((_, i) => (i < upto ? "done" : i === upto ? "read" : "idle")));
          const listTrack = (upto, mode) => {
            const prefix = typed.slice(0, upto);
            return track("dictionary (sorted)", sorted, sorted.map((w) => {
              if (mode === "setup") return "idle";
              if (mode === "typing") return w.startsWith(prefix) ? "read" : "idle";
              return w.startsWith(prefix) ? "good" : "dim";
            }));
          };
          const matchesOf = (prefix) => sorted.filter((w) => w.startsWith(prefix));
          const showTyped = Math.min(typed.length, 10); /* two steps per char for the first 10 */

          steps.push({
            title: "Set up: the word list and an empty prefix",
            showIdx: false,
            tracks: [listTrack(0, "setup"), prefixTrack(-1), slotsTrack()],
            counters: [count("words", sorted.length), count("characters typed", 0, typed.length), count("slots filled", 0, 3)],
            legend: ["read", "done", "good", "dim", "result", "idle"],
            happened: parts.length > 1
              ? `Dictionary: ${sorted.length ? sorted.join(", ") : "(empty)"}. The user is about to type "${typed}".`
              : `No '|' separator, so the whole input was read as the dictionary and the prefix is empty.`,
            why: "Autocomplete only has meaning once the possible answers are ordered — that ordering is what makes 'first three' a stable choice.",
            codeLine: 17,
          });

          steps.push({
            title: "Sort the dictionary once, up front",
            showIdx: false,
            tracks: [
              track("dictionary (sorted)", sorted, fill(sorted.length, "done")),
              prefixTrack(-1),
              slotsTrack(),
            ],
            counters: [count("words", sorted.length), count("characters typed", 0, typed.length), count("slots filled", 0, 3)],
            legend: ["read", "done", "good", "dim", "result"],
            happened: `Sorted order: ${sorted.length ? sorted.join(", ") : "(nothing)"} — every prefix's candidates now sit together.`,
            why: "After one sort, the words sharing a prefix are contiguous, so the three smallest suggestions are just the first three of that run.",
            codeLine: 6,
          });

          if (!typed.length) {
            steps.push({
              title: "No characters typed — nothing to suggest yet",
              showIdx: false,
              tracks: [listTrack(0, "setup"), prefixTrack(-1), slotsTrack()],
              counters: [count("words", sorted.length), count("characters typed", 0, 0), count("slots filled", 0, 3)],
              legend: ["read", "done", "good", "dim", "result", "idle"],
              happened: "The prefix is empty, so there is nothing to filter the dictionary with.",
              why: "Suggestion systems wait for at least one character — an empty prefix would match every word in the dictionary.",
              codeLine: 9,
            });
          }

          for (let i = 0; i < typed.length; i++) {
            const prefix = typed.slice(0, i + 1);
            const matches = matchesOf(prefix);
            const twoSteps = i < showTyped;

            if (twoSteps) {
              steps.push({
                title: `Type '${typed[i]}' → prefix "${prefix}": keep only the words that still match`,
                showIdx: false,
                tracks: [listTrack(i, "typing"), prefixTrack(i), slotsTrack()],
                counters: [count("words", sorted.length), count("characters typed", i + 1, typed.length), count("still matching", matches.length), count("slots filled", 0, 3)],
                legend: ["read", "done", "good", "dim", "result", "idle"],
                happened: `With "${prefix}" typed, ${matches.length} word${matches.length === 1 ? "" : "s"} in the list still begin with it${matches.length && matches.length <= 5 ? `: ${matches.join(", ")}` : ""}.`,
                why: "Each new character narrows the candidate run — words eliminated here can never come back for a longer prefix.",
                codeLine: 12,
              });
              slots = matches.slice(0, 3);
              steps.push({
                title: slots.length
                  ? `Slots filled: ${slots.join(", ")}`
                  : `Slots stay empty — no word starts with "${prefix}"`,
                showIdx: false,
                tracks: [listTrack(i, "filter"), prefixTrack(i), slotsTrack()],
                counters: [count("words", sorted.length), count("characters typed", i + 1, typed.length), count("slots filled", slots.length, 3)],
                legend: ["read", "done", "good", "dim", "result", "idle"],
                happened: slots.length
                  ? `Taking the first ${slots.length} match${slots.length === 1 ? "" : "es"} in sorted order fills ${slots.length} of 3 slots.`
                  : `Nothing in the dictionary begins with "${prefix}", so all three slots stay empty.`,
                why: "Reading matches left to right in sorted order IS the 'three smallest words' rule — no extra comparison needed.",
                codeLine: 13,
              });
            } else {
              slots = matches.slice(0, 3);
              steps.push({
                title: `Type '${typed[i]}' → prefix "${prefix}": slots now hold ${slots.length ? slots.join(", ") : "nothing"}`,
                showIdx: false,
                tracks: [listTrack(i, "filter"), prefixTrack(i), slotsTrack()],
                counters: [count("words", sorted.length), count("characters typed", i + 1, typed.length), count("still matching", matches.length), count("slots filled", slots.length, 3)],
                legend: ["read", "done", "good", "dim", "result", "idle"],
                happened: `The prefix is long now, so filtering and refilling share one step: ${matches.length} match${matches.length === 1 ? "" : "es"}, slots hold ${slots.length ? slots.join(", ") : "nothing"}.`,
                why: "Longer prefixes only shrink the matching run — the top three can change but never grow beyond three.",
                codeLine: 12,
              });
            }
          }

          const finalMatches = matchesOf(typed);
          slots = finalMatches.slice(0, 3);
          steps.push({
            title: typed.length
              ? `Answer for "${typed}": ${slots.length ? slots.join(", ") : "(no matches)"}`
              : "Answer: prefix is empty, no suggestions",
            showIdx: false,
            tracks: [
              listTrack(typed.length, "filter"),
              prefixTrack(typed.length),
              slotsTrack(),
            ],
            counters: [count("words", sorted.length), count("characters typed", typed.length, typed.length), count("slots filled", slots.length, 3), count("answer", slots.length)],
            legend: ["done", "good", "dim", "result", "idle"],
            happened: typed.length
              ? `After typing "${typed}", the three slots hold ${slots.length ? slots.join(", ") : "nothing"} — the first three matches of ${finalMatches.length} total.`
              : "With no typed characters there is nothing to suggest.",
            why: "Every character only ever trimmed the candidate run: the final answer is simply the first three survivors of a sorted list.",
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     6. Word Search II
     ============================================================ */
  V.register({
    id: "word-search-ii",
    title: "Word Search II",
    category: "Tries",
    difficulty: "Advanced",
    description: "Find every listed word on a board by walking the grid guided by a trie.",
    input: { label: "Grid rows | words", default: "oath pea xxxx | oath eat", parse: "string" },
    approaches: [
      {
        name: "Grid DFS Pruned by a Trie",
        complexity: "O(R·C·4^L) worst, trie pruning cuts it sharply in practice",
        idea: [
          "Every word goes into a trie first. Then each board cell can start a depth-first walk: move up/down/left/right without reusing a cell, following the trie instead of a word list. The moment the current path is not a prefix of any listed word, the walk dies instantly.",
          "On screen the board is a grid stage: the current cell is green, cells on the current path are 'handled', and cells already fully explored as starting points fade out. The final step switches to a cells stage listing the words found and the words missing.",
          "The input is 'rows | words': everything left of the '|' gives the board rows (row lengths may differ — short rows are padded and faded), everything right lists the words to find.",
        ],
        problem: [
          "Without the trie this is 4-directional exploration from every cell against every word — hopeless on a large board. The trie turns each wrong letter into an instant rejection, but the worst case (a board dense with one letter and a long word) still explores an exponential number of paths, so the animation caps how many walk steps it will show.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>
#include <string.h>

typedef struct Node {
    struct Node *kids[26];
    bool end;
    const char *word;        /* which word finishes here */
} Node;

static Node pool[8192];
static int used = 0;
static Node *new_node(void) { return &pool[used++]; }

void insert(Node *root, const char *w) {
    Node *cur = root;
    for (const char *p = w; *p; p++) {
        int i = *p - 'a';
        if (!cur->kids[i])
            cur->kids[i] = new_node();
        cur = cur->kids[i];
    }
    cur->end = true;
    cur->word = w;
}

static char board[8][9], vis[8][8];
static int R, C;

/* one call per start cell; the trie prunes every wrong turn */
void dfs(Node *node, int r, int c, char **out, int *n) {
    if (r < 0 || r >= R || c < 0 || c >= C || vis[r][c]) return;
    node = node->kids[board[r][c] - 'a'];
    if (!node) return;        /* prefix impossible — stop */
    if (node->end) {
        out[(*n)++] = (char *)node->word;
        node->end = false;    /* report each word only once */
    }
    vis[r][c] = 1;
    dfs(node, r + 1, c, out, n);
    dfs(node, r - 1, c, out, n);
    dfs(node, r, c + 1, out, n);
    dfs(node, r, c - 1, out, n);
    vis[r][c] = 0;            /* free the cell for other paths */
}

int main(void) {
    char *rows[] = {"oath", "peax"};
    R = 2; C = 4;
    for (int r = 0; r < R; r++) strcpy(board[r], rows[r]);
    Node root = {{0}, false, NULL};
    insert(&root, "oath");
    insert(&root, "eat");
    char *found[16];
    int nf = 0;
    for (int r = 0; r < R; r++)
        for (int c = 0; c < C; c++)
            dfs(&root, r, c, found, &nf);
    for (int i = 0; i < nf; i++) printf("%s\\n", found[i]);
    return 0;
}`,
          cpp: `#include <iostream>
#include <string>
#include <vector>
#include <set>

// trie-guided DFS: the path must always be a prefix of some word
struct Node {
    Node* kids[26] = {};
    bool end = false;
    std::string word;
};

void dfs(std::vector<std::string>& board, std::vector<std::vector<bool>>& used,
         Node* node, int r, int c, std::set<std::string>& found) {
    if (r < 0 || r >= (int)board.size() || c < 0 ||
        c >= (int)board[0].size() || used[r][c]) return;
    node = node->kids[board[r][c] - 'a'];
    if (!node) return;                        // impossible prefix
    if (node->end) {
        found.insert(node->word);
        node->end = false;                    // each word once
    }
    used[r][c] = true;
    dfs(board, used, node, r + 1, c, found);
    dfs(board, used, node, r - 1, c, found);
    dfs(board, used, node, r, c + 1, found);
    dfs(board, used, node, r, c - 1, found);
    used[r][c] = false;
}

std::set<std::string> findWords(std::vector<std::string>& board,
                                std::vector<std::string>& words) {
    Node root;
    for (const std::string& w : words) {
        Node* cur = &root;
        for (char c : w) {
            int i = c - 'a';
            if (!cur->kids[i]) cur->kids[i] = new Node(); // demo: no cleanup
            cur = cur->kids[i];
        }
        cur->end = true;
        cur->word = w;
    }
    std::set<std::string> found;
    std::vector<std::vector<bool>> used(board.size(),
        std::vector<bool>(board[0].size(), false));
    for (int r = 0; r < (int)board.size(); ++r)
        for (int c = 0; c < (int)board[0].size(); ++c)
            dfs(board, used, &root, r, c, found);
    return found;
}`,
        },
        steps(raw) {
          const parts = String(raw).split("|");
          const rowStrs = splitWords(parts[0]);
          const words = splitWords(parts.slice(1).join(" "));
          const rows = rowStrs.length;
          const cols = rowStrs.reduce((m, r) => Math.max(m, r.length), 0);
          const board = rowStrs.map((r) => r + " ".repeat(Math.max(0, cols - r.length)));
          const inBoard = (r, c) => r >= 0 && r < rows && c >= 0 && c < cols && c < rowStrs[r].length;
          const letter = (r, c) => (inBoard(r, c) ? board[r][c] : "");
          const steps = [];
          const found = [];
          const foundSet = new Set();
          const startsDone = new Set();
          let budget = 90;
          let overBudget = false;

          const gcells = (r, c, path) =>
            grid(rows, cols, (rr, cc) => {
              const key = rr + "," + cc;
              if (!inBoard(rr, cc)) return { v: "", state: "dim" };
              if (rr === r && cc === c) return { v: letter(rr, cc), state: "read" };
              if (path.has(key)) return { v: letter(rr, cc), state: "done" };
              if (startsDone.has(key)) return { v: letter(rr, cc), state: "dim" };
              return { v: letter(rr, cc), state: "idle" };
            });
          const gstep = (r, c, path, title, counters, why, line) => {
            if (budget <= 0) { overBudget = true; return null; }
            budget--;
            const step = {
              kind: "grid",
              rows, cols,
              cells: gcells(r, c, path),
              title,
              counters,
              legend: ["read", "done", "good", "dim", "idle"],
              happened: title,
              why,
              codeLine: line,
            };
            steps.push(step);
            return step;
          };
          const pathString = (path) =>
            [...path].map((k) => letter(+k.split(",")[0], +k.split(",")[1])).join("-");

          steps.push({
            kind: "grid",
            rows, cols,
            cells: gcells(-1, -1, new Set()),
            title: "Set up: the board and the word list",
            label: words.length ? `words to find: ${words.join(", ")}` : "no words to find",
            counters: [count("board cells", rows * cols), count("words to find", words.length), count("found", 0, words.length)],
            legend: ["read", "done", "good", "dim", "idle"],
            happened: rows
              ? `A ${rows}×${cols} board with ${rows * cols} letter cells${cols ? "" : ""}; the words to hunt are ${words.length ? words.join(", ") : "(none)"}.`
              : `No board rows were given; the words to hunt are ${words.length ? words.join(", ") : "(none)"}.`,
            why: "Collecting all words in one trie before touching the board is what lets a single walk answer 'does any word still need this letter?'.",
            codeLine: 19,
          });

          /* build the trie */
          const root = tn();
          const firstLetters = new Set();
          for (const w of words) {
            let node = root;
            for (const ch of w) {
              if (!node.kids[ch]) node.kids[ch] = tn();
              node = node.kids[ch];
            }
            node.end = true;
            node.word = w;
          }
          Object.keys(root.kids).forEach((k) => firstLetters.add(k));

          steps.push({
            title: "Build the trie: only paths spelling a listed word exist",
            showIdx: false,
            tracks: [
              track("words to find", words, fill(words.length, "done")),
              {
                label: "first letters worth starting from",
                cells: firstLetters.size
                  ? [...firstLetters].sort().map((l) => ({ v: l, state: "read", tag: "root child" }))
                  : [blankCell("no words")],
              },
            ],
            counters: [count("words to find", words.length), count("first letters", firstLetters.size), count("found", 0, words.length)],
            legend: ["read", "done", "good", "dim", "idle"],
            happened: firstLetters.size
              ? `The trie only branches on ${[...firstLetters].sort().join(", ")} at the root, so cells with other letters can never start a match.`
              : "With no words to find, the trie stays an empty root and the walk never begins.",
            why: "Pruning whole starting cells before any walking is free: a cell whose letter is nobody's first letter cannot begin a word.",
            codeLine: 33,
          });

          if (words.length && rows && cols) {
            const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
            const dfs = (r, c, node, path) => {
              const child = node.kids[letter(r, c)];
              if (!child) return;
              const cur = new Set(path);
              cur.add(r + "," + c);
              if (child.end && !foundSet.has(child.word)) {
                foundSet.add(child.word);
                found.push(child.word);
                gstep(r, c, cur,
                  `✓ found "${child.word}" — the path ${pathString(cur)} spells it end to end`,
                  [count("words to find", words.length), count("found", found.length, words.length), count("walk budget left", budget)],
                  "Reaching a word-end node on the board completes a listed word — the trie flagged it the moment the last letter landed.",
                  37);
                if (overBudget) return;
              }
              for (const [dr, dc] of dirs) {
                if (overBudget) return;
                const nr = r + dr, nc = c + dc;
                if (!inBoard(nr, nc)) continue;
                if (cur.has(nr + "," + nc)) continue;
                if (!child.kids[letter(nr, nc)]) continue;
                const nextPath = new Set([...cur, nr + "," + nc]);
                const step = gstep(nr, nc, cur,
                  `Step to (${nr},${nc}) '${letter(nr, nc)}' — prefix "${pathString(nextPath)}" is still a real prefix`,
                  [count("words to find", words.length), count("found", found.length, words.length), count("walk budget left", budget)],
                  "Only cells that continue a listed word's prefix are entered; every other neighbour is skipped without a step.",
                  39);
                if (!step) return;
                dfs(nr, nc, child, cur);
                if (overBudget) return;
              }
            };

            for (let r = 0; r < rows && !overBudget; r++) {
              for (let c = 0; c < cols && !overBudget; c++) {
                if (!inBoard(r, c)) continue;
                if (!root.kids[letter(r, c)]) continue;
                const before = steps.length;
                const step = gstep(r, c, new Set(),
                  `Start from (${r},${c}) '${letter(r, c)}' — a first letter of a listed word`,
                  [count("words to find", words.length), count("found", found.length, words.length), count("walk budget left", budget)],
                  "Every live starting cell gets its own exploration; the trie guarantees the very first letter already matters.",
                  38);
                if (!step) break;
                dfs(r, c, root, new Set());
                startsDone.add(r + "," + c);
                if (steps.length > before + 1 && !overBudget) {
                  gstep(r, c, new Set([r + "," + c]),
                    `Branch from (${r},${c}) is fully explored — no more matches are reachable from it`,
                    [count("words to find", words.length), count("found", found.length, words.length), count("walk budget left", budget)],
                    "Once a start cell has been exhausted, it fades out: every path beginning there has already succeeded or died.",
                    44);
                }
              }
            }
          }

          if (overBudget) {
            steps.push({
              kind: "grid",
              rows, cols,
              cells: gcells(-1, -1, new Set()),
              title: "Walk budget reached — showing results gathered so far",
              label: found.length ? `found so far: ${found.join(", ")}` : "nothing found before the budget ran out",
              counters: [count("words to find", words.length), count("found", found.length, words.length), count("walk budget left", budget)],
              legend: ["read", "done", "good", "dim", "idle"],
              happened: "The board kept producing readable walk steps until the animation's step budget ran out, so exploring stops here.",
              why: "This is the honest worst case of grid search: dense boards can fan out for a very long time. The trie kept it to letter-legal moves the whole way.",
              codeLine: 39,
            });
          }

          const missing = words.filter((w) => !foundSet.has(w));
          steps.push({
            title: words.length
              ? found.length
                ? `Answer: found ${found.length} of ${words.length} — ${found.join(", ")}`
                : "Answer: none of the words are on the board"
              : "Answer: no words were requested",
            showIdx: false,
            tracks: [
              {
                label: "words found",
                cells: found.length ? found.map((w) => ({ v: w, state: "good", tag: "on the board" })) : [blankCell("none found")],
              },
              ...(missing.length ? [track("not found", missing, fill(missing.length, "bad"))] : []),
            ],
            counters: [count("words to find", words.length), count("found", found.length, words.length), count("answer", found.length)],
            legend: ["good", "bad", "read", "done", "result", "idle"],
            happened: found.length
              ? `Collected in discovery order: ${found.join(", ")}${missing.length ? `; still missing: ${missing.join(", ")}` : ", and nothing was missed"}.`
              : `No walk ever reached a word-end node${missing.length ? ` — ${missing.join(", ")} never appeared` : ""}.`,
            why: "The trie made every wrong letter free: the search only ever walked paths that could still complete a listed word.",
            codeLine: 37,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     7. Last Stone Weight
     ============================================================ */
  V.register({
    id: "last-stone-weight",
    title: "Last Stone Weight",
    category: "Heaps",
    difficulty: "Beginner",
    description: "Repeatedly smash the two heaviest stones until at most one is left.",
    input: { label: "Stone weights", default: "2, 7, 4, 1, 8, 1", parse: "ints" },
    approaches: [
      {
        name: "Max-Heap Smash Loop",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "A max-heap always hands you the largest stone at the front. Smashing means popping the two largest, computing the difference, and pushing the remainder back — repeat until one stone (or none) remains.",
          "On screen the heap is one cells track sorted so the heaviest stone sits at the left. The two stones being smashed light up as 'comparing', then the track redraws with the remainder slipped into its sorted position (tagged so you can follow it).",
          "If the two heaviest weigh the same they both vanish and nothing is pushed — that is why the answer can be 0.",
        ],
        problem: [
          "Keeping a fully sorted array instead of a heap would also work and is simpler to code, but every insert would cost O(n); the heap keeps both the pop and the push at O(log n), which is what the loop does n times.",
        ],
        code: {
          c: `#include <stdio.h>

static int h[100], n; /* max-heap: every parent >= its children */

void push(int v) {
    int i = n++;
    h[i] = v;
    while (i > 0) {
        int p = (i - 1) / 2;
        if (h[p] >= h[i]) break;
        int t = h[p]; h[p] = h[i]; h[i] = t;
        i = p;
    }
}

int pop(void) {
    int top = h[0];
    h[0] = h[--n];
    int i = 0;
    for (;;) {
        int l = 2 * i + 1, r = l + 1, m = i;
        if (l < n && h[l] > h[m]) m = l;
        if (r < n && h[r] > h[m]) m = r;
        if (m == i) break;
        int t = h[m]; h[m] = h[i]; h[i] = t;
        i = m;
    }
    return top;
}

int main(void) {
    int a[] = {2, 7, 4, 1, 8, 1};
    for (int i = 0; i < 6; i++) push(a[i]);
    while (n > 1) {
        int x = pop(), y = pop();
        if (x > y) push(x - y);   /* equal stones both vanish */
    }
    printf("%d\\n", n ? h[0] : 0); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <queue>
#include <vector>

// pop the two heaviest, push the difference, until one stone is left
int lastStoneWeight(const std::vector<int>& stones) {
    std::priority_queue<int> pq(stones.begin(), stones.end());
    while (pq.size() > 1) {
        int a = pq.top(); pq.pop();   // heaviest
        int b = pq.top(); pq.pop();   // second heaviest
        if (a > b) pq.push(a - b);    // equal pair leaves nothing
    }
    return pq.empty() ? 0 : pq.top();
}

int main() {
    std::cout << lastStoneWeight({2, 7, 4, 1, 8, 1}) << '\\n'; // 1
    std::cout << lastStoneWeight({7, 7}) << '\\n';             // 0
}`,
        },
        steps(nums) {
          const stones = nums.slice().sort((a, b) => b - a);
          const steps = [];
          let smashes = 0;
          const heapTrack = (states, tags) => ({
            label: "heap — heaviest at the left",
            cells: stones.length
              ? stones.map((v, i) => ({ v, state: states[i], tag: tags && tags[i] }))
              : [blankCell("no stones left")],
          });
          const idleStates = () => fill(stones.length, "idle");
          const total = stones.length;

          steps.push({
            title: `Set up: ${total} stone${total === 1 ? "" : "s"}, sorted heaviest first`,
            showIdx: false,
            tracks: [heapTrack(idleStates())],
            counters: [count("stones left", stones.length, total), count("smashes", 0), count("heaviest", stones[0])],
            legend: ["compare", "result", "read", "done", "idle"],
            happened: `The pile is ${stones.join(", ")} — a max-heap would present exactly this order, heaviest first.`,
            why: "Each round needs the two biggest stones, so keeping them at the front is the only ordering the loop ever cares about.",
            codeLine: 3,
          });

          let round = 0;
          while (stones.length > 1) {
            const a = stones[0], b = stones[1];
            steps.push({
              title: `Smash the two heaviest: ${a} vs ${b}`,
              showIdx: false,
              tracks: [heapTrack(stones.map((_, i) => (i < 2 ? "compare" : "done")))],
              counters: [count("stones left", stones.length, total), count("smashes", smashes), count("round", round + 1)],
              legend: ["compare", "result", "done", "idle"],
              happened: `The heap hands over its two largest values, ${a} and ${b}; everything smaller waits at the right.`,
              why: "Popping from the front of a max-heap is O(log n) and guarantees these really are the two heaviest — no rescanning the pile.",
              codeLine: 34,
            });
            stones.shift();
            stones.shift();
            const diff = a - b;
            smashes++;
            round++;
            if (diff > 0) {
              let idx = stones.findIndex((v) => v < diff);
              if (idx === -1) idx = stones.length;
              stones.splice(idx, 0, diff);
              const states = stones.map((_, i) => (i === idx ? "result" : "done"));
              const tags = stones.map((_, i) => (i === idx ? `${a} − ${b}` : undefined));
              steps.push({
                title: `${a} − ${b} = ${diff} → push ${diff} back onto the heap`,
                showIdx: false,
                tracks: [heapTrack(states, tags)],
                counters: [count("stones left", stones.length, total), count("smashes", smashes), count("heaviest", stones[0])],
                legend: ["compare", "result", "done", "idle"],
                happened: `The difference ${diff} slides into its sorted spot; the pile is now ${stones.join(", ")}.`,
                why: "The remainder is a normal stone again — re-inserting it keeps the heap shape so the next round can pop the true heaviest.",
                codeLine: 35,
              });
            } else {
              steps.push({
                title: `${a} and ${b} were equal → both destroyed, nothing returns`,
                showIdx: false,
                tracks: [heapTrack(fill(stones.length, "done"))],
                counters: [count("stones left", stones.length, total), count("smashes", smashes), count("heaviest", stones.length ? stones[0] : 0)],
                legend: ["compare", "result", "done", "idle"],
                happened: `A zero difference means no remainder — the heap shrinks to ${stones.length ? stones.join(", ") : "nothing"}.`,
                why: "Equal stones annihilate completely; the loop must handle an empty pile, since the final answer in that case is 0.",
                codeLine: 35,
              });
            }
          }

          const answer = stones.length ? stones[0] : 0;
          steps.push({
            title: `Answer: ${answer}`,
            showIdx: false,
            tracks: [stones.length ? heapTrack(fill(stones.length, "result"), stones.map(() => "last one standing")) : { label: "heap — heaviest at the left", cells: [blankCell("empty pile → 0")] }],
            counters: [count("stones left", stones.length, total), count("smashes", smashes), count("answer", answer)],
            legend: ["result", "read", "done", "idle"],
            happened: stones.length
              ? `Only ${stones[0]} remains after ${smashes} smash${smashes === 1 ? "" : "es"} — it is the survivor.`
              : `Every stone was destroyed in ${smashes} smash${smashes === 1 ? "" : "es"} — an empty pile means the answer is 0.`,
            why: "The loop only ever removed two and added at most one, so it strictly shrinks the pile and must stop — this is the single value left.",
            codeLine: 38,
          });
          return steps;
        },
      },
    ],
  });

  /* ============================================================
     8. Find Median from Data Stream
     ============================================================ */
  V.register({
    id: "find-median-from-data-stream",
    title: "Find Median from Data Stream",
    category: "Heaps",
    difficulty: "Intermediate",
    description: "Keep the median current with two heaps as numbers arrive one by one.",
    input: { label: "Commands: add X / median", default: "add 5 add 2 median add 3 median", parse: "tokens" },
    approaches: [
      {
        name: "Balanced Max-Heap and Min-Heap",
        complexity: "add O(log n); median O(1); O(n) space",
        idea: [
          "Split the stream in half: a max-heap holds everything at or below the middle, a min-heap holds the rest. The heaps are kept within one element of each other, so every number sits on the correct side of the divide.",
          "The median is then almost free — with equal sizes it is the average of the two heap tops; with one extra element it is simply the top of the bigger heap. After every add the halves are rebalanced by moving one root across.",
          "On screen each heap is a cells track shown SORTED, not in internal heap order: the lower half reads heaviest-first (its max-heap root is the leftmost cell) and the upper half lightest-first (its min-heap root is also the leftmost cell). The idea is what matters — the leftmost cell of each track is always that heap's top.",
          "Token parsing: 'add X' takes the next token as the number, 'median' takes none, unknown tokens are skipped with a friendly note.",
        ],
        problem: [
          "Two heaps are the right tool when medians must be answered online. If the whole stream were available up front, sorting once and indexing the middle would be simpler — the heap pair only earns its keep because numbers keep arriving.",
        ],
        code: {
          c: `#include <stdio.h>

/* lower half as a max-heap lo[], upper half as a min-heap hi[] */
int lo[200], hi[200], nl = 0, nh = 0;

void lo_up(int i) { int p = (i - 1) / 2; while (i && lo[p] < lo[i]) {
    int t = lo[p]; lo[p] = lo[i]; lo[i] = t; i = p; p = (i - 1) / 2; } }
void lo_dn(int i) { for (;;) { int l = 2*i+1, r = l+1, m = i;
    if (l < nl && lo[l] > lo[m]) m = l;
    if (r < nl && lo[r] > lo[m]) m = r;
    if (m == i) break;
    int t = lo[m]; lo[m] = lo[i]; lo[i] = t; i = m; } }
void hi_up(int i) { int p = (i - 1) / 2; while (i && hi[p] > hi[i]) {
    int t = hi[p]; hi[p] = hi[i]; hi[i] = t; i = p; p = (i - 1) / 2; } }
void hi_dn(int i) { for (;;) { int l = 2*i+1, r = l+1, m = i;
    if (l < nh && hi[l] < hi[m]) m = l;
    if (r < nh && hi[r] < hi[m]) m = r;
    if (m == i) break;
    int t = hi[m]; hi[m] = hi[i]; hi[i] = t; i = m; } }

void add(int x) {
    if (!nl || x <= lo[0]) { lo[nl++] = x; lo_up(nl - 1); }
    else                   { hi[nh++] = x; hi_up(nh - 1); }
    if (nl > nh + 1) {          /* rebalance: differ by at most 1 */
        hi[nh++] = lo[0];
        lo[0] = lo[--nl]; if (nl) lo_dn(0);
    } else if (nh > nl + 1) {
        lo[nl++] = hi[0];
        hi[0] = hi[--nh]; if (nh) hi_dn(0);
    }
}

double median(void) {
    if (!nl && !nh) return 0;
    if (nl == nh) return (lo[0] + hi[0]) / 2.0;
    return nl > nh ? lo[0] : hi[0];
}

int main(void) {
    int a[] = {5, 2, 3};
    for (int i = 0; i < 3; i++) add(a[i]);
    printf("%.1f\\n", median()); /* 3.0 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <queue>
#include <vector>
#include <functional>

// lower half (max on top) and upper half (min on top), kept within one
std::priority_queue<int> lower;                                  // max-heap
std::priority_queue<int, std::vector<int>, std::greater<int>> upper; // min-heap

void add(int x) {
    if (lower.empty() || x <= lower.top()) lower.push(x);
    else                                   upper.push(x);
    // rebalance: the halves may differ in size by at most one
    if ((int)lower.size() > (int)upper.size() + 1) {
        upper.push(lower.top()); lower.pop();
    } else if ((int)upper.size() > (int)lower.size() + 1) {
        lower.push(upper.top()); upper.pop();
    }
}

double median() {
    if (lower.empty() && upper.empty()) return 0;
    if (lower.size() == upper.size())
        return (lower.top() + upper.top()) / 2.0;  // average of the tops
    return lower.size() > upper.size() ? lower.top() : upper.top();
}

int main() {
    for (int x : {5, 2, 3}) add(x);
    std::cout << median() << '\\n'; // 3
}`,
        },
        steps(tokens) {
          const cmds = [];
          for (let i = 0; i < tokens.length; ) {
            const t = tokens[i].toLowerCase();
            if (t === "add") {
              const rawV = tokens[i + 1];
              const x = Number(rawV);
              if (rawV == null) {
                cmds.push({ op: "skip", note: "'add' with no number after it", from: i, to: i }); i += 1; continue;
              }
              if (!Number.isFinite(x)) {
                cmds.push({ op: "skip", note: `'${rawV}' is not a number, add skipped`, from: i, to: i + 1 }); i += 2; continue;
              }
              cmds.push({ op: "add", x, from: i, to: i + 1 }); i += 2;
            } else if (t === "median") {
              cmds.push({ op: "median", from: i, to: i }); i += 1;
            } else {
              cmds.push({ op: "skip", note: `'${tokens[i]}' is not an add or median command`, from: i, to: i }); i += 1;
            }
          }
          const lower = []; /* max-heap, displayed sorted: largest first */
          const upper = []; /* min-heap, displayed sorted: smallest first */
          const stream = [];
          const medians = [];
          let medianAsked = 0;
          let cmdDone = 0;
          const steps = [];
          const cmdTrack = (op) =>
            track("commands", tokens, tokens.map((_, i) => (i < op.from ? "done" : i >= op.from && i <= op.to ? "read" : "idle")));
          const lowerTrack = (states) => ({
            label: "max-heap (lower half) — sorted for display, root at left",
            cells: lower.length ? lower.map((v, i) => ({ v, state: states ? states[i] : "done", tag: i === 0 ? "root" : undefined })) : [blankCell("empty")],
          });
          const upperTrack = (states) => ({
            label: "min-heap (upper half) — sorted for display, root at left",
            cells: upper.length ? upper.map((v, i) => ({ v, state: states ? states[i] : "done", tag: i === 0 ? "root" : undefined })) : [blankCell("empty")],
          });
          const streamTrack = (hotIdx) =>
            track("stream so far", stream, stream.map((_, i) => (i === hotIdx ? "read" : "done")));
          const medianCell = (val, tag) => ({ label: "median", cells: [{ v: val, state: "result", tag }] });
          const currentMedian = () => {
            if (!lower.length && !upper.length) return null;
            if (lower.length === upper.length) return (lower[0] + upper[0]) / 2;
            return lower.length > upper.length ? lower[0] : upper[0];
          };
          const rebalance = (hot) => {
            if (lower.length > upper.length + 1) {
              const moved = lower.shift();
              let idx = upper.findIndex((v) => v > moved);
              if (idx === -1) idx = upper.length;
              upper.splice(idx, 0, moved);
              return { moved, from: "lower", to: "upper", idx };
            }
            if (upper.length > lower.length + 1) {
              const moved = upper.shift();
              let idx = lower.findIndex((v) => v < moved);
              if (idx === -1) idx = lower.length;
              lower.splice(idx, 0, moved);
              return { moved, from: "upper", to: "lower", idx };
            }
            return null;
          };

          steps.push({
            title: "Set up: two empty heaps and the command script",
            showIdx: false,
            tracks: [
              cmdTrack({ from: 0, to: -1 }),
              lowerTrack(),
              upperTrack(),
              medianCell("—", "no numbers yet"),
            ],
            counters: [count("commands", 0, cmds.length), count("numbers added", 0), count("sizes", "0 / 0")],
            legend: ["read", "done", "result", "active", "idle"],
            happened: `${cmds.length} command${cmds.length === 1 ? "" : "s"} queued; both halves of the split start empty.`,
            why: "Everything below the middle goes left, everything above goes right — starting empty keeps the divide honest from the first number.",
            codeLine: 4,
          });

          for (const op of cmds) {
            const base = [count("commands", cmdDone, cmds.length), count("numbers added", stream.length), count("sizes", `${lower.length} / ${upper.length}`)];

            if (op.op === "skip") {
              steps.push({
                title: `Skipped: ${op.note}`,
                showIdx: false,
                tracks: [cmdTrack(op), lowerTrack(), upperTrack(), medianCell(currentMedian() == null ? "—" : currentMedian(), "unchanged")],
                counters: base,
                legend: ["read", "done", "result", "idle"],
                happened: "The token did not have the shape 'add X' or 'median', so it was ignored with a note.",
                why: "Validating before touching the heaps keeps their balance invariant exactly as strong as the script promised.",
                codeLine: 19,
              });
              cmdDone++;
              continue;
            }

            if (op.op === "add") {
              const x = op.x;
              const toLower = lower.length === 0 || x <= lower[0];
              if (toLower) {
                let idx = lower.findIndex((v) => v < x);
                if (idx === -1) idx = lower.length;
                lower.splice(idx, 0, x);
              } else {
                let idx = upper.findIndex((v) => v > x);
                if (idx === -1) idx = upper.length;
                upper.splice(idx, 0, x);
              }
              stream.push(x);
              steps.push({
                title: `add ${x} → ${toLower ? "lower half (it is at most the current floor)" : "upper half (it is above the floor)"}`,
                showIdx: false,
                tracks: [
                  cmdTrack(op),
                  lowerTrack(toLower ? lower.map((v) => (v === x ? "read" : "done")) : undefined),
                  upperTrack(toLower ? undefined : upper.map((v) => (v === x ? "read" : "done"))),
                  streamTrack(stream.length - 1),
                  medianCell(currentMedian(), "after add"),
                ],
                counters: [count("commands", cmdDone, cmds.length), count("numbers added", stream.length), count("sizes", `${lower.length} / ${upper.length}`)],
                legend: ["read", "done", "result", "active", "idle"],
                happened: toLower
                  ? `${x} is no bigger than the lower half's root (${lower[0]}), so it belongs below the middle and joins that heap.`
                  : `${x} is above the lower half's root (${lower[0] || "—"}), so it lands in the upper half — the floor of the stream sits below it.`,
                why: "Routing by comparison against the current floor is what keeps every left value ≤ every right value without sorting anything.",
                codeLine: 20,
              });

              const reb = rebalance();
              if (reb) {
                steps.push({
                  title: `Rebalance: move ${reb.moved} from the ${reb.from} heap to the ${reb.to} heap`,
                  showIdx: false,
                  tracks: [
                    cmdTrack(op),
                    lowerTrack(lower.map((v) => (reb.from === "lower" && v === reb.moved ? "bad" : reb.to === "lower" && v === reb.moved ? "active" : "done"))),
                    upperTrack(upper.map((v) => (reb.from === "upper" && v === reb.moved ? "bad" : reb.to === "upper" && v === reb.moved ? "active" : "done"))),
                    streamTrack(-1),
                    medianCell(currentMedian(), "balanced"),
                  ],
                  counters: [count("commands", cmdDone, cmds.length), count("numbers added", stream.length), count("sizes", `${lower.length} / ${upper.length}`)],
                  legend: ["read", "done", "result", "active", "bad", "idle"],
                  happened: `${reb.moved} crossed from the ${reb.from} heap into the ${reb.to} heap, leaving the sizes at ${lower.length} and ${upper.length}.`,
                  why: "Sizes within one of each other guarantee each heap's root is a genuine middle candidate — that invariant is the whole trick.",
                  codeLine: 24,
                });
              }
              cmdDone++;
              continue;
            }

            /* median */
            medianAsked++;
            const m = currentMedian();
            if (m != null) medians.push(m);
            const parts =
              m == null
                ? "no numbers yet"
                : lower.length === upper.length
                  ? `(${lower[0]} + ${upper[0]}) ÷ 2`
                  : `${lower.length > upper.length ? lower[0] : upper[0]} from the bigger heap`;
            steps.push({
              title: m == null ? "median: the stream is empty — nothing to report" : `median = ${m} — ${parts}`,
              showIdx: false,
              tracks: [
                cmdTrack(op),
                lowerTrack(),
                upperTrack(),
                streamTrack(-1),
                medianCell(m == null ? "—" : m, m == null ? "empty stream" : "answer so far"),
              ],
              counters: [count("commands", cmdDone + 1, cmds.length), count("numbers added", stream.length), count("sizes", `${lower.length} / ${upper.length}`), count("answer", m == null ? "none" : m)],
              legend: ["read", "done", "result", "active", "idle"],
              happened: m == null
                ? "Both heaps are empty, so there is no middle value yet — the median command reports that honestly."
                : lower.length === upper.length
                  ? `Both halves hold ${lower.length} number${lower.length === 1 ? "" : "s"}, so the median averages the two roots: ${lower[0]} and ${upper[0]}.`
                  : `The halves differ by one, so the median is simply the root of the bigger heap: ${m}.`,
              why: m == null
                ? "A median query before any add is a real edge case the code must answer instead of crashing on."
                : lower.length === upper.length
                  ? "With an even count the middle falls between two values — averaging the two heap tops gives it in O(1)."
                  : "With an odd count one heap holds the exact middle, and its root is exposed at the front by the heap property.",
              codeLine: 32,
            });
            cmdDone++;
          }

          const answer = medians.length ? medians[medians.length - 1] : null;
          steps.push({
            title: medianAsked === 0
              ? "Answer: no median was ever requested"
              : answer == null
                ? "Answer: every median query arrived on an empty stream"
                : `Answer: the last real median asked for is ${answer}`,
            showIdx: false,
            tracks: [
              track("commands", tokens, fill(tokens.length, "done")),
              track("stream (sorted for reading)", stream.slice().sort((a, b) => a - b), fill(stream.length, "done")),
              lowerTrack(),
              upperTrack(),
              medianCell(answer == null ? "—" : answer, "final answer"),
            ],
            counters: [count("commands", cmds.length, cmds.length), count("numbers added", stream.length), count("medians answered", medians.length, medianAsked), count("answer", answer == null ? "none" : answer)],
            legend: ["done", "result", "active", "good", "idle"],
            happened: answer == null
              ? medianAsked === 0
                ? `The script ran ${cmds.length} command${cmds.length === 1 ? "" : "s"} without ever asking for a median; ${stream.length} number${stream.length === 1 ? " is" : "s are"} stored across the two heaps.`
                : `${medianAsked} median quer${medianAsked === 1 ? "y" : "ies"} came in before any number was added, so there was never a middle value to report.`
              : `After ${stream.length} addition${stream.length === 1 ? "" : "s"}, ${medians.length} of ${medianAsked} median quer${medianAsked === 1 ? "y" : "ies"} produced a value — the last one being ${answer}.`,
            why: "Each add cost one log-time push plus at most one move across the divide; each median read two tops and stopped — nothing was ever sorted.",
            codeLine: 32,
          });
          return steps;
        },
      },
    ],
  });
})();
