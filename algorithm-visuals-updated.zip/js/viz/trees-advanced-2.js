/* ============================================================
   DSA Visuals — Trees II
   Rebuilding from traversals, serialising, BST checks and
   in-place reshaping. Steps that mutate a tree take a deep
   snapshot first so every frame stays truthful.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, binaryTree } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const show = (a) => `[${a.join(", ")}]`;

  function toVal(t) {
    if (t == null) return null;
    const s = String(t).trim();
    if (!s || s.toLowerCase() === "null" || s === "-") return null;
    const n = Number(s);
    return Number.isFinite(n) ? n : s;
  }
  const toVals = (tokens) => (tokens || []).map(toVal);
  function sideVals(text) {
    return String(text || "").split(/[\s,;]+/).filter(Boolean).map(toVal);
  }
  function bfsList(root) {
    const out = [];
    for (const q = root ? [root] : []; q.length;) {
      const n = q.shift();
      out.push(n);
      if (n.l) q.push(n.l);
      if (n.r) q.push(n.r);
    }
    return out;
  }
  function inOrder(root) {
    const out = [];
    (function walk(n) {
      if (!n) return;
      walk(n.l);
      out.push(n);
      walk(n.r);
    })(root);
    return out;
  }
  const isLeaf = (n) => n && !n.l && !n.r;
  const cloneTree = (n) => (n ? { id: n.id, v: n.v, l: cloneTree(n.l), r: cloneTree(n.r) } : null);
  const mark = (base, ids, state) => {
    const m = Object.assign({}, base || {});
    ids.forEach((id) => { if (id != null) m[id] = state; });
    return m;
  };
  const empty = (title, happened, why) => [{
    title,
    kind: "cells",
    tracks: [{ label: "tree", cells: [{ v: "∅", state: "idle", empty: true }] }],
    counters: [count("nodes", 0)],
    legend: LEG,
    happened,
    why,
  }];

  /* ---------------------------------------------------------- */
  V.register({
    id: "construct-tree-from-traversals",
    title: "Construct Tree from Traversals",
    category: "Trees",
    difficulty: "Advanced",
    description: "Rebuild a unique binary tree from its preorder and inorder lists.",
    input: { label: "preorder | inorder", default: "3, 9, 20, 15, 7 | 9, 3, 15, 20, 7", parse: "string" },
    approaches: [
      {
        name: "Root Splits the Inorder Range",
        complexity: "O(n²) with linear search, O(n) with a value map",
        idea: [
          "The first unused preorder value is the root of the current subtree. Find that value in the inorder list.",
          "Everything before it in inorder belongs to the left subtree; everything after belongs to the right. Recurse on the two ranges using the same preorder cursor.",
        ],
        problem: [
          "If the inorder index is searched from the start of the whole list instead of the current range, values outside the subtree are mistaken for its children.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };
int pre[] = {3, 9, 20, 15, 7};
int in[]  = {9, 3, 15, 20, 7};
int cursor = 0;

int find_inorder(int v, int lo, int hi) {
    for (int i = lo; i <= hi; i++) if (in[i] == v) return i;
    return -1;
}

struct node *build(int lo, int hi) {
    if (lo > hi) return NULL;

    int v = pre[cursor++];
    struct node *root = malloc(sizeof *root);
    root->v = v;
    root->l = root->r = NULL;

    int mid = find_inorder(v, lo, hi);
    root->l = build(lo, mid - 1);
    root->r = build(mid + 1, hi);
    return root;
}

int main(void) {
    struct node *root = build(0, 4);
    printf("%d\\n", root->r->l->v); /* 15 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };

Node* build(const vector<int>& pre, int& at, int lo, int hi, unordered_map<int,int>& pos) {
    if (lo > hi) return nullptr;

    int v = pre[at++];
    Node* root = new Node{v};
    int mid = pos[v];                  // index in the full inorder list
    root->l = build(pre, at, lo, mid - 1, pos);
    root->r = build(pre, at, mid + 1, hi, pos);
    return root;
}

int main() {
    vector<int> pre{3,9,20,15,7}, in{9,3,15,20,7};
    unordered_map<int,int> pos;
    for (int i = 0; i < (int)in.size(); i++) pos[in[i]] = i;

    int at = 0;
    Node* root = build(pre, at, 0, (int)in.size() - 1, pos);
    cout << root->r->l->v << '\\n'; // 15
}`,
        },
        steps(text) {
          const segs = String(text || "").split("|");
          const pre = sideVals(segs[0]);
          const ino = sideVals(segs[1]);
          if (!pre.length || pre.length !== ino.length) {
            return [{
              title: "Give two traversals of the same length",
              kind: "cells",
              tracks: [{ label: "preorder", cells: pre.map((v) => ({ v, state: "idle" })) }, { label: "inorder", cells: ino.map((v) => ({ v, state: "idle" })) }],
              counters: [count("preorder", pre.length), count("inorder", ino.length)],
              legend: LEG,
              happened: "Both lists must describe the same nodes.",
              why: "A tree has one of each traversal, so the lengths must match.",
            }];
          }
          const steps = [];
          let cursor = 0, counter = 0;
          const created = [];
          steps.push({
            title: `Preorder ${show(pre)} and inorder ${show(ino)}`,
            kind: "cells",
            tracks: [track("preorder", pre, fill(pre.length, "idle")), track("inorder", ino, fill(ino.length, "idle"))],
            counters: [count("nodes", pre.length), count("built", 0)],
            legend: LEG,
            happened: "The preorder head is the next root; the inorder split decides its children.",
            why: "Preorder visits a node before its subtrees, inorder visits the left subtree first.",
            codeLine: 3,
          });
          const make = (lo, hi) => {
            if (lo > hi) return null;
            const v = pre[cursor++];
            const node = { id: "c" + counter++, v, l: null, r: null };
            created.push(node);
            const mid = ino.indexOf(v, lo);
            const states = mark({}, created.map((n) => n.id), "done");
            states[node.id] = "read";
            steps.push({
              title: `New root ${v}; inorder split at index ${mid}`,
              kind: "tree", tree: node,
              nodeStates: states,
              label: `inorder range [${lo}..${hi}] → left [${lo}..${mid - 1}], right [${mid + 1}..${hi}]`,
              counters: [count("built", created.length, pre.length), count("preorder cursor", cursor, pre.length)],
              legend: LEG,
              happened: `Values left of ${v} in the current range build the left subtree, values right build the right.`,
              why: "Inorder guarantees that the left subtree appears before the root and the right subtree after it.",
              codeLine: 14,
            });
            node.l = make(lo, mid - 1);
            node.r = make(mid + 1, hi);
            return node;
          };
          const root = make(0, ino.length - 1);
          steps.push({
            title: `Answer: rebuilt tree, preorder ${show(pre)}`,
            kind: "tree", tree: root,
            nodeStates: mark({}, created.map((n) => n.id), "result"),
            label: "the two traversals fully determine this tree",
            counters: [count("nodes", created.length), count("preorder used", cursor)],
            legend: LEG,
            happened: "Every preorder value was consumed exactly once.",
            why: "Inorder ranges prevent any node from being attached twice.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "serialize-and-deserialize-binary-tree",
    title: "Serialize and Deserialize Binary Tree",
    category: "Trees",
    difficulty: "Advanced",
    description: "Turn a tree into a string and rebuild the exact same tree from that string.",
    input: { label: "Tree (level order, null = gap)", default: "1, 2, 3, null, null, 4, 5", parse: "tokens" },
    approaches: [
      {
        name: "Preorder with Null Markers",
        complexity: "O(n) time and space",
        idea: [
          "Write a node's value, then serialize its left and right subtrees. Write a null marker for every missing child.",
          "To rebuild, read the next token: a marker means an empty subtree, anything else creates a node and consumes the following tokens for its children.",
        ],
        problem: [
          "Without null markers the shape is ambiguous: a single value does not say whether a missing child is on the left or the right.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

struct node { int v; struct node *l, *r; };
char out[256];
int at = 0;

void serialize(struct node *n) {
    if (!n) { strcat(out, "#,"); return; }
    char buf[16];
    sprintf(buf, "%d,", n->v);
    strcat(out, buf);
    serialize(n->l);
    serialize(n->r);
}

struct node *parse(char tokens[][16], int count) {
    if (at >= count) return NULL;
    if (strcmp(tokens[at], "#") == 0) { at++; return NULL; }

    struct node *n = malloc(sizeof *n);
    n->v = atoi(tokens[at++]);
    n->l = parse(tokens, count);
    n->r = parse(tokens, count);
    return n;
}

int main(void) {
    struct node n4 = {4, NULL, NULL}, n5 = {5, NULL, NULL};
    struct node n3 = {3, &n4, &n5}, n2 = {2, NULL, NULL};
    struct node root = {1, &n2, &n3};

    out[0] = 0;
    serialize(&root);
    printf("%s\\n", out); /* 1,2,#,#,3,4,#,#,5,#,#, */
    return 0;
}`,
          cpp: `#include <iostream>
#include <sstream>
#include <string>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };

void serialize(Node* n, string& out) {
    if (!n) { out += "#,"; return; }
    out += to_string(n->v) + ",";
    serialize(n->l, out);
    serialize(n->r, out);
}

Node* parse(const string& data, size_t& at) {
    size_t comma = data.find(',', at);
    string token = data.substr(at, comma - at);
    at = comma + 1;
    if (token == "#") return nullptr;

    Node* n = new Node{stoi(token)};
    n->l = parse(data, at);
    n->r = parse(data, at);
    return n;
}

int main() {
    Node n4{4}, n5{5}, n3{3}, n2{2};
    n3.l = &n4; n3.r = &n5;
    Node root{1}; root.l = &n2; root.r = &n3;

    string data;
    serialize(&root, data);
    cout << data << '\\n'; // 1,2,#,#,3,4,#,#,5,#,#,

    size_t at = 0;
    Node* copy = parse(data, at);
    cout << copy->r->l->v << '\\n'; // 4
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root) return empty("Empty tree — string is just #", "A null root writes one marker.", "The empty tree serializes to a single null marker.");
          const total = bfsList(root).length;
          const steps = [];
          const parts = [];
          const visited = [];
          steps.push({
            title: `Serialize root ${root.v} first`,
            kind: "tree", tree: root, nodeStates: { [root.id]: "read" },
            label: "string: (empty)",
            counters: [count("nodes", total), count("tokens", 0)],
            legend: LEG,
            happened: "Preorder writes a node before its children.",
            why: "A marker is needed wherever a child is missing.",
            codeLine: 7,
          });
          (function write(n) {
            if (!n) { parts.push("#"); return; }
            parts.push(String(n.v));
            visited.push(n.id);
            const states = mark({}, visited, "done");
            states[n.id] = "read";
            steps.push({
              title: n.l || n.r ? `Write ${n.v}, then its children` : `Write leaf ${n.v}, then two markers`,
              kind: "tree", tree: root, nodeStates: states,
              label: `string: ${parts.join(",")},`,
              counters: [count("tokens", parts.length), count("nodes written", visited.length, total)],
              legend: LEG,
              happened: isLeaf(n) ? `${n.v} is a leaf, so it is followed by # and #.` : `After ${n.v}, the left subtree is written completely before the right.`,
              why: "Preorder plus null markers makes the shape unambiguous.",
              codeLine: 9,
            });
            write(n.l);
            write(n.r);
          })(root);
          const data = parts.join(",") + ",";
          steps.push({
            title: `Serialized string, ${parts.length} tokens`,
            kind: "tree", tree: root, nodeStates: mark({}, bfsList(root).map((n) => n.id), "result"),
            label: data,
            counters: [count("tokens", parts.length), count("null markers", parts.filter((p) => p === "#").length)],
            legend: LEG,
            happened: "Every node and every missing child has one token.",
            why: "The marker count makes the parse deterministic.",
            codeLine: 14,
          });
          let at = 0, rebuilt = 0;
          const parse = () => {
            const token = parts[at++];
            if (token === "#") return null;
            const v = Number(token);
            rebuilt++;
            const node = { id: "d" + rebuilt, v, l: null, r: null };
            node.l = parse();
            node.r = parse();
            return node;
          };
          const copy = parse();
          const rebuiltNodes = bfsList(copy);
          steps.push({
            title: `Deserialize: read tokens left to right`,
            kind: "tree", tree: copy,
            nodeStates: mark({}, rebuiltNodes.map((n) => n.id), "result"),
            label: `rebuilt ${rebuilt} nodes from ${parts.length} tokens`,
            counters: [count("nodes rebuilt", rebuilt, total), count("tokens read", at)],
            legend: LEG,
            happened: "Each value creates a node and immediately consumes its left and right token runs.",
            why: "The recursive parse mirrors the recursive write exactly.",
            codeLine: 19,
          });
          steps.push({
            title: "Answer: the rebuilt tree matches the original",
            kind: "tree", tree: copy,
            nodeStates: mark({}, rebuiltNodes.map((n) => n.id), "done"),
            label: "structure and values are identical",
            counters: [count("nodes", rebuilt), count("original nodes", total)],
            legend: LEG,
            happened: "Preorder was consumed without leftovers.",
            why: "A unique token stream for the shape is what makes deserialization exact.",
            codeLine: 24,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "validate-binary-search-tree",
    title: "Validate Binary Search Tree",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Check that every node lies inside the open value range set by its ancestors.",
    input: { label: "Tree (level order, null = gap)", default: "5, 1, 7, null, null, 6, 8", parse: "tokens" },
    approaches: [
      {
        name: "Inorder Must Increase",
        complexity: "O(n) time, O(h) space",
        idea: [
          "An inorder walk of a valid search tree visits values in strictly increasing order.",
          "Carry the previous value; if the current value is not greater, the tree is invalid.",
        ],
        problem: [
          "Comparing only each node with its immediate children misses a violation deeper across a larger range.",
        ],
        code: {
          c: `#include <stdio.h>
#include <limits.h>

struct node { int v; struct node *l, *r; };

int check(struct node *n, long long *prev) {
    if (!n) return 1;
    if (!check(n->l, prev)) return 0;
    if (n->v <= *prev) return 0;      /* inorder must strictly increase */
    *prev = n->v;
    return check(n->r, prev);
}

int main(void) {
    struct node n6 = {6, NULL, NULL}, n8 = {8, NULL, NULL};
    struct node n7 = {7, &n6, &n8}, n1 = {1, NULL, NULL};
    struct node root = {5, &n1, &n7};

    long long prev = LLONG_MIN;
    printf("%d\\n", check(&root, &prev)); /* 0: 6 sits in the right subtree but below 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <climits>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };

bool valid(Node* n, long long& prev) {
    if (!n) return true;
    if (!valid(n->l, prev)) return false;
    if (n->v <= prev) return false;
    prev = n->v;
    return valid(n->r, prev);
}

int main() {
    Node n6{6}, n8{8}, n7{7}, n1{1};
    n7.l = &n6; n7.r = &n8;
    Node root{5}; root.l = &n1; root.r = &n7;

    long long prev = LLONG_MIN;
    cout << valid(&root, prev) << '\\n'; // 0
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root) return empty("Empty tree — valid", "There are no values to compare.", "An empty search tree trivially satisfies the ordering rule.");
          const steps = [];
          const order = [];
          let prev = -Infinity, ok = true, bad = null;
          steps.push({
            title: `Inorder values must strictly increase`,
            kind: "tree", tree: root, nodeStates: {},
            label: "previous: −∞",
            counters: [count("visited", 0), count("previous", "−∞")],
            legend: LEG,
            happened: "The first value has no predecessor.",
            why: "Inorder exposes the sorted order of a search tree directly.",
            codeLine: 6,
          });
          (function walk(n) {
            if (!n || !ok) return;
            walk(n.l);
            {
              const good = n.v > prev;
              if (!good) {
                ok = false;
                bad = n;
              }
              order.push(n.v);
              steps.push({
                title: good ? `Visit ${n.v}: greater than ${prev === -Infinity ? "−∞" : prev}` : `Visit ${n.v}: not greater than ${prev} → invalid`,
                kind: "tree", tree: root,
                nodeStates: mark(mark({}, order.map((v) => bfsList(root).find((x) => x.v === v)?.id), "done"), [n.id], good ? "read" : "bad"),
                label: `inorder: ${order.join(", ")}`,
                counters: [count("previous", prev === -Infinity ? "−∞" : prev), count("current", n.v)],
                legend: LEG,
                happened: good ? `${n.v} keeps the sequence increasing.` : `${n.v} should be larger than ${prev}.`,
                why: "One decreasing pair is enough to reject the whole tree.",
                codeLine: 8,
              });
              prev = n.v;
            }
            if (ok) walk(n.r);
          })(root);
          steps.push({
            title: ok ? "Answer: valid binary search tree" : `Answer: invalid at node ${bad.v}`,
            kind: "tree", tree: root,
            nodeStates: mark({}, bfsList(root).map((n) => n.id), ok ? "result" : "dim"),
            label: `inorder: ${order.join(", ")}`,
            counters: [count("visited", order.length), count("answer", ok ? "valid" : "invalid")],
            legend: LEG,
            happened: ok ? "The inorder sequence is strictly increasing end to end." : "At least one value broke the increasing order.",
            why: "The inorder sequence is the exact sorted order the tree claims to maintain.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "kth-smallest-element-in-bst",
    title: "Kth Smallest Element in BST",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Stop an inorder walk as soon as the k-th value has been seen.",
    input: { label: "Tree | k", default: "3, 1, 4, null, 2 | 1", parse: "string" },
    approaches: [
      {
        name: "Count While Walking Inorder",
        complexity: "O(h + k) time, O(h) space",
        idea: [
          "Inorder visits values from smallest to largest, so the k-th visited node is the answer.",
          "Keep a counter; as soon as it reaches k, return that value without visiting the rest of the tree.",
        ],
        problem: [
          "Collecting the whole inorder list first does unnecessary work when k is small, and uses O(n) extra memory.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };
int seen = 0, k, answer = -1;

void walk(struct node *n) {
    if (!n || answer != -1) return;
    walk(n->l);
    if (++seen == k) { answer = n->v; return; }
    walk(n->r);
}

int main(void) {
    struct node n2 = {2, NULL, NULL}, n1 = {1, NULL, NULL};
    struct node n4 = {4, NULL, NULL}, n3 = {3, &n1, &n4};
    struct node root = {3, &n1, &n4};
    root.l->r = &n2;

    k = 1;
    walk(&root);
    printf("%d\\n", answer); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };
int seen = 0;

int kthSmallest(Node* n, int k, bool& done) {
    if (!n) return -1;
    int left = kthSmallest(n->l, k, done);
    if (done) return left;

    if (++seen == k) { done = true; return n->v; }
    return kthSmallest(n->r, k, done);
}

int main() {
    Node n1{1}, n2{2}, n4{4};
    Node root{3};
    root.l = &n1; root.r = &n4; root.l->r = &n2;

    bool done = false;
    cout << kthSmallest(&root, 1, done) << '\\n'; // 1
}`,
        },
        steps(text) {
          const segs = String(text || "").split("|");
          const root = binaryTree(sideVals(segs[0]));
          const k = Math.max(1, parseInt(segs[1], 10) || 1);
          if (!root) return empty("Empty tree — no k-th value", "The walk never starts.", "There is no value to return.");
          const steps = [];
          const seen = [];
          let answer = null;
          steps.push({
            title: `Walk inorder and stop at visit ${k}`,
            kind: "tree", tree: root, nodeStates: {},
            label: "visited: (none)",
            counters: [count("visit", 0, k), count("k", k)],
            legend: LEG,
            happened: "The smallest value is the leftmost node, not the root.",
            why: "Inorder turns the search-tree ordering into a sorted sequence.",
            codeLine: 5,
          });
          (function walk(n) {
            if (!n || answer != null) return;
            walk(n.l);
            if (answer != null) return;
            seen.push(n);
            steps.push({
              title: `Visit ${n.v} → position ${seen.length}`,
              kind: "tree", tree: root,
              nodeStates: mark(mark({}, seen.map((x) => x.id), "done"), [n.id], seen.length === k ? "result" : "read"),
              label: `visited: ${seen.map((x) => x.v).join(", ")}`,
              counters: [count("visit", seen.length, k), count("k", k)],
              legend: LEG,
              happened: seen.length === k ? `${n.v} is the ${k}-th smallest value, so the walk stops.` : `${n.v} is number ${seen.length}; keep going.`,
              why: "The count is incremented before moving to the right subtree.",
              codeLine: 7,
            });
            if (seen.length === k) { answer = n.v; return; }
            walk(n.r);
          })(root);
          steps.push({
            title: answer != null ? `Answer: ${answer}` : "Answer: k is larger than the node count",
            kind: "tree", tree: root,
            nodeStates: mark({}, seen.map((x) => x.id), answer != null ? "done" : "dim"),
            label: `k = ${k}; visited ${seen.length} node${seen.length === 1 ? "" : "s"}`,
            counters: [count("k", k), count("answer", answer != null ? answer : "—")],
            legend: LEG,
            happened: answer != null ? "The walk stopped as soon as the k-th value was reached." : "The tree has fewer than k nodes.",
            why: "No value after the k-th visit can be the answer, so the rest is skipped.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "recover-binary-search-tree",
    title: "Recover Binary Search Tree",
    category: "Trees",
    difficulty: "Advanced",
    description: "Exactly two values were swapped in a search tree; find them and restore the order.",
    input: { label: "Tree (level order, null = gap)", default: "3, 1, 4, null, null, 2", parse: "tokens" },
    approaches: [
      {
        name: "Find the Two Inversions",
        complexity: "O(n) time, O(h) space",
        idea: [
          "Walk inorder while remembering the previous node. A valid search tree never produces a pair where previous > current.",
          "The first such pair contributes the previous node, the last pair contributes the current node. Swapping those two values restores the tree.",
        ],
        problem: [
          "Swapping the two nodes immediately on the first inversion fails when the swapped values are adjacent and the second culprit appears later.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };
struct node *first = NULL, *second = NULL, *prev = NULL;

void scan(struct node *n) {
    if (!n) return;
    scan(n->l);
    if (prev && prev->v > n->v) {
        if (!first) first = prev;        /* first inversion: keep previous */
        second = n;                      /* latest inversion: keep current */
    }
    prev = n;
    scan(n->r);
}

int main(void) {
    struct node n2 = {2, NULL, NULL}, n4 = {4, NULL, NULL};
    struct node n1 = {1, NULL, NULL}, n3 = {3, &n1, &n4};
    n4.l = &n2;
    struct node root = {3, &n1, &n4};

    scan(&root);
    int tmp = first->v; first->v = second->v; second->v = tmp;
    printf("%d %d\\n", first->v, second->v); /* 2 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <algorithm>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };
Node *first = nullptr, *second = nullptr, *prev = nullptr;

void scan(Node* n) {
    if (!n) return;
    scan(n->l);
    if (prev && prev->v > n->v) {
        if (!first) first = prev;
        second = n;
    }
    prev = n;
    scan(n->r);
}

int main() {
    Node n1{1}, n2{2}, n4{4};
    Node root{3};
    root.l = &n1; root.r = &n4; root.r->l = &n2;

    scan(&root);
    swap(first->v, second->v);
    cout << first->v << ' ' << second->v << '\\n'; // 2 3
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root) return empty("Empty tree — nothing to recover", "There is no value to compare.", "A swapped pair needs at least two nodes.");
          const steps = [];
          const order = [];
          let prev = null, first = null, second = null;
          steps.push({
            title: "Scan inorder, watching for a drop",
            kind: "tree", tree: cloneTree(root), nodeStates: {},
            label: "previous: none",
            counters: [count("inversions", 0), count("nodes seen", 0)],
            legend: LEG,
            happened: "A sorted sequence must never decrease.",
            why: "Two swapped values create one or two places where the order breaks.",
            codeLine: 5,
          });
          (function scan(n) {
            if (!n) return;
            scan(n.l);
            order.push(n);
            let title;
            if (prev && prev.v > n.v) {
              if (!first) first = prev;
              second = n;
              title = `Drop: ${prev.v} > ${n.v} → record ${first.v} and ${second.v}`;
            } else {
              title = `Visit ${n.v}; order is fine`;
            }
            const states = mark({}, order.map((x) => x.id), "done");
            if (prev) states[prev.id] = "compare";
            if (first) states[first.id] = "bad";
            if (second) states[second.id] = "bad";
            states[n.id] = "read";
            steps.push({
              title,
              kind: "tree", tree: cloneTree(root), nodeStates: states,
              label: `inorder so far: ${order.map((x) => x.v).join(", ")}`,
              counters: [count("inversions", first ? (second ? 2 : 1) : 0), count("nodes seen", order.length)],
              legend: LEG,
              happened: prev && prev.v > n.v ? `${prev.v} should come after ${n.v}, not before it.` : "This value continues the increasing run.",
              why: "The first inversion names one swapped value; the last inversion names the other.",
              codeLine: 8,
            });
            prev = n;
            scan(n.r);
          })(root);
          const aVal = first ? first.v : null;
          const bVal = second ? second.v : null;
          if (first && second) {
            const tmp = first.v;
            first.v = second.v;
            second.v = tmp;
          }
          const states = mark({}, [first && first.id, second && second.id], "result");
          steps.push({
            title: first && second ? `Answer: swap ${aVal} and ${bVal} back` : "Answer: the tree was already valid",
            kind: "tree", tree: cloneTree(root), nodeStates: states,
            label: first && second ? `restored inorder: ${inOrder(root).map((n) => n.v).join(", ")}` : "no swap needed",
            counters: [count("answer", first && second ? "recovered" : "valid"), count("nodes", order.length)],
            legend: LEG,
            happened: first && second ? "Swapping the two recorded values makes the inorder sequence strictly increase." : "No inversion was found.",
            why: "Exactly two values were misplaced, so one swap is sufficient.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "flatten-binary-tree-to-linked-list",
    title: "Flatten Binary Tree to Linked List",
    category: "Trees",
    difficulty: "Advanced",
    description: "Reshape the tree in place into a right-leaning chain in preorder.",
    input: { label: "Tree (level order, null = gap)", default: "1, 2, 5, 3, 4, null, 6", parse: "tokens" },
    approaches: [
      {
        name: "Move Left Subtree Under the Right",
        complexity: "O(n) time, O(1) extra space",
        idea: [
          "For each node that has a left child, find the rightmost node of that left subtree.",
          "Attach the old right subtree below that rightmost node, move the left subtree to the right, and clear the left pointer. Then continue with the new right child.",
        ],
        problem: [
          "Copying nodes into a new list uses extra memory; the reshaping must reuse the existing nodes.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };

void flatten(struct node *root) {
    for (struct node *n = root; n; n = n->r) {
        if (!n->l) continue;

        struct node *tail = n->l;
        while (tail->r) tail = tail->r;   /* rightmost of left subtree */
        tail->r = n->r;                    /* old right follows it */
        n->r = n->l;                       /* left becomes right */
        n->l = NULL;
    }
}

int main(void) {
    struct node n3 = {3, NULL, NULL}, n4 = {4, NULL, NULL};
    struct node n6 = {6, NULL, NULL};
    struct node n2 = {2, &n3, &n4}, n5 = {5, NULL, &n6};
    struct node root = {1, &n2, &n5};

    flatten(&root);
    for (struct node *n = &root; n; n = n->r) printf("%d ", n->v); /* 1 2 3 4 5 6 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };

void flatten(Node* root) {
    for (Node* n = root; n; n = n->r) {
        if (!n->l) continue;

        Node* tail = n->l;
        while (tail->r) tail = tail->r;
        tail->r = n->r;
        n->r = n->l;
        n->l = nullptr;
    }
}

int main() {
    Node n3{3}, n4{4}, n6{6}, n2{2}, n5{5};
    n2.l = &n3; n2.r = &n4;
    n5.r = &n6;
    Node root{1}; root.l = &n2; root.r = &n5;

    flatten(&root);
    for (Node* n = &root; n; n = n->r) cout << n->v << ' '; // 1 2 3 4 5 6
    cout << '\\n';
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root) return empty("Empty tree — nothing to flatten", "There is no node to move.", "A chain needs at least one node.");
          const steps = [];
          const total = bfsList(root).length;
          const done = new Set();
          steps.push({
            title: `Start at root ${root.v}`,
            kind: "tree", tree: cloneTree(root), nodeStates: {},
            label: "still a tree",
            counters: [count("nodes", total), count("flattened", 0, total)],
            legend: LEG,
            happened: "Preorder is the target order of the chain.",
            why: "Flattening keeps every node and rewires only the pointers.",
            codeLine: 5,
          });
          let n = root;
          for (let guard = 0; n && guard < 40; guard++) {
            if (!n.l) {
              done.add(n.id);
              steps.push({
                title: `${n.v}: no left child, move down the right side`,
                kind: "tree", tree: cloneTree(root),
                nodeStates: mark(mark({}, [...done], "done"), [n.id], "read"),
                label: "this node is already in place",
                counters: [count("flattened", done.size, total), count("node", n.v)],
                legend: LEG,
                happened: `${n.v} is already on the right spine.`,
                why: "Nothing needs to move when the left pointer is empty.",
                codeLine: 8,
              });
              n = n.r;
              continue;
            }
            let tail = n.l;
            while (tail.r) tail = tail.r;
            const oldRight = n.r;
            tail.r = oldRight;
            n.r = n.l;
            n.l = null;
            done.add(n.id);
            steps.push({
              title: `${n.v}: attach old right under ${tail.v}, then move left up`,
              kind: "tree", tree: cloneTree(root),
              nodeStates: mark(mark({}, [...done], "done"), [n.id, tail.id], "read"),
              label: `right spine starts ${n.v} → ${n.r.v}`,
              counters: [count("flattened", done.size, total), count("rightmost of left", tail.v)],
              legend: LEG,
              happened: `The whole left subtree now sits to the right of ${n.v}, followed by the old right subtree.`,
              why: "Finding the rightmost node of the left subtree gives a safe place to hang the old right side.",
              codeLine: 11,
            });
            n = n.r;
          }
          steps.push({
            title: `Answer: ${inOrder(root).length ? "preorder chain" : "empty"} ${(() => { const vals = []; for (let x = root; x; x = x.r) vals.push(x.v); return vals.join(" → "); })()}`,
            kind: "tree", tree: cloneTree(root),
            nodeStates: mark({}, bfsList(root).map((x) => x.id), "result"),
            label: "every node has an empty left child",
            counters: [count("nodes", total), count("left children", bfsList(root).filter((x) => x.l).length)],
            legend: LEG,
            happened: "Following right pointers from the root visits the original preorder.",
            why: "Each move placed the left subtree before the old right subtree, matching preorder.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "house-robber-iii",
    title: "House Robber III",
    category: "Trees",
    difficulty: "Advanced",
    description: "Rob houses on a binary tree so that no robbed node is next to another robbed node.",
    input: { label: "Tree of house values", default: "3, 2, 3, null, 3, null, 1", parse: "tokens" },
    approaches: [
      {
        name: "Return Rob and Skip Totals",
        complexity: "O(n) time, O(h) space",
        idea: [
          "Each subtree reports two numbers: the best total if its root is robbed, and the best total if its root is skipped.",
          "Robbing a node excludes robbing its children but allows their skipped totals. Skipping a node allows the better of rob or skip for each child.",
        ],
        problem: [
          "Returning only one number per subtree forces recomputation, because the parent needs to know whether the child was taken.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };
struct pair { int rob, skip; };

struct pair best(struct node *n) {
    if (n == NULL) return (struct pair){0, 0};

    struct pair L = best(n->l), R = best(n->r);
    int rob = n->v + L.skip + R.skip;                     /* children skipped */
    int skip = (L.rob > L.skip ? L.rob : L.skip)
             + (R.rob > R.skip ? R.rob : R.skip);         /* children free */
    return (struct pair){rob, skip};
}

int main(void) {
    struct node n3a = {3, NULL, NULL}, n1 = {1, NULL, NULL};
    struct node n2 = {2, NULL, &n3a}, n3b = {3, NULL, &n1};
    struct node root = {3, &n2, &n3b};

    struct pair p = best(&root);
    printf("%d\\n", p.rob > p.skip ? p.rob : p.skip); /* 7 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <algorithm>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };
struct Best { int rob, skip; };

Best best(Node* n) {
    if (!n) return {0, 0};
    Best L = best(n->l), R = best(n->r);

    int rob = n->v + L.skip + R.skip;
    int skip = max(L.rob, L.skip) + max(R.rob, R.skip);
    return {rob, skip};
}

int main() {
    Node n3a{3}, n1{1}, n2{2}, n3b{3};
    n2.r = &n3a; n3b.r = &n1;
    Node root{3}; root.l = &n2; root.r = &n3b;

    Best b = best(&root);
    cout << max(b.rob, b.skip) << '\\n'; // 7
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root) return empty("Empty tree — loot 0", "No house can be robbed.", "With no houses the best total is zero.");
          const steps = [];
          const results = new Map();
          const states = {};
          const label = () => [...results].map(([n, b]) => `${n.v}:rob ${b.rob}/skip ${b.skip}`).join(" · ") || "none yet";
          steps.push({
            title: "Work from the leaves upward",
            kind: "tree", tree: root, nodeStates: {},
            label: "rob / skip: none yet",
            counters: [count("best", 0), count("nodes", bfsList(root).length)],
            legend: LEG,
            happened: "A parent needs two numbers from each child.",
            why: "The decision at a node depends on whether its children were robbed.",
            codeLine: 6,
          });
          (function walk(n) {
            if (!n) return { rob: 0, skip: 0 };
            const L = walk(n.l);
            const R = walk(n.r);
            const rob = n.v + L.skip + R.skip;
            const skip = Math.max(L.rob, L.skip) + Math.max(R.rob, R.skip);
            results.set(n, { rob, skip });
            states[n.id] = "read";
            steps.push({
              title: `${n.v}: rob ${rob}, skip ${skip}`,
              kind: "tree", tree: root, nodeStates: mark(states, [n.id], "compare"),
              label: label(),
              counters: [count("rob here", rob), count("skip here", skip)],
              legend: LEG,
              happened: `Robbing ${n.v} adds ${n.v} to both children's skip totals; skipping it takes the better option from each child.`,
              why: "Two totals are needed because the parent cannot know which choice the child made otherwise.",
              codeLine: 9,
            });
            states[n.id] = "done";
            return { rob, skip };
          })(root);
          const answer = results.get(root);
          const best = Math.max(answer.rob, answer.skip);
          steps.push({
            title: `Answer: maximum loot ${best}`,
            kind: "tree", tree: root,
            nodeStates: mark({}, bfsList(root).map((n) => n.id), "result"),
            label: `root wants rob ${answer.rob} or skip ${answer.skip}`,
            counters: [count("answer", best), count("nodes", bfsList(root).length)],
            legend: LEG,
            happened: "The better of robbing and skipping the root is the overall maximum.",
            why: "Each subtree combined its children's best compatible totals exactly once.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "all-nodes-distance-k",
    title: "All Nodes Distance K",
    category: "Trees",
    difficulty: "Advanced",
    description: "List every node exactly k edges from a target, travelling through parents as well as children.",
    input: { label: "Tree | target | k", default: "3, 5, 1, 6, 2, 0, 8, null, null, 7, 4 | 5 | 2", parse: "string" },
    approaches: [
      {
        name: "Add Parent Edges, Then BFS",
        complexity: "O(n) time, O(n) space",
        idea: [
          "A tree only points downward, so add each node's parent as an extra undirected neighbour.",
          "Breadth-first search from the target for k rounds; the nodes reached in exactly the last round are the answer.",
        ],
        problem: [
          "Searching only downward misses nodes that are k steps away by going up towards the root first.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r, *parent; };
struct node *q[64];

void link(struct node *n, struct node *p) {
    if (!n) return;
    n->parent = p;
    link(n->l, n);
    link(n->r, n);
}

void distance_k(struct node *target, int k) {
    struct node *seen[64];
    int seen_n = 0, head = 0, tail = 0;
    q[tail++] = target;
    seen[seen_n++] = target;

    for (int d = 0; d < k; d++) {
        int end = tail;
        for (; head < end; head++) {
            struct node *n = q[head];
            struct node *next[3] = {n->l, n->r, n->parent};
            for (int i = 0; i < 3; i++) {
                if (!next[i]) continue;
                int known = 0;
                for (int s = 0; s < seen_n; s++) if (seen[s] == next[i]) known = 1;
                if (!known) { seen[seen_n++] = next[i]; q[tail++] = next[i]; }
            }
        }
    }
    for (int i = head; i < tail; i++) printf("%d ", q[i]->v);
    printf("\\n");
}

int main(void) {
    struct node n6 = {6}, n2 = {2}, n7 = {7}, n4 = {4};
    struct node n0 = {0}, n8 = {8}, n5 = {5}, n1 = {1};
    n2.l = &n7; n2.r = &n4;
    n5.l = &n6; n5.r = &n2; n1.l = &n0; n1.r = &n8;
    struct node root = {3}; root.l = &n5; root.r = &n1;

    link(&root, NULL);
    distance_k(&n5, 2); /* 7 4 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <unordered_set>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };

void parents(Node* n, Node* p, unordered_map<Node*, Node*>& up) {
    if (!n) return;
    up[n] = p;
    parents(n->l, n, up);
    parents(n->r, n, up);
}

vector<int> distanceK(Node* target, int k, unordered_map<Node*, Node*>& up) {
    unordered_set<Node*> seen{target};
    queue<Node*> q;
    q.push(target);

    for (int d = 0; d < k && !q.empty(); d++) {
        int size = (int)q.size();
        while (size--) {
            Node* n = q.front(); q.pop();
            for (Node* next : {n->l, n->r, up[n]}) {
                if (next && seen.insert(next).second) q.push(next);
            }
        }
    }

    vector<int> out;
    while (!q.empty()) { out.push_back(q.front()->v); q.pop(); }
    return out;
}

int main() {
    Node n6{6}, n2{2}, n7{7}, n4{4}, n0{0}, n8{8}, n5{5}, n1{1};
    n2.l = &n7; n2.r = &n4;
    n5.l = &n6; n5.r = &n2; n1.l = &n0; n1.r = &n8;
    Node root{3}; root.l = &n5; root.r = &n1;

    unordered_map<Node*, Node*> up;
    parents(&root, nullptr, up);
    for (int v : distanceK(&n5, 2, up)) cout << v << ' '; // 7 4 1
    cout << '\\n';
}`,
        },
        steps(text) {
          const segs = String(text || "").split("|");
          const root = binaryTree(sideVals(segs[0]));
          const targetV = toVal(segs[1]);
          const k = Math.max(0, parseInt(segs[2], 10) || 0);
          if (!root) return empty("Empty tree — no nodes at distance k", "There is no target to start from.", "Distance needs a starting node.");
          const steps = [];
          const nodes = bfsList(root);
          const target = nodes.find((n) => n.v === targetV) || root;
          const parent = new Map();
          parent.set(root, null);
          (function link(n) {
            if (!n) return;
            if (n.l) { parent.set(n.l, n); link(n.l); }
            if (n.r) { parent.set(n.r, n); link(n.r); }
          })(root);
          const seen = new Set([target]);
          let frontier = [target];
          steps.push({
            title: `Start at target ${target.v} with k = ${k}`,
            kind: "tree", tree: root, nodeStates: { [target.id]: "read" },
            label: "distance 0: " + target.v,
            counters: [count("distance", 0, k), count("reached", 1, nodes.length)],
            legend: LEG,
            happened: "The target itself is at distance 0.",
            why: "Parent pointers will be used as an extra direction during the search.",
            codeLine: 5,
          });
          for (let d = 0; d < k && frontier.length; d++) {
            const next = [];
            frontier.forEach((n) => {
              [n.l, n.r, parent.get(n)].forEach((m) => {
                if (m && !seen.has(m)) { seen.add(m); next.push(m); }
              });
            });
            const states = mark({}, [...seen].map((n) => n.id), "done");
            next.forEach((n) => { states[n.id] = d + 1 === k ? "result" : "active"; });
            steps.push({
              title: d + 1 === k ? `Distance ${k}: ${next.map((n) => n.v).join(", ") || "none"}` : `Distance ${d + 1}: ${next.map((n) => n.v).join(", ") || "none"}`,
              kind: "tree", tree: root, nodeStates: states,
              label: `frontier: ${next.map((n) => n.v).join(", ") || "(empty)"}`,
              counters: [count("distance", d + 1, k), count("reached", seen.size, nodes.length)],
              legend: LEG,
              happened: `One edge further reaches ${next.length} new node${next.length === 1 ? "" : "s"}.`,
              why: "Visited nodes are skipped so a step never returns to where it came from.",
              codeLine: 12,
            });
            frontier = next;
          }
          const answer = k === 0 ? [target] : frontier;
          steps.push({
            title: answer.length ? `Answer: ${answer.map((n) => n.v).join(", ")}` : "Answer: no node at that distance",
            kind: "tree", tree: root,
            nodeStates: mark({}, answer.map((n) => n.id), "result"),
            label: `distance ${k} from ${target.v}: ${answer.map((n) => n.v).join(", ") || "none"}`,
            counters: [count("distance", k), count("answer", answer.length)],
            legend: LEG,
            happened: answer.length ? "These are exactly the nodes reached on the final round." : "The search ran out of new neighbours before distance k.",
            why: "Each BFS round adds precisely one edge of distance.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });
})();
