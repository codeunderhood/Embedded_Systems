/* ============================================================
   DSA Visuals — Queues & Deques
   A ring buffer, a sliding window of negatives and a stack of
   colliding asteroids. Order is the whole point.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const nums = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number);
  const ops = (text) => String(text || "").split(";").map((s) => s.trim()).filter(Boolean);
  const show = (a) => `[${a.join(", ")}]`;

  /* ---------------------------------------------------------- */
  V.register({
    id: "first-negative-number-in-every-window",
    title: "First Negative Number in Every Window",
    category: "Queues & Deques",
    difficulty: "Intermediate",
    description:
      "Report the first negative value in each window of width k using a deque of negative indices.",
    input: { label: "numbers | k", default: "12,-1,-7,8,-15,30,16,28 | 3", parse: "string" },
    approaches: [
      {
        name: "Deque of Negative Indices",
        complexity: "O(n) time, O(k) space",
        idea: [
          "Push the index of each negative value into a deque. Positives are irrelevant and never enter.",
          "Drop indices that have left the window. The front is then the leftmost negative in the current window.",
        ],
        problem: [
          "Indices must be removed from the front exactly when they expire; values alone cannot reveal when that happens.",
        ],
        code: {
          c: `#include <stdio.h>

int main(void) {
    int a[] = {12, -1, -7, 8, -15, 30, 16, 28};
    int n = 8, k = 3, dq[64], head = 0, tail = 0;

    for (int i = 0; i < n; i++) {
        if (a[i] < 0) dq[tail++] = i;
        if (head < tail && dq[head] <= i - k) head++;
        if (i >= k - 1)
            printf("%d ", head < tail ? a[dq[head]] : 0);
    }
    printf("\\n"); /* -1 -1 -7 -15 -15 0 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <deque>
using namespace std;

vector<int> firstNegative(const vector<int>& a, int k) {
    deque<int> dq;
    vector<int> out;

    for (int i = 0; i < (int)a.size(); i++) {
        if (a[i] < 0) dq.push_back(i);
        if (!dq.empty() && dq.front() <= i - k) dq.pop_front();
        if (i >= k - 1) out.push_back(dq.empty() ? 0 : a[dq.front()]);
    }
    return out;
}

int main() {
    for (int v : firstNegative({12,-1,-7,8,-15,30,16,28}, 3)) cout << v << ' '; // -1 -1 -7 -15 -15 0
    cout << '\\n';
}`,
        },
        steps(text) {
          const [numsRaw, kRaw] = parts(text);
          const a = nums(numsRaw);
          const k = Math.max(1, parseInt(kRaw, 10) || 1);
          if (!a.length) {
            return [{
              title: "Give numbers and a window width",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("k", k)],
              legend: ["idle", "result"],
              happened: "Only negative values matter for this question.",
              why: "A deque keeps their order and their indices.",
            }];
          }
          const steps = [];
          const dq = [];
          const out = [];
          steps.push({
            title: `Window width ${k}; the deque stores negative indices only`,
            tracks: [track("numbers", a, fill(a.length, "idle")), chips("deque (indices)", ["—"], "dim")],
            counters: [count("k", k), count("windows", 0)],
            legend: LEG,
            happened: "The front of the deque will be the first negative in each window.",
            why: "Positives can be skipped because they never answer the question.",
            codeLine: 4,
          });
          for (let i = 0; i < a.length; i++) {
            if (a[i] < 0) dq.push(i);
            let expired = null;
            if (dq.length && dq[0] <= i - k) expired = dq.shift();
            const ready = i >= k - 1;
            if (ready) out.push(dq.length ? a[dq[0]] : 0);
            steps.push({
              title: ready
                ? `Window ${i - k + 1}..${i}: first negative ${dq.length ? a[dq[0]] : "none (0)"}`
                : `Index ${i} enters; window still filling`,
              tracks: [
                track("numbers", a, a.map((_, j) => (j === i ? "read" : j >= i - k + 1 && j <= i ? "active" : j < i ? "dim" : "idle"))),
                chips("deque indices", dq.length ? dq : ["—"], (j) => (j === 0 ? "result" : "dim")),
                chips("output", out.length ? out : ["—"], "result"),
              ],
              counters: [count("position", i, a.length), count("windows", out.length)],
              legend: LEG,
              happened: expired != null ? `Index ${expired} left the window and was removed from the front.` : a[i] < 0 ? `${a[i]} is negative, so its index joined the deque.` : "A positive value never enters the deque.",
              why: "The deque is ordered by index, so its front is the leftmost negative still in range.",
              codeLine: ready ? 7 : 5,
            });
          }
          steps.push({
            title: `Answer: ${show(out)}`,
            tracks: [chips("first negatives", out.map((v) => (v === 0 ? "none" : v)), "result")],
            counters: [count("windows", out.length), count("non-zero answers", out.filter((v) => v !== 0).length)],
            legend: LEG,
            happened: `${out.length} windows were answered.`,
            why: "Each index entered and left the deque at most once.",
            codeLine: 8,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "design-circular-queue",
    title: "Design Circular Queue",
    category: "Queues & Deques",
    difficulty: "Intermediate",
    description:
      "Implement a fixed-size queue whose tail wraps around to reuse freed slots.",
    input: {
      label: "capacity | enqueue v ; dequeue ; front ; rear ; full ; empty",
      default: "3 | enQueue 1 ; enQueue 2 ; enQueue 3 ; enQueue 4 ; deQueue ; enQueue 4 ; rear",
      parse: "string",
    },
    approaches: [
      {
        name: "Ring Buffer With Head and Size",
        complexity: "O(1) per operation",
        idea: [
          "Store values in a fixed array. The tail position is (head + size) mod capacity, so it wraps automatically.",
          "Enqueue writes at the tail and grows size; dequeue reads at the head and advances head, shrinking size.",
        ],
        problem: [
          "Tracking size separately avoids the classic full-versus-empty ambiguity when head equals tail.",
        ],
        code: {
          c: `#include <stdio.h>

int data[3], cap = 3, head = 0, size = 0;

int is_full(void) { return size == cap; }
int is_empty(void) { return size == 0; }

int enqueue(int v) {
    if (is_full()) return 0;
    data[(head + size) % cap] = v;
    size++;
    return 1;
}

int dequeue(void) {
    if (is_empty()) return 0;
    head = (head + 1) % cap;
    size--;
    return 1;
}

int rear(void) { return is_empty() ? -1 : data[(head + size - 1) % cap]; }

int main(void) {
    enqueue(1); enqueue(2); enqueue(3);
    printf("%d %d\\n", enqueue(4), rear()); /* 0 3 */
    dequeue(); enqueue(4);
    printf("%d\\n", rear()); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

class MyCircularQueue {
    vector<int> data;
    int head = 0, size = 0, cap;
public:
    explicit MyCircularQueue(int k) : data(k), cap(k) {}

    bool enQueue(int value) {
        if (isFull()) return false;
        data[(head + size) % cap] = value;
        size++;
        return true;
    }

    bool deQueue() {
        if (isEmpty()) return false;
        head = (head + 1) % cap;
        size--;
        return true;
    }

    int Front() { return isEmpty() ? -1 : data[head]; }
    int Rear() { return isEmpty() ? -1 : data[(head + size - 1) % cap]; }
    bool isEmpty() { return size == 0; }
    bool isFull() { return size == cap; }
};

int main() {
    MyCircularQueue q(3);
    q.enQueue(1); q.enQueue(2); q.enQueue(3);
    cout << q.enQueue(4) << ' ' << q.Rear() << '\\n'; // 0 3
    q.deQueue(); q.enQueue(4);
    cout << q.Rear() << '\\n'; // 4
}`,
        },
        steps(text) {
          const [capRaw, opRaw] = parts(text);
          const cap = Math.max(1, parseInt(capRaw, 10) || 1);
          const list = ops(opRaw);
          const data = Array(cap).fill(null);
          let head = 0, size = 0;
          const steps = [];
          const render = (mark) =>
            grid(1, cap, (r, c) => {
              const v = data[c];
              const pos = (head + size - 1) % cap;
              const markHere = mark && mark.col === c;
              return {
                v: v == null ? "·" : v,
                state: markHere ? mark.state : c === head && size ? "read" : c === pos && size ? "compare" : v == null ? "dim" : "idle",
              };
            });
          steps.push({
            title: `${cap} slots, head at 0, size 0`,
            kind: "grid", rows: 1, cols: cap,
            cells: render(),
            colHeads: Array.from({ length: cap }, (_, i) => i),
            counters: [count("size", 0, cap), count("head", 0)],
            legend: LEG,
            happened: "A slot is written at (head + size) mod capacity.",
            why: "The modulo makes the tail wrap without shifting any elements.",
            codeLine: 3,
          });
          for (const op of list) {
            const words = op.split(/\s+/);
            const name = words[0].toLowerCase();
            const value = parseInt(words[1], 10);
            let happened = "";
            let mark = null;
            if (name === "enqueue") {
              if (size === cap) happened = "Queue is full, enqueue fails.";
              else {
                const at = (head + size) % cap;
                data[at] = value;
                size++;
                mark = { col: at, state: "good" };
                happened = `${value} written at slot ${at}, size ${size}.`;
              }
            } else if (name === "dequeue") {
              if (size === 0) happened = "Queue is empty, dequeue fails.";
              else {
                const gone = data[head];
                mark = { col: head, state: "bad" };
                data[head] = null;
                head = (head + 1) % cap;
                size--;
                happened = `${gone} removed; head moves to ${head}, size ${size}.`;
              }
            } else if (name === "front") {
              happened = size ? `Front is ${data[head]}.` : "Queue is empty → −1.";
              mark = size ? { col: head, state: "result" } : null;
            } else if (name === "rear") {
              const pos = (head + size - 1 + cap) % cap;
              happened = size ? `Rear is ${data[pos]}.` : "Queue is empty → −1.";
              mark = size ? { col: pos, state: "result" } : null;
            } else if (name === "isempty") {
              happened = size === 0 ? "isEmpty is true." : "isEmpty is false.";
            } else if (name === "isfull") {
              happened = size === cap ? "isFull is true." : "isFull is false.";
            }
            steps.push({
              title: `${op} → ${happened}`,
              kind: "grid", rows: 1, cols: cap,
              cells: render(mark),
              colHeads: Array.from({ length: cap }, (_, i) => i),
              counters: [count("size", size, cap), count("head", head)],
              legend: LEG,
              happened,
              why: "The ring never moves existing values; only head and size change.",
              codeLine: name === "enqueue" ? 6 : name === "dequeue" ? 12 : name === "front" ? 18 : 19,
            });
          }
          steps.push({
            title: `Final queue: ${size ? show(Array.from({ length: size }, (_, i) => data[(head + i) % cap])) : "empty"}`,
            kind: "grid", rows: 1, cols: cap,
            cells: render(),
            colHeads: Array.from({ length: cap }, (_, i) => i),
            counters: [count("size", size, cap), count("head", head)],
            legend: LEG,
            happened: `${size} of ${cap} slots are in use.`,
            why: "Reading from head forward recovers the queue order.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "asteroid-collision",
    title: "Asteroid Collision",
    category: "Queues & Deques",
    difficulty: "Intermediate",
    description:
      "Simulate asteroids moving left and right, resolving collisions with a stack.",
    input: { label: "asteroids (sign = direction)", default: "5,10,-5,-15", parse: "ints" },
    approaches: [
      {
        name: "Stack of Survivors",
        complexity: "O(n) time, O(n) space",
        idea: [
          "A right-moving asteroid is pushed onto a stack. A left-moving one can only meet survivors already on the stack.",
          "Collisions happen while the stack top moves right and is no larger. Equal sizes destroy both; the survivor is decided by size.",
        ],
        problem: [
          "A left-moving asteroid never collides with an earlier left-mover, so the stack naturally skips those pairs.",
        ],
        code: {
          c: `#include <stdio.h>

int main(void) {
    int a[] = {5, 10, -5, -15};
    int n = 4, stack[64], top = 0;

    for (int i = 0; i < n; i++) {
        int alive = 1;
        while (alive && a[i] < 0 && top > 0 && stack[top - 1] > 0) {
            if (stack[top - 1] < -a[i]) { top--; continue; }      /* top explodes */
            if (stack[top - 1] == -a[i]) top--;                   /* both explode */
            alive = 0;
        }
        if (alive) stack[top++] = a[i];
    }

    for (int i = 0; i < top; i++) printf("%d ", stack[i]);
    printf("\\n"); /* 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

vector<int> asteroidCollision(vector<int> a) {
    vector<int> stack;

    for (int x : a) {
        bool alive = true;
        while (alive && x < 0 && !stack.empty() && stack.back() > 0) {
            if (stack.back() < -x) { stack.pop_back(); continue; }
            if (stack.back() == -x) stack.pop_back();
            alive = false;
        }
        if (alive) stack.push_back(x);
    }
    return stack;
}

int main() {
    for (int v : asteroidCollision({5,10,-5,-15})) cout << v << ' '; // 5
    cout << '\\n';
}`,
        },
        steps(values) {
          const a = values.slice();
          if (!a.length) {
            return [{
              title: "Give some asteroids",
              tracks: [chips("asteroids", ["—"], "idle")],
              counters: [count("survivors", 0)],
              legend: ["idle", "result"],
              happened: "Positive values move right, negative values move left.",
              why: "Only opposite-moving neighbours can collide.",
            }];
          }
          const steps = [];
          const stack = [];
          steps.push({
            title: `Queue: ${show(a)}; stack starts empty`,
            tracks: [track("asteroids", a, fill(a.length, "idle")), chips("survivors", ["—"], "dim")],
            counters: [count("survivors", 0), count("processed", 0)],
            legend: LEG,
            happened: "Positive moves right, negative moves left.",
            why: "A left-mover can only meet right-movers already on the stack.",
            codeLine: 4,
          });
          for (let i = 0; i < a.length; i++) {
            const x = a[i];
            let alive = true;
            const events = [];
            while (alive && x < 0 && stack.length && stack[stack.length - 1] > 0) {
              const top = stack[stack.length - 1];
              if (top < -x) {
                stack.pop();
                events.push(`${top} destroyed`);
                continue;
              }
              if (top === -x) {
                stack.pop();
                events.push(`${top} and ${x} destroy each other`);
              } else {
                events.push(`${x} destroyed by ${top}`);
              }
              alive = false;
            }
            if (alive) stack.push(x);
            steps.push({
              title: events.length ? `Asteroid ${x}: ${events.join("; ")}` : `Asteroid ${x} survives and joins the stack`,
              tracks: [
                track("asteroids", a, a.map((_, j) => (j === i ? "read" : j < i ? "dim" : "idle"))),
                chips("survivors", stack.length ? stack : ["—"], (j) => (j === stack.length - 1 ? "active" : "dim")),
              ],
              counters: [count("survivors", stack.length), count("processed", i + 1, a.length)],
              legend: LEG,
              happened: events.length ? events.join(". ") + "." : `${x} had nothing to collide with.`,
              why: "Larger asteroids survive; equal sizes cancel both.",
              codeLine: events.length ? 6 : 10,
            });
          }
          steps.push({
            title: `Answer: ${show(stack)}`,
            tracks: [chips("survivors", stack.length ? stack : ["none"], "result")],
            counters: [count("survivors", stack.length), count("destroyed", a.length - stack.length)],
            legend: LEG,
            happened: `${stack.length} asteroid${stack.length === 1 ? " survived" : "s survived"} ${a.length - stack.length} collision${a.length - stack.length === 1 ? "" : "s"}.`,
            why: "Each asteroid is pushed at most once and popped at most once.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });
})();
