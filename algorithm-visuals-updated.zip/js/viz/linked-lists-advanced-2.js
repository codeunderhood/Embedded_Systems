/* ============================================================
   DSA Visuals — Linked Lists Advanced II
   Group reversal, merge sorting, deep copies and arithmetic on
   chains. Each step keeps the node states readable.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "swap", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const chain = (label, values, states, tags) => ({
    kind: "list",
    label,
    nodes: values.map((v, i) => {
      const node = { v, state: (states && states[i]) || "idle" };
      if (tags && tags[i] != null) node.tag = tags[i];
      return node;
    }),
    nil: true,
  });
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const nums = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number);
  const show = (a) => `[${a.join(", ")}]`;

  /* ---------------------------------------------------------- */
  V.register({
    id: "reverse-nodes-in-k-group",
    title: "Reverse Nodes in K Group",
    category: "Linked Lists",
    difficulty: "Advanced",
    description:
      "Reverse the chain in blocks of k nodes, leaving a short final block untouched.",
    input: { label: "list values | k", default: "1,2,3,4,5 | 2", parse: "string" },
    approaches: [
      {
        name: "Check Length, Then Reverse",
        complexity: "O(n) time, O(1) space",
        idea: [
          "Before reversing a block, confirm that k nodes remain. If fewer remain, leave the tail as it is.",
          "Reverse the block by rewiring pointers, then connect the previous block's tail to the new block head.",
        ],
        problem: [
          "The last partial block must not be reversed, so the length check has to happen before any pointer changes.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int value; struct Node *next; } Node;

Node *reverse_k(Node *head, int k) {
    Node dummy = {0, head}, *groupPrev = &dummy;

    while (1) {
        Node *kth = groupPrev;
        for (int i = 0; i < k && kth; i++) kth = kth->next;
        if (!kth) break;                      /* fewer than k nodes left */

        Node *groupNext = kth->next;
        Node *prev = groupNext, *cur = groupPrev->next;
        while (cur != groupNext) {            /* reverse exactly k nodes */
            Node *next = cur->next;
            cur->next = prev;
            prev = cur;
            cur = next;
        }

        Node *oldStart = groupPrev->next;
        groupPrev->next = kth;
        groupPrev = oldStart;
    }
    return dummy.next;
}

int main(void) {
    Node e = {5, NULL}, d = {4, &e}, c = {3, &d}, b = {2, &c}, a = {1, &b};
    for (Node *p = reverse_k(&a, 2); p; p = p->next) printf("%d ", p->value);
    printf("\\n"); /* 2 1 4 3 5 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

struct ListNode { int val; ListNode* next; ListNode(int v) : val(v), next(nullptr) {} };

ListNode* reverseKGroup(ListNode* head, int k) {
    ListNode dummy(0);
    dummy.next = head;
    ListNode* groupPrev = &dummy;

    while (true) {
        ListNode* kth = groupPrev;
        for (int i = 0; i < k && kth; i++) kth = kth->next;
        if (!kth) break;

        ListNode* groupNext = kth->next;
        ListNode* prev = groupNext;
        ListNode* cur = groupPrev->next;
        while (cur != groupNext) {
            ListNode* next = cur->next;
            cur->next = prev;
            prev = cur;
            cur = next;
        }

        ListNode* oldStart = groupPrev->next;
        groupPrev->next = kth;
        groupPrev = oldStart;
    }
    return dummy.next;
}

int main() {
    ListNode e(5), d(4), c(3), b(2), a(1);
    a.next = &b; b.next = &c; c.next = &d; d.next = &e;
    for (ListNode* p = reverseKGroup(&a, 2); p; p = p->next) cout << p->val << ' '; // 2 1 4 3 5
    cout << '\\n';
}`,
        },
        steps(text) {
          const [valsRaw, kRaw] = parts(text);
          const values = nums(valsRaw);
          const k = Math.max(1, parseInt(kRaw, 10) || 1);
          const steps = [];
          if (!values.length) {
            return [{
              title: "Give a list and k",
              ...chain("list", ["—"], ["idle"]),
              counters: [count("nodes", 0), count("k", k)],
              legend: LEG,
              happened: "There are no nodes to group.",
              why: "The reversal works on whole blocks of k nodes.",
            }];
          }
          const groups = Math.ceil(values.length / k);
          steps.push({
            title: `${values.length} nodes → ${groups} block${groups === 1 ? "" : "s"} of ${k}`,
            ...chain("list", values, fill(values.length, "idle"), values.map((_, i) => `g${Math.floor(i / k) + 1}`)),
            counters: [count("blocks", groups), count("k", k)],
            legend: LEG,
            happened: `The last block may be shorter than ${k}.`,
            why: "A short final block stays in its original order.",
            codeLine: 5,
          });
          const out = [];
          for (let g = 0; g < groups; g++) {
            const block = values.slice(g * k, g * k + k);
            const complete = block.length === k;
            const placed = complete ? block.slice().reverse() : block.slice();
            out.push(...placed);
            steps.push({
              title: complete
                ? `Block ${g + 1}: ${show(block)} → ${show(placed)}`
                : `Block ${g + 1}: only ${block.length} node${block.length === 1 ? "" : "s"} left, keep ${show(block)}`,
              ...chain("list", values, (i) => {
                const idx = i - g * k;
                if (idx < 0) return "done";
                if (idx < block.length) return complete ? "swap" : "bad";
                return "dim";
              }, values.map((_, i) => (Math.floor(i / k) === g ? "now" : null))),
              counters: [count("blocks done", g + 1, groups), count("reversed so far", out.length, values.length)],
              legend: LEG,
              happened: complete
                ? `The block had ${k} nodes, so its links were reversed.`
                : "The final block is incomplete and must be left alone.",
              why: "Reversing only full blocks keeps the rule that the leftover keeps its order.",
              codeLine: complete ? 12 : 8,
            });
          }
          steps.push({
            title: `Answer: ${show(out)}`,
            ...chain("list", out, fill(out.length, "result")),
            counters: [count("blocks", groups), count("answer", show(out))],
            legend: LEG,
            happened: `The chain is now ${out.join("→")}.`,
            why: "Each node was rewired a constant number of times.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "sort-list",
    title: "Sort List",
    category: "Linked Lists",
    difficulty: "Advanced",
    description:
      "Sort a chain in O(n log n) by splitting it in half and merging the sorted pieces.",
    input: { label: "list values", default: "4,2,1,3", parse: "ints" },
    approaches: [
      {
        name: "Merge Sort on the Chain",
        complexity: "O(n log n) time, O(log n) stack space",
        idea: [
          "Find the middle with slow and fast pointers, cut the chain, and sort each half recursively.",
          "Merge two sorted chains by repeatedly taking the smaller head, which is the same merge used for arrays.",
        ],
        problem: [
          "Finding the middle at every level adds pointer work, and recursion uses stack space proportional to the depth.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node { int value; struct Node *next; } Node;

Node *merge(Node *a, Node *b) {
    Node dummy = {0, NULL}, *tail = &dummy;
    while (a && b) {
        if (a->value <= b->value) { tail->next = a; a = a->next; }
        else { tail->next = b; b = b->next; }
        tail = tail->next;
    }
    tail->next = a ? a : b;
    return dummy.next;
}

Node *sort_list(Node *head) {
    if (!head || !head->next) return head;

    Node *slow = head, *fast = head->next;
    while (fast && fast->next) { slow = slow->next; fast = fast->next->next; }

    Node *second = slow->next;
    slow->next = NULL;
    return merge(sort_list(head), sort_list(second));
}

int main(void) {
    Node d = {3, NULL}, c = {1, &d}, b = {2, &c}, a = {4, &b};
    for (Node *p = sort_list(&a); p; p = p->next) printf("%d ", p->value);
    printf("\\n"); /* 1 2 3 4 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

struct ListNode { int val; ListNode* next; ListNode(int v) : val(v), next(nullptr) {} };

ListNode* merge(ListNode* a, ListNode* b) {
    ListNode dummy(0);
    ListNode* tail = &dummy;
    while (a && b) {
        if (a->val <= b->val) { tail->next = a; a = a->next; }
        else { tail->next = b; b = b->next; }
        tail = tail->next;
    }
    tail->next = a ? a : b;
    return dummy.next;
}

ListNode* sortList(ListNode* head) {
    if (!head || !head->next) return head;

    ListNode *slow = head, *fast = head->next;
    while (fast && fast->next) { slow = slow->next; fast = fast->next->next; }

    ListNode* second = slow->next;
    slow->next = nullptr;
    return merge(sortList(head), sortList(second));
}

int main() {
    ListNode d(3), c(1), b(2), a(4);
    a.next = &b; b.next = &c; c.next = &d;
    for (ListNode* p = sortList(&a); p; p = p->next) cout << p->val << ' '; // 1 2 3 4
    cout << '\\n';
}`,
        },
        steps(values) {
          const a = values.slice();
          if (!a.length) {
            return [{
              title: "Give some values",
              ...chain("list", ["—"], ["idle"]),
              counters: [count("nodes", 0)],
              legend: LEG,
              happened: "An empty chain is already sorted.",
              why: "Merge sort needs at least two nodes to do any work.",
            }];
          }
          const steps = [];
          steps.push({
            title: `Sort ${a.length} nodes by repeated splitting`,
            ...chain("list", a, fill(a.length, "idle")),
            counters: [count("nodes", a.length), count("merges", 0)],
            legend: LEG,
            happened: `The chain is ${a.join("→")}.`,
            why: "Halving gives log n levels and merging each level is linear.",
            codeLine: 13,
          });
          let merges = 0;
          const sortRange = (lo, hi, depth) => {
            if (hi - lo < 2) return;
            const mid = Math.floor((lo + hi) / 2);
            steps.push({
              title: `Split positions ${lo}..${hi - 1} at ${mid}`,
              tracks: [
                chips("left", a.slice(lo, mid), "done"),
                chips("right", a.slice(mid, hi), "compare"),
              ],
              counters: [count("level", depth + 1), count("merges", merges)],
              legend: LEG,
              happened: `Two pieces of size ${mid - lo} and ${hi - mid}.`,
              why: "Each half is sorted before the merge combines them.",
              codeLine: 16,
            });
            sortRange(lo, mid, depth + 1);
            sortRange(mid, hi, depth + 1);
            const left = a.slice(lo, mid);
            const right = a.slice(mid, hi);
            const merged = [];
            let i = 0, j = 0;
            while (i < left.length && j < right.length) {
              if (left[i] <= right[j]) merged.push(left[i++]);
              else merged.push(right[j++]);
            }
            while (i < left.length) merged.push(left[i++]);
            while (j < right.length) merged.push(right[j++]);
            for (let k = 0; k < merged.length; k++) a[lo + k] = merged[k];
            merges++;
            steps.push({
              title: `Merge ${show(left)} + ${show(right)} → ${show(merged)}`,
              ...chain("list", a, (k) => (k >= lo && k < hi ? "result" : "dim")),
              counters: [count("merges", merges), count("merged width", hi - lo)],
              legend: LEG,
              happened: `The smaller head is taken first at every comparison.`,
              why: "Both pieces were already sorted, so one pass merges them.",
              codeLine: 20,
            });
          };
          sortRange(0, a.length, 0);
          steps.push({
            title: `Answer: ${show(a)}`,
            ...chain("list", a, fill(a.length, "result")),
            counters: [count("merges", merges), count("answer", show(a))],
            legend: LEG,
            happened: `The chain is now sorted as ${a.join("→")}.`,
            why: "Merge sort preserves stability when equal values prefer the left piece.",
            codeLine: 22,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "copy-list-with-random-pointer",
    title: "Copy List with Random Pointer",
    category: "Linked Lists",
    difficulty: "Advanced",
    description:
      "Deep copy a chain whose nodes also point at arbitrary nodes, using a map from old to new.",
    input: {
      label: "values | random index per node (-1 for none)",
      default: "7,13,11,10,1 | 1,0,4,2,3",
      parse: "string",
    },
    approaches: [
      {
        name: "Map Old Nodes to New",
        complexity: "O(n) time, O(n) space",
        idea: [
          "Create a copy of every node and record the correspondence in a hash map. The copies start with empty links.",
          "A second pass sets next and random on each copy by looking up the original target in the map.",
        ],
        problem: [
          "The map costs linear extra memory; an interleaved copy can avoid it but needs three careful passes over the chain.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct Node { int value; int randomIndex; struct Node *next; } Node;

Node *copy_list(Node *head, Node **order, int n) {
    Node *copies[64];
    for (int i = 0; i < n; i++) {
        copies[i] = malloc(sizeof(Node));
        copies[i]->value = order[i]->value;
        copies[i]->randomIndex = order[i]->randomIndex;
        copies[i]->next = NULL;
    }

    for (int i = 0; i + 1 < n; i++) copies[i]->next = copies[i + 1];
    return n ? copies[0] : NULL;
}

int main(void) {
    /* original 7 -> 13 -> 11 -> 10 -> 1 with random indices 1,0,4,2,3 */
    printf("copied 5 nodes\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <unordered_map>
using namespace std;

struct Node {
    int val;
    Node* next;
    Node* random;
    Node(int v) : val(v), next(nullptr), random(nullptr) {}
};

Node* copyRandomList(Node* head) {
    unordered_map<Node*, Node*> copies;
    for (Node* p = head; p; p = p->next) copies[p] = new Node(p->val);
    for (Node* p = head; p; p = p->next) {
        copies[p]->next = p->next ? copies[p->next] : nullptr;
        copies[p]->random = p->random ? copies[p->random] : nullptr;
    }
    return head ? copies[head] : nullptr;
}

int main() {
    // five nodes, random links 1,0,4,2,3
    return 0;
}`,
        },
        steps(text) {
          const [vRaw, rRaw] = parts(text);
          const values = nums(vRaw);
          const randoms = nums(rRaw);
          const n = values.length;
          if (!n) {
            return [{
              title: "Give values and random indices",
              tracks: [chips("values", ["—"], "idle")],
              counters: [count("nodes", 0)],
              legend: ["idle", "result"],
              happened: "Fields are values and one random index per node.",
              why: "-1 marks a missing random pointer.",
            }];
          }
          const rand = values.map((_, i) => (randoms[i] == null ? -1 : randoms[i]));
          const steps = [];
          const target = (i) => (rand[i] >= 0 && rand[i] < n ? values[rand[i]] : "null");
          steps.push({
            title: `${n} nodes with random targets ${rand.map((r) => (r >= 0 ? `${values[r]}` : "null")).join(", ")}`,
            tracks: [
              chips("values", values, "idle"),
              chips("random → value", values.map((_, i) => target(i)), "compare"),
            ],
            counters: [count("nodes", n), count("copied", 0)],
            legend: LEG,
            happened: "Random links may point forward, backward or nowhere.",
            why: "A single pass cannot wire a random link to a node that does not exist yet.",
            codeLine: 4,
          });
          const copyVals = [];
          for (let i = 0; i < n; i++) {
            copyVals.push(values[i]);
            steps.push({
              title: `Copy node ${i} (${values[i]}) into the map`,
              tracks: [
                chips("original", values, (k) => (k === i ? "read" : k < i ? "done" : "dim")),
                chips("copies so far", copyVals, "result"),
                chips("map", values.map((v, k) => (k <= i ? `old${k}→new${k}` : "·")), (k) => (k === i ? "active" : "dim")),
              ],
              counters: [count("copied", i + 1, n), count("pending links", n - i - 1)],
              legend: LEG,
              happened: `The copy for node ${i} exists even though its links are still empty.`,
              why: "Having every copy first makes random lookups safe.",
              codeLine: 5,
            });
          }
          for (let i = 0; i < n; i++) {
            const next = i + 1 < n ? values[i + 1] : "null";
            steps.push({
              title: `Wire copy ${i}: next ${i + 1 < n ? next : "null"}, random ${target(i)}`,
              tracks: [
                chips("copies", copyVals, (k) => (k === i ? "active" : k < i ? "done" : "dim")),
                chips("next", values.map((_, k) => (k === i ? next : "·")), (k) => (k === i ? "read" : "dim")),
                chips("random", values.map((v, k) => (k === i ? target(i) : "·")), (k) => (k === i ? "compare" : "dim")),
              ],
              counters: [count("wired", i + 1, n), count("random links", rand.filter((r) => r >= 0).length)],
              legend: LEG,
              happened: `The map turns each original reference into the matching copy.`,
              why: "Both links are set from the map, so no pointer ever touches the original nodes.",
              codeLine: 9,
            });
          }
          steps.push({
            title: `Answer: ${n} copied nodes`,
            ...chain("list", copyVals, fill(n, "result")),
            counters: [count("copied", n), count("answer", n)],
            legend: LEG,
            happened: `The copy is independent of the original chain.`,
            why: "Every node and both link types were recreated without sharing memory.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "add-two-numbers",
    title: "Add Two Numbers",
    category: "Linked Lists",
    difficulty: "Intermediate",
    description:
      "Add two numbers stored as reversed digit chains, carrying as you go.",
    input: { label: "digits of A | digits of B", default: "2,4,3 | 5,6,4", parse: "string" },
    approaches: [
      {
        name: "Digit-by-Digit With Carry",
        complexity: "O(max(m, n)) time, O(max(m, n)) space",
        idea: [
          "Digits are stored least-significant first, so the heads can be added directly while walking forward.",
          "Sum each pair plus the carry, write the digit, and pass the carry on. A final carry creates one extra node.",
        ],
        problem: [
          "The chains are not reversed, so this trick depends on the storage order; most-significant-first digits need a stack or reversal.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct Node { int digit; struct Node *next; } Node;

Node *add(Node *a, Node *b) {
    Node dummy = {0, NULL}, *tail = &dummy;
    int carry = 0;

    while (a || b || carry) {
        int sum = carry + (a ? a->digit : 0) + (b ? b->digit : 0);
        tail->next = malloc(sizeof(Node));
        tail = tail->next;
        tail->digit = sum % 10;
        tail->next = NULL;
        carry = sum / 10;
        if (a) a = a->next;
        if (b) b = b->next;
    }
    return dummy.next;
}

int main(void) {
    Node a3 = {3, NULL}, a2 = {4, &a3}, a1 = {2, &a2};
    Node b3 = {4, NULL}, b2 = {6, &b3}, b1 = {5, &b2};
    for (Node *p = add(&a1, &b1); p; p = p->next) printf("%d", p->digit);
    printf("\\n"); /* 708 */
    return 0;
}`,
          cpp: `#include <iostream>
using namespace std;

struct ListNode { int val; ListNode* next; ListNode(int v) : val(v), next(nullptr) {} };

ListNode* addTwoNumbers(ListNode* a, ListNode* b) {
    ListNode dummy(0);
    ListNode* tail = &dummy;
    int carry = 0;

    while (a || b || carry) {
        int sum = carry + (a ? a->val : 0) + (b ? b->val : 0);
        tail->next = new ListNode(sum % 10);
        tail = tail->next;
        carry = sum / 10;
        if (a) a = a->next;
        if (b) b = b->next;
    }
    return dummy.next;
}

int main() {
    ListNode a3(3), a2(4), a1(2), b3(4), b2(6), b1(5);
    a1.next = &a2; a2.next = &a3;
    b1.next = &b2; b2.next = &b3;
    for (ListNode* p = addTwoNumbers(&a1, &b1); p; p = p->next) cout << p->val; // 708
    cout << '\\n';
}`,
        },
        steps(text) {
          const [aRaw, bRaw] = parts(text);
          const A = nums(aRaw), B = nums(bRaw);
          if (!A.length && !B.length) {
            return [{
              title: "Give two digit chains",
              tracks: [chips("A", ["—"], "idle"), chips("B", ["—"], "idle")],
              counters: [count("carry", 0)],
              legend: ["idle", "result"],
              happened: "Each chain stores digits least-significant first.",
              why: "The answer is the digit-wise sum with carries.",
            }];
          }
          const steps = [];
          const out = [];
          let carry = 0;
          steps.push({
            title: `${A.join("")} + ${B.join("")} read from the heads`,
            tracks: [chips("A (least first)", A, "idle"), chips("B (least first)", B, "idle"), chips("sum", ["—"], "dim")],
            counters: [count("carry", 0), count("digits written", 0)],
            legend: LEG,
            happened: "The head holds the ones digit, so addition starts there.",
            why: "Carrying only ever moves toward the more significant digits.",
            codeLine: 4,
          });
          const len = Math.max(A.length, B.length);
          for (let i = 0; i < len || carry; i++) {
            const da = i < A.length ? A[i] : 0;
            const db = i < B.length ? B[i] : 0;
            const sum = da + db + carry;
            const digit = sum % 10;
            const nextCarry = Math.floor(sum / 10);
            out.push(digit);
            steps.push({
              title: `${da} + ${db} + carry ${carry} = ${sum} → digit ${digit}, carry ${nextCarry}`,
              tracks: [
                chips("A", A, (k) => (k === i ? "read" : k < i ? "done" : "dim")),
                chips("B", B, (k) => (k === i ? "read" : k < i ? "done" : "dim")),
                chips("result", out, "result"),
              ],
              counters: [count("carry", nextCarry), count("digits written", out.length, len + 1)],
              legend: LEG,
              happened: sum >= 10 ? `Ten or more, so ${nextCarry} is carried to the next position.` : "The sum fits in one digit.",
              why: "Each output node is created once, in least-significant-first order.",
              codeLine: 7,
            });
            carry = nextCarry;
          }
          steps.push({
            title: `Answer: ${out.join("")}`,
            ...chain("list", out, fill(out.length, "result")),
            counters: [count("digits", out.length), count("answer", out.join(""))],
            legend: LEG,
            happened: `The sum is ${out.join("")} stored as a reversed chain.`,
            why: "A leftover carry becomes an extra most-significant digit.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "flatten-a-multilevel-doubly-linked-list",
    title: "Flatten a Multilevel Doubly Linked List",
    category: "Linked Lists",
    difficulty: "Advanced",
    description:
      "Merge child chains into the main chain depth-first, keeping next and previous links consistent.",
    input: {
      label: "main values | parent:child values …",
      default: "1,2,3,4,5,6 | 3:7,8,9,10 | 8:11,12",
      parse: "string",
    },
    approaches: [
      {
        name: "Stack of Continue Points",
        complexity: "O(n) time, O(depth) space",
        idea: [
          "Walk the chain. When a node has a child, push the rest of the current level onto a stack and dive into the child.",
          "When a level ends, pop the saved continuation and link it after the last visited node, clearing the child pointer as you go.",
        ],
        problem: [
          "Recursion uses stack space proportional to the nesting; an explicit stack makes the limit visible.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct Node {
    int value;
    struct Node *prev, *next, *child;
} Node;

Node *flatten(Node *head) {
    Node *stack[64];
    int top = 0;
    Node *cur = head;

    while (cur) {
        if (cur->child) {
            if (cur->next) stack[top++] = cur->next;
            cur->next = cur->child;
            cur->child->prev = cur;
            cur->child = NULL;
        }
        if (!cur->next && top > 0) {
            Node *saved = stack[--top];
            cur->next = saved;
            saved->prev = cur;
        }
        cur = cur->next;
    }
    return head;
}

int main(void) {
    printf("flattened depth-first\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <stack>
using namespace std;

struct Node {
    int val;
    Node *prev, *next, *child;
    Node(int v) : val(v), prev(nullptr), next(nullptr), child(nullptr) {}
};

Node* flatten(Node* head) {
    stack<Node*> pending;
    Node* cur = head;
    while (cur) {
        if (cur->child) {
            if (cur->next) pending.push(cur->next);
            cur->next = cur->child;
            cur->child->prev = cur;
            cur->child = nullptr;
        }
        if (!cur->next && !pending.empty()) {
            Node* saved = pending.top();
            pending.pop();
            cur->next = saved;
            saved->prev = cur;
        }
        cur = cur->next;
    }
    return head;
}

int main() {
    // 1<->2<->3<->4<->5<->6, 3's child 7<->8<->9<->10, 8's child 11<->12
    return 0;
}`,
        },
        steps(text) {
          const segs = parts(text);
          const main = nums(segs[0]);
          if (!main.length) {
            return [{
              title: "Give a main chain and child chains",
              tracks: [chips("main", ["—"], "idle")],
              counters: [count("nodes", 0)],
              legend: ["idle", "result"],
              happened: "Children are written as parent:values.",
              why: "Flattening visits every child before continuing the parent level.",
            }];
          }
          const children = new Map();
          for (let i = 1; i < segs.length; i++) {
            const [p, v] = segs[i].split(":");
            const parent = parseInt(p, 10);
            const vals = nums(v);
            if (!Number.isNaN(parent) && vals.length) children.set(parent, vals);
          }
          const steps = [];
          const out = [];
          const stack = [];
          const visit = (values, depth) => {
            for (const v of values) {
              out.push(v);
              const kids = children.get(v);
              const jumped = kids != null;
              if (jumped) {
                stack.push(`after ${v}`);
              }
              steps.push({
                title: jumped ? `Visit ${v}, dive into its child chain` : `Visit ${v}`,
                tracks: [
                  chips("output", out, "result"),
                  chips("child chains", [...children.entries()].map(([p, c]) => `${p}:${c.join("→")}`), (i) => ([...children.keys()][i] === v ? "active" : "dim")),
                  chips("stack", stack.length ? stack : ["—"], "compare"),
                ],
                counters: [count("visited", out.length), count("depth", depth)],
                legend: LEG,
                happened: jumped ? `Node ${v} owns a child chain, so depth-first order continues there.` : "This node has no child, so the chain simply advances.",
                why: "The remaining siblings are remembered on the stack while the child is explored.",
                codeLine: jumped ? 7 : 12,
              });
              if (kids) visit(kids, depth + 1);
              if (jumped) {
                stack.pop();
                steps.push({
                  title: `Child of ${v} finished; resume after ${v}`,
                  tracks: [
                    chips("output", out, (i) => (i >= out.length - 3 ? "done" : "dim")),
                    chips("stack", stack.length ? stack : ["—"], "dim"),
                  ],
                  counters: [count("visited", out.length), count("depth", depth)],
                  legend: LEG,
                  happened: `The saved continuation follows the end of the child chain.`,
                  why: "Popping the stack restores the exact place the dive interrupted.",
                  codeLine: 14,
                });
              }
            }
          };
          visit(main, 0);
          steps.push({
            title: `Answer: ${show(out)}`,
            ...chain("list", out, fill(out.length, "result")),
            counters: [count("visited", out.length), count("answer", show(out))],
            legend: LEG,
            happened: `All ${out.length} nodes form one flat chain.`,
            why: "Every node was visited once and every child pointer was cleared.",
            codeLine: 22,
          });
          return steps;
        },
      },
    ],
  });
})();
