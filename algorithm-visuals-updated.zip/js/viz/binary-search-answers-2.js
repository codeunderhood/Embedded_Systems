/* ============================================================
   DSA Visuals — Binary Search Answers II
   "Binary search on the answer": the search space is a range of
   possible results, not positions. Each guess is checked by a
   greedy scan.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => `[${a.join(", ")}]`;

  /* Shared driver: lo..hi is the range of candidate answers.
     trial(mid) returns { ok, step }. On ok the answer can only be
     mid or smaller, so hi = mid; otherwise lo = mid + 1. */
  function answerSearch({ lo, hi, trial }) {
    const steps = [];
    let trials = 0;
    while (lo < hi) {
      const mid = lo + Math.floor((hi - lo) / 2);
      const r = trial(mid);
      trials++;
      steps.push(r.step);
      if (r.ok) hi = mid;
      else lo = mid + 1;
    }
    return { steps, answer: lo, trials };
  }

  /* ---------------------------------------------------------- */
  V.register({
    id: "koko-eating-bananas",
    title: "Koko Eating Bananas",
    category: "Binary Search",
    difficulty: "Intermediate",
    description:
      "Find the slowest eating speed that still clears every pile within the allowed hours.",
    input: {
      label: "row 1 = pile sizes, row 2 = hours",
      default: "3, 6, 7, 11 | 8",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Binary Search the Speed",
        complexity: "O(n log max) time, O(1) space",
        idea: [
          "A speed of 1 is always too slow eventually, and a speed equal to the largest pile clears one pile per hour, which is enough for any valid schedule.",
          "For a guessed speed, the hours needed are the sum of pile ÷ speed rounded up. That test shrinks with the speed, so binary search finds the smallest speed that fits.",
        ],
        problem: [
          "Each guess costs a full scan of the piles, so the total is n times log of the largest pile, not just log.",
        ],
        code: {
          c: `#include <stdio.h>\n\nlong hours_needed(const int *p, int n, int speed) {\n    long total = 0;\n    for (int i = 0; i < n; i++)\n        total += (p[i] + speed - 1) / speed;  /* ceiling division */\n    return total;\n}\n\nint min_speed(const int *p, int n, int h) {\n    int lo = 1, hi = 0;\n    for (int i = 0; i < n; i++) if (p[i] > hi) hi = p[i];\n    while (lo < hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (hours_needed(p, n, mid) <= h) hi = mid;\n        else lo = mid + 1;\n    }\n    return lo;\n}\n\nint main(void) {\n    int p[] = {3, 6, 7, 11};\n    printf(\"%d\\\\n\", min_speed(p, 4, 8)); /* 4 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nlong long hoursNeeded(const vector<int>& piles, int speed) {\n    long long total = 0;\n    for (int p : piles) total += (p + speed - 1) / speed;\n    return total;\n}\n\nint minEatingSpeed(const vector<int>& piles, int h) {\n    int lo = 1, hi = *max_element(piles.begin(), piles.end());\n    while (lo < hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (hoursNeeded(piles, mid) <= h) hi = mid;\n        else lo = mid + 1;\n    }\n    return lo;\n}\n\nint main() {\n    cout << minEatingSpeed({3, 6, 7, 11}, 8) << '\\\\n'; // 4\n}`,
        },
        steps(rows) {
          const piles = rows[0] || [];
          const hours = (rows[1] || [])[0];
          if (!piles.length || !hours) {
            return [{
              title: "Give pile sizes and an hour limit",
              tracks: [track("piles", piles.length ? piles : ["—"], fill(Math.max(1, piles.length), "idle"))],
              counters: [count("piles", piles.length)],
              legend: ["idle", "bad", "result"],
              happened: "The first row holds the piles, the second row the allowed hours.",
              why: "The answer is a speed, bounded between 1 and the largest pile.",
            }];
          }
          const steps = [];
          const maxPile = Math.max(...piles);
          const cost = (speed) => piles.reduce((s, p) => s + Math.ceil(p / speed), 0);
          steps.push({
            title: `Search speeds 1..${maxPile}; ${hours} hours available`,
            tracks: [
              track("piles", piles, fill(piles.length, "idle")),
              chips("range", [`1..${maxPile}`], "read"),
              chips("hours at speed 1", [cost(1)], "bad"),
            ],
            counters: [count("range", `${1}..${maxPile}`), count("trials", 0)],
            legend: LEG,
            happened: `At one banana per hour the piles need ${cost(1)} hours, which is ${cost(1) > hours ? "too slow" : "already enough"}.`,
            why: "Hours only fall as speed rises, so the feasible speeds form a suffix.",
            codeLine: 12,
          });
          const out = answerSearch({
            lo: 1,
            hi: maxPile,
            trial(speed) {
              const need = cost(speed);
              const ok = need <= hours;
              return {
                ok,
                step: {
                  title: `Speed ${speed}: ${need} hour${need === 1 ? "" : "s"} ${ok ? "≤" : ">"} ${hours}`,
                  tracks: [
                    track("piles", piles, piles.map((p) => (Math.ceil(p / speed) === 1 ? "done" : "read"))),
                    chips("hours per pile", piles.map((p) => `${p}→${Math.ceil(p / speed)}`), "dim"),
                    chips("total hours", [need], ok ? "good" : "bad"),
                    chips("range", [`${speed}${ok ? ".." : "?"}`], "compare"),
                  ],
                  counters: [count("trial speed", speed), count("hours", need)],
                  legend: LEG,
                  happened: ok
                    ? `Speed ${speed} clears every pile inside ${hours} hours, so a slower speed might also work.`
                    : `Speed ${speed} needs ${need} hours, so it is too slow and must be raised.`,
                  why: ok
                    ? "The answer can only be this speed or lower, so the high end moves here."
                    : "All speeds at or below this one fail, so the low end moves above it.",
                  codeLine: ok ? 16 : 17,
                },
              };
            },
          });
          steps.push(...out.steps);
          steps.push({
            title: `Answer: eat ${out.answer} banana${out.answer === 1 ? "" : "s"} per hour`,
            tracks: [
              track("piles", piles, fill(piles.length, "done")),
              chips("hours used", [cost(out.answer)], "result"),
              chips("answer", [out.answer], "result"),
            ],
            counters: [count("trials", out.trials), count("answer", out.answer)],
            legend: LEG,
            happened: `At speed ${out.answer} the piles need ${cost(out.answer)} hours, which fits in ${hours}; one speed slower does not.`,
            why: "Binary search over a monotone feasibility test gives the minimum valid speed.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "capacity-to-ship-packages",
    title: "Capacity to Ship Packages",
    category: "Binary Search",
    difficulty: "Intermediate",
    description:
      "Find the smallest daily ship capacity that delivers every package within the allowed days, in order.",
    input: {
      label: "row 1 = weights, row 2 = days",
      default: "1, 2, 3, 4, 5, 6, 7, 8, 9, 10 | 5",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Search the Capacity",
        complexity: "O(n log sum) time, O(1) space",
        idea: [
          "The capacity must be at least the heaviest package and at most the total weight. Within that range, a larger capacity never needs more days.",
          "For a guessed capacity, fill each day greedily until the next package would overflow, then start a new day. If the day count fits, try a smaller capacity.",
        ],
        problem: [
          "The greedy day count is optimal only because packages must be shipped in order; reordering would change the problem.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint days_needed(const int *w, int n, int cap) {\n    int days = 1, load = 0;\n    for (int i = 0; i < n; i++) {\n        if (load + w[i] > cap) { days++; load = 0; }\n        load += w[i];\n    }\n    return days;\n}\n\nint ship_within_days(const int *w, int n, int days) {\n    int lo = 0, hi = 0;\n    for (int i = 0; i < n; i++) {\n        if (w[i] > lo) lo = w[i];\n        hi += w[i];\n    }\n    while (lo < hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (days_needed(w, n, mid) <= days) hi = mid;\n        else lo = mid + 1;\n    }\n    return lo;\n}\n\nint main(void) {\n    int w[] = {1,2,3,4,5,6,7,8,9,10};\n    printf(\"%d\\\\n\", ship_within_days(w, 10, 5)); /* 15 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <numeric>\nusing namespace std;\n\nint daysNeeded(const vector<int>& w, int cap) {\n    int days = 1, load = 0;\n    for (int x : w) {\n        if (load + x > cap) { days++; load = 0; }\n        load += x;\n    }\n    return days;\n}\n\nint shipWithinDays(const vector<int>& w, int days) {\n    int lo = *max_element(w.begin(), w.end());\n    int hi = accumulate(w.begin(), w.end(), 0);\n    while (lo < hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (daysNeeded(w, mid) <= days) hi = mid;\n        else lo = mid + 1;\n    }\n    return lo;\n}\n\nint main() {\n    cout << shipWithinDays({1,2,3,4,5,6,7,8,9,10}, 5) << '\\\\n'; // 15\n}`,
        },
        steps(rows) {
          const w = rows[0] || [];
          const days = (rows[1] || [])[0];
          if (!w.length || !days) {
            return [{
              title: "Give weights and a day limit",
              tracks: [track("weights", w.length ? w : ["—"], fill(Math.max(1, w.length), "idle"))],
              counters: [count("packages", w.length)],
              legend: ["idle", "bad", "result"],
              happened: "The first row holds the package weights, the second the available days.",
              why: "Capacity lies between the heaviest package and the total weight.",
            }];
          }
          const steps = [];
          const maxW = Math.max(...w);
          const total = w.reduce((s, v) => s + v, 0);
          const daysAt = (cap) => {
            let d = 1, load = 0;
            for (const v of w) {
              if (load + v > cap) { d++; load = 0; }
              load += v;
            }
            return d;
          };
          steps.push({
            title: `Capacity between ${maxW} (heaviest) and ${total} (total weight)`,
            tracks: [
              track("weights", w, fill(w.length, "idle")),
              chips("range", [`${maxW}..${total}`], "read"),
              chips("days at full capacity", [daysAt(total)], "done"),
            ],
            counters: [count("range", `${maxW}..${total}`), count("trials", 0)],
            legend: LEG,
            happened: `The heaviest package needs ${maxW} units of space; carrying everything at once needs ${total}.`,
            why: "Any capacity below the heaviest package is impossible, and the total is always enough.",
            codeLine: 12,
          });
          const out = answerSearch({
            lo: maxW,
            hi: total,
            trial(cap) {
              const d = daysAt(cap);
              const ok = d <= days;
              return {
                ok,
                step: {
                  title: `Capacity ${cap}: ${d} day${d === 1 ? "" : "s"} ${ok ? "≤" : ">"} ${days}`,
                  tracks: [
                    track("weights", w, w.map((v) => (v > cap ? "bad" : "read"))),
                    chips("days packed", [d], ok ? "good" : "bad"),
                  ],
                  counters: [count("trial capacity", cap), count("days", d)],
                  legend: LEG,
                  happened: ok
                    ? `Packing greedily fits in ${days} days, so a smaller capacity may still work.`
                    : `Packing needs ${d} days, so the capacity must grow.`,
                  why: "A bigger capacity can only reduce the day count, which is why binary search applies.",
                  codeLine: ok ? 18 : 19,
                },
              };
            },
          });
          steps.push(...out.steps);
          steps.push({
            title: `Answer: capacity ${out.answer}`,
            tracks: [
              track("weights", w, fill(w.length, "done")),
              chips("days used", [daysAt(out.answer)], "result"),
              chips("answer", [out.answer], "result"),
            ],
            counters: [count("trials", out.trials), count("answer", out.answer)],
            legend: LEG,
            happened: `A capacity of ${out.answer} ships everything in ${daysAt(out.answer)} days, and ${out.answer - 1} would need ${daysAt(out.answer - 1)}.`,
            why: "The smallest feasible capacity is the first value where the day count drops under the limit.",
            codeLine: 21,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "split-array-largest-sum",
    title: "Split Array Largest Sum",
    category: "Binary Search",
    difficulty: "Advanced",
    description:
      "Split the row into a fixed number of contiguous parts so the largest part sum is as small as possible.",
    input: {
      label: "row 1 = numbers, row 2 = k parts",
      default: "7, 2, 5, 10, 8 | 2",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Search the Largest Allowed Part",
        complexity: "O(n log sum) time, O(1) space",
        idea: [
          "Guess a limit for a part sum. Greedily pack numbers until the next one would exceed the limit, then start a new part.",
          "If the number of parts needed is at most k, the limit is feasible. Binary search the smallest feasible limit.",
        ],
        problem: [
          "Greedy packing is only optimal for contiguous parts; allowing arbitrary subsets would need a different method.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint parts_needed(const int *a, int n, int limit) {\n    int parts = 1, sum = 0;\n    for (int i = 0; i < n; i++) {\n        if (sum + a[i] > limit) { parts++; sum = 0; }\n        sum += a[i];\n    }\n    return parts;\n}\n\nint split_array(const int *a, int n, int k) {\n    int lo = 0, hi = 0;\n    for (int i = 0; i < n; i++) {\n        if (a[i] > lo) lo = a[i];\n        hi += a[i];\n    }\n    while (lo < hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (parts_needed(a, n, mid) <= k) hi = mid;\n        else lo = mid + 1;\n    }\n    return lo;\n}\n\nint main(void) {\n    int a[] = {7, 2, 5, 10, 8};\n    printf(\"%d\\\\n\", split_array(a, 5, 2)); /* 18 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <numeric>\nusing namespace std;\n\nint partsNeeded(const vector<int>& a, int limit) {\n    int parts = 1, sum = 0;\n    for (int v : a) {\n        if (sum + v > limit) { parts++; sum = 0; }\n        sum += v;\n    }\n    return parts;\n}\n\nint splitArray(const vector<int>& a, int k) {\n    int lo = *max_element(a.begin(), a.end());\n    int hi = accumulate(a.begin(), a.end(), 0);\n    while (lo < hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (partsNeeded(a, mid) <= k) hi = mid;\n        else lo = mid + 1;\n    }\n    return lo;\n}\n\nint main() {\n    cout << splitArray({7,2,5,10,8}, 2) << '\\\\n'; // 18\n}`,
        },
        steps(rows) {
          const a = rows[0] || [];
          const k = (rows[1] || [])[0];
          if (!a.length || !k) {
            return [{
              title: "Give numbers and a part count",
              tracks: [track("numbers", a.length ? a : ["—"], fill(Math.max(1, a.length), "idle"))],
              counters: [count("parts", k || 0)],
              legend: ["idle", "bad", "result"],
              happened: "The first row is the data, the second row is k.",
              why: "A part sum must be at least the largest single number.",
            }];
          }
          const steps = [];
          const maxV = Math.max(...a);
          const total = a.reduce((s, v) => s + v, 0);
          const partsAt = (limit) => {
            let parts = 1, sum = 0;
            for (const v of a) {
              if (sum + v > limit) { parts++; sum = 0; }
              sum += v;
            }
            return parts;
          };
          steps.push({
            title: `Limit between ${maxV} and ${total}, at most ${k} part${k === 1 ? "" : "s"}`,
            tracks: [
              track("numbers", a, fill(a.length, "idle")),
              chips("range", [`${maxV}..${total}`], "read"),
            ],
            counters: [count("range", `${maxV}..${total}`), count("trials", 0)],
            legend: LEG,
            happened: `No part can be smaller than ${maxV}, and one part holding everything sums to ${total}.`,
            why: "Packing greedily under a limit gives the fewest parts for that limit.",
            codeLine: 12,
          });
          const out = answerSearch({
            lo: maxV,
            hi: total,
            trial(limit) {
              const parts = partsAt(limit);
              const ok = parts <= k;
              return {
                ok,
                step: {
                  title: `Limit ${limit}: greedy uses ${parts} part${parts === 1 ? "" : "s"} ${ok ? "≤" : ">"} ${k}`,
                  tracks: [
                    track("numbers", a, a.map((v) => (v > limit ? "bad" : "read"))),
                    chips("parts counted", [parts], ok ? "good" : "bad"),
                  ],
                  counters: [count("trial limit", limit), count("parts", parts)],
                  legend: LEG,
                  happened: ok
                    ? `The row fits in ${k} parts at this limit, so a tighter limit may work.`
                    : `Greedy needs ${parts} parts, so the limit must rise.`,
                  why: "The part count falls as the limit rises, which makes the test monotone.",
                  codeLine: ok ? 18 : 19,
                },
              };
            },
          });
          steps.push(...out.steps);
          steps.push({
            title: `Answer: largest part is ${out.answer}`,
            tracks: [
              track("numbers", a, fill(a.length, "done")),
              chips("parts at answer", [partsAt(out.answer)], "result"),
              chips("answer", [out.answer], "result"),
            ],
            counters: [count("trials", out.trials), count("answer", out.answer)],
            legend: LEG,
            happened: `With a limit of ${out.answer} the row splits into ${partsAt(out.answer)} part${partsAt(out.answer) === 1 ? "" : "s"}, and a limit of ${out.answer - 1} needs ${partsAt(out.answer - 1)}.`,
            why: "The smallest feasible limit is exactly the minimised largest part sum.",
            codeLine: 21,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "aggressive-cows",
    title: "Aggressive Cows",
    category: "Binary Search",
    difficulty: "Advanced",
    description:
      "Place a fixed number of cows in stalls so that the closest pair is as far apart as possible.",
    input: {
      label: "row 1 = stall positions, row 2 = cows",
      default: "1, 2, 4, 8, 9 | 3",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Search the Minimum Gap",
        complexity: "O(n log span) time, O(1) space",
        idea: [
          "Guess a minimum distance and place cows greedily: always take the next stall that is far enough from the last occupied one.",
          "If all cows fit, that distance is possible, so try larger. Binary search the largest feasible distance.",
        ],
        problem: [
          "The stalls must be sorted first, and the greedy placement only maximises the minimum gap — not the sum of gaps.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\nstatic int cmp(const void *a, const void *b) {\n    return *(const int *)a - *(const int *)b;\n}\n\nint can_place(const int *stalls, int n, int cows, int gap) {\n    int placed = 1, last = stalls[0];\n    for (int i = 1; i < n; i++)\n        if (stalls[i] - last >= gap) { placed++; last = stalls[i]; }\n    return placed >= cows;\n}\n\nint max_min_gap(const int *stalls, int n, int cows) {\n    int lo = 1, hi = stalls[n - 1] - stalls[0];\n    while (lo < hi) {\n        int mid = lo + (hi - lo + 1) / 2;      /* round up */\n        if (can_place(stalls, n, cows, mid)) lo = mid;\n        else hi = mid - 1;\n    }\n    return lo;\n}\n\nint main(void) {\n    int s[] = {1, 2, 4, 8, 9};\n    printf(\"%d\\\\n\", max_min_gap(s, 5, 3)); /* 3 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <algorithm>\nusing namespace std;\n\nbool canPlace(const vector<int>& s, int cows, int gap) {\n    int placed = 1, last = s[0];\n    for (size_t i = 1; i < s.size(); i++)\n        if (s[i] - last >= gap) { placed++; last = s[i]; }\n    return placed >= cows;\n}\n\nint maxMinGap(vector<int> s, int cows) {\n    sort(s.begin(), s.end());\n    int lo = 1, hi = s.back() - s.front();\n    while (lo < hi) {\n        int mid = lo + (hi - lo + 1) / 2;\n        if (canPlace(s, cows, mid)) lo = mid;\n        else hi = mid - 1;\n    }\n    return lo;\n}\n\nint main() {\n    cout << maxMinGap({1, 2, 4, 8, 9}, 3) << '\\\\n'; // 3\n}`,
        },
        steps(rows) {
          const stalls = (rows[0] || []).slice().sort((x, y) => x - y);
          const cows = (rows[1] || [])[0];
          if (stalls.length < 2 || !cows) {
            return [{
              title: "Give stall positions and a cow count",
              tracks: [track("stalls", stalls.length ? stalls : ["—"], fill(Math.max(1, stalls.length), "idle"))],
              counters: [count("cows", cows || 0)],
              legend: ["idle", "bad", "result"],
              happened: "The first row holds the stalls, the second the number of cows.",
              why: "At least two stalls are needed to measure a gap.",
            }];
          }
          const steps = [];
          const span = stalls[stalls.length - 1] - stalls[0];
          const placedAt = (gap) => {
            const picked = [stalls[0]];
            for (let i = 1; i < stalls.length; i++) if (stalls[i] - picked[picked.length - 1] >= gap) picked.push(stalls[i]);
            return picked;
          };
          steps.push({
            title: `${stalls.length} stalls span ${span} units; place ${cows} cows`,
            tracks: [
              track("stalls", stalls, fill(stalls.length, "idle")),
              chips("gap range", [`1..${span}`], "read"),
            ],
            counters: [count("range", `1..${span}`), count("cows", cows)],
            legend: LEG,
            happened: `Sorted stalls are ${show(stalls)}.`,
            why: "The closest pair can never be further apart than the whole span.",
            codeLine: 14,
          });
          // upward binary search: keep the largest feasible gap
          let lo = 1, hi = span, trials = 0;
          while (lo < hi) {
            const mid = lo + Math.ceil((hi - lo) / 2);
            const picked = placedAt(mid);
            const ok = picked.length >= cows;
            trials++;
            steps.push({
              title: `Gap ${mid}: ${picked.length} cow${picked.length === 1 ? "" : "s"} fit ${ok ? "≥" : "<"} ${cows}`,
              tracks: [
                track("stalls", stalls, stalls.map((v) => (picked.includes(v) ? "done" : "dim"))),
                chips("picked stalls", picked.length ? picked : ["none"], ok ? "good" : "bad"),
              ],
              counters: [count("trial gap", mid), count("cows placed", picked.length)],
              legend: LEG,
              happened: ok
                ? `All ${cows} cows fit with a gap of ${mid}, so a larger gap is worth trying.`
                : `Only ${picked.length} cow${picked.length === 1 ? "" : "s"} fit, so the gap must shrink.`,
              why: "Greedy placement is optimal for checking a fixed minimum gap.",
              codeLine: ok ? 8 : 9,
            });
            if (ok) lo = mid;
            else hi = mid - 1;
          }
          const finalPick = placedAt(lo);
          steps.push({
            title: `Answer: minimum gap ${lo}`,
            tracks: [
              track("stalls", stalls, stalls.map((v) => (finalPick.includes(v) ? "result" : "dim"))),
              chips("chosen stalls", finalPick, "result"),
              chips("answer", [lo], "result"),
            ],
            counters: [count("trials", trials), count("answer", lo)],
            legend: LEG,
            happened: `The cows can stand ${lo} units apart at best, for example on ${finalPick.join(", ")}.`,
            why: "The upward search keeps the largest gap that still fits every cow.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "allocate-minimum-number-of-pages",
    title: "Allocate Minimum Number of Pages",
    category: "Binary Search",
    difficulty: "Advanced",
    description:
      "Assign books to students so the student with the most pages gets as few as possible.",
    input: {
      label: "row 1 = page counts, row 2 = students",
      default: "12, 34, 67, 90 | 2",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Search the Page Limit",
        complexity: "O(n log sum) time, O(1) space",
        idea: [
          "Books must stay in order, so each student receives a contiguous block. Guess a maximum number of pages per student and assign greedily.",
          "If the blocks fit within the student count, the limit is feasible; binary search the smallest feasible limit.",
        ],
        problem: [
          "If there are more students than books, some student must receive nothing, so the problem needs a guard clause.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint students_needed(const int *b, int n, int limit) {\n    int students = 1, pages = 0;\n    for (int i = 0; i < n; i++) {\n        if (pages + b[i] > limit) { students++; pages = 0; }\n        pages += b[i];\n    }\n    return students;\n}\n\nint allocate(const int *b, int n, int students) {\n    if (n < students) return -1;\n    int lo = 0, hi = 0;\n    for (int i = 0; i < n; i++) {\n        if (b[i] > lo) lo = b[i];\n        hi += b[i];\n    }\n    while (lo < hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (students_needed(b, n, mid) <= students) hi = mid;\n        else lo = mid + 1;\n    }\n    return lo;\n}\n\nint main(void) {\n    int b[] = {12, 34, 67, 90};\n    printf(\"%d\\\\n\", allocate(b, 4, 2)); /* 113 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <numeric>\nusing namespace std;\n\nint studentsNeeded(const vector<int>& b, int limit) {\n    int students = 1, pages = 0;\n    for (int v : b) {\n        if (pages + v > limit) { students++; pages = 0; }\n        pages += v;\n    }\n    return students;\n}\n\nint allocate(const vector<int>& b, int students) {\n    if ((int)b.size() < students) return -1;\n    int lo = *max_element(b.begin(), b.end());\n    int hi = accumulate(b.begin(), b.end(), 0);\n    while (lo < hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (studentsNeeded(b, mid) <= students) hi = mid;\n        else lo = mid + 1;\n    }\n    return lo;\n}\n\nint main() {\n    cout << allocate({12, 34, 67, 90}, 2) << '\\\\n'; // 113\n}`,
        },
        steps(rows) {
          const b = rows[0] || [];
          const students = (rows[1] || [])[0];
          if (!b.length || !students) {
            return [{
              title: "Give page counts and a student count",
              tracks: [track("books", b.length ? b : ["—"], fill(Math.max(1, b.length), "idle"))],
              counters: [count("students", students || 0)],
              legend: ["idle", "bad", "result"],
              happened: "The first row is the books in order, the second the students.",
              why: "Each book goes to exactly one student and blocks stay contiguous.",
            }];
          }
          const steps = [];
          if (b.length < students) {
            steps.push({
              title: "More students than books: impossible",
              tracks: [track("books", b, fill(b.length, "bad")), chips("students", [students], "bad")],
              counters: [count("books", b.length), count("students", students)],
              legend: LEG,
              happened: "There are not enough books to give every student one.",
              why: "The guard clause returns -1 before any searching.",
              codeLine: 12,
            });
            return steps;
          }
          const maxP = Math.max(...b);
          const total = b.reduce((s, v) => s + v, 0);
          const studentsAt = (limit) => {
            let s = 1, pages = 0;
            for (const v of b) {
              if (pages + v > limit) { s++; pages = 0; }
              pages += v;
            }
            return s;
          };
          steps.push({
            title: `Limit between ${maxP} and ${total}`,
            tracks: [
              track("books", b, fill(b.length, "idle")),
              chips("range", [`${maxP}..${total}`], "read"),
            ],
            counters: [count("range", `${maxP}..${total}`), count("students", students)],
            legend: LEG,
            happened: `A student must hold the largest book (${maxP} pages), and the total is ${total}.`,
            why: "The answer is the smallest page limit that needs no more than the given students.",
            codeLine: 16,
          });
          const out = answerSearch({
            lo: maxP,
            hi: total,
            trial(limit) {
              const need = studentsAt(limit);
              const ok = need <= students;
              return {
                ok,
                step: {
                  title: `Limit ${limit}: ${need} student${need === 1 ? "" : "s"} ${ok ? "≤" : ">"} ${students}`,
                  tracks: [
                    track("books", b, b.map((v) => (v > limit ? "bad" : "read"))),
                    chips("students needed", [need], ok ? "good" : "bad"),
                  ],
                  counters: [count("trial limit", limit), count("students", need)],
                  legend: LEG,
                  happened: ok
                    ? `The books fit into ${students} students at this limit, so a smaller limit may work.`
                    : `The limit forces ${need} students, so it must rise.`,
                  why: "Fewer students are needed as the limit grows, so the test is monotone.",
                  codeLine: ok ? 22 : 23,
                },
              };
            },
          });
          steps.push(...out.steps);
          steps.push({
            title: `Answer: ${out.answer} pages for the busiest student`,
            tracks: [
              track("books", b, fill(b.length, "done")),
              chips("students needed", [studentsAt(out.answer)], "result"),
              chips("answer", [out.answer], "result"),
            ],
            counters: [count("trials", out.trials), count("answer", out.answer)],
            legend: LEG,
            happened: `A limit of ${out.answer} fits ${students} students, and ${out.answer - 1} needs ${studentsAt(out.answer - 1)}.`,
            why: "The first feasible limit is the minimised maximum load.",
            codeLine: 25,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "kth-smallest-pair-distance",
    title: "Kth Smallest Pair Distance",
    category: "Binary Search",
    difficulty: "Advanced",
    description:
      "Sort the row, then binary search the distance value while counting pairs no further apart than it.",
    input: {
      label: "row 1 = numbers, row 2 = k",
      default: "1, 3, 1 | 1",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Count Pairs Under a Distance",
        complexity: "O(n log n + n log span) time",
        idea: [
          "After sorting, the number of pairs with distance at most d can be counted with two pointers in linear time.",
          "That count never decreases as d grows, so binary search the smallest d whose count reaches k.",
        ],
        problem: [
          "The binary search is over distances, so the runtime includes the span of values, not just the number of pairs.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\nstatic int cmp(const void *a, const void *b) {\n    return *(const int *)a - *(const int *)b;\n}\n\nlong pairs_within(const int *a, int n, int d) {\n    long total = 0;\n    int lo = 0;\n    for (int hi = 0; hi < n; hi++) {\n        while (a[hi] - a[lo] > d) lo++;\n        total += hi - lo;\n    }\n    return total;\n}\n\nint kth_distance(int *a, int n, int k) {\n    qsort(a, n, sizeof(int), cmp);\n    int lo = 0, hi = a[n - 1] - a[0];\n    while (lo < hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (pairs_within(a, n, mid) >= k) hi = mid;\n        else lo = mid + 1;\n    }\n    return lo;\n}\n\nint main(void) {\n    int a[] = {1, 3, 1};\n    printf(\"%d\\\\n\", kth_distance(a, 3, 1)); /* 0 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <algorithm>\nusing namespace std;\n\nlong long pairsWithin(const vector<int>& a, int d) {\n    long long total = 0;\n    int lo = 0;\n    for (int hi = 0; hi < (int)a.size(); hi++) {\n        while (a[hi] - a[lo] > d) lo++;\n        total += hi - lo;\n    }\n    return total;\n}\n\nint smallestDistancePair(vector<int> a, int k) {\n    sort(a.begin(), a.end());\n    int lo = 0, hi = a.back() - a.front();\n    while (lo < hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (pairsWithin(a, mid) >= k) hi = mid;\n        else lo = mid + 1;\n    }\n    return lo;\n}\n\nint main() {\n    cout << smallestDistancePair({1, 3, 1}, 1) << '\\\\n'; // 0\n}`,
        },
        steps(rows) {
          const a = (rows[0] || []).slice().sort((x, y) => x - y);
          const k = Math.max(1, (rows[1] || [])[0] | 0);
          const n = a.length;
          if (n < 2) {
            return [{
              title: "Two values are needed for a pair",
              tracks: [track("numbers", n ? a : ["—"], fill(Math.max(1, n), "idle"))],
              counters: [count("k", k)],
              legend: ["idle", "bad", "result"],
              happened: "A pair distance needs two numbers.",
              why: "The search range starts at zero, since equal values give distance zero.",
            }];
          }
          const steps = [];
          const span = a[n - 1] - a[0];
          const pairsWithin = (d) => {
            let total = 0, lo = 0;
            for (let hi = 0; hi < n; hi++) {
              while (a[hi] - a[lo] > d) lo++;
              total += hi - lo;
            }
            return total;
          };
          steps.push({
            title: `${n} values sorted; distances range 0..${span}`,
            tracks: [
              track("numbers", a, fill(n, "idle")),
              chips("range", [`0..${span}`], "read"),
            ],
            counters: [count("k", k), count("pairs", n * (n - 1) / 2)],
            legend: LEG,
            happened: `Sorted values ${show(a)} make nearby pairs contiguous.`,
            why: "Counting pairs at or below a distance is easy with two pointers once the row is sorted.",
            codeLine: 14,
          });
          const out = answerSearch({
            lo: 0,
            hi: span,
            trial(d) {
              const c = pairsWithin(d);
              const ok = c >= k;
              return {
                ok,
                step: {
                  title: `Distance ${d}: ${c} pair${c === 1 ? "" : "s"} ${ok ? "≥" : "<"} k = ${k}`,
                  tracks: [
                    track("numbers", a, a.map((v, i) => (i > 0 && v - a[0] <= d ? "read" : "idle"))),
                    chips("pairs at most", [c], ok ? "good" : "bad"),
                  ],
                  counters: [count("trial distance", d), count("pairs counted", c)],
                  legend: LEG,
                  happened: ok
                    ? `At least ${k} pairs are this close, so the kth distance may be smaller.`
                    : `Fewer than ${k} pairs are this close, so the distance must grow.`,
                  why: "The pair count is monotone in the distance, which is what permits binary search.",
                  codeLine: ok ? 18 : 19,
                },
              };
            },
          });
          steps.push(...out.steps);
          steps.push({
            title: `Answer: the ${k}${k === 1 ? "st" : k === 2 ? "nd" : k === 3 ? "rd" : "th"} smallest distance is ${out.answer}`,
            tracks: [
              track("numbers", a, fill(n, "done")),
              chips("pairs at most", [pairsWithin(out.answer)], "result"),
              chips("answer", [out.answer], "result"),
            ],
            counters: [count("trials", out.trials), count("answer", out.answer)],
            legend: LEG,
            happened: `Exactly ${pairsWithin(out.answer)} pairs are within ${out.answer}, and one fewer distance would not reach k.`,
            why: "Binary searching the value instead of the index is the key idea.",
            codeLine: 21,
          });
          return steps;
        },
      },
    ],
  });
})();
