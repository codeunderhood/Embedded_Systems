/* ============================================================
   DSA Visuals — Trees I
   Level-order walks, boundary and vertical views, plus path
   searches. Input is level-order with "null" for a missing
   child, exactly like the tree basics set.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, binaryTree } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];

  /* one input token -> node value (null means a missing child) */
  function toVal(t) {
    if (t == null) return null;
    const s = String(t).trim();
    if (!s || s.toLowerCase() === "null" || s === "-") return null;
    const n = Number(s);
    return Number.isFinite(n) ? n : s;
  }
  const toVals = (tokens) => (tokens || []).map(toVal);
  function sideVals(text) {
    return String(text || "").split(/[\s,;]+/).filter(Boolean).map(toVal);
  }
  function bfsList(root) {
    const out = [];
    for (const q = root ? [root] : []; q.length;) {
      const n = q.shift();
      out.push(n);
      if (n.l) q.push(n.l);
      if (n.r) q.push(n.r);
    }
    return out;
  }
  const isLeaf = (n) => n && !n.l && !n.r;
  const show = (a) => `[${a.join(", ")}]`;
  const empty = (title, happened, why) => [{
    title,
    kind: "cells",
    tracks: [{ label: "tree", cells: [{ v: "∅", state: "idle", empty: true }] }],
    counters: [count("nodes", 0)],
    legend: LEG,
    happened,
    why,
  }];
  const mark = (base, ids, state) => {
    const m = Object.assign({}, base || {});
    ids.forEach((id) => { if (id != null) m[id] = state; });
    return m;
  };

  /* ---------------------------------------------------------- */
  V.register({
    id: "binary-tree-level-order-traversal",
    title: "Binary Tree Level Order Traversal",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Read the tree row by row: the root first, then its children, then their children.",
    input: { label: "Tree (level order, null = gap)", default: "3, 9, 20, null, null, 15, 7", parse: "tokens" },
    approaches: [
      {
        name: "Queue of Nodes",
        complexity: "O(n) time, O(w) queue space",
        idea: [
          "Keep a queue that starts with the root. Taking a node from the front gives the current level's nodes in order.",
          "While draining one level, append each node's children to the next queue. A snapshot of the queue size at the start of the round tells exactly how many nodes belong to this level.",
        ],
        problem: [
          "Without the per-level size snapshot, children from the next level mix into the current output.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };

void levels(struct node *root) {
    if (root == NULL) return;
    struct node *q[64];
    int head = 0, tail = 0;
    q[tail++] = root;

    while (head < tail) {
        int end = tail;              /* nodes queued so far = one level */
        for (; head < end; head++) {
            struct node *n = q[head];
            printf("%d ", n->v);
            if (n->l) q[tail++] = n->l;
            if (n->r) q[tail++] = n->r;
        }
        printf("\\n");
    }
}

int main(void) {
    struct node n4 = {15, NULL, NULL}, n5 = {7, NULL, NULL};
    struct node n3 = {20, &n4, &n5}, n2 = {9, NULL, NULL};
    struct node root = {3, &n2, &n3};
    levels(&root); /* 3 / 9 20 / 15 7 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <queue>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };

void levels(Node* root) {
    if (!root) return;
    queue<Node*> q;
    q.push(root);

    while (!q.empty()) {
        int size = (int)q.size();    // exactly this level
        while (size--) {
            Node* n = q.front(); q.pop();
            cout << n->v << ' ';
            if (n->l) q.push(n->l);
            if (n->r) q.push(n->r);
        }
        cout << '\\n';
    }
}

int main() {
    Node n4{15}, n5{7}, n3{20}, n2{9};
    n3.l = &n4; n3.r = &n5;
    Node root{3}; root.l = &n2; root.r = &n3;
    levels(&root); // 3 / 9 20 / 15 7
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root) return empty("Empty tree — no levels", "The queue never receives a node.", "Level order of an empty tree is an empty list.");
          const total = bfsList(root).length;
          const steps = [];
          const levels = [];
          const done = new Set();
          let q = [root], level = 0;
          let base = { [root.id]: "read" };
          steps.push({
            title: `Root ${root.v} enters the queue`,
            kind: "tree", tree: root, nodeStates: base,
            label: `queue: ${root.v}`,
            counters: [count("level", 0), count("visited", 0, total)],
            legend: LEG,
            happened: "The queue holds exactly one node, so the first level has one node.",
            why: "Breadth-first search expands nodes in the order they were discovered.",
            codeLine: 7,
          });
          while (q.length) {
            const current = q.slice();
            const vals = current.map((n) => n.v);
            const next = [];
            const drainStates = mark(base, current.map((n) => n.id), "read");
            steps.push({
              title: `Level ${level}: dequeue ${vals.join(", ")}`,
              kind: "tree", tree: root, nodeStates: drainStates,
              label: `queue size locked at ${current.length}`,
              counters: [count("level", level), count("visited", done.size, total)],
              legend: LEG,
              happened: `These ${current.length} node${current.length === 1 ? "" : "s"} are the whole of level ${level}.`,
              why: "The saved size prevents the children appended below from being read as part of this level.",
              codeLine: 9,
            });
            current.forEach((n) => {
              done.add(n.id);
              if (n.l) next.push(n.l);
              if (n.r) next.push(n.r);
            });
            levels.push(vals);
            q = next;
            const after = mark(base, [...done], "done");
            const queued = mark(after, next.map((n) => n.id), "active");
            base = after;
            steps.push({
              title: next.length ? `Level ${level} complete; ${next.length} child${next.length === 1 ? "" : "ren"} queued` : `Level ${level} is the last`,
              kind: "tree", tree: root, nodeStates: queued,
              label: `levels so far: ${levels.map((v) => "[" + v.join(",") + "]").join(" ")}`,
              counters: [count("levels", levels.length), count("visited", done.size, total)],
              legend: LEG,
              happened: next.length ? `Next up: ${next.map((n) => n.v).join(", ")}.` : "No node has an unvisited child, so the walk ends.",
              why: "Each level is finished before any child of that level is read.",
              codeLine: 13,
            });
            level++;
          }
          steps.push({
            title: `Answer: ${levels.map((v) => "[" + v.join(",") + "]").join(" ")}`,
            kind: "tree", tree: root, nodeStates: mark(base, bfsList(root).map((n) => n.id), "result"),
            label: `levels: ${levels.map((v) => "[" + v.join(",") + "]").join(" ")}`,
            counters: [count("levels", levels.length), count("visited", done.size, total)],
            legend: LEG,
            happened: `Every node appears exactly once, in non-decreasing depth order.`,
            why: "The queue's first-in-first-out order is what makes the output level by level.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "zigzag-level-order-traversal",
    title: "Zigzag Level Order Traversal",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Read levels alternately left-to-right and right-to-left while the tree is still walked top-down.",
    input: { label: "Tree (level order, null = gap)", default: "3, 9, 20, null, null, 15, 7", parse: "tokens" },
    approaches: [
      {
        name: "Level Order, Reverse the Odd Levels",
        complexity: "O(n) time, O(w) queue space",
        idea: [
          "Run an ordinary level-order walk and collect each level's nodes.",
          "Reverse the collected list when the level index is odd, then append it. Reversing after collection keeps the child discovery order unchanged.",
        ],
        problem: [
          "Reversing while enqueuing children would change the structure the next level sees, so the reversal must be purely presentational.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };

void zigzag(struct node *root) {
    if (root == NULL) return;
    struct node *q[64];
    int head = 0, tail = 0, level = 0;
    q[tail++] = root;

    while (head < tail) {
        int end = tail;
        int lo = head, hi = end - 1;
        int left_to_right = (level % 2 == 0);
        while (lo <= hi) {
            struct node *n = left_to_right ? q[lo++] : q[hi--];
            printf("%d ", n->v);
        }
        printf("\\n");
        for (int i = head; i < end; i++) {
            if (q[i]->l) q[tail++] = q[i]->l;
            if (q[i]->r) q[tail++] = q[i]->r;
        }
        head = end;
        level++;
    }
}

int main(void) {
    struct node n4 = {15, NULL, NULL}, n5 = {7, NULL, NULL};
    struct node n3 = {20, &n4, &n5}, n2 = {9, NULL, NULL};
    struct node root = {3, &n2, &n3};
    zigzag(&root); /* 3 / 20 9 / 15 7 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };

vector<vector<int>> zigzag(Node* root) {
    vector<vector<int>> out;
    if (!root) return out;
    queue<Node*> q;
    q.push(root);
    int level = 0;

    while (!q.empty()) {
        int size = (int)q.size();
        vector<int> row;
        while (size--) {
            Node* n = q.front(); q.pop();
            row.push_back(n->v);
            if (n->l) q.push(n->l);
            if (n->r) q.push(n->r);
        }
        if (level % 2) reverse(row.begin(), row.end());
        out.push_back(row);
        level++;
    }
    return out;
}

int main() {
    Node n4{15}, n5{7}, n3{20}, n2{9};
    n3.l = &n4; n3.r = &n5;
    Node root{3}; root.l = &n2; root.r = &n3;
    for (auto& row : zigzag(&root)) {
        for (int v : row) cout << v << ' ';
        cout << '\\n';
    }
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root) return empty("Empty tree — nothing to zigzag", "The queue starts empty.", "There are no levels to alternate.");
          const total = bfsList(root).length;
          const steps = [];
          const levels = [];
          const done = new Set();
          let q = [root], level = 0, base = { [root.id]: "read" };
          steps.push({
            title: `Root ${root.v} starts level 0 (left to right)`,
            kind: "tree", tree: root, nodeStates: base,
            label: `queue: ${root.v} · direction →`,
            counters: [count("level", 0), count("visited", 0, total)],
            legend: LEG,
            happened: "Even levels read left to right; odd levels will read right to left.",
            why: "The direction depends only on the level index.",
            codeLine: 8,
          });
          while (q.length) {
            const current = q.slice();
            const visible = level % 2 === 0 ? current.map((n) => n.v) : current.map((n) => n.v).reverse();
            const next = [];
            const states = mark(base, current.map((n) => n.id), "read");
            steps.push({
              title: `Level ${level}: ${level % 2 ? "right → left" : "left → right"} gives ${visible.join(", ")}`,
              kind: "tree", tree: root, nodeStates: states,
              label: `visit order: ${visible.join(" → ")}`,
              counters: [count("level", level), count("visited", done.size, total)],
              legend: LEG,
              happened: `The level has ${current.length} node${current.length === 1 ? "" : "s"} and is added in ${level % 2 ? "reverse" : "natural"} order.`,
              why: "Children are still enqueued left then right, so lower levels keep their usual structure.",
              codeLine: 11,
            });
            current.forEach((n) => {
              done.add(n.id);
              if (n.l) next.push(n.l);
              if (n.r) next.push(n.r);
            });
            levels.push(visible);
            q = next;
            base = mark(base, [...done], "done");
            steps.push({
              title: next.length ? `Queue next level: ${next.map((n) => n.v).join(", ")}` : "Last level reached",
              kind: "tree", tree: root, nodeStates: mark(base, next.map((n) => n.id), "active"),
              label: `result so far: ${levels.map((v) => "[" + v.join(",") + "]").join(" ")}`,
              counters: [count("levels", levels.length), count("visited", done.size, total)],
              legend: LEG,
              happened: next.length ? "The next level is ready and will read in the opposite direction." : "No children remain.",
              why: "Alternating the display does not alternate the child order.",
              codeLine: 16,
            });
            level++;
          }
          steps.push({
            title: `Answer: ${levels.map((v) => "[" + v.join(",") + "]").join(" ")}`,
            kind: "tree", tree: root, nodeStates: mark(base, bfsList(root).map((n) => n.id), "result"),
            label: `zigzag: ${levels.map((v) => "[" + v.join(",") + "]").join(" ")}`,
            counters: [count("levels", levels.length), count("visited", done.size, total)],
            legend: LEG,
            happened: "Odd levels appear reversed while every level still contains the same nodes.",
            why: "The tree itself never changes; only the reading direction does.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "right-side-view",
    title: "Right Side View",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Stand to the right of the tree and list the node visible on each level.",
    input: { label: "Tree (level order, null = gap)", default: "1, 2, 3, null, 5, null, 4", parse: "tokens" },
    approaches: [
      {
        name: "Last Node of Every Level",
        complexity: "O(n) time, O(w) queue space",
        idea: [
          "Walk level by level with a queue. The rightmost node of a level is the last one taken from that level's queue segment.",
          "Record that node and continue with the next level.",
        ],
        problem: [
          "A depth-first walk that always goes right misses a visible node when the right branch is shorter than the left one.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };

void right_view(struct node *root) {
    if (root == NULL) return;
    struct node *q[64];
    int head = 0, tail = 0;
    q[tail++] = root;

    while (head < tail) {
        int end = tail;
        printf("%d ", q[end - 1]->v);       /* last node of this level */
        for (; head < end; head++) {
            if (q[head]->l) q[tail++] = q[head]->l;
            if (q[head]->r) q[tail++] = q[head]->r;
        }
    }
    printf("\\n");
}

int main(void) {
    struct node n5 = {5, NULL, NULL}, n4 = {4, NULL, NULL}, n3 = {3, NULL, &n4};
    struct node n2 = {2, NULL, &n5};
    struct node root = {1, &n2, &n3};
    right_view(&root); /* 1 3 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };

vector<int> rightView(Node* root) {
    vector<int> out;
    if (!root) return out;
    queue<Node*> q;
    q.push(root);

    while (!q.empty()) {
        int size = (int)q.size();
        for (int i = 0; i < size; i++) {
            Node* n = q.front(); q.pop();
            if (i == size - 1) out.push_back(n->v);   // last of the level
            if (n->l) q.push(n->l);
            if (n->r) q.push(n->r);
        }
    }
    return out;
}

int main() {
    Node n5{5}, n4{4}, n3{3}, n2{2};
    n3.r = &n4; n2.r = &n5;
    Node root{1}; root.l = &n2; root.r = &n3;
    for (int v : rightView(&root)) cout << v << ' '; // 1 3 4
    cout << '\\n';
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root) return empty("Empty tree — nothing visible", "There is no level to look at.", "The right view of an empty tree is empty.");
          const total = bfsList(root).length;
          const steps = [];
          const visible = [];
          const done = new Set();
          let q = [root], level = 0, base = { [root.id]: "read" };
          steps.push({
            title: `Look from the right at level 0`,
            kind: "tree", tree: root, nodeStates: base,
            label: "visible: (none yet)",
            counters: [count("level", 0), count("visible", 0, total)],
            legend: LEG,
            happened: "Only one node sits on the first level, so it must be visible.",
            why: "The right view takes exactly one node per occupied level.",
            codeLine: 7,
          });
          while (q.length) {
            const current = q.slice();
            const next = [];
            const last = current[current.length - 1];
            const states = mark(base, current.map((n) => n.id), "read");
            visible.push(last.v);
            steps.push({
              title: `Level ${level}: queue holds ${current.map((n) => n.v).join(", ")}`,
              kind: "tree", tree: root, nodeStates: mark(states, [last.id], "good"),
              label: `rightmost of the level: ${last.v}`,
              counters: [count("level", level), count("visible", visible.length, total)],
              legend: LEG,
              happened: `${last.v} is the last node taken from this level, so it hides the nodes to its left.`,
              why: "Within one level, depth from the root is equal, so the rightmost node is nearest the viewer.",
              codeLine: 10,
            });
            current.forEach((n) => {
              done.add(n.id);
              if (n.l) next.push(n.l);
              if (n.r) next.push(n.r);
            });
            q = next;
            base = mark(base, [...done], "done");
            steps.push({
              title: next.length ? `Go down to level ${level + 1}` : "No deeper level",
              kind: "tree", tree: root, nodeStates: mark(base, next.map((n) => n.id), "active"),
              label: `visible so far: ${visible.join(", ")}`,
              counters: [count("levels seen", visible.length), count("visited", done.size, total)],
              legend: LEG,
              happened: next.length ? `${next.length} node${next.length === 1 ? "" : "s"} wait on the next level.` : "The tree has no more levels.",
              why: "The view is complete once the queue runs out.",
              codeLine: 13,
            });
            level++;
          }
          steps.push({
            title: `Answer: right view ${show(visible)}`,
            kind: "tree", tree: root, nodeStates: mark(base, bfsList(root).map((n) => n.id), "result"),
            label: `visible: ${visible.join(", ")}`,
            counters: [count("visible", visible.length), count("levels", level)],
            legend: LEG,
            happened: `One node was chosen from each of the ${level} levels.`,
            why: "Every recorded node was the last one on its level in the queue order.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "boundary-traversal",
    title: "Boundary Traversal",
    category: "Trees",
    difficulty: "Advanced",
    description: "Walk the outline of a tree: left edge, then leaves, then the right edge upwards.",
    input: { label: "Tree (level order, null = gap)", default: "1, 2, 3, 4, 5, 6, 7", parse: "tokens" },
    approaches: [
      {
        name: "Three Separate Walks",
        complexity: "O(n) time, O(h) space",
        idea: [
          "Collect the left boundary top-down, stopping before leaves. Then collect all leaves left to right.",
          "Finally collect the right boundary top-down and reverse it, so the outline is finished bottom-up.",
        ],
        problem: [
          "The root and the leaves are each on more than one of the three lists, so they need explicit exclusion rules to avoid duplicates.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };
int leaf(struct node *n) { return n && !n->l && !n->r; }

void left_edge(struct node *n) {
    while (n && !leaf(n)) { printf("%d ", n->v); n = n->l ? n->l : n->r; }
}
void leaves(struct node *n) {
    if (!n) return;
    if (leaf(n)) { printf("%d ", n->v); return; }
    leaves(n->l);
    leaves(n->r);
}
void right_edge(struct node *n) {
    if (!n || leaf(n)) return;
    right_edge(n->r ? n->r : n->l);
    printf("%d ", n->v);                  /* post-order = bottom-up */
}
void boundary(struct node *root) {
    if (!root) return;
    printf("%d ", root->v);
    left_edge(root->l);
    leaves(root->l);
    leaves(root->r);
    right_edge(root->r);
    printf("\\n");
}

int main(void) {
    struct node n4 = {4, NULL, NULL}, n5 = {5, NULL, NULL};
    struct node n6 = {6, NULL, NULL}, n7 = {7, NULL, NULL};
    struct node n2 = {2, &n4, &n5}, n3 = {3, &n6, &n7};
    struct node root = {1, &n2, &n3};
    boundary(&root); /* 1 2 4 5 6 7 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };
bool leaf(Node* n) { return n && !n->l && !n->r; }

void leftEdge(Node* n, vector<int>& out) {
    while (n && !leaf(n)) { out.push_back(n->v); n = n->l ? n->l : n->r; }
}
void leaves(Node* n, vector<int>& out) {
    if (!n) return;
    if (leaf(n)) { out.push_back(n->v); return; }
    leaves(n->l, out);
    leaves(n->r, out);
}
void rightEdge(Node* n, vector<int>& out) {
    if (!n || leaf(n)) return;
    rightEdge(n->r ? n->r : n->l, out);
    out.push_back(n->v);                  // bottom-up
}

int main() {
    Node n4{4}, n5{5}, n6{6}, n7{7}, n2{2}, n3{3};
    n2.l = &n4; n2.r = &n5; n3.l = &n6; n3.r = &n7;
    Node root{1}; root.l = &n2; root.r = &n3;

    vector<int> out{root.v};
    leftEdge(root.l, out);
    leaves(root.l, out);
    leaves(root.r, out);
    rightEdge(root.r, out);
    for (int v : out) cout << v << ' '; // 1 2 4 5 6 7 3
    cout << '\\n';
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root) return empty("Empty tree — no boundary", "There is no root to start the outline.", "An outline needs at least one node.");
          const total = bfsList(root).length;
          const steps = [];
          const boundary = [root];
          let base = { [root.id]: "result" };
          steps.push({
            title: `Start the outline at root ${root.v}`,
            kind: "tree", tree: root, nodeStates: base,
            label: `boundary: ${root.v}`,
            counters: [count("nodes", 1, total), count("phase", "root")],
            legend: LEG,
            happened: "The root is always the first boundary node.",
            why: "Every outline starts at the top of the tree.",
            codeLine: 21,
          });

          /* left edge: descend through the left child, keeping non-leaves */
          let cur = root.l;
          const leftIds = [];
          while (cur && !isLeaf(cur)) {
            boundary.push(cur);
            leftIds.push(cur.id);
            base = mark(base, [cur.id], "done");
            steps.push({
              title: `Left edge: add ${cur.v}`,
              kind: "tree", tree: root, nodeStates: mark(base, [cur.id], "read"),
              label: `boundary: ${boundary.map((n) => n.v).join(", ")}`,
              counters: [count("boundary nodes", boundary.length, total), count("phase", "left edge")],
              legend: LEG,
              happened: `${cur.v} is on the left outline and is not a leaf.`,
              why: "Leaves are handled by their own walk, so the edge stops before them.",
              codeLine: 8,
            });
            cur = cur.l || cur.r;
          }

          /* leaves, left to right */
          const leafNodes = [];
          (function collect(n) {
            if (!n) return;
            if (isLeaf(n)) { leafNodes.push(n); return; }
            collect(n.l);
            collect(n.r);
          })(root);
          leafNodes.forEach((leaf) => {
            boundary.push(leaf);
            base = mark(base, [leaf.id], "done");
            steps.push({
              title: `Leaf ${leaf.v} joins the outline`,
              kind: "tree", tree: root, nodeStates: mark(base, [leaf.id], "read"),
              label: `boundary: ${boundary.map((n) => n.v).join(", ")}`,
              counters: [count("boundary nodes", boundary.length, total), count("leaves", leafNodes.length)],
              legend: LEG,
              happened: "Leaves are read left to right along the bottom of the tree.",
              why: "A leaf has no child, so the outline turns along the bottom edge.",
              codeLine: 13,
            });
          });

          /* right edge, collected top-down then reversed */
          cur = root.r;
          const rightNodes = [];
          while (cur && !isLeaf(cur)) {
            rightNodes.push(cur);
            cur = cur.r || cur.l;
          }
          rightNodes.reverse();
          rightNodes.forEach((n) => {
            boundary.push(n);
            base = mark(base, [n.id], "done");
            steps.push({
              title: `Right edge upward: add ${n.v}`,
              kind: "tree", tree: root, nodeStates: mark(base, [n.id], "read"),
              label: `boundary: ${boundary.map((x) => x.v).join(", ")}`,
              counters: [count("boundary nodes", boundary.length, total), count("phase", "right edge")],
              legend: LEG,
              happened: `${n.v} closes the right side after the leaves.`,
              why: "Reversing the top-down right edge makes the walk return towards the root.",
              codeLine: 17,
            });
          });

          steps.push({
            title: `Answer: ${boundary.map((n) => n.v).join(" → ")}`,
            kind: "tree", tree: root, nodeStates: mark(base, boundary.map((n) => n.id), "result"),
            label: `boundary: ${boundary.map((n) => n.v).join(", ")}`,
            counters: [count("boundary nodes", boundary.length, total), count("phases", 3)],
            legend: LEG,
            happened: "The root, left edge, leaves and right edge form one closed outline with no repeats.",
            why: "Each phase excludes the nodes that another phase already owns.",
            codeLine: 26,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "vertical-order-traversal",
    title: "Vertical Order Traversal",
    category: "Trees",
    difficulty: "Advanced",
    description: "Group nodes by their horizontal distance from the root and read the columns left to right.",
    input: { label: "Tree (level order, null = gap)", default: "3, 9, 20, null, null, 15, 7", parse: "tokens" },
    approaches: [
      {
        name: "Column Index per Node",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Give the root column 0, a left child column − 1 and a right child column + 1 while walking breadth-first.",
          "Collect nodes per column, then sort columns and, inside each column, order by row so upper nodes come first.",
        ],
        problem: [
          "Two nodes in the same column can share a row only when they are the same node, so a stable row order is enough for a tree.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

struct node { int v; struct node *l, *r; };
struct entry { int row, col, v; };
struct entry all[64];
int count_nodes = 0;

void walk(struct node *n, int row, int col) {
    if (!n) return;
    all[count_nodes++] = (struct entry){row, col, n->v};
    walk(n->l, row + 1, col - 1);
    walk(n->r, row + 1, col + 1);
}

int by_col(const void *a, const void *b) {
    const struct entry *x = a, *y = b;
    if (x->col != y->col) return x->col - y->col;
    if (x->row != y->row) return x->row - y->row;
    return x->v - y->v;
}

int main(void) {
    struct node n4 = {15, NULL, NULL}, n5 = {7, NULL, NULL};
    struct node n3 = {20, &n4, &n5}, n2 = {9, NULL, NULL};
    struct node root = {3, &n2, &n3};

    walk(&root, 0, 0);
    qsort(all, count_nodes, sizeof(struct entry), by_col);
    for (int i = 0; i < count_nodes; i++) {
        if (i && all[i].col != all[i - 1].col) printf(" | ");
        printf("%d ", all[i].v);
    }
    printf("\\n"); /* 9 | 3 15 | 20 | 7 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };

void walk(Node* n, int row, int col, map<int, vector<pair<int,int>>>& cols) {
    if (!n) return;
    cols[col].push_back({row, n->v});
    walk(n->l, row + 1, col - 1, cols);
    walk(n->r, row + 1, col + 1, cols);
}

int main() {
    Node n4{15}, n5{7}, n3{20}, n2{9};
    n3.l = &n4; n3.r = &n5;
    Node root{3}; root.l = &n2; root.r = &n3;

    map<int, vector<pair<int,int>>> cols;   // sorted by column
    walk(&root, 0, 0, cols);
    for (auto& [col, row] : cols) {
        sort(row.begin(), row.end());
        for (auto& [r, v] : row) cout << v << ' ';
        cout << '|';
    }
    cout << '\\n'; // 9 | 3 15 | 20 | 7
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root) return empty("Empty tree — no columns", "No node has a column index.", "Without nodes there is nothing to group.");
          const total = bfsList(root).length;
          const steps = [];
          const groups = new Map();
          let q = [{ n: root, col: 0, row: 0 }];
          let level = 0;
          let base = {};
          steps.push({
            title: `Root ${root.v} sits in column 0`,
            kind: "tree", tree: root, nodeStates: { [root.id]: "read" },
            label: "columns: 0 → [" + root.v + "]",
            counters: [count("columns", 1), count("level", 0)],
            legend: LEG,
            happened: "Left moves decrease the column, right moves increase it.",
            why: "The column is the horizontal position of a node when the tree is drawn flat.",
            codeLine: 1,
          });
          while (q.length) {
            const current = q.slice();
            const next = [];
            const seen = [];
            const states = Object.assign({}, base);
            current.forEach(({ n, col, row }) => {
              if (!groups.has(col)) groups.set(col, []);
              groups.get(col).push({ row, v: n.v, id: n.id });
              seen.push(`${n.v}→${col}`);
              states[n.id] = "read";
              if (n.l) next.push({ n: n.l, col: col - 1, row: row + 1 });
              if (n.r) next.push({ n: n.r, col: col + 1, row: row + 1 });
            });
            steps.push({
              title: `Level ${level}: columns ${seen.join(", ")}`,
              kind: "tree", tree: root, nodeStates: states,
              label: "column assignment: " + seen.join(" · "),
              counters: [count("level", level), count("columns", groups.size)],
              legend: LEG,
              happened: "Each node inherits its parent's column with a ±1 shift.",
              why: "Breadth-first order is not required for correctness, but it makes the row number easy to track.",
              codeLine: 5,
            });
            current.forEach(({ n }) => { base = mark(base, [n.id], "done"); });
            q = next;
            level++;
          }
          const cols = [...groups.keys()].sort((a, b) => a - b);
          cols.forEach((col) => {
            const list = groups.get(col).slice().sort((a, b) => a.row - b.row || a.v - b.v);
            steps.push({
              title: `Column ${col}: ${list.map((x) => x.v).join(", ")}`,
              kind: "tree", tree: root, nodeStates: mark(base, list.map((x) => x.id), "result"),
              label: `column ${col} = [${list.map((x) => x.v).join(", ")}]`,
              counters: [count("column", col), count("nodes in column", list.length)],
              legend: LEG,
              happened: `All nodes at horizontal distance ${col} read top to bottom.`,
              why: "Sorting by row first keeps upper nodes ahead of lower ones inside the column.",
              codeLine: 10,
            });
          });
          steps.push({
            title: `Answer: ${cols.map((c) => "[" + groups.get(c).map((x) => x.v).join(",") + "]").join(" ")}`,
            kind: "tree", tree: root, nodeStates: mark(base, bfsList(root).map((n) => n.id), "result"),
            label: `columns: ${cols.map((c) => "[" + groups.get(c).map((x) => x.v).join(",") + "]").join(" ")}`,
            counters: [count("columns", cols.length), count("visited", total)],
            legend: LEG,
            happened: "Columns are ordered from the far left to the far right.",
            why: "The sign of the column index gives the left-to-right order directly.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "path-sum",
    title: "Path Sum",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Decide whether a root-to-leaf path adds up to a target.",
    input: { label: "Tree (level order) | target", default: "5, 4, 8, 11, null, 13, 4, 7, 2, null, null, null, 1 | 22", parse: "string" },
    approaches: [
      {
        name: "Running Sum on the Way Down",
        complexity: "O(n) time, O(h) space",
        idea: [
          "Carry the sum of the current root-to-node path into each recursive call.",
          "Only at a leaf does the sum count as a candidate; then return to the previous node and subtract its value by dropping the frame.",
        ],
        problem: [
          "Checking a partial sum at an internal node can produce a false positive: the path must end at a leaf.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };

int has_path(struct node *n, int need) {
    if (n == NULL) return 0;
    need -= n->v;

    if (!n->l && !n->r) return need == 0;   /* only leaves count */
    return has_path(n->l, need) || has_path(n->r, need);
}

int main(void) {
    struct node n7 = {7, NULL, NULL}, n2 = {2, NULL, NULL};
    struct node n1 = {1, NULL, NULL}, n11 = {11, &n7, &n2};
    struct node n13 = {13, NULL, NULL}, n4b = {4, NULL, NULL}, n4 = {4, &n11, NULL};
    struct node n8 = {8, &n13, &n4b};
    struct node root = {5, &n4, &n8};
    printf("%d\\n", has_path(&root, 22)); /* 1: 5+4+11+2 */
    return 0;
}`,
          cpp: `#include <iostream>

struct Node { int v; Node *l = nullptr, *r = nullptr; };

bool hasPathSum(Node* n, int need) {
    if (!n) return false;
    need -= n->v;
    if (!n->l && !n->r) return need == 0;
    return hasPathSum(n->l, need) || hasPathSum(n->r, need);
}

int main() {
    Node n7{7}, n2{2}, n1{1}, n11{11}, n13{13}, n4b{4}, n4{4}, n8{8};
    n11.l = &n7; n11.r = &n2; n4.l = &n11;
    n8.l = &n13; n8.r = &n4b;
    Node root{5}; root.l = &n4; root.r = &n8;
    std::cout << hasPathSum(&root, 22) << '\\n'; // 1
}`,
        },
        steps(text) {
          const segs = String(text || "").split("|");
          const root = binaryTree(sideVals(segs[0]));
          const target = parseInt(segs[1], 10);
          if (!root) return empty("Empty tree — no path", "There is no root to start a path.", "A path needs at least one node.");
          const steps = [];
          let found = null;
          const path = [];
          const record = (n, sum, states, title, happened, why, line) => {
            steps.push({
              title,
              kind: "tree", tree: root, nodeStates: states,
              label: `path: ${path.map((x) => x.v).join(" + ")} = ${sum}`,
              counters: [count("running sum", sum), count("target", Number.isFinite(target) ? target : "—")],
              legend: LEG,
              happened, why, codeLine: line,
            });
          };
          (function walk(n) {
            if (!n) return;
            path.push(n);
            const sum = path.reduce((s, x) => s + x.v, 0);
            const states = {};
            path.forEach((x) => { states[x.id] = "read"; });
            if (isLeaf(n)) {
              const ok = sum === target;
              record(n, sum, mark(states, [n.id], ok ? "good" : "bad"),
                `Leaf ${n.v}: total ${sum} ${ok ? "matches" : "misses"} ${target}`,
                ok ? "This path ends at a leaf and reaches the target." : "The path ends here but the total is wrong.",
                "Only leaf sums are accepted, so an internal partial sum never counts.",
                8);
              if (ok && !found) found = path.slice();
            } else {
              record(n, sum, states,
                `At ${n.v}: running sum ${sum}`,
                `The path has not ended yet, so the sum is only a candidate.`,
                "The sum is passed down by subtraction so the caller does not need a separate accumulator.",
                5);
              walk(n.l);
              walk(n.r);
            }
            path.pop();
          })(root);
          steps.push({
            title: found ? `Answer: yes — ${found.map((x) => x.v).join(" + ")} = ${target}` : "Answer: no root-to-leaf path reaches the target",
            kind: "tree", tree: root, nodeStates: found ? mark({}, found.map((x) => x.id), "result") : { [root.id]: "bad" },
            label: found ? `${found.map((x) => x.v).join(" + ")} = ${target}` : "no matching leaf",
            counters: [count("target", Number.isFinite(target) ? target : "—"), count("answer", found ? "yes" : "no")],
            legend: LEG,
            happened: found ? "The highlighted nodes form a complete root-to-leaf path." : "Every leaf was checked and none matched.",
            why: "A path is only valid when it starts at the root and stops at a leaf.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "binary-tree-maximum-path-sum",
    title: "Binary Tree Maximum Path Sum",
    category: "Trees",
    difficulty: "Advanced",
    description: "Find the highest-sum path between any two nodes in a tree.",
    input: { label: "Tree (level order, null = gap)", default: "-10, 9, 20, null, null, 15, 7", parse: "tokens" },
    approaches: [
      {
        name: "One Gain per Subtree",
        complexity: "O(n) time, O(h) space",
        idea: [
          "For each node, compute the best downward gain from that node. A negative child gain is replaced by 0.",
          "The best path through a node is its value plus both child gains. Carry that candidate to a global maximum, but return only the better single side to the parent.",
        ],
        problem: [
          "Returning the through-node total to the parent would create a path with a branch, which is not a path any more.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };
int best;

int gain(struct node *n) {
    if (n == NULL) return 0;

    int left = gain(n->l);
    int right = gain(n->r);
    if (left < 0) left = 0;               /* dropping a negative branch helps */
    if (right < 0) right = 0;

    int through = n->v + left + right;    /* path that bends here */
    if (through > best) best = through;

    int down = n->v + (left > right ? left : right);
    return down > 0 ? down : 0;           /* only useful directions go up */
}

int main(void) {
    struct node n15 = {15, NULL, NULL}, n7 = {7, NULL, NULL};
    struct node n20 = {20, &n15, &n7}, n9 = {9, NULL, NULL};
    struct node root = {-10, &n9, &n20};

    best = root.v;
    gain(&root);
    printf("%d\\n", best); /* 42: 15 + 20 + 7 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <algorithm>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };
int best = 0;

int gain(Node* n) {
    if (!n) return 0;
    int left = max(0, gain(n->l));
    int right = max(0, gain(n->r));

    best = max(best, n->v + left + right);   // path bending here
    return max(0, n->v + max(left, right));  // straight path upward
}

int main() {
    Node n15{15}, n7{7}, n20{20}, n9{9};
    n20.l = &n15; n20.r = &n7;
    Node root{-10}; root.l = &n9; root.r = &n20;

    best = root.v;
    gain(&root);
    cout << best << '\\n'; // 42
}`,
        },
        steps(tokens) {
          const root = binaryTree(toVals(tokens));
          if (!root) return empty("Empty tree — sum 0", "No node can start a path.", "Maximum path sum needs at least one node.");
          const total = bfsList(root).length;
          const steps = [];
          let best = -Infinity;
          const gains = new Map();
          const states = {};
          const labelGains = () => [...gains].map(([n, g]) => `${n.v}→${g}`).join(", ") || "none yet";
          steps.push({
            title: `Start at the leaves; best is unknown`,
            kind: "tree", tree: root, nodeStates: {},
            label: "gains: none yet",
            counters: [count("best", "−∞"), count("nodes", total)],
            legend: LEG,
            happened: "Each subtree reports one straight-line gain upward.",
            why: "A path cannot branch, so only the better child direction can be passed to the parent.",
            codeLine: 3,
          });
          (function gain(n) {
            if (!n) return 0;
            const l = Math.max(0, gain(n.l));
            const r = Math.max(0, gain(n.r));
            const through = n.v + l + r;
            const down = n.v + Math.max(l, r);
            gains.set(n, Math.max(0, down));
            best = Math.max(best, through);
            states[n.id] = "read";
            steps.push({
              title: `${n.v}: children give ${l} and ${r}; through = ${through}`,
              kind: "tree", tree: root, nodeStates: mark(states, [n.id], "compare"),
              label: `gains: ${labelGains()}`,
              counters: [count("through", through), count("best", best === -Infinity ? "−∞" : best)],
              legend: LEG,
              happened: `The best path that bends at ${n.v} is ${n.v} + ${l} + ${r} = ${through}.`,
              why: "Only non-negative child gains are worth keeping; a negative branch would lower the total.",
              codeLine: 7,
            });
            states[n.id] = "done";
            steps.push({
              title: `${n.v} returns gain ${Math.max(0, down)} to its parent`,
              kind: "tree", tree: root, nodeStates: mark(states, [n.id], "good"),
              label: `gains: ${labelGains()}`,
              counters: [count("gain up", Math.max(0, down)), count("best", best)],
              legend: LEG,
              happened: `The parent may continue through ${n.v} in one direction only.`,
              why: "Returning only one side keeps the path straight instead of branching.",
              codeLine: 11,
            });
            return Math.max(0, down);
          })(root);
          steps.push({
            title: `Answer: maximum path sum ${best}`,
            kind: "tree", tree: root, nodeStates: mark({}, bfsList(root).map((n) => n.id), "result"),
            label: "every subtree contributed its best straight gain",
            counters: [count("best", best), count("nodes", total)],
            legend: LEG,
            happened: "The best value came from some node plus its two non-negative child gains.",
            why: "Every possible bending point was considered while walking up once.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "lowest-common-ancestor",
    title: "Lowest Common Ancestor",
    category: "Trees",
    difficulty: "Intermediate",
    description: "Find the deepest node that has both targets somewhere in its subtree.",
    input: { label: "Tree | node p | node q", default: "3, 5, 1, 6, 2, 0, 8, null, null, 7, 4 | 5 | 1", parse: "string" },
    approaches: [
      {
        name: "Paths From the Root",
        complexity: "O(n) time, O(h) space",
        idea: [
          "Walk down once, recording each node's parent, and locate p and q.",
          "Walk p's ancestors into a set, then climb from q until a node is already in the set. The first hit is the lowest common ancestor.",
        ],
        problem: [
          "Comparing node depths alone is not enough; the two paths must share the same ancestors, not merely the same level.",
        ],
        code: {
          c: `#include <stdio.h>

struct node { int v; struct node *l, *r; };
struct node *parent_of[64];
int value_of[64];

void find_parents(struct node *n, struct node *p) {
    if (!n) return;
    parent_of[n->v + 32] = p;             /* shift for negative values */
    find_parents(n->l, n);
    find_parents(n->r, n);
}

int depth(struct node *n) {
    int d = 0;
    while (parent_of[n->v + 32]) { n = parent_of[n->v + 32]; d++; }
    return d;
}

struct node *lca(struct node *a, struct node *b) {
    int da = depth(a), db = depth(b);
    while (da > db) { a = parent_of[a->v + 32]; da--; }
    while (db > da) { b = parent_of[b->v + 32]; db--; }
    while (a != b) {
        a = parent_of[a->v + 32];
        b = parent_of[b->v + 32];
    }
    return a;
}

int main(void) {
    struct node n6 = {6, NULL, NULL}, n2 = {2, NULL, NULL};
    struct node n0 = {0, NULL, NULL}, n8 = {8, NULL, NULL};
    struct node n5 = {5, &n6, &n2}, n1 = {1, &n0, &n8};
    struct node root = {3, &n5, &n1};
    find_parents(&root, NULL);
    printf("%d\\n", lca(&n5, &n1)->v); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <unordered_map>
#include <unordered_set>
using namespace std;

struct Node { int v; Node *l = nullptr, *r = nullptr; };

void parents(Node* n, Node* p, unordered_map<Node*, Node*>& up) {
    if (!n) return;
    up[n] = p;
    parents(n->l, n, up);
    parents(n->r, n, up);
}

Node* lca(Node* a, Node* b, unordered_map<Node*, Node*>& up) {
    unordered_set<Node*> seen;
    for (Node* n = a; n; n = up[n]) seen.insert(n);   // a and all ancestors
    for (Node* n = b; n; n = up[n])
        if (seen.count(n)) return n;                  // first shared node
    return nullptr;
}

int main() {
    Node n6{6}, n2{2}, n0{0}, n8{8}, n5{5}, n1{1};
    n5.l = &n6; n5.r = &n2; n1.l = &n0; n1.r = &n8;
    Node root{3}; root.l = &n5; root.r = &n1;

    unordered_map<Node*, Node*> up;
    parents(&root, nullptr, up);
    cout << lca(&n5, &n1, up)->v << '\\n'; // 3
}`,
        },
        steps(text) {
          const segs = String(text || "").split("|");
          const root = binaryTree(sideVals(segs[0]));
          const pv = toVal(segs[1]);
          const qv = toVal(segs[2]);
          if (!root) return empty("Empty tree — no ancestor", "There are no nodes to compare.", "An ancestor needs a node and its descendants.");
          const steps = [];
          const nodes = bfsList(root);
          const p = nodes.find((n) => n.v === pv);
          const q = nodes.find((n) => n.v === qv);
          const parent = new Map();
          parent.set(root, null);
          (function link(n) {
            if (!n) return;
            if (n.l) { parent.set(n.l, n); link(n.l); }
            if (n.r) { parent.set(n.r, n); link(n.r); }
          })(root);
          steps.push({
            title: `Find nodes ${pv} and ${qv}`,
            kind: "tree", tree: root, nodeStates: mark({}, [p && p.id, q && q.id], "read"),
            label: p && q ? `p = ${p.v}, q = ${q.v}` : "one of the targets is missing",
            counters: [count("nodes", nodes.length), count("found", [p, q].filter(Boolean).length, 2)],
            legend: LEG,
            happened: p && q ? "Both targets exist, so a common ancestor must exist too." : "A missing target has no ancestor path.",
            why: "Every node in a tree is a descendant of the root.",
            codeLine: 4,
          });
          if (!p || !q) {
            steps.push({
              title: "Answer: no common ancestor",
              kind: "tree", tree: root, nodeStates: {},
              label: "target not present",
              counters: [count("answer", "none")],
              legend: LEG,
              happened: "At least one value does not occur in the tree.",
              why: "The ancestor relation only exists between nodes that are actually present.",
              codeLine: 8,
            });
            return steps;
          }
          const pathTo = (node) => {
            const out = [];
            for (let n = node; n; n = parent.get(n)) out.push(n);
            return out;
          };
          const pa = pathTo(p);
          const qa = pathTo(q);
          const states = {};
          pa.forEach((n) => { states[n.id] = "active"; });
          states[p.id] = "result";
          steps.push({
            title: `Path from root to p = ${p.v}`,
            kind: "tree", tree: root, nodeStates: states,
            label: `ancestors of ${p.v}: ${pa.map((n) => n.v).join(" → ")}`,
            counters: [count("depth of p", pa.length - 1), count("nodes on path", pa.length)],
            legend: LEG,
            happened: "Following parent pointers from p reaches the root.",
            why: "The common ancestor must appear on both ancestor chains.",
            codeLine: 15,
          });
          const shared = new Set(pa.map((n) => n.id));
          const chain = [];
          for (let n = q; n; n = parent.get(n)) {
            chain.push(n);
            if (shared.has(n.id)) break;
          }
          states[q.id] = "result";
          chain.forEach((n) => { states[n.id] = "compare"; });
          const lca = chain[chain.length - 1];
          steps.push({
            title: `Climb from q = ${q.v} until the paths meet`,
            kind: "tree", tree: root, nodeStates: states,
            label: `q's chain: ${chain.map((n) => n.v).join(" → ")}`,
            counters: [count("shared node", lca.v), count("steps up", chain.length - 1)],
            legend: LEG,
            happened: `${lca.v} is the first node on q's chain that also lies on p's chain.`,
            why: "Going upward from q, the first shared node is the deepest shared ancestor.",
            codeLine: 19,
          });
          steps.push({
            title: `Answer: lowest common ancestor is ${lca.v}`,
            kind: "tree", tree: root, nodeStates: mark(mark({}, pa.concat(chain).map((n) => n.id), "done"), [lca.id], "result"),
            label: `LCA(${p.v}, ${q.v}) = ${lca.v}`,
            counters: [count("answer", lca.v), count("depth", pa.length - 1)],
            legend: LEG,
            happened: `Both ${p.v} and ${q.v} sit inside the subtree rooted at ${lca.v}.`,
            why: "Any lower shared node would have appeared earlier when climbing from q.",
            codeLine: 22,
          });
          return steps;
        },
      },
    ],
  });
})();
