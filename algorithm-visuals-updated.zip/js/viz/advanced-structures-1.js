/* ============================================================
   DSA Visuals — Advanced Structures I
   Fenwick trees, order statistics, range minima, difference
   arrays and the three calendar booking counters. The stages
   are built from short rows so every bucket and segment can be
   read at a glance. All prose and code here is original.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  /* ---------------- small shared helpers ---------------- */

  function clamp(v, lo, hi) {
    return Math.max(lo, Math.min(hi, v));
  }

  function cell(label, v, state, tag) {
    return { label, cells: [{ v, state, tag }] };
  }

  /* Truncate to whole numbers and cap the length so rows stay legible. */
  function ints(list, cap) {
    const out = [];
    const src = Array.isArray(list) ? list : [];
    for (const v of src) {
      const num = Math.trunc(Number(v));
      if (Number.isFinite(num)) out.push(num);
      if (out.length >= (cap || 40)) break;
    }
    return out;
  }

  function dashes(n) {
    return Array(n).fill("—");
  }

  /* Pairs become half-open intervals [start, end). */
  function pairList(pairs, cap) {
    const out = [];
    const src = Array.isArray(pairs) ? pairs : [];
    for (const p of src) {
      if (!Array.isArray(p) || p.length < 2) continue;
      let s = Math.trunc(Number(p[0]));
      let e = Math.trunc(Number(p[1]));
      if (!Number.isFinite(s) || !Number.isFinite(e)) continue;
      if (s > e) { const t = s; s = e; e = t; }
      out.push({ s, e });
      if (out.length >= (cap || 8)) break;
    }
    return out;
  }

  function clash(a, b) {
    return a.s < b.e && b.s < a.e;
  }

  function span(x) {
    return x.s + "–" + x.e;
  }

  function signed(v) {
    return (v >= 0 ? "+" : "") + v;
  }

  /* A row of interval labels; empty lists still get one idle cell. */
  function listRow(label, list, stateOf, tagOf) {
    return {
      label,
      cells: list.length
        ? list.map((x) => ({
            v: span(x),
            state: stateOf ? stateOf(x) : "done",
            tag: tagOf ? tagOf(x) : "start " + x.s,
          }))
        : [{ v: "—", state: "idle", empty: true }],
    };
  }

  /* ============================================================
     1. Range Sum Query Mutable
     ============================================================ */
  V.register({
    id: "range-sum-query-mutable",
    title: "Range Sum Query Mutable",
    category: "Advanced Structures",
    difficulty: "Advanced",
    description: "Use a Fenwick tree so a point update and a range-sum query both take logarithmic time.",
    input: {
      label: "Array | update index, new value, query left, query right",
      default: "3, 1, 4, 1, 5, 9 | 2, 10, 1, 4",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Fenwick Tree",
        complexity: "O(n log n) build, O(log n) update and query, O(n) space",
        idea: [
          "Number the array slots 1 to n. Bucket b(i) stores the sum of the block that ends at i and has length lowbit(i), so b(1) holds a[0], b(2) holds a[0]+a[1], and b(4) holds a[0]+a[1]+a[2]+a[3].",
          "A prefix sum starts at i and keeps jumping left by lowbit(i), so it lands on buckets that exactly partition the prefix. A point update walks the other way, adding the change to every bucket whose block contains that position.",
          "Both walks touch at most log2(n) buckets, which is why a mutable range sum never needs to add up the whole range again.",
        ],
        problem: [
          "A Fenwick tree only answers prefix-shaped questions directly. A range query needs two prefixes, and it cannot report the minimum or the actual values — for those a segment tree or a balanced tree is the right tool.",
          "The 1-based indexing and lowbit arithmetic are easy to get wrong at the boundaries, especially when an update lands on the last slot or a query starts at index 0.",
        ],
        code: {
          c: `#include <stdio.h>

/* bucket i covers the range (i - lowbit(i), i] */
typedef struct { int n; int t[32]; } Fenwick;

void fenwick_add(Fenwick *f, int i, int delta) {
    for (; i <= f->n; i += i & -i)
        f->t[i] += delta;
}

void fenwick_build(Fenwick *f, const int *a) {
    for (int i = 1; i <= f->n; i++)
        fenwick_add(f, i, a[i - 1]);
}

int fenwick_prefix(const Fenwick *f, int i) {
    int sum = 0;
    for (; i > 0; i -= i & -i)
        sum += f->t[i];
    return sum;
}

int main(void) {
    int a[] = {3, 1, 4, 1, 5, 9};
    Fenwick f = {6, {0}};
    fenwick_build(&f, a);
    fenwick_add(&f, 3, 6);            /* a[2]: 4 -> 10 */
    printf("%d\\n", fenwick_prefix(&f, 5) - fenwick_prefix(&f, 1)); /* 17 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// bucket i covers (i - lowbit(i), i]
struct Fenwick {
    int n;
    std::vector<int> t;
    explicit Fenwick(int size) : n(size), t(size + 1, 0) {}
    void add(int i, int delta) {
        for (; i <= n; i += i & -i) t[i] += delta;
    }
    int prefix(int i) const {
        int sum = 0;
        for (; i > 0; i -= i & -i) sum += t[i];
        return sum;
    }
};

int main() {
    std::vector<int> a{3, 1, 4, 1, 5, 9};
    Fenwick f(static_cast<int>(a.size()));
    for (int i = 1; i <= f.n; ++i) f.add(i, a[i - 1]);
    f.add(3, 6);                        // a[2]: 4 -> 10
    std::cout << f.prefix(5) - f.prefix(1) << '\\n'; // 17
}`,
        },
        steps(parsed) {
          const raw = parsed && Array.isArray(parsed[0]) ? parsed[0] : [];
          const cfg = parsed && Array.isArray(parsed[1]) ? parsed[1] : [];
          const LEG = ["read", "compare", "active", "done", "result", "good", "bad", "dim", "idle"];
          const arr = ints(raw, 10);
          const n = arr.length;
          const steps = [];

          if (!n) {
            return [
              {
                title: "No array values to index",
                tracks: [cell("the array", "empty", "bad", "nothing to store")],
                counters: [count("buckets", 0), count("answer", "—")],
                legend: LEG,
                happened: "The first row of the input is empty, so there is no slot for a Fenwick tree to cover.",
                why: "Every bucket covers at least one array position; with no positions the structure has nothing to hold.",
                codeLine: 10,
              },
              {
                title: "Give a few numbers, then the command",
                tracks: [cell("example", "3, 1, 4, 1, 5, 9 | 2, 10, 1, 4", "idle", "array | update, query")],
                counters: [count("buckets", 0), count("answer", "—")],
                legend: LEG,
                happened: "The left side of the vertical bar is the array; the right side names one update and one query.",
                why: "Splitting the input keeps the array separate from the commands that follow it.",
              },
              {
                title: "Answer: n/a — add array values first",
                tracks: [cell("status", "waiting for numbers", "bad")],
                counters: [count("buckets", 0), count("answer", "—")],
                legend: LEG,
                happened: "There is nothing to build, update or query yet.",
                why: "The Fenwick walk needs at least one indexed value to demonstrate anything.",
              },
            ];
          }

          const truncated = raw.length > n;
          const bit = new Array(n + 1).fill(0);
          const arrTags = arr.map((_, i) => "a" + i);
          const bucketTags = [];
          for (let i = 1; i <= n; i++) {
            bucketTags.push("b" + i + ": " + (i - (i & -i) + 1) + "-" + i);
          }
          const bucketValues = () => bit.slice(1);
          const bucketStates = (hot) =>
            bit.slice(1).map((v, k) => {
              if (hot && hot.indexOf(k + 1) >= 0) return "result";
              return v !== 0 ? "done" : "idle";
            });

          const hasCmd = cfg.length >= 2;
          let ui = hasCmd ? clamp(Math.trunc(cfg[0]), 0, n - 1) : 0;
          let nv = hasCmd ? Math.trunc(cfg[1]) : arr[ui];
          let ql = cfg.length >= 3 ? clamp(Math.trunc(cfg[2]), 0, n - 1) : 0;
          let qr = cfg.length >= 4 ? clamp(Math.trunc(cfg[3]), 0, n - 1) : n - 1;
          if (ql > qr) { const t = ql; ql = qr; qr = t; }

          const prefixOf = (p) => {
            const used = [];
            let sum = 0;
            let i = p;
            while (i > 0) {
              used.push(i);
              sum += bit[i];
              i -= i & -i;
            }
            return { sum, used };
          };

          steps.push({
            title: `Set up a Fenwick tree for ${n} value${n === 1 ? "" : "s"}`,
            tracks: [
              track("the array", arr, fill(n, "idle"), arrTags),
              track("Fenwick buckets", bucketValues(), fill(n, "idle"), bucketTags),
              cell(
                "command",
                (hasCmd ? `a[${ui}]: ${arr[ui]} → ${nv}` : "build only") +
                  `, sum a[${ql}..${qr}]`,
                "idle",
                truncated ? "first 10 values shown" : "from the input",
              ),
            ],
            counters: [count("buckets", 0, n), count("answer", "—")],
            legend: LEG,
            happened: `The row holds ${arr.join(", ")}. All ${n} buckets start at zero${truncated ? "; only the first 10 values are shown" : ""}.`,
            why: "Each bucket will hold the sum of a whole block, so the empty tree is the starting point for every later walk.",
            codeLine: 10,
          });

          const sample = n >= 4 ? 4 : n;
          steps.push({
            title: `Bucket b${sample} owns a[${sample - (sample & -sample)}..${sample - 1}]`,
            tracks: [
              track("the array", arr, fill(n, "idle"), arrTags),
              track("Fenwick buckets", bucketValues(), fill(n, "idle"), bucketTags),
              cell("coverage rule", "b(i) covers i - lowbit(i) + 1 .. i", "read", "lowbit = i & -i"),
            ],
            counters: [count("buckets", 0, n), count("blocks explained", 1, n)],
            legend: LEG,
            happened: `Bucket b${sample} spans ${sample & -sample} slot${(sample & -sample) === 1 ? "" : "s"} because lowbit(${sample}) is ${sample & -sample}.`,
            why: "Block sizes are powers of two, which is what lets a prefix walk skip whole blocks with one subtraction.",
            codeLine: 2,
          });

          for (let i = 0; i < n; i++) {
            const touched = [];
            for (let j = i + 1; j <= n; j += j & -j) {
              bit[j] += arr[i];
              touched.push(j);
            }
            const last = touched[touched.length - 1];
            steps.push({
              title: `${arr[i]} climbs buckets ${touched.map((j) => "b" + j).join(" → ")}`,
              tracks: [
                track(
                  "the array",
                  arr,
                  arr.map((_, k) => (k < i ? "done" : k === i ? "read" : "idle")),
                  arrTags,
                ),
                track("Fenwick buckets", bucketValues(), bucketStates(touched), bucketTags),
                cell("inserted", `${arr[i]} at a[${i}]`, "result", `${touched.length} bucket${touched.length === 1 ? "" : "s"} updated`),
              ],
              counters: [count("values inserted", i + 1, n), count("buckets in last walk", touched.length)],
              legend: LEG,
              happened: `Adding ${arr[i]} to b${touched.join(", b")} makes b${last} equal ${bit[last]}.`,
              why: `From index ${i + 1} the walk jumps by its own lowbit, so it reaches only the buckets whose block contains a[${i}].`,
              codeLine: 12,
            });
          }

          const old = arr[ui];
          const delta = nv - old;
          steps.push({
            title: hasCmd
              ? `Update a[${ui}]: ${old} → ${nv} (change ${delta >= 0 ? "+" : ""}${delta})`
              : `No update given — a[${ui}] stays ${old}`,
            tracks: [
              track("the array", arr, paint(fill(n, "done"), { [ui]: "read" }), arrTags),
              track("Fenwick buckets", bucketValues(), bucketStates([]), bucketTags),
              cell("delta", `${delta >= 0 ? "+" : ""}${delta}`, delta === 0 ? "dim" : "compare", "added to covering buckets"),
            ],
            counters: [count("buckets", n), count("delta", delta)],
            legend: LEG,
            happened: `Only buckets whose block contains a[${ui}] need to move; every other bucket keeps its value.`,
            why: "An update is the same upward walk as an insert, carrying the difference instead of a whole value.",
            codeLine: 26,
          });

          const upTouched = [];
          for (let j = ui + 1; j <= n; j += j & -j) {
            bit[j] += delta;
            upTouched.push(j);
          }
          arr[ui] = nv;
          steps.push({
            title:
              delta === 0
                ? "Delta 0 leaves every bucket unchanged"
                : `${upTouched.map((j) => "b" + j).join(" and ")} gain ${delta >= 0 ? "+" : ""}${delta}`,
            tracks: [
              track("the array", arr, paint(fill(n, "done"), { [ui]: "result" }), arrTags),
              track("Fenwick buckets", bucketValues(), bucketStates(upTouched), bucketTags),
              cell("buckets changed", upTouched.length, "result", upTouched.map((j) => "b" + j).join(", ")),
            ],
            counters: [count("buckets", n), count("delta applied", delta)],
            legend: LEG,
            happened: `The array slot now reads ${nv}, and ${upTouched.length} bucket${upTouched.length === 1 ? "" : "s"} absorbed the change of ${delta >= 0 ? "+" : ""}${delta}.`,
            why: "Because a bucket's block is fixed, changing one array value only changes the buckets that already include it.",
            codeLine: 6,
          });

          steps.push({
            title: `Range a[${ql}..${qr}] = prefix(${qr + 1}) − prefix(${ql})`,
            tracks: [
              track(
                "the array",
                arr,
                arr.map((_, k) => (k >= ql && k <= qr ? "result" : "dim")),
                arrTags,
              ),
              track("Fenwick buckets", bucketValues(), bucketStates([]), bucketTags),
              cell("two prefixes", `prefix(${qr + 1}) − prefix(${ql})`, "active", "each is a short bucket walk"),
            ],
            counters: [count("buckets", n), count("prefix walks", 0, 2)],
            legend: LEG,
            happened: `The wanted window is a[${ql}] through a[${qr}]. A prefix stops one slot before the window.`,
            why: "Subtracting the prefix that ends before the window removes everything outside the range.",
            codeLine: 27,
          });

          const right = prefixOf(qr + 1);
          const left = prefixOf(ql);

          steps.push({
            title: `prefix(${qr + 1}) = ${right.used.length ? right.used.map((j) => "b" + j + "=" + bit[j]).join(" + ") : "0"} = ${right.sum}`,
            tracks: [
              track("the array", arr, arr.map((_, k) => (k <= qr ? "done" : "dim")), arrTags),
              track("buckets read", bucketValues(), bucketStates(right.used), bucketTags),
              cell("prefix total", right.sum, "result", `first ${qr + 1} values`),
            ],
            counters: [count("buckets read", right.used.length), count("prefix total", right.sum)],
            legend: LEG,
            happened: right.used.length
              ? `Start at ${qr + 1}; the walk visits ${right.used.join(" then ")} and adds their bucket values.`
              : "The prefix is empty, so its total is 0.",
            why: `Those buckets partition a[0..${qr}], so their values add up to exactly the prefix sum.`,
            codeLine: 18,
          });

          steps.push({
            title: `prefix(${ql}) = ${left.used.length ? left.used.map((j) => "b" + j + "=" + bit[j]).join(" + ") : "0"} = ${left.sum}`,
            tracks: [
              track("the array", arr, arr.map((_, k) => (k < ql ? "done" : "dim")), arrTags),
              track("buckets read", bucketValues(), bucketStates(left.used), bucketTags),
              cell("prefix total", left.sum, "result", `first ${ql} values`),
            ],
            counters: [count("buckets read", right.used.length + left.used.length), count("prefix total", left.sum)],
            legend: LEG,
            happened: left.used.length
              ? `The second walk reads ${left.used.join(" then ")} and reaches ${left.sum}.`
              : `prefix(${ql}) is 0 because the window starts at a[0].`,
            why: "The left prefix is the part that must be removed from the right prefix.",
            codeLine: 18,
          });

          const answer = right.sum - left.sum;
          const direct = arr.slice(ql, qr + 1).reduce((a, b) => a + b, 0);
          steps.push({
            title: `Answer: a[${ql}..${qr}] sums to ${answer}`,
            tracks: [
              track(
                "the array",
                arr,
                arr.map((_, k) => (k >= ql && k <= qr ? "result" : "dim")),
                arrTags,
              ),
              track("Fenwick buckets", bucketValues(), bucketStates([]), bucketTags),
              cell("answer", answer, "result", `${right.sum} − ${left.sum}`),
            ],
            counters: [count("buckets", n), count("answer", answer)],
            legend: LEG,
            happened: `The two prefix totals give ${right.sum} − ${left.sum} = ${answer}. Adding the window directly also gives ${direct}.`,
            why: "The tree answered with a handful of bucket reads instead of re-adding the whole range.",
            codeLine: 27,
          });

          return steps;
        },
      },
    ],
  });

  /* ============================================================
     2. Count of Smaller Numbers After Self
     ============================================================ */
  V.register({
    id: "count-of-smaller-numbers-after-self",
    title: "Count of Smaller Numbers After Self",
    category: "Advanced Structures",
    difficulty: "Advanced",
    description: "For every position, count how many later values are strictly smaller than it.",
    input: { label: "The numbers", default: "5, 2, 6, 1", parse: "ints" },
    approaches: [
      {
        name: "Check Every Later Value",
        complexity: "O(n²) time, O(n) space",
        idea: [
          "For position i, walk every position j after it and compare a[j] with a[i]. Each comparison that finds a strictly smaller value adds one to counts[i].",
          "The method is a direct translation of the question, so it is the easiest version to trust and to check by hand.",
        ],
        problem: [
          "Every pair of positions is compared once, which becomes 780 comparisons for 40 values. On large inputs this quadratic cost dominates.",
        ],
        code: {
          c: `#include <stdio.h>

/* counts[i] = how many later values are smaller than a[i] */
void smaller_after(const int *a, int n, int *counts) {
    for (int i = 0; i < n; i++) {
        counts[i] = 0;
        for (int j = i + 1; j < n; j++)
            if (a[j] < a[i])
                counts[i]++;
    }
}

int main(void) {
    int a[] = {5, 2, 6, 1};
    int counts[4];
    smaller_after(a, 4, counts);
    for (int i = 0; i < 4; i++) printf("%d ", counts[i]);
    printf("\\n"); /* 2 1 1 0 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// counts[i] = number of later values smaller than a[i]
std::vector<int> smallerAfter(const std::vector<int>& a) {
    int n = static_cast<int>(a.size());
    std::vector<int> counts(n, 0);
    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j)
            if (a[j] < a[i]) ++counts[i];
    return counts;
}

int main() {
    std::vector<int> a{5, 2, 6, 1};
    for (int x : smallerAfter(a)) std::cout << x << ' '; // 2 1 1 0
    std::cout << '\\n';
}`,
        },
        steps(nums) {
          const arr = ints(nums, 12);
          const n = arr.length;
          const LEG = ["read", "compare", "good", "result", "done", "dim", "idle"];
          const steps = [];
          const counts = dashes(n);
          const arrTags = arr.map((_, i) => "a" + i);

          if (!n) {
            return [
              {
                title: "No numbers arrived",
                tracks: [cell("the numbers", "empty", "bad")],
                counters: [count("positions", 0), count("answer", "—")],
                legend: LEG,
                happened: "There are no positions, so no count can be written.",
                why: "Each answer belongs to one array position; without positions the result is empty.",
                codeLine: 3,
              },
              {
                title: "Add a few values, for example 5, 2, 6, 1",
                tracks: [cell("example", "5, 2, 6, 1", "idle", "four positions")],
                counters: [count("positions", 0), count("answer", "—")],
                legend: LEG,
                happened: "Four numbers produce four counts.",
                why: "The visual compares each value with the values that come after it.",
              },
              {
                title: "Answer: n/a — waiting for numbers",
                tracks: [cell("status", "nothing to compare", "bad")],
                counters: [count("positions", 0), count("answer", "—")],
                legend: LEG,
                happened: "No comparisons are possible on an empty row.",
                why: "The count for a position is defined relative to its later neighbours.",
              },
            ];
          }

          steps.push({
            title: `Count smaller values after each of ${n} number${n === 1 ? "" : "s"}`,
            tracks: [
              track("the numbers", arr, fill(n, "idle"), arrTags),
              track("smaller counts", counts, fill(n, "idle")),
            ],
            counters: [count("positions fixed", 0, n), count("comparisons", 0)],
            legend: LEG,
            happened: `The row holds ${arr.join(", ")}. Every count starts blank.`,
            why: "Position i only cares about positions to its right, so the scan direction is settled before any comparison.",
            codeLine: 3,
          });

          let comps = 0;
          for (let i = 0; i < n; i++) {
            let c = 0;
            counts[i] = 0;
            steps.push({
              title: n === 1 || i === n - 1
                ? `a[${i}] = ${arr[i]} has no later values`
                : `Start a[${i}] = ${arr[i]}: scan the values after it`,
              tracks: [
                track(
                  "the numbers",
                  arr,
                  arr.map((_, k) => (k < i ? "dim" : k === i ? "read" : "idle")),
                  arrTags,
                ),
                track(
                  "smaller counts",
                  counts,
                  counts.map((v, k) => (k < i ? "result" : k === i ? "read" : "idle")),
                ),
              ],
              counters: [count("positions fixed", i, n), count("comparisons", comps)],
              legend: LEG,
              happened: `The count for a[${i}] starts at 0 and will only look at indices beyond ${i}.`,
              why: "Values to the left were already answered and are not part of this question.",
              codeLine: 4,
            });

            for (let j = i + 1; j < n; j++) {
              comps++;
              const smaller = arr[j] < arr[i];
              if (smaller) {
                c++;
                counts[i] = c;
              }
              steps.push({
                title: `${arr[j]} ${smaller ? "<" : "≥"} ${arr[i]} → count for a[${i}] is ${c}`,
                tracks: [
                  track(
                    "the numbers",
                    arr,
                    arr.map((_, k) => (k < i ? "dim" : k === i ? "good" : k === j ? "compare" : "idle")),
                    arrTags,
                  ),
                  track(
                    "smaller counts",
                    counts,
                    counts.map((v, k) => (k < i ? "result" : k === i ? "read" : "idle")),
                  ),
                ],
                counters: [count("positions fixed", i, n), count("comparisons", comps)],
                legend: LEG,
                happened: smaller
                  ? `${arr[j]} is smaller than ${arr[i]}, so the count for position ${i} becomes ${c}.`
                  : `${arr[j]} is not smaller than ${arr[i]}, so the count for position ${i} stays ${c}.`,
                why: "Only strictly smaller values count; an equal value on the right is ignored.",
                codeLine: smaller ? 8 : 7,
              });
            }
          }

          const answerText = counts.join(", ");
          steps.push({
            title: `Answer: counts = ${answerText}`,
            tracks: [
              track("the numbers", arr, fill(n, "dim"), arrTags),
              track("smaller counts", counts, fill(n, "result")),
            ],
            counters: [count("positions fixed", n, n), count("answer", answerText)],
            legend: LEG,
            happened: `Every position has been compared with all positions after it, giving ${answerText}.`,
            why: "The quadratic scan is easy to follow but performed one comparison for every ordered pair.",
            codeLine: 16,
          });

          return steps;
        },
      },
      {
        name: "Fenwick Tree from the Right",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Compress the values into ranks: the smallest distinct value gets rank 1, the next rank 2, and so on. Equal values share a rank.",
          "Walk the array from right to left. Before inserting the current value, ask the Fenwick tree how many already-seen values have a smaller rank. That number is exactly counts[i].",
          "Then insert the current rank into the tree. The tree only needs one bucket per distinct value, and each step touches a logarithmic number of them.",
        ],
        problem: [
          "Values must be compressed first, so the method needs a sorted copy and a rank for every element. It also counts only what has been inserted, which is why the scan direction must be right to left.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>
#define MAXN 64
static int tree[MAXN + 1];
static int cmp(const void *x, const void *y) {
    int a = *(const int *)x, b = *(const int *)y;
    return (a > b) - (a < b);
}
static void add(int n, int i) {
    for (; i <= n; i += i & -i) tree[i] += 1;
}
static int prefix(int i) {
    int sum = 0;
    for (; i > 0; i -= i & -i) sum += tree[i];
    return sum;
}
int main(void) {
    int a[] = {5, 2, 6, 1}, n = 4, sorted[4], counts[4];
    for (int i = 0; i < n; i++) sorted[i] = a[i];
    qsort(sorted, n, sizeof(int), cmp);
    for (int i = n - 1; i >= 0; i--) {
        int r = 0;
        while (r < n && sorted[r] < a[i]) r++;
        counts[i] = prefix(r);     /* how many seen are smaller */
        add(n, r + 1);             /* ranks are 1-based */
    }
    for (int i = 0; i < n; i++) printf("%d ", counts[i]); /* 2 1 1 0 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <algorithm>
#include <vector>

// count smaller later values while scanning right to left
struct Fenwick {
    int n;
    std::vector<int> tree;
    explicit Fenwick(int size) : n(size), tree(size + 1, 0) {}
    void add(int i) { for (; i <= n; i += i & -i) ++tree[i]; }
    int prefix(int i) const {
        int sum = 0;
        for (; i > 0; i -= i & -i) sum += tree[i];
        return sum;
    }
};

int main() {
    std::vector<int> a{5, 2, 6, 1}, sorted = a;
    std::sort(sorted.begin(), sorted.end());
    Fenwick bit(static_cast<int>(a.size()));
    std::vector<int> counts(a.size(), 0);
    for (int i = static_cast<int>(a.size()) - 1; i >= 0; --i) {
        int r = static_cast<int>(std::lower_bound(sorted.begin(), sorted.end(), a[i]) - sorted.begin());
        counts[i] = bit.prefix(r);
        bit.add(r + 1);
    }
    for (int x : counts) std::cout << x << ' '; // 2 1 1 0
    std::cout << '\\n';
}`,
        },
        steps(nums) {
          const arr = ints(nums, 12);
          const n = arr.length;
          const LEG = ["read", "compare", "good", "result", "done", "dim", "idle"];
          const steps = [];

          if (!n) {
            return [
              {
                title: "No numbers to rank",
                tracks: [cell("the numbers", "empty", "bad")],
                counters: [count("ranked values", 0), count("answer", "—")],
                legend: LEG,
                happened: "An empty row has no ranks and no counts.",
                why: "The Fenwick tree is indexed by compressed value rank, so at least one value is needed.",
                codeLine: 17,
              },
              {
                title: "Add values such as 5, 2, 6, 1",
                tracks: [cell("example", "5, 2, 6, 1", "idle", "ranks 3, 2, 4, 1")],
                counters: [count("ranked values", 0), count("answer", "—")],
                legend: LEG,
                happened: "Four values compress into four ranks.",
                why: "Scanning from the right then asks only about ranks already inserted.",
              },
              {
                title: "Answer: n/a — nothing to count",
                tracks: [cell("status", "waiting for numbers", "bad")],
                counters: [count("ranked values", 0), count("answer", "—")],
                legend: LEG,
                happened: "There are no positions to fill.",
                why: "The right-to-left scan has no starting index.",
              },
            ];
          }

          const sorted = [...new Set(arr)].sort((a, b) => a - b);
          const m = sorted.length;
          const rankOf = (v) => sorted.indexOf(v) + 1;
          const ranks = arr.map(rankOf);
          const counts = dashes(n);
          const tree = new Array(m + 1).fill(0);
          const arrTags = arr.map((_, i) => "a" + i);
          const rankTags = ranks.map((r, i) => "a" + i + " → rank " + r);
          const bucketTags = [];
          for (let r = 1; r <= m; r++) bucketTags.push("rank " + r + ": value " + sorted[r - 1]);
          const bucketStates = (hot) =>
            tree.slice(1).map((v, k) => {
              if (hot && hot.indexOf(k + 1) >= 0) return "compare";
              return v !== 0 ? "done" : "idle";
            });
          const rankText = sorted.map((v, k) => `${v}→${k + 1}`).join(", ");

          steps.push({
            title: `Rank ${n} values, then scan from the right`,
            tracks: [
              track("the numbers", arr, fill(n, "idle"), arrTags),
              track("value ranks", dashes(n), fill(n, "idle"), rankTags),
              track("Fenwick buckets by rank", tree.slice(1), fill(m, "idle"), bucketTags),
              track("smaller counts", counts, fill(n, "idle")),
            ],
            counters: [count("values seen", 0, n), count("answer", "—")],
            legend: LEG,
            happened: `The row holds ${arr.join(", ")}. The tree has one bucket per distinct value and is empty.`,
            why: "Counting smaller values is easiest if values are replaced by their order, so equal values share a rank.",
            codeLine: 20,
          });

          steps.push({
            title: `Compress to ranks: ${rankText}`,
            tracks: [
              track("the numbers", arr, arr.map(() => "good"), arrTags),
              track("value ranks", ranks, fill(n, "result"), rankTags),
              track("sorted distinct", sorted, fill(m, "done"), sorted.map((v, k) => "rank " + (k + 1))),
              track("smaller counts", counts, fill(n, "idle")),
            ],
            counters: [count("distinct values", m, m), count("ranks assigned", n, n)],
            legend: LEG,
            happened: `Sorted distinct values are ${sorted.join(", ")}, so the ranks run from 1 to ${m}.`,
            why: "Comparing ranks preserves the order of the original values, which is all the counting question needs.",
            codeLine: 19,
          });

          const prefixOf = (p) => {
            const used = [];
            let sum = 0;
            let i = p;
            while (i > 0) {
              used.push(i);
              sum += tree[i];
              i -= i & -i;
            }
            return { sum, used };
          };

          for (let i = n - 1; i >= 0; i--) {
            const r = ranks[i];
            const q = prefixOf(r - 1);
            steps.push({
              title: `a[${i}] = ${arr[i]} (rank ${r}): ${q.sum} smaller value${q.sum === 1 ? "" : "s"} to the right`,
              tracks: [
                track(
                  "the numbers",
                  arr,
                  arr.map((_, k) => (k > i ? "done" : k === i ? "read" : "idle")),
                  arrTags,
                ),
                track("value ranks", ranks, ranks.map((_, k) => (k > i ? "done" : k === i ? "read" : "idle")), rankTags),
                track("Fenwick buckets by rank", tree.slice(1), bucketStates(q.used), bucketTags),
                track("smaller counts", counts, counts.map((v, k) => (k > i ? "result" : k === i ? "read" : "idle"))),
              ],
              counters: [count("values seen", n - 1 - i, n), count("smaller found", q.sum)],
              legend: LEG,
              happened: q.used.length
                ? `prefix(${r - 1}) reads ${q.used.map((x) => "bucket " + x + " = " + tree[x]).join(" + ")} = ${q.sum}.`
                : `Rank ${r} is the smallest possible, so prefix(${r - 1}) is 0.`,
              why: "Only ranks inserted so far are counted, and those are exactly the values that sit to the right.",
              codeLine: 23,
            });

            const touched = [];
            for (let j = r; j <= m; j += j & -j) {
              tree[j] += 1;
              touched.push(j);
            }
            counts[i] = q.sum;
            steps.push({
              title: `Record count ${q.sum} at a[${i}], then insert rank ${r}`,
              tracks: [
                track(
                  "the numbers",
                  arr,
                  arr.map((_, k) => (k > i ? "done" : k === i ? "good" : "idle")),
                  arrTags,
                ),
                track("value ranks", ranks, ranks.map((_, k) => (k > i ? "done" : k === i ? "result" : "idle")), rankTags),
                track("Fenwick buckets by rank", tree.slice(1), bucketStates(touched), bucketTags),
                track("smaller counts", counts, counts.map((v, k) => (k >= i ? "result" : "idle"))),
              ],
              counters: [count("values seen", n - i, n), count("buckets touched", touched.length)],
              legend: LEG,
              happened: `counts[${i}] is ${q.sum}; rank ${r} now joins buckets ${touched.map((x) => "b" + x).join(", ")}.`,
              why: "Inserting the current rank makes it visible to every position further left, which is where it belongs.",
              codeLine: 24,
            });
          }

          const answerText = counts.join(", ");
          steps.push({
            title: `Answer: counts = ${answerText}`,
            tracks: [
              track("the numbers", arr, fill(n, "dim"), arrTags),
              track("value ranks", ranks, fill(n, "dim"), rankTags),
              track("Fenwick buckets by rank", tree.slice(1), fill(m, "done"), bucketTags),
              track("smaller counts", counts, fill(n, "result")),
            ],
            counters: [count("values seen", n, n), count("answer", answerText)],
            legend: LEG,
            happened: `Scanning right to left produced ${answerText} in ${n} queries and ${n} inserts.`,
            why: "Each query and insert touched only a few buckets, so the work grew with n log n rather than n².",
            codeLine: 26,
          });

          return steps;
        },
      },
    ],
  });

  /* ============================================================
     3. Range Minimum Query
     ============================================================ */
  V.register({
    id: "range-minimum-query",
    title: "Range Minimum Query",
    category: "Advanced Structures",
    difficulty: "Intermediate",
    description: "Find the smallest value in a range, first by scanning and then with a segment tree.",
    input: { label: "The array | query left, query right", default: "4, 2, 7, 1, 3, 6 | 1, 4", parse: "tworows" },
    approaches: [
      {
        name: "Scan the Window",
        complexity: "O(k) time for a window of k values, O(1) space",
        idea: [
          "Take the first value in the window as the current best, then look at every remaining slot in the window. Whenever a smaller value appears, it becomes the new best.",
          "One pass over the window is enough, and no extra structure is needed. This is the version to reach for when queries are rare or the array never changes.",
        ],
        problem: [
          "A wide window costs a full scan, so many queries on a large array repeat most of the same comparisons. That repeated work is exactly what a segment tree removes.",
        ],
        code: {
          c: `#include <stdio.h>

/* smallest value in a[left..right], scanning every slot */
int range_min(const int *a, int left, int right) {
    int best = a[left];
    for (int i = left + 1; i <= right; i++)
        if (a[i] < best)
            best = a[i];
    return best;
}

int main(void) {
    int a[] = {4, 2, 7, 1, 3, 6};
    printf("%d\\n", range_min(a, 1, 4)); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// smallest value in a[left..right], scanning every slot
int rangeMin(const std::vector<int>& a, int left, int right) {
    int best = a[left];
    for (int i = left + 1; i <= right; ++i)
        if (a[i] < best) best = a[i];
    return best;
}

int main() {
    std::vector<int> a{4, 2, 7, 1, 3, 6};
    std::cout << rangeMin(a, 1, 4) << '\\n'; // 1
}`,
        },
        steps(parsed) {
          const raw = parsed && Array.isArray(parsed[0]) ? parsed[0] : [];
          const q = parsed && Array.isArray(parsed[1]) ? parsed[1] : [];
          const LEG = ["read", "compare", "good", "result", "done", "dim", "idle"];
          const arr = ints(raw, 12);
          const n = arr.length;
          const steps = [];

          if (!n) {
            return [
              {
                title: "No array values to search",
                tracks: [cell("the array", "empty", "bad")],
                counters: [count("slots checked", 0), count("answer", "—")],
                legend: LEG,
                happened: "There is no window to scan.",
                why: "A minimum needs at least one value.",
                codeLine: 3,
              },
              {
                title: "Add values such as 4, 2, 7, 1, 3, 6",
                tracks: [cell("example", "4, 2, 7, 1, 3, 6 | 1, 4", "idle", "array | query")],
                counters: [count("slots checked", 0), count("answer", "—")],
                legend: LEG,
                happened: "The left side is the array and the right side names the query window.",
                why: "The query indices are 0-based, matching the C array.",
              },
              {
                title: "Answer: n/a — waiting for an array",
                tracks: [cell("status", "nothing to scan", "bad")],
                counters: [count("slots checked", 0), count("answer", "—")],
                legend: LEG,
                happened: "An empty row has no minimum.",
                why: "The scan needs a first slot to seed the best value.",
              },
            ];
          }

          let l = q.length ? clamp(Math.trunc(q[0]), 0, n - 1) : 0;
          let r = q.length > 1 ? clamp(Math.trunc(q[1]), 0, n - 1) : n - 1;
          const swapped = l > r;
          if (swapped) { const t = l; l = r; r = t; }
          const arrTags = arr.map((_, i) => "a" + i);
          let best = arr[l];
          let bestAt = l;

          steps.push({
            title: `Find the minimum in a[${l}..${r}]`,
            tracks: [
              track("the array", arr, fill(n, "idle"), arrTags),
              cell("query window", `a[${l}]..a[${r}]`, "read", swapped ? "ends swapped into order" : "from the input"),
            ],
            counters: [count("slots checked", 0), count("best so far", "—")],
            legend: LEG,
            happened: `The window covers ${r - l + 1} slot${r - l + 1 === 1 ? "" : "s"}.${swapped ? " The two ends arrived reversed, so they were swapped." : ""}`,
            why: "Writing the window down first prevents the scan from wandering outside the requested range.",
            codeLine: 3,
          });

          steps.push({
            title: `Only a[${l}] through a[${r}] are candidates`,
            tracks: [
              track(
                "the array",
                arr,
                arr.map((_, k) => (k >= l && k <= r ? "result" : "dim")),
                arrTags,
              ),
              cell("window size", r - l + 1, "read", `indices ${l}..${r}`),
            ],
            counters: [count("slots checked", 0), count("best so far", "—")],
            legend: LEG,
            happened: `Values outside ${l}..${r} cannot win, however small they are.`,
            why: "The answer is defined only by the requested slice, so everything else can be faded out.",
            codeLine: 4,
          });

          steps.push({
            title: `Seed the best with a[${l}] = ${arr[l]}`,
            tracks: [
              track(
                "the array",
                arr,
                arr.map((_, k) => (k >= l && k <= r ? (k === l ? "read" : "idle") : "dim")),
                arrTags,
              ),
              cell("best so far", arr[l], "result", `at index ${l}`),
            ],
            counters: [count("slots checked", 1), count("best so far", arr[l])],
            legend: LEG,
            happened: `The first slot in the window becomes the value to beat.`,
            why: "A scan needs a starting candidate; the first window value is the cheapest choice.",
            codeLine: 4,
          });

          for (let i = l + 1; i <= r; i++) {
            const previous = best;
            const smaller = arr[i] < previous;
            if (smaller) { best = arr[i]; bestAt = i; }
            steps.push({
              title: `${arr[i]} ${smaller ? "<" : "≥"} ${previous} → ${smaller ? "new best " + best : "keep " + best}`,
              tracks: [
                track(
                  "the array",
                  arr,
                  arr.map((_, k) => {
                    if (k < l || k > r) return "dim";
                    if (k === i) return "compare";
                    if (k === bestAt) return "good";
                    return "idle";
                  }),
                  arrTags,
                ),
                cell("best so far", best, "result", `at index ${bestAt}`),
              ],
              counters: [count("slots checked", i - l + 1), count("best so far", best)],
              legend: LEG,
              happened: smaller
                ? `${arr[i]} beats the previous best ${previous}, so index ${i} takes over.`
                : `${arr[i]} does not beat ${previous}, so the current best stays.`,
              why: "One comparison per slot is enough: either the newcomer is smaller or it is ignored.",
              codeLine: smaller ? 7 : 6,
            });
          }

          steps.push({
            title: `Smallest value is ${best} at index ${bestAt}`,
            tracks: [
              track(
                "the array",
                arr,
                arr.map((_, k) => (k === bestAt ? "result" : k >= l && k <= r ? "done" : "dim")),
                arrTags,
              ),
              cell("best", best, "result", `index ${bestAt}`),
            ],
            counters: [count("slots checked", r - l + 1), count("best so far", best)],
            legend: LEG,
            happened: `All ${r - l + 1} slots in the window were checked and ${best} was never beaten.`,
            why: "Once the window is exhausted, the stored best is the minimum by definition.",
            codeLine: 5,
          });

          steps.push({
            title: `Answer: ${best}`,
            tracks: [
              track(
                "the array",
                arr,
                arr.map((_, k) => (k === bestAt ? "result" : "dim")),
                arrTags,
              ),
              cell("minimum", best, "result", `a[${bestAt}]`),
            ],
            counters: [count("slots checked", r - l + 1), count("answer", best)],
            legend: LEG,
            happened: `The minimum of a[${l}..${r}] is ${best}.`,
            why: "The scan used one pass and no extra storage beyond the best value and its index.",
            codeLine: 13,
          });

          return steps;
        },
      },
      {
        name: "Segment Tree",
        complexity: "O(n) build, O(log n) query, O(n) space",
        idea: [
          "Store the minimum of every aligned segment in a tree. The root covers the whole array, each node splits its segment in half, and a leaf holds one array value.",
          "Every internal node is the smaller of its two children. Once the tree is built, a query walks down and collects the few whole segments that fit inside the window.",
          "The window is covered by at most two segments per level, so a query touches O(log n) nodes instead of scanning the range.",
        ],
        problem: [
          "The tree allocates about four slots per array value, and a point update must repair every ancestor up to the root.",
          "The recursive query has more moving parts than a scan: partial overlaps must be split, and a disjoint branch must return a neutral value such as infinity.",
        ],
        code: {
          c: `#include <stdio.h>

#define MAXN 64
static int tree[4 * MAXN];

static int build(const int *a, int node, int lo, int hi) {
    if (lo == hi) return tree[node] = a[lo];
    int mid = (lo + hi) / 2;
    int l = build(a, node * 2, lo, mid);
    int r = build(a, node * 2 + 1, mid + 1, hi);
    return tree[node] = l < r ? l : r;
}

static int query(int node, int lo, int hi, int l, int r) {
    if (r < lo || hi < l) return 1 << 30;      /* disjoint */
    if (l <= lo && hi <= r) return tree[node]; /* fully inside */
    int mid = (lo + hi) / 2;
    int left = query(node * 2, lo, mid, l, r);
    int right = query(node * 2 + 1, mid + 1, hi, l, r);
    return left < right ? left : right;
}

int main(void) {
    int a[] = {4, 2, 7, 1, 3, 6};
    build(a, 1, 0, 5);
    printf("%d\\n", query(1, 0, 5, 1, 4)); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

// segment tree of minima; node 1 covers [0, n)
struct MinTree {
    int n;
    std::vector<int> t;
    explicit MinTree(const std::vector<int>& a)
        : n(static_cast<int>(a.size())), t(4 * std::max(1, n)) {
        build(a, 1, 0, n - 1);
    }
    void build(const std::vector<int>& a, int node, int lo, int hi) {
        if (lo == hi) { t[node] = a[lo]; return; }
        int mid = (lo + hi) / 2;
        build(a, node * 2, lo, mid);
        build(a, node * 2 + 1, mid + 1, hi);
        t[node] = std::min(t[node * 2], t[node * 2 + 1]);
    }
    int query(int node, int lo, int hi, int l, int r) const {
        if (r < lo || hi < l) return 1 << 30;
        if (l <= lo && hi <= r) return t[node];
        int mid = (lo + hi) / 2;
        return std::min(query(node * 2, lo, mid, l, r),
                        query(node * 2 + 1, mid + 1, hi, l, r));
    }
};

int main() {
    std::vector<int> a{4, 2, 7, 1, 3, 6};
    MinTree tree(a);
    std::cout << tree.query(1, 0, 5, 1, 4) << '\\n'; // 1
}`,
        },
        steps(parsed) {
          const raw = parsed && Array.isArray(parsed[0]) ? parsed[0] : [];
          const q = parsed && Array.isArray(parsed[1]) ? parsed[1] : [];
          const LEG = ["read", "compare", "good", "result", "done", "dim", "idle"];
          const arr = ints(raw, 12);
          const n = arr.length;
          const steps = [];

          if (!n) {
            return [
              {
                title: "No leaves to build from",
                tracks: [cell("the array", "empty", "bad")],
                counters: [count("segments", 0), count("answer", "—")],
                legend: LEG,
                happened: "A segment tree needs at least one array slot.",
                why: "Leaves copy array values, so an empty array leaves the tree empty.",
                codeLine: 6,
              },
              {
                title: "Add values such as 4, 2, 7, 1, 3, 6",
                tracks: [cell("example", "4, 2, 7, 1, 3, 6 | 1, 4", "idle", "array | query")],
                counters: [count("segments", 0), count("answer", "—")],
                legend: LEG,
                happened: "Six values become six leaves and five internal segments.",
                why: "Each internal node needs two children, so the number of segments is bounded by the array size.",
              },
              {
                title: "Answer: n/a — nothing to build",
                tracks: [cell("status", "waiting for an array", "bad")],
                counters: [count("segments", 0), count("answer", "—")],
                legend: LEG,
                happened: "There is no range to query.",
                why: "The query window describes indices into the missing array.",
              },
            ];
          }

          let l = q.length ? clamp(Math.trunc(q[0]), 0, n - 1) : 0;
          let r = q.length > 1 ? clamp(Math.trunc(q[1]), 0, n - 1) : n - 1;
          const swapped = l > r;
          if (swapped) { const t = l; l = r; r = t; }
          const arrTags = arr.map((_, i) => "a" + i);

          const nodes = [];
          let seq = 0;
          const make = (lo, hi, depth) => {
            const node = { id: "s" + seq++, lo, hi, depth, val: 0, stage: 0, l: null, r: null };
            nodes.push(node);
            if (lo === hi) {
              node.val = arr[lo];
              node.stage = 0;
              return node;
            }
            const mid = (lo + hi) >> 1;
            node.l = make(lo, mid, depth + 1);
            node.r = make(mid + 1, hi, depth + 1);
            node.val = Math.min(node.l.val, node.r.val);
            node.stage = Math.max(node.l.stage, node.r.stage) + 1;
            return node;
          };
          const root = make(0, n - 1, 0);
          const maxStage = Math.max(...nodes.map((nd) => nd.stage));
          const maxDepth = Math.max(...nodes.map((nd) => nd.depth));

          const segRows = (revealed, stateOf) => {
            const rows = [];
            for (let d = 0; d <= maxDepth; d++) {
              const list = nodes.filter((nd) => nd.depth === d).sort((a, b) => a.lo - b.lo);
              if (!list.length) continue;
              rows.push({
                label: `depth ${d} segments`,
                cells: list.map((nd) => ({
                  v: nd.stage <= revealed ? nd.val : "?",
                  state: stateOf ? stateOf(nd) : nd.stage <= revealed ? "done" : "idle",
                  tag: `${nd.lo}-${nd.hi}`,
                })),
              });
            }
            return rows;
          };

          steps.push({
            title: `Build a segment tree over ${n} value${n === 1 ? "" : "s"}`,
            tracks: [
              track("the array", arr, arr.map(() => "read"), arrTags),
              ...segRows(-1, null),
              cell("query", `a[${l}..${r}]`, "idle", swapped ? "ends swapped" : "from the input"),
            ],
            counters: [count("segments built", 0, nodes.length), count("answer", "—")],
            legend: LEG,
            happened: `Every segment is unknown so far. The tree will have ${nodes.length} nodes for ${n} leaves.`,
            why: "Building from the leaves upward guarantees a parent is never filled before both of its children.",
            codeLine: 5,
          });

          for (let st = 0; st <= maxStage; st++) {
            const group = nodes
              .filter((nd) => nd.stage === st)
              .sort((a, b) => a.lo - b.lo || a.hi - b.hi);
            const shown = group.slice(0, 5).map((nd) => `[${nd.lo}-${nd.hi}] = ${nd.val}`).join(", ");
            const more = group.length > 5 ? `, plus ${group.length - 5} more` : "";
            steps.push({
              title:
                st === 0
                  ? `Leaves copy the array: ${shown}${more}`
                  : `Parents take the smaller child: ${shown}${more}`,
              tracks: [
                track("the array", arr, arr.map(() => "done"), arrTags),
                ...segRows(st, (nd) => (nd.stage === st ? "result" : nd.stage < st ? "done" : "idle")),
              ],
              counters: [count("segments built", nodes.filter((nd) => nd.stage <= st).length, nodes.length)],
              legend: LEG,
              happened:
                st === 0
                  ? "Each leaf now holds exactly one array value."
                  : "Each of these segments is the minimum of its two finished children.",
              why: "This level can only be filled after the level below it, so the build proceeds one layer at a time.",
              codeLine: st === 0 ? 6 : 10,
            });
          }

          const collected = [];
          const walk = (nd) => {
            if (r < nd.lo || nd.hi < l) return;
            if (l <= nd.lo && nd.hi <= r) { collected.push(nd); return; }
            if (nd.l) { walk(nd.l); walk(nd.r); }
          };
          walk(root);

          steps.push({
            title: `Query a[${l}..${r}]: collect whole segments`,
            tracks: [
              track(
                "the array",
                arr,
                arr.map((_, k) => (k >= l && k <= r ? "result" : "dim")),
                arrTags,
              ),
              ...segRows(maxStage, (nd) => (nd === root ? "read" : "dim")),
            ],
            counters: [count("candidates", 0), count("best so far", "—")],
            legend: LEG,
            happened: `A segment wholly inside ${l}..${r} can be used directly; a segment that only overlaps must be split.`,
            why: "Collecting aligned segments is what keeps the query logarithmic instead of linear.",
            codeLine: 15,
          });

          let best = Infinity;
          let found = 0;
          for (const nd of collected) {
            found++;
            best = Math.min(best, nd.val);
            steps.push({
              title: `Whole segment ${nd.lo}-${nd.hi} gives ${nd.val}`,
              tracks: [
                track(
                  "the array",
                  arr,
                  arr.map((_, k) => (k >= l && k <= r ? "done" : "dim")),
                  arrTags,
                ),
                ...segRows(maxStage, (s) => (s === nd ? "good" : collected.indexOf(s) >= 0 && collected.indexOf(s) < found ? "result" : "dim")),
                cell("candidate", nd.val, "result", `best now ${best}`),
              ],
              counters: [count("candidates", found, collected.length), count("best so far", best)],
              legend: LEG,
              happened: `Segment [${nd.lo}-${nd.hi}] lies fully inside the window, so its stored minimum ${nd.val} is a valid candidate.`,
              why: "The answer is the minimum over the collected segments; no value inside them needs to be visited individually.",
              codeLine: 15,
            });
          }

          if (!collected.length) {
            steps.push({
              title: "The window collected no segments",
              tracks: [
                track("the array", arr, fill(n, "bad"), arrTags),
                ...segRows(maxStage, () => "dim"),
                cell("best so far", "—", "bad", "empty window"),
              ],
              counters: [count("candidates", 0), count("best so far", "—")],
              legend: LEG,
              happened: "No aligned segment fitted the window, which can only happen when the window itself is empty.",
              why: "A non-empty range always contains at least one leaf, and leaves are valid segments.",
              codeLine: 15,
            });
          }

          steps.push({
            title: `Answer: minimum is ${best}`,
            tracks: [
              track(
                "the array",
                arr,
                arr.map((_, k) => (k >= l && k <= r ? "result" : "dim")),
                arrTags,
              ),
              ...segRows(maxStage, (nd) => (collected.indexOf(nd) >= 0 ? "result" : "dim")),
              cell("minimum", best, "result", `from ${collected.length} segment${collected.length === 1 ? "" : "s"}`),
            ],
            counters: [count("candidates", collected.length), count("answer", best)],
            legend: LEG,
            happened: `The collected segments were ${collected.map((nd) => `[${nd.lo}-${nd.hi}]`).join(", ")}; the smallest stored value is ${best}.`,
            why: "Every array slot in the window belongs to exactly one collected segment, so their minimum is the range minimum.",
            codeLine: 25,
          });

          return steps;
        },
      },
    ],
  });

  /* ============================================================
     4. Range Addition
     ============================================================ */
  V.register({
    id: "range-addition",
    title: "Range Addition",
    category: "Advanced Structures",
    difficulty: "Intermediate",
    description: "Apply many add-to-a-range updates with two marks each, then one prefix pass.",
    input: { label: "Length, then l r +value groups", default: "6, 1, 3, 2, 2, 4, 3, 0, 2, -2", parse: "ints" },
    approaches: [
      {
        name: "Difference Array",
        complexity: "O(n + q) time, O(n) space",
        idea: [
          "An update that adds v across [l, r] can be written with just two marks on a difference row: +v at position l, and −v at position r+1.",
          "After all updates are marked, one left-to-right prefix pass turns the difference row into the final array. A running total absorbs the +v at l and cancels it again just after r.",
          "The array is never touched between updates, so q updates plus one rebuild cost only n + q work.",
        ],
        problem: [
          "The trick fits addition only; a range assignment or a range minimum needs a different structure. The final array is also unavailable until the prefix pass runs, which is a problem for interleaved queries.",
        ],
        code: {
          c: `#include <stdio.h>

/* each update touches two slots, then one prefix pass rebuilds the row */
void range_add(int *diff, int n, int l, int r, int v) {
    diff[l] += v;
    if (r + 1 <= n) diff[r + 1] -= v;   /* diff has n + 1 slots */
}

void build_result(int *diff, int n, int *out) {
    int run = 0;
    for (int i = 0; i < n; i++) {
        run += diff[i];
        out[i] = run;
    }
}

int main(void) {
    int n = 6, diff[7] = {0}, out[6];
    range_add(diff, n, 1, 3, 2);
    range_add(diff, n, 2, 4, 3);
    range_add(diff, n, 0, 2, -2);
    build_result(diff, n, out);
    for (int i = 0; i < n; i++) printf("%d ", out[i]); /* -2 0 3 5 3 0 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// mark +v at l and -v just after r
void rangeAdd(std::vector<int>& diff, int l, int r, int v) {
    diff[l] += v;
    diff[r + 1] -= v;
}

std::vector<int> buildResult(const std::vector<int>& diff, int n) {
    std::vector<int> out(n);
    int run = 0;
    for (int i = 0; i < n; ++i)
        out[i] = run += diff[i];
    return out;
}

int main() {
    int n = 6;
    std::vector<int> diff(n + 1, 0);
    rangeAdd(diff, 1, 3, 2);
    rangeAdd(diff, 2, 4, 3);
    rangeAdd(diff, 0, 2, -2);
    for (int x : buildResult(diff, n)) std::cout << x << ' '; // -2 0 3 5 3 0
    std::cout << '\\n';
}`,
        },
        steps(parsed) {
          const all = ints(parsed, 40);
          const n = all.length ? clamp(all[0], 0, 10) : 0;
          const LEG = ["read", "compare", "active", "done", "result", "good", "bad", "dim", "idle"];
          const steps = [];

          if (!n) {
            return [
              {
                title: "Length 0 — no slots to add to",
                tracks: [cell("the array", "empty", "bad")],
                counters: [count("updates applied", 0), count("answer", "—")],
                legend: LEG,
                happened: "The first input value is the array length, and it is zero.",
                why: "Range updates need at least one index inside the array.",
                codeLine: 3,
              },
              {
                title: "Use a length followed by l r value groups",
                tracks: [cell("example", "6, 1, 3, 2, 2, 4, 3, 0, 2, -2", "idle", "n=6 and three updates")],
                counters: [count("updates applied", 0), count("answer", "—")],
                legend: LEG,
                happened: "Each group of three numbers describes one range update.",
                why: "Keeping the length first lets the demo size the arrays before reading the updates.",
              },
              {
                title: "Answer: n/a — length must be at least 1",
                tracks: [cell("status", "waiting for a positive length", "bad")],
                counters: [count("updates applied", 0), count("answer", "—")],
                legend: LEG,
                happened: "No update can be placed in an empty array.",
                why: "The difference row would have exactly one slot and no prefix to build.",
              },
            ];
          }

          const ups = [];
          for (let i = 1; i + 2 < all.length && ups.length < 6; i += 3) {
            let l = clamp(all[i], 0, n - 1);
            let r = clamp(all[i + 1], 0, n - 1);
            if (l > r) { const t = l; l = r; r = t; }
            ups.push({ l, r, v: all[i + 2] });
          }
          const ignored = all.length > 1 + ups.length * 3;
          const diff = new Array(n + 1).fill(0);
          const result = dashes(n);
          const updateLabels = ups.length
            ? ups.map((u) => `a[${u.l}..${u.r}] ${u.v >= 0 ? "+" : ""}${u.v}`)
            : ["no updates given"];

          steps.push({
            title: `Zero the difference row for ${n} slot${n === 1 ? "" : "s"}`,
            tracks: [
              track("updates", updateLabels, fill(updateLabels.length, "idle")),
              track("difference row", diff, fill(diff.length, "idle")),
              track("final array", result, fill(n, "idle")),
            ],
            counters: [count("updates applied", 0, ups.length), count("answer", "—")],
            legend: LEG,
            happened: `There are ${ups.length} range update${ups.length === 1 ? "" : "s"}. Both the difference row and the final array start at zero.`,
            why: "The difference row is one slot longer than the array so that a cancel mark can land just past the last position.",
            codeLine: 17,
          });

          if (!ups.length) {
            steps.push({
              title: "No complete update group was given",
              tracks: [
                track("updates", updateLabels, ["bad"]),
                track("difference row", diff, fill(diff.length, "dim")),
                track("final array", result, fill(n, "dim")),
              ],
              counters: [count("updates applied", 0, 0), count("answer", "—")],
              legend: LEG,
              happened: "A group needs three numbers: left, right and the value to add.",
              why: "Without a complete group there is nothing to mark, so the final array would stay all zero.",
              codeLine: 3,
            });
          }

          ups.forEach((u, k) => {
            steps.push({
              title: `Update ${k + 1}: add ${signed(u.v)} across a[${u.l}..${u.r}]`,
              tracks: [
                track("updates", updateLabels, updateLabels.map((_, x) => (x < k ? "done" : x === k ? "read" : "idle"))),
                track("difference row", diff, diff.map(() => "idle")),
                track("final array", result, fill(n, "dim")),
                cell("two marks", `d[${u.l}] += ${signed(u.v)}, d[${u.r + 1}] -= ${signed(u.v)}`, "active", "no array slots touched"),
              ],
              counters: [count("updates applied", k, ups.length), count("array slots touched", 0)],
              legend: LEG,
              happened: `${signed(u.v)} must reach positions ${u.l} through ${u.r} only, so one mark starts it and one mark stops it.`,
              why: "The prefix pass will add the value from l onward, and the cancel mark at r+1 removes it again.",
              codeLine: 4,
            });

            diff[u.l] += u.v;
            diff[u.r + 1] -= u.v;
            steps.push({
              title: `d[${u.l}] = ${diff[u.l]}, d[${u.r + 1}] = ${diff[u.r + 1]}`,
              tracks: [
                track("updates", updateLabels, updateLabels.map((_, x) => (x <= k ? "done" : "idle"))),
                track(
                  "difference row",
                  diff,
                  diff.map((_, x) => (x === u.l || x === u.r + 1 ? "result" : diff[x] !== 0 ? "done" : "idle")),
                ),
                track("final array", result, fill(n, "dim")),
              ],
              counters: [count("updates applied", k + 1, ups.length), count("marks written", 2 * (k + 1))],
              legend: LEG,
              happened: `The two marks are stored: ${signed(u.v)} at ${u.l} and ${signed(-u.v)} at ${u.r + 1}. The final array is still untouched.`,
              why: "Two slots encode an entire range because every later prefix sum sees the start mark and then the stop mark.",
              codeLine: 5,
            });
          });

          let run = 0;
          for (let i = 0; i < n; i++) {
            const before = run;
            run += diff[i];
            result[i] = run;
            steps.push({
              title: `prefix[${i}] = ${before} + ${diff[i]} = ${run}`,
              tracks: [
                track("updates", updateLabels, fill(updateLabels.length, "done")),
                track(
                  "difference row",
                  diff,
                  diff.map((_, x) => (x === i ? "read" : x < i ? "done" : "idle")),
                ),
                track("final array", result, result.map((v, x) => (x < i ? "done" : x === i ? "result" : "idle"))),
              ],
              counters: [count("slots filled", i + 1, n), count("running total", run)],
              legend: LEG,
              happened: `The running total changes by d[${i}] = ${diff[i]} and becomes ${run}, which is a[${i}].`,
              why: "Every start mark adds its value for all following slots, and every stop mark removes it at exactly the right place.",
              codeLine: 11,
            });
          }

          steps.push({
            title: `Answer: ${result.map((v) => (v === "—" ? 0 : v)).join(", ")}`,
            tracks: [
              track("updates", updateLabels, fill(updateLabels.length, "good")),
              track("difference row", diff, fill(diff.length, "done")),
              track("final array", result, fill(n, "result")),
              cell("answer", `a = [${result.join(", ")}]`, "result", "one prefix pass"),
            ],
            counters: [count("updates applied", ups.length), count("answer", `[${result.join(", ")}]`)],
            legend: LEG,
            happened:
              `All ${ups.length} range updates are folded into the final array` +
              (ignored ? " (a trailing incomplete group was ignored)." : "."),
            why: "The two-mark encoding turned q range updates into q pairs of writes plus a single prefix pass.",
            codeLine: 22,
          });

          return steps;
        },
      },
    ],
  });

  /* ============================================================
     5. My Calendar I
     ============================================================ */
  V.register({
    id: "my-calendar-i",
    title: "My Calendar I",
    category: "Advanced Structures",
    difficulty: "Intermediate",
    description: "Accept a booking while it shares no time with any already accepted half-open interval.",
    input: { label: "Booking pairs start,end", default: "10,20 15,25 20,30 5,10", parse: "pairs" },
    approaches: [
      {
        name: "Check Every Accepted Booking",
        complexity: "O(n) per request, O(n) space",
        idea: [
          "Keep the accepted bookings in a list. For each new request, compare it with every accepted interval using one overlap test: the request starts before the stored one ends, and the stored one starts before the request ends.",
          "If no stored interval passes that test, the request is free and can be added. Because the list is kept in start order, the first clash is also easy to spot.",
          "This is enough for the single-booking version: there is no need to count overlaps, only to notice whether at least one exists.",
        ],
        problem: [
          "Each request may scan every accepted booking, so n requests cost O(n²). A balanced tree keyed by start would cut the lookup to O(log n) at the cost of more bookkeeping.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct { int start, end; } Interval;

/* half-open [start, end): touching ends do not collide */
int can_book(Interval *booked, int n, int start, int end) {
    for (int i = 0; i < n; i++)
        if (start < booked[i].end && booked[i].start < end)
            return 0;
    return 1;
}

int main(void) {
    Interval booked[16];
    int n = 0;
    int requests[4][2] = {{10, 20}, {15, 25}, {20, 30}, {5, 10}};
    for (int k = 0; k < 4; k++) {
        if (can_book(booked, n, requests[k][0], requests[k][1])) {
            booked[n].start = requests[k][0];
            booked[n].end = requests[k][1];
            n++;
        }
    }
    printf("%d\\n", n); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

struct Interval { int start, end; };

// half-open intervals: touching endpoints are allowed
bool clash(const Interval& a, const Interval& b) {
    return a.start < b.end && b.start < a.end;
}

int main() {
    std::vector<Interval> booked;
    std::vector<Interval> requests{{10, 20}, {15, 25}, {20, 30}, {5, 10}};
    for (const auto& q : requests) {
        bool ok = true;
        for (const auto& b : booked)
            if (clash(q, b)) ok = false;
        if (ok) booked.push_back(q);
    }
    std::cout << booked.size() << '\\n'; // 3
}`,
        },
        steps(pairs) {
          const reqs = pairList(pairs, 8);
          const n = reqs.length;
          const LEG = ["read", "compare", "good", "bad", "result", "done", "dim", "idle"];
          const steps = [];
          const labels = reqs.map((r, i) => `#${i + 1} ${span(r)}`);

          if (!n) {
            return [
              {
                title: "No booking requests arrived",
                tracks: [cell("requests", "empty", "bad")],
                counters: [count("requests seen", 0), count("accepted", 0)],
                legend: LEG,
                happened: "The input contains no start,end pairs.",
                why: "A booking needs a start and an end before it can be tested.",
                codeLine: 5,
              },
              {
                title: "Use pairs such as 10,20 15,25 20,30",
                tracks: [cell("example", "10,20 15,25 20,30", "idle", "each pair is one booking")],
                counters: [count("requests seen", 0), count("accepted", 0)],
                legend: LEG,
                happened: "Each pair is read as the half-open interval [start, end).",
                why: "Half-open intervals let one booking end exactly when the next one starts.",
              },
              {
                title: "Answer: 0 bookings accepted",
                tracks: [cell("answer", 0, "bad", "no requests")],
                counters: [count("requests seen", 0), count("answer", 0)],
                legend: LEG,
                happened: "With no intervals there is nothing to accept.",
                why: "The accepted count starts and remains at zero.",
              },
            ];
          }

          let booked = [];

          steps.push({
            title: `Test ${n} booking request${n === 1 ? "" : "s"}`,
            tracks: [
              track("requests", labels, fill(n, "idle")),
              listRow("accepted (half-open)", booked),
            ],
            counters: [count("requests seen", 0, n), count("accepted", 0)],
            legend: LEG,
            happened: `The requests are ${reqs.map(span).join(", ")}. Nothing is booked yet.`,
            why: "A request is accepted only when it does not overlap any interval already on the calendar.",
            codeLine: 5,
          });

          reqs.forEach((q, k) => {
            const hits = booked.filter((b) => clash(q, b));
            steps.push({
              title: hits.length
                ? `#${k + 1} ${span(q)} hits ${hits.map(span).join(" and ")}`
                : `#${k + 1} ${span(q)} overlaps none of ${booked.length} booking${booked.length === 1 ? "" : "s"}`,
              tracks: [
                track("requests", labels, labels.map((_, x) => (x < k ? "done" : x === k ? "read" : "idle"))),
                listRow("accepted (half-open)", booked, (b) => (hits.indexOf(b) >= 0 ? "compare" : "done")),
                cell(
                  "overlap test",
                  hits.length ? `${hits.length} clash${hits.length === 1 ? "" : "es"}` : "free",
                  hits.length ? "bad" : "good",
                  "start < their end and their start < end",
                ),
              ],
              counters: [count("requests seen", k + 1, n), count("checks", booked.length)],
              legend: LEG,
              happened: hits.length
                ? `The interval ${span(hits[0])} already owns part of ${span(q)}, because ${q.s} < ${hits[0].e} and ${hits[0].s} < ${q.e}.`
                : `No accepted interval satisfies both overlap conditions, so ${span(q)} is free.`,
              why: "Two half-open intervals overlap exactly when each one starts before the other ends.",
              codeLine: 6,
            });

            if (hits.length) {
              steps.push({
                title: `Reject ${span(q)} — the slot is taken`,
                tracks: [
                  track("requests", labels, labels.map((_, x) => (x < k ? "done" : x === k ? "bad" : "idle"))),
                  listRow("accepted (half-open)", booked, (b) => (hits.indexOf(b) >= 0 ? "compare" : "done")),
                  cell("decision", "not booked", "bad", `${hits.length} collision${hits.length === 1 ? "" : "s"}`),
                ],
                counters: [count("requests seen", k + 1, n), count("rejected", k + 1 - booked.length)],
                legend: LEG,
                happened: `${span(q)} would double-book ${hits.map(span).join(", ")}, so it is refused.`,
                why: "The calendar never stores two overlapping intervals in this version; a refusal keeps that promise.",
                codeLine: 7,
              });
              return;
            }

            booked.push(q);
            booked.sort((a, b) => a.s - b.s);
            steps.push({
              title: `Accept ${span(q)} → ${booked.length} booking${booked.length === 1 ? "" : "s"}`,
              tracks: [
                track("requests", labels, labels.map((_, x) => (x < k ? "done" : x === k ? "good" : "idle"))),
                listRow("accepted (half-open)", booked, (b) => (b === q ? "result" : "done"), (b) => "start " + b.s),
                cell("decision", "booked", "good", "kept in start order"),
              ],
              counters: [count("requests seen", k + 1, n), count("accepted", booked.length)],
              legend: LEG,
              happened: `${span(q)} has no conflict, so it joins the calendar after ${booked.filter((b) => b.s < q.s).length} earlier booking${booked.filter((b) => b.s < q.s).length === 1 ? "" : "s"}.`,
              why: "Keeping the list sorted by start makes it obvious where the new interval belongs.",
              codeLine: 18,
            });
          });

          const answer = booked.length;
          steps.push({
            title: `Answer: ${answer} of ${n} booking${n === 1 ? "" : "s"} accepted`,
            tracks: [
              track("requests", labels, fill(n, "done")),
              listRow("accepted (half-open)", booked, () => "result"),
              cell("answer", answer, "result", "non-overlapping"),
            ],
            counters: [count("requests seen", n, n), count("answer", answer)],
            legend: LEG,
            happened: `The calendar ends with ${answer} non-overlapping interval${answer === 1 ? "" : "s"}: ${booked.map(span).join(", ") || "none"}.`,
            why: "Every accepted request passed the overlap test against all intervals already stored.",
            codeLine: 23,
          });

          return steps;
        },
      },
    ],
  });

  /* ============================================================
     6. My Calendar II
     ============================================================ */
  V.register({
    id: "my-calendar-ii",
    title: "My Calendar II",
    category: "Advanced Structures",
    difficulty: "Advanced",
    description: "Allow double bookings but refuse any request that would create a triple booking.",
    input: { label: "Booking pairs start,end", default: "10,20 50,60 10,40 5,15 5,10", parse: "pairs" },
    approaches: [
      {
        name: "Keep Single and Double Lists",
        complexity: "O(n²) time, O(n) space",
        idea: [
          "Maintain two lists. The first holds intervals covered exactly once, the second holds regions covered exactly twice.",
          "A new request is checked against the double list first: any overlap there would create a triple, so the request is refused immediately.",
          "Otherwise the request is compared with the single list. Each overlap becomes a new region for the double list, and the request itself joins the single list.",
        ],
        problem: [
          "Both lists can grow with the number of requests, and each booking scans them from the start, so the total cost is quadratic. Overlapping double regions may also be stored in several pieces.",
        ],
        code: {
          c: `#include <stdio.h>

typedef struct { int start, end; } Seg;

static int clash(Seg a, Seg b) {
    return a.start < b.end && b.start < a.end;
}

int main(void) {
    Seg one[16], two[16];
    int n1 = 0, n2 = 0;
    Seg req[] = {{10, 20}, {50, 60}, {10, 40}, {5, 15}, {5, 10}};
    for (int k = 0; k < 5; k++) {
        Seg q = req[k];
        int ok = 1;
        for (int i = 0; i < n2; i++)
            if (clash(q, two[i])) ok = 0;
        for (int i = 0; ok && i < n1; i++)
            if (clash(q, one[i])) {
                Seg o = {q.start > one[i].start ? q.start : one[i].start,
                         q.end < one[i].end ? q.end : one[i].end};
                if (n2 < 16) two[n2++] = o;
            }
        if (ok) one[n1++] = q;
    }
    printf("%d\\n", n1); /* 4 accepted */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

struct Seg { int start, end; };

bool clash(Seg a, Seg b) {
    return a.start < b.end && b.start < a.end;
}

int main() {
    std::vector<Seg> one, two;
    std::vector<Seg> req{{10, 20}, {50, 60}, {10, 40}, {5, 15}, {5, 10}};
    for (Seg q : req) {
        bool ok = true;
        for (Seg d : two)
            if (clash(q, d)) ok = false;
        for (int i = 0; ok && i < static_cast<int>(one.size()); ++i) {
            if (!clash(q, one[i])) continue;
            two.push_back({std::max(q.start, one[i].start),
                           std::min(q.end, one[i].end)});
        }
        if (ok) one.push_back(q);
    }
    std::cout << one.size() << '\\n'; // 4 accepted
}`,
        },
        steps(pairs) {
          const reqs = pairList(pairs, 6);
          const n = reqs.length;
          const LEG = ["read", "compare", "good", "bad", "result", "done", "dim", "idle"];
          const steps = [];
          const labels = reqs.map((r, i) => `#${i + 1} ${span(r)}`);
          const one = [];
          const two = [];

          if (!n) {
            return [
              {
                title: "No booking requests arrived",
                tracks: [cell("requests", "empty", "bad")],
                counters: [count("requests seen", 0), count("accepted", 0)],
                legend: LEG,
                happened: "There are no pairs to test.",
                why: "A triple can only be detected after at least one request exists.",
                codeLine: 13,
              },
              {
                title: "Use pairs such as 10,20 50,60 10,40",
                tracks: [cell("example", "10,20 50,60 10,40", "idle", "half-open intervals")],
                counters: [count("requests seen", 0), count("accepted", 0)],
                legend: LEG,
                happened: "Each pair is one half-open booking.",
                why: "The double list starts empty along with the single list.",
              },
              {
                title: "Answer: 0 accepted",
                tracks: [cell("answer", 0, "bad", "no requests")],
                counters: [count("requests seen", 0), count("answer", 0)],
                legend: LEG,
                happened: "Nothing was booked.",
                why: "With no requests there is no overlap to count.",
              },
            ];
          }

          steps.push({
            title: `Guard against triples across ${n} request${n === 1 ? "" : "s"}`,
            tracks: [
              track("requests", labels, fill(n, "idle")),
              listRow("booked once", one),
              listRow("booked twice (triple guard)", two),
            ],
            counters: [count("requests seen", 0, n), count("accepted", 0), count("rejected", 0)],
            legend: LEG,
            happened: `Requests are ${reqs.map(span).join(", ")}. Both booking lists start empty.`,
            why: "A third overlapping booking is exactly an overlap with a region that is already covered twice.",
            codeLine: 13,
          });

          reqs.forEach((q, k) => {
            const dhits = two.filter((d) => clash(q, d));
            steps.push({
              title: dhits.length
                ? `#${k + 1} ${span(q)} overlaps double-booked ${dhits.map(span).join(", ")}`
                : `#${k + 1} ${span(q)} avoids every double-booked region`,
              tracks: [
                track("requests", labels, labels.map((_, x) => (x < k ? "done" : x === k ? "read" : "idle"))),
                listRow("booked once", one, () => "done"),
                listRow("booked twice (triple guard)", two, (d) => (dhits.indexOf(d) >= 0 ? "bad" : "done")),
                cell("triple test", dhits.length ? "would be triple" : "safe", dhits.length ? "bad" : "good", "check the double list first"),
              ],
              counters: [count("requests seen", k + 1, n), count("double regions checked", two.length)],
              legend: LEG,
              happened: dhits.length
                ? `${span(dhits[0])} is already covered twice, so ${span(q)} would push that region to three.`
                : `No region currently covered twice intersects ${span(q)}.`,
              why: "The double list is the cheapest place to reject a request: one overlap there is already fatal.",
              codeLine: 15,
            });

            if (dhits.length) {
              steps.push({
                title: `Reject ${span(q)} — it would triple-book ${span(dhits[0])}`,
                tracks: [
                  track("requests", labels, labels.map((_, x) => (x < k ? "done" : x === k ? "bad" : "idle"))),
                  listRow("booked once", one, () => "done"),
                  listRow("booked twice (triple guard)", two, (d) => (dhits.indexOf(d) >= 0 ? "compare" : "done")),
                  cell("decision", "not booked", "bad", "no triple allowed"),
                ],
                counters: [count("requests seen", k + 1, n), count("rejected", steps.filter((s) => s.title.indexOf("Reject") === 0).length + 1)],
                legend: LEG,
                happened: `Accepting ${span(q)} would make three bookings share ${span(dhits[0])}, so it is refused.`,
                why: "Refusing before touching the single list keeps the double list a truthful record of coverage.",
                codeLine: 16,
              });
              return;
            }

            const shits = one.filter((b) => clash(q, b));
            steps.push({
              title: shits.length
                ? `#${k + 1} ${span(q)} overlaps ${shits.map(span).join(", ")} once`
                : `#${k + 1} ${span(q)} does not overlap a single booking`,
              tracks: [
                track("requests", labels, labels.map((_, x) => (x < k ? "done" : x === k ? "read" : "idle"))),
                listRow("booked once", one, (b) => (shits.indexOf(b) >= 0 ? "compare" : "done")),
                listRow("booked twice (triple guard)", two, () => "done"),
                cell("single test", shits.length ? `${shits.length} overlap${shits.length === 1 ? "" : "s"}` : "no overlap", shits.length ? "compare" : "good", "these become double regions"),
              ],
              counters: [count("requests seen", k + 1, n), count("single bookings checked", one.length)],
              legend: LEG,
              happened: shits.length
                ? `The overlap${shits.length === 1 ? "" : "s"} ${shits.map(span).join(", ")} will join the double list, not the triple list.`
                : `${span(q)} fits beside every single booking.`,
              why: "Only the parts shared with a single booking become double-booked; no part reaches three.",
              codeLine: 17,
            });

            const added = [];
            for (const b of shits) {
              const o = { s: Math.max(q.s, b.s), e: Math.min(q.e, b.e) };
              if (!two.some((x) => x.s === o.s && x.e === o.e)) {
                two.push(o);
                added.push(o);
              }
            }
            two.sort((a, b) => a.s - b.s);
            one.push(q);
            one.sort((a, b) => a.s - b.s);
            steps.push({
              title: added.length
                ? `Accept ${span(q)}; ${added.map(span).join(", ")} becomes double-booked`
                : `Accept ${span(q)} as a single booking`,
              tracks: [
                track("requests", labels, labels.map((_, x) => (x < k ? "done" : x === k ? "good" : "idle"))),
                listRow("booked once", one, (b) => (b === q ? "result" : "done"), (b) => "start " + b.s),
                listRow("booked twice (triple guard)", two, (d) => (added.indexOf(d) >= 0 ? "result" : "done")),
                cell("decision", "booked", "good", added.length ? "new double region" : "still single"),
              ],
              counters: [
                count("requests seen", k + 1, n),
                count("accepted", one.length),
                count("double regions", two.length),
              ],
              legend: LEG,
              happened: `${span(q)} is stored in the single list${added.length ? `, and ${added.map(span).join(", ")} now appears in both lists.` : "."}`,
              why: "Every overlap with a single booking is by definition covered twice once the new request is accepted.",
              codeLine: 23,
            });
          });

          const answer = one.length;
          steps.push({
            title: `Answer: ${answer} accepted, never more than 2 at once`,
            tracks: [
              track("requests", labels, fill(n, "done")),
              listRow("booked once", one, () => "result"),
              listRow("booked twice (triple guard)", two, () => "result"),
              cell("answer", answer, "result", "no triple booking"),
            ],
            counters: [count("requests seen", n, n), count("accepted", answer), count("answer", answer)],
            legend: LEG,
            happened: `The calendar accepted ${answer} of ${n} requests; the double list records ${two.length} region${two.length === 1 ? "" : "s"} covered twice.`,
            why: "Any request that touched the double list was refused, so no region can ever be covered three times.",
            codeLine: 25,
          });

          return steps;
        },
      },
    ],
  });

  /* ============================================================
     7. My Calendar III
     ============================================================ */
  V.register({
    id: "my-calendar-iii",
    title: "My Calendar III",
    category: "Advanced Structures",
    difficulty: "Advanced",
    description: "Book every request and report the largest number of bookings that overlap at one moment.",
    input: { label: "Booking pairs start,end", default: "10,20 50,60 10,40 5,15 5,10", parse: "pairs" },
    approaches: [
      {
        name: "Sweep the Event Points",
        complexity: "O(n log n) per full sweep, O(n) space",
        idea: [
          "Every booking becomes two events: a start event adds one at the start position, and an end event subtracts one at the end position.",
          "Sort all events by position. At a tie, endings must be processed before starts, because a half-open interval frees its slot exactly when another may claim it.",
          "A running total follows the sorted events. Its largest value is the greatest number of bookings that overlap at once.",
        ],
        problem: [
          "The sweep only reports the maximum after all events are sorted, so inserting one more booking and asking again costs O(n log n) unless a balanced map or segment tree is maintained incrementally.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int x, d; } Event;

static int cmp(const void *a, const void *b) {
    const Event *p = a, *q = b;
    if (p->x != q->x) return p->x < q->x ? -1 : 1;
    return p->d - q->d;              /* ends (-1) before starts (+1) */
}

int main(void) {
    int starts[] = {10, 50, 10, 5, 5};
    int ends[]   = {20, 60, 40, 15, 10};
    Event ev[10];
    int m = 0;
    for (int i = 0; i < 5; i++) {
        ev[m++] = (Event){starts[i], +1};
        ev[m++] = (Event){ends[i], -1};
    }
    qsort(ev, m, sizeof(Event), cmp);
    int run = 0, best = 0;
    for (int i = 0; i < m; i++) {
        run += ev[i].d;
        if (run > best) best = run;
    }
    printf("%d\\n", best); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <map>

int main() {
    std::map<int, int> events;
    int starts[] = {10, 50, 10, 5, 5};
    int ends[] = {20, 60, 40, 15, 10};
    for (int i = 0; i < 5; ++i) {
        ++events[starts[i]];
        --events[ends[i]];
    }
    int run = 0, best = 0;
    for (const auto& e : events) {   // map visits positions in order
        run += e.second;
        if (run > best) best = run;
    }
    std::cout << best << '\\n'; // 3
}`,
        },
        steps(pairs) {
          const reqs = pairList(pairs, 6);
          const n = reqs.length;
          const LEG = ["read", "compare", "good", "result", "done", "dim", "idle"];
          const steps = [];
          const labels = reqs.map((r, i) => `#${i + 1} ${span(r)}`);
          const events = [];

          if (!n) {
            return [
              {
                title: "No events without a booking",
                tracks: [cell("requests", "empty", "bad")],
                counters: [count("events", 0), count("max overlap", 0)],
                legend: LEG,
                happened: "No start or end points were supplied.",
                why: "A sweep needs at least one interval to turn into events.",
                codeLine: 16,
              },
              {
                title: "Use pairs such as 10,20 50,60 10,40",
                tracks: [cell("example", "10,20 50,60 10,40", "idle", "two events each")],
                counters: [count("events", 0), count("max overlap", 0)],
                legend: LEG,
                happened: "The sweep will sort every start and end point.",
                why: "The running count changes only at event positions.",
              },
              {
                title: "Answer: 0 bookings at once",
                tracks: [cell("answer", 0, "bad")],
                counters: [count("events", 0), count("answer", 0)],
                legend: LEG,
                happened: "There are no booking intervals, so the maximum overlap is zero.",
                why: "An empty calendar never has anyone booked.",
              },
            ];
          }

          steps.push({
            title: `Turn ${n} booking${n === 1 ? "" : "s"} into start and end events`,
            tracks: [
              track("requests", labels, fill(n, "idle")),
              listRow("events (position, change)", events),
              cell("max so far", 0, "idle", "nothing swept yet"),
            ],
            counters: [count("events", 0, 2 * n), count("max overlap", 0)],
            legend: LEG,
            happened: `Requests are ${reqs.map(span).join(", ")}. Each one will add +1 at its start and −1 at its end.`,
            why: "The exact positions inside a booking do not matter; only the moments when the count changes do.",
            codeLine: 16,
          });

          reqs.forEach((q, k) => {
            const e1 = { x: q.s, d: 1, k };
            const e2 = { x: q.e, d: -1, k };
            events.push(e1, e2);
            steps.push({
              title: `#${k + 1} ${span(q)} adds events at ${q.s} (+1) and ${q.e} (−1)`,
              tracks: [
                track("requests", labels, labels.map((_, x) => (x < k ? "done" : x === k ? "read" : "idle"))),
                {
                  label: "events (position, change)",
                  cells: events.map((e) => ({
                    v: `${e.x} ${signed(e.d)}`,
                    state: e === e1 || e === e2 ? "result" : "done",
                    tag: `#${e.k + 1}`,
                  })),
                },
                cell("max so far", "—", "idle", "events not sorted yet"),
              ],
              counters: [count("events", events.length, 2 * n), count("max overlap", "—")],
              legend: LEG,
              happened: `The new events are ${q.s} ${signed(1)} and ${q.e} ${signed(-1)}.`,
              why: "One booking contributes exactly two changes to the running count.",
              codeLine: 17,
            });
          });

          const sorted = events.slice().sort((a, b) => a.x - b.x || a.d - b.d);
          steps.push({
            title: `Sort ${sorted.length} events, endings before starts on ties`,
            tracks: [
              track("requests", labels, fill(n, "done")),
              {
                label: "events sorted by position",
                cells: sorted.map((e) => ({
                  v: `${e.x} ${signed(e.d)}`,
                  state: "done",
                  tag: `#${e.k + 1}`,
                })),
              },
              cell("max so far", 0, "idle", "sweep starts next"),
            ],
            counters: [count("events", sorted.length, sorted.length), count("max overlap", 0)],
            legend: LEG,
            happened: `The positions now run ${[...new Set(sorted.map((e) => e.x))].join(", ")}. At a repeated position, every −1 comes before every +1.`,
            why: "Half-open intervals release their slot at the end position, so the release must happen before a new booking claims it.",
            codeLine: 20,
          });

          const groups = [];
          for (const e of sorted) {
            const last = groups[groups.length - 1];
            if (last && last.x === e.x) {
              last.ends += e.d === -1 ? 1 : 0;
              last.starts += e.d === 1 ? 1 : 0;
              last.net += e.d;
            } else {
              groups.push({ x: e.x, net: e.d, ends: e.d === -1 ? 1 : 0, starts: e.d === 1 ? 1 : 0 });
            }
          }

          let run = 0;
          let best = 0;
          const running = [];
          groups.forEach((g, gi) => {
            run += g.net;
            if (run > best) best = run;
            running.push({ v: run, state: "result", tag: `x=${g.x}` });
            const deltaText = `${g.starts ? `+${g.starts}` : ""}${g.starts && g.ends ? " " : ""}${g.ends ? `−${g.ends}` : ""}`;
            steps.push({
              title: `At x=${g.x}: ${deltaText} → ${run} booking${run === 1 ? "" : "s"} at once`,
              tracks: [
                track("requests", labels, fill(n, "done")),
                {
                  label: "events sorted by position",
                  cells: sorted.map((e) => ({
                    v: `${e.x} ${signed(e.d)}`,
                    state: e.x === g.x ? "read" : e.x < g.x ? "done" : "idle",
                    tag: `#${e.k + 1}`,
                  })),
                },
                { label: "running bookings", cells: running.map((c, i) => ({ ...c, state: i === running.length - 1 ? "result" : "done" })) },
                cell("max so far", best, "result", best === run ? "new maximum" : "held from earlier"),
              ],
              counters: [count("positions swept", gi + 1, groups.length), count("max overlap", best)],
              legend: LEG,
              happened:
                `${g.ends ? `${g.ends} booking${g.ends === 1 ? "" : "s"} ended at ${g.x}` : `No booking ends at ${g.x}`}` +
                `${g.starts ? `, then ${g.starts} started` : ", and none started"}, leaving ${run} active.`,
              why: "The running count is the number of half-open intervals covering the moment just after this position.",
              codeLine: 22,
            });
          });

          steps.push({
            title: `Answer: at most ${best} bookings overlap`,
            tracks: [
              track("requests", labels, fill(n, "done")),
              {
                label: "events sorted by position",
                cells: sorted.map((e) => ({ v: `${e.x} ${signed(e.d)}`, state: "done", tag: `#${e.k + 1}` })),
              },
              { label: "running bookings", cells: running.map((c) => ({ ...c, state: "result" })) },
              cell("answer", best, "result", "largest running count"),
            ],
            counters: [count("positions swept", groups.length), count("answer", best)],
            legend: LEG,
            happened: `Across all ${groups.length} event positions the running count reached ${best}, and never went higher.`,
            why: "The maximum prefix of the sorted event changes is exactly the maximum number of overlapping bookings.",
            codeLine: 26,
          });

          return steps;
        },
      },
    ],
  });

  /* ============================================================
     8. Falling Squares
     ============================================================ */
  V.register({
    id: "falling-squares",
    title: "Falling Squares",
    category: "Advanced Structures",
    difficulty: "Advanced",
    description: "Drop squares onto a skyline and report the tallest top after each landing.",
    input: { label: "Square pairs left,side", default: "1,2 2,3 6,1", parse: "pairs" },
    approaches: [
      {
        name: "Coordinate Compression",
        complexity: "O(n²) time with 2n compressed boundaries, O(n) space",
        idea: [
          "Only square edges can change the skyline, so collect every left edge and every right edge (left + side). Sorted and deduplicated, those boundaries cut the x-axis into narrow gaps that never split.",
          "A square covers a contiguous run of gaps. Its landing height is the tallest height below that run plus its own side; every gap in the run then rises to that new height.",
          "After each drop, the running maximum of all gap heights is the highest top so far. The final maximum is the answer.",
        ],
        problem: [
          "Each square scans and rewrites every gap it covers, so the worst case is quadratic. A segment tree over the compressed gaps would cut each drop to O(log n) but needs lazy range assignment.",
          "Compression assumes every relevant edge is known in advance. With squares arriving one at a time, new boundaries can appear later and force the structure to be rebuilt.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>
typedef struct { int left, side; } Square;
static int cmp(const void *a, const void *b) {
    return (*(const int *)a > *(const int *)b) - (*(const int *)a < *(const int *)b);
}
int main(void) {
    Square sq[] = {{1, 2}, {2, 3}, {6, 1}}; int n = 3;
    int xs[16], m = 0;
    for (int i = 0; i < n; i++) {
        xs[m++] = sq[i].left; xs[m++] = sq[i].left + sq[i].side;
    }
    qsort(xs, m, sizeof(int), cmp);
    int gaps = 0;
    for (int i = 0; i < m; i++)
        if (i == 0 || xs[i] != xs[i - 1]) xs[gaps++] = xs[i];
    int height[15] = {0}, best = 0;
    for (int i = 0; i < n; i++) {
        int l = 0, r = gaps - 1;
        while (xs[l] < sq[i].left) l++;
        while (xs[r] > sq[i].left + sq[i].side) r--;
        int top = 0;
        for (int g = l; g < r; g++) if (height[g] > top) top = height[g];
        top += sq[i].side;
        for (int g = l; g < r; g++) height[g] = top;
        if (top > best) best = top;
    }
    printf("%d\\n", best); /* 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::vector<std::pair<int, int>> sq{{1, 2}, {2, 3}, {6, 1}};
    std::vector<int> xs;
    for (const auto& s : sq) {
        xs.push_back(s.first);
        xs.push_back(s.first + s.second);
    }
    std::sort(xs.begin(), xs.end());
    xs.erase(std::unique(xs.begin(), xs.end()), xs.end());
    std::vector<int> height(xs.size() - 1, 0);
    int best = 0;
    for (const auto& s : sq) {
        int l = static_cast<int>(std::lower_bound(xs.begin(), xs.end(), s.first) - xs.begin());
        int r = static_cast<int>(std::lower_bound(xs.begin(), xs.end(), s.first + s.second) - xs.begin());
        int top = 0;
        for (int g = l; g < r; ++g) top = std::max(top, height[g]);
        top += s.second;
        for (int g = l; g < r; ++g) height[g] = top;
        best = std::max(best, top);
    }
    std::cout << best << '\\n'; // 5
}`,
        },
        steps(pairs) {
          const LEG = ["read", "compare", "good", "result", "done", "bad", "dim", "idle"];
          const steps = [];
          const squares = [];
          const src = Array.isArray(pairs) ? pairs : [];
          for (const p of src) {
            if (!Array.isArray(p) || p.length < 2) continue;
            const left = Math.trunc(Number(p[0]));
            const rawSide = Math.trunc(Number(p[1]));
            if (!Number.isFinite(left) || !Number.isFinite(rawSide)) continue;
            squares.push({ left, side: Math.max(0, rawSide), clamped: rawSide < 0 });
            if (squares.length >= 8) break;
          }

          if (!squares.length) {
            return [
              {
                title: "No squares to drop",
                tracks: [cell("squares", "empty", "bad")],
                counters: [count("squares dropped", 0), count("answer", 0)],
                legend: LEG,
                happened: "The input contains no left,side pairs.",
                why: "A skyline needs at least one square to have any height.",
                codeLine: 9,
              },
              {
                title: "Use pairs such as 1,2 2,3 6,1",
                tracks: [cell("example", "1,2 2,3 6,1", "idle", "left edge, side length")],
                counters: [count("squares dropped", 0), count("answer", 0)],
                legend: LEG,
                happened: "Each pair places a square with its left edge at the first number.",
                why: "Only the left edge and the side length are needed to find the covered x-range.",
              },
              {
                title: "Answer: 0 — nothing has landed",
                tracks: [cell("answer", 0, "bad")],
                counters: [count("squares dropped", 0), count("answer", 0)],
                legend: LEG,
                happened: "The skyline stays flat at zero.",
                why: "No square means no height anywhere.",
              },
            ];
          }

          const boundarySet = [];
          for (const s of squares) {
            boundarySet.push(s.left);
            boundarySet.push(s.left + s.side);
          }
          const xs = [...new Set(boundarySet)].sort((a, b) => a - b);
          const gaps = Math.max(0, xs.length - 1);
          const height = new Array(gaps).fill(0);
          const labels = squares.map((s, i) => `#${i + 1} at ${s.left}, side ${s.side}`);
          const heightCells = (stateOf, extra) => {
            const cells = [];
            for (let g = 0; g < gaps; g++) {
              cells.push({
                v: height[g],
                state: stateOf ? stateOf(g) : height[g] > 0 ? "done" : "idle",
                tag: `${xs[g]}-${xs[g + 1]}`,
              });
            }
            if (extra) cells.push(...extra);
            return cells.length ? cells : [{ v: "—", state: "idle", empty: true }];
          };
          const boundaryCells = (stateOf) =>
            xs.map((x, i) => ({
              v: x,
              state: stateOf ? stateOf(i) : "idle",
              tag: "b" + i,
            }));

          steps.push({
            title: `Drop ${squares.length} square${squares.length === 1 ? "" : "s"} on a flat skyline`,
            tracks: [
              track("squares (left, side)", labels, fill(squares.length, "idle")),
              track("x boundaries", xs, fill(xs.length, "idle")),
              { label: "height per gap", cells: heightCells(null) },
              cell("highest top", 0, "idle", "skyline starts flat"),
            ],
            counters: [count("squares dropped", 0, squares.length), count("answer", 0)],
            legend: LEG,
            happened: `The squares are ${labels.join("; ")}. Every gap between boundaries starts at height 0.`,
            why: "Only square edges can change the skyline, so those edges are the only x positions worth tracking.",
            codeLine: 7,
          });

          steps.push({
            title: `Compress ${boundarySet.length} edges into ${gaps} gap${gaps === 1 ? "" : "s"}`,
            tracks: [
              track("squares (left, side)", labels, fill(squares.length, "idle")),
              track("x boundaries", xs, fill(xs.length, "result"), xs.map((x) => "edge " + x)),
              {
                label: "height per gap",
                cells: heightCells(() => "idle"),
              },
              cell("gap tags", "left-right", "read", "each tag is one compressed span"),
            ],
            counters: [count("boundaries", xs.length), count("gaps", gaps)],
            legend: LEG,
            happened: `Sorted edges are ${xs.join(", ")}, giving the spans ${xs.slice(0, -1).map((x, i) => `${x}-${xs[i + 1]}`).join(", ") || "none"}.`,
            why: "A square's edges always land on these boundaries, so no future square can cut a gap in half.",
            codeLine: 12,
          });

          let highest = 0;
          squares.forEach((s, k) => {
            const right = s.left + s.side;
            const l = xs.indexOf(s.left);
            const r = xs.indexOf(right);
            const widthGaps = Math.max(0, r - l);
            let floor = 0;
            for (let g = l; g < r; g++) floor = Math.max(floor, height[g]);
            const top = floor + s.side;

            steps.push({
              title:
                widthGaps === 0
                  ? `#${k + 1} at ${s.left} has zero width — no gap below`
                  : `#${k + 1} covers x=${s.left}..${right}: floor is ${floor}`,
              tracks: [
                track("squares (left, side)", labels, labels.map((_, i) => (i < k ? "done" : i === k ? "read" : "idle"))),
                { label: "x boundaries", cells: boundaryCells((i) => (i >= l && i <= r ? "compare" : "done")) },
                { label: "height per gap", cells: heightCells((g) => (g >= l && g < r ? "compare" : height[g] > 0 ? "done" : "idle")) },
                cell("floor below", floor, "result", widthGaps ? `tallest of gaps ${l}–${r - 1}` : "no covered gap"),
              ],
              counters: [count("squares dropped", k, squares.length), count("gaps covered", widthGaps)],
              legend: LEG,
              happened: widthGaps
                ? `The widest existing height under the square is ${floor}, found across ${widthGaps} gap${widthGaps === 1 ? "" : "s"}.`
                : `The square has no width, so it cannot rest on any gap.`,
              why: "A falling square stops on the tallest thing directly beneath it, not on the average or the last value.",
              codeLine: 22,
            });

            for (let g = l; g < r; g++) height[g] = top;
            highest = Math.max(highest, top);
            steps.push({
              title:
                widthGaps === 0
                  ? `#${k + 1} lands at height ${top}`
                  : `#${k + 1}: ${floor} + ${s.side} = ${top} across gaps ${l}–${r - 1}`,
              tracks: [
                track("squares (left, side)", labels, labels.map((_, i) => (i <= k ? "done" : "idle"))),
                { label: "x boundaries", cells: boundaryCells((i) => (i >= l && i <= r ? "good" : "done")) },
                { label: "height per gap", cells: heightCells((g) => (g >= l && g < r ? "result" : height[g] > 0 ? "done" : "idle")) },
                cell("new top", top, "result", `highest so far ${highest}`),
              ],
              counters: [count("squares dropped", k + 1, squares.length), count("highest top", highest)],
              legend: LEG,
              happened: widthGaps
                ? `Every covered gap is raised to ${top}, so the square sits flat on top of the old skyline.`
                : `The square adds no width, so the skyline is unchanged and its top is ${top}.`,
              why: "Raising all covered gaps to the same new height records both the square's top and the space it occupies.",
              codeLine: 24,
            });
          });

          steps.push({
            title: `Answer: highest top is ${highest}`,
            tracks: [
              track("squares (left, side)", labels, fill(squares.length, "done")),
              track("x boundaries", xs, fill(xs.length, "done")),
              { label: "height per gap", cells: heightCells(() => "result") },
              cell("answer", highest, "result", "maximum after every drop"),
            ],
            counters: [count("squares dropped", squares.length, squares.length), count("answer", highest)],
            legend: LEG,
            happened: `The final skyline is ${height.join(", ") || "empty"}, so the tallest top reached is ${highest}.`,
            why: "The running maximum only ever grows, so it already contains the best answer after the last drop.",
            codeLine: 27,
          });

          return steps;
        },
      },
    ],
  });
})();
