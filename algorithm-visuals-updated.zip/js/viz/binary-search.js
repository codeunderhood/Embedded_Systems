/* ============================================================
   DSA Visuals — Binary Search
   Six visualisations built on the same idea: keep a window
   [lo..hi] over the input, probe its middle, and throw away
   whichever half cannot contain the answer.
      { id, title, category, difficulty, description,
        input: { label, default, parse },
        approaches: [ { name, complexity, idea, problem,
                        code: { c, cpp }, steps(parsed) } ] }
   Shared input convention for target-based problems: the LAST
   number in the input is the target, everything before it is
   the (usually sorted) row.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, paint, count } = window.H;
  const V = window.VIZ;

  /* ---------------------------------------------------------- */
  /* shared local utilities                                      */

  // input convention: last number = target, the rest = the row
  function splitTarget(nums) {
    if (!nums.length) return { arr: [], target: 0 };
    return { arr: nums.slice(0, -1), target: nums[nums.length - 1] };
  }

  // first neighbour pair that breaks non-decreasing order, or null
  function sortIssue(a) {
    for (let i = 1; i < a.length; i++)
      if (a[i] < a[i - 1]) return { at: i };
    return null;
  }

  // is `a` a rotation of a strictly increasing row?
  // a genuine rotation has exactly one downward step when you walk
  // around the circle, and no repeated values.
  function rotationIssue(a) {
    const n = a.length;
    if (n <= 1) return null;
    const dups = new Set(a).size !== n;
    let drops = 0;
    for (let i = 0; i < n; i++)
      if (a[i] < a[(i - 1 + n) % n]) drops++;
    if (drops === 1 && !dups) return null;
    if (dups && drops !== 1)
      return { text: "the row repeats values and drops " + drops + " times around the circle" };
    if (dups) return { text: "the row repeats values" };
    if (drops === 0) return { text: "the row never drops, so nothing was rotated apart" };
    return { text: "the circle drops " + drops + " times instead of once" };
  }

  // states for a row of n cells while [lo..hi] is still in play
  function winStates(n, lo, hi, mid, midState, inState) {
    const st = new Array(n).fill(inState || "active");
    for (let i = 0; i < n; i++) {
      if (i < lo || i > hi) st[i] = "dim";
      else if (i === mid) st[i] = midState || "read";
    }
    return st;
  }

  // dedicated pointer row showing lo / hi / mid as tagged cells
  function ptrTrack(lo, hi, mid, midState) {
    return track(
      "pointers",
      [lo, hi, mid == null ? "—" : mid],
      ["active", "active", mid == null ? "idle" : midState || "read"],
      ["lo", "hi", "mid"]
    );
  }

  /* ---------------------------------------------------------- */
  V.register({
    id: "binary-search",
    title: "Binary Search",
    category: "Binary Search",
    difficulty: "Beginner",
    description: "Find a target in a sorted row by repeatedly cutting the search window in half.",
    input: { label: "Sorted numbers, then the target (last value)", default: "2, 5, 8, 12, 16, 23, 38, 23", parse: "ints" },
    approaches: [
      {
        name: "Iterative Halving",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "Keep two pointers: lo at the left edge of the remaining window and hi at the right. Probe the middle index and compare its value with the target.",
          "If the middle is too big the whole right half is too big, and vice versa — move one pointer past the middle and repeat until the pointers cross or the middle matches.",
        ],
        problem: [
          "The row must really be sorted; on an unsorted row the comparison points the search the wrong way and the answer cannot be trusted.",
          "It also only reports some index — if duplicates exist you never learn which copy you found.",
        ],
        code: {
          c: `#include <stdio.h>

/* index of target in sorted a[], or -1 when absent */
int binary_search(const int *a, int n, int target) {
    int lo = 0, hi = n - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}

int main(void) {
    int a[] = {2, 5, 8, 12, 16, 23, 38};
    printf("%d\\n", binary_search(a, 7, 23)); /* 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// index of target in sorted a, or -1
int binarySearch(const std::vector<int>& a, int target) {
    int lo = 0, hi = (int)a.size() - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}

int main() {
    std::vector<int> a{2, 5, 8, 12, 16, 23, 38};
    std::cout << binarySearch(a, 23) << '\\n'; // 5
}`,
        },
        steps(parsed) {
          const { arr, target } = splitTarget(parsed);
          const n = arr.length;
          const shown = n ? arr : ["∅"];
          const steps = [];
          const issue = sortIssue(arr);

          steps.push({
            title: "Setup: one window over the whole row",
            tracks: [track("the numbers", shown, fill(shown.length, "idle")), ptrTrack(0, n - 1, null)],
            counters: [count("search space", n), count("mid compared", 0)],
            legend: ["read", "active", "idle", "dim"],
            happened: n
              ? `${n} sorted numbers, and we are hunting for ${target}. lo starts at index 0 and hi at index ${n - 1}.`
              : `The input held a single number, so it was taken as the target ${target} and the row itself is empty.`,
            why: "Everything between lo and hi is still a candidate; the whole algorithm does is move these two pointers.",
            codeLine: 4,
          });

          if (issue) {
            steps.push({
              title: `Sorted check fails: ${arr[issue.at]} < ${arr[issue.at - 1]} at index ${issue.at}`,
              tracks: [
                track("the numbers", shown, paint(fill(n, "dim"), { [issue.at - 1]: "compare", [issue.at]: "bad" })),
                ptrTrack(0, n - 1, null),
              ],
              counters: [count("neighbour pairs checked", issue.at), count("search space", n)],
              legend: ["compare", "bad", "dim", "idle"],
              happened: `Walking left to right the row falls backwards at index ${issue.at}: ${arr[issue.at - 1]} is followed by ${arr[issue.at]}.`,
              why: "Halving assumes a smaller target must sit to the left — without sorted order the verdict below is only a hint.",
              codeLine: 5,
            });
          } else {
            steps.push({
              title: n <= 1 ? "Sorted check: trivially in order" : "Sorted check: every neighbour pair ascends",
              tracks: [track("the numbers", shown, fill(shown.length, "good")), ptrTrack(0, n - 1, null)],
              counters: [count("neighbour pairs checked", Math.max(0, n - 1)), count("search space", n)],
              legend: ["good", "active", "idle"],
              happened: n <= 1
                ? "A row of at most one number never breaks the sorted promise."
                : `All ${n - 1} neighbour pairs ascend — the sorted promise holds, so a smaller target must lie left of the middle.`,
              why: "Discarding half the window in one comparison is only legal when sorted order guarantees where the target can live.",
              codeLine: 5,
            });
          }

          if (n === 0) {
            steps.push({
              title: "Empty window — the loop never runs",
              tracks: [track("the numbers", shown, fill(shown.length, "idle")), ptrTrack(0, -1, null)],
              counters: [count("search space", 0), count("mid compared", 0)],
              legend: ["active", "idle", "dim"],
              happened: "lo is already past hi, so while (lo <= hi) is false before the first probe.",
              why: "An empty window is instantly 'not found' — there is nothing left to compare against.",
              codeLine: 5,
            });
            steps.push({
              title: "Answer: not found (-1)",
              tracks: [track("the numbers", shown, fill(shown.length, "dim")), ptrTrack(0, -1, null)],
              counters: [count("answer", -1), count("mid compared", 0)],
              legend: ["dim", "idle"],
              happened: `No comparisons were needed: the row is empty, so ${target} is not in it.`,
              why: "The loop guard already proves absence here — an empty window contains no candidates at all.",
              codeLine: 11,
            });
            return steps;
          }

          let lo = 0, hi = n - 1, probes = 0, found = -1;
          while (lo <= hi && found < 0) {
            const mid = lo + Math.floor((hi - lo) / 2);
            probes++;
            steps.push({
              title: `Probe: mid = ${mid} → inspect ${arr[mid]}`,
              tracks: [track("the numbers", shown, winStates(n, lo, hi, mid, "read")), ptrTrack(lo, hi, mid)],
              counters: [count("search space", hi - lo + 1, n), count("mid compared", probes)],
              legend: ["read", "active", "dim"],
              happened: `lo = ${lo} and hi = ${hi}, so mid = lo + (hi - lo) / 2 = ${mid}. The window holds ${hi - lo + 1} numbers and we look at its middle one: ${arr[mid]}.`,
              why: "The middle is the most informative spot — one comparison decides which entire half can be thrown away.",
              codeLine: 6,
            });
            if (arr[mid] === target) {
              found = mid;
              steps.push({
                title: `Match: ${arr[mid]} equals the target → stop shrinking`,
                tracks: [track("the numbers", shown, paint(winStates(n, lo, hi, mid, "read"), { [mid]: "good" })), ptrTrack(lo, hi, mid)],
                counters: [count("search space", hi - lo + 1, n), count("mid compared", probes)],
                legend: ["good", "read", "active", "dim"],
                happened: `The probe landed straight on ${target} at index ${mid} — the search has its answer and needs no further narrowing.`,
                why: "Equality at the middle ends the loop early; every other value in the window is simply irrelevant now.",
                codeLine: 7,
              });
            } else if (target < arr[mid]) {
              const newHi = mid - 1;
              steps.push({
                title: `${arr[mid]} is too big → drop indices ${mid}..${hi}`,
                tracks: [
                  track("the numbers", shown, paint(winStates(n, lo, newHi, null), { [mid]: "done" })),
                  ptrTrack(lo, newHi, mid, "done"),
                ],
                counters: [count("search space", Math.max(0, newHi - lo + 1), n), count("mid compared", probes)],
                legend: ["done", "active", "dim"],
                happened: `${target} sits left of ${arr[mid]}, so hi jumps to ${newHi} and everything from index ${mid} rightwards is out of play.`,
                why: `Sorted order means every index at or after mid holds a value of at least ${arr[mid]} — none of them can be ${target}, so half the window dies in one step.`,
                codeLine: 9,
              });
              hi = newHi;
            } else {
              const newLo = mid + 1;
              steps.push({
                title: `${arr[mid]} is too small → drop indices ${lo}..${mid}`,
                tracks: [
                  track("the numbers", shown, paint(winStates(n, newLo, hi, null), { [mid]: "done" })),
                  ptrTrack(newLo, hi, mid, "done"),
                ],
                counters: [count("search space", Math.max(0, hi - newLo + 1), n), count("mid compared", probes)],
                legend: ["done", "active", "dim"],
                happened: `${target} sits right of ${arr[mid]}, so lo jumps to ${newLo} and everything up to index ${mid} is out of play.`,
                why: `Sorted order means every index up to mid holds a value of at most ${arr[mid]} — ${target} cannot be hiding there.`,
                codeLine: 8,
              });
              lo = newLo;
            }
          }

          if (found >= 0) {
            steps.push({
              title: `Answer: index ${found}`,
              tracks: [
                track("the numbers", shown, shown.map((v, i) => (i === found ? "result" : "dim"))),
                ptrTrack(lo, hi, found, "result"),
              ],
              counters: [count("answer", found), count("mid compared", probes)],
              legend: ["result", "dim"],
              happened: `Binary search stopped after ${probes} probes: ${target} lives at index ${found}.`,
              why: `Starting from ${n} candidates, each probe kept only half — the answer cost about log2(${n}) comparisons instead of a full scan.`,
              codeLine: 7,
            });
          } else {
            steps.push({
              title: "Answer: not found (-1)",
              tracks: [track("the numbers", shown, fill(shown.length, "dim")), ptrTrack(lo, hi, null)],
              counters: [count("answer", -1), count("mid compared", probes)],
              legend: ["dim", "active"],
              happened: `The window collapsed (lo = ${lo} is past hi = ${hi}) without ever landing on ${target}.`,
              why: "Every probe provably removed half the remaining numbers, so an empty window proves absence — not just failure to look.",
              codeLine: 11,
            });
          }
          return steps;
        },
      },
      {
        name: "Recursive Halving",
        complexity: "O(log n) time, O(log n) call-stack space",
        idea: [
          "Same halving logic, but instead of moving pointers in a loop the function calls itself on whichever half can still hold the target: search(lo, mid - 1) or search(mid + 1, hi).",
          "The base cases are 'the window is empty → -1' and 'the middle matches → mid'; each finished call hands its answer straight back to the caller.",
        ],
        problem: [
          "Every recursive call adds a frame to the call stack, so this version uses O(log n) extra memory where the loop used none.",
          "On very large inputs deep recursion can overflow the stack, which is why the iterative loop is the default in production code.",
        ],
        code: {
          c: `#include <stdio.h>

/* search a[lo..hi] for target; -1 when the window is empty */
int search(const int *a, int lo, int hi, int target) {
    if (lo > hi) return -1;                /* base case */
    int mid = lo + (hi - lo) / 2;
    if (a[mid] == target) return mid;
    if (a[mid] < target)
        return search(a, mid + 1, hi, target);
    return search(a, lo, mid - 1, target);
}

int main(void) {
    int a[] = {2, 5, 8, 12, 16, 23, 38};
    printf("%d\\n", search(a, 0, 6, 23)); /* 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// search a[lo..hi] for target; -1 when the window is empty
int search(const std::vector<int>& a, int lo, int hi, int target) {
    if (lo > hi) return -1;              // base case
    int mid = lo + (hi - lo) / 2;
    if (a[mid] == target) return mid;
    if (a[mid] < target)
        return search(a, mid + 1, hi, target);
    return search(a, lo, mid - 1, target);
}

int main() {
    std::vector<int> a{2, 5, 8, 12, 16, 23, 38};
    std::cout << search(a, 0, 6, 23) << '\\n'; // 5
}`,
        },
        steps(parsed) {
          const { arr, target } = splitTarget(parsed);
          const n = arr.length;
          const shown = n ? arr : ["∅"];
          const steps = [];
          const issue = sortIssue(arr);
          const stack = [{ lo: 0, hi: n - 1 }];
          const stackTrack = () => ({
            label: "call stack",
            cells: stack.map((f, i) => ({
              v: `search(${f.lo}, ${f.hi})`,
              state: i === stack.length - 1 ? "read" : "done",
            })),
          });

          steps.push({
            title: "Setup: call search(0, n-1)",
            tracks: [track("the numbers", shown, fill(shown.length, "idle")), ptrTrack(0, n - 1, null), stackTrack()],
            counters: [count("search space", n), count("frames on stack", 1), count("mid compared", 0)],
            legend: ["read", "done", "active", "idle"],
            happened: n
              ? `One frame search(0, ${n - 1}) is pushed for our ${n} sorted numbers; the target is ${target}.`
              : `The input held a single number, so it was taken as the target ${target} and the row itself is empty — frame search(0, -1) is already a base case.`,
            why: "Each recursive call owns its own little window; the stack remembers which windows are still waiting for an answer.",
            codeLine: 3,
          });

          if (issue) {
            steps.push({
              title: `Sorted check fails: ${arr[issue.at]} < ${arr[issue.at - 1]} at index ${issue.at}`,
              tracks: [
                track("the numbers", shown, paint(fill(n, "dim"), { [issue.at - 1]: "compare", [issue.at]: "bad" })),
                ptrTrack(0, n - 1, null),
                stackTrack(),
              ],
              counters: [count("neighbour pairs checked", issue.at), count("frames on stack", stack.length)],
              legend: ["compare", "bad", "dim"],
              happened: `The row falls backwards at index ${issue.at}: ${arr[issue.at - 1]} is followed by ${arr[issue.at]}.`,
              why: "The recursion picks its branch by comparing against the middle — on an unsorted row that choice may point the wrong way.",
              codeLine: 5,
            });
          } else {
            steps.push({
              title: n <= 1 ? "Sorted check: trivially in order" : "Sorted check: every neighbour pair ascends",
              tracks: [track("the numbers", shown, fill(shown.length, "good")), ptrTrack(0, n - 1, null), stackTrack()],
              counters: [count("neighbour pairs checked", Math.max(0, n - 1)), count("frames on stack", stack.length)],
              legend: ["good", "active", "read"],
              happened: n <= 1
                ? "A row of at most one number never breaks the sorted promise."
                : `All ${n - 1} neighbour pairs ascend, so each recursive branch can trust its comparison.`,
              why: "Sorted order is what lets a child call receive a strictly smaller window than its parent had.",
              codeLine: 5,
            });
          }

          // one probe per frame: a frame splits once, then delegates the
          // surviving half to a child and never looks at its window again.
          let probes = 0, found = -1;
          while (stack.length) {
            const top = stack[stack.length - 1];
            if (top.lo > top.hi) {
              stack.pop();
              steps.push({
                title: `Base case: search(${top.lo}, ${top.hi}) has an empty window → return -1`,
                tracks: [track("the numbers", shown, fill(shown.length, "dim")), ptrTrack(top.lo, top.hi, null), stackTrack()],
                counters: [count("search space", 0), count("frames on stack", stack.length), count("mid compared", probes)],
                legend: ["dim", "read", "done"],
                happened: `lo ${top.lo} is past hi ${top.hi}, so this call returns -1 without probing anything.`,
                why: "The emptiness check runs before any comparison — it is the guard that stops the recursion from descending forever.",
                codeLine: 4,
              });
              steps.push({
                title: stack.length
                  ? `The -1 passes straight back through ${stack.length} waiting frame${stack.length === 1 ? "" : "s"}`
                  : "The -1 goes straight back to the original caller",
                tracks: [
                  track("the numbers", shown, fill(shown.length, "dim")),
                  { label: "call stack", cells: stack.length ? stack.map((f, i) => ({ v: `search(${f.lo}, ${f.hi})`, state: "done" })) : [{ v: "∅", state: "idle", empty: true }] },
                ],
                counters: [count("answer so far", -1), count("frames on stack", 0)],
                legend: ["done", "dim"],
                happened: "Every parent was written as \"return search(...)\" — it can only forward the -1 and pop, so the stack drains in one motion.",
                why: "No ancestor re-probes: once the base case proves absence, each waiting frame simply returns that verdict.",
                codeLine: 9,
              });
              steps.push({
                title: "Answer: not found (-1)",
                tracks: [track("the numbers", shown, fill(shown.length, "dim")), { label: "call stack", cells: [{ v: "∅", state: "idle", empty: true }] }],
                counters: [count("answer", -1), count("mid compared", probes)],
                legend: ["dim", "idle"],
                happened: `The original call returns -1 after ${probes} probes — ${target} is not in the row.`,
                why: "Recursion explored exactly the halves the loop would have, just with frames instead of pointer moves.",
                codeLine: 4,
              });
              return steps;
            }
            const mid = top.lo + Math.floor((top.hi - top.lo) / 2);
            probes++;
            steps.push({
              title: `search(${top.lo}, ${top.hi}): mid = ${mid} → inspect ${arr[mid]}`,
              tracks: [track("the numbers", shown, winStates(n, top.lo, top.hi, mid, "read")), ptrTrack(top.lo, top.hi, mid), stackTrack()],
              counters: [count("search space", top.hi - top.lo + 1, n), count("frames on stack", stack.length), count("mid compared", probes)],
              legend: ["read", "active", "dim", "done"],
              happened: `The top frame splits its window: mid = ${mid} holds ${arr[mid]}. ${stack.length} frame${stack.length === 1 ? " is" : "s are"} waiting below it.`,
              why: "A frame only ever looks inside its own window — parent frames stay frozen until the child returns.",
              codeLine: 5,
            });
            if (arr[mid] === target) {
              found = mid;
              steps.push({
                title: `Match: ${arr[mid]} equals the target → return ${mid}`,
                tracks: [
                  track("the numbers", shown, paint(winStates(n, top.lo, top.hi, mid, "read"), { [mid]: "good" })),
                  ptrTrack(top.lo, top.hi, mid),
                  stackTrack(),
                ],
                counters: [count("answer so far", mid), count("frames on stack", stack.length), count("mid compared", probes)],
                legend: ["good", "read", "active", "done"],
                happened: `The middle IS the target, so this frame stops recursing and returns index ${mid}.`,
                why: "The match is decided at the deepest frame — all that remains is handing the index back up.",
                codeLine: 6,
              });
              steps.push({
                title: stack.length > 1
                  ? `The index ${mid} passes back through ${stack.length - 1} waiting frame${stack.length - 1 === 1 ? "" : "s"}`
                  : `The index ${mid} goes straight back to the original caller`,
                tracks: [
                  track("the numbers", shown, shown.map((v, i) => (i === mid ? "good" : "dim"))),
                  { label: "call stack", cells: stack.map((f) => ({ v: `search(${f.lo}, ${f.hi})`, state: "done" })) },
                ],
                counters: [count("answer so far", mid), count("frames on stack", 0), count("mid compared", probes)],
                legend: ["good", "dim", "done"],
                happened: stack.length > 1
                  ? "Every waiting frame was built as \"return search(...)\", so it immediately forwards index " + mid + " and pops off."
                  : "Nothing stands between the matching frame and the caller — the index is handed straight back.",
                why: "Nothing up the stack re-checks the answer — the frame that found the target owns the result.",
                codeLine: 8,
              });
              stack.length = 0;
            } else if (target < arr[mid]) {
              stack.push({ lo: top.lo, hi: mid - 1 });
              steps.push({
                title: `${arr[mid]} is too big → recurse search(${top.lo}, ${mid - 1})`,
                tracks: [
                  track("the numbers", shown, paint(winStates(n, top.lo, mid - 1, null), { [mid]: "done" })),
                  ptrTrack(top.lo, mid - 1, mid, "done"),
                  stackTrack(),
                ],
                counters: [count("search space", Math.max(0, mid - top.lo + 1), n), count("frames on stack", stack.length), count("mid compared", probes)],
                legend: ["done", "active", "dim", "read"],
                happened: `${target} lies left of ${arr[mid]}, so a child frame search(${top.lo}, ${mid - 1}) is pushed — the parent freezes with its original window and just waits.`,
                why: `Sorted order rules out every index from ${mid} rightwards — the child window is at most half its parent's size.`,
                codeLine: 9,
              });
            } else {
              stack.push({ lo: mid + 1, hi: top.hi });
              steps.push({
                title: `${arr[mid]} is too small → recurse search(${mid + 1}, ${top.hi})`,
                tracks: [
                  track("the numbers", shown, paint(winStates(n, mid + 1, top.hi, null), { [mid]: "done" })),
                  ptrTrack(mid + 1, top.hi, mid, "done"),
                  stackTrack(),
                ],
                counters: [count("search space", Math.max(0, top.hi - mid), n), count("frames on stack", stack.length), count("mid compared", probes)],
                legend: ["done", "active", "dim", "read"],
                happened: `${target} lies right of ${arr[mid]}, so a child frame search(${mid + 1}, ${top.hi}) is pushed — the parent freezes with its original window and just waits.`,
                why: `Sorted order rules out every index up to ${mid} — the child window is at most half its parent's size.`,
                codeLine: 8,
              });
            }
          }

          steps.push({
            title: `Answer: index ${found}`,
            tracks: [
              track("the numbers", shown, shown.map((v, i) => (i === found ? "result" : "dim"))),
              { label: "call stack", cells: [{ v: "∅", state: "idle", empty: true }] },
            ],
            counters: [count("answer", found), count("mid compared", probes)],
            legend: ["result", "dim", "done"],
            happened: `After ${probes} probes and at most a handful of frames, the outermost call reports index ${found} for ${target}.`,
            why: `The stack carried at most log2(${n}) frames deep — recursion traded the loop's O(1) pointers for O(log n) of call-stack memory.`,
            codeLine: 6,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "search-insert-position",
    title: "Search Insert Position",
    category: "Binary Search",
    difficulty: "Beginner",
    description: "Find the index where a target would sit inside a sorted row, keeping the order intact.",
    input: { label: "Sorted numbers, then the target (last value)", default: "1, 3, 5, 7, 9, 11, 15, 6", parse: "ints" },
    approaches: [
      {
        name: "Lower-Bound Halving",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "This is binary search with a twist: instead of stopping at a match, every probe asks 'could the insert point still be at mid or further left?'. If a[mid] is smaller than the target the answer must be right of mid, otherwise mid itself is a candidate and hi slides down to it.",
          "hi starts at n — one past the last index — because appending the target after everything is a perfectly legal insert. When lo and hi meet, that single slot is the answer.",
        ],
        problem: [
          "Like every binary search it needs the row sorted; an unsorted row produces a plausible-looking but meaningless index.",
          "If the target already exists you silently return its first occurrence, which is only one of several equally valid insert positions.",
        ],
        code: {
          c: `#include <stdio.h>

/* index where target keeps a[] in sorted order (0..n) */
int search_insert(const int *a, int n, int target) {
    int lo = 0, hi = n;                /* hi may sit one past the end */
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid;                 /* mid is still a candidate */
    }
    return lo;
}

int main(void) {
    int a[] = {1, 3, 5, 7, 9, 11, 15};
    printf("%d\\n", search_insert(a, 7, 6)); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// index where target keeps a in sorted order (0..n)
int searchInsert(const std::vector<int>& a, int target) {
    int lo = 0, hi = (int)a.size();    // hi may sit one past the end
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid;                 // mid is still a candidate
    }
    return lo;
}

int main() {
    std::vector<int> a{1, 3, 5, 7, 9, 11, 15};
    std::cout << searchInsert(a, 6) << '\\n'; // 3
}`,
        },
        steps(parsed) {
          const { arr, target } = splitTarget(parsed);
          const n = arr.length;
          const cells = n + 1;                       // index n = the append slot
          const shown = arr.concat([n ? "·" : "∅"]); // a visible empty slot at the end
          const issue = sortIssue(arr);
          const steps = [];
          const states = (lo, hi, mid) => {
            const st = [];
            for (let i = 0; i < cells; i++) {
              if (i === mid) st[i] = "read";
              else if (i > hi) st[i] = "dim";
              else if (i < lo) st[i] = "done";
              else st[i] = "active";
            }
            return st;
          };
          const row = (st, tags) => track("the numbers", shown, st, tags);

          steps.push({
            title: "Setup: window over every insert slot",
            tracks: [
              row(fill(cells, "idle"), undefined),
              ptrTrack(0, n, null),
            ],
            counters: [count("candidate slots", n + 1), count("mid compared", 0)],
            legend: ["read", "active", "done", "dim"],
            happened: n
              ? `lo = 0 and hi = ${n} — hi deliberately sits one slot past the last number, because appending ${target} after the row is a legal insert too.`
              : `The input was a single number, so it became the target ${target} and the row is empty: lo = hi = 0, the lone append slot.`,
            why: "Every slot from lo to hi could still be the insert point; the extra end slot keeps 'append' inside the search space.",
            codeLine: 4,
          });

          if (issue) {
            steps.push({
              title: `Sorted check fails: ${arr[issue.at]} < ${arr[issue.at - 1]} at index ${issue.at}`,
              tracks: [
                row(paint(fill(cells, "dim"), { [issue.at - 1]: "compare", [issue.at]: "bad" })),
                ptrTrack(0, n, null),
              ],
              counters: [count("neighbour pairs checked", issue.at), count("candidate slots", n + 1)],
              legend: ["compare", "bad", "dim"],
              happened: `The row falls backwards at index ${issue.at}: ${arr[issue.at - 1]} is followed by ${arr[issue.at]}.`,
              why: "The halving below still runs without crashing, but on an unsorted row the reported index is only a hint, not a sorted insert point.",
              codeLine: 5,
            });
          } else {
            steps.push({
              title: n <= 1 ? "Sorted check: trivially in order" : "Sorted check: every neighbour pair ascends",
              tracks: [row(fill(cells, "good")), ptrTrack(0, n, null)],
              counters: [count("neighbour pairs checked", Math.max(0, n - 1)), count("candidate slots", n + 1)],
              legend: ["good", "active"],
              happened: n <= 1
                ? "A row of at most one number never breaks the sorted promise."
                : `All ${n - 1} neighbour pairs ascend, so "smaller than the target" reliably points left.`,
              why: "The insert point is defined by sorted order — without it the question 'where does it belong?' has no single answer.",
              codeLine: 5,
            });
          }

          let lo = 0, hi = n, probes = 0;
          if (lo === hi) {
            steps.push({
              title: "Only one slot left — the loop never runs",
              tracks: [row(states(lo, hi, null)), ptrTrack(lo, hi, null)],
              counters: [count("candidate slots", hi - lo + 1), count("mid compared", 0)],
              legend: ["read", "active", "done", "dim"],
              happened: `lo and hi already agree on slot ${lo}, so while (lo < hi) is false before the first probe.`,
              why: "With nothing left to narrow, the surviving slot IS the insert position.",
              codeLine: 5,
            });
          }
          while (lo < hi) {
            const mid = lo + Math.floor((hi - lo) / 2);
            probes++;
            steps.push({
              title: `Probe: mid = ${mid} → inspect ${arr[mid]}`,
              tracks: [row(states(lo, hi, mid)), ptrTrack(lo, hi, mid)],
              counters: [count("candidate slots", hi - lo + 1), count("mid compared", probes)],
              legend: ["read", "active", "done", "dim"],
              happened: `lo = ${lo}, hi = ${hi} → mid = ${mid} holds ${arr[mid]}. ${hi - lo + 1} slot${hi - lo + 1 === 1 ? " is" : "s are"} still in play.`,
              why: "The probe asks one question about the middle candidate: does the target belong at, or left of, this slot?",
              codeLine: 6,
            });
            if (arr[mid] < target) {
              const newLo = mid + 1;
              steps.push({
                title: `${arr[mid]} < ${target} → insert point is right of ${mid}`,
                tracks: [
                  row(paint(states(newLo, hi, null), { [mid]: "done" })),
                  ptrTrack(newLo, hi, mid, "done"),
                ],
                counters: [count("candidate slots", hi - newLo + 1), count("mid compared", probes)],
                legend: ["done", "active", "dim", "read"],
                happened: `${arr[mid]} sits below the target, so slot ${mid} and everything before it is settled — lo moves to ${newLo}.`,
                why: "In a sorted row every earlier number is even smaller; the target can never fit to the left of a value it already beats.",
                codeLine: 7,
              });
              lo = newLo;
            } else {
              const newHi = mid;
              steps.push({
                title: `${arr[mid]} ≥ ${target} → keep ${mid} as a candidate, hi = ${mid}`,
                tracks: [
                  row(paint(states(lo, newHi, null), { [mid]: "read" })),
                  ptrTrack(lo, newHi, mid),
                ],
                counters: [count("candidate slots", newHi - lo + 1), count("mid compared", probes)],
                legend: ["read", "active", "dim", "done"],
                happened: `${arr[mid]} is at least the target, so the insert point cannot be right of ${mid} — hi slides down to ${newHi} but keeps ${mid} inside the window.`,
                why: "hi lands ON mid rather than past it: this branch has not ruled mid out, it has only ruled out everything after it.",
                codeLine: 8,
              });
              hi = newHi;
            }
          }

          const tags = new Array(cells).fill(undefined);
          tags[lo] = "insert here";
          const answerText = lo === n
            ? `lo and hi met at ${lo}, one past the last number — ${target} would be appended at the end.`
            : arr[lo] === target
              ? `lo and hi met at ${lo} — the target already lives there, and inserting keeps the earliest spot.`
              : `lo and hi met at ${lo} — slot ${lo} sits ${lo === 0 ? "before every number" : `between ${arr[lo - 1]} and ${arr[lo]}`}, where ${target} belongs.`;
          steps.push({
            title: `Answer: index ${lo}`,
            tracks: [
              track(
                "the numbers",
                shown,
                shown.map((v, i) => (i < lo ? "done" : i === lo ? "result" : "dim")),
                tags
              ),
              ptrTrack(lo, hi, lo, "result"),
            ],
            counters: [count("answer", lo), count("mid compared", probes)],
            legend: ["result", "done", "dim"],
            happened: answerText,
            why: `The window halved from ${n + 1} slots down to 1 in ${probes} probes — O(log n) instead of scanning for the right spot.`,
            codeLine: 10,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "first-and-last-position",
    title: "First and Last Position",
    category: "Binary Search",
    difficulty: "Intermediate",
    description: "Locate both edges of a run of equal values in a sorted row.",
    input: { label: "Sorted numbers, then the target (last value)", default: "1, 2, 3, 5, 5, 5, 6, 5", parse: "ints" },
    approaches: [
      {
        name: "Left Bound, Then Right Bound",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "Run binary search twice. The first pass refuses to settle: every match becomes a candidate for 'first' and the window keeps moving LEFT, so the last candidate recorded is the leftmost occurrence.",
          "The second pass mirrors it — a match updates 'last' and the window moves RIGHT. When both windows empty, first and last are the two edges of the run.",
        ],
        problem: [
          "Two passes means up to 2·log2(n) probes instead of one — still logarithmic, but twice the API-free comparisons of a single narrowing search.",
          "Both passes lean on the sorted promise: the leftward pass can only find the earliest copy because equal values are never split across the row.",
        ],
        code: {
          c: `#include <stdio.h>

/* first index with a[i] == target, or -1 */
int first_pos(const int *a, int n, int target) {
    int lo = 0, hi = n - 1, ans = -1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < target) lo = mid + 1;
        else {
            if (a[mid] == target) ans = mid;
            hi = mid - 1;              /* matches are only candidates now */
        }
    }
    return ans;
}

/* last index with a[i] == target, or -1 */
int last_pos(const int *a, int n, int target) {
    int lo = 0, hi = n - 1, ans = -1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] > target) hi = mid - 1;
        else {
            if (a[mid] == target) ans = mid;
            lo = mid + 1;              /* keep going right */
        }
    }
    return ans;
}

int main(void) {
    int a[] = {1, 2, 3, 5, 5, 5, 6};
    printf("%d %d\\n", first_pos(a, 7, 5), last_pos(a, 7, 5)); /* 3 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// first index with a[i] == target, or -1
int firstPos(const std::vector<int>& a, int target) {
    int lo = 0, hi = (int)a.size() - 1, ans = -1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < target) lo = mid + 1;
        else {
            if (a[mid] == target) ans = mid;
            hi = mid - 1;            // matches are only candidates now
        }
    }
    return ans;
}

// last index with a[i] == target, or -1
int lastPos(const std::vector<int>& a, int target) {
    int lo = 0, hi = (int)a.size() - 1, ans = -1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] > target) hi = mid - 1;
        else {
            if (a[mid] == target) ans = mid;
            lo = mid + 1;            // keep going right
        }
    }
    return ans;
}

int main() {
    std::vector<int> a{1, 2, 3, 5, 5, 5, 6};
    std::cout << firstPos(a, 5) << ' ' << lastPos(a, 5) << '\\n'; // 3 5
}`,
        },
        steps(parsed) {
          const { arr, target } = splitTarget(parsed);
          const n = arr.length;
          const shown = n ? arr : ["∅"];
          const issue = sortIssue(arr);
          const steps = [];
          let probes = 0;
          const row = (st, tags) => track("the numbers", shown, st, tags);
          const cand = (label, val, tag) => ({
            label,
            cells: [{ v: val < 0 ? "—" : val, state: val < 0 ? "idle" : "result", tag }],
          });

          steps.push({
            title: "Setup: two passes — left edge first, right edge second",
            tracks: [row(fill(n, "idle")), ptrTrack(0, n - 1, null), cand("first match so far", -1, "first")],
            counters: [count("search space", n), count("pass", "1 of 2"), count("mid compared", 0)],
            legend: ["read", "active", "idle", "dim", "result"],
            happened: n
              ? `${n} sorted numbers, target ${target}. Pass 1 narrows down the FIRST occurrence; pass 2 will mirror it for the LAST.`
              : `The input held a single number, so it became the target ${target} — the row itself is empty, both passes will report nothing.`,
            why: "One run of equal values can have many copies; two directional searches pin down both ends without scanning the run.",
            codeLine: 4,
          });

          if (issue) {
            steps.push({
              title: `Sorted check fails: ${arr[issue.at]} < ${arr[issue.at - 1]} at index ${issue.at}`,
              tracks: [row(paint(fill(n, "dim"), { [issue.at - 1]: "compare", [issue.at]: "bad" })), ptrTrack(0, n - 1, null)],
              counters: [count("neighbour pairs checked", issue.at), count("search space", n)],
              legend: ["compare", "bad", "dim"],
              happened: `The row falls backwards at index ${issue.at}: ${arr[issue.at - 1]} is followed by ${arr[issue.at]}.`,
              why: "The passes below still run safely, but without sorted order their edges are only hints — copies of the target may hide outside them.",
              codeLine: 5,
            });
          } else {
            steps.push({
              title: n <= 1 ? "Sorted check: trivially in order" : "Sorted check: every neighbour pair ascends",
              tracks: [row(fill(n, "good")), ptrTrack(0, n - 1, null)],
              counters: [count("neighbour pairs checked", Math.max(0, n - 1)), count("search space", n)],
              legend: ["good", "active"],
              happened: n <= 1
                ? "A row of at most one number never breaks the sorted promise."
                : `All ${n - 1} neighbour pairs ascend, so equal copies form one unbroken run — edges are well defined.`,
              why: "Sorted order guarantees the target's copies are contiguous; that is exactly why directional halving can find the run's borders.",
              codeLine: 5,
            });
          }

          /* ---- pass 1: left bound ---- */
          let lo = 0, hi = n - 1, first = -1;
          while (lo <= hi) {
            const mid = lo + Math.floor((hi - lo) / 2);
            probes++;
            steps.push({
              title: `Pass 1 · probe mid ${mid} → ${arr[mid]}`,
              tracks: [row(winStates(n, lo, hi, mid, "read")), ptrTrack(lo, hi, mid), cand("first match so far", first, "first")],
              counters: [count("search space", hi - lo + 1, n), count("mid compared", probes), count("first", first < 0 ? "—" : first)],
              legend: ["read", "active", "dim", "result"],
              happened: `lo = ${lo}, hi = ${hi} → mid = ${mid} holds ${arr[mid]}; the window has ${hi - lo + 1} numbers left.`,
              why: "Pass 1 only ever narrows towards smaller indices, so a match here is a candidate for the earliest copy, not a final answer yet.",
              codeLine: 6,
            });
            let newLo = lo, newHi = hi, title, happened, why, codeLine;
            if (arr[mid] < target) {
              newLo = mid + 1;
              title = `Pass 1 · ${arr[mid]} < ${target} → lo = ${newLo}`;
              happened = `${arr[mid]} is too small, so every index up to ${mid} is ruled out — lo steps to ${newLo}.`;
              why = "Smaller numbers live left in a sorted row; a target-sized copy cannot be hiding at or before mid.";
              codeLine = 7;
            } else if (arr[mid] > target) {
              newHi = mid - 1;
              title = `Pass 1 · ${arr[mid]} > ${target} → hi = ${newHi}`;
              happened = `${arr[mid]} is too big, so indices ${mid}..${hi} are ruled out — hi drops to ${newHi}.`;
              why = "Bigger numbers live right in a sorted row; the target can only be at or left of mid.";
              codeLine = 10;
            } else {
              first = mid;
              newHi = mid - 1;
              title = `Pass 1 · match at ${mid} → remember it, keep going left`;
              happened = `${arr[mid]} equals ${target}, so ${mid} becomes the best 'first' so far — and hi still drops to ${newHi} to look for an earlier copy.`;
              why = "Recording but not stopping is the whole trick: only after the window dies do we know no earlier copy exists.";
              codeLine = 9;
            }
            steps.push({
              title,
              tracks: [row(paint(winStates(n, newLo, newHi, null), { [mid]: "done" })), ptrTrack(newLo, newHi, mid, "done"), cand("first match so far", first, "first")],
              counters: [count("search space", Math.max(0, newHi - newLo + 1), n), count("mid compared", probes), count("first", first < 0 ? "—" : first)],
              legend: ["done", "active", "dim", "result"],
              happened,
              why,
              codeLine,
            });
            lo = newLo; hi = newHi;
          }

          if (first < 0) {
            steps.push({
              title: "Pass 1 ends empty-handed → target is absent",
              tracks: [row(fill(n, "dim")), ptrTrack(lo, hi, null), cand("first match so far", -1, "first")],
              counters: [count("search space", 0), count("mid compared", probes), count("first", "—")],
              legend: ["dim", "idle", "active"],
              happened: `The window crossed without a single match, so ${target} never appears — pass 2 would have nothing to stretch from.`,
              why: "If there is no first occurrence there can be no last one either; both answers collapse to -1 together.",
              codeLine: 13,
            });
            steps.push({
              title: "Answer: [-1, -1]",
              tracks: [row(fill(n, "dim")), { label: "answer", cells: [{ v: "[-1, -1]", state: "result", tag: "not found" }] }],
              counters: [count("first", -1), count("last", -1), count("mid compared", probes)],
              legend: ["result", "dim"],
              happened: `No copy of ${target} exists in the row.`,
              why: "One directional pass proved absence — the second search would only repeat the same conclusion.",
              codeLine: 13,
            });
            return steps;
          }

          steps.push({
            title: `Pass 1 done: the left edge is index ${first} → reset for pass 2`,
            tracks: [
              row(shown.map((v, i) => (i === first ? "good" : "dim"))),
              ptrTrack(0, n - 1, null),
              cand("first match so far", first, "first"),
            ],
            counters: [count("search space", n), count("pass", "2 of 2"), count("mid compared", probes)],
            legend: ["good", "dim", "active", "result"],
            happened: `The window died with ${first} as the last recorded match — no copy of ${target} sits left of it. The pointers now reset to the whole row.`,
            why: "The left edge is settled; the second pass runs the same halving but pushes right after every match to reach the other end.",
            codeLine: 18,
          });

          /* ---- pass 2: right bound ---- */
          lo = 0; hi = n - 1;
          let last = -1;
          while (lo <= hi) {
            const mid = lo + Math.floor((hi - lo) / 2);
            probes++;
            steps.push({
              title: `Pass 2 · probe mid ${mid} → ${arr[mid]}`,
              tracks: [row(winStates(n, lo, hi, mid, "read")), ptrTrack(lo, hi, mid), cand("last match so far", last, "last")],
              counters: [count("search space", hi - lo + 1, n), count("mid compared", probes), count("last", last < 0 ? "—" : last)],
              legend: ["read", "active", "dim", "result"],
              happened: `lo = ${lo}, hi = ${hi} → mid = ${mid} holds ${arr[mid]}; the window has ${hi - lo + 1} numbers left.`,
              why: "This time a match moves the window to the RIGHT, so every later probe hunts for a copy further along the run.",
              codeLine: 20,
            });
            let newLo = lo, newHi = hi, title, happened, why, codeLine;
            if (arr[mid] > target) {
              newHi = mid - 1;
              title = `Pass 2 · ${arr[mid]} > ${target} → hi = ${newHi}`;
              happened = `${arr[mid]} is too big — indices ${mid}..${hi} drop out and hi moves to ${newHi}.`;
              why = "Same rule as pass 1: anything at or right of a too-big value is also too big for the target.";
              codeLine = 21;
            } else if (arr[mid] < target) {
              newLo = mid + 1;
              title = `Pass 2 · ${arr[mid]} < ${target} → lo = ${newLo}`;
              happened = `${arr[mid]} is too small — indices ${lo}..${mid} drop out and lo moves to ${newLo}.`;
              why = "Smaller values sit left of the target's run, so the search cannot stop before it.";
              codeLine = 24;
            } else {
              last = mid;
              newLo = mid + 1;
              title = `Pass 2 · match at ${mid} → remember it, keep going right`;
              happened = `${arr[mid]} equals ${target}, so ${mid} becomes the best 'last' so far — and lo still climbs to ${newLo} to look for a later copy.`;
              why = "Recording without stopping lets the window keep sliding right until the run provably ends.";
              codeLine = 23;
            }
            steps.push({
              title,
              tracks: [row(paint(winStates(n, newLo, newHi, null), { [mid]: "done" })), ptrTrack(newLo, newHi, mid, "done"), cand("last match so far", last, "last")],
              counters: [count("search space", Math.max(0, newHi - newLo + 1), n), count("mid compared", probes), count("last", last < 0 ? "—" : last)],
              legend: ["done", "active", "dim", "result"],
              happened,
              why,
              codeLine,
            });
            lo = newLo; hi = newHi;
          }

          let note = "";
          if (last < 0) { last = first; note = " Pass 2 strangely confirmed no right edge (the row is not sorted), so the left edge is used for both."; }
          else if (last < first) { note = ` Pass 2 reported ${last} which is left of ${first} (the row is not sorted) — the pair was clamped.`; last = first; }
          steps.push({
            title: `Pass 2 done: the right edge is index ${last}`,
            tracks: [row(shown.map((v, i) => (i === last ? "good" : "dim"))), ptrTrack(lo, hi, null), cand("last match so far", last, "last")],
            counters: [count("search space", 0), count("mid compared", probes), count("last", last)],
            legend: ["good", "dim", "result"],
            happened: `The window crossed again with ${last} as the last recorded match — no copy of ${target} sits right of it.${note}`,
            why: "Both directional searches have now spoken; the pair of surviving candidates is the run's full extent.",
            codeLine: 27,
          });

          const tags = new Array(n).fill(undefined);
          tags[first] = first === last ? "first & last" : "first";
          tags[last] = first === last ? undefined : "last";
          steps.push({
            title: `Answer: first ${first}, last ${last}`,
            tracks: [
              row(shown.map((v, i) => (i >= first && i <= last ? "result" : "dim")), tags),
              { label: "answer", cells: [{ v: `[${first}, ${last}]`, state: "result", tag: "edges" }] },
            ],
            counters: [count("first", first), count("last", last), count("mid compared", probes)],
            legend: ["result", "dim"],
            happened: `The run of ${target} spans index ${first} to ${last} — ${last - first + 1} cop${last - first + 1 === 1 ? "y" : "ies"} in total.`,
            why: `Two halves of log2(${n}) probes each beat walking the whole row, and neither pass ever inspected more than one window.`,
            codeLine: 32,
          });
          return steps;
        },
      },
      {
        name: "Find Any Match, Then Expand",
        complexity: "O(log n + k) time, O(1) space",
        idea: [
          "First run a plain binary search that stops at the FIRST copy it happens to hit — any copy will do. The moment the middle matches, halving is over.",
          "Then walk outwards one cell at a time from that copy: step left while the neighbour still equals the target, step right likewise. Those two walks paint the whole run, and k is how many copies there are.",
        ],
        problem: [
          "The expansion is linear: a run of k copies costs k extra steps, so a row stuffed with the target degrades towards O(n).",
          "It also touches every cell around the run, while the two-bound approach never looks inside the run at all — the trade is probes versus walks.",
        ],
        code: {
          c: `#include <stdio.h>

/* walk outwards from any match to find both edges */
void first_last(const int *a, int n, int target, int *first, int *last) {
    int lo = 0, hi = n - 1, at = -1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) { at = mid; break; }
        if (a[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    *first = *last = at;
    if (at < 0) return;
    while (*first > 0 && a[*first - 1] == target) (*first)--;
    while (*last + 1 < n && a[*last + 1] == target) (*last)++;
}

int main(void) {
    int a[] = {1, 2, 3, 5, 5, 5, 6}, f, l;
    first_last(a, 7, 5, &f, &l);
    printf("%d %d\\n", f, l); /* 3 5 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <utility>

// walk outwards from any match to find both edges
std::pair<int, int> firstLast(const std::vector<int>& a, int target) {
    int lo = 0, hi = (int)a.size() - 1, at = -1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) { at = mid; break; }
        if (a[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    if (at < 0) return {-1, -1};
    int first = at, last = at;
    while (first > 0 && a[first - 1] == target) --first;
    while (last + 1 < (int)a.size() && a[last + 1] == target) ++last;
    return {first, last};
}

int main() {
    auto [f, l] = firstLast({1, 2, 3, 5, 5, 5, 6}, 5);
    std::cout << f << ' ' << l << '\\n'; // 3 5
}`,
        },
        steps(parsed) {
          const { arr, target } = splitTarget(parsed);
          const n = arr.length;
          const shown = n ? arr : ["∅"];
          const issue = sortIssue(arr);
          const steps = [];
          let probes = 0;
          const row = (st, tags) => track("the numbers", shown, st, tags);

          const walkStates = (first, last, check) => {
            const st = shown.map((v, i) => (i >= first && i <= last ? "good" : "dim"));
            if (check != null && check >= 0 && check < shown.length) st[check] = "read";
            return st;
          };
          const walkTags = (first, last) => {
            const t = new Array(shown.length).fill(undefined);
            t[first] = first === last ? "first & last" : "first";
            if (first !== last) t[last] = "last";
            return t;
          };

          steps.push({
            title: "Setup: binary search for any one copy",
            tracks: [row(fill(n, "idle")), ptrTrack(0, n - 1, null)],
            counters: [count("search space", n), count("mid compared", 0), count("run length", 0)],
            legend: ["read", "active", "idle", "dim"],
            happened: n
              ? `${n} sorted numbers, target ${target}. Phase 1 only needs ONE copy; phase 2 will stretch that copy into the full run.`
              : `The input held a single number, so it became the target ${target} and the row is empty.`,
            why: "Halving cannot count a run — but it lands on some copy cheaply, and a single copy is enough to start a walk.",
            codeLine: 4,
          });

          if (issue) {
            steps.push({
              title: `Sorted check fails: ${arr[issue.at]} < ${arr[issue.at - 1]} at index ${issue.at}`,
              tracks: [row(paint(fill(n, "dim"), { [issue.at - 1]: "compare", [issue.at]: "bad" })), ptrTrack(0, n - 1, null)],
              counters: [count("neighbour pairs checked", issue.at), count("search space", n)],
              legend: ["compare", "bad", "dim"],
              happened: `The row falls backwards at index ${issue.at}: ${arr[issue.at - 1]} is followed by ${arr[issue.at]}.`,
              why: "The walk below still stops safely on a differing neighbour, but on an unsorted row the edges may not bound every copy.",
              codeLine: 5,
            });
          } else {
            steps.push({
              title: n <= 1 ? "Sorted check: trivially in order" : "Sorted check: every neighbour pair ascends",
              tracks: [row(fill(n, "good")), ptrTrack(0, n - 1, null)],
              counters: [count("neighbour pairs checked", Math.max(0, n - 1)), count("search space", n)],
              legend: ["good", "active"],
              happened: n <= 1
                ? "A row of at most one number never breaks the sorted promise."
                : `All ${n - 1} neighbour pairs ascend, so equal copies sit shoulder to shoulder — a differing neighbour really is the edge.`,
              why: "The outward walk only works because copies cannot be scattered: one non-matching neighbour closes the run for good.",
              codeLine: 5,
            });
          }

          /* ---- phase 1: any match ---- */
          let lo = 0, hi = n - 1, at = -1;
          while (lo <= hi && at < 0) {
            const mid = lo + Math.floor((hi - lo) / 2);
            probes++;
            steps.push({
              title: `Probe: mid = ${mid} → inspect ${arr[mid]}`,
              tracks: [row(winStates(n, lo, hi, mid, "read")), ptrTrack(lo, hi, mid)],
              counters: [count("search space", hi - lo + 1, n), count("mid compared", probes)],
              legend: ["read", "active", "dim"],
              happened: `lo = ${lo}, hi = ${hi} → mid = ${mid} holds ${arr[mid]}.`,
              why: "Any copy of the target will do as a starting point — this probe is happy with the first hit, not the earliest.",
              codeLine: 6,
            });
            let newLo = lo, newHi = hi, title, happened, why, codeLine;
            if (arr[mid] === target) {
              at = mid;
              title = `Match at ${mid} → stop halving, start walking`;
              happened = `${arr[mid]} equals ${target}; the search records index ${mid} and breaks out of the loop immediately.`;
              why = "Halving has done its job — landing inside the run is the green light for the linear walk.";
              codeLine = 7;
            } else if (target < arr[mid]) {
              newHi = mid - 1;
              title = `${arr[mid]} is too big → drop indices ${mid}..${hi}`;
              happened = `${target} sits left of ${arr[mid]}, so hi drops to ${newHi}.`;
              why = "Sorted order rules out the whole right half in one comparison, same as plain binary search.";
              codeLine = 9;
            } else {
              newLo = mid + 1;
              title = `${arr[mid]} is too small → drop indices ${lo}..${mid}`;
              happened = `${target} sits right of ${arr[mid]}, so lo climbs to ${newLo}.`;
              why = "Sorted order rules out the whole left half in one comparison.";
              codeLine = 8;
            }
            steps.push({
              title,
              tracks: [row(paint(winStates(n, newLo, newHi, null), { [mid]: at === mid ? "good" : "done" })), ptrTrack(newLo, newHi, mid, at === mid ? "good" : "done")],
              counters: [count("search space", Math.max(0, newHi - newLo + 1), n), count("mid compared", probes)],
              legend: at === mid ? ["good", "active", "dim", "done"] : ["done", "active", "dim"],
              happened,
              why,
              codeLine,
            });
            lo = newLo; hi = newHi;
          }

          if (at < 0) {
            steps.push({
              title: "Window empty → target absent",
              tracks: [row(fill(n, "dim")), ptrTrack(lo, hi, null)],
              counters: [count("search space", 0), count("mid compared", probes)],
              legend: ["dim", "active"],
              happened: `The pointers crossed without a single match, so ${target} never appears in the row.`,
              why: "A fully eliminated window proves absence — there is no copy from which a walk could start.",
              codeLine: 12,
            });
            steps.push({
              title: "Answer: [-1, -1]",
              tracks: [row(fill(n, "dim")), { label: "answer", cells: [{ v: "[-1, -1]", state: "result", tag: "not found" }] }],
              counters: [count("first", -1), count("last", -1), count("mid compared", probes)],
              legend: ["result", "dim"],
              happened: `No copy of ${target} exists, so neither edge can be reported.`,
              why: "Phase 2 never runs — a walk needs a starting copy, and there is none.",
              codeLine: 12,
            });
            return steps;
          }

          /* ---- phase 2: walk left ---- */
          let first = at, last = at;
          while (first - 1 >= 0 && arr[first - 1] === target) {
            first--;
            steps.push({
              title: `Walk left: index ${first} also equals ${target} → first = ${first}`,
              tracks: [row(walkStates(first, last, first), walkTags(first, last))],
              counters: [count("first", first), count("last", last), count("run length", last - first + 1)],
              legend: ["good", "read", "dim"],
              happened: `The neighbour left of the run, ${arr[first]}, matches too — the left edge slides to index ${first}.`,
              why: "The walk only moves while neighbours keep matching; each step extends the known run by exactly one copy.",
              codeLine: 13,
            });
          }
          steps.push({
            title: first === 0
              ? "Left edge locked: index 0 is the start of the row"
              : `Left edge locked: ${arr[first - 1]} ≠ ${target}`,
            tracks: [row(walkStates(first, last, first - 1), walkTags(first, last))],
            counters: [count("first", first), count("last", last), count("run length", last - first + 1)],
            legend: ["good", "read", "dim"],
            happened: first === 0
              ? "There is nothing further left to test — the run begins at the very first cell."
              : `Testing ${arr[first - 1]} at index ${first - 1} failed the match, so the run cannot extend any further left.`,
            why: "A single differing neighbour is a definitive stop sign — sorted order forbids another copy from hiding beyond it.",
            codeLine: 13,
          });

          /* ---- phase 2: walk right ---- */
          while (last + 1 < n && arr[last + 1] === target) {
            last++;
            steps.push({
              title: `Walk right: index ${last} also equals ${target} → last = ${last}`,
              tracks: [row(walkStates(first, last, last), walkTags(first, last))],
              counters: [count("first", first), count("last", last), count("run length", last - first + 1)],
              legend: ["good", "read", "dim"],
              happened: `The neighbour right of the run, ${arr[last]}, matches too — the right edge slides to index ${last}.`,
              why: "Same rule mirrored: keep stepping while the next cell still equals the target.",
              codeLine: 14,
            });
          }
          steps.push({
            title: last === n - 1
              ? "Right edge locked: last index is the end of the row"
              : `Right edge locked: ${arr[last + 1]} ≠ ${target}`,
            tracks: [row(walkStates(first, last, last + 1), walkTags(first, last))],
            counters: [count("first", first), count("last", last), count("run length", last - first + 1)],
            legend: ["good", "read", "dim"],
            happened: last === n - 1
              ? "There is nothing further right to test — the run ends at the very last cell."
              : `Testing ${arr[last + 1]} at index ${last + 1} failed the match, so the run cannot extend any further right.`,
            why: "Both walkers have now hit a wall — together they bracket every copy of the target.",
            codeLine: 14,
          });

          steps.push({
            title: `Answer: first ${first}, last ${last}`,
            tracks: [
              row(shown.map((v, i) => (i >= first && i <= last ? "result" : "dim")), walkTags(first, last)),
              { label: "answer", cells: [{ v: `[${first}, ${last}]`, state: "result", tag: "edges" }] },
            ],
            counters: [count("first", first), count("last", last), count("mid compared", probes)],
            legend: ["result", "dim"],
            happened: `Starting from one random copy at index ${at}, the two walkers bracketed the run: ${first} to ${last}.`,
            why: `About log2(${n}) probes found the entry point and ${last - first} single steps measured the run — linear only in the number of copies.`,
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "first-bad-version",
    title: "First Bad Version",
    category: "Binary Search",
    difficulty: "Beginner",
    description: "Find the earliest broken release while asking the isBadVersion API as few times as possible.",
    input: { label: "versions, firstBad (e.g. 10 4)", default: "10 4", parse: "ints" },
    approaches: [
      {
        name: "Halve the Release Line",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "Releases are numbered 1..n and once a version goes bad every later one is bad too — so the truth looks like good…good bad…bad with one hidden cut-off. That is just a sorted row of zeros and ones.",
          "Ask isBadVersion at the midpoint. A 'bad' answer means the cut-off is at or before mid (record mid as a candidate answer, drop the right half); a 'good' answer means it is strictly after mid. Repeat until the window dies, and the last bad candidate recorded is the answer.",
        ],
        problem: [
          "You never get to read the versions yourself — everything depends on a black-box call, so if the API is slow, log2(n) slow calls is still real waiting.",
          "If no bad version exists (or n is 0) the window empties with no candidate and the answer is -1; the code must treat that as a legitimate outcome, not an error.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdbool.h>

/* pretend API: versions 1..3 are good, 4 and up are bad */
bool is_bad(int v) { return v >= 4; }

/* first bad version among 1..n, or -1 */
int first_bad(int n) {
    int lo = 1, hi = n, ans = -1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (is_bad(mid)) { ans = mid; hi = mid - 1; }
        else lo = mid + 1;
    }
    return ans;
}

int main(void) {
    printf("%d\\n", first_bad(10)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>

// pretend API: versions 1..3 are good, 4 and up are bad
bool isBad(int v) { return v >= 4; }

// first bad version among 1..n, or -1
int firstBad(int n) {
    int lo = 1, hi = n, ans = -1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (isBad(mid)) { ans = mid; hi = mid - 1; }
        else lo = mid + 1;
    }
    return ans;
}

int main() {
    std::cout << firstBad(10) << '\\n'; // 4
}`,
        },
        steps(parsed) {
          const versions = Math.max(0, Math.floor(parsed[0]));
          const firstBad = parsed.length > 1 ? Math.floor(parsed[1]) : 1;
          const bad = (v) => v >= firstBad;
          const showVers = versions > 0 && versions <= 40;
          const versVals = showVers ? Array.from({ length: versions }, (_, i) => i + 1) : [];
          const steps = [];
          const isBadTrack = (mid, b) => ({
            label: `isBadVersion(${mid})`,
            cells: [{ v: b ? "true" : "false", state: b ? "bad" : "good", tag: "API says" }],
          });
          const candTrack = (ans) => ({
            label: "first bad so far",
            cells: [{ v: ans < 0 ? "—" : ans, state: ans < 0 ? "idle" : "result", tag: "candidate" }],
          });
          const vStates = (lo, hi, mid, overrides) =>
            showVers
              ? winStates(versions, lo - 1, hi - 1, mid == null ? null : mid - 1, "read").map((s, i) =>
                  overrides && overrides[i] != null ? overrides[i] : s
                )
              : [];

          steps.push({
            title: `Setup: ${versions} release${versions === 1 ? "" : "s"}, window 1..${versions}`,
            tracks: [
              ...(showVers ? [track("versions", versVals, fill(versions, "idle"))] : []),
              ptrTrack(1, versions, null),
              candTrack(-1),
            ],
            counters: [count("versions in window", versions), count("API calls", 0)],
            legend: ["read", "active", "idle", "result"],
            happened: versions
              ? `Versions 1 to ${versions} are lined up. Our only tool is isBadVersion(v) — where the good versions stop is hidden from us.`
              : "There are no releases at all — lo starts at 1 and hi at 0.",
            why: "Scanning every release would cost n API calls; the plan is to keep halving the window instead.",
            codeLine: 8,
          });

          steps.push({
            title: "Rule: once bad, always bad — one hidden cut-off",
            tracks: [
              ...(showVers ? [track("versions", versVals, fill(versions, "idle"))] : []),
              ptrTrack(1, versions, null),
              candTrack(-1),
            ],
            counters: [count("versions in window", versions), count("API calls", 0)],
            legend: ["idle", "active", "result"],
            happened: "Versions never heal: everything before the first bad one is good, everything from it onward is bad — a single boundary splits the line.",
            why: "That boundary behaves like the first 1 in a sorted row of zeros, which is exactly the shape binary search exploits.",
            codeLine: 3,
          });

          let lo = 1, hi = versions, ans = -1, probes = 0;
          if (lo > hi) {
            steps.push({
              title: "Empty window — the loop never runs",
              tracks: [ptrTrack(1, versions, null), candTrack(-1)],
              counters: [count("versions in window", 0), count("API calls", 0)],
              legend: ["active", "idle"],
              happened: `lo = 1 is already past hi = ${versions}, so while (lo <= hi) is false from the start.`,
              why: "With no versions there is nothing to ask the API about — absence is decided by the window itself.",
              codeLine: 9,
            });
            steps.push({
              title: "Answer: no bad version (-1)",
              tracks: [{ label: "answer", cells: [{ v: -1, state: "result", tag: "no releases" }] }],
              counters: [count("answer", -1), count("API calls", 0)],
              legend: ["result"],
              happened: "Zero API calls were needed: an empty release line has no bad version.",
              why: "Guarding for n = 0 up front keeps the search loop honest instead of letting it probe versions that do not exist.",
              codeLine: 14,
            });
            return steps;
          }

          while (lo <= hi) {
            const mid = lo + Math.floor((hi - lo) / 2);
            probes++;
            steps.push({
              title: `Probe: mid = ${mid} → ask isBadVersion(${mid})`,
              tracks: [
                ...(showVers ? [track("versions", versVals, vStates(lo, hi, mid))] : []),
                ptrTrack(lo, hi, mid),
                candTrack(ans),
              ],
              counters: [count("versions in window", hi - lo + 1, versions), count("API calls", probes)],
              legend: ["read", "active", "dim", "result"],
              happened: `lo = ${lo}, hi = ${hi} → mid = ${mid}. One question covers the ${hi - lo + 1} versions still possible.`,
              why: "Whatever the answer, half of the remaining releases disappear — that trade is the whole cost story.",
              codeLine: 10,
            });
            const b = bad(mid);
            let newLo = lo, newHi = hi, title, happened, why, codeLine;
            if (b) {
              ans = mid;
              newHi = mid - 1;
              title = `isBadVersion(${mid}) = true → cut-off is at or before ${mid} → hi = ${newHi}`;
              happened = `Version ${mid} is bad, so it becomes the best candidate so far and everything after it (${mid}..${hi}) is ruled out.`;
              why = "If mid is bad, an earlier version might be bad too — keep mid as a candidate and search the left half for something even earlier.";
              codeLine = 11;
            } else {
              newLo = mid + 1;
              title = `isBadVersion(${mid}) = false → cut-off is after ${mid} → lo = ${newLo}`;
              happened = `Version ${mid} is good, so the boundary must sit to its right — lo climbs to ${newLo}.`;
              why = "Versions never heal, so a good midpoint proves the whole left half is good; those calls are never needed again.";
              codeLine = 12;
            }
            const overrides = {};
            if (showVers) overrides[mid - 1] = b ? "bad" : "good";
            steps.push({
              title,
              tracks: [
                ...(showVers ? [track("versions", versVals, vStates(newLo, newHi, null, overrides))] : []),
                ptrTrack(newLo, newHi, mid, "done"),
                isBadTrack(mid, b),
                candTrack(ans),
              ],
              counters: [count("versions in window", Math.max(0, newHi - newLo + 1), versions), count("API calls", probes), count("candidate", ans < 0 ? "—" : ans)],
              legend: ["good", "bad", "done", "active", "dim", "result"],
              happened,
              why,
              codeLine,
            });
            lo = newLo; hi = newHi;
          }

          if (ans < 0) {
            if (showVers) {
              steps.push({
                title: "Answer: no bad version among 1..n (-1)",
                tracks: [
                  track("versions", versVals, fill(versions, "good")),
                  { label: "answer", cells: [{ v: -1, state: "result", tag: "all good" }] },
                ],
                counters: [count("answer", -1), count("API calls", probes)],
                legend: ["good", "result"],
                happened: `Every probe came back false and the window died — all ${versions} releases are good (the true cut-off ${firstBad} lies outside 1..${versions}).`,
                why: "Recording a candidate only on 'true' answers means an untouched candidate stays -1 — the loop cannot invent a bad version.",
                codeLine: 14,
              });
            } else {
              steps.push({
                title: "Answer: no bad version among 1..n (-1)",
                tracks: [
                  ptrTrack(lo, hi, null),
                  { label: "answer", cells: [{ v: -1, state: "result", tag: "all good" }] },
                ],
                counters: [count("answer", -1), count("API calls", probes)],
                legend: ["result", "active"],
                happened: `After ${probes} calls every one returned false — the window is empty and no candidate was ever recorded (the true cut-off ${firstBad} lies outside 1..${versions}).`,
                why: "Recording a candidate only on 'true' answers means an untouched candidate stays -1 — the loop cannot invent a bad version.",
                codeLine: 14,
              });
            }
            return steps;
          }

          const tags = new Array(versions).fill(undefined);
          if (showVers) tags[ans - 1] = "first bad";
          steps.push({
            title: `Answer: version ${ans} is the first bad one`,
            tracks: [
              ...(showVers
                ? [track("versions", versVals, versVals.map((v) => (v < ans ? "good" : v === ans ? "result" : "bad")), tags)]
                : []),
              { label: "answer", cells: [{ v: ans, state: "result", tag: "first bad" }] },
            ],
            counters: [count("answer", ans), count("API calls", probes)],
            legend: showVers ? ["good", "bad", "result"] : ["result"],
            happened: `The window crossed with ${ans} as the last 'true' answer recorded — and nothing earlier was ever bad, so ${ans} is the boundary.`,
            why: `${probes} API calls located one cut-off out of ${versions} releases — a linear check could have needed ${versions}.`,
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "search-in-rotated-sorted-array",
    title: "Search in Rotated Sorted Array",
    category: "Binary Search",
    difficulty: "Intermediate",
    description: "Binary search a row that was cut in half and glued back together with the front moved to the back.",
    input: { label: "Rotated numbers, then the target (last value)", default: "4, 5, 6, 7, 0, 1, 2, 0", parse: "ints" },
    approaches: [
      {
        name: "Which Half Is Sorted?",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "After rotation the row is two ascending runs joined at the bottom. At every probe, compare a[lo] with a[mid]: if the left end is not above the middle, indices lo..mid form one clean sorted run; otherwise the clean run is the right side (mid..hi).",
          "Exactly one half is always unbroken, so test whether the target lies inside that sorted run using its two ends. If it fits, discard the other half — if not, discard the sorted half itself. The window still halves every round.",
        ],
        problem: [
          "The method assumes a genuine rotation of a strictly increasing row. Duplicates break the 'exactly one clean half' logic (a[lo] == a[mid] can hide the drop), and an unsorted row makes the sorted-run test meaningless.",
          "This finds only whether the target exists (an index is a bonus), and with duplicates present some solutions degrade to O(n) — the version here keeps the loop but can no longer promise a correct verdict.",
        ],
        code: {
          c: `#include <stdio.h>

/* index of target in a rotated strictly increasing row, or -1 */
int search_rotated(const int *a, int n, int target) {
    int lo = 0, hi = n - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (a[lo] <= a[mid]) {              /* left half is sorted */
            if (a[lo] <= target && target < a[mid]) hi = mid - 1;
            else lo = mid + 1;
        } else {                            /* right half is sorted */
            if (a[mid] < target && target <= a[hi]) lo = mid + 1;
            else hi = mid - 1;
        }
    }
    return -1;
}

int main(void) {
    int a[] = {4, 5, 6, 7, 0, 1, 2};
    printf("%d\\n", search_rotated(a, 7, 0)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// index of target in a rotated strictly increasing row, or -1
int searchRotated(const std::vector<int>& a, int target) {
    int lo = 0, hi = (int)a.size() - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (a[lo] <= a[mid]) {            // left half is sorted
            if (a[lo] <= target && target < a[mid]) hi = mid - 1;
            else lo = mid + 1;
        } else {                          // right half is sorted
            if (a[mid] < target && target <= a[hi]) lo = mid + 1;
            else hi = mid - 1;
        }
    }
    return -1;
}

int main() {
    std::vector<int> a{4, 5, 6, 7, 0, 1, 2};
    std::cout << searchRotated(a, 0) << '\\n'; // 4
}`,
        },
        steps(parsed) {
          const { arr, target } = splitTarget(parsed);
          const n = arr.length;
          const shown = n ? arr : ["∅"];
          const issue = rotationIssue(arr);
          const steps = [];
          const row = (st) => track("the numbers", shown, st);
          let drop = -1;
          for (let i = 0; i < n; i++) if (arr[i] < arr[(i - 1 + n) % n]) { drop = i; break; }

          steps.push({
            title: "Setup: one window over the rotated row",
            tracks: [row(fill(n, "idle")), ptrTrack(0, n - 1, null)],
            counters: [count("search space", n), count("mid compared", 0)],
            legend: ["read", "active", "idle", "dim"],
            happened: n
              ? drop >= 0
                ? `${n} numbers — a sorted row whose rotation point is index ${drop}: ${arr.join(", ")}. Target: ${target}.`
                : `${n} number${n === 1 ? "" : "s"} — ${arr.join(", ")}. Target: ${target}.`
              : `The input held a single number, so it became the target ${target} and the row is empty.`,
            why: "Rotation hides the sorted order globally but not locally — each probe will decide which side of the window is still a clean run.",
            codeLine: 4,
          });

          if (issue) {
            steps.push({
              title: `Rotation check fails: ${issue.text}`,
              tracks: [row(fill(n, "dim")), ptrTrack(0, n - 1, null)],
              counters: [count("search space", n), count("mid compared", 0)],
              legend: ["dim", "active"],
              happened: `Walking around the circle, ${issue.text} — this is not the cut-and-glue of one sorted row.`,
              why: "The search below still terminates safely, but its 'which half is sorted' verdict can be wrong — treat the result as a hint only.",
              codeLine: 8,
            });
          } else {
            steps.push({
              title: n <= 1 ? "Rotation check: trivially a clean rotation" : drop === 0 ? "Rotation check: plain sorted row (a rotation by 0)" : `Rotation check: one drop at index ${drop} — a clean rotation`,
              tracks: [row(fill(n, "good")), ptrTrack(0, n - 1, null)],
              counters: [count("search space", n), count("mid compared", 0)],
              legend: ["good", "active"],
              happened: n <= 1
                ? "At most one number — every rotation of it is itself."
                : drop === 0
                  ? `The only downward step is the wrap from ${arr[n - 1]} back to ${arr[0]}, so the row was never actually rotated — it is fully sorted.`
                  : `Exactly one downward step exists, at index ${drop} (${arr[drop]} < ${arr[drop - 1]}), and no value repeats — a genuine rotation.`,
              why: "With a real rotation, at least one half of any window is an unbroken sorted run — that is the invariant every probe relies on.",
              codeLine: 8,
            });
          }

          if (n === 0) {
            steps.push({
              title: "Empty window — the loop never runs",
              tracks: [row(fill(shown.length, "idle")), ptrTrack(0, -1, null)],
              counters: [count("search space", 0), count("mid compared", 0)],
              legend: ["active", "idle", "dim"],
              happened: "lo is already past hi, so while (lo <= hi) is false before the first probe.",
              why: "An empty window is instantly 'not found' — there is no cell that could equal the target.",
              codeLine: 5,
            });
            steps.push({
              title: "Answer: not found (-1)",
              tracks: [row(fill(shown.length, "dim")), ptrTrack(0, -1, null)],
              counters: [count("answer", -1), count("mid compared", 0)],
              legend: ["dim", "idle"],
              happened: `The row is empty, so ${target} cannot be in it.`,
              why: "Guarding the empty case keeps the loop from computing a middle index for a window that does not exist.",
              codeLine: 16,
            });
            return steps;
          }

          let lo = 0, hi = n - 1, probes = 0, found = -1;
          while (lo <= hi && found < 0) {
            const mid = lo + Math.floor((hi - lo) / 2);
            probes++;
            steps.push({
              title: `Probe: mid = ${mid} → inspect ${arr[mid]}`,
              tracks: [row(winStates(n, lo, hi, mid, "read")), ptrTrack(lo, hi, mid)],
              counters: [count("search space", hi - lo + 1, n), count("mid compared", probes)],
              legend: ["read", "active", "dim"],
              happened: `lo = ${lo}, hi = ${hi} → mid = ${mid} holds ${arr[mid]}. The window still holds ${hi - lo + 1} numbers.`,
              why: "Before trusting any comparison the probe must first identify which half of the window is the unbroken sorted run.",
              codeLine: 6,
            });
            const leftSorted = arr[lo] <= arr[mid];
            let newLo = lo, newHi = hi, title, happened, why, codeLine;
            if (arr[mid] === target) {
              found = mid;
              title = `Match: ${arr[mid]} equals the target → found at index ${mid}`;
              happened = `The probe landed on ${target} itself — the search stops here.`;
              why = "Rotation or not, an equality test at the middle needs no sorted-run reasoning at all.";
              codeLine = 7;
            } else if (leftSorted) {
              const fits = arr[lo] <= target && target < arr[mid];
              if (fits) { newHi = mid - 1; codeLine = 9; } else { newLo = mid + 1; codeLine = 10; }
              title = fits
                ? `Left half ${lo}..${mid} is sorted and contains ${target} → hi = ${newHi}`
                : `Left half ${lo}..${mid} is sorted but misses ${target} → lo = ${newLo}`;
              happened = `a[${lo}] = ${arr[lo]} is not above a[${mid}] = ${arr[mid]}, so indices ${lo}..${mid} climb ${arr[lo]} → ${arr[mid]} without a dip. ` +
                (fits
                  ? `The target fits inside that climb, so everything from ${mid} onwards is discarded.`
                  : `${arr[lo]}..${arr[mid]} never reaches ${target}, so the answer must hide in the right part.`);
              why = "When the left end is not above the middle, the left half is one clean sorted run — and only a clean run can be trusted for a range test.";
            } else {
              const fits = arr[mid] < target && target <= arr[hi];
              if (fits) { newLo = mid + 1; codeLine = 12; } else { newHi = mid - 1; codeLine = 13; }
              title = fits
                ? `Right half ${mid}..${hi} is sorted and contains ${target} → lo = ${newLo}`
                : `Right half ${mid}..${hi} is sorted but misses ${target} → hi = ${newHi}`;
              happened = `a[${lo}] = ${arr[lo]} sits above a[${mid}] = ${arr[mid]}, so the rotation point is left of mid — indices ${mid}..${hi} climb ${arr[mid]} → ${arr[hi]} cleanly. ` +
                (fits
                  ? `The target fits inside that climb, so everything left of ${mid} is discarded.`
                  : `${arr[mid]}..${arr[hi]} never reaches ${target}, so the answer must hide in the left part.`);
              why = "The opposite ends pin the clean run on the right side — comparing a[lo] with a[mid] is how rotation is detected without a separate scan.";
            }
            steps.push({
              title,
              tracks: [
                row(paint(winStates(n, newLo, newHi, null), { [mid]: found === mid ? "good" : "done" })),
                ptrTrack(newLo, newHi, mid, found === mid ? "good" : "done"),
              ],
              counters: [count("search space", Math.max(0, newHi - newLo + 1), n), count("mid compared", probes)],
              legend: found === mid ? ["good", "active", "dim", "done"] : ["done", "active", "dim"],
              happened,
              why,
              codeLine,
            });
            lo = newLo; hi = newHi;
          }

          if (found >= 0) {
            steps.push({
              title: `Answer: index ${found}`,
              tracks: [
                row(shown.map((v, i) => (i === found ? "result" : "dim"))),
                ptrTrack(lo, hi, found, "result"),
              ],
              counters: [count("answer", found), count("mid compared", probes)],
              legend: ["result", "dim"],
              happened: `After ${probes} probes the window reports ${target} at index ${found} — the bottom of the rotation happens to hold it.`,
              why: `The loop halved like ordinary binary search; the only extra work was one comparison per probe to pick the sorted half.`,
              codeLine: 21,
            });
          } else {
            steps.push({
              title: "Answer: not found (-1)",
              tracks: [row(fill(n, "dim")), ptrTrack(lo, hi, null)],
              counters: [count("answer", -1), count("mid compared", probes)],
              legend: ["dim", "active"],
              happened: `The window crossed without ever landing on ${target}.`,
              why: issue
                ? "The row is not a genuine rotation, so this 'absent' verdict is only as trustworthy as the broken precondition."
                : "Every probe discarded a provably out-of-range half, so an empty window proves the target is absent.",
              codeLine: 16,
            });
          }
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-minimum-in-rotated-sorted-array",
    title: "Find Minimum in Rotated Sorted Array",
    category: "Binary Search",
    difficulty: "Intermediate",
    description: "Locate the bottom of a rotated sorted row — the rotation point — without scanning it.",
    input: { label: "Rotated sorted numbers", default: "4, 5, 6, 7, 0, 1, 2", parse: "ints" },
    approaches: [
      {
        name: "Chase the Drop Against the Right End",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "The minimum of a rotated sorted row is exactly where it falls: the last step of the high run down into the low run. So keep a window that is guaranteed to contain that fall, and shrink it using a single question at mid — is a[mid] above a[hi]?",
          "If mid is above the right end, mid still sits in the high run and the fall is further right: jump lo past mid. Otherwise mid is at or below the bottom's level, so the fall is at mid or to its left: pull hi down onto mid (keeping mid in play, since mid could BE the minimum). The window shrinks every round until lo and hi meet on the answer.",
        ],
        problem: [
          "Comparing against a[hi] — the right end — is the non-obvious part; comparing against the left end breaks as soon as rotation moves the high run around.",
          "It assumes a genuine rotation of strictly increasing values. With duplicates (or no rotation at all) the comparison can mislead; the loop still terminates, but the surviving index may not be the true minimum.",
        ],
        code: {
          c: `#include <stdio.h>

/* index of the minimum in a rotated strictly increasing row */
int find_min(const int *a, int n) {
    int lo = 0, hi = n - 1;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] > a[hi]) lo = mid + 1;   /* the drop is ahead */
        else hi = mid;                      /* min is mid or left */
    }
    return lo;
}

int main(void) {
    int a[] = {4, 5, 6, 7, 0, 1, 2};
    printf("%d\\n", find_min(a, 7)); /* 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>

// index of the minimum in a rotated strictly increasing row
int findMin(const std::vector<int>& a) {
    int lo = 0, hi = (int)a.size() - 1;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] > a[hi]) lo = mid + 1;   // the drop is ahead
        else hi = mid;                      // min is mid or left
    }
    return lo;
}

int main() {
    std::vector<int> a{4, 5, 6, 7, 0, 1, 2};
    std::cout << findMin(a) << '\\n'; // 4
}`,
        },
        steps(parsed) {
          const arr = parsed.slice();
          const n = arr.length;
          const shown = n ? arr : ["∅"];
          const issue = rotationIssue(arr);
          const steps = [];
          const row = (st, tags) => track("the numbers", shown, st, tags);
          let drop = -1;
          for (let i = 0; i < n; i++) if (arr[i] < arr[(i - 1 + n) % n]) { drop = i; break; }

          steps.push({
            title: "Setup: one window over the whole rotated row",
            tracks: [row(fill(n, "idle")), ptrTrack(0, n - 1, null)],
            counters: [count("candidates", n), count("mid compared", 0)],
            legend: ["read", "active", "idle", "dim"],
            happened: n
              ? `${n} numbers forming one sorted row rotated at the bottom: ${arr.join(", ")}. The smallest value is hiding somewhere inside.`
              : "There are no numbers at all — nothing to minimise.",
            why: "No scanning allowed: the rotation point (and hence the minimum) must be pinned down by halving.",
            codeLine: 4,
          });

          if (issue) {
            steps.push({
              title: `Rotation check fails: ${issue.text}`,
              tracks: [row(fill(n, "dim")), ptrTrack(0, n - 1, null)],
              counters: [count("candidates", n), count("mid compared", 0)],
              legend: ["dim", "active"],
              happened: `Walking around the circle, ${issue.text} — this is not the cut-and-glue of one sorted row.`,
              why: "The loop below still shrinks safely and terminates, but its 'has mid passed the drop' verdict can be wrong — treat the result as a hint only.",
              codeLine: 7,
            });
          } else {
            steps.push({
              title: n <= 1 ? "Rotation check: trivially a clean rotation" : drop === 0 ? "Rotation check: plain sorted row (a rotation by 0)" : `Rotation check: one drop at index ${drop} — a clean rotation`,
              tracks: [row(fill(n, "good")), ptrTrack(0, n - 1, null)],
              counters: [count("candidates", n), count("mid compared", 0)],
              legend: ["good", "active"],
              happened: n <= 1
                ? "At most one number — every rotation of it is itself, so it is already the minimum."
                : drop === 0
                  ? `The only downward step is the wrap from ${arr[n - 1]} back to ${arr[0]} — the row was never rotated, and its minimum sits at index 0.`
                  : `Exactly one downward step exists, at index ${drop} (${arr[drop]} < ${arr[drop - 1]}), and no value repeats — the minimum must be that step's low side.`,
              why: "One single fall is the whole structure this search exploits: everything left of it is high, everything right is low.",
              codeLine: 5,
            });
          }

          if (n === 0) {
            steps.push({
              title: "Empty row — nothing to search",
              tracks: [row(fill(shown.length, "idle")), ptrTrack(0, -1, null)],
              counters: [count("candidates", 0), count("mid compared", 0)],
              legend: ["idle", "dim"],
              happened: "There is no cell that could hold a minimum.",
              why: "Guarding the empty case keeps the loop from ever computing a middle index for a window that does not exist.",
              codeLine: 9,
            });
            steps.push({
              title: "Answer: no minimum (-1)",
              tracks: [row(fill(shown.length, "dim")), { label: "answer", cells: [{ v: -1, state: "result", tag: "empty" }] }],
              counters: [count("answer", -1), count("mid compared", 0)],
              legend: ["result", "dim"],
              happened: "An empty row has no smallest value to report.",
              why: "Returning a sentinel instead of indexing a[0] is what keeps the function crash-free on empty input.",
              codeLine: 9,
            });
            return steps;
          }

          steps.push({
            title: `Ready: ${n} candidate${n === 1 ? "" : "s"} inside lo 0 .. hi ${n - 1}`,
            tracks: [row(winStates(n, 0, n - 1, null)), ptrTrack(0, n - 1, null)],
            counters: [count("candidates", n), count("mid compared", 0)],
            legend: ["active", "read", "dim"],
            happened: "Every index is a candidate: while lo < hi the window keeps the fall — and the minimum with it — inside lo..hi.",
            why: "The invariant to protect: no probe may discard the minimum, so each round must shrink the window but never past it.",
            codeLine: 5,
          });

          let lo = 0, hi = n - 1, probes = 0;
          while (lo < hi) {
            const mid = lo + Math.floor((hi - lo) / 2);
            probes++;
            steps.push({
              title: `Probe: mid = ${mid} → weigh ${arr[mid]} against the right end ${arr[hi]}`,
              tracks: [row(winStates(n, lo, hi, mid, "read")), ptrTrack(lo, hi, mid)],
              counters: [count("candidates", hi - lo + 1, n), count("mid compared", probes)],
              legend: ["read", "active", "dim"],
              happened: `lo = ${lo}, hi = ${hi} → mid = ${mid} holds ${arr[mid]}; the right end of the window holds ${arr[hi]}.`,
              why: "The right end is the reference point: it always sits in the low run after the fall, so comparing mid against it tests whether mid has passed the bottom yet.",
              codeLine: 6,
            });
            const jump = arr[mid] > arr[hi];
            const newLo = jump ? mid + 1 : lo;
            const newHi = jump ? hi : mid;
            steps.push({
              title: jump
                ? `${arr[mid]} > ${arr[hi]} → mid is still high, the drop is ahead → lo = ${newLo}`
                : `${arr[mid]} ≤ ${arr[hi]} → mid is at or below the bottom's level → hi = ${newHi}`,
              tracks: [
                row(paint(winStates(n, newLo, newHi, null), { [mid]: "done" })),
                ptrTrack(newLo, newHi, mid, "done"),
              ],
              counters: [count("candidates", newHi - newLo + 1, n), count("mid compared", probes)],
              legend: ["done", "active", "dim"],
              happened: jump
                ? `${arr[mid]} towers over the right end ${arr[hi]}, so indices ${lo}..${mid} are all part of the high run before the fall — lo jumps to ${newLo}, cutting the window to ${newHi - newLo + 1} candidates.`
                : `${arr[mid]} is not above ${arr[hi]}, so mid has not passed the fall: the minimum is mid itself or something to its left. hi settles on ${mid}, keeping ${arr[mid]} in play.`,
              why: jump
                ? "If mid is still high, the bottom cannot be at or left of mid — the whole left part, mid included, is safely discarded."
                : "Pulling hi down onto mid (rather than past it) is essential: mid could be the minimum itself.",
              codeLine: jump ? 7 : 8,
            });
            lo = newLo; hi = newHi;
          }

          steps.push({
            title: `Loop ends: lo = hi = ${lo}${probes === 0 ? " — a single candidate from the start" : " — one candidate left"}`,
            tracks: [row(paint(fill(n, "dim"), { [lo]: "read" })), ptrTrack(lo, hi, lo)],
            counters: [count("candidates", 1, n), count("mid compared", probes)],
            legend: ["read", "dim"],
            happened: probes === 0
              ? `lo and hi already agreed on index ${lo}, so while (lo < hi) was false before any probe.`
              : `Each round either jumped past a too-large mid or pulled hi down onto it — now lo and hi meet at index ${lo} and the window cannot shrink further.`,
            why: "Once the window holds a single index, that index must be the fall: the invariant kept the minimum inside every round.",
            codeLine: 9,
          });

          const tags = new Array(shown.length).fill(undefined);
          tags[lo] = "min";
          steps.push({
            title: `Answer: index ${lo} → value ${arr[lo]}`,
            tracks: [
              row(shown.map((v, i) => (i === lo ? "result" : "dim")), tags),
              { label: "answer", cells: [{ v: arr[lo], state: "result", tag: `index ${lo}` }] },
            ],
            counters: [count("answer", arr[lo]), count("index", lo), count("mid compared", probes)],
            legend: ["result", "dim"],
            happened: `${arr[lo]} at index ${lo} is the bottom of the rotation${issue ? " — though the row is not a genuine rotation, so treat this as a hint" : ""}.`,
            why: `Each probe compared two cells and kept half the window — about log2(${n}) probes beat walking all ${n} values looking for a dip.`,
            codeLine: 15,
          });
          return steps;
        },
      },
    ],
  });
})();
