/* ============================================================
   DSA Visuals - NeetCode 250 additions, heaps and graphs
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, grid } = window.H;
  const V = window.VIZ;

  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => "[" + a.join(", ") + "]";
  const ints = (s) => String(s || "").split(/[\s,;]+/).filter(Boolean).map(Number).filter(Number.isFinite);
  const pairs = (s) => String(s || "").split(/[\s;|]+/).filter(Boolean).map((p) => p.split(",").map(Number)).filter((p) => p.length >= 2 && p.every(Number.isFinite));
  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];

  /* ---------------------------------------------------------- */
  V.register({
    id: "kth-largest-integer-in-a-stream",
    title: "Kth Largest Element In a Stream",
    category: "Heap / Priority Queue",
    difficulty: "Beginner",
    description: "Keep only the k largest values seen so far and report the smallest of them.",
    input: { label: "k followed by added values", default: "3, 4, 5, 8, 2", parse: "ints" },
    approaches: [
      {
        name: "Min-Heap of Size k",
        complexity: "O(log k) per add, O(k) space",
        idea: [
          "Maintain a min-heap containing at most k values. The heap's root is therefore the smallest of the k largest values, which is exactly the kth largest.",
          "After adding a value, remove the root if the heap grows beyond k. Small values are evicted first.",
        ],
        problem: ["A min-heap is intentionally used even though the question asks for a largest value; the root gives the needed boundary cheaply."],
        code: {
          c: `#include <stdlib.h>

typedef struct { int* a; int n, k; } KthLargest;

void swap(int* a, int* b) { int t = *a; *a = *b; *b = t; }
void up(int* a, int i) {
    while (i && a[(i-1)/2] > a[i]) { swap(&a[i], &a[(i-1)/2]); i = (i-1)/2; }
}
void down(int* a, int n, int i) {
    while (2*i+1 < n) {
        int j = 2*i+1;
        if (j+1 < n && a[j+1] < a[j]) j++;
        if (a[i] <= a[j]) break;
        swap(&a[i], &a[j]); i = j;
    }
}

int add(KthLargest* h, int val) {
    h->a[h->n++] = val;
    up(h->a, h->n - 1);
    if (h->n > h->k) { h->a[0] = h->a[--h->n]; down(h->a, h->n, 0); }
    return h->a[0];
}`,
          cpp: `#include <functional>
#include <queue>
#include <vector>
using namespace std;

class KthLargest {
    priority_queue<int, vector<int>, greater<int>> heap;
    int k;
public:
    KthLargest(int k, vector<int>& nums) : k(k) {
        for (int x : nums) add(x);
    }
    int add(int val) {
        heap.push(val);
        if ((int)heap.size() > k) heap.pop();
        return heap.top();
    }
};`,
        },
        steps(values) {
          const k = Math.max(1, values[0] || 1);
          const added = values.slice(1);
          const heap = [];
          const out = [];
          out.push({
            title: `Keep the ${k} largest values`,
            tracks: [chips("added values", added, "idle"), chips("heap", [], "idle")],
            counters: [count("k", k), count("heap size", 0, k)],
            happened: "The heap will hold at most k values, with its smallest at the root.",
            why: "The k - 1 larger values plus the root make the root the kth largest.",
            legend: LEG,
            codeLine: 12,
          });
          for (let i = 0; i < added.length; i++) {
            heap.push(added[i]);
            heap.sort((a, b) => a - b);
            if (heap.length > k) heap.shift();
            out.push({
              title: `Add ${added[i]}; kth largest is ${heap[0]}`,
              tracks: [chips("added values", added, (j) => (j === i ? "read" : j < i ? "done" : "idle")), chips("heap", heap, "active")],
              counters: [count("heap size", heap.length, k), count("kth largest", heap[0])],
              happened: `The heap now holds ${show(heap)}; its smallest value is ${heap[0]}.`,
              why: heap.length === k ? "The root is the boundary between the kept large values and the discarded small ones." : "The heap is not full yet, so every seen value is still kept.",
              legend: LEG,
              codeLine: 15,
            });
          }
          out.push({
            title: `Final kth largest is ${heap[0] ?? "-"}`,
            tracks: [chips("heap", heap, "result")],
            counters: [count("k", k), count("answer", heap[0] ?? "-")],
            happened: `The kept values are ${show(heap)}.`,
            why: "The min-heap root is always the kth largest among everything processed.",
            legend: LEG,
            codeLine: 17,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "design-twitter-feed",
    title: "Design Twitter",
    category: "Heap / Priority Queue",
    difficulty: "Intermediate",
    description: "Support posts, follows and a merged feed of the ten newest tweets.",
    input: { label: "Operations", default: "post 1 5 post 2 6 follow 1 2 get 1", parse: "words" },
    approaches: [
      {
        name: "Per-User Posts + Follow Set",
        complexity: "O(F log F + 10 log F) per feed, O(total posts) space",
        idea: [
          "Each user owns a list of posts with a global increasing timestamp. A follow table stores which users each user follows.",
          "For a feed, collect the newest post from every followed user (including the user), then repeatedly take the newest among those lists. That is a merge of sorted lists, naturally done with a heap.",
        ],
        problem: ["A real system shards posts and fans out feeds; this in-memory version is intentionally small and single-process."],
        code: {
          c: `#include <stdlib.h>
#include <string.h>

typedef struct { int user, time, tweet; } Post;
typedef struct { Post* posts; int n; } Feed;

void getFeed(Post** lists, int* sizes, int count, int* out, int* outN) {
    for (int i = 0; i < count; i++) {
        for (int j = 0; j < sizes[i]; j++) {
            out[(*outN)++] = lists[i][j].tweet;
        }
    }
    for (int i = 0; i < *outN; i++)
        for (int j = i + 1; j < *outN; j++)
            if (lists[0][0].time < lists[0][0].time) { }
}`,
          cpp: `#include <algorithm>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>
using namespace std;

class Twitter {
    int clock = 0;
    unordered_map<int, vector<pair<int,int>>> posts;
    unordered_map<int, unordered_set<int>> follows;
public:
    void postTweet(int u, int t) { posts[u].push_back({clock++, t}); }
    void follow(int a, int b) { follows[a].insert(b); }
    void unfollow(int a, int b) { follows[a].erase(b); }
    vector<int> getNewsFeed(int u) {
        vector<pair<int,int>> all = posts[u];
        for (int v : follows[u]) all.insert(all.end(), posts[v].begin(), posts[v].end());
        sort(all.rbegin(), all.rend());
        vector<int> out;
        for (int i = 0; i < (int)all.size() && i < 10; i++) out.push_back(all[i].second);
        return out;
    }
};`,
        },
        steps(ops) {
          const posts = new Map();
          const follows = new Map();
          let clock = 1;
          const out = [];
          out.push({
            title: "Posts carry increasing timestamps",
            tracks: [chips("operations", ops, "idle"), chips("feed", [], "idle")],
            counters: [count("users", 0), count("clock", 0)],
            happened: "A post is stored under its author with the next timestamp.",
            why: "The newest tweets are the ones with the largest timestamps.",
            legend: LEG,
            codeLine: 6,
          });
          let i = 0;
          while (i < ops.length) {
            const op = String(ops[i]).toLowerCase();
            if (op === "post" && i + 2 < ops.length) {
              const u = parseInt(ops[i + 1], 10);
              const t = parseInt(ops[i + 2], 10);
              if (!posts.has(u)) posts.set(u, []);
              posts.get(u).push([clock++, t]);
              out.push({
                title: `User ${u} posts ${t}`,
                tracks: [chips("operations", ops, (k) => (k >= i && k <= i + 2 ? "read" : k < i ? "done" : "idle")), chips("user " + u + " posts", posts.get(u).map((p) => p[1]), "active")],
                counters: [count("posts", [...posts.values()].reduce((s, a) => s + a.length, 0)), count("clock", clock - 1)],
                happened: `The post is timestamped ${clock - 1}.`,
                why: "A global clock keeps posts from different users comparable.",
                legend: LEG,
                codeLine: 7,
              });
              i += 3;
            } else if (op === "follow" && i + 2 < ops.length) {
              const a = parseInt(ops[i + 1], 10), b = parseInt(ops[i + 2], 10);
              if (!follows.has(a)) follows.set(a, new Set());
              follows.get(a).add(b);
              out.push({
                title: `User ${a} follows ${b}`,
                tracks: [chips("operations", ops, (k) => (k >= i && k <= i + 2 ? "read" : k < i ? "done" : "idle")), chips("follows", [...follows.entries()].map(([u, s]) => u + "->" + [...s].join("&")), "active")],
                counters: [count("follow edges", [...follows.values()].reduce((s, x) => s + x.size, 0)), count("users", new Set([...posts.keys(), ...follows.keys()]).size)],
                happened: `The follow set of user ${a} now contains ${b}.`,
                why: "A feed merges posts from the user and every followed user.",
                legend: LEG,
                codeLine: 8,
              });
              i += 3;
            } else if (op === "get" && i + 1 < ops.length) {
              const u = parseInt(ops[i + 1], 10);
              const feed = posts.get(u) ? posts.get(u).slice() : [];
              for (const v of follows.get(u) || []) feed.push(...(posts.get(v) || []));
              feed.sort((a, b) => b[0] - a[0]);
              const tweets = feed.slice(0, 10).map((p) => p[1]);
              out.push({
                title: `Feed for ${u}: ${show(tweets)}`,
                tracks: [chips("operations", ops, (k) => (k >= i && k <= i + 1 ? "read" : k < i ? "done" : "idle")), chips("feed tweets", tweets, "result")],
                counters: [count("posts considered", feed.length), count("returned", tweets.length, 10)],
                happened: "The merged posts were sorted by descending timestamp and cut to ten.",
                why: "Ten newest means the largest timestamps, regardless of which user wrote them.",
                legend: LEG,
                codeLine: 14,
              });
              i += 2;
            } else {
              i++;
            }
          }
          out.push({
            title: "Operations complete",
            tracks: [chips("users with posts", [...posts.keys()], "done")],
            counters: [count("users", posts.size), count("follow edges", [...follows.values()].reduce((s, x) => s + x.size, 0))],
            happened: "Post, follow and feed requests all use the same two tables.",
            why: "Separating authorship from following keeps each update small.",
            legend: LEG,
            codeLine: 16,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "single-threaded-cpu",
    title: "Single Threaded CPU",
    category: "Heap / Priority Queue",
    difficulty: "Intermediate",
    description: "Order tasks by when they become available and how long they take.",
    input: { label: "enqueue time, processing time", default: "1,2 2,4 3,2 4,1", parse: "pairs" },
    approaches: [
      {
        name: "Sort by Start, Heap by Duration",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "At any moment the CPU chooses the available task with the shortest processing time, breaking ties by index.",
          "Sort tasks by enqueue time. Push every task that has become available into a min-heap keyed by duration and index, then run the top task for its full duration.",
        ],
        problem: ["The CPU is idle whenever no task has arrived yet, so time must jump forward to the next enqueue time."],
        code: {
          c: `#include <stdlib.h>

typedef struct { int start, cost, idx; } Task;
int cmp(const void* a, const void* b) {
    Task* x = (Task*)a; Task* y = (Task*)b;
    if (x->start != y->start) return x->start - y->start;
    return x->idx - y->idx;
}

int* getOrder(int** tasks, int n, int* returnSize) {
    Task* t = malloc(n * sizeof(Task));
    for (int i = 0; i < n; i++) t[i] = (Task){tasks[i][0], tasks[i][1], i};
    qsort(t, n, sizeof(Task), cmp);
    int* out = malloc(n * sizeof(int));
    *returnSize = n;
    int i = 0, time = 0, k = 0;
    while (k < n) {
        int best = -1;
        for (int j = i; j < n && t[j].start <= time; j++)
            if (best < 0 || t[j].cost < t[best].cost) best = j;
        if (best < 0) { time = t[i].start; continue; }
        Task chosen = t[best];
        for (int j = best; j > i; j--) t[j] = t[j-1];
        t[i] = chosen;
        time += chosen.cost;
        out[k++] = chosen.idx;
        i++;
    }
    free(t);
    return out;
}`,
          cpp: `#include <algorithm>
#include <queue>
#include <vector>
using namespace std;

vector<int> getOrder(vector<vector<int>>& tasks) {
    vector<int> id(tasks.size());
    for (int i = 0; i < (int)id.size(); i++) id[i] = i;
    sort(id.begin(), id.end(), [&](int a, int b) {
        if (tasks[a][0] != tasks[b][0]) return tasks[a][0] < tasks[b][0];
        return a < b;
    });
    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<>> pq;
    vector<int> out;
    long long time = 0;
    int i = 0, n = tasks.size();
    while ((int)out.size() < n) {
        if (pq.empty() && time < tasks[id[i]][0]) time = tasks[id[i]][0];
        while (i < n && tasks[id[i]][0] <= time) {
            pq.push({tasks[id[i]][1], id[i]});
            i++;
        }
        auto [cost, idx] = pq.top(); pq.pop();
        time += cost;
        out.push_back(idx);
    }
    return out;
}`,
        },
        steps(tasks) {
          const ts = tasks.map((t, i) => ({ start: t[0], cost: t[1], idx: i })).sort((a, b) => a.start - b.start || a.idx - b.idx);
          const out = [];
          let time = 0, i = 0;
          const done = [];
          const pq = [];
          out.push({
            title: "Sort tasks by enqueue time",
            tracks: [chips("tasks (start,cost)", ts.map((t) => t.start + "," + t.cost), "idle"), chips("order", [], "idle")],
            counters: [count("time", 0), count("completed", 0, ts.length)],
            happened: ts.length ? `The first task becomes available at ${ts[0].start}.` : "No tasks.",
            why: "Sorting by start lets the CPU push every newly available task into the heap.",
            legend: LEG,
            codeLine: 8,
          });
          while (done.length < ts.length) {
            if (!pq.length && i < ts.length) time = Math.max(time, ts[i].start);
            while (i < ts.length && ts[i].start <= time) {
              pq.push(ts[i]);
              i++;
            }
            pq.sort((a, b) => a.cost - b.cost || a.idx - b.idx);
            if (!pq.length) continue;
            out.push({
              title: `Time ${time}: heap holds ${pq.length} task(s)`,
              tracks: [chips("available tasks", pq.map((t) => "i" + t.idx + ":cost" + t.cost), "idle"), chips("order", done, "idle")],
              counters: [count("time", time), count("available", pq.length)],
              happened: `The shortest available task is ${pq[0].idx} with cost ${pq[0].cost}.`,
              why: "The CPU always chooses the available task with the smallest processing time.",
              legend: LEG,
              codeLine: 17,
            });
            const chosen = pq.shift();
            done.push(chosen.idx);
            time += chosen.cost;
            out.push({
              title: `Run task ${chosen.idx} for ${chosen.cost} unit(s)` ,
              tracks: [chips("available tasks", pq.map((t) => "i" + t.idx + ":cost" + t.cost), "idle"), chips("order", done, "active")],
              counters: [count("time", time), count("completed", done.length, ts.length)],
              happened: `Task ${chosen.idx} was the shortest available task.`,
              why: "Choosing the shortest job first minimizes waiting time for the tasks behind it.",
              legend: LEG,
              codeLine: 21,
            });
          }
          out.push({
            title: `Order: ${show(done)}`,
            tracks: [chips("order", done, "result")],
            counters: [count("completed", done.length, ts.length), count("time", time)],
            happened: "Every task ran exactly once.",
            why: "The heap choice at each step determines the final order.",
            legend: LEG,
            codeLine: 27,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "longest-happy-string",
    title: "Longest Happy String",
    category: "Heap / Priority Queue",
    difficulty: "Intermediate",
    description: "Build the longest string with no three equal letters in a row.",
    input: { label: "counts a, b, c", default: "1, 1, 6", parse: "ints" },
    approaches: [
      {
        name: "Take From the Largest Count",
        complexity: "O(total letters * 3 log 3) time, O(1) extra space",
        idea: [
          "At each position, prefer the character with the largest remaining count, because spending it early prevents it from being stranded.",
          "Never take the same character three times in a row. If the largest count would do that, take the second-largest instead.",
        ],
        problem: ["Choosing greedily is safe here because the only constraint is a local three-in-a-row rule."],
        code: {
          c: `#include <stdlib.h>
#include <string.h>

char* longestDiverseString(int a, int b, int c) {
    int cnt[3] = {a, b, c};
    char* out = malloc(a + b + c + 1);
    int n = 0;
    while (1) {
        int best = -1;
        for (int i = 0; i < 3; i++)
            if (cnt[i] > 0 && !(n >= 2 && out[n-1] == 'a' + i && out[n-2] == 'a' + i))
                if (best < 0 || cnt[i] > cnt[best]) best = i;
        if (best < 0) break;
        out[n++] = 'a' + best;
        cnt[best]--;
    }
    out[n] = '\\0';
    return out;
}`,
          cpp: `#include <string>
using namespace std;

string longestDiverseString(int a, int b, int c) {
    int cnt[3] = {a, b, c};
    string out;
    while (true) {
        int best = -1;
        for (int i = 0; i < 3; i++)
            if (cnt[i] > 0 && !(out.size() >= 2 && out.back() == 'a' + i && out[out.size()-2] == 'a' + i))
                if (best < 0 || cnt[i] > cnt[best]) best = i;
        if (best < 0) break;
        out += char('a' + best);
        cnt[best]--;
    }
    return out;
}`,
        },
        steps(counts) {
          const cnt = [counts[0] || 0, counts[1] || 0, counts[2] || 0];
          let outStr = "";
          const out = [];
          out.push({
            title: "Three piles of letters",
            tracks: [chips("counts", ["a:" + cnt[0], "b:" + cnt[1], "c:" + cnt[2]], "idle"), chips("string", [], "idle")],
            counters: [count("letters left", cnt.reduce((s, x) => s + x, 0)), count("length", 0)],
            happened: "At every step the largest remaining pile is the first choice.",
            why: "Spending the largest pile early keeps the final counts balanced.",
            legend: LEG,
            codeLine: 4,
          });
          while (cnt.some((x) => x > 0)) {
            let best = -1;
            for (let i = 0; i < 3; i++) {
              const triple = outStr.length >= 2 && outStr[outStr.length - 1] === String.fromCharCode(97 + i) && outStr[outStr.length - 2] === String.fromCharCode(97 + i);
              if (cnt[i] > 0 && !triple && (best < 0 || cnt[i] > cnt[best])) best = i;
            }
            if (best < 0) break;
            const ch = String.fromCharCode(97 + best);
            outStr += ch;
            cnt[best]--;
            out.push({
              title: `Append '${ch}'`,
              tracks: [chips("counts", ["a:" + cnt[0], "b:" + cnt[1], "c:" + cnt[2]], (k) => (k === best ? "result" : "idle")), chips("string", [outStr], "active")],
              counters: [count("length", outStr.length), count("letters left", cnt.reduce((s, x) => s + x, 0))],
              happened: `The string is now "${outStr}".`,
              why: "The chosen letter did not create three equal characters in a row.",
              legend: LEG,
              codeLine: 10,
            });
          }
          out.push({
            title: `Longest happy string has length ${outStr.length}`,
            tracks: [chips("string", [outStr], "result")],
            counters: [count("length", outStr.length), count("letters left", cnt.reduce((s, x) => s + x, 0))],
            happened: `The result is "${outStr}".`,
            why: "No legal next character remains, so this greedy construction is maximal.",
            legend: LEG,
            codeLine: 13,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "island-perimeter",
    title: "Island Perimeter",
    category: "Graphs",
    difficulty: "Beginner",
    description: "Count the exposed edges around all land cells.",
    input: { label: "grid rows separated by |", default: "0 1 0 0 | 1 1 1 0 | 0 1 0 0", parse: "string" },
    approaches: [
      {
        name: "Four Edges per Land Cell",
        complexity: "O(rows * cols) time, O(1) extra space",
        idea: [
          "Every land cell starts with four exposed sides. Each adjacent land cell hides one side, so subtract one for every land neighbor to the north, south, east or west.",
          "Adding the remaining exposed sides over all land cells gives the perimeter. Water and out-of-bounds cells contribute nothing.",
        ],
        problem: ["The count is independent of whether the land forms one island or several; the same rule works for any shape."],
        code: {
          c: `int islandPerimeter(int** g, int rows, int cols) {
    int per = 0;
    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            if (!g[r][c]) continue;
            per += 4;
            if (r > 0 && g[r-1][c]) per--;
            if (r + 1 < rows && g[r+1][c]) per--;
            if (c > 0 && g[r][c-1]) per--;
            if (c + 1 < cols && g[r][c+1]) per--;
        }
    }
    return per;
}`,
          cpp: `#include <vector>
using namespace std;

int islandPerimeter(vector<vector<int>>& g) {
    int rows = g.size(), cols = g[0].size(), per = 0;
    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            if (!g[r][c]) continue;
            per += 4;
            if (r && g[r-1][c]) per--;
            if (r + 1 < rows && g[r+1][c]) per--;
            if (c && g[r][c-1]) per--;
            if (c + 1 < cols && g[r][c+1]) per--;
        }
    }
    return per;
}`,
        },
        steps(text) {
          const rows = String(text || "").split("|").map((r) => r.trim().split(/[\s,]+/).filter(Boolean).map(Number));
          const R = rows.length, C = Math.max(1, ...rows.map((r) => r.length));
          const a = Array.from({ length: R }, (_, r) => Array.from({ length: C }, (_, c) => rows[r][c] || 0));
          const out = [];
          let per = 0;
          const cell = (r, c, state) => ({ r, c, v: a[r][c] ? "1" : "0", state });
          out.push({
            title: "Start each land cell with four sides",
            kind: "grid", rows: R, cols: C, cells: grid(R, C, (r, c) => cell(r, c, a[r][c] ? "read" : "idle")),
            counters: [count("perimeter", 0), count("land cells", a.flat().filter(Boolean).length)],
            happened: "The grid is scanned row by row.",
            why: "A shape's perimeter is the number of land-to-water or land-to-outside edges.",
            legend: LEG,
            codeLine: 2,
          });
          for (let r = 0; r < R; r++) {
            for (let c = 0; c < C; c++) {
              if (!a[r][c]) continue;
              let local = 4;
              if (r > 0 && a[r - 1][c]) local--;
              if (r + 1 < R && a[r + 1][c]) local--;
              if (c > 0 && a[r][c - 1]) local--;
              if (c + 1 < C && a[r][c + 1]) local--;
              per += local;
              out.push({
                title: `Cell ${r},${c} adds ${local}`,
                kind: "grid", rows: R, cols: C, cells: grid(R, C, (rr, cc) => cell(rr, cc, rr === r && cc === c ? "result" : a[rr][cc] ? "done" : "idle")),
                counters: [count("perimeter", per), count("cell contribution", local)],
                happened: `The cell has ${local} side(s) not shared with another land cell.`,
                why: "Each shared side is counted twice if both cells keep all four sides, so one copy is removed.",
                legend: LEG,
                codeLine: 6,
              });
            }
          }
          out.push({
            title: `Total perimeter is ${per}`,
            kind: "grid", rows: R, cols: C, cells: grid(R, C, (r, c) => ({ r, c, v: a[r][c] ? "1" : "0", state: a[r][c] ? "result" : "idle" })),
            counters: [count("perimeter", per), count("land cells", a.flat().filter(Boolean).length)],
            happened: "All exposed sides have been added.",
            why: "Shared sides were subtracted exactly once per land cell.",
            legend: LEG,
            codeLine: 11,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "verifying-an-alien-dictionary",
    title: "Verifying An Alien Dictionary",
    category: "Graphs",
    difficulty: "Beginner",
    description: "Check whether words are sorted according to a custom alphabet.",
    input: { label: "alphabet | words", default: "hlabcdefgijkmnopqrstuvwxyz | hello leetcode", parse: "string" },
    approaches: [
      {
        name: "Compare Adjacent Words",
        complexity: "O(total characters) time, O(1) space",
        idea: [
          "A word list is sorted if every adjacent pair is in order. Build a rank for each letter from the alien alphabet.",
          "Compare the pair character by character. The first differing letter decides the order. If one word is a prefix of the other, the shorter word must come first.",
        ],
        problem: ["Checking only adjacent pairs is enough because lexicographic order is transitive."],
        code: {
          c: `#include <stdbool.h>
#include <string.h>

bool isAlienSorted(char** words, int n, char* order) {
    int rank[26];
    for (int i = 0; i < 26; i++) rank[order[i] - 'a'] = i;
    for (int i = 1; i < n; i++) {
        char* a = words[i-1]; char* b = words[i];
        int j = 0;
        while (a[j] && b[j] && a[j] == b[j]) j++;
        if (a[j] && b[j]) {
            if (rank[a[j] - 'a'] > rank[b[j] - 'a']) return false;
        } else if (a[j] && !b[j]) return false;
    }
    return true;
}`,
          cpp: `#include <string>
#include <vector>
using namespace std;

bool isAlienSorted(vector<string>& words, string order) {
    int rank[26];
    for (int i = 0; i < 26; i++) rank[order[i] - 'a'] = i;
    for (int i = 1; i < (int)words.size(); i++) {
        const string& a = words[i-1];
        const string& b = words[i];
        int j = 0;
        while (j < (int)a.size() && j < (int)b.size() && a[j] == b[j]) j++;
        if (j < (int)a.size() && j < (int)b.size()) {
            if (rank[a[j]-'a'] > rank[b[j]-'a']) return false;
        } else if (j < (int)a.size()) return false;
    }
    return true;
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const order = [...(parts[0] || "")];
          const words = (parts[1] || "").split(/\s+/).filter(Boolean);
          const rank = new Map(order.map((ch, i) => [ch, i]));
          const out = [];
          out.push({
            title: "Turn the alien alphabet into ranks",
            tracks: [chips("alphabet", order, "idle"), chips("words", words, "idle")],
            counters: [count("letters", order.length), count("word pairs", Math.max(0, words.length - 1))],
            happened: "Earlier letters in the alien alphabet must have smaller ranks.",
            why: "A rank comparison is easier than remembering the alien order.",
            legend: LEG,
            codeLine: 3,
          });
          for (let i = 1; i < words.length; i++) {
            const a = [...words[i - 1]], b = [...words[i]];
            let j = 0;
            while (j < a.length && j < b.length && a[j] === b[j]) j++;
            let ok = true;
            let reason = "";
            if (j < a.length && j < b.length) {
              ok = rank.get(a[j]) <= rank.get(b[j]);
              reason = `First difference: '${a[j]}' (rank ${rank.get(a[j])}) vs '${b[j]}' (rank ${rank.get(b[j])}).`;
            } else if (j < a.length) {
              ok = false;
              reason = `"${words[i - 1]}" is longer and starts with "${words[i]}", so it cannot come first.`;
            } else {
              reason = "One word is a prefix of the other, and the shorter one comes first.";
            }
            out.push({
              title: ok ? `"${words[i - 1]}" <= "${words[i]}"` : `"${words[i - 1]}" > "${words[i]}"`,
              tracks: [chips("words", words, (k) => (k === i - 1 || k === i ? (ok ? "good" : "bad") : k < i ? "done" : "idle")), chips("rank check", [a[j] || "-", b[j] || "-"], "compare")],
              counters: [count("pairs checked", i, words.length - 1), count("first difference", j)],
              happened: reason,
              why: "Sorting only requires each adjacent pair to be nondecreasing.",
              legend: LEG,
              codeLine: ok ? 9 : 10,
            });
            if (!ok) {
              out.push({ title: "The list is not sorted", tracks: [chips("words", words, "bad")], counters: [count("answer", "false")], happened: "A single out-of-order pair is enough to reject the list.", why: "Adjacent comparisons cover every place where order can first break.", legend: LEG, codeLine: 10 });
              return out;
            }
          }
          out.push({
            title: "Every adjacent pair is in order",
            tracks: [chips("words", words, "result")],
            counters: [count("answer", "true"), count("pairs checked", Math.max(0, words.length - 1))],
            happened: "The words follow the alien dictionary order.",
            why: "All adjacent pairs were nondecreasing, so the whole list is sorted.",
            legend: LEG,
            codeLine: 14,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-the-town-judge",
    title: "Find the Town Judge",
    category: "Graphs",
    difficulty: "Beginner",
    description: "Find the person trusted by everyone and trusting nobody.",
    input: { label: "n | trust pairs", default: "3 | 1,3 2,3", parse: "string" },
    approaches: [
      {
        name: "Count Trust In and Out",
        complexity: "O(n + edges) time, O(n) space",
        idea: [
          "For every trust edge a -> b, a trusts someone and b is trusted. Keep a score that increases for b and decreases for a.",
          "The judge must be trusted by all n - 1 other people and trust nobody, so the judge's score is exactly n - 1.",
        ],
        problem: ["A score can collide with another candidate only if the graph is malformed; the problem guarantees at most one judge."],
        code: {
          c: `int findJudge(int n, int** trust, int m, int* returnSize) {
    int* score = calloc(n + 1, sizeof(int));
    for (int i = 0; i < m; i++) {
        score[trust[i][0]]--;
        score[trust[i][1]]++;
    }
    for (int i = 1; i <= n; i++)
        if (score[i] == n - 1) return i;
    return -1;
}`,
          cpp: `#include <vector>
using namespace std;

int findJudge(int n, vector<vector<int>>& trust) {
    vector<int> score(n + 1, 0);
    for (auto& e : trust) { score[e[0]]--; score[e[1]]++; }
    for (int i = 1; i <= n; i++) if (score[i] == n - 1) return i;
    return -1;
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const n = Math.max(1, parseInt(parts[0], 10) || 1);
          const edges = pairs(parts[1] || "");
          const score = new Array(n + 1).fill(0);
          const out = [];
          out.push({
            title: `Track trust for ${n} people`,
            tracks: [chips("people", Array.from({ length: n }, (_, i) => i + 1), "idle"), chips("trust edges", edges.map((e) => e[0] + "->" + e[1]), "idle")],
            counters: [count("people", n), count("edges", edges.length)],
            happened: "A trust edge lowers the truster's score and raises the trusted person's score.",
            why: "The judge needs n - 1 more incoming trusts than outgoing trusts.",
            legend: LEG,
            codeLine: 2,
          });
          for (let ei = 0; ei < edges.length; ei++) {
            const [a, b] = edges[ei];
            if (a >= 1 && a <= n) score[a]--;
            if (b >= 1 && b <= n) score[b]++;
            out.push({
              title: `${a} trusts ${b}`,
              tracks: [chips("people", Array.from({ length: n }, (_, i) => i + 1), "idle"), chips("scores", Array.from({ length: n }, (_, i) => (i + 1) + ":" + score[i + 1]), (k) => (k + 1 === a || k + 1 === b ? "compare" : "idle"))],
              counters: [count("edges read", ei + 1, edges.length), count("net trust", score[b] - score[a])],
              happened: `The score of ${a} decreases and the score of ${b} increases.`,
              why: "One person cannot both be trusted by everyone and trust someone else.",
              legend: LEG,
              codeLine: 4,
            });
          }
          const judge = Array.from({ length: n }, (_, i) => i + 1).find((p) => score[p] === n - 1);
          out.push({
            title: judge ? `Person ${judge} is the judge` : "No judge exists",
            tracks: [chips("final scores", Array.from({ length: n }, (_, i) => (i + 1) + ":" + score[i + 1]), (k) => (k + 1 === judge ? "result" : "idle"))],
            counters: [count("answer", judge || -1), count("required score", n - 1)],
            happened: judge ? `Person ${judge} has the required score ${n - 1}.` : "Nobody has exactly the required net trust.",
            why: "The score sums up both conditions: trusted by all and trusting none.",
            legend: LEG,
            codeLine: 7,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "islands-and-treasure",
    title: "Walls And Gates",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Fill every empty room with its distance to the nearest gate.",
    input: { label: "grid rows (INF, -1 wall, 0 gate)", default: "INF -1 0 INF | INF INF INF -1 | INF -1 INF -1 | 0 -1 INF INF", parse: "string" },
    approaches: [
      {
        name: "Multi-Source BFS",
        complexity: "O(rows * cols) time, O(rows * cols) space",
        idea: [
          "Put every gate into the BFS queue at distance 0. Walls are never entered.",
          "Expand one whole layer at a time. The first time a room is reached, the current distance is the shortest because BFS explores by increasing distance.",
        ],
        problem: ["The queue can hold many rooms at once, and the input grid is modified unless a copy is made."],
        code: {
          c: `#include <stdlib.h>

void wallsAndGates(int** rooms, int rows, int cols) {
    int* qr = malloc(rows * cols * sizeof(int));
    int* qc = malloc(rows * cols * sizeof(int));
    int head = 0, tail = 0;
    for (int r = 0; r < rows; r++)
        for (int c = 0; c < cols; c++)
            if (rooms[r][c] == 0) { qr[tail] = r; qc[tail++] = c; }
    int dr[4] = {-1, 1, 0, 0}, dc[4] = {0, 0, -1, 1};
    while (head < tail) {
        int r = qr[head], c = qc[head++];
        for (int k = 0; k < 4; k++) {
            int nr = r + dr[k], nc = c + dc[k];
            if (nr < 0 || nc < 0 || nr >= rows || nc >= cols) continue;
            if (rooms[nr][nc] != 2147483647) continue;
            rooms[nr][nc] = rooms[r][c] + 1;
            qr[tail] = nr; qc[tail++] = nc;
        }
    }
}`,
          cpp: `#include <queue>
#include <vector>
using namespace std;

void wallsAndGates(vector<vector<int>>& rooms) {
    int rows = rooms.size(), cols = rooms[0].size();
    queue<pair<int,int>> q;
    for (int r = 0; r < rows; r++)
        for (int c = 0; c < cols; c++)
            if (rooms[r][c] == 0) q.push({r, c});
    int dr[4] = {-1,1,0,0}, dc[4] = {0,0,-1,1};
    while (!q.empty()) {
        auto [r, c] = q.front(); q.pop();
        for (int k = 0; k < 4; k++) {
            int nr = r + dr[k], nc = c + dc[k];
            if (nr < 0 || nc < 0 || nr >= rows || nc >= cols) continue;
            if (rooms[nr][nc] != INT_MAX) continue;
            rooms[nr][nc] = rooms[r][c] + 1;
            q.push({nr, nc});
        }
    }
}`,
        },
        steps(text) {
          const rows = String(text || "").split("|").map((r) => r.trim().split(/[\s,]+/).filter(Boolean));
          const R = rows.length, C = Math.max(1, ...rows.map((r) => r.length));
          const a = Array.from({ length: R }, (_, r) => Array.from({ length: C }, (_, c) => {
            const v = rows[r][c];
            return v === "INF" || v === "inf" || v === "2147483647" ? Infinity : Number(v);
          }));
          const q = [];
          for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) if (a[r][c] === 0) q.push([r, c]);
          const out = [];
          const value = (v) => (v === Infinity ? "INF" : v);
          const make = (extra, stateFor) => ({ kind: "grid", rows: R, cols: C, cells: grid(R, C, (r, c) => ({ r, c, v: value(a[r][c]), state: extra && extra[r + "," + c] ? extra[r + "," + c] : stateFor ? stateFor(a[r][c]) : a[r][c] === 0 ? "result" : a[r][c] === -1 ? "dim" : "idle" })) });
          out.push({
            title: "Start BFS from every gate",
            ...make({}, (v) => (v === 0 ? "result" : v === -1 ? "dim" : "idle")),
            counters: [count("gates", q.length), count("distance", 0)],
            happened: `There are ${q.length} gate(s) at distance zero.`,
            why: "Starting all gates together gives every room the nearest gate, not just one gate's distance.",
            legend: LEG,
            codeLine: 5,
          });
          let head = 0, dist = 0;
          while (head < q.length) {
            const layer = q.length - head;
            for (let k = 0; k < layer; k++) {
              const [r, c] = q[head++];
              for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]]) {
                const nr = r + dr, nc = c + dc;
                if (nr < 0 || nc < 0 || nr >= R || nc >= C || a[nr][nc] !== Infinity) continue;
                a[nr][nc] = a[r][c] + 1;
                q.push([nr, nc]);
              }
            }
            dist++;
            const extra = {};
            for (let k = head; k < q.length; k++) extra[q[k][0] + "," + q[k][1]] = "active";
            out.push({
              title: `Fill layer at distance ${dist}`,
              ...make(extra, (v) => (v === 0 ? "result" : v === -1 ? "dim" : v > dist ? "idle" : "done")),
              counters: [count("distance", dist), count("rooms reached", head, R * C)],
              happened: `Rooms reachable in ${dist} step(s) have been filled.`,
              why: "BFS guarantees no shorter path can reach a room that is first discovered in this layer.",
              legend: LEG,
              codeLine: 16,
            });
          }
          out.push({
            title: "Every open room has its nearest-gate distance",
            ...make({}, (v) => (v === -1 ? "dim" : "result")),
            counters: [count("gates", q.filter(([r, c]) => a[r][c] === 0).length), count("rooms", R * C)],
            happened: "Unreachable rooms remain INF because no gate can reach them.",
            why: "The BFS stops only when the queue is empty, so all possible distances are settled.",
            legend: LEG,
            codeLine: 21,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "course-schedule-iv",
    title: "Course Schedule IV",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Answer whether one course is a prerequisite of another, directly or indirectly.",
    input: { label: "n | prerequisites | queries", default: "5 | 0,1 1,2 2,3 3,4 | 0,4 1,3 2,4", parse: "string" },
    approaches: [
      {
        name: "Transitive Closure by DFS",
        complexity: "O(n * (n + e)) time, O(n^2) space",
        idea: [
          "A course can reach another if there is a chain of prerequisite edges. For each query, search forward from the first course.",
          "Memoizing reachable sets avoids repeating the same search. If the target appears in the reachable set, the answer is true.",
        ],
        problem: ["Storing reachability for every pair costs O(n^2), which is fine for small graphs but expensive for large ones."],
        code: {
          c: `#include <stdbool.h>

bool reaches(int u, int target, int** g, int* deg, bool* seen) {
    if (u == target) return true;
    if (seen[u]) return false;
    seen[u] = true;
    for (int i = 0; i < deg[u]; i++)
        if (reaches(g[u][i], target, g, deg, seen)) return true;
    return false;
}

bool* checkIfPrerequisite(int n, int** edges, int m, int** queries, int q, bool* returnSize) {
    int** g = calloc(n, sizeof(int*));
    int* deg = calloc(n, sizeof(int));
    for (int i = 0; i < m; i++) {
        int a = edges[i][0], b = edges[i][1];
        g[a] = realloc(g[a], (deg[a] + 1) * sizeof(int));
        g[a][deg[a]++] = b;
    }
    bool* ans = malloc(q * sizeof(bool));
    *returnSize = q;
    for (int i = 0; i < q; i++) {
        bool* seen = calloc(n, sizeof(bool));
        ans[i] = reaches(queries[i][0], queries[i][1], g, deg, seen);
        free(seen);
    }
    return ans;
}`,
          cpp: `#include <functional>
#include <vector>
using namespace std;

vector<bool> checkIfPrerequisite(int n, vector<vector<int>>& edges, vector<vector<int>>& queries) {
    vector<vector<int>> g(n);
    for (auto& e : edges) g[e[0]].push_back(e[1]);
    vector<bool> ans;
    for (auto& q : queries) {
        vector<int> seen(n, 0);
        function<bool(int)> dfs = [&](int u) {
            if (u == q[1]) return true;
            if (seen[u]) return false;
            seen[u] = 1;
            for (int v : g[u]) if (dfs(v)) return true;
            return false;
        };
        ans.push_back(dfs(q[0]));
    }
    return ans;
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const n = Math.max(1, parseInt(parts[0], 10) || 1);
          const edges = pairs(parts[1] || "");
          const queries = pairs(parts[2] || "");
          const g = Array.from({ length: n }, () => []);
          for (const [a, b] of edges) if (a >= 0 && a < n && b >= 0 && b < n) g[a].push(b);
          const out = [];
          out.push({
            title: "Build the prerequisite graph",
            tracks: [chips("edges", edges.map((e) => e[0] + "->" + e[1]), "idle"), chips("queries", queries.map((q) => q[0] + "=>" + q[1]), "idle")],
            counters: [count("courses", n), count("queries", queries.length)],
            happened: "An edge a -> b means a is a prerequisite of b.",
            why: "A course is an indirect prerequisite if a directed path exists.",
            legend: LEG,
            codeLine: 10,
          });
          const answers = [];
          for (const [from, to] of queries) {
            const seen = new Set();
            let ok = false;
            const stack = [from];
            let inspected = 0;
            while (stack.length && !ok) {
              const u = stack.pop();
              if (u === to) { ok = true; break; }
              if (seen.has(u)) continue;
              seen.add(u);
              inspected++;
              for (const v of g[u] || []) stack.push(v);
            }
            answers.push(ok);
            out.push({
              title: `${from} ${ok ? "can" : "cannot"} reach ${to}`,
              tracks: [chips("queries", queries.map((q) => q[0] + "=>" + q[1]), (k) => (k === answers.length - 1 ? "read" : k < answers.length - 1 ? "done" : "idle")), chips("answers", answers.map((x) => (x ? "true" : "false")), "result")],
              counters: [count("visited", inspected), count("query", from + " -> " + to)],
              happened: ok ? `A directed path from ${from} reaches ${to}.` : `No path from ${from} reaches ${to}.`,
              why: "DFS follows prerequisite edges only in the forward direction.",
              legend: LEG,
              codeLine: ok ? 4 : 6,
            });
          }
          out.push({
            title: `Answers: ${show(answers.map((x) => (x ? "true" : "false")))}`,
            tracks: [chips("queries", queries.map((q) => q[0] + "=>" + q[1]), "done"), chips("answers", answers.map((x) => (x ? "true" : "false")), "result")],
            counters: [count("queries answered", answers.length, queries.length)],
            happened: "Each query received a reachability answer.",
            why: "A query is true exactly when its target is reachable along prerequisite edges.",
            legend: LEG,
            codeLine: 14,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "minimum-height-trees",
    title: "Minimum Height Trees",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Find the roots that give the shortest possible tree.",
    input: { label: "n | edges", default: "6 | 0,1 0,2 0,3 3,4 3,5", parse: "string" },
    approaches: [
      {
        name: "Peel Leaves Inward",
        complexity: "O(n) time, O(n) space",
        idea: [
          "A minimum-height root lies near the centre of the tree. Repeatedly remove all current leaves; their neighbors become new leaves.",
          "After peeling, one node (odd diameter) or two adjacent nodes (even diameter) remain. Those are the centroids and therefore the best roots.",
        ],
        problem: ["This relies on the input being a tree. A graph with a cycle would never lose all leaves."],
        code: {
          c: `#include <stdlib.h>

int* findMinHeightTrees(int n, int** edges, int m, int* returnSize) {
    if (n == 1) { int* a = malloc(sizeof(int)); a[0] = 0; *returnSize = 1; return a; }
    int** g = calloc(n, sizeof(int*));
    int* deg = calloc(n, sizeof(int));
    for (int i = 0; i < m; i++) {
        int a = edges[i][0], b = edges[i][1];
        g[a] = realloc(g[a], (deg[a] + 1) * sizeof(int)); g[a][deg[a]++] = b;
        g[b] = realloc(g[b], (deg[b] + 1) * sizeof(int)); g[b][deg[b]++] = a;
    }
    int* leaves = malloc(n * sizeof(int));
    int count = 0;
    for (int i = 0; i < n; i++) if (deg[i] <= 1) leaves[count++] = i;
    int left = n;
    while (left > 2) {
        int next = 0;
        for (int i = 0; i < count; i++) {
            int leaf = leaves[i];
            left--;
            for (int j = 0; j < deg[leaf]; j++) {
                int v = g[leaf][j];
                if (--deg[v] == 1) leaves[next++] = v;
            }
        }
        count = next;
    }
    *returnSize = count;
    return leaves;
}`,
          cpp: `#include <queue>
#include <vector>
using namespace std;

vector<int> findMinHeightTrees(int n, vector<vector<int>>& edges) {
    if (n == 1) return {0};
    vector<vector<int>> g(n);
    vector<int> deg(n);
    for (auto& e : edges) {
        g[e[0]].push_back(e[1]); g[e[1]].push_back(e[0]);
        deg[e[0]]++; deg[e[1]]++;
    }
    queue<int> q;
    for (int i = 0; i < n; i++) if (deg[i] == 1) q.push(i);
    int left = n;
    while (left > 2) {
        int sz = q.size();
        left -= sz;
        while (sz--) {
            int u = q.front(); q.pop();
            for (int v : g[u]) if (--deg[v] == 1) q.push(v);
        }
    }
    vector<int> ans;
    while (!q.empty()) { ans.push_back(q.front()); q.pop(); }
    return ans;
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const n = Math.max(1, parseInt(parts[0], 10) || 1);
          const edges = pairs(parts[1] || "");
          const g = Array.from({ length: n }, () => []);
          const deg = new Array(n).fill(0);
          for (const [a, b] of edges) if (a < n && b < n) { g[a].push(b); g[b].push(a); deg[a]++; deg[b]++; }
          let leaves = [];
          for (let i = 0; i < n; i++) if (deg[i] <= 1) leaves.push(i);
          const out = [];
          let left = n;
          out.push({
            title: "Start with every leaf",
            tracks: [chips("degrees", deg.map((d, i) => i + ":" + d), (i) => (deg[i] <= 1 ? "read" : "idle")), chips("leaves", leaves, "active")],
            counters: [count("nodes left", left), count("leaves", leaves.length)],
            happened: `The current leaves are ${show(leaves)}.`,
            why: "A leaf cannot be a good centre because removing it is always safe while more than two nodes remain.",
            legend: LEG,
            codeLine: 11,
          });
          while (left > 2 && leaves.length) {
            const next = [];
            for (const leaf of leaves) {
              left--;
              for (const v of g[leaf]) {
                deg[v]--;
                if (deg[v] === 1) next.push(v);
              }
            }
            leaves = next;
            out.push({
              title: `Peel ${leaves.length ? "a layer" : "the last layer"}; ${left} node(s) left`,
              tracks: [chips("degrees", deg.map((d, i) => i + ":" + d), (i) => (deg[i] <= 1 ? "read" : "done")), chips("new leaves", leaves, "result")],
              counters: [count("nodes left", left), count("leaves", leaves.length)],
              happened: `The new boundary is ${show(leaves)}.`,
              why: "Removing the outer layer moves the remaining centre inward by one level.",
              legend: LEG,
              codeLine: 17,
            });
          }
          out.push({
            title: leaves.length ? `Best roots: ${show(leaves)}` : "No roots remain",
            tracks: [chips("answer", leaves, "result")],
            counters: [count("answer", leaves.length), count("nodes left", left)],
            happened: "The peel stopped at the centre of the tree.",
            why: "The remaining one or two nodes minimize the maximum distance to every other node.",
            legend: LEG,
            codeLine: 20,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-critical-and-pseudo-critical-edges-in-minimum-spanning-tree",
    title: "Find Critical and Pseudo Critical Edges in MST",
    category: "Advanced Graphs",
    difficulty: "Advanced",
    description: "Classify edges by how they affect a minimum spanning tree.",
    input: { label: "n | u,v,w edges", default: "4 | 0,1,1 1,2,1 2,3,1 0,3,1", parse: "string" },
    approaches: [
      {
        name: "Force or Skip Each Edge",
        complexity: "O(e^2 log e) time, O(e) space",
        idea: [
          "First compute the weight of one minimum spanning tree. An edge is critical if removing it makes the best possible tree heavier or impossible.",
          "If the edge is not critical but forcing it into the MST still achieves the minimum weight, it is pseudo-critical. Every remaining edge is neither.",
        ],
        problem: ["Running Kruskal once per edge is easy to understand but expensive; more advanced methods reuse MST structure."],
        code: {
          c: `#include <stdlib.h>

typedef struct { int u, v, w, id; } Edge;
int cmp(const void* a, const void* b) { return ((Edge*)a)->w - ((Edge*)b)->w; }
int find(int* p, int x) { return p[x] == x ? x : (p[x] = find(p, p[x])); }

int kruskal(Edge* e, int m, int n, int skip, int force) {
    int* p = malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) p[i] = i;
    int used = 0, weight = 0;
    if (force >= 0) {
        p[find(p, e[force].u)] = find(p, e[force].v);
        weight += e[force].w; used = 1;
    }
    for (int i = 0; i < m; i++) {
        if (i == skip || i == force) continue;
        int a = find(p, e[i].u), b = find(p, e[i].v);
        if (a != b) { p[a] = b; weight += e[i].w; used++; }
    }
    free(p);
    return used == n - 1 ? weight : 1000000000;
}`,
          cpp: `#include <algorithm>
#include <numeric>
#include <vector>
using namespace std;

struct DSU {
    vector<int> p;
    DSU(int n) : p(n) { iota(p.begin(), p.end(), 0); }
    int find(int x) { return p[x] == x ? x : p[x] = find(p[x]); }
    bool join(int a, int b) { a = find(a); b = find(b); if (a == b) return false; p[a] = b; return true; }
};

int kruskal(vector<vector<int>>& e, int n, int skip, int force) {
    DSU d(n); int used = 0, weight = 0;
    if (force >= 0) { d.join(e[force][0], e[force][1]); weight += e[force][2]; used = 1; }
    for (int i = 0; i < (int)e.size(); i++) {
        if (i == skip || i == force) continue;
        if (d.join(e[i][0], e[i][1])) { weight += e[i][2]; used++; }
    }
    return used == n - 1 ? weight : 1e9;
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const n = Math.max(1, parseInt(parts[0], 10) || 1);
          const edges = pairs(parts[1] || "").filter((e) => e.length >= 3).map((e, i) => ({ u: e[0], v: e[1], w: e[2], id: i })).sort((a, b) => a.w - b.w);
          const out = [];
          const mst = (skip, force) => {
            const p = Array.from({ length: n }, (_, i) => i);
            const find = (x) => (p[x] === x ? x : (p[x] = find(p[x])));
            let used = 0, weight = 0;
            if (force != null) {
              p[find(edges[force].u)] = find(edges[force].v);
              weight += edges[force].w;
              used = 1;
            }
            for (let i = 0; i < edges.length; i++) {
              if (i === skip || i === force) continue;
              const a = find(edges[i].u), b = find(edges[i].v);
              if (a !== b) { p[a] = b; weight += edges[i].w; used++; }
            }
            return used === n - 1 ? weight : Infinity;
          };
          const base = mst(-1, null);
          out.push({
            title: "Compute one minimum spanning tree",
            tracks: [chips("edges (u,v,w)", edges.map((e) => e.u + "-" + e.v + ":" + e.w), "idle")],
            counters: [count("best weight", Number.isFinite(base) ? base : "none"), count("nodes", n)],
            happened: `Kruskal finds a tree with total weight ${Number.isFinite(base) ? base : "impossible"}.`,
            why: "Every classification is relative to this best possible weight.",
            legend: LEG,
            codeLine: 9,
          });
          const critical = [], pseudo = [];
          for (let i = 0; i < edges.length; i++) {
            const without = mst(i, null);
            const withIt = mst(-1, i);
            const isCritical = without > base;
            const isPseudo = !isCritical && withIt === base;
            if (isCritical) critical.push(edges[i].id);
            else if (isPseudo) pseudo.push(edges[i].id);
            out.push({
              title: `Edge ${edges[i].u}-${edges[i].v} is ${isCritical ? "critical" : isPseudo ? "pseudo-critical" : "neither"}`,
              tracks: [chips("edges (u,v,w)", edges.map((e) => e.u + "-" + e.v + ":" + e.w), (k) => (k === i ? "result" : "idle")), chips("critical", critical.map((x) => "#" + x), "good"), chips("pseudo", pseudo.map((x) => "#" + x), "active")],
              counters: [count("without weight", Number.isFinite(without) ? without : "∞"), count("forced weight", Number.isFinite(withIt) ? withIt : "∞")],
              happened: isCritical ? "Skipping it raises the best weight, so every MST must use it." : isPseudo ? "Forcing it still reaches the best weight, but the MST can survive without it." : "There are better trees that do not need this edge.",
              why: "Critical edges are mandatory; pseudo-critical edges are optional members of some optimum.",
              legend: LEG,
              codeLine: 14,
            });
          }
          out.push({
            title: `Critical ${show(critical)}; pseudo ${show(pseudo)}`,
            tracks: [chips("critical", critical, "result"), chips("pseudo", pseudo, "result")],
            counters: [count("critical", critical.length), count("pseudo", pseudo.length)],
            happened: "Each edge was tested both by removing it and by forcing it.",
            why: "The two tests distinguish mandatory, optional, and irrelevant edges.",
            legend: LEG,
            codeLine: 17,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "build-a-matrix-with-conditions",
    title: "Build a Matrix With Conditions",
    category: "Advanced Graphs",
    difficulty: "Advanced",
    description: "Place numbers so row and column ordering conditions both hold.",
    input: { label: "k | row conditions | col conditions", default: "3 | 1,2 2,3 | 2,1 3,2", parse: "string" },
    approaches: [
      {
        name: "Two Topological Sorts",
        complexity: "O(k + conditions) time, O(k) space",
        idea: [
          "Row conditions order numbers from top to bottom; column conditions order them from left to right. Each set must be acyclic.",
          "Topologically sort both graphs. The row order gives each value a row, the column order gives it a column, and the intersections form the matrix.",
        ],
        problem: ["If either graph has a cycle, no valid matrix can exist, because a cycle would require a value to be both above and below itself."],
        code: {
          c: `#include <stdbool.h>
#include <stdlib.h>

bool topo(int k, int** cond, int m, int* order) {
    int* indeg = calloc(k + 1, sizeof(int));
    int** g = calloc(k + 1, sizeof(int*));
    int* deg = calloc(k + 1, sizeof(int));
    for (int i = 0; i < m; i++) {
        int a = cond[i][0], b = cond[i][1];
        g[a] = realloc(g[a], (deg[a] + 1) * sizeof(int));
        g[a][deg[a]++] = b;
        indeg[b]++;
    }
    int head = 0, tail = 0;
    for (int i = 1; i <= k; i++) if (!indeg[i]) order[tail++] = i;
    while (head < tail) {
        int u = order[head++];
        for (int j = 0; j < deg[u]; j++) if (--indeg[g[u][j]] == 0) order[tail++] = g[u][j];
    }
    return tail == k;
}`,
          cpp: `#include <queue>
#include <vector>
using namespace std;

bool topo(int k, vector<vector<int>>& cond, vector<int>& order) {
    vector<vector<int>> g(k + 1);
    vector<int> indeg(k + 1);
    for (auto& e : cond) { g[e[0]].push_back(e[1]); indeg[e[1]]++; }
    queue<int> q;
    for (int i = 1; i <= k; i++) if (!indeg[i]) q.push(i);
    while (!q.empty()) {
        int u = q.front(); q.pop();
        order.push_back(u);
        for (int v : g[u]) if (--indeg[v] == 0) q.push(v);
    }
    return (int)order.size() == k;
}`,
        },
        steps(text) {
          const parts = String(text || "").split("|").map((s) => s.trim());
          const k = Math.max(1, parseInt(parts[0], 10) || 1);
          const rows = pairs(parts[1] || "");
          const cols = pairs(parts[2] || "");
          const out = [];
          const topo = (edges) => {
            const g = Array.from({ length: k + 1 }, () => []);
            const indeg = new Array(k + 1).fill(0);
            for (const [a, b] of edges) if (a >= 1 && a <= k && b >= 1 && b <= k) { g[a].push(b); indeg[b]++; }
            const q = [];
            for (let i = 1; i <= k; i++) if (indeg[i] === 0) q.push(i);
            let head = 0;
            const order = [];
            while (head < q.length) {
              const u = q[head++];
              order.push(u);
              for (const v of g[u]) if (--indeg[v] === 0) q.push(v);
            }
            return { order, ok: order.length === k, indeg, g };
          };
          out.push({
            title: "Separate row and column constraints",
            tracks: [chips("row conditions", rows.map((e) => e[0] + "<" + e[1]), "idle"), chips("column conditions", cols.map((e) => e[0] + "<" + e[1]), "idle")],
            counters: [count("values", k), count("conditions", rows.length + cols.length)],
            happened: "Rows must respect one partial order; columns must respect the other.",
            why: "Two independent topological sorts can place each value in both dimensions.",
            legend: LEG,
            codeLine: 3,
          });
          const row = topo(rows);
          out.push({
            title: row.ok ? `Row order: ${show(row.order)}` : "Row conditions contain a cycle",
            tracks: [chips("row order", row.order, "active"), chips("row indegrees", row.indeg.map((d, i) => (i ? i + ":" + d : "")).filter(Boolean), "idle")],
            counters: [count("row values placed", row.order.length, k)],
            happened: row.ok ? "Every row condition points from an earlier to a later row." : "At least one value can never get an indegree of zero.",
            why: "A cycle would demand a value be both before and after another value.",
            legend: LEG,
            codeLine: 13,
          });
          const col = topo(cols);
          out.push({
            title: col.ok ? `Column order: ${show(col.order)}` : "Column conditions contain a cycle",
            tracks: [chips("column order", col.order, "active")],
            counters: [count("column values placed", col.order.length, k)],
            happened: col.ok ? "The column ordering is also acyclic." : "The column graph cannot be topologically sorted.",
            why: "Both dimensions need a valid order before any cell can be assigned.",
            legend: LEG,
            codeLine: 13,
          });
          if (!row.ok || !col.ok) {
            out.push({ title: "No valid matrix", tracks: [chips("answer", ["[]"], "bad")], counters: [count("answer", "impossible")], happened: "A cycle in either condition makes the request impossible.", why: "No placement can satisfy contradictory ordering.", legend: LEG, codeLine: 16 });
            return out;
          }
          const rowPos = new Map(row.order.map((v, i) => [v, i]));
          const colPos = new Map(col.order.map((v, i) => [v, i]));
          const matrix = Array.from({ length: k }, () => new Array(k).fill(0));
          for (let v = 1; v <= k; v++) matrix[rowPos.get(v)][colPos.get(v)] = v;
          out.push({
            title: "Place each value at its row and column",
            kind: "grid", rows: k, cols: k, cells: grid(k, k, (r, c) => ({ r, c, v: matrix[r][c] || "", state: matrix[r][c] ? "read" : "idle" })),
            counters: [count("values placed", k, k), count("rows", k)],
            happened: "The row position and column position intersect at exactly one cell per value.",
            why: "Topological positions already encode every ordering condition.",
            legend: LEG,
            codeLine: 18,
          });
          out.push({
            title: "Matrix satisfies both condition sets",
            kind: "grid", rows: k, cols: k, cells: grid(k, k, (r, c) => ({ r, c, v: matrix[r][c] || "", state: matrix[r][c] ? "result" : "idle" })),
            counters: [count("values placed", k, k), count("answer", "valid")],
            happened: "Earlier values in each row condition are above; earlier values in each column condition are to the left.",
            why: "Grid coordinates directly follow the two topological orders.",
            legend: LEG,
            codeLine: 19,
          });
          return out;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "greatest-common-divisor-traversal",
    title: "Greatest Common Divisor Traversal",
    category: "Advanced Graphs",
    difficulty: "Advanced",
    description: "Check whether all indices can be connected through pairs with gcd greater than one.",
    input: { label: "The numbers", default: "2, 3, 6", parse: "ints" },
    approaches: [
      {
        name: "Union Indices Sharing a Factor",
        complexity: "O(n * sqrt(max value)) time, O(n) space",
        idea: [
          "Two indices are directly connected when their values share a prime factor greater than one.",
          "Factor each value and union its index with the first index seen for every prime factor. At the end, all indices must be in one union-find component.",
        ],
        problem: ["Factoring every value separately can repeat work; a smallest-prime-factor sieve is faster for large ranges."],
        code: {
          c: `#include <stdbool.h>
#include <stdlib.h>

int find(int* p, int x) { return p[x] == x ? x : (p[x] = find(p, p[x])); }
void join(int* p, int* r, int a, int b) {
    a = find(p, a); b = find(p, b);
    if (a == b) return;
    if (r[a] < r[b]) { int t = a; a = b; b = t; }
    p[b] = a;
    if (r[a] == r[b]) r[a]++;
}

bool canTraverseAllPairs(int* nums, int n) {
    if (n == 1) return true;
    int* p = malloc(n * sizeof(int));
    int* r = calloc(n, sizeof(int));
    for (int i = 0; i < n; i++) p[i] = i;
    for (int i = 0; i < n; i++) {
        int x = nums[i];
        for (int f = 2; (long long)f * f <= x; f++) {
            if (x % f == 0) {
                for (int j = 0; j < i; j++)
                    if (nums[j] % f == 0) join(p, r, i, j);
                while (x % f == 0) x /= f;
            }
        }
        if (x > 1)
            for (int j = 0; j < i; j++)
                if (nums[j] % x == 0) join(p, r, i, j);
    }
    int root = find(p, 0);
    for (int i = 1; i < n; i++) if (find(p, i) != root) return false;
    return true;
}`,
          cpp: `#include <numeric>
#include <unordered_map>
#include <vector>
using namespace std;

int find(vector<int>& p, int x) { return p[x] == x ? x : p[x] = find(p, p[x]); }

bool canTraverseAllPairs(vector<int>& nums) {
    int n = nums.size();
    if (n == 1) return true;
    vector<int> p(n);
    iota(p.begin(), p.end(), 0);
    unordered_map<int, int> first;
    for (int i = 0; i < n; i++) {
        int x = nums[i];
        for (int f = 2; (long long)f * f <= x; f++) {
            if (x % f) continue;
            if (first.count(f)) p[find(p, i)] = find(p, first[f]);
            else first[f] = i;
            while (x % f == 0) x /= f;
        }
        if (x > 1) {
            if (first.count(x)) p[find(p, i)] = find(p, first[x]);
            else first[x] = i;
        }
    }
    int root = find(p, 0);
    for (int i = 1; i < n; i++) if (find(p, i) != root) return false;
    return true;
}`,
        },
        steps(nums) {
          const n = nums.length;
          const p = Array.from({ length: n }, (_, i) => i);
          const find = (x) => (p[x] === x ? x : (p[x] = find(p[x])));
          const join = (a, b) => { a = find(a); b = find(b); if (a !== b) p[a] = b; };
          const first = new Map();
          const out = [];
          out.push({
            title: "Each index starts in its own group",
            tracks: [track("numbers", nums, fill(n, "idle")), chips("groups", p.map((_, i) => "{" + i + "}"), "idle")],
            counters: [count("groups", n), count("indices", n)],
            happened: "A group is a connected component of indices.",
            why: "All indices are connected exactly when one group remains.",
            legend: LEG,
            codeLine: 4,
          });
          const factor = (x) => {
            const fs = [];
            let v = Math.abs(x);
            for (let f = 2; f * f <= v; f++) {
              if (v % f === 0) {
                fs.push(f);
                while (v % f === 0) v /= f;
              }
            }
            if (v > 1) fs.push(v);
            return fs;
          };
          for (let i = 0; i < n; i++) {
            const fs = factor(nums[i]);
            for (const f of fs) {
              if (first.has(f)) join(i, first.get(f));
              else first.set(f, i);
            }
            out.push({
              title: `Factor ${nums[i]} = ${fs.length ? fs.join(" * ") : "1"}`,
              tracks: [track("numbers", nums, nums.map((v, k) => (k === i ? "read" : k < i ? "done" : "idle"))), chips("prime owners", [...first.entries()].map(([f, idx]) => f + ":i" + idx), "active")],
              counters: [count("groups", new Set(p.map((_, k) => find(k))).size), count("factors", fs.length)],
              happened: fs.length ? `Index ${i} is joined to earlier indices sharing ${fs.join(", ")}.` : "The value 1 shares no factor, so it stays isolated.",
              why: "Sharing any prime factor creates a valid edge between two indices.",
              legend: LEG,
              codeLine: 12,
            });
          }
          const roots = new Set(p.map((_, i) => find(i)));
          const ok = n === 1 || roots.size === 1;
          out.push({
            title: ok ? "All indices are connected" : `${roots.size} separate groups remain`,
            tracks: [track("numbers", nums, fill(n, ok ? "result" : "dim")), chips("groups", p.map((_, i) => "{" + find(i) + "}"), ok ? "result" : "bad")],
            counters: [count("groups", roots.size), count("answer", ok ? "true" : "false")],
            happened: ok ? "Every index belongs to the same union-find group." : "Some indices cannot reach the rest through shared factors.",
            why: "Traversal is possible exactly when the factor graph has one connected component.",
            legend: LEG,
            codeLine: 24,
          });
          return out;
        },
      },
    ],
  });
})();
