/* ============================================================
   DSA Visuals — Graphs I
   Water flow from two oceans, topological order, DSU checks
   and two-colouring. Small graphs use a circular layout with
   one state per node and one state per edge.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => `[${a.join(", ")}]`;
  const partsOf = (text) => String(text || "").split("|").map((p) => p.trim());
  const ints = (text) => String(text || "").split(/[\s,;]+/).filter(Boolean).map(Number);
  const pairsOf = (text) =>
    String(text || "").split(/\s+/).filter(Boolean).map((p) => p.split(",").map((x) => parseInt(x, 10))).filter((p) => p.length === 2 && p.every(Number.isFinite));

  function circlePos(i, n) {
    const a = (2 * Math.PI * i) / Math.max(1, n) - Math.PI / 2;
    return { x: +(25 + 20 * Math.cos(a)).toFixed(1), y: +(25 + 20 * Math.sin(a)).toFixed(1) };
  }
  function graphStep(labels, edges, states, edgeStates, extra) {
    return Object.assign({
      kind: "graph",
      nodes: labels.map((lab, i) => {
        const p = circlePos(i, labels.length);
        return { id: "n" + i, label: String(lab), x: p.x, y: p.y, state: (states && states[i]) || "idle" };
      }),
      edges: edges.map(([u, v], i) => ({ a: "n" + u, b: "n" + v, state: (edgeStates && edgeStates[i]) || "idle" })),
      legend: LEG,
    }, extra);
  }
  function dsuOf(n) {
    const p = Array.from({ length: n }, (_, i) => i);
    const find = (x) => {
      while (p[x] !== x) { p[x] = p[p[x]]; x = p[x]; }
      return x;
    };
    const union = (a, b) => {
      const ra = find(a), rb = find(b);
      if (ra === rb) return false;
      p[rb] = ra;
      return true;
    };
    return { p, find, union };
  }

  /* ---------------------------------------------------------- */
  V.register({
    id: "pacific-atlantic-water-flow",
    title: "Pacific Atlantic Water Flow",
    category: "Graphs",
    difficulty: "Advanced",
    description: "Find the cells whose water can drain to both the Pacific and the Atlantic edge.",
    input: { label: "Height rows separated by |", default: "1,2,2,3,5 | 3,2,3,4,4 | 2,4,5,3,1 | 6,7,1,4,5 | 5,1,1,2,4", parse: "string" },
    approaches: [
      {
        name: "Reverse Flow From Both Coasts",
        complexity: "O(rows × cols) time",
        idea: [
          "Water flows from high to low, which is awkward to search forwards from every cell. Reverse it: start at the ocean edges and walk uphill to cells that could drain into them.",
          "Run one uphill flood from the Pacific edges and one from the Atlantic edges. A cell is an answer only when both floods reach it.",
        ],
        problem: [
          "Testing every cell separately repeats the same walks; two multi-source floods touch every cell at most twice.",
        ],
        code: {
          c: `#include <stdio.h>
#include <string.h>

int h[5][5] = {{1,2,2,3,5},{3,2,3,4,4},{2,4,5,3,1},{6,7,1,4,5},{5,1,1,2,4}};
int seen[2][5][5];
int dr[] = {1,-1,0,0}, dc[] = {0,0,1,-1};

void flood(int ocean, int r, int c, int from_h) {
    if (r < 0 || r > 4 || c < 0 || c > 4) return;
    if (seen[ocean][r][c] || h[r][c] < from_h) return;
    seen[ocean][r][c] = 1;
    for (int d = 0; d < 4; d++) flood(ocean, r + dr[d], c + dc[d], h[r][c]);
}

int main(void) {
    for (int r = 0; r < 5; r++) { flood(0, r, 0, 0); flood(1, r, 4, 0); }
    for (int c = 0; c < 5; c++) { flood(0, 0, c, 0); flood(1, 4, c, 0); }

    for (int r = 0; r < 5; r++)
        for (int c = 0; c < 5; c++)
            if (seen[0][r][c] && seen[1][r][c]) printf("(%d,%d) ", r, c);
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

int dr[] = {1,-1,0,0}, dc[] = {0,0,1,-1};

void flood(vector<vector<int>>& h, vector<vector<bool>>& seen, int r, int c, int from) {
    int R = h.size(), C = h[0].size();
    if (r < 0 || r >= R || c < 0 || c >= C) return;
    if (seen[r][c] || h[r][c] < from) return;
    seen[r][c] = true;
    for (int d = 0; d < 4; d++) flood(h, seen, r + dr[d], c + dc[d], h[r][c]);
}

int main() {
    vector<vector<int>> h{{1,2,2,3,5},{3,2,3,4,4},{2,4,5,3,1},{6,7,1,4,5},{5,1,1,2,4}};
    int R = h.size(), C = h[0].size();
    vector<vector<bool>> pac(R, vector<bool>(C)), atl(R, vector<bool>(C));

    for (int r = 0; r < R; r++) { flood(h, pac, r, 0, 0); flood(h, atl, r, C - 1, 0); }
    for (int c = 0; c < C; c++) { flood(h, pac, 0, c, 0); flood(h, atl, R - 1, c, 0); }

    for (int r = 0; r < R; r++)
        for (int c = 0; c < C; c++)
            if (pac[r][c] && atl[r][c]) cout << '(' << r << ',' << c << ") ";
    cout << '\\n';
}`,
        },
        steps(text) {
          const rows = partsOf(text).map((r) => r.split(/[\s,]+/).filter(Boolean).map(Number)).filter((r) => r.length);
          if (!rows.length) return [{
            title: "Give height rows",
            tracks: [chips("heights", ["—"], "idle")],
            counters: [count("cells", 0)],
            legend: LEG,
            happened: "There is no terrain to flood.",
            why: "The grid must contain at least one height.",
          }];
          const R = Math.min(8, rows.length);
          const C = Math.min(8, Math.max(...rows.map((r) => r.length)));
          const h = Array.from({ length: R }, (_, r) => Array.from({ length: C }, (_, c) => (rows[r] && rows[r][c]) || 0));
          const pac = Array.from({ length: R }, () => Array(C).fill(false));
          const atl = Array.from({ length: R }, () => Array(C).fill(false));
          const steps = [];
          const both = [];
          const cells = (fr, extra) => grid(R, C, (r, c) => {
            const isFront = fr && fr.some(([a, b]) => a === r && b === c);
            const state = isFront ? "read" : pac[r][c] && atl[r][c] ? "result" : pac[r][c] ? "active" : atl[r][c] ? "compare" : extra || "dim";
            return { v: h[r][c], state };
          });
          steps.push({
            title: "Start floods at the ocean edges",
            kind: "grid", rows: R, cols: C, cells: cells(),
            counters: [count("Pacific reach", 0), count("Atlantic reach", 0), count("cells", R * C)],
            legend: LEG,
            happened: "Pacific water touches the top and left edges; Atlantic water touches the bottom and right edges.",
            why: "Reversing the flow turns many sources into two ordinary multi-source searches.",
            codeLine: 7,
          });
          const bfs = (seen, seeds, name) => {
            const queue = [];
            seeds.forEach(([r, c]) => { if (!seen[r][c]) { seen[r][c] = true; queue.push([r, c]); } });
            const counts = () => seen.flat().filter(Boolean).length;
            steps.push({
              title: `Seed the ${name} flood from its coastline`,
              kind: "grid", rows: R, cols: C, cells: cells(queue),
              counters: [count("Pacific reach", pac.flat().filter(Boolean).length), count("Atlantic reach", atl.flat().filter(Boolean).length), count("frontier", queue.length)],
              legend: LEG,
              happened: `${queue.length} edge cell${queue.length === 1 ? "" : "s"} start the ${name} search.`,
              why: "Every coastal cell can drain directly into its ocean.",
              codeLine: 8,
            });
            const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
            while (queue.length) {
              const level = queue.splice(0, queue.length);
              level.forEach(([r, c]) => {
                dirs.forEach(([dr, dc]) => {
                  const nr = r + dr, nc = c + dc;
                  if (nr < 0 || nr >= R || nc < 0 || nc >= C) return;
                  if (seen[nr][nc] || h[nr][nc] < h[r][c]) return;
                  seen[nr][nc] = true;
                  queue.push([nr, nc]);
                });
              });
              if (!queue.length) break;
              steps.push({
                title: `${name} flood reaches ${queue.length} more cell${queue.length === 1 ? "" : "s"}`,
                kind: "grid", rows: R, cols: C, cells: cells(queue),
                counters: [count("Pacific reach", pac.flat().filter(Boolean).length), count("Atlantic reach", atl.flat().filter(Boolean).length), count("frontier", queue.length)],
                legend: LEG,
                happened: "The search only climbs to equal or higher neighbours, mirroring water flowing back down the same edge.",
                why: "Uphill from the ocean is exactly the reverse of downhill towards it.",
                codeLine: 6,
              });
            }
          };
          const pacSeeds = [];
          const atlSeeds = [];
          for (let r = 0; r < R; r++) { pacSeeds.push([r, 0]); atlSeeds.push([r, C - 1]); }
          for (let c = 0; c < C; c++) { pacSeeds.push([0, c]); atlSeeds.push([R - 1, c]); }
          bfs(pac, pacSeeds, "Pacific");
          bfs(atl, atlSeeds, "Atlantic");
          for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) if (pac[r][c] && atl[r][c]) both.push([r, c]);
          steps.push({
            title: `Answer: ${both.length} cell${both.length === 1 ? "" : "s"} drain to both oceans`,
            kind: "grid", rows: R, cols: C, cells: cells(),
            counters: [count("both", both.length), count("Pacific reach", pac.flat().filter(Boolean).length), count("Atlantic reach", atl.flat().filter(Boolean).length)],
            legend: LEG,
            happened: both.length ? `${both.map(([r, c]) => `(${r},${c})`).join(" ")} appear in both flood sets.` : "No cell is reachable from both oceans.",
            why: "The intersection of the two uphill reachable sets is exactly the answer.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  const kahnSteps = (raw, wantOrder) => {
    const parts = partsOf(raw);
    const n = Math.min(20, Math.max(0, parseInt(parts[0], 10) || 0));
    const edges = pairsOf(parts[1] || "").filter(([u, v]) => u >= 0 && v >= 0 && u < n && v < n && u !== v);
    const adj = Array.from({ length: n }, () => []);
    const indeg = Array(n).fill(0);
    edges.forEach(([u, v]) => { adj[u].push(v); indeg[v]++; });
    const steps = [];
    const queue = [];
    indeg.forEach((d, i) => { if (d === 0) queue.push(i); });
    const done = new Set();
    const order = [];
    const stateOf = (i) => (order.includes(i) ? "done" : queue.includes(i) ? "active" : done.has(i) ? "done" : "idle");
    steps.push({
      title: `${n} courses, ${edges.length} prerequisite edge${edges.length === 1 ? "" : "s"}`,
      tracks: [
        chips("courses", Array.from({ length: n }, (_, i) => i), "idle"),
        chips("indegree", indeg.map((d, i) => `${i}:${d}`), (i) => (indeg[i] === 0 ? "good" : "dim")),
        chips("queue", queue, "active"),
      ],
      counters: [count("processed", 0, n), count("queue", queue.length), count("edges", edges.length)],
      legend: LEG,
      happened: "A course with indegree 0 has no unfinished prerequisite, so it can be taken now.",
      why: "Kahn's algorithm repeatedly removes such a course and lowers the indegree of its dependants.",
      codeLine: 6,
    });
    while (queue.length) {
      const u = queue.shift();
      order.push(u);
      done.add(u);
      const changed = [];
      adj[u].forEach((v) => {
        indeg[v]--;
        if (indeg[v] === 0) { queue.push(v); changed.push(v); }
      });
      steps.push({
        title: `Take course ${u}${changed.length ? `; ${changed.join(", ")} become${changed.length === 1 ? "s" : ""} free` : ""}`,
        tracks: [
          chips("courses", Array.from({ length: n }, (_, i) => i), stateOf),
          chips("indegree", indeg.map((d, i) => `${i}:${d}`), (i) => (i === u ? "read" : indeg[i] === 0 ? "good" : "dim")),
          chips("order", order, (i) => (i === order.length - 1 ? "result" : "done")),
        ],
        counters: [count("processed", order.length, n), count("queue", queue.length), count("course", u)],
        legend: LEG,
        happened: `Course ${u} leaves the queue; every course that needed it now has one less prerequisite.`,
        why: "Only a course whose count falls to zero joins the queue, so prerequisites are never skipped.",
        codeLine: 11,
      });
    }
    steps.push({
      title: wantOrder
        ? (order.length === n ? `Answer: ${show(order)}` : "Answer: a cycle blocks every course")
        : (order.length === n ? "Answer: all courses can be finished" : "Answer: a prerequisite cycle makes finishing impossible"),
      tracks: [
        chips("order", order.length ? order : ["none"], order.length === n ? "result" : "bad"),
        chips("remaining", Array.from({ length: n }, (_, i) => i).filter((i) => !done.has(i)), (i) => (order.length === n ? "done" : "bad")),
      ],
      counters: [count("processed", order.length, n), count("answer", order.length === n ? "yes" : "cycle")],
      legend: LEG,
      happened: order.length === n ? "Every course left the queue exactly once." : `${n - order.length} courses never reached indegree 0.`,
      why: "A cycle has no entry point, so its courses keep at least one unfinished prerequisite forever.",
      codeLine: 15,
    });
    return steps;
  };

  V.register({
    id: "course-schedule",
    title: "Course Schedule",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Decide whether every course can be taken without breaking a prerequisite.",
    input: { label: "courses | prerequisite pairs (course,needs)", default: "4 | 1,0 2,0 3,1 3,2", parse: "string" },
    approaches: [
      {
        name: "Kahn's Indegree Queue",
        complexity: "O(V + E) time",
        idea: [
          "Count how many prerequisites each course still needs. Courses with count 0 start in a queue.",
          "Taking a course lowers the count of every course that depends on it. If all courses are taken, there is no cycle; if some never reach 0, a cycle blocks them.",
        ],
        problem: [
          "A plain DFS that marks visited without distinguishing the current recursion stack reports cycles incorrectly on shared prerequisites.",
        ],
        code: {
          c: `#include <stdio.h>

int main(void) {
    int n = 4;
    int edges[4][2] = {{1,0},{2,0},{3,1},{3,2}};
    int indeg[16] = {0}, adj[16][16] = {0}, outdeg[16] = {0};

    for (int i = 0; i < 4; i++) {
        int course = edges[i][0], needs = edges[i][1];
        adj[needs][outdeg[needs]++] = course;
        indeg[course]++;
    }

    int queue[16], head = 0, tail = 0;
    for (int c = 0; c < n; c++) if (indeg[c] == 0) queue[tail++] = c;

    int taken = 0;
    while (head < tail) {
        int c = queue[head++];
        taken++;
        for (int i = 0; i < outdeg[c]; i++) {
            int next = adj[c][i];
            if (--indeg[next] == 0) queue[tail++] = next;
        }
    }
    printf("%d\\n", taken == n); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
using namespace std;

bool canFinish(int n, vector<vector<int>>& pre) {
    vector<vector<int>> adj(n);
    vector<int> indeg(n, 0);
    for (auto& p : pre) { adj[p[1]].push_back(p[0]); indeg[p[0]]++; }

    queue<int> q;
    for (int i = 0; i < n; i++) if (!indeg[i]) q.push(i);

    int taken = 0;
    while (!q.empty()) {
        int c = q.front(); q.pop();
        taken++;
        for (int next : adj[c])
            if (--indeg[next] == 0) q.push(next);
    }
    return taken == n;
}

int main() {
    vector<vector<int>> pre{{1,0},{2,0},{3,1},{3,2}};
    cout << canFinish(4, pre) << '\\n'; // 1
}`,
        },
        steps(raw) { return kahnSteps(raw, false); },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "course-schedule-ii",
    title: "Course Schedule II",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Return one valid order for finishing every course.",
    input: { label: "courses | prerequisite pairs", default: "4 | 1,0 2,0 3,1 3,2", parse: "string" },
    approaches: [
      {
        name: "Kahn's Order",
        complexity: "O(V + E) time",
        idea: [
          "Start with every course that has no prerequisites and append it to the order.",
          "Each time a prerequisite is removed, a dependant's count drops. A course enters the order exactly when its count reaches zero.",
        ],
        problem: [
          "Reversing the edges and hoping for the best can output a course before its prerequisite; the indegree queue enforces the order directly.",
        ],
        code: {
          c: `#include <stdio.h>

int main(void) {
    int n = 4;
    int edges[4][2] = {{1,0},{2,0},{3,1},{3,2}};
    int indeg[16] = {0}, adj[16][16] = {0}, outdeg[16] = {0};

    for (int i = 0; i < 4; i++) {
        adj[edges[i][1]][outdeg[edges[i][1]]++] = edges[i][0];
        indeg[edges[i][0]]++;
    }

    int q[16], head = 0, tail = 0, order[16], at = 0;
    for (int c = 0; c < n; c++) if (!indeg[c]) q[tail++] = c;

    while (head < tail) {
        int c = q[head++];
        order[at++] = c;
        for (int i = 0; i < outdeg[c]; i++)
            if (--indeg[adj[c][i]] == 0) q[tail++] = adj[c][i];
    }

    if (at != n) { printf("cycle\\n"); return 0; }
    for (int i = 0; i < at; i++) printf("%d ", order[i]); /* 0 1 2 3 */
    printf("\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
using namespace std;

vector<int> findOrder(int n, vector<vector<int>>& pre) {
    vector<vector<int>> adj(n);
    vector<int> indeg(n, 0);
    for (auto& p : pre) { adj[p[1]].push_back(p[0]); indeg[p[0]]++; }

    queue<int> q;
    for (int i = 0; i < n; i++) if (!indeg[i]) q.push(i);

    vector<int> order;
    while (!q.empty()) {
        int c = q.front(); q.pop();
        order.push_back(c);
        for (int next : adj[c])
            if (--indeg[next] == 0) q.push(next);
    }
    if ((int)order.size() != n) return {};   // cycle
    return order;
}

int main() {
    vector<vector<int>> pre{{1,0},{2,0},{3,1},{3,2}};
    for (int c : findOrder(4, pre)) cout << c << ' '; // 0 1 2 3
    cout << '\\n';
}`,
        },
        steps(raw) { return kahnSteps(raw, true); },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  const dsuViz = (raw, mode) => {
    const parts = partsOf(raw);
    const n = Math.min(14, Math.max(0, parseInt(parts[0], 10) || 0));
    const edges = pairsOf(parts[1] || "").filter(([u, v]) => u >= 0 && v >= 0 && u < n && v < n && u !== v);
    const labels = Array.from({ length: n }, (_, i) => i);
    const { p, find, union } = dsuOf(n);
    const steps = [];
    let components = n;
    const edgeStates = [];
    const compState = (i) => {
      const root = find(i);
      const seenRoots = [];
      for (let k = 0; k < i; k++) seenRoots.push(find(k));
      const idx = [...new Set(seenRoots)].indexOf(root);
      return ["good", "active", "compare", "result", "done"][Math.max(0, idx) % 5];
    };
    steps.push(graphStep(labels, edges.map(([u, v]) => [u, v]), Object.fromEntries(labels.map((i) => [i, "idle"])), fill(edges.length, "idle"), {
      title: `Start with ${n} isolated components`,
      label: "every node is its own component",
      counters: [count("components", components, n), count("edges used", 0, edges.length)],
      happened: "No edge has been merged yet.",
      why: "Union-find starts with each vertex as a separate set.",
      codeLine: 5,
    }));
    for (let e = 0; e < edges.length; e++) {
      const [u, v] = edges[e];
      const ru = find(u), rv = find(v);
      const ok = ru !== rv;
      if (ok) { union(u, v); components--; edgeStates[e] = "good"; }
      else edgeStates[e] = "bad";
      const states = {};
      labels.forEach((i) => { states[i] = i === u || i === v ? "read" : compState(i); });
      steps.push(graphStep(labels, edges, states, edgeStates, {
        title: ok ? `Union ${u} and ${v}` : `Edge ${u}–${v} closes a cycle`,
        label: ok ? `components: ${components}` : `roots already equal (${ru})`,
        counters: [count("components", components, n), count("edges processed", e + 1, edges.length)],
        happened: ok ? `${u} and ${v} were in different sets, so the sets merge.` : `${u} and ${v} already share a root, so this edge adds no connection.`,
        why: mode === "tree"
          ? "A valid tree needs every edge to merge two different components."
          : "A redundant edge is exactly one whose endpoints are already connected.",
        codeLine: ok ? 9 : 7,
      }));
    }
    if (mode === "tree") {
      const ok = edges.length === n - 1 && components === 1;
      steps.push(graphStep(labels, edges, Object.fromEntries(labels.map((i) => [i, ok ? "result" : "bad"])), fill(edges.length, ok ? "done" : "bad"), {
        title: ok ? "Answer: these edges form a valid tree" : "Answer: not a valid tree",
        label: `${edges.length} edges for ${n} nodes; components ${components}`,
        counters: [count("edges", edges.length), count("needed", Math.max(0, n - 1)), count("components", components)],
        happened: ok ? "The graph is connected and has exactly n − 1 edges." : "Either a cycle appeared or some node stayed disconnected.",
        why: "A tree is connected and acyclic, which is equivalent to exactly n − 1 merging edges.",
        codeLine: 14,
      }));
    } else {
      steps.push(graphStep(labels, edges, Object.fromEntries(labels.map((i) => [i, "result"])), fill(edges.length, "done"), {
        title: `Answer: ${components} connected component${components === 1 ? "" : "s"}`,
        label: `component count = ${components}`,
        counters: [count("components", components), count("nodes", n), count("edges", edges.length)],
        happened: `The unions reduced ${n} singleton sets to ${components} sets.`,
        why: "Each successful union decreases the component count by exactly one.",
        codeLine: 12,
      }));
    }
    return steps;
  };

  V.register({
    id: "graph-valid-tree",
    title: "Graph Valid Tree",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Check that an undirected graph is connected and has no cycle.",
    input: { label: "nodes | edges as u,v pairs", default: "5 | 0,1 0,2 0,3 1,4", parse: "string" },
    approaches: [
      {
        name: "Union Until a Merge Fails",
        complexity: "O(E α(V)) time",
        idea: [
          "Process the edges one by one, merging the components of their endpoints.",
          "Every edge in a forest must merge two different components. If an edge finds both endpoints already together, it closes a cycle and the graph is not a tree. At the end there must be exactly one component.",
        ],
        problem: [
          "Counting edges alone is not enough: n − 1 edges can still leave two separate components and one cycle.",
        ],
        code: {
          c: `#include <stdio.h>

int parent[16];
int find(int x) {
    while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }
    return x;
}

int main(void) {
    int n = 5;
    int edges[4][2] = {{0,1},{0,2},{0,3},{1,4}};
    for (int i = 0; i < n; i++) parent[i] = i;

    int components = n;
    for (int i = 0; i < 4; i++) {
        int a = find(edges[i][0]), b = find(edges[i][1]);
        if (a == b) { printf("cycle\\n"); return 0; }
        parent[b] = a;
        components--;
    }
    printf("%d\\n", components == 1); /* 1 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <numeric>
using namespace std;

int find(vector<int>& p, int x) {
    while (p[x] != x) { p[x] = p[p[x]]; x = p[x]; }
    return x;
}

bool validTree(int n, vector<vector<int>>& edges) {
    if ((int)edges.size() != n - 1) return false;
    vector<int> p(n);
    iota(p.begin(), p.end(), 0);

    for (auto& e : edges) {
        int a = find(p, e[0]), b = find(p, e[1]);
        if (a == b) return false;   // cycle
        p[b] = a;
    }
    return true;
}

int main() {
    vector<vector<int>> edges{{0,1},{0,2},{0,3},{1,4}};
    cout << validTree(5, edges) << '\\n'; // 1
}`,
        },
        steps(raw) { return dsuViz(raw, "tree"); },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "number-of-connected-components",
    title: "Number of Connected Components",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Count the groups of vertices that are joined to each other by edges.",
    input: { label: "nodes | edges as u,v pairs", default: "5 | 0,1 1,2 3,4", parse: "string" },
    approaches: [
      {
        name: "Union-Find Component Count",
        complexity: "O(E α(V)) time",
        idea: [
          "Begin with n components, one per vertex, and a running count of n.",
          "Each edge whose endpoints have different roots merges two groups and lowers the count by one. An edge inside one group leaves the count unchanged.",
        ],
        problem: [
          "Recounting groups by scanning every pair after each edge turns a near-linear algorithm into a quadratic one.",
        ],
        code: {
          c: `#include <stdio.h>

int parent[16];
int find(int x) {
    while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }
    return x;
}

int main(void) {
    int n = 5;
    int edges[3][2] = {{0,1},{1,2},{3,4}};
    for (int i = 0; i < n; i++) parent[i] = i;

    int components = n;
    for (int i = 0; i < 3; i++) {
        int a = find(edges[i][0]), b = find(edges[i][1]);
        if (a == b) continue;
        parent[b] = a;
        components--;
    }
    printf("%d\\n", components); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <numeric>
using namespace std;

int find(vector<int>& p, int x) {
    while (p[x] != x) { p[x] = p[p[x]]; x = p[x]; }
    return x;
}

int countComponents(int n, vector<vector<int>>& edges) {
    vector<int> p(n);
    iota(p.begin(), p.end(), 0);
    int components = n;

    for (auto& e : edges) {
        int a = find(p, e[0]), b = find(p, e[1]);
        if (a == b) continue;
        p[b] = a;
        components--;
    }
    return components;
}

int main() {
    vector<vector<int>> edges{{0,1},{1,2},{3,4}};
    cout << countComponents(5, edges) << '\\n'; // 2
}`,
        },
        steps(raw) { return dsuViz(raw, "count"); },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  const bipartiteSteps = (raw, labelled) => {
    const parts = partsOf(raw);
    let n, adj;
    if (labelled) {
      n = Math.min(12, Math.max(0, parseInt(parts[0], 10) || 0));
      adj = Array.from({ length: n }, () => []);
      pairsOf(parts[1] || "").forEach(([a, b]) => {
        const u = a - 1, v = b - 1;
        if (u >= 0 && v >= 0 && u < n && v < n && u !== v) { adj[u].push(v); adj[v].push(u); }
      });
    } else {
      const rows = parts.filter(Boolean);
      n = rows.length;
      adj = Array.from({ length: n }, () => []);
      const seen = new Set();
      rows.forEach((row, u) => {
        row.split(/[\s,]+/).filter(Boolean).forEach((x) => {
          const v = parseInt(x, 10);
          if (!Number.isFinite(v) || v < 0 || v >= n || v === u) return;
          const key = u < v ? u + "-" + v : v + "-" + u;
          if (seen.has(key)) return;
          seen.add(key);
          adj[u].push(v); adj[v].push(u);
        });
      });
    }
    const edges = [];
    const seen = new Set();
    adj.forEach((list, u) => list.forEach((v) => {
      const key = u < v ? u + "-" + v : v + "-" + u;
      if (!seen.has(key)) { seen.add(key); edges.push([Math.min(u, v), Math.max(u, v)]); }
    }));
    const labels = Array.from({ length: n }, (_, i) => i);
    const color = Array(n).fill(-1);
    const steps = [];
    let bad = null;
    const nodeStates = (cur) => {
      const m = {};
      labels.forEach((i) => { m[i] = color[i] === 0 ? "good" : color[i] === 1 ? "compare" : "idle"; });
      if (cur != null) m[cur] = "read";
      if (bad != null) m[bad] = "bad";
      return m;
    };
    const edgeStates = () => edges.map(([u, v]) => (bad != null && (u === bad || v === bad) ? "bad" : color[u] !== -1 && color[v] !== -1 ? (color[u] !== color[v] ? "good" : "bad") : "idle"));
    steps.push(graphStep(labels, edges, nodeStates(), edgeStates(), {
      title: `${n} vertices; colouring has not started`,
      label: labelled ? "two groups with no dislikes inside a group" : "two colours, no same-colour edge",
      counters: [count("coloured", 0, n), count("conflicts", 0)],
      happened: "Every edge must join different colours.",
      why: "A graph is bipartite exactly when a two-colouring exists.",
      codeLine: 4,
    }));
    for (let start = 0; start < n && bad == null; start++) {
      if (color[start] !== -1) continue;
      color[start] = 0;
      const queue = [start];
      while (queue.length && bad == null) {
        const u = queue.shift();
        adj[u].forEach((v) => {
          if (bad != null) return;
          if (color[v] === -1) {
            color[v] = 1 - color[u];
            queue.push(v);
          } else if (color[v] === color[u]) {
            bad = v;
          }
        });
        const conflict = adj[u].find((v) => color[v] === color[u]);
        steps.push(graphStep(labels, edges, nodeStates(u), edgeStates(), {
          title: conflict != null ? `Conflict at ${u}: neighbour ${conflict} has the same colour` : `Colour ${u} and push its uncoloured neighbours`,
          label: `colours: ${labels.map((i) => (color[i] === -1 ? "?" : color[i])).join(" ")}`,
          counters: [count("coloured", color.filter((c) => c !== -1).length, n), count("conflicts", conflict != null ? 1 : 0)],
          happened: conflict != null ? `Edge ${u}–${conflict} joins two nodes of colour ${color[u]}.` : `Every neighbour of ${u} gets the opposite colour.`,
          why: "An edge always flips the colour, so colouring follows the graph's parity.",
          codeLine: conflict != null ? 11 : 8,
        }));
      }
    }
    steps.push(graphStep(labels, edges, bad == null ? Object.fromEntries(labels.map((i) => [i, "result"])) : nodeStates(), bad == null ? fill(edges.length, "good") : edgeStates(), {
      title: bad == null ? (labelled ? "Answer: the dislikes can be split into two groups" : "Answer: the graph is bipartite") : "Answer: not bipartite",
      label: bad == null ? "two-colouring succeeded" : `conflict at vertex ${bad}`,
      counters: [count("coloured", color.filter((c) => c !== -1).length, n), count("answer", bad == null ? "yes" : "no")],
      happened: bad == null ? "No edge joined equal colours." : "At least one edge joined two nodes that had to share a colour.",
      why: "The BFS assigns the only colour that can possibly work, so a conflict proves impossibility.",
      codeLine: 15,
    }));
    return steps;
  };

  V.register({
    id: "is-graph-bipartite",
    title: "Is Graph Bipartite",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Test whether the vertices can be split into two groups with no edge inside a group.",
    input: { label: "Adjacency rows separated by |", default: "1,3 | 0,2 | 1,3 | 0,2", parse: "string" },
    approaches: [
      {
        name: "BFS Two-Colouring",
        complexity: "O(V + E) time",
        idea: [
          "Colour an uncoloured start vertex 0, then walk its connected component.",
          "Every neighbour must receive the opposite colour. If a neighbour already has the same colour, the graph is not bipartite.",
        ],
        problem: [
          "Checking only that degrees are even misses odd cycles: parity of a single vertex does not decide bipartiteness.",
        ],
        code: {
          c: `#include <stdio.h>

int adj[4][4] = {{0,1,0,1},{1,0,1,0},{0,1,0,1},{1,0,1,0}};
int color[4] = {-1,-1,-1,-1};

int main(void) {
    int q[16], head = 0, tail = 0;
    color[0] = 0;
    q[tail++] = 0;

    while (head < tail) {
        int u = q[head++];
        for (int v = 0; v < 4; v++) {
            if (!adj[u][v]) continue;
            if (color[v] == -1) { color[v] = 1 - color[u]; q[tail++] = v; }
            else if (color[v] == color[u]) { printf("not bipartite\\n"); return 0; }
        }
    }
    printf("bipartite\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
using namespace std;

bool isBipartite(vector<vector<int>>& adj) {
    vector<int> color(adj.size(), -1);
    for (int s = 0; s < (int)adj.size(); s++) {
        if (color[s] != -1) continue;
        color[s] = 0;
        queue<int> q;
        q.push(s);
        while (!q.empty()) {
            int u = q.front(); q.pop();
            for (int v : adj[u]) {
                if (color[v] == -1) { color[v] = 1 - color[u]; q.push(v); }
                else if (color[v] == color[u]) return false;
            }
        }
    }
    return true;
}

int main() {
    vector<vector<int>> adj{{1,3},{0,2},{1,3},{0,2}};
    cout << isBipartite(adj) << '\\n'; // 1
}`,
        },
        steps(raw) { return bipartiteSteps(raw, false); },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "possible-bipartition",
    title: "Possible Bipartition",
    category: "Graphs",
    difficulty: "Intermediate",
    description: "Split people into two groups so that nobody who dislikes someone shares their group.",
    input: { label: "people | dislike pairs (1-based)", default: "4 | 1,2 1,3 2,4", parse: "string" },
    approaches: [
      {
        name: "Colour the Dislike Graph",
        complexity: "O(V + E) time",
        idea: [
          "Treat each dislike as an undirected edge and try to two-colour the resulting graph.",
          "A person and everyone they dislike must land in different groups, which is exactly the opposite-colour rule.",
        ],
        problem: [
          "Greedily putting each person in the smaller group ignores chains of dislikes and can split two people who must be together.",
        ],
        code: {
          c: `#include <stdio.h>

int adj[5][5];
int color[5] = {-1,-1,-1,-1,-1};

int main(void) {
    int n = 4;
    int pairs[3][2] = {{1,2},{1,3},{2,4}};
    for (int i = 0; i < 3; i++) {
        int a = pairs[i][0] - 1, b = pairs[i][1] - 1;
        adj[a][b] = adj[b][a] = 1;
    }

    int q[5], head = 0, tail = 0;
    color[0] = 0;
    q[tail++] = 0;
    while (head < tail) {
        int u = q[head++];
        for (int v = 0; v < n; v++) {
            if (!adj[u][v]) continue;
            if (color[v] == -1) { color[v] = 1 - color[u]; q[tail++] = v; }
            else if (color[v] == color[u]) { printf("impossible\\n"); return 0; }
        }
    }
    printf("possible\\n");
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
using namespace std;

bool possibleBipartition(int n, vector<vector<int>>& dislikes) {
    vector<vector<int>> adj(n);
    for (auto& d : dislikes) {
        int a = d[0] - 1, b = d[1] - 1;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    vector<int> color(n, -1);
    for (int s = 0; s < n; s++) {
        if (color[s] != -1) continue;
        color[s] = 0;
        queue<int> q;
        q.push(s);
        while (!q.empty()) {
            int u = q.front(); q.pop();
            for (int v : adj[u]) {
                if (color[v] == -1) { color[v] = 1 - color[u]; q.push(v); }
                else if (color[v] == color[u]) return false;
            }
        }
    }
    return true;
}

int main() {
    vector<vector<int>> dislikes{{1,2},{1,3},{2,4}};
    cout << possibleBipartition(4, dislikes) << '\\n'; // 1
}`,
        },
        steps(raw) { return bipartiteSteps(raw, true); },
      },
    ],
  });
})();
