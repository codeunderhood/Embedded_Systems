/* ============================================================
   DSA Visuals — Dynamic Programming IV
   Wildcards, interleaving, stock transactions, two-walker
   collection, bitmask TSP, digit sums and strange printer.
   ============================================================ */
(function () {
  "use strict";
  const { count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const partsOf = (text) => String(text || "").split("|").map((p) => p.trim());
  const intsOf = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number).filter(Number.isFinite);

  /* ---------------------------------------------------------- */
  V.register({
    id: "wildcard-matching",
    title: "Wildcard Matching",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Match a string against a pattern where ? matches one character and * matches any sequence.",
    input: { label: "String | pattern", default: "adceb | *a*b", parse: "string" },
    approaches: [
      {
        name: "Prefix Match With Star States",
        complexity: "O(string length × pattern length) time",
        idea: [
          "match[i][j] says whether the first i characters match the first j pattern symbols. A normal character and ? consume exactly one character; * can consume none or extend over one more character.",
          "For *, look left (use the star for zero characters) and up (let the star absorb the current character). The table needs only those two predecessors.",
        ],
        problem: [
          "A single greedy star expansion cannot know how much of the string later pattern symbols will need.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <string.h>\\n#include <stdbool.h>\\n\\nint main(void) {\\n    char s[] = \\\"adceb\\\", p[] = \\\"*a*b\\\";\\n    int n = strlen(s), m = strlen(p);\\n    bool dp[6][5] = {{true}};\\n\\n    for (int j = 1; j <= m; j++)\\n        if (p[j-1] == '*') dp[0][j] = dp[0][j-1];\\n\\n    for (int i = 1; i <= n; i++)\\n        for (int j = 1; j <= m; j++) {\\n            if (p[j-1] == '*') dp[i][j] = dp[i][j-1] || dp[i-1][j];\\n            else if (p[j-1] == '?' || p[j-1] == s[i-1]) dp[i][j] = dp[i-1][j-1];\\n        }\\n\\n    printf(\\\"%s\\\\n\\\", dp[n][m] ? \\\"true\\\" : \\\"false\\\"); /* true */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <string>\\n#include <vector>\\nusing namespace std;\\n\\nbool isMatch(string s, string p) {\\n    int n = s.size(), m = p.size();\\n    vector<vector<bool>> dp(n + 1, vector<bool>(m + 1, false));\\n    dp[0][0] = true;\\n    for (int j = 1; j <= m; j++)\\n        if (p[j-1] == '*') dp[0][j] = dp[0][j-1];\\n    for (int i = 1; i <= n; i++)\\n        for (int j = 1; j <= m; j++) {\\n            if (p[j-1] == '*') dp[i][j] = dp[i][j-1] || dp[i-1][j];\\n            else if (p[j-1] == '?' || p[j-1] == s[i-1]) dp[i][j] = dp[i-1][j-1];\\n        }\\n    return dp[n][m];\\n}\\n\\nint main() {\\n    cout << (isMatch(\\\"adceb\\\", \\\"*a*b\\\") ? \\\"true\\\" : \\\"false\\\") << '\\\\n'; // true\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const s = String(parts[0] || "").slice(0, 12);
          const p = String(parts[1] || "").slice(0, 12);
          if (!p) return [{
            title: "Give a string and a pattern",
            tracks: [chips("string", s ? s.split("") : ["—"], "idle")],
            counters: [count("matched", 0)],
            legend: LEG,
            happened: "There is no pattern.",
            why: "Matching needs at least one pattern symbol.",
          }];
          const n = s.length, m = p.length;
          const dp = Array.from({ length: n + 1 }, () => Array(m + 1).fill(false));
          dp[0][0] = true;
          for (let j = 1; j <= m; j++) if (p[j - 1] === "*") dp[0][j] = dp[0][j - 1];
          const steps = [];
          const cells = (curR) => grid(n + 1, m + 1, (i, j) => ({ v: dp[i][j] ? "✓" : "·", state: i === curR ? "read" : i < curR ? "done" : "idle" }));
          steps.push({
            title: `Match "${s}" against "${p}"`,
            kind: "grid", rows: n + 1, cols: m + 1,
            rowHeads: ["ε", ...s.split("")], colHeads: ["ε", ...p.split("")],
            cells: cells(-1),
            counters: [count("string", n), count("pattern", m)],
            legend: LEG,
            happened: "Only the empty string and empty pattern match before any symbols are read.",
            why: "An initial run of stars can also match the empty prefix.",
            codeLine: 5,
          });
          for (let i = 1; i <= n; i++) {
            for (let j = 1; j <= m; j++) {
              if (p[j - 1] === "*") dp[i][j] = dp[i][j - 1] || dp[i - 1][j];
              else if (p[j - 1] === "?" || p[j - 1] === s[i - 1]) dp[i][j] = dp[i - 1][j - 1];
            }
            steps.push({
              title: `String prefix "${s.slice(0, i)}" against every pattern prefix`,
              kind: "grid", rows: n + 1, cols: m + 1,
              rowHeads: ["ε", ...s.split("")], colHeads: ["ε", ...p.split("")],
              cells: cells(i),
              counters: [count("matched prefixes", dp[i].filter(Boolean).length), count("row", i, n)],
              legend: LEG,
              happened: `Character ${s[i - 1]} was compared against each pattern symbol.`,
              why: "A star inherits a match from the left (zero characters) or from above (one more character).",
              codeLine: 12,
            });
          }
          steps.push({
            title: dp[n][m] ? "Answer: the pattern matches" : "Answer: the pattern does not match",
            kind: "grid", rows: n + 1, cols: m + 1,
            rowHeads: ["ε", ...s.split("")], colHeads: ["ε", ...p.split("")],
            cells: grid(n + 1, m + 1, (i, j) => ({ v: dp[i][j] ? "✓" : "·", state: i === n && j === m ? "result" : "done" })),
            counters: [count("matched", dp[n][m] ? 1 : 0), count("cells", (n + 1) * (m + 1))],
            legend: LEG,
            happened: dp[n][m] ? "The bottom-right cell is reachable, so the whole string matches." : "The bottom-right cell was never reached.",
            why: "The final cell checks every character and every pattern symbol together.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "interleaving-string",
    title: "Interleaving String",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Decide whether a third string is an interleaving of the first two while preserving their orders.",
    input: { label: "s1 | s2 | s3", default: "aabcc | dbbca | aadbbcbcac", parse: "string" },
    approaches: [
      {
        name: "Two-Source Prefix Grid",
        complexity: "O(len(s1) × len(s2)) time",
        idea: [
          "A prefix of s3 of length i+j is built from i characters of s1 and j characters of s2. The table records which (i,j) pairs are reachable.",
          "A cell is reachable if the next s3 character came from s1 (left neighbour) or from s2 (upper neighbour). Keeping both source orders is automatic because indices only move forward.",
        ],
        problem: [
          "Choosing locally matching characters from either string can consume a character that a later part of the other string needs.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <string.h>\\n#include <stdbool.h>\\n\\nint main(void) {\\n    char a[] = \\\"aabcc\\\", b[] = \\\"dbbca\\\", c[] = \\\"aadbbcbcac\\\";\\n    int n = strlen(a), m = strlen(b);\\n    if (strlen(c) != n + m) { printf(\\\"false\\\\n\\\"); return 0; }\\n    bool dp[6][6] = {{true}};\\n\\n    for (int i = 1; i <= n; i++) dp[i][0] = dp[i-1][0] && a[i-1] == c[i-1];\\n    for (int j = 1; j <= m; j++) dp[0][j] = dp[0][j-1] && b[j-1] == c[j-1];\\n\\n    for (int i = 1; i <= n; i++)\\n        for (int j = 1; j <= m; j++)\\n            dp[i][j] = (dp[i-1][j] && a[i-1] == c[i+j-1]) ||\\n                       (dp[i][j-1] && b[j-1] == c[i+j-1]);\\n\\n    printf(\\\"%s\\\\n\\\", dp[n][m] ? \\\"true\\\" : \\\"false\\\"); /* true */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <string>\\n#include <vector>\\nusing namespace std;\\n\\nbool isInterleave(string a, string b, string c) {\\n    int n = a.size(), m = b.size();\\n    if (c.size() != n + m) return false;\\n    vector<vector<bool>> dp(n + 1, vector<bool>(m + 1, false));\\n    dp[0][0] = true;\\n    for (int i = 1; i <= n; i++) dp[i][0] = dp[i-1][0] && a[i-1] == c[i-1];\\n    for (int j = 1; j <= m; j++) dp[0][j] = dp[0][j-1] && b[j-1] == c[j-1];\\n    for (int i = 1; i <= n; i++)\\n        for (int j = 1; j <= m; j++)\\n            dp[i][j] = (dp[i-1][j] && a[i-1] == c[i+j-1]) ||\\n                       (dp[i][j-1] && b[j-1] == c[i+j-1]);\\n    return dp[n][m];\\n}\\n\\nint main() {\\n    cout << (isInterleave(\\\"aabcc\\\", \\\"dbbca\\\", \\\"aadbbcbcac\\\") ? \\\"true\\\" : \\\"false\\\") << '\\\\n'; // true\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const a = String(parts[0] || "").slice(0, 10);
          const b = String(parts[1] || "").slice(0, 10);
          const c = String(parts[2] || "").slice(0, 20);
          const n = a.length, m = b.length;
          if (c.length !== n + m) return [{
            title: "The target length does not match",
            tracks: [chips("s1", a ? a.split("") : ["—"], "idle"), chips("s2", b ? b.split("") : ["—"], "idle")],
            counters: [count("target length", c.length), count("needed", n + m)],
            legend: LEG,
            happened: `The target has ${c.length} characters but the sources supply ${n + m}.`,
            why: "An interleaving must use every character exactly once.",
          }];
          const dp = Array.from({ length: n + 1 }, () => Array(m + 1).fill(false));
          dp[0][0] = true;
          for (let i = 1; i <= n; i++) dp[i][0] = dp[i - 1][0] && a[i - 1] === c[i - 1];
          for (let j = 1; j <= m; j++) dp[0][j] = dp[0][j - 1] && b[j - 1] === c[j - 1];
          const steps = [];
          const cells = (curR) => grid(n + 1, m + 1, (i, j) => ({ v: dp[i][j] ? "✓" : "·", state: i === curR ? "read" : i < curR ? "done" : "idle" }));
          steps.push({
            title: `Interleave "${a}" and "${b}" into "${c}"`,
            kind: "grid", rows: n + 1, cols: m + 1,
            rowHeads: ["0", ...a.split("").map((ch, i) => `${i + 1}:${ch}`)],
            colHeads: ["0", ...b.split("").map((ch, j) => `${j + 1}:${ch}`)],
            cells: cells(-1),
            counters: [count("s1", n), count("s2", m)],
            legend: LEG,
            happened: "The empty prefix of the target is built from empty prefixes of both sources.",
            why: "Table coordinates count how many characters have been consumed from each source.",
            codeLine: 4,
          });
          for (let i = 1; i <= n; i++) {
            for (let j = 1; j <= m; j++) {
              dp[i][j] = (dp[i - 1][j] && a[i - 1] === c[i + j - 1]) || (dp[i][j - 1] && b[j - 1] === c[i + j - 1]);
            }
            steps.push({
              title: `Consume ${i} character${i === 1 ? "" : "s"} from s1`,
              kind: "grid", rows: n + 1, cols: m + 1,
              rowHeads: ["0", ...a.split("").map((ch, k) => `${k + 1}:${ch}`)],
              colHeads: ["0", ...b.split("").map((ch, k) => `${k + 1}:${ch}`)],
              cells: cells(i),
              counters: [count("reachable pairs", dp[i].filter(Boolean).length), count("row", i, n)],
              legend: LEG,
              happened: `Row ${i} checks whether the next target character can come from either source.`,
              why: "A cell is reachable only from a reachable neighbour that supplies the matching character.",
              codeLine: 11,
            });
          }
          steps.push({
            title: dp[n][m] ? "Answer: the target is an interleaving" : "Answer: the target is not an interleaving",
            kind: "grid", rows: n + 1, cols: m + 1,
            rowHeads: ["0", ...a.split("").map((ch, k) => `${k + 1}:${ch}`)],
            colHeads: ["0", ...b.split("").map((ch, k) => `${k + 1}:${ch}`)],
            cells: grid(n + 1, m + 1, (i, j) => ({ v: dp[i][j] ? "✓" : "·", state: i === n && j === m ? "result" : "done" })),
            counters: [count("interleaved", dp[n][m] ? 1 : 0), count("target length", c.length)],
            legend: LEG,
            happened: dp[n][m] ? "Every character of the target was consumed while preserving both source orders." : "The final pair of consumed counts was never reached.",
            why: "The bottom-right cell means all characters of both sources were used in order.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "best-time-to-buy-and-sell-stock-iv",
    title: "Best Time to Buy and Sell Stock IV",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Maximise profit with at most k buy-sell transactions.",
    input: { label: "Prices | k", default: "3,2,6,5,0,3 | 2", parse: "string" },
    approaches: [
      {
        name: "Profit by Transaction Count",
        complexity: "O(k × days²) time",
        idea: [
          "profit[t][d] is the best profit using at most t transactions through day d. Skipping day d keeps profit[t][d−1].",
          "Selling on day d after buying on an earlier day j gives prices[d] − prices[j] plus the best profit with t−1 transactions up to j. Taking the maximum over j finds the best earlier buy.",
        ],
        problem: [
          "Choosing every local minimum and maximum can exceed the transaction limit, and a greedy pairing may miss a better split of trades.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int p[] = {3,2,6,5,0,3}, n = 6, k = 2;\\n    int dp[3][6] = {0};\\n\\n    for (int t = 1; t <= k; t++)\\n        for (int d = 1; d < n; d++) {\\n            dp[t][d] = dp[t][d-1];\\n            for (int j = 0; j < d; j++)\\n                if (p[d] > p[j] && p[d] - p[j] + dp[t-1][j] > dp[t][d])\\n                    dp[t][d] = p[d] - p[j] + dp[t-1][j];\\n        }\\n\\n    printf(\\\"%d\\\\n\\\", dp[k][n-1]); /* 7 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint maxProfit(int k, vector<int>& p) {\\n    int n = p.size();\\n    vector<vector<int>> dp(k + 1, vector<int>(n, 0));\\n    for (int t = 1; t <= k; t++)\\n        for (int d = 1; d < n; d++) {\\n            dp[t][d] = dp[t][d-1];\\n            for (int j = 0; j < d; j++)\\n                if (p[d] > p[j]) dp[t][d] = max(dp[t][d], p[d] - p[j] + dp[t-1][j]);\\n        }\\n    return dp[k][n-1];\\n}\\n\\nint main() {\\n    vector<int> p{3,2,6,5,0,3};\\n    cout << maxProfit(2, p) << '\\\\n'; // 7\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const prices = intsOf(parts[0]).filter((x) => x >= 0).slice(0, 10);
          const k = Math.min(4, Math.max(1, parseInt(parts[1], 10) || 1));
          if (!prices.length) return [{
            title: "Give a price list and k",
            tracks: [chips("prices", ["—"], "idle")],
            counters: [count("profit", 0)],
            legend: LEG,
            happened: "There are no prices.",
            why: "Trading needs at least one day.",
          }];
          const n = prices.length;
          const dp = Array.from({ length: k + 1 }, () => Array(n).fill(0));
          const steps = [];
          const cells = (curT) => grid(k + 1, n, (t, d) => ({
            v: dp[t][d],
            state: t === curT ? "read" : t < curT ? "done" : "idle",
          }));
          steps.push({
            title: `${n} days, at most ${k} transaction${k === 1 ? "" : "s"}`,
            kind: "grid", rows: k + 1, cols: n,
            rowHeads: Array.from({ length: k + 1 }, (_, t) => (t === 0 ? "0 trades" : `${t} trade${t === 1 ? "" : "s"}`)),
            colHeads: prices.map((p, d) => `${d}:${p}`),
            cells: cells(0),
            counters: [count("profit", 0), count("days", n)],
            legend: LEG,
            happened: "With zero transactions the profit is zero on every day.",
            why: "The table builds answers from fewer transactions to more.",
            codeLine: 4,
          });
          for (let t = 1; t <= k; t++) {
            for (let d = 1; d < n; d++) {
              dp[t][d] = dp[t][d - 1];
              for (let j = 0; j < d; j++) {
                if (prices[d] > prices[j]) dp[t][d] = Math.max(dp[t][d], prices[d] - prices[j] + dp[t - 1][j]);
              }
            }
            steps.push({
              title: `${t} trade${t === 1 ? "" : "s"}: best profit ${dp[t][n - 1]}`,
              kind: "grid", rows: k + 1, cols: n,
              rowHeads: Array.from({ length: k + 1 }, (_, r) => (r === 0 ? "0 trades" : `${r} trade${r === 1 ? "" : "s"}`)),
              colHeads: prices.map((p, d) => `${d}:${p}`),
              cells: cells(t),
              counters: [count("profit", dp[t][n - 1]), count("trades used", t, k)],
              legend: LEG,
              happened: `Row ${t} either skips the day or sells a buy made on an earlier day.`,
              why: "The earlier buy adds the best profit from one fewer trade before that day.",
              codeLine: 10,
            });
          }
          let best = dp[k][n - 1];
          const trades = [];
          let t = k, d = n - 1;
          while (t > 0 && d > 0) {
            if (dp[t][d] === dp[t][d - 1]) { d--; continue; }
            let found = false;
            for (let j = d - 1; j >= 0; j--) {
              if (prices[d] > prices[j] && dp[t][d] === prices[d] - prices[j] + dp[t - 1][j]) {
                trades.unshift([j, d]);
                t--; d = j; found = true; break;
              }
            }
            if (!found) break;
          }
          steps.push({
            title: `Answer: profit ${best}`,
            kind: "grid", rows: k + 1, cols: n,
            rowHeads: Array.from({ length: k + 1 }, (_, r) => (r === 0 ? "0 trades" : `${r} trade${r === 1 ? "" : "s"}`)),
            colHeads: prices.map((p, dd) => `${dd}:${p}`),
            cells: grid(k + 1, n, (r, dd) => ({ v: dp[r][dd], state: r === k && dd === n - 1 ? "result" : "done" })),
            counters: [count("profit", best), count("trades", trades.length)],
            legend: LEG,
            happened: trades.length ? `Trades used days ${trades.map(([b, s]) => `${b}→${s}`).join(", ")}.` : "No profitable trade fits the limit.",
            why: "Backtracking along equal profit values reconstructs a sequence of transactions achieving the optimum.",
            codeLine: 14,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "cherry-pickup",
    title: "Cherry Pickup",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Send two walkers from the top-left to the bottom-right and collect the most cherries.",
    input: { label: "Grid rows of -1, 0, 1 separated by |", default: "0,1,-1 | 1,0,-1 | 1,1,1", parse: "string" },
    approaches: [
      {
        name: "Two Walkers on the Same Diagonal",
        complexity: "O(n³) time",
        idea: [
          "Model both trips as two walkers moving simultaneously. After s steps both are on the same anti-diagonal, so their rows determine their columns.",
          "dp[r1][r2] is the best cherries collected when walker one is in row r1 and walker two in row r2. A cherry is counted once when both occupy the same cell. Cells with thorns are excluded.",
        ],
        problem: [
          "Optimising the forward trip alone can consume cherries that the return trip needs, so the two routes must be planned together.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int g[3][3] = {{0,1,-1},{1,0,-1},{1,1,1}};\\n    int n = 3, dp[3][3] = {{0}}, ndp[3][3];\\n    dp[0][0] = g[0][0];\\n\\n    for (int s = 1; s <= 2*n - 2; s++) {\\n        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) ndp[i][j] = -1 << 30;\\n        for (int r1 = 0; r1 < n; r1++) {\\n            int c1 = s - r1; if (c1 < 0 || c1 >= n || g[r1][c1] < 0) continue;\\n            for (int r2 = 0; r2 < n; r2++) {\\n                int c2 = s - r2; if (c2 < 0 || c2 >= n || g[r2][c2] < 0) continue;\\n                int gain = g[r1][c1] + (r1 != r2 ? g[r2][c2] : 0);\\n                for (int a = r1 - 1; a <= r1; a++)\\n                    for (int b = r2 - 1; b <= r2; b++)\\n                        if (a >= 0 && b >= 0 && dp[a][b] >= 0 && dp[a][b] + gain > ndp[r1][r2]) ndp[r1][r2] = dp[a][b] + gain;\\n            }\\n        }\\n        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) dp[i][j] = ndp[i][j];\\n    }\\n\\n    printf(\\\"%d\\\\n\\\", dp[n-1][n-1]); /* 5 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint cherryPickup(vector<vector<int>>& g) {\\n    int n = g.size();\\n    vector<vector<int>> dp(n, vector<int>(n, -1));\\n    dp[0][0] = g[0][0];\\n    for (int s = 1; s <= 2*n - 2; s++) {\\n        vector<vector<int>> ndp(n, vector<int>(n, -1));\\n        for (int r1 = 0; r1 < n; r1++) {\\n            int c1 = s - r1; if (c1 < 0 || c1 >= n || g[r1][c1] < 0) continue;\\n            for (int r2 = 0; r2 < n; r2++) {\\n                int c2 = s - r2; if (c2 < 0 || c2 >= n || g[r2][c2] < 0) continue;\\n                int gain = g[r1][c1] + (r1 != r2 ? g[r2][c2] : 0);\\n                for (int a = r1 - 1; a <= r1; a++)\\n                    for (int b = r2 - 1; b <= r2; b++)\\n                        if (a >= 0 && b >= 0 && dp[a][b] >= 0) ndp[r1][r2] = max(ndp[r1][r2], dp[a][b] + gain);\\n            }\\n        }\\n        dp = ndp;\\n    }\\n    return max(0, dp[n-1][n-1]);\\n}\\n\\nint main() {\\n    vector<vector<int>> g{{0,1,-1},{1,0,-1},{1,1,1}};\\n    cout << cherryPickup(g) << '\\\\n'; // 5\\n}`,
        },
        steps(text) {
          const rows = partsOf(text).filter(Boolean).map((r) => r.split(",").map(Number).filter(Number.isFinite));
          const n = Math.min(6, rows.length);
          if (!n) return [{
            title: "Give a grid",
            tracks: [chips("grid", ["—"], "idle")],
            counters: [count("cherries", 0)],
            legend: LEG,
            happened: "There is no grid.",
            why: "The walkers need cells to move through.",
          }];
          const g = Array.from({ length: n }, (_, r) => Array.from({ length: n }, (_, c) => (Number.isFinite(rows[r][c]) ? rows[r][c] : -1)));
          if (g[0][0] < 0 || g[n - 1][n - 1] < 0) return [{
            title: "A walker starts or ends on thorns",
            tracks: [chips("grid", ["blocked"], "bad")],
            counters: [count("cherries", 0)],
            legend: LEG,
            happened: "The route is impossible when an endpoint is blocked.",
            why: "Both trips must start and finish on open cells.",
          }];
          let dp = Array.from({ length: n }, () => Array(n).fill(-Infinity));
          dp[0][0] = g[0][0];
          const steps = [];
          const gridCells = (positions, step) => grid(n, n, (r, c) => {
            const here = positions.some(([pr, pc]) => pr === r && pc === c);
            return {
              v: g[r][c] < 0 ? "×" : g[r][c],
              state: g[r][c] < 0 ? "bad" : here ? "active" : r + c <= step ? "done" : "idle",
            };
          });
          steps.push({
            title: "Both walkers start at the top-left",
            kind: "grid", rows: n, cols: n, cells: gridCells([[0, 0]], 0),
            counters: [count("cherries", g[0][0]), count("step", 0)],
            legend: LEG,
            happened: `The shared starting cherry is counted once: ${g[0][0]}.`,
            why: "Planning both trips at once avoids counting the same cherry twice.",
            codeLine: 5,
          });
          for (let s = 1; s <= 2 * n - 2; s++) {
            const ndp = Array.from({ length: n }, () => Array(n).fill(-Infinity));
            const active = [];
            for (let r1 = 0; r1 < n; r1++) {
              const c1 = s - r1;
              if (c1 < 0 || c1 >= n || g[r1][c1] < 0) continue;
              for (let r2 = 0; r2 < n; r2++) {
                const c2 = s - r2;
                if (c2 < 0 || c2 >= n || g[r2][c2] < 0) continue;
                const gain = g[r1][c1] + (r1 !== r2 ? g[r2][c2] : 0);
                for (let a = r1 - 1; a <= r1; a++) {
                  for (let b = r2 - 1; b <= r2; b++) {
                    if (a >= 0 && b >= 0 && Number.isFinite(dp[a][b])) {
                      ndp[r1][r2] = Math.max(ndp[r1][r2], dp[a][b] + gain);
                    }
                  }
                }
                if (Number.isFinite(ndp[r1][r2])) active.push([r1, c1], [r2, c2]);
              }
            }
            dp = ndp;
            const uniq = [];
            active.forEach(([r, c]) => { if (!uniq.some(([a, b]) => a === r && b === c)) uniq.push([r, c]); });
            const best = Math.max(...dp.flat().filter(Number.isFinite), -Infinity);
            steps.push({
              title: `Diagonal ${s}: best collected ${best === -Infinity ? "none" : best}`,
              kind: "grid", rows: n, cols: n, cells: gridCells(uniq, s),
              counters: [count("cherries", best === -Infinity ? 0 : best), count("step", s, 2 * n - 2)],
              legend: LEG,
              happened: `Both walkers advance one cell; overlapping cherries count once, and thorns are skipped.`,
              why: "The two rows at step s determine both columns, so a 2D table is enough for two walkers.",
              codeLine: 12,
            });
          }
          const ans = dp[n - 1][n - 1];
          steps.push({
            title: Number.isFinite(ans) ? `Answer: ${ans} cherries` : "Answer: no valid pair of routes",
            kind: "grid", rows: n, cols: n,
            cells: grid(n, n, (r, c) => ({ v: g[r][c] < 0 ? "×" : g[r][c], state: g[r][c] < 0 ? "bad" : r === n - 1 && c === n - 1 ? "result" : "done" })),
            counters: [count("cherries", Number.isFinite(ans) ? ans : 0), count("cells", n * n)],
            legend: LEG,
            happened: Number.isFinite(ans) ? `Both walkers finish together with ${ans} cherries.` : "No pair of routes reaches the corner.",
            why: "The final table entry represents both walkers at the destination.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "traveling-salesperson-with-bitmask-dp",
    title: "Traveling Salesperson with Bitmask DP",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Find the cheapest tour that visits every city once and returns to the start.",
    input: { label: "Distance matrix rows separated by |", default: "0,10,15,20 | 10,0,35,25 | 15,35,0,30 | 20,25,30,0", parse: "string" },
    approaches: [
      {
        name: "Subsets Ending at a City",
        complexity: "O(2ⁿ × n²) time",
        idea: [
          "A bitmask records which cities have been visited, and dp[mask][i] is the cheapest route that visits exactly mask and ends at city i.",
          "Extending a route with an unvisited city j costs dp[mask][i] + distance[i][j]. Finally, add the edge from the last city back to city 0.",
        ],
        problem: [
          "Trying all permutations is factorial; many permutations share the same visited set and endpoint.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int d[4][4] = {{0,10,15,20},{10,0,35,25},{15,35,0,30},{20,25,30,0}};\\n    int n = 4, full = 1 << n;\\n    int dp[16][4];\\n    for (int m = 0; m < full; m++) for (int i = 0; i < n; i++) dp[m][i] = 1 << 30;\\n    dp[1][0] = 0;\\n\\n    for (int m = 1; m < full; m++)\\n        for (int i = 0; i < n; i++) if ((m & (1 << i)) && dp[m][i] < (1 << 30))\\n            for (int j = 0; j < n; j++) if (!(m & (1 << j))) {\\n                int nm = m | (1 << j), cost = dp[m][i] + d[i][j];\\n                if (cost < dp[nm][j]) dp[nm][j] = cost;\\n            }\\n\\n    int best = 1 << 30;\\n    for (int i = 1; i < n; i++) if (dp[full-1][i] + d[i][0] < best) best = dp[full-1][i] + d[i][0];\\n    printf(\\\"%d\\\\n\\\", best); /* 80 */\\n    return 0;\\n}`,
          cpp: `#include <algorithm>\\n#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint tsp(vector<vector<int>>& d) {\\n    int n = d.size(), full = 1 << n;\\n    vector<vector<int>> dp(full, vector<int>(n, 1e9));\\n    dp[1][0] = 0;\\n    for (int mask = 1; mask < full; mask++)\\n        for (int i = 0; i < n; i++) if ((mask & (1 << i)) && dp[mask][i] < 1e9)\\n            for (int j = 0; j < n; j++) if (!(mask & (1 << j)))\\n                dp[mask | (1 << j)][j] = min(dp[mask | (1 << j)][j], dp[mask][i] + d[i][j]);\\n    int best = 1e9;\\n    for (int i = 1; i < n; i++) best = min(best, dp[full-1][i] + d[i][0]);\\n    return best;\\n}\\n\\nint main() {\\n    vector<vector<int>> d{{0,10,15,20},{10,0,35,25},{15,35,0,30},{20,25,30,0}};\\n    cout << tsp(d) << '\\\\n'; // 80\\n}`,
        },
        steps(text) {
          const rows = partsOf(text).filter(Boolean).map((r) => r.split(",").map(Number).filter(Number.isFinite));
          const n = Math.min(4, rows.length);
          if (n < 2) return [{
            title: "Give at least two cities",
            tracks: [chips("cities", ["—"], "idle")],
            counters: [count("cost", 0)],
            legend: LEG,
            happened: "There is no tour to build.",
            why: "A tour needs at least two cities.",
          }];
          const d = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (Number.isFinite(rows[i][j]) ? rows[i][j] : 0)));
          const full = 1 << n;
          const INF = Infinity;
          const dp = Array.from({ length: full }, () => Array(n).fill(INF));
          dp[1][0] = 0;
          const steps = [];
          const maskText = (m) => `{${Array.from({ length: n }, (_, i) => (m & (1 << i) ? i : null)).filter((x) => x !== null).join(",")}}`;
          const cells = (curM) => grid(full, n, (m, i) => ({
            v: !Number.isFinite(dp[m][i]) ? "∞" : dp[m][i],
            state: m === curM ? "read" : m < curM ? "done" : "idle",
          }));
          steps.push({
            title: `${n} cities; start and end at city 0`,
            kind: "grid", rows: full, cols: n,
            rowHeads: Array.from({ length: full }, (_, m) => maskText(m)),
            colHeads: Array.from({ length: n }, (_, i) => `city ${i}`),
            cells: cells(1),
            counters: [count("cities", n), count("cost", 0)],
            legend: LEG,
            happened: "Only the singleton set {0} is reachable at zero cost.",
            why: "Every tour starts at city 0 before visiting anything else.",
            codeLine: 5,
          });
          for (let m = 1; m < full; m++) {
            for (let i = 0; i < n; i++) {
              if (!(m & (1 << i)) || !Number.isFinite(dp[m][i])) continue;
              for (let j = 0; j < n; j++) {
                if (m & (1 << j)) continue;
                const nm = m | (1 << j);
                const cand = dp[m][i] + d[i][j];
                if (cand < dp[nm][j]) dp[nm][j] = cand;
              }
            }
            if (m > 1) {
              steps.push({
                title: `Visited ${maskText(m)}: extend with any unvisited city`,
                kind: "grid", rows: full, cols: n,
                rowHeads: Array.from({ length: full }, (_, mm) => maskText(mm)),
                colHeads: Array.from({ length: n }, (_, i) => `city ${i}`),
                cells: cells(m),
                counters: [count("reachable states", dp[m].filter(Number.isFinite).length), count("mask", m, full - 1)],
                legend: LEG,
                happened: `Each reachable endpoint in ${maskText(m)} was extended to every unvisited city.`,
                why: "The mask remembers the visited set, and the endpoint column remembers where the route currently stands.",
                codeLine: 10,
              });
            }
          }
          let best = INF;
          for (let i = 1; i < n; i++) best = Math.min(best, dp[full - 1][i] + d[i][0]);
          steps.push({
            title: `Answer: cheapest tour ${best}`,
            kind: "grid", rows: full, cols: n,
            rowHeads: Array.from({ length: full }, (_, m) => maskText(m)),
            colHeads: Array.from({ length: n }, (_, i) => `city ${i}`),
            cells: grid(full, n, (m, i) => ({ v: !Number.isFinite(dp[m][i]) ? "∞" : dp[m][i], state: m === full - 1 ? "result" : "done" })),
            counters: [count("cost", Number.isFinite(best) ? best : 0), count("cities", n)],
            legend: LEG,
            happened: `Returning to city 0 adds the final edge, giving ${best}.`,
            why: "The full mask has visited every city; closing the cycle at city 0 completes the tour.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "digit-sum-counting",
    title: "Digit Sum Counting",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Count numbers from 0 to n whose digits add up to a chosen sum.",
    input: { label: "n | digit sum", default: "20 | 2", parse: "string" },
    approaches: [
      {
        name: "Digit DP on Suffix Counts",
        complexity: "O(digits × sum × 10) time",
        idea: [
          "suffix[pos][sum] counts the digit strings of length len−pos, including leading zeros, whose digits add to sum. It is filled from right to left.",
          "To stay at or below n, scan its digits from the left. At each position, every smaller digit branches into a suffix count; then continue along the exact digit of n. This counts all numbers up to n without enumerating them.",
        ],
        problem: [
          "A plain range loop counts digit sums one number at a time, which is too slow for large n.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <string.h>\\n\\nint main(void) {\\n    char n[] = \\\"20\\\";\\n    int L = strlen(n), target = 2;\\n    int ways[8][32] = {0};\\n    ways[L][0] = 1;\\n\\n    for (int pos = L - 1; pos >= 0; pos--)\\n        for (int s = 0; s <= target; s++)\\n            for (int d = 0; d <= 9; d++)\\n                if (s >= d) ways[pos][s] += ways[pos+1][s-d];\\n\\n    int ans = 0, used = 0;\\n    for (int pos = 0; pos < L; pos++) {\\n        int lim = n[pos] - '0';\\n        for (int d = 0; d < lim; d++)\\n            if (used + d <= target) ans += ways[pos+1][target - used - d];\\n        used += lim;\\n        if (used > target) break;\\n    }\\n    if (used == target) ans++;\\n\\n    printf(\\\"%d\\\\n\\\", ans); /* 3 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <string>\\n#include <vector>\\nusing namespace std;\\n\\nint countDigitSum(int n, int target) {\\n    string s = to_string(n);\\n    int L = s.size();\\n    vector<vector<int>> ways(L + 1, vector<int>(target + 1, 0));\\n    ways[L][0] = 1;\\n    for (int pos = L - 1; pos >= 0; pos--)\\n        for (int sum = 0; sum <= target; sum++)\\n            for (int d = 0; d <= 9 && d <= sum; d++)\\n                ways[pos][sum] += ways[pos + 1][sum - d];\\n    int ans = 0, used = 0;\\n    for (int pos = 0; pos < L; pos++) {\\n        int lim = s[pos] - '0';\\n        for (int d = 0; d < lim; d++)\\n            if (used + d <= target) ans += ways[pos + 1][target - used - d];\\n        used += lim;\\n        if (used > target) break;\\n    }\\n    if (used == target) ans++;\\n    return ans;\\n}\\n\\nint main() {\\n    cout << countDigitSum(20, 2) << '\\\\n'; // 3\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const n = Math.max(0, Math.min(9999, parseInt(parts[0], 10) || 0));
          const target = Math.max(0, Math.min(20, parseInt(parts[1], 10) || 0));
          const s = String(n);
          const L = s.length;
          const ways = Array.from({ length: L + 1 }, () => Array(target + 1).fill(0));
          ways[L][0] = 1;
          for (let pos = L - 1; pos >= 0; pos--) {
            for (let sum = 0; sum <= target; sum++) {
              for (let d = 0; d <= 9 && d <= sum; d++) ways[pos][sum] += ways[pos + 1][sum - d];
            }
          }
          const steps = [];
          const cells = (curP) => grid(L + 1, target + 1, (pos, sum) => ({
            v: ways[pos][sum],
            state: pos === curP ? "read" : pos > curP ? "done" : "idle",
          }));
          steps.push({
            title: `Count numbers up to ${n} with digit sum ${target}`,
            tracks: [chips("digits", s.split(""), "compare"), chips("suffix sums", ways.map((row) => row.reduce((a, b) => a + b, 0)), "idle")],
            counters: [count("limit", n), count("target sum", target)],
            legend: LEG,
            happened: `Numbers are limited to ${L} digits, with leading zeros allowed inside suffixes.`,
            why: "Counting suffixes first avoids enumerating each number individually.",
            codeLine: 4,
          });
          steps.push({
            title: "A zero-length suffix can only sum to zero",
            kind: "grid", rows: L + 1, cols: target + 1,
            rowHeads: Array.from({ length: L + 1 }, (_, p) => `pos ${p}`),
            colHeads: Array.from({ length: target + 1 }, (_, sum) => `Σ${sum}`),
            cells: cells(L),
            counters: [count("suffix ways", ways[L][0]), count("target sum", target)],
            legend: LEG,
            happened: "ways[L][0] = 1: there is exactly one empty suffix.",
            why: "All longer suffixes add one digit on top of a shorter suffix.",
            codeLine: 5,
          });
          for (let pos = L - 1; pos >= 0; pos--) {
            steps.push({
              title: `Suffix starting at position ${pos}: ${ways[pos][target]} ways to sum ${target}`,
              kind: "grid", rows: L + 1, cols: target + 1,
              rowHeads: Array.from({ length: L + 1 }, (_, p) => `pos ${p}`),
              colHeads: Array.from({ length: target + 1 }, (_, sum) => `Σ${sum}`),
              cells: cells(pos),
              counters: [count("suffix ways", ways[pos][target]), count("position", L - pos, L)],
              legend: LEG,
              happened: `Row ${pos} adds every digit 0–9 to the already-known suffix row ${pos + 1}.`,
              why: "The first digit can be anything; the remaining positions are counted by the next row.",
              codeLine: 9,
            });
          }
          let ans = 0, used = 0, tightDone = false;
          for (let pos = 0; pos < L; pos++) {
            const lim = Number(s[pos]);
            for (let d = 0; d < lim; d++) {
              if (used + d <= target) ans += ways[pos + 1][target - used - d];
            }
            used += lim;
            if (used > target) { tightDone = true; break; }
          }
          if (!tightDone && used === target) ans++;
          steps.push({
            title: `Answer: ${ans} number${ans === 1 ? "" : "s"} with digit sum ${target}`,
            tracks: [chips("digits", s.split(""), "done"), chips("suffix sums", ways.map((row) => row.reduce((a, b) => a + b, 0)), "result")],
            counters: [count("matches", ans), count("limit", n)],
            legend: LEG,
            happened: `Scanning ${s} and taking every smaller digit at each position counted ${ans} numbers.`,
            why: "Each branch stayed strictly below n at its first smaller digit, so no number was counted twice.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "strange-printer",
    title: "Strange Printer",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Find the fewest printer turns needed to print a string, where each turn prints one repeated character.",
    input: { label: "String", default: "aba", parse: "string" },
    approaches: [
      {
        name: "Interval Turns",
        complexity: "O(n³) time",
        idea: [
          "turns[i][j] is the minimum number of turns to print s[i..j]. Printing s[i] alone costs one turn plus the rest of the interval.",
          "If s[i] equals some later s[k], the first turn can extend to cover that position, splitting the interval into two smaller parts without an extra turn for s[i].",
        ],
        problem: [
          "Printing left to right and starting a new turn for every run ignores that one turn can print matching characters separated by other letters.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <string.h>\\n\\nint main(void) {\\n    char s[] = \\\"aba\\\";\\n    int n = strlen(s);\\n    int dp[8][8] = {0};\\n\\n    for (int i = 0; i < n; i++) dp[i][i] = 1;\\n    for (int len = 2; len <= n; len++)\\n        for (int i = 0; i + len <= n; i++) {\\n            int j = i + len - 1;\\n            dp[i][j] = dp[i+1][j] + 1;\\n            for (int k = i + 1; k <= j; k++)\\n                if (s[k] == s[i]) {\\n                    int cand = dp[i+1][k-1] + dp[k][j];\\n                    if (cand < dp[i][j]) dp[i][j] = cand;\\n                }\\n        }\\n\\n    printf(\\\"%d\\\\n\\\", dp[0][n-1]); /* 2 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <string>\\n#include <vector>\\nusing namespace std;\\n\\nint strangePrinter(string s) {\\n    int n = s.size();\\n    vector<vector<int>> dp(n, vector<int>(n, 0));\\n    for (int i = 0; i < n; i++) dp[i][i] = 1;\\n    for (int len = 2; len <= n; len++)\\n        for (int i = 0; i + len <= n; i++) {\\n            int j = i + len - 1;\\n            dp[i][j] = dp[i+1][j] + 1;\\n            for (int k = i + 1; k <= j; k++)\\n                if (s[k] == s[i]) dp[i][j] = min(dp[i][j], dp[i+1][k-1] + dp[k][j]);\\n        }\\n    return dp[0][n-1];\\n}\\n\\nint main() {\\n    cout << strangePrinter(\\\"aba\\\") << '\\\\n'; // 2\\n}`,
        },
        steps(text) {
          const s = String(text || "").replace(/\s/g, "").slice(0, 10);
          if (!s) return [{
            title: "Give a string",
            tracks: [chips("string", ["—"], "idle")],
            counters: [count("turns", 0)],
            legend: LEG,
            happened: "There is nothing to print.",
            why: "The printer needs at least one character.",
          }];
          const n = s.length;
          const dp = Array.from({ length: n }, () => Array(n).fill(0));
          for (let i = 0; i < n; i++) dp[i][i] = 1;
          const steps = [];
          const cells = (len) => grid(n, n, (i, j) => {
            if (j < i) return { v: "·", state: "dim" };
            const width = j - i + 1;
            return { v: dp[i][j], state: width === len ? "read" : width < len ? "done" : "idle" };
          });
          steps.push({
            title: `Print "${s}" with one repeated character per turn`,
            kind: "grid", rows: n, cols: n,
            rowHeads: s.split(""), colHeads: s.split(""),
            cells: cells(1),
            counters: [count("characters", n), count("turns", 0)],
            legend: LEG,
            happened: "Every single character needs one turn on its own.",
            why: "The diagonal is the base case for one-character intervals.",
            codeLine: 4,
          });
          for (let len = 2; len <= n; len++) {
            for (let i = 0; i + len <= n; i++) {
              const j = i + len - 1;
              dp[i][j] = dp[i + 1][j] + 1;
              for (let k = i + 1; k <= j; k++) {
                if (s[k] === s[i]) dp[i][j] = Math.min(dp[i][j], dp[i + 1][k - 1] + dp[k][j]);
              }
            }
            steps.push({
              title: `Intervals of ${len} characters`,
              kind: "grid", rows: n, cols: n,
              rowHeads: s.split(""), colHeads: s.split(""),
              cells: cells(len),
              counters: [count("turns", dp[0][n - 1] || "—"), count("width", len, n)],
              legend: LEG,
              happened: `Matching endpoints share a turn, splitting the interval around the match.`,
              why: "A turn can print the same character at several separated positions.",
              codeLine: 10,
            });
          }
          steps.push({
            title: `Answer: ${dp[0][n - 1]} printer turn${dp[0][n - 1] === 1 ? "" : "s"}`,
            kind: "grid", rows: n, cols: n,
            rowHeads: s.split(""), colHeads: s.split(""),
            cells: grid(n, n, (i, j) => ({ v: j < i ? "·" : dp[i][j], state: i === 0 && j === n - 1 ? "result" : "done" })),
            counters: [count("turns", dp[0][n - 1]), count("characters", n)],
            legend: LEG,
            happened: `"${s}" can be printed in ${dp[0][n - 1]} turn${dp[0][n - 1] === 1 ? "" : "s"}.`,
            why: "The full interval chooses the best sharing of turns for matching characters.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });
})();
