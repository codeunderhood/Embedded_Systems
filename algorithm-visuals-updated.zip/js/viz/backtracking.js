/* ============================================================
   DSA Visuals — Backtracking
   Six visualisations that make the "try a choice, then undo it"
   rhythm visible: subsets, subsets with duplicates, permutations,
   unique permutations, combinations and combination sum.
   All text and C / C++ listings are original.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  /* A guard so a runaway input cannot ask for millions of steps. */
  const MAX_STEPS = 900;

  /* ---------------- small shared helpers ---------------- */
  const fmtSet = (a) => (a.length ? a.join(" ") : "∅");
  const factorial = (n) => { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; };
  const pow2 = (n) => (n <= 20 ? Math.pow(2, n) : "2^n");
  function chooseCount(n, k) {
    if (k < 0 || k > n) return 0;
    k = Math.min(k, n - k);
    let r = 1;
    for (let i = 1; i <= k; i++) r = (r * (n - k + i)) / i;
    return Math.round(r);
  }
  /* 0-based line number of the first line containing needle. */
  function lineOf(src, needle) {
    const lines = src.split("\n");
    for (let i = 0; i < lines.length; i++) if (lines[i].indexOf(needle) !== -1) return i;
    return 0;
  }
  /* Split tokens like "1, 2, 3 k=2" into numbers + named numbers. */
  function parseKeyed(tokens, keys) {
    let s = " " + tokens.join(" ") + " ";
    const found = {};
    for (const key of keys) {
      const re = new RegExp(key + "\\s*=\\s*(-?\\d+)", "i");
      const m = re.exec(s);
      if (m) { found[key] = parseInt(m[1], 10); s = s.replace(re, " "); }
    }
    const nums = s.split(/[\s,]+/).filter(Boolean).map(Number).filter((x) => Number.isFinite(x));
    return { nums, found };
  }
  /* Classic next-permutation on a small JS array (for the second approach). */
  function nextPermutation(a) {
    let i = a.length - 2;
    while (i >= 0 && a[i] >= a[i + 1]) i--;
    if (i < 0) return false;
    let j = a.length - 1;
    while (a[j] <= a[i]) j--;
    const t = a[i]; a[i] = a[j]; a[j] = t;
    for (let l = i + 1, r = a.length - 1; l < r; l++, r--) { const u = a[l]; a[l] = a[r]; a[r] = u; }
    return true;
  }

  /* ================= code listings ================= */

  const SUBSETS_C = `#include <stdio.h>

/* Print every subset by including or skipping each number in turn. */
void walk(const int *a, int n, int *pick, int depth, int start) {
    if (start == n) {                 /* nothing left to decide */
        printf("{ ");
        for (int i = 0; i < depth; i++) printf("%d ", pick[i]);
        printf("}\\n");
        return;
    }
    pick[depth] = a[start];           /* include a[start] */
    walk(a, n, pick, depth + 1, start + 1);
    walk(a, n, pick, depth, start + 1);  /* skip a[start] */
}

int main(void) {
    int a[] = {1, 2, 3};
    int pick[3];
    walk(a, 3, pick, 0, 0);
    return 0;
}`;

  const SUBSETS_CPP = `#include <iostream>
#include <vector>

// Collect every subset by trying include / skip at each position.
void walk(const std::vector<int>& a, int start,
          std::vector<int>& pick, std::vector<std::vector<int>>& out) {
    if (start == (int)a.size()) {
        out.push_back(pick);          // a finished subset
        return;
    }
    pick.push_back(a[start]);         // include
    walk(a, start + 1, pick, out);
    pick.pop_back();                  // undo before the other branch
    walk(a, start + 1, pick, out);    // skip
}

int main() {
    std::vector<int> a{1, 2, 3};
    std::vector<int> pick;
    std::vector<std::vector<int>> out;
    walk(a, 0, pick, out);
    for (const auto& s : out) {
        std::cout << "{ ";
        for (int x : s) std::cout << x << ' ';
        std::cout << "}\\n";
    }
}`;

  const SUBSETS_BITS_C = `#include <stdio.h>

/* One bitmask per subset: bit b says whether a[b] is included. */
int main(void) {
    int a[] = {1, 2, 3};
    int n = 3;
    for (int mask = 0; mask < (1 << n); mask++) {
        printf("{ ");
        for (int b = 0; b < n; b++)
            if (mask & (1 << b))
                printf("%d ", a[b]);
        printf("}\\n");
    }
    return 0;
}`;

  const SUBSETS_BITS_CPP = `#include <iostream>
#include <vector>

// Each mask from 0 to 2^n-1 spells out exactly one subset.
int main() {
    std::vector<int> a{1, 2, 3};
    int n = (int)a.size();
    for (int mask = 0; mask < (1 << n); ++mask) {
        std::cout << "{ ";
        for (int b = 0; b < n; ++b)
            if (mask & (1 << b))
                std::cout << a[b] << ' ';
        std::cout << "}\\n";
    }
}`;

  const SUBSETS_II_C = `#include <stdio.h>

/* Sorted input: after skipping a value, skip all of its twins too. */
void walk(const int *a, int n, int *pick, int depth, int start) {
    if (start == n) {                 /* base: nothing left to decide */
        printf("{ ");
        for (int i = 0; i < depth; i++) printf("%d ", pick[i]);
        printf("}\\n");
        return;
    }
    pick[depth] = a[start];           /* include a[start] */
    walk(a, n, pick, depth + 1, start + 1);
    int next = start + 1;             /* skip a[start] and equal twins */
    while (next < n && a[next] == a[start]) next++;
    walk(a, n, pick, depth, next);
}

int main(void) {
    int a[] = {1, 2, 2};              /* the input must be sorted */
    int pick[3];
    walk(a, 3, pick, 0, 0);
    return 0;
}`;

  const SUBSETS_II_CPP = `#include <iostream>
#include <vector>
#include <algorithm>

// Sorted input + jumping over equal twins keeps subsets unique.
void walk(const std::vector<int>& a, int start,
          std::vector<int>& pick, std::vector<std::vector<int>>& out) {
    if (start == (int)a.size()) {
        out.push_back(pick);          // base case
        return;
    }
    pick.push_back(a[start]);         // include
    walk(a, start + 1, pick, out);
    pick.pop_back();                  // undo the include
    int next = start + 1;             // skip the value and its twins
    while (next < (int)a.size() && a[next] == a[start]) ++next;
    walk(a, next, pick, out);
}

int main() {
    std::vector<int> a{1, 2, 2};      // sort first
    std::sort(a.begin(), a.end());
    std::vector<int> pick;
    std::vector<std::vector<int>> out;
    walk(a, 0, pick, out);
    for (const auto& s : out) {
        std::cout << "{ ";
        for (int x : s) std::cout << x << ' ';
        std::cout << "}\\n";
    }
}`;

  const PERMS_C = `#include <stdio.h>

/* Fix one unused number in each position, then undo it. */
void walk(const int *a, int n, int *cur, int *used, int depth) {
    if (depth == n) {                 /* base: one full permutation */
        for (int i = 0; i < n; i++) printf("%d ", cur[i]);
        printf("\\n");
        return;
    }
    for (int i = 0; i < n; i++) {
        if (used[i]) continue;
        used[i] = 1;                  /* take a[i] at this depth */
        cur[depth] = a[i];
        walk(a, n, cur, used, depth + 1);
        used[i] = 0;                  /* undo: free a[i] again */
    }
}

int main(void) {
    int a[] = {1, 2, 3};
    int cur[3], used[3] = {0, 0, 0};
    walk(a, 3, cur, used, 0);
    return 0;
}`;

  const PERMS_CPP = `#include <iostream>
#include <vector>

// Build permutations in place, un-choosing every number on the way back.
void walk(const std::vector<int>& a, std::vector<bool>& used,
          std::vector<int>& cur, std::vector<std::vector<int>>& out) {
    if (cur.size() == a.size()) {
        out.push_back(cur);           // one full permutation
        return;
    }
    for (size_t i = 0; i < a.size(); ++i) {
        if (used[i]) continue;
        used[i] = true;               // choose
        cur.push_back(a[i]);
        walk(a, used, cur, out);
        cur.pop_back();               // un-choose
        used[i] = false;
    }
}

int main() {
    std::vector<int> a{1, 2, 3};
    std::vector<bool> used(a.size(), false);
    std::vector<int> cur;
    std::vector<std::vector<int>> out;
    walk(a, used, cur, out);
    for (const auto& p : out) {
        for (int x : p) std::cout << x << ' ';
        std::cout << '\\n';
    }
}`;

  const PERMS_NEXT_C = `#include <stdio.h>

/* Rearrange a[] into the next larger permutation. 0 means "done". */
int next_perm(int *a, int n) {
    int i = n - 2;
    while (i >= 0 && a[i] >= a[i + 1]) i--;      /* last ascent */
    if (i < 0) return 0;                         /* already largest */
    int j = n - 1;
    while (a[j] <= a[i]) j--;                    /* first bigger right */
    int t = a[i]; a[i] = a[j]; a[j] = t;
    for (int l = i + 1, r = n - 1; l < r; l++, r--) {
        t = a[l]; a[l] = a[r]; a[r] = t;         /* reverse the tail */
    }
    return 1;
}

int main(void) {
    int a[] = {1, 2, 3};
    int n = 3;
    do {
        for (int i = 0; i < n; i++) printf("%d ", a[i]);
        printf("\\n");
    } while (next_perm(a, n));
    return 0;
}`;

  const PERMS_NEXT_CPP = `#include <iostream>
#include <vector>
#include <algorithm>

// Repeatedly ask the array for its next permutation.
int main() {
    std::vector<int> a{1, 2, 3};
    std::sort(a.begin(), a.end());
    do {
        for (int x : a) std::cout << x << ' ';
        std::cout << '\\n';
    } while (std::next_permutation(a.begin(), a.end()));
}`;

  const PERMS_II_C = `#include <stdio.h>
#include <stdbool.h>

/* Sorted input + "skip a twin whose earlier copy is unused". */
void walk(const int *a, int n, int *cur, bool *used, int depth) {
    if (depth == n) {                 /* base: one full permutation */
        for (int i = 0; i < n; i++) printf("%d ", cur[i]);
        printf("\\n");
        return;
    }
    for (int i = 0; i < n; i++) {
        if (used[i]) continue;
        if (i > 0 && a[i] == a[i - 1] && !used[i - 1]) continue;
        used[i] = true;               /* take a[i] at this depth */
        cur[depth] = a[i];
        walk(a, n, cur, used, depth + 1);
        used[i] = false;              /* undo: free a[i] again */
    }
}

int main(void) {
    int a[] = {1, 1, 2};              /* the input must be sorted */
    int cur[3];
    bool used[3] = {false, false, false};
    walk(a, 3, cur, used, 0);
    return 0;
}`;

  const PERMS_II_CPP = `#include <iostream>
#include <vector>
#include <algorithm>

// Sorted input; a twin may only be used after its earlier copy.
void walk(const std::vector<int>& a, std::vector<bool>& used,
          std::vector<int>& cur, std::vector<std::vector<int>>& out) {
    if (cur.size() == a.size()) {
        out.push_back(cur);
        return;
    }
    for (size_t i = 0; i < a.size(); ++i) {
        if (used[i]) continue;
        if (i > 0 && a[i] == a[i - 1] && !used[i - 1]) continue;
        used[i] = true;
        cur.push_back(a[i]);
        walk(a, used, cur, out);
        cur.pop_back();
        used[i] = false;
    }
}

int main() {
    std::vector<int> a{1, 1, 2};      // sort first
    std::sort(a.begin(), a.end());
    std::vector<bool> used(a.size(), false);
    std::vector<int> cur;
    std::vector<std::vector<int>> out;
    walk(a, used, cur, out);
    for (const auto& p : out) {
        for (int x : p) std::cout << x << ' ';
        std::cout << '\\n';
    }
}`;

  const COMB_C = `#include <stdio.h>

/* Pick k numbers, always stepping forward so no order repeats. */
void choose(const int *a, int n, int k, int *pick, int filled, int start) {
    if (filled == k) {                /* base: a full selection */
        for (int i = 0; i < k; i++) printf("%d ", pick[i]);
        printf("\\n");
        return;
    }
    for (int i = start; i < n; i++) {
        if (n - i < k - filled) break;   /* too few numbers left */
        pick[filled] = a[i];
        choose(a, n, k, pick, filled + 1, i + 1);
    }
}

int main(void) {
    int a[] = {1, 2, 3, 4};
    int pick[2];
    choose(a, 4, 2, pick, 0, 0);
    return 0;
}`;

  const COMB_CPP = `#include <iostream>
#include <vector>

// Forward-only choices give each k-subset exactly once.
void choose(const std::vector<int>& a, int k,
            std::vector<int>& pick, int start) {
    if ((int)pick.size() == k) {
        for (int x : pick) std::cout << x << ' ';
        std::cout << '\\n';
        return;
    }
    for (int i = start; i < (int)a.size(); ++i) {
        if ((int)a.size() - i < k - (int)pick.size()) break;
        pick.push_back(a[i]);
        choose(a, k, pick, i + 1);
        pick.pop_back();
    }
}

int main() {
    std::vector<int> a{1, 2, 3, 4};
    std::vector<int> pick;
    choose(a, 2, pick, 0);
}`;

  const CSUM_C = `#include <stdio.h>

/* Sorted candidates; stay on the same index so numbers may repeat. */
void find(const int *a, int n, int target, int *pick, int len, int start) {
    if (target == 0) {                /* base: the sum is exact */
        for (int i = 0; i < len; i++) printf("%d ", pick[i]);
        printf("\\n");
        return;
    }
    for (int i = start; i < n; i++) {
        if (a[i] > target) break;                  /* sorted: stop early */
        if (i > start && a[i] == a[i - 1]) continue;  /* skip twin branches */
        pick[len] = a[i];
        find(a, n, target - a[i], pick, len + 1, i);  /* same i: reuse */
    }
}

int main(void) {
    int a[] = {2, 3, 5};
    int pick[16];
    find(a, 3, 8, pick, 0, 0);   /* 2+2+2+2, 2+3+3, 3+5 */
    return 0;
}`;

  const CSUM_CPP = `#include <iostream>
#include <vector>
#include <algorithm>

// Same index after a pick = unlimited reuse of that candidate.
void find(const std::vector<int>& a, int target,
          std::vector<int>& pick, int start) {
    if (target == 0) {
        for (int x : pick) std::cout << x << ' ';
        std::cout << '\\n';
        return;
    }
    for (int i = start; i < (int)a.size(); ++i) {
        if (a[i] > target) break;
        if (i > start && a[i] == a[i - 1]) continue;
        pick.push_back(a[i]);
        find(a, target - a[i], pick, i);   // i, not i + 1
        pick.pop_back();
    }
}

int main() {
    std::vector<int> a{2, 3, 5};
    std::sort(a.begin(), a.end());
    std::vector<int> pick;
    find(a, 8, pick, 0);
}`;

  /* =========================================================
     Shared step generator: subsets / subsets II
     ========================================================= */
  function subsetSteps(rawNums, dedupe, L) {
    const nums = dedupe ? rawNums.slice().sort((a, b) => a - b) : rawNums.slice();
    const n = nums.length;
    const steps = [];
    const subset = [];
    const path = {};
    const results = [];
    const total = pow2(n);
    const legend = ["read", "done", "dim", "result", "idle"];
    let choices = 0;
    let truncated = false;

    const push = (s) => {
      if (steps.length >= MAX_STEPS) { truncated = true; return false; }
      steps.push(s);
      return true;
    };
    const pathVals = () => Array.from({ length: n }, (_, i) => (path[i] != null ? path[i] : "·"));
    const pathStates = () => Array.from({ length: n }, (_, i) =>
      path[i] === "in" ? "done" : path[i] === "out" ? "dim" : "idle");
    const candStates = (cur) => nums.map((_, i) =>
      i === cur ? "read" : path[i] === "in" ? "done" : path[i] === "out" ? "dim" : "idle");
    const subTrack = () => subset.length
      ? { label: "current subset", cells: subset.map((v) => ({ v, state: "result" })) }
      : { label: "current subset", cells: [{ v: "∅", state: "idle", empty: true }] };
    const resTrack = (just) => ({
      label: "results so far",
      cells: results.length
        ? results.map((r, i) => ({ v: fmtSet(r), state: i === just ? "result" : "done" }))
        : [{ v: "∅", state: "idle", empty: true }],
    });
    const view = (cur, just) => [
      track("candidates", nums.slice(), candStates(cur)),
      subTrack(),
      track("path", pathVals(), pathStates()),
      resTrack(just),
    ];
    const counters = () => [count("choices made", choices), count("results found", results.length, total)];

    steps.push({
      title: `Set up: ${n} ${n === 1 ? "number" : "numbers"}, start with the empty subset`,
      tracks: view(-1, -1),
      counters: [count("choices made", 0), count("results found", 0, total)],
      legend,
      happened: `${dedupe ? "Sorted, the " : "The "}candidates ${nums.join(", ")} wait to be decided one at a time. Nothing is in the subset yet.`,
      why: "Backtracking asks one question per number — include it or skip it — and records a subset only after every number has been decided.",
      codeLine: L.entry,
    });

    const stepInclude = (i) => ({
      title: `Include ${nums[i]} → subset [${fmtSet(subset)}]`,
      tracks: view(i, -1),
      counters: counters(),
      legend,
      happened: `${nums[i]} joins the current subset, which is now [${fmtSet(subset)}]; the walk moves on to the next number.`,
      why: "Including a number opens a whole branch of subsets that all contain it.",
      codeLine: L.include,
    });
    const stepIncludeRecord = (i) => ({
      title: `Include ${nums[i]} → record [${fmtSet(subset)}]`,
      tracks: view(i, results.length - 1),
      counters: counters(),
      legend,
      happened: `That was the last undecided number, so [${fmtSet(subset)}] is complete and lands in the results.`,
      why: "Running past the last number is the base case — the current choices already form a finished subset.",
      codeLine: L.base,
    });
    const stepBacktrack = (i) => ({
      title: `Backtrack: pop ${nums[i]} — now skip it`,
      tracks: view(i, -1),
      counters: counters(),
      legend,
      happened: `The include branch for ${nums[i]} is exhausted, so ${nums[i]} is removed from the subset and we take the skip branch instead.`,
      why: "Undoing the choice is what lets the same number be tried the other way without keeping two copies of the input.",
      codeLine: L.skip,
    });
    const stepBacktrackRecord = (i) => ({
      title: `Backtrack: pop ${nums[i]}, skip ${nums[i]} → record [${fmtSet(subset)}]`,
      tracks: view(i, results.length - 1),
      counters: counters(),
      legend,
      happened: `Removing ${nums[i]} and skipping it reaches the end again, producing the subset [${fmtSet(subset)}].`,
      why: "The skip branch also hits the base case, so it hands a finished subset to the results too.",
      codeLine: L.skip,
    });

    function dfs(i) {
      if (truncated) return;
      if (i >= n) {
        results.push(subset.slice());
        push({
          title: `Record complete subset [${fmtSet(subset)}]`,
          tracks: view(-1, results.length - 1),
          counters: counters(),
          legend,
          happened: `Every number has been decided, so [${fmtSet(subset)}] is a finished subset.`,
          why: "The base case simply stores whatever the current path produced.",
          codeLine: L.base,
        });
        return;
      }
      const v = nums[i];
      /* include */
      subset.push(v);
      path[i] = "in";
      choices++;
      if (i + 1 >= n) {
        results.push(subset.slice());
        push(stepIncludeRecord(i));
      } else {
        push(stepInclude(i));
        dfs(i + 1);
      }
      subset.pop();
      delete path[i];
      /* skip */
      let j = i + 1;
      if (dedupe) { while (j < n && nums[j] === v) j++; }
      path[i] = "out";
      choices++;
      if (j >= n) {
        results.push(subset.slice());
        push(stepBacktrackRecord(i));
      } else {
        push(stepBacktrack(i));
        dfs(j);
      }
      delete path[i];
    }
    dfs(0);

    steps.push({
      title: truncated ? `Stopped early after ${results.length} subsets` : `Answer: ${results.length} subsets`,
      tracks: [
        track("candidates", nums.slice(), fill(n, "done")),
        { label: "current subset", cells: [{ v: "∅", state: "idle", empty: true }] },
        track("path", Array(n).fill("·"), fill(n, "idle")),
        { label: "results so far", cells: results.map((r) => ({ v: fmtSet(r), state: "result" })) },
      ],
      counters: [count("choices made", choices), count("results found", results.length, total), count("answer", `${results.length} subsets`)],
      legend,
      happened: truncated
        ? `The input was large, so the animation stops after ${results.length} subsets; a full search would visit ${total}.`
        : `The walk explored every include-or-skip combination and produced ${results.length} subsets, including the empty one.`,
      why: "Each number doubles the number of subsets, so n numbers give 2^n of them — found with one shared buffer.",
      codeLine: L.entry,
    });
    return steps;
  }

  /* =========================================================
     Shared step generator: permutations / permutations II
     ========================================================= */
  function permutationSteps(rawNums, dedupe, L) {
    const nums = dedupe ? rawNums.slice().sort((a, b) => a - b) : rawNums.slice();
    const n = nums.length;
    const steps = [];
    const used = Array(n).fill(false);
    const cur = [];
    const results = [];
    const total = n <= 12 ? factorial(n) : "n!";
    const legend = ["read", "done", "result", "idle"];
    let placed = 0;
    let truncated = false;

    const push = (s) => {
      if (steps.length >= MAX_STEPS) { truncated = true; return false; }
      steps.push(s);
      return true;
    };
    const view = (curIdx) => [
      track("numbers", nums.slice(), nums.map((_, i) => (i === curIdx ? "read" : used[i] ? "done" : "idle"))),
      track("used", used.map((u) => (u ? "✓" : "·")), used.map((u) => (u ? "done" : "idle"))),
      cur.length
        ? { label: "current permutation", cells: cur.map((v) => ({ v, state: "result" })) }
        : { label: "current permutation", cells: [{ v: "∅", state: "idle", empty: true }] },
      results.length
        ? { label: "permutations so far", cells: results.map((r, i) => ({ v: fmtSet(r), state: i === results.length - 1 ? "result" : "done" })) }
        : { label: "permutations so far", cells: [{ v: "∅", state: "idle", empty: true }] },
    ];
    const counters = () => [count("placed", placed), count("permutations found", results.length, total)];

    steps.push({
      title: `Set up: fill ${n} ${n === 1 ? "position" : "positions"}, one number each`,
      tracks: view(-1),
      counters: [count("placed", 0), count("permutations found", 0, total)],
      legend,
      happened: `${dedupe ? "Sorted, the " : "The "}numbers ${nums.join(", ")} are all free. No position has been filled yet.`,
      why: "A permutation uses every number exactly once, so the walk keeps a used[] mask and fills positions one at a time.",
      codeLine: L.entry,
    });

    const placeStep = (i) => ({
      title: `Place ${nums[i]} at position ${cur.length - 1} → current [${fmtSet(cur)}]`,
      tracks: view(i),
      counters: counters(),
      legend,
      happened: `${nums[i]} takes the next empty position and is marked used, so it cannot be placed again in this branch.`,
      why: "Fixing one number per position turns 'all orderings' into a simple loop over the unused numbers.",
      codeLine: L.use,
    });
    const placeRecordStep = (i) => ({
      title: `Place ${nums[i]} → record permutation [${fmtSet(cur)}]`,
      tracks: view(i),
      counters: counters(),
      legend,
      happened: `That placement filled the final position, so [${fmtSet(cur)}] is a complete permutation and is recorded.`,
      why: "With every position filled there is nothing left to decide — the arrangement is done.",
      codeLine: L.base,
    });
    const undoStep = (i) => ({
      title: `Backtrack: take ${nums[i]} back out of position ${cur.length}`,
      tracks: view(i),
      counters: counters(),
      legend,
      happened: `${nums[i]} is removed from the current permutation and marked free again, clearing the way for the next candidate.`,
      why: "Clearing the used flag on the way back out is the undo that lets other branches reuse this number.",
      codeLine: L.undo,
    });
    const skipDupStep = (i) => ({
      title: `Skip ${nums[i]} — the earlier ${nums[i]} is still unused`,
      tracks: view(i),
      counters: counters(),
      legend,
      happened: `This copy of ${nums[i]} is left alone because an equal number before it has not been used yet.`,
      why: "Always taking the leftmost equal number first removes duplicate permutations without a separate set.",
      codeLine: L.skip,
    });

    function dfs() {
      if (truncated) return;
      if (cur.length === n) {
        results.push(cur.slice());
        push({
          title: `Record permutation [${fmtSet(cur)}]`,
          tracks: view(-1),
          counters: counters(),
          legend,
          happened: `All positions are filled, so [${fmtSet(cur)}] is complete.`,
          why: "The base case stores the finished arrangement.",
          codeLine: L.base,
        });
        return;
      }
      for (let i = 0; i < n; i++) {
        if (truncated) return;
        if (used[i]) continue;
        if (dedupe && i > 0 && nums[i] === nums[i - 1] && !used[i - 1]) {
          push(skipDupStep(i));
          continue;
        }
        used[i] = true;
        cur.push(nums[i]);
        placed++;
        if (cur.length === n) {
          results.push(cur.slice());
          push(placeRecordStep(i));
        } else {
          push(placeStep(i));
          dfs();
        }
        cur.pop();
        used[i] = false;
        push(undoStep(i));
      }
    }
    dfs();

    steps.push({
      title: truncated ? `Stopped early after ${results.length} permutations` : `Answer: ${results.length} permutations`,
      tracks: [
        track("numbers", nums.slice(), fill(n, "done")),
        track("used", Array(n).fill("·"), fill(n, "idle")),
        { label: "current permutation", cells: [{ v: "∅", state: "idle", empty: true }] },
        { label: "permutations so far", cells: results.map((r) => ({ v: fmtSet(r), state: "result" })) },
      ],
      counters: [count("placed", placed), count("permutations found", results.length, total), count("answer", `${results.length} permutations`)],
      legend,
      happened: truncated
        ? `The input was large, so the animation stops after ${results.length} permutations; the full count would be ${total} (and would keep growing).`
        : `Every number was placed in every position, giving ${results.length} distinct permutations.`,
      why: "Each of the n! orderings is built once; the used[] mask prevents any number from appearing twice in one arrangement.",
      codeLine: L.entry,
    });
    return steps;
  }

  /* =========================================================
     Combinations
     ========================================================= */
  function combinationSteps(nums, k, L) {
    const n = nums.length;
    const steps = [];
    const cur = [];
    const results = [];
    const total = n <= 20 ? chooseCount(n, k) : "C(n,k)";
    const legend = ["read", "done", "dim", "result", "idle"];
    let truncated = false;

    const push = (s) => {
      if (steps.length >= MAX_STEPS) { truncated = true; return false; }
      steps.push(s);
      return true;
    };
    const view = (start, curIdx) => [
      track("candidates", nums.slice(), nums.map((_, i) =>
        i === curIdx ? "read" : i < start ? "dim" : i < curIdx ? "done" : "idle")),
      cur.length
        ? { label: "current combination", cells: cur.map((v) => ({ v, state: "result" })) }
        : { label: "current combination", cells: [{ v: "∅", state: "idle", empty: true }] },
      { label: "progress", cells: [{ v: `${cur.length} of ${k}`, state: cur.length === k ? "result" : "active" }] },
      results.length
        ? { label: "combinations so far", cells: results.map((r, i) => ({ v: fmtSet(r), state: i === results.length - 1 ? "result" : "done" })) }
        : { label: "combinations so far", cells: [{ v: "∅", state: "idle", empty: true }] },
    ];
    const counters = () => [count("chosen", cur.length, k), count("combinations found", results.length, total)];

    steps.push({
      title: `Set up: choose ${k} of ${n}${n ? "" : " (no candidates)"}`,
      tracks: view(0, -1),
      counters: [count("chosen", 0, k), count("combinations found", 0, total)],
      legend,
      happened: `${n ? `The candidates ${nums.join(", ")} are available and ` : ""}the selection starts empty. Choices only move forward, so each group is built in one order.`,
      why: "By never looking back, the walk avoids producing the same group in a different order.",
      codeLine: L.entry,
    });

    if (k === 0) {
      results.push([]);
      push({
        title: `Choose 0 numbers → record [${fmtSet([])}]`,
        tracks: view(0, -1),
        counters: counters(),
        legend,
        happened: "Choosing nothing is a valid (and the only) selection when k is zero.",
        why: "The empty selection finishes immediately at the base case.",
        codeLine: L.base,
      });
    } else if (k > n) {
      push({
        title: `No combinations: k = ${k} is larger than n = ${n}`,
        tracks: view(0, -1),
        counters: counters(),
        legend,
        happened: `You cannot pick ${k} different numbers from only ${n}.`,
        why: "The forward-only loop runs out of positions before filling k slots.",
        codeLine: L.prune,
      });
    } else {
      dfs(0);
    }

    function dfs(start) {
      if (truncated) return;
      if (cur.length === k) {
        results.push(cur.slice());
        push(recordStep(-1));
        return;
      }
      for (let i = start; i < n; i++) {
        if (truncated) return;
        if (n - i < k - cur.length) {
          push(pruneStep(i));
          break;
        }
        cur.push(nums[i]);
        push(chooseStep(i));
        if (cur.length === k) {
          results.push(cur.slice());
          push(recordStep(i));
        } else {
          dfs(i + 1);
        }
        cur.pop();
        push(undoStep(i));
      }
    }
    function chooseStep(i) {
      return {
        title: `Choose ${nums[i]} → [${fmtSet(cur)}] (${cur.length} of ${k})`,
        tracks: view(i, i),
        counters: counters(),
        legend,
        happened: `${nums[i]} takes the next slot; the walk continues from the following index only.`,
        why: "Advancing the start index is what keeps each group sorted and unique.",
        codeLine: L.choose,
      };
    }
    function recordStep(i) {
      return {
        title: `Complete [${fmtSet(cur)}] → record`,
        tracks: view(i === -1 ? cur.length : i, i),
        counters: counters(),
        legend,
        happened: `${k} slots are filled, so [${fmtSet(cur)}] is a valid selection and is recorded.`,
        why: "Filling exactly k slots is the base case of the selection walk.",
        codeLine: L.base,
      };
    }
    function pruneStep(i) {
      return {
        title: `Stop: only ${n - i} ${n - i === 1 ? "number" : "numbers"} left, need ${k - cur.length}`,
        tracks: view(i, i),
        counters: counters(),
        legend,
        happened: `Starting at ${nums[i]} there are not enough numbers left to fill the remaining slots.`,
        why: "This cut-off skips whole runs of doomed branches, which is why the count matches C(n,k) exactly.",
        codeLine: L.prune,
      };
    }
    function undoStep(i) {
      return {
        title: `Backtrack: remove ${nums[i]}`,
        tracks: view(i + 1, i),
        counters: counters(),
        legend,
        happened: `${nums[i]} leaves the selection so the next candidate can be tried in its place.`,
        why: "Popping the last choice restores the buffer for the sibling branch.",
        codeLine: L.choose,
      };
    }

    steps.push({
      title: truncated
        ? `Stopped early after ${results.length} combinations`
        : results.length
          ? `Answer: ${results.length} combinations`
          : "Answer: no combinations",
      tracks: [
        track("candidates", nums.slice(), fill(n, results.length ? "done" : "dim")),
        { label: "current combination", cells: [{ v: "∅", state: "idle", empty: true }] },
        { label: "progress", cells: [{ v: `${results.length ? k : 0} of ${k}`, state: "result" }] },
        { label: "combinations so far", cells: results.length ? results.map((r) => ({ v: fmtSet(r), state: "result" })) : [{ v: "∅", state: "idle", empty: true }] },
      ],
      counters: [count("combinations found", results.length, total), count("answer", `${results.length}`)],
      legend,
      happened: results.length
        ? `The whole list of ${results.length} selection${results.length === 1 ? "" : "s"} is ready${truncated ? " (stopped early — the input was large)" : ""}.`
        : `There is no way to choose ${k} numbers from ${n}, so the result is empty rather than an error.`,
      why: "Choosing without looking back visits every k-subset exactly once — C(n,k) of them.",
      codeLine: L.entry,
    });
    return steps;
  }

  /* =========================================================
     Combination Sum
     ========================================================= */
  function combinationSumSteps(rawCands, target, L) {
    const cands = rawCands.filter((x) => Number.isFinite(x) && x > 0).slice().sort((a, b) => a - b);
    const n = cands.length;
    const steps = [];
    const cur = [];
    const results = [];
    const legend = ["read", "done", "dim", "result", "idle"];
    let picks = 0;
    let truncated = false;

    const push = (s) => {
      if (steps.length >= MAX_STEPS) { truncated = true; return false; }
      steps.push(s);
      return true;
    };
    const view = (start, curIdx, remaining) => [
      track("candidates", cands.slice(), cands.map((_, i) =>
        i === curIdx ? "read" : i < start ? "dim" : i < curIdx ? "done" : "idle")),
      cur.length
        ? { label: "current pick", cells: cur.map((v) => ({ v, state: "result" })) }
        : { label: "current pick", cells: [{ v: "∅", state: "idle", empty: true }] },
      { label: "remaining", cells: [{ v: remaining, state: remaining === 0 ? "result" : "active", tag: `of ${target}` }] },
      results.length
        ? { label: "solutions so far", cells: results.map((r, i) => ({ v: fmtSet(r), state: i === results.length - 1 ? "result" : "done" })) }
        : { label: "solutions so far", cells: [{ v: "∅", state: "idle", empty: true }] },
    ];
    const counters = () => [count("picks", picks), count("remaining", target - sum(cur)), count("solutions found", results.length)];

    steps.push({
      title: `Set up: reach ${target} using ${n ? cands.join(", ") : "no usable candidates"}`,
      tracks: view(0, -1, target),
      counters: [count("picks", 0), count("remaining", target), count("solutions found", 0)],
      legend,
      happened: `${n ? `Sorted candidates ${cands.join(", ")} are available; ` : ""}the goal is exactly ${target}, and any candidate may be reused.`,
      why: "Reuse is allowed, so after taking a candidate the walk stays on the same index instead of moving past it.",
      codeLine: L.entry,
    });

    if (target === 0) {
      results.push([]);
      push({
        title: "Target is 0 → record the empty pick",
        tracks: view(0, -1, 0),
        counters: counters(),
        legend,
        happened: "Adding nothing already hits the target, so the empty selection is a solution.",
        why: "Zero remaining is the base case, and it is reached immediately.",
        codeLine: L.base,
      });
    } else if (target < 0) {
      push({
        title: `No solutions: target ${target} is negative`,
        tracks: view(0, -1, target),
        counters: counters(),
        legend,
        happened: "Positive candidates can never add up to a negative target.",
        why: "The comparison stops the search as soon as the first candidate is bigger than what is left.",
        codeLine: L.prune,
      });
    } else if (n === 0) {
      push({
        title: "No solutions: no positive candidates",
        tracks: view(0, -1, target),
        counters: counters(),
        legend,
        happened: "There is nothing positive to add, so the target cannot be reached.",
        why: "Non-positive candidates are ignored because reusing them would never change the sum.",
        codeLine: L.entry,
      });
    } else {
      dfs(0, target);
    }

    function dfs(start, remaining) {
      if (truncated) return;
      for (let i = start; i < n; i++) {
        if (truncated) return;
        if (cands[i] > remaining) { push(pruneStep(i, remaining)); break; }
        if (i > start && cands[i] === cands[i - 1]) continue;
        cur.push(cands[i]);
        picks++;
        const left = remaining - cands[i];
        if (left === 0) {
          results.push(cur.slice());
          push(pickRecordStep(i, remaining));
        } else {
          push(pickStep(i, remaining));
          dfs(i, left);
        }
        cur.pop();
        push(undoStep(i, remaining));
      }
    }
    function pickStep(i, remaining) {
      return {
        title: `Take ${cands[i]} → remaining ${remaining - cands[i]}`,
        tracks: view(i, i, remaining - cands[i]),
        counters: counters(),
        legend,
        happened: `${cands[i]} is added to the pick, leaving ${remaining - cands[i]} to reach ${target}.`,
        why: "The next level starts again at index i, so the same candidate can be taken again.",
        codeLine: L.reuse,
      };
    }
    function pickRecordStep(i, remaining) {
      return {
        title: `Take ${cands[i]} → solution [${fmtSet(cur)}]`,
        tracks: view(i, i, 0),
        counters: counters(),
        legend,
        happened: `Adding ${cands[i]} lands exactly on ${target}, so [${fmtSet(cur)}] is a solution and is recorded.`,
        why: "Hitting zero remaining is the base case of the search.",
        codeLine: L.base,
      };
    }
    function pruneStep(i, remaining) {
      return {
        title: `Stop: ${cands[i]} is bigger than the remaining ${remaining}`,
        tracks: view(i, i, remaining),
        counters: counters(),
        legend,
        happened: `${cands[i]} overshoots the ${remaining} still needed.`,
        why: "Because the candidates are sorted, every later candidate is even bigger, so the whole tail can be skipped.",
        codeLine: L.prune,
      };
    }
    function undoStep(i, remaining) {
      return {
        title: `Backtrack: remove ${cands[i]}`,
        tracks: view(i + 1, i, remaining),
        counters: counters(),
        legend,
        happened: `${cands[i]} is removed from the pick so the next candidate can be tried with ${remaining} still to go.`,
        why: "Undoing the last take restores the remaining sum for the sibling branch.",
        codeLine: L.reuse,
      };
    }
    function sum(a) { return a.reduce((x, y) => x + y, 0); }

    steps.push({
      title: truncated
        ? `Stopped early after ${results.length} solutions`
        : results.length
          ? `Answer: ${results.length} solution${results.length === 1 ? "" : "s"}`
          : "Answer: no solutions",
      tracks: [
        track("candidates", cands.slice(), fill(n, results.length ? "done" : "dim")),
        { label: "current pick", cells: [{ v: "∅", state: "idle", empty: true }] },
        { label: "remaining", cells: [{ v: 0, state: "result", tag: `of ${target}` }] },
        { label: "solutions so far", cells: results.length ? results.map((r) => ({ v: fmtSet(r), state: "result" })) : [{ v: "∅", state: "idle", empty: true }] },
      ],
      counters: [count("picks", picks), count("solutions found", results.length), count("answer", `${results.length}`)],
      legend,
      happened: results.length
        ? `Every combination that adds up to ${target} is listed${truncated ? " (stopped early — the input was large)" : ""}.`
        : `No combination of the candidates adds up to exactly ${target}.`,
      why: "Staying on the same index allows reuse, while sorting and twin-skipping keep each combination unique.",
      codeLine: L.entry,
    });
    return steps;
  }

  /* =========================================================
     1. Subsets
     ========================================================= */
  V.register({
    id: "subsets",
    title: "Subsets",
    category: "Backtracking",
    difficulty: "Intermediate",
    description: "Every subset of a list, built one include-or-skip decision at a time.",
    input: { label: "Candidate numbers", default: "1, 2, 3", parse: "ints" },
    approaches: [
      {
        name: "Include or Skip (backtracking)",
        complexity: "O(2^n) results, O(n) extra space",
        idea: [
          "Walk the numbers left to right. At each one there are exactly two honest choices: put it in the current subset, or leave it out.",
          "A choice is made by adding the number (or not), the walk continues to the next number, and when it runs past the end the current subset is complete and gets recorded.",
          "Then it steps back — the include is undone — so the very same number can be tried the other way. That undo is the 'backtrack'.",
        ],
        problem: [
          "There really are 2^n subsets, so no method can list them faster. With backtracking the cost is the output size itself, and the shared buffer means only O(n) extra space is used — but the step count explodes quickly as n grows.",
        ],
        code: { c: SUBSETS_C, cpp: SUBSETS_CPP },
        steps(parsed) {
          const L = {
            entry: lineOf(SUBSETS_C, "void walk"),
            base: lineOf(SUBSETS_C, "nothing left to decide"),
            include: lineOf(SUBSETS_C, "include a[start]"),
            skip: lineOf(SUBSETS_C, "skip a[start]"),
          };
          return subsetSteps(parsed, false, L);
        },
      },
      {
        name: "Bitmask Enumeration",
        complexity: "O(2^n · n) time, O(n) space",
        idea: [
          "Give every position one bit. A number is in a subset exactly when its bit is 1, so each mask from 0 to 2^n − 1 spells out one subset.",
          "Counting in binary therefore walks through the whole power set without any recursion.",
        ],
        problem: [
          "It is short and jump-free, but it always visits all 2^n masks even when you wanted a specific subset, and it needs the bit trick (1 << n) which overflows for large n in fixed-width integers.",
        ],
        code: { c: SUBSETS_BITS_C, cpp: SUBSETS_BITS_CPP },
        steps(parsed) {
          const nums = parsed.slice();
          const n = nums.length;
          const steps = [];
          const results = [];
          const bitsOf = (mask) => nums.map((_, b) => (Math.floor(mask / Math.pow(2, b)) % 2 === 1 ? "done" : "dim"));
          const resTrack = () => ({
            label: "results so far",
            cells: results.length ? results.map((r, i) => ({ v: fmtSet(r), state: i === results.length - 1 ? "result" : "done" })) : [{ v: "∅", state: "idle", empty: true }],
          });
          const legend = ["done", "dim", "result", "idle"];
          const total = pow2(n);
          steps.push({
            title: `Set up: ${n} bits spell out ${total} subsets`,
            tracks: [
              track("candidates", nums.slice(), fill(n, "idle")),
              { label: "current subset", cells: [{ v: "∅", state: "idle", empty: true }] },
              resTrack(),
            ],
            counters: [count("masks read", 0, total), count("results found", 0, total)],
            legend,
            happened: `Each of the ${n} numbers gets a bit; the mask starts at 0.`,
            why: "Counting in binary guarantees every possible combination of bits is visited exactly once.",
            codeLine: lineOf(SUBSETS_BITS_C, "for (int mask"),
          });
          const limit = Math.min(Math.pow(2, n), MAX_STEPS - 2);
          for (let mask = 0; mask < limit; mask++) {
            const sub = [];
            for (let b = 0; b < n; b++) if (Math.floor(mask / Math.pow(2, b)) % 2 === 1) sub.push(nums[b]);
            results.push(sub);
            steps.push({
              title: `Mask ${mask.toString(2).padStart(n, "0")} → subset [${fmtSet(sub)}]`,
              tracks: [
                track("candidates", nums.slice(), bitsOf(mask)),
                sub.length
                  ? { label: "current subset", cells: sub.map((v) => ({ v, state: "result" })) }
                  : { label: "current subset", cells: [{ v: "∅", state: "idle", empty: true }] },
                resTrack(),
              ],
              counters: [count("masks read", mask + 1, total), count("results found", results.length, total)],
              legend,
              happened: `Mask ${mask} selects the numbers whose bit is 1, giving [${fmtSet(sub)}].`,
              why: "Reading the bits left to right is the same two-way decision as include or skip, just written down in advance.",
              codeLine: lineOf(SUBSETS_BITS_C, "if (mask & (1 << b))"),
            });
          }
          steps.push({
            title: `Answer: ${results.length} subsets`,
            tracks: [
              track("candidates", nums.slice(), fill(n, "done")),
              { label: "current subset", cells: [{ v: "∅", state: "idle", empty: true }] },
              { label: "results so far", cells: results.map((r) => ({ v: fmtSet(r), state: "result" })) },
            ],
            counters: [count("masks read", results.length, total), count("results found", results.length, total), count("answer", `${results.length} subsets`)],
            legend,
            happened: `Counting from 0 to ${total - 1 < 0 ? 0 : total - 1} produced all ${results.length} subsets — the empty set included.`,
            why: "The power set is exactly the set of all n-bit masks, so simple counting enumerates it completely.",
            codeLine: lineOf(SUBSETS_BITS_C, "for (int mask"),
          });
          return steps;
        },
      },
    ],
  });

  /* =========================================================
     2. Subsets II
     ========================================================= */
  V.register({
    id: "subsets-ii",
    title: "Subsets II",
    category: "Backtracking",
    difficulty: "Intermediate",
    description: "Unique subsets when the list repeats values — sort first, then skip twins.",
    input: { label: "Candidate numbers (may repeat)", default: "1, 2, 2", parse: "ints" },
    approaches: [
      {
        name: "Sort and Skip Equal Twins",
        complexity: "O(2^n) worst case, O(n) extra space",
        idea: [
          "With duplicates, plain include-or-skip would build the same subset several times. Sorting the input first puts equal numbers side by side.",
          "When the walk decides to skip a number, it skips every following number equal to it as well — so all copies of a value are either taken together (a run of includes) or passed over together (one skip).",
          "That single rule removes every duplicate subset while the include branch still keeps its natural shape.",
        ],
        problem: [
          "The sort costs O(n log n) and changes the original order, so the subsets come out in sorted order rather than input order. The rule is also easy to get subtly wrong if the twins are not truly adjacent.",
        ],
        code: { c: SUBSETS_II_C, cpp: SUBSETS_II_CPP },
        steps(parsed) {
          const L = {
            entry: lineOf(SUBSETS_II_C, "void walk"),
            base: lineOf(SUBSETS_II_C, "base: nothing left"),
            include: lineOf(SUBSETS_II_C, "include a[start]"),
            skip: lineOf(SUBSETS_II_C, "skip a[start] and equal twins"),
          };
          return subsetSteps(parsed, true, L);
        },
      },
    ],
  });

  /* =========================================================
     3. Permutations
     ========================================================= */
  V.register({
    id: "permutations",
    title: "Permutations",
    category: "Backtracking",
    difficulty: "Intermediate",
    description: "All arrangements built one position at a time, with an explicit undo after each.",
    input: { label: "Numbers to arrange", default: "1, 2, 3", parse: "ints" },
    approaches: [
      {
        name: "Fill Positions with a used[] Mask",
        complexity: "O(n! · n) time, O(n) extra space",
        idea: [
          "Fill the first position with any number, the second with any still-unused number, and so on. A used[] mask records which numbers are already in the arrangement.",
          "When every position is filled the arrangement is complete and is recorded.",
          "Then the walk steps back: the last number is removed and its mask bit is cleared, so it becomes available for the next sibling branch. That removal plus clearing is the backtrack.",
        ],
        problem: [
          "n! grows extremely fast — 10 numbers already mean over three million arrangements — and each result is a full copy of length n, so the memory for the output dominates.",
        ],
        code: { c: PERMS_C, cpp: PERMS_CPP },
        steps(parsed) {
          const L = {
            entry: lineOf(PERMS_C, "void walk"),
            base: lineOf(PERMS_C, "base: one full permutation"),
            use: lineOf(PERMS_C, "take a[i] at this depth"),
            undo: lineOf(PERMS_C, "undo: free a[i] again"),
          };
          return permutationSteps(parsed, false, L);
        },
      },
      {
        name: "Next-Permutation Sweep",
        complexity: "O(n! · n) time, O(1) extra space",
        idea: [
          "Start from the numbers sorted into their smallest order. A helper finds the next larger arrangement in place: locate the last place that rises, swap it with the smallest larger number to its right, then reverse the tail.",
          "Calling that helper until it returns 'no next' walks through every permutation in dictionary order.",
        ],
        problem: [
          "It re-orders the array in place (the original order is lost), and each step scans part of the array again, so it is no faster than recursion — but it stores no extra results buffer at all.",
        ],
        code: { c: PERMS_NEXT_C, cpp: PERMS_NEXT_CPP },
        steps(parsed) {
          const a = parsed.slice().sort((x, y) => x - y);
          const n = a.length;
          const steps = [];
          const total = n <= 12 ? factorial(n) : "n!";
          const legend = ["result", "done", "idle"];
          let count_ = 0;
          const doneTrack = () => ({
            label: "permutations so far",
            cells: count_ ? Array.from({ length: count_ }, (_, i) => ({ v: i === count_ - 1 ? `#${i + 1}` : "·", state: i === count_ - 1 ? "result" : "done" })) : [{ v: "∅", state: "idle", empty: true }],
          });
          steps.push({
            title: "Set up: sort into the smallest arrangement",
            tracks: [track("the arrangement", a.slice(), fill(n, "idle")), doneTrack()],
            counters: [count("permutations made", 0, total)],
            legend,
            happened: `${a.join(", ")} is the smallest order of these ${n} numbers.`,
            why: "Next-permutation must start from the sorted order, otherwise some arrangements would never appear.",
            codeLine: lineOf(PERMS_NEXT_C, "int next_perm"),
          });
          do {
            count_++;
            steps.push({
              title: `Permutation #${count_}: ${a.join(" ")}`,
              tracks: [track("the arrangement", a.slice(), fill(n, "result")), doneTrack()],
              counters: [count("permutations made", count_, total), count("current order", a.join(" "))],
              legend,
              happened: `The array now reads ${a.join(", ")}; that is permutation number ${count_}.`,
              why: "Each call advances the array to the next larger arrangement, so the order never repeats.",
              codeLine: lineOf(PERMS_NEXT_C, "while (i >= 0 && a[i] >= a[i + 1])"),
            });
          } while (nextPermutation(a) && steps.length < MAX_STEPS - 1);
          steps.push({
            title: `Answer: ${count_} permutations`,
            tracks: [track("the arrangement", a.slice(), fill(n, "done")), doneTrack()],
            counters: [count("permutations made", count_, total), count("answer", `${count_}`)],
            legend,
            happened: `The helper had no next arrangement after ${count_} steps, so all ${count_} permutations have been seen.`,
            why: "Once the array is in its largest order there is nothing bigger, which is exactly the stopping point.",
            codeLine: lineOf(PERMS_NEXT_C, "if (i < 0) return 0"),
          });
          return steps;
        },
      },
    ],
  });

  /* =========================================================
     4. Permutations II
     ========================================================= */
  V.register({
    id: "permutations-ii",
    title: "Permutations II",
    category: "Backtracking",
    difficulty: "Intermediate",
    description: "Unique arrangements when some numbers repeat — sort, then only use a twin after its twin.",
    input: { label: "Numbers to arrange (may repeat)", default: "1, 1, 2", parse: "ints" },
    approaches: [
      {
        name: "Sort plus Twin-Order Rule",
        complexity: "O(n! · n) worst case, O(n) extra space",
        idea: [
          "Sort the numbers first so equal values sit together.",
          "The extra rule is: never use a number if an equal number just before it is still unused. Read it as 'a group of equal values must be consumed from left to right'.",
          "That single check removes every arrangement that is just a copy of another, without any separate set of seen permutations.",
        ],
        problem: [
          "The rule relies on the array being sorted, and it is easy to misread — removing or inverting the 'previous is unused' test either allows duplicates again or drops valid arrangements.",
        ],
        code: { c: PERMS_II_C, cpp: PERMS_II_CPP },
        steps(parsed) {
          const L = {
            entry: lineOf(PERMS_II_C, "void walk"),
            base: lineOf(PERMS_II_C, "base: one full permutation"),
            use: lineOf(PERMS_II_C, "take a[i] at this depth"),
            undo: lineOf(PERMS_II_C, "undo: free a[i] again"),
            skip: lineOf(PERMS_II_C, "a[i] == a[i - 1]"),
          };
          return permutationSteps(parsed, true, L);
        },
      },
    ],
  });

  /* =========================================================
     5. Combinations
     ========================================================= */
  V.register({
    id: "combinations",
    title: "Combinations",
    category: "Backtracking",
    difficulty: "Beginner",
    description: "All size-k selections from a list, built with forward-only recursion.",
    input: { label: "Candidates and k, e.g. 1, 2, 3, 4 k=2", default: "1, 2, 3, 4 k=2", parse: "tokens" },
    approaches: [
      {
        name: "Forward-Only Choice",
        complexity: "O(C(n,k) · k) time, O(k) extra space",
        idea: [
          "To choose k numbers, fill the first slot with some candidate, then only look at candidates after it for the next slot, and so on.",
          "Choosing strictly forward means each group is built once, in increasing order — the mirror group never appears.",
          "When there are fewer numbers left than slots still to fill, the loop stops early instead of descending into dead ends.",
        ],
        problem: [
          "The forward-only rule loses the ability to produce groups in a chosen order, and C(n,k) is still enormous in the middle of Pascal's triangle, so it only stays cheap for small k or small n.",
        ],
        code: { c: COMB_C, cpp: COMB_CPP },
        steps(parsed) {
          const { nums, found } = parseKeyed(parsed, ["k"]);
          let k = found.k != null ? Math.trunc(found.k) : 2;
          if (!Number.isFinite(k) || k < 0) k = 0;
          const L = {
            entry: lineOf(COMB_C, "void choose"),
            base: lineOf(COMB_C, "base: a full selection"),
            choose: lineOf(COMB_C, "pick[filled] = a[i]"),
            prune: lineOf(COMB_C, "too few numbers left"),
          };
          return combinationSteps(nums, k, L);
        },
      },
    ],
  });

  /* =========================================================
     6. Combination Sum
     ========================================================= */
  V.register({
    id: "combination-sum",
    title: "Combination Sum",
    category: "Backtracking",
    difficulty: "Intermediate",
    description: "Every way to add candidates up to a target, reusing numbers freely.",
    input: { label: "Candidates and target, e.g. 2, 3, 5 target=8", default: "2, 3, 5 target=8", parse: "tokens" },
    approaches: [
      {
        name: "Reuse by Staying at the Same Index",
        complexity: "Exponential in the target, O(target) depth",
        idea: [
          "Keep a running 'remaining' amount starting at the target. Taking a candidate subtracts it from the remaining.",
          "The key rule for unlimited reuse: after taking a candidate, the next level starts at the same index, not the next one. That is what lets 2 be taken again and again.",
          "When the remaining hits zero the pick is a solution; when a candidate is bigger than the remaining the sorted list lets the whole tail be skipped.",
        ],
        problem: [
          "Because numbers may repeat, the search tree can be very deep and wide — with candidate 1 and a big target the number of steps grows with the target itself. Sorting and skipping equal twin values are what keep duplicate picks out.",
        ],
        code: { c: CSUM_C, cpp: CSUM_CPP },
        steps(parsed) {
          const { nums, found } = parseKeyed(parsed, ["target"]);
          const positive = nums.filter((x) => x > 0);
          const target = found.target != null ? Math.trunc(found.target) : positive.reduce((a, b) => a + b, 0);
          const L = {
            entry: lineOf(CSUM_C, "void find"),
            base: lineOf(CSUM_C, "base: the sum is exact"),
            prune: lineOf(CSUM_C, "sorted: stop early"),
            reuse: lineOf(CSUM_C, "same i: reuse"),
          };
          return combinationSumSteps(nums, target, L);
        },
      },
    ],
  });
})();
