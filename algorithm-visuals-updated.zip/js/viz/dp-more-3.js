/* ============================================================
   DSA Visuals — Dynamic Programming III
   Envelope nesting, interval DP, string partitioning, boolean
   evaluation, egg dropping and regular expression matching.
   ============================================================ */
(function () {
  "use strict";
  const { count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const partsOf = (text) => String(text || "").split("|").map((p) => p.trim());
  const intsOf = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number).filter(Number.isFinite);

  /* ---------------------------------------------------------- */
  V.register({
    id: "russian-doll-envelopes",
    title: "Russian Doll Envelopes",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Find the largest number of envelopes that can be nested inside one another.",
    input: { label: "Envelopes as width,height separated by |", default: "5,4 | 6,4 | 6,7 | 2,3", parse: "string" },
    approaches: [
      {
        name: "Sort Then Longest Increasing Subsequence",
        complexity: "O(n log n) time",
        idea: [
          "Sort envelopes by width ascending. Equal widths are sorted by height descending, so an envelope cannot nest inside another of the same width.",
          "The answer is now the longest strictly increasing subsequence of heights. Keeping the smallest possible tail for each subsequence length allows binary search.",
        ],
        problem: [
          "Nesting is two-dimensional; sorting converts it to a one-dimensional LIS but equal widths need a careful tie-break.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <stdlib.h>\\n\\ntypedef struct { int w, h; } Env;\\nint cmp(const void *a, const void *b) {\\n    Env x = *(Env*)a, y = *(Env*)b;\\n    if (x.w != y.w) return x.w - y.w;\\n    return y.h - x.h;\\n}\\n\\nint main(void) {\\n    Env e[] = {{5,4},{6,4},{6,7},{2,3}};\\n    int n = 4, tails[4], len = 0;\\n    qsort(e, n, sizeof(Env), cmp);\\n\\n    for (int i = 0; i < n; i++) {\\n        int lo = 0, hi = len;\\n        while (lo < hi) { int mid = (lo + hi) / 2; if (tails[mid] < e[i].h) lo = mid + 1; else hi = mid; }\\n        tails[lo] = e[i].h;\\n        if (lo == len) len++;\\n    }\\n    printf(\\\"%d\\\\n\\\", len); /* 3 */\\n    return 0;\\n}`,
          cpp: `#include <algorithm>\\n#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint maxEnvelopes(vector<pair<int,int>>& env) {\\n    sort(env.begin(), env.end(), [](auto& a, auto& b) {\\n        return a.first != b.first ? a.first < b.first : a.second > b.second;\\n    });\\n    vector<int> tails;\\n    for (auto& e : env) {\\n        auto it = lower_bound(tails.begin(), tails.end(), e.second);\\n        if (it == tails.end()) tails.push_back(e.second);\\n        else *it = e.second;\\n    }\\n    return tails.size();\\n}\\n\\nint main() {\\n    vector<pair<int,int>> e{{5,4},{6,4},{6,7},{2,3}};\\n    cout << maxEnvelopes(e) << '\\\\n'; // 3\\n}`,
        },
        steps(text) {
          const env = partsOf(text).map((p) => p.split(",").map(Number).filter(Number.isFinite)).filter((p) => p.length >= 2 && p[0] > 0 && p[1] > 0).slice(0, 12).map(([w, h]) => ({ w, h }));
          if (!env.length) return [{
            title: "Give envelopes as width,height pairs",
            tracks: [chips("envelopes", ["—"], "idle")],
            counters: [count("nested", 0)],
            legend: LEG,
            happened: "There are no valid envelopes.",
            why: "Each envelope needs a positive width and height.",
          }];
          env.sort((a, b) => (a.w !== b.w ? a.w - b.w : b.h - a.h));
          const heights = env.map((e) => e.h);
          const tails = [];
          const steps = [];
          const labels = env.map((e) => `${e.w}×${e.h}`);
          const tailShow = (t) => (t.length ? t : ["—"]);
          steps.push({
            title: `Sorted ${env.length} envelopes by width, then height descending`,
            tracks: [chips("sorted", labels, "compare"), chips("heights", heights, "idle")],
            counters: [count("envelopes", env.length), count("nested", 0)],
            legend: LEG,
            happened: labels.join(", "),
            why: "Descending heights within a width prevents two equal-width envelopes from nesting.",
            codeLine: 7,
          });
          env.forEach((e, idx) => {
            let lo = 0, hi = tails.length;
            while (lo < hi) { const mid = (lo + hi) >> 1; if (tails[mid] < e.h) lo = mid + 1; else hi = mid; }
            const replaced = lo < tails.length;
            tails[lo] = e.h;
            steps.push({
              title: `Height ${e.h} ${replaced ? `replaces tail ${lo + 1}` : `extends the chain to ${tails.length}`}`,
              tracks: [chips("sorted", labels, (i) => (i === idx ? "active" : i < idx ? "done" : "idle")), chips("tails", tailShow(tails), (i) => (i === lo ? (replaced ? "compare" : "result") : "done"))],
              counters: [count("nested", tails.length), count("envelope", idx + 1, env.length)],
              legend: LEG,
              happened: `Tails are now ${tails.join(", ")}; the best nesting has length ${tails.length}.`,
              why: "A smaller tail leaves more room for later, taller envelopes without changing the chain length.",
              codeLine: 13,
            });
          });
          steps.push({
            title: `Answer: ${tails.length} nested envelopes`,
            tracks: [chips("sorted", labels, "done"), chips("tails", tailShow(tails), "result")],
            counters: [count("nested", tails.length), count("envelopes", env.length)],
            legend: LEG,
            happened: `The longest strictly increasing height chain has length ${tails.length}.`,
            why: "Each height in the chain fits a strictly wider envelope, so the corresponding envelopes nest.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "matrix-chain-multiplication",
    title: "Matrix Chain Multiplication",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Choose the parenthesisation that minimises scalar multiplications.",
    input: { label: "Dimensions (n+1 values for n matrices)", default: "10,30,5,60", parse: "string" },
    approaches: [
      {
        name: "Interval DP on Matrix Ranges",
        complexity: "O(n³) time",
        idea: [
          "A chain from matrix i to matrix j is split at some k. The cost is the best cost for i..k, plus the best cost for k+1..j, plus the cost of multiplying the two resulting matrices.",
          "Solving short ranges first makes every subrange cost available when a longer range is considered. The split point with the smallest total wins.",
        ],
        problem: [
          "The number of parenthesisations grows exponentially, and different orders can differ by orders of magnitude in cost.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int d[] = {10,30,5,60}, n = 3;\\n    int dp[3][3] = {0};\\n\\n    for (int len = 2; len <= n; len++)\\n        for (int i = 0; i + len <= n; i++) {\\n            int j = i + len - 1;\\n            dp[i][j] = 1 << 30;\\n            for (int k = i; k < j; k++) {\\n                int cost = dp[i][k] + dp[k+1][j] + d[i]*d[k+1]*d[j+1];\\n                if (cost < dp[i][j]) dp[i][j] = cost;\\n            }\\n        }\\n\\n    printf(\\\"%d\\\\n\\\", dp[0][n-1]); /* 4500 */\\n    return 0;\\n}`,
          cpp: `#include <climits>\\n#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint matrixChain(vector<int>& d) {\\n    int n = d.size() - 1;\\n    vector<vector<int>> dp(n, vector<int>(n, 0));\\n    for (int len = 2; len <= n; len++)\\n        for (int i = 0; i + len <= n; i++) {\\n            int j = i + len - 1;\\n            dp[i][j] = INT_MAX;\\n            for (int k = i; k < j; k++)\\n                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + d[i]*d[k+1]*d[j+1]);\\n        }\\n    return dp[0][n-1];\\n}\\n\\nint main() {\\n    vector<int> d{10,30,5,60};\\n    cout << matrixChain(d) << '\\\\n'; // 4500\\n}`,
        },
        steps(text) {
          const d = intsOf(text).filter((x) => x > 0).slice(0, 8);
          if (d.length < 3) return [{
            title: "Give at least three dimensions",
            tracks: [chips("dimensions", d.length ? d : ["—"], "idle")],
            counters: [count("cost", 0)],
            legend: LEG,
            happened: "At least two matrices are needed.",
            why: "A chain of one matrix has nothing to multiply.",
          }];
          const n = d.length - 1;
          const dp = Array.from({ length: n }, () => Array(n).fill(0));
          const split = Array.from({ length: n }, () => Array(n).fill(-1));
          const steps = [];
          const cells = (len) => grid(n, n, (i, j) => {
            if (j < i) return { v: "·", state: "dim" };
            const isDiagonal = i === j;
            const isCurrent = j - i + 1 === len;
            return { v: isDiagonal ? 0 : dp[i][j], state: isCurrent ? "read" : j - i + 1 < len ? "done" : "idle" };
          });
          steps.push({
            title: `${n} matrices with dimensions ${d.join(" × ")}`,
            kind: "grid", rows: n, cols: n,
            rowHeads: Array.from({ length: n }, (_, i) => `A${i + 1}`),
            colHeads: Array.from({ length: n }, (_, j) => `A${j + 1}`),
            cells: cells(1),
            counters: [count("matrices", n), count("cost", 0)],
            legend: LEG,
            happened: "A single matrix needs no multiplication, so the diagonal is zero.",
            why: "The table stores costs for contiguous ranges of matrices.",
            codeLine: 4,
          });
          for (let len = 2; len <= n; len++) {
            for (let i = 0; i + len <= n; i++) {
              const j = i + len - 1;
              dp[i][j] = Infinity;
              for (let k = i; k < j; k++) {
                const cost = dp[i][k] + dp[k + 1][j] + d[i] * d[k + 1] * d[j + 1];
                if (cost < dp[i][j]) { dp[i][j] = cost; split[i][j] = k; }
              }
            }
            const range = `A${1}..A${n}`;
            steps.push({
              title: `Chains of ${len} matrices: smallest cost ${dp[0][n - 1] || "—"}`,
              kind: "grid", rows: n, cols: n,
              rowHeads: Array.from({ length: n }, (_, i) => `A${i + 1}`),
              colHeads: Array.from({ length: n }, (_, j) => `A${j + 1}`),
              cells: cells(len),
              counters: [count("chain length", len, n), count("cost", dp[0][n - 1] === Infinity ? 0 : dp[0][n - 1])],
              legend: LEG,
              happened: `Every length-${len} range tried all internal split points.`,
              why: "A split at k multiplies the resulting left and right matrices, whose costs are already optimal.",
              codeLine: 10,
            });
          }
          steps.push({
            title: `Answer: minimum cost ${dp[0][n - 1]}`,
            kind: "grid", rows: n, cols: n,
            rowHeads: Array.from({ length: n }, (_, i) => `A${i + 1}`),
            colHeads: Array.from({ length: n }, (_, j) => `A${j + 1}`),
            cells: grid(n, n, (i, j) => ({ v: j < i ? "·" : dp[i][j], state: j < i ? "dim" : i === 0 && j === n - 1 ? "result" : "done" })),
            counters: [count("cost", dp[0][n - 1]), count("matrices", n)],
            legend: LEG,
            happened: `The full chain costs ${dp[0][n - 1]} scalar multiplications.`,
            why: "The top-right cell represents the entire chain and was minimised over every first split.",
            codeLine: 17,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "burst-balloons",
    title: "Burst Balloons",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Burst balloons in an order that maximises the coins collected.",
    input: { label: "Balloon values", default: "3,1,5,8", parse: "string" },
    approaches: [
      {
        name: "Choose the Last Balloon in a Range",
        complexity: "O(n³) time",
        idea: [
          "Pad the row with 1s at both ends. For an interval, decide which balloon bursts last; by then only the interval's two boundary neighbours remain.",
          "That last balloon earns left × value × right, and the two sides of the interval are independent subproblems. Trying every last balloon finds the best order.",
        ],
        problem: [
          "Choosing the first balloon to burst changes both neighbours, so a forward greedy order has no reliable local rule.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int a[] = {3,1,5,8}, n = 4;\\n    int v[6] = {1,3,1,5,8,1};\\n    int dp[6][6] = {0};\\n\\n    for (int len = 1; len <= n; len++)\\n        for (int i = 1; i + len - 1 <= n; i++) {\\n            int j = i + len - 1;\\n            for (int k = i; k <= j; k++) {\\n                int coins = dp[i][k-1] + dp[k+1][j] + v[i-1]*v[k]*v[j+1];\\n                if (coins > dp[i][j]) dp[i][j] = coins;\\n            }\\n        }\\n\\n    printf(\\\"%d\\\\n\\\", dp[1][n]); /* 167 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint maxCoins(vector<int>& a) {\\n    vector<int> v{1};\\n    v.insert(v.end(), a.begin(), a.end());\\n    v.push_back(1);\\n    int n = a.size();\\n    vector<vector<int>> dp(n + 2, vector<int>(n + 2, 0));\\n    for (int len = 1; len <= n; len++)\\n        for (int i = 1; i + len - 1 <= n; i++) {\\n            int j = i + len - 1;\\n            for (int k = i; k <= j; k++)\\n                dp[i][j] = max(dp[i][j], dp[i][k-1] + dp[k+1][j] + v[i-1]*v[k]*v[j+1]);\\n        }\\n    return dp[1][n];\\n}\\n\\nint main() {\\n    vector<int> a{3,1,5,8};\\n    cout << maxCoins(a) << '\\\\n'; // 167\\n}`,
        },
        steps(text) {
          const nums = intsOf(text).filter((x) => x >= 0).slice(0, 7);
          if (!nums.length) return [{
            title: "Give balloon values",
            tracks: [chips("balloons", ["—"], "idle")],
            counters: [count("coins", 0)],
            legend: LEG,
            happened: "There are no balloons.",
            why: "Bursting needs at least one balloon.",
          }];
          const n = nums.length;
          const v = [1, ...nums, 1];
          const dp = Array.from({ length: n + 2 }, () => Array(n + 2).fill(0));
          const steps = [];
          const cells = (len) => grid(n + 2, n + 2, (i, j) => {
            if (i === 0 || j === 0 || i === n + 1 || j === n + 1 || j < i) return { v: "·", state: "dim" };
            const width = j - i + 1;
            return { v: dp[i][j], state: width === len ? "read" : width < len ? "done" : "idle" };
          });
          steps.push({
            title: `Balloons ${nums.join(", ")} with sentinel 1s at both ends`,
            kind: "grid", rows: n + 2, cols: n + 2,
            rowHeads: v.map((x) => String(x)),
            colHeads: v.map((x) => String(x)),
            cells: cells(1),
            counters: [count("balloons", n), count("coins", 0)],
            legend: LEG,
            happened: "The sentinels act as permanent neighbours beyond the row.",
            why: "They let an interval's last balloon use virtual boundary values of 1.",
            codeLine: 5,
          });
          for (let len = 1; len <= n; len++) {
            for (let i = 1; i + len - 1 <= n; i++) {
              const j = i + len - 1;
              for (let k = i; k <= j; k++) {
                const coins = dp[i][k - 1] + dp[k + 1][j] + v[i - 1] * v[k] * v[j + 1];
                if (coins > dp[i][j]) dp[i][j] = coins;
              }
            }
            steps.push({
              title: `Intervals of ${len} balloon${len === 1 ? "" : "s"}: best ${dp[1][n] || "—"}`,
              kind: "grid", rows: n + 2, cols: n + 2,
              rowHeads: v.map((x) => String(x)),
              colHeads: v.map((x) => String(x)),
              cells: cells(len),
              counters: [count("coins", dp[1][n]), count("width", len, n)],
              legend: LEG,
              happened: `For each interval, every balloon was tried as the one burst last.`,
              why: "Bursting the last balloon leaves its left and right sides independent.",
              codeLine: 11,
            });
          }
          steps.push({
            title: `Answer: ${dp[1][n]} coins`,
            kind: "grid", rows: n + 2, cols: n + 2,
            rowHeads: v.map((x) => String(x)),
            colHeads: v.map((x) => String(x)),
            cells: grid(n + 2, n + 2, (i, j) => ({ v: i === 0 || j === 0 || i === n + 1 || j === n + 1 || j < i ? "·" : dp[i][j], state: i === 1 && j === n ? "result" : "done" })),
            counters: [count("coins", dp[1][n]), count("balloons", n)],
            legend: LEG,
            happened: `The whole row earns ${dp[1][n]} coins.`,
            why: "The full interval's value covers every possible last balloon recursively.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "palindrome-partitioning-ii",
    title: "Palindrome Partitioning II",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Split a string into palindromic pieces using the fewest cuts.",
    input: { label: "String", default: "aab", parse: "string" },
    approaches: [
      {
        name: "Fewest Cuts for Each Prefix",
        complexity: "O(n²) time",
        idea: [
          "cuts[i] is the fewest cuts needed for the first i characters. If the whole prefix is a palindrome, it needs zero cuts.",
          "Otherwise, try every earlier split point j: when s[j..i−1] is a palindrome, cuts[i] can be cuts[j] + 1. A precomputed palindrome table makes each check constant time.",
        ],
        problem: [
          "Greedily cutting the longest palindrome can leave a suffix that needs many extra cuts.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <string.h>\\n\\nint main(void) {\\n    char s[] = \\\"aab\\\";\\n    int n = strlen(s);\\n    int pal[8][8] = {0}, cuts[9];\\n\\n    for (int i = 0; i < n; i++)\\n        for (int j = 0; j <= i; j++)\\n            if (s[i] == s[j] && (i - j < 2 || pal[j+1][i-1])) pal[j][i] = 1;\\n\\n    cuts[0] = 0;\\n    for (int i = 1; i <= n; i++) {\\n        cuts[i] = i - 1;\\n        if (pal[0][i-1]) cuts[i] = 0;\\n        for (int j = 1; j < i; j++)\\n            if (pal[j][i-1] && cuts[j] + 1 < cuts[i]) cuts[i] = cuts[j] + 1;\\n    }\\n\\n    printf(\\\"%d\\\\n\\\", cuts[n]); /* 1 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <string>\\n#include <vector>\\nusing namespace std;\\n\\nint minCut(string s) {\\n    int n = s.size();\\n    vector<vector<bool>> pal(n, vector<bool>(n, false));\\n    for (int i = 0; i < n; i++)\\n        for (int j = 0; j <= i; j++)\\n            if (s[i] == s[j] && (i - j < 2 || pal[j+1][i-1])) pal[j][i] = true;\\n    vector<int> cuts(n + 1, 0);\\n    for (int i = 1; i <= n; i++) {\\n        cuts[i] = i - 1;\\n        if (pal[0][i-1]) cuts[i] = 0;\\n        for (int j = 1; j < i; j++)\\n            if (pal[j][i-1]) cuts[i] = min(cuts[i], cuts[j] + 1);\\n    }\\n    return cuts[n];\\n}\\n\\nint main() {\\n    cout << minCut(\\\"aab\\\") << '\\\\n'; // 1\\n}`,
        },
        steps(text) {
          const s = String(text || "").replace(/\s/g, "").slice(0, 16);
          if (!s) return [{
            title: "Give a string",
            tracks: [chips("string", ["—"], "idle")],
            counters: [count("cuts", 0)],
            legend: LEG,
            happened: "There is nothing to partition.",
            why: "A partition needs at least one character.",
          }];
          const n = s.length;
          const pal = Array.from({ length: n }, () => Array(n).fill(false));
          const cuts = Array(n + 1).fill(0);
          for (let i = 0; i < n; i++) {
            for (let j = 0; j <= i; j++) {
              if (s[i] === s[j] && (i - j < 2 || pal[j + 1][i - 1])) pal[j][i] = true;
            }
          }
          const steps = [];
          steps.push({
            title: `Fewest cuts for "${s}"`,
            tracks: [chips("string", s.split(""), "compare"), chips("cuts", cuts, (i) => (i === 0 ? "result" : "dim"))],
            counters: [count("length", n), count("cuts", 0)],
            legend: LEG,
            happened: "The empty prefix needs no cuts.",
            why: "cuts[i] will store the best answer for the first i characters.",
            codeLine: 4,
          });
          for (let i = 1; i <= n; i++) {
            cuts[i] = i - 1;
            let bestStart = -1;
            if (pal[0][i - 1]) { cuts[i] = 0; bestStart = 0; }
            for (let j = 1; j < i; j++) {
              if (pal[j][i - 1] && cuts[j] + 1 < cuts[i]) { cuts[i] = cuts[j] + 1; bestStart = j; }
            }
            steps.push({
              title: `Prefix "${s.slice(0, i)}": ${cuts[i]} cut${cuts[i] === 1 ? "" : "s"}`,
              tracks: [chips("string", s.split(""), (j) => (j < i ? (j === bestStart ? "active" : "done") : "dim")), chips("cuts", cuts, (k) => (k === i ? "read" : k < i ? "done" : "dim"))],
              counters: [count("cuts", cuts[i]), count("prefix", i, n)],
              legend: LEG,
              happened: bestStart >= 0 ? `The last piece starts at ${bestStart} and is a palindrome.` : `The whole prefix "${s.slice(0, i)}" is already a palindrome.`,
              why: "A palindromic last piece adds one cut to the best partition of the prefix before it.",
              codeLine: 15,
            });
          }
          steps.push({
            title: `Answer: ${cuts[n]} cut${cuts[n] === 1 ? "" : "s"}`,
            tracks: [chips("string", s.split(""), "done"), chips("cuts", cuts, (i) => (i === n ? "result" : "done"))],
            counters: [count("cuts", cuts[n]), count("length", n)],
            legend: LEG,
            happened: `"${s}" needs ${cuts[n]} cut${cuts[n] === 1 ? "" : "s"} to become palindromic pieces.`,
            why: "The full prefix entry is the minimum over every possible final palindromic piece.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "boolean-parenthesization",
    title: "Boolean Parenthesisation",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Count parenthesisation of a boolean expression that evaluate to true.",
    input: { label: "Expression of T/F with & | ^", default: "T|F&T", parse: "string" },
    approaches: [
      {
        name: "True and False Ways per Interval",
        complexity: "O(n³) time",
        idea: [
          "For every interval of operands, store how many parenthesisation make it true and how many make it false.",
          "At each split, combine the left and right counts according to the operator: AND needs both true, OR needs at least one true, and XOR needs exactly one true. Trying every split sums all parenthesisation.",
        ],
        problem: [
          "An expression's truth value cannot be decided without knowing which side of the operator is grouped first.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    char op[] = \\\"|&\\\";\\n    int T[] = {1,0,1}, F[] = {0,1,0}, n = 3;\\n    int tw[3][3] = {0}, fw[3][3] = {0};\\n\\n    for (int i = 0; i < n; i++) { tw[i][i] = T[i]; fw[i][i] = F[i]; }\\n    for (int len = 2; len <= n; len++)\\n        for (int i = 0; i + len <= n; i++) {\\n            int j = i + len - 1;\\n            for (int k = i; k < j; k++) {\\n                int lt = tw[i][k], lf = fw[i][k], rt = tw[k+1][j], rf = fw[k+1][j];\\n                if (op[k] == '&') { tw[i][j] += lt*rt; fw[i][j] += lt*rf + lf*rt + lf*rf; }\\n                if (op[k] == '|') { tw[i][j] += lt*rt + lt*rf + lf*rt; fw[i][j] += lf*rf; }\\n                if (op[k] == '^') { tw[i][j] += lt*rf + lf*rt; fw[i][j] += lt*rt + lf*rf; }\\n            }\\n        }\\n\\n    printf(\\\"%d\\\\n\\\", tw[0][n-1]); /* 2 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <string>\\n#include <vector>\\nusing namespace std;\\n\\nint countWays(string s) {\\n    vector<char> val, op;\\n    for (char c : s) {\\n        if (c == 'T' || c == 'F') val.push_back(c);\\n        else if (c == '&' || c == '|' || c == '^') op.push_back(c);\\n    }\\n    int n = val.size();\\n    vector<vector<int>> T(n, vector<int>(n, 0)), F(n, vector<int>(n, 0));\\n    for (int i = 0; i < n; i++) { T[i][i] = val[i] == 'T'; F[i][i] = val[i] == 'F'; }\\n    for (int len = 2; len <= n; len++)\\n        for (int i = 0; i + len <= n; i++) {\\n            int j = i + len - 1;\\n            for (int k = i; k < j; k++) {\\n                int lt = T[i][k], lf = F[i][k], rt = T[k+1][j], rf = F[k+1][j];\\n                if (op[k] == '&') { T[i][j] += lt*rt; F[i][j] += lt*rf + lf*rt + lf*rf; }\\n                if (op[k] == '|') { T[i][j] += lt*rt + lt*rf + lf*rt; F[i][j] += lf*rf; }\\n                if (op[k] == '^') { T[i][j] += lt*rf + lf*rt; F[i][j] += lt*rt + lf*rf; }\\n            }\\n        }\\n    return T[0][n-1];\\n}\\n\\nint main() {\\n    cout << countWays(\\\"T|F&T\\\") << '\\\\n'; // 2\\n}`,
        },
        steps(text) {
          const raw = String(text || "").toUpperCase().replace(/[^TF&|^]/g, "");
          const vals = raw.split("").filter((c) => c === "T" || c === "F");
          const ops = raw.split("").filter((c) => c === "&" || c === "|" || c === "^");
          if (!vals.length) return [{
            title: "Give a boolean expression",
            tracks: [chips("expression", ["—"], "idle")],
            counters: [count("true ways", 0)],
            legend: LEG,
            happened: "There are no operands.",
            why: "The expression needs T/F values joined by &, | or ^.",
          }];
          const n = vals.length;
          const T = Array.from({ length: n }, () => Array(n).fill(0));
          const F = Array.from({ length: n }, () => Array(n).fill(0));
          for (let i = 0; i < n; i++) { T[i][i] = vals[i] === "T" ? 1 : 0; F[i][i] = vals[i] === "F" ? 1 : 0; }
          const steps = [];
          const cells = (len) => grid(n, n, (i, j) => {
            if (j < i) return { v: "·", state: "dim" };
            const width = j - i + 1;
            return { v: `${T[i][j]}/${F[i][j]}`, state: width === len ? "read" : width < len ? "done" : "idle" };
          });
          steps.push({
            title: `Expression ${vals.map((v, i) => (i < ops.length ? v + ops[i] : v)).join("")}`,
            kind: "grid", rows: n, cols: n,
            rowHeads: vals, colHeads: vals,
            cells: cells(1),
            counters: [count("operands", n), count("operators", ops.length)],
            legend: LEG,
            happened: "Single operands have one true way or one false way.",
            why: "Each cell will show true/false parenthesisation counts for its operand interval.",
            codeLine: 4,
          });
          for (let len = 2; len <= n; len++) {
            for (let i = 0; i + len <= n; i++) {
              const j = i + len - 1;
              for (let k = i; k < j; k++) {
                const lt = T[i][k], lf = F[i][k], rt = T[k + 1][j], rf = F[k + 1][j];
                if (ops[k] === "&") { T[i][j] += lt * rt; F[i][j] += lt * rf + lf * rt + lf * rf; }
                if (ops[k] === "|") { T[i][j] += lt * rt + lt * rf + lf * rt; F[i][j] += lf * rf; }
                if (ops[k] === "^") { T[i][j] += lt * rf + lf * rt; F[i][j] += lt * rt + lf * rf; }
              }
            }
            steps.push({
              title: `Intervals of ${len} operands`,
              kind: "grid", rows: n, cols: n,
              rowHeads: vals, colHeads: vals,
              cells: cells(len),
              counters: [count("true ways", T[0][n - 1]), count("false ways", F[0][n - 1])],
              legend: LEG,
              happened: `Split points were combined with ${ops.slice(0, n - 1).join(", ")}.`,
              why: "Each split combines the true/false counts of its left and right subexpressions.",
              codeLine: 10,
            });
          }
          steps.push({
            title: `Answer: ${T[0][n - 1]} true parenthesisation${T[0][n - 1] === 1 ? "" : "s"}`,
            kind: "grid", rows: n, cols: n,
            rowHeads: vals, colHeads: vals,
            cells: grid(n, n, (i, j) => ({ v: j < i ? "·" : `${T[i][j]}/${F[i][j]}`, state: i === 0 && j === n - 1 ? "result" : "done" })),
            counters: [count("true ways", T[0][n - 1]), count("false ways", F[0][n - 1])],
            legend: LEG,
            happened: "The top-right cell counts every parenthesisation of the full expression that evaluates to true.",
            why: "The interval spans all operands, and both operator outcomes were accumulated exactly once per split.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "egg-dropping",
    title: "Egg Dropping",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Find the minimum worst-case drops needed to determine the highest safe floor.",
    input: { label: "Eggs | floors", default: "2 | 10", parse: "string" },
    approaches: [
      {
        name: "Worst-Case Trials Table",
        complexity: "O(eggs × floors²) time",
        idea: [
          "trials[e][f] is the minimum worst-case number of drops with e eggs and f floors. Dropping from floor x either breaks the egg (solve e−1 eggs below) or does not (solve e eggs above), and the worst of the two is taken.",
          "The answer is one plus the best such worst case over all x. With one egg the answer is f, because floors must be checked from the bottom.",
        ],
        problem: [
          "Binary search is wrong for limited eggs: a break consumes an egg, and the worst case can be worse than half the floors.",
        ],
        code: {
          c: `#include <stdio.h>\\n\\nint main(void) {\\n    int E = 2, F = 10;\\n    int dp[3][11];\\n\\n    for (int f = 0; f <= F; f++) dp[1][f] = f;\\n    for (int e = 0; e <= E; e++) dp[e][0] = 0;\\n\\n    for (int e = 2; e <= E; e++)\\n        for (int f = 1; f <= F; f++) {\\n            dp[e][f] = 1 << 30;\\n            for (int x = 1; x <= f; x++) {\\n                int worst = dp[e-1][x-1] > dp[e][f-x] ? dp[e-1][x-1] : dp[e][f-x];\\n                if (1 + worst < dp[e][f]) dp[e][f] = 1 + worst;\\n            }\\n        }\\n\\n    printf(\\\"%d\\\\n\\\", dp[E][F]); /* 4 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <vector>\\nusing namespace std;\\n\\nint superEggDrop(int eggs, int floors) {\\n    vector<vector<int>> dp(eggs + 1, vector<int>(floors + 1, 0));\\n    for (int f = 0; f <= floors; f++) dp[1][f] = f;\\n    for (int e = 2; e <= eggs; e++)\\n        for (int f = 1; f <= floors; f++) {\\n            dp[e][f] = INT_MAX;\\n            for (int x = 1; x <= f; x++)\\n                dp[e][f] = min(dp[e][f], 1 + max(dp[e-1][x-1], dp[e][f-x]));\\n        }\\n    return dp[eggs][floors];\\n}\\n\\nint main() {\\n    cout << superEggDrop(2, 10) << '\\\\n'; // 4\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const eggs = Math.min(4, Math.max(1, parseInt(parts[0], 10) || 2));
          const floors = Math.min(20, Math.max(1, parseInt(parts[1], 10) || 10));
          const dp = Array.from({ length: eggs + 1 }, () => Array(floors + 1).fill(0));
          for (let f = 0; f <= floors; f++) dp[1][f] = f;
          const steps = [];
          const cells = (curE) => grid(eggs + 1, floors + 1, (e, f) => ({
            v: e === 0 || f === 0 ? 0 : dp[e][f],
            state: e === curE ? "read" : e < curE || e === 1 ? "done" : "idle",
          }));
          steps.push({
            title: `${eggs} egg${eggs === 1 ? "" : "s"} and ${floors} floors`,
            kind: "grid", rows: eggs + 1, cols: floors + 1,
            rowHeads: Array.from({ length: eggs + 1 }, (_, e) => (e === 0 ? "0" : `${e} egg${e === 1 ? "" : "s"}`)),
            colHeads: Array.from({ length: floors + 1 }, (_, f) => String(f)),
            cells: cells(1),
            counters: [count("eggs", eggs), count("floors", floors)],
            legend: LEG,
            happened: "With one egg every floor may need a drop, so the first row equals the floor count.",
            why: "A broken egg cannot be reused, so a single egg forces a linear search from the bottom.",
            codeLine: 5,
          });
          for (let e = 2; e <= eggs; e++) {
            for (let f = 1; f <= floors; f++) {
              dp[e][f] = Infinity;
              for (let x = 1; x <= f; x++) {
                const worst = Math.max(dp[e - 1][x - 1], dp[e][f - x]);
                if (1 + worst < dp[e][f]) dp[e][f] = 1 + worst;
              }
            }
            steps.push({
              title: `${e} eggs: ${dp[e][floors]} drops cover ${floors} floors`,
              kind: "grid", rows: eggs + 1, cols: floors + 1,
              rowHeads: Array.from({ length: eggs + 1 }, (_, r) => (r === 0 ? "0" : `${r} egg${r === 1 ? "" : "s"}`)),
              colHeads: Array.from({ length: floors + 1 }, (_, f) => String(f)),
              cells: cells(e),
              counters: [count("drops", dp[e][floors]), count("eggs used", e, eggs)],
              legend: LEG,
              happened: `Row ${e} minimises the worse of the break and no-break branches.`,
              why: "The broken branch has one fewer egg below x; the intact branch keeps e eggs above x.",
              codeLine: 12,
            });
          }
          steps.push({
            title: `Answer: ${dp[eggs][floors]} drops in the worst case`,
            kind: "grid", rows: eggs + 1, cols: floors + 1,
            rowHeads: Array.from({ length: eggs + 1 }, (_, e) => (e === 0 ? "0" : `${e} egg${e === 1 ? "" : "s"}`)),
            colHeads: Array.from({ length: floors + 1 }, (_, f) => String(f)),
            cells: grid(eggs + 1, floors + 1, (e, f) => ({ v: e === 0 || f === 0 ? 0 : dp[e][f], state: e === eggs && f === floors ? "result" : "done" })),
            counters: [count("drops", dp[eggs][floors]), count("floors", floors)],
            legend: LEG,
            happened: `${eggs} eggs always identify the critical floor within ${dp[eggs][floors]} drops.`,
            why: "The bottom-right cell is the minimised worst case across every possible first drop.",
            codeLine: 18,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "regular-expression-matching",
    title: "Regular Expression Matching",
    category: "Dynamic Programming",
    difficulty: "Advanced",
    description: "Match a string against a pattern supporting . and *.",
    input: { label: "String | pattern", default: "aab | c*a*b", parse: "string" },
    approaches: [
      {
        name: "Prefix Match Table",
        complexity: "O(string length × pattern length) time",
        idea: [
          "match[i][j] is true when the first i characters match the first j pattern tokens. A dot matches any single character.",
          "A star can repeat zero times, which drops the preceding token, or one more time when the previous token matches the current character. The table fills left to right, top to bottom.",
        ],
        problem: [
          "A greedy expansion of * cannot know how many characters later tokens will need.",
        ],
        code: {
          c: `#include <stdio.h>\\n#include <string.h>\\n\\nint main(void) {\\n    char s[] = \\\"aab\\\", p[] = \\\"c*a*b\\\";\\n    int n = strlen(s), m = strlen(p);\\n    int dp[16][16] = {0};\\n    dp[0][0] = 1;\\n\\n    for (int j = 1; j <= m; j++)\\n        if (p[j-1] == '*' && dp[0][j-2]) dp[0][j] = 1;\\n\\n    for (int i = 1; i <= n; i++)\\n        for (int j = 1; j <= m; j++) {\\n            char pc = p[j-1];\\n            if (pc == '*') {\\n                if (dp[i][j-2]) dp[i][j] = 1;\\n                else if ((s[i-1] == p[j-2] || p[j-2] == '.') && dp[i-1][j]) dp[i][j] = 1;\\n            } else if (pc == '.' || pc == s[i-1]) dp[i][j] = dp[i-1][j-1];\\n        }\\n\\n    printf(\\\"%d\\\\n\\\", dp[n][m]); /* 1 */\\n    return 0;\\n}`,
          cpp: `#include <iostream>\\n#include <string>\\n#include <vector>\\nusing namespace std;\\n\\nbool isMatch(string s, string p) {\\n    int n = s.size(), m = p.size();\\n    vector<vector<bool>> dp(n + 1, vector<bool>(m + 1, false));\\n    dp[0][0] = true;\\n    for (int j = 1; j <= m; j++)\\n        if (p[j-1] == '*' && dp[0][j-2]) dp[0][j] = true;\\n    for (int i = 1; i <= n; i++)\\n        for (int j = 1; j <= m; j++) {\\n            char pc = p[j-1];\\n            if (pc == '*') {\\n                if (dp[i][j-2]) dp[i][j] = true;\\n                else if ((s[i-1] == p[j-2] || p[j-2] == '.') && dp[i-1][j]) dp[i][j] = true;\\n            } else if (pc == '.' || pc == s[i-1]) dp[i][j] = dp[i-1][j-1];\\n        }\\n    return dp[n][m];\\n}\\n\\nint main() {\\n    cout << (isMatch(\\\"aab\\\", \\\"c*a*b\\\") ? \\\"true\\\" : \\\"false\\\") << '\\\\n'; // true\\n}`,
        },
        steps(text) {
          const parts = partsOf(text);
          const s = String(parts[0] || "").slice(0, 12);
          const p = String(parts[1] || "").slice(0, 12);
          if (!p) return [{
            title: "Give a string and a pattern",
            tracks: [chips("string", s ? s.split("") : ["—"], "idle")],
            counters: [count("matched", 0)],
            legend: LEG,
            happened: "There is no pattern to match.",
            why: "Matching needs string and pattern characters.",
          }];
          const n = s.length, m = p.length;
          const dp = Array.from({ length: n + 1 }, () => Array(m + 1).fill(false));
          dp[0][0] = true;
          for (let j = 1; j <= m; j++) if (p[j - 1] === "*" && j >= 2 && dp[0][j - 2]) dp[0][j] = true;
          const steps = [];
          const cells = (curR) => grid(n + 1, m + 1, (i, j) => ({
            v: dp[i][j] ? "✓" : "·",
            state: i === curR ? "read" : i < curR ? "done" : "idle",
          }));
          steps.push({
            title: `Match "${s}" against "${p}"`,
            kind: "grid", rows: n + 1, cols: m + 1,
            rowHeads: ["ε", ...s.split("")], colHeads: ["ε", ...p.split("")],
            cells: cells(-1),
            counters: [count("string", n), count("pattern", m)],
            legend: LEG,
            happened: "The empty string matches the empty pattern.",
            why: "Each cell will record whether a prefix of the string matches a prefix of the pattern.",
            codeLine: 4,
          });
          for (let i = 1; i <= n; i++) {
            for (let j = 1; j <= m; j++) {
              const pc = p[j - 1];
              if (pc === "*") {
                if (dp[i][j - 2]) dp[i][j] = true;
                else if ((s[i - 1] === p[j - 2] || p[j - 2] === ".") && dp[i - 1][j]) dp[i][j] = true;
              } else if (pc === "." || pc === s[i - 1]) {
                dp[i][j] = dp[i - 1][j - 1];
              }
            }
            steps.push({
              title: `String prefix "${s.slice(0, i)}" against every pattern prefix`,
              kind: "grid", rows: n + 1, cols: m + 1,
              rowHeads: ["ε", ...s.split("")], colHeads: ["ε", ...p.split("")],
              cells: cells(i),
              counters: [count("matched prefixes", dp[i].filter(Boolean).length), count("row", i, n)],
              legend: LEG,
              happened: `Row ${i} compares ${s[i - 1]} with each pattern token.`,
              why: "A star either removes its token (two columns back) or repeats it using the row above.",
              codeLine: 14,
            });
          }
          steps.push({
            title: dp[n][m] ? "Answer: the pattern matches" : "Answer: the pattern does not match",
            kind: "grid", rows: n + 1, cols: m + 1,
            rowHeads: ["ε", ...s.split("")], colHeads: ["ε", ...p.split("")],
            cells: grid(n + 1, m + 1, (i, j) => ({ v: dp[i][j] ? "✓" : "·", state: i === n && j === m ? "result" : "done" })),
            counters: [count("matched", dp[n][m] ? 1 : 0), count("cells", (n + 1) * (m + 1))],
            legend: LEG,
            happened: dp[n][m] ? "The bottom-right cell shows a complete match." : "The bottom-right cell stayed empty.",
            why: "The final cell combines the full string and the full pattern.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });
})();
