/* ============================================================
   DSA Visuals — Sorting & Intervals
   Sweeps over time ranges, divide-and-conquer counting and
   distribution-based ordering.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const nums = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number);
  const show = (a) => `[${a.join(", ")}]`;

  function parsePairs(text) {
    return String(text || "")
      .split(/[\s|]+/)
      .filter(Boolean)
      .map((pair) => {
        const [a, b] = pair.split(/[,:]/).map(Number);
        return { start: a || 0, end: b || 0 };
      })
      .filter((p) => p.end >= p.start);
  }
  const span = (p) => `${p.start}–${p.end}`;

  /* ---------------------------------------------------------- */
  V.register({
    id: "meeting-rooms",
    title: "Meeting Rooms",
    category: "Sorting & Intervals",
    difficulty: "Beginner",
    description:
      "Decide whether one person can attend every meeting by checking whether any two ranges overlap.",
    input: { label: "start,end pairs", default: "0,30 5,10 15,20", parse: "pairs" },
    approaches: [
      {
        name: "Sort by Start",
        complexity: "O(n log n) time, O(1) extra space",
        idea: [
          "Sort the meetings by start time. Two meetings overlap exactly when the later start is before the earlier end.",
          "After sorting, only adjacent pairs need checking: if any adjacent pair overlaps, the whole set cannot fit one room.",
        ],
        problem: [
          "Touching intervals such as 0–10 and 10–20 are considered compatible, so the comparison must be strict.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int start, end; } Interval;
static int by_start(const void *a, const void *b) {
    return ((const Interval *)a)->start - ((const Interval *)b)->start;
}

int can_attend(Interval *m, int n) {
    qsort(m, n, sizeof(Interval), by_start);
    for (int i = 1; i < n; i++)
        if (m[i].start < m[i - 1].end) return 0;
    return 1;
}

int main(void) {
    Interval m[] = {{0,30},{5,10},{15,20}};
    printf("%d\\n", can_attend(m, 3)); /* 0 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool canAttendMeetings(vector<vector<int>> meetings) {
    sort(meetings.begin(), meetings.end());
    for (int i = 1; i < (int)meetings.size(); i++)
        if (meetings[i][0] < meetings[i - 1][1]) return false;
    return true;
}

int main() {
    cout << canAttendMeetings({{0,30},{5,10},{15,20}}) << '\\n'; // 0
}`,
        },
        steps(pairs) {
          const meetings = pairs.slice().sort((a, b) => a.start - b.start);
          const steps = [];
          if (!meetings.length) {
            return [{
              title: "No meetings, no conflicts",
              tracks: [chips("meetings", ["—"], "idle")],
              counters: [count("meetings", 0)],
              legend: ["idle", "result"],
              happened: "An empty schedule trivially fits one room.",
              why: "There are no pairs to compare.",
            }];
          }
          steps.push({
            title: `Sort ${meetings.length} meetings by start`,
            tracks: [chips("meetings", meetings.map(span), "dim")],
            counters: [count("meetings", meetings.length), count("checked", 0)],
            legend: LEG,
            happened: `Sorted order is ${meetings.map(span).join(", ")}.`,
            why: "After sorting, an overlap can only happen between neighbours in time.",
            codeLine: 7,
          });
          let conflict = -1;
          for (let i = 1; i < meetings.length; i++) {
            const prev = meetings[i - 1], cur = meetings[i];
            const overlap = cur.start < prev.end;
            if (overlap && conflict < 0) conflict = i;
            steps.push({
              title: `${span(cur)} ${overlap ? "starts before" : "starts after"} ${span(prev)} ends`,
              tracks: [
                chips("meetings", meetings.map(span), (k) => (k === i ? (overlap ? "bad" : "read") : k === i - 1 ? "compare" : k < i ? "done" : "dim")),
                chips("gap", [`${cur.start} ${overlap ? "<" : "≥"} ${prev.end}`], overlap ? "bad" : "good"),
              ],
              counters: [count("meetings", meetings.length), count("checked", i)],
              legend: LEG,
              happened: overlap ? "The new meeting begins while the previous one is still running." : "The previous meeting has ended, so both can be attended.",
              why: "Only the most recent end time matters for the next meeting.",
              codeLine: 8,
            });
            if (conflict >= 0) break;
          }
          steps.push({
            title: conflict >= 0 ? `Answer: no — ${span(meetings[conflict])} overlaps ${span(meetings[conflict - 1])}` : "Answer: yes, all meetings fit",
            tracks: [
              chips("meetings", meetings.map(span), (k) => (conflict >= 0 && (k === conflict || k === conflict - 1) ? "bad" : "done")),
              chips("answer", [conflict >= 0 ? "no" : "yes"], "result"),
            ],
            counters: [count("checked", meetings.length), count("answer", conflict >= 0 ? "no" : "yes")],
            legend: LEG,
            happened: conflict >= 0 ? "Two meetings demand the same room at the same time." : "Every meeting ends before the next begins.",
            why: "The sweep needs only one pass after sorting.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "meeting-rooms-ii",
    title: "Meeting Rooms II",
    category: "Sorting & Intervals",
    difficulty: "Intermediate",
    description:
      "Count the number of rooms needed for all meetings by tracking the earliest end time.",
    input: { label: "start,end pairs", default: "0,30 5,10 15,20", parse: "pairs" },
    approaches: [
      {
        name: "Sweep With a Min-Heap of Ends",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Sort meetings by start. Keep a min-heap of end times for rooms currently in use.",
          "Before starting a meeting, free every room whose meeting has already ended. Then take a room, or open a new one if none is free.",
        ],
        problem: [
          "Using a heap is not strictly necessary; sorting all start and end times separately yields the same peak with less code.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

static int asc(const void *a, const void *b) { return *(const int *)a - *(const int *)b; }

int min_rooms(int starts[], int ends[], int n) {
    qsort(starts, n, sizeof(int), asc);
    qsort(ends, n, sizeof(int), asc);

    int rooms = 0, best = 0, e = 0;
    for (int i = 0; i < n; i++) {
        while (e < n && ends[e] <= starts[i]) { rooms--; e++; }  /* free a room */
        rooms++;
        if (rooms > best) best = rooms;
    }
    return best;
}

int main(void) {
    int s[] = {0, 5, 15}, e[] = {30, 10, 20};
    printf("%d\\n", min_rooms(s, e, 3)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int minMeetingRooms(vector<vector<int>> meetings) {
    sort(meetings.begin(), meetings.end());

    priority_queue<int, vector<int>, greater<int>> ends;   // end times in use
    for (auto& m : meetings) {
        if (!ends.empty() && ends.top() <= m[0]) ends.pop();
        ends.push(m[1]);
    }
    return ends.size();
}

int main() {
    cout << minMeetingRooms({{0,30},{5,10},{15,20}}) << '\\n'; // 2
}`,
        },
        steps(pairs) {
          const meetings = pairs.slice().sort((a, b) => a.start - b.start);
          const steps = [];
          if (!meetings.length) {
            return [{
              title: "No meetings need no rooms",
              tracks: [chips("meetings", ["—"], "idle")],
              counters: [count("rooms", 0)],
              legend: ["idle", "result"],
              happened: "An empty schedule uses zero rooms.",
              why: "The peak room count is maintained while sweeping.",
            }];
          }
          const active = [];
          let peak = 0;
          steps.push({
            title: `Sort by start: ${meetings.map(span).join(", ")}`,
            tracks: [chips("meetings", meetings.map(span), "dim"), chips("rooms in use", ["—"], "idle")],
            counters: [count("rooms", 0), count("peak", 0)],
            legend: LEG,
            happened: "Rooms are released before each new meeting claims one.",
            why: "Only the earliest ending active meeting can free a room.",
            codeLine: 7,
          });
          for (const m of meetings) {
            let freed = null;
            while (active.length && active[0] <= m.start) {
              freed = active.shift();
            }
            active.push(m.end);
            active.sort((a, b) => a - b);
            peak = Math.max(peak, active.length);
            steps.push({
              title: `${span(m)}: ${freed != null ? `room freed at ${freed}, ` : ""}now ${active.length} room${active.length === 1 ? "" : "s"}`,
              tracks: [
                chips("meetings", meetings.map(span), (k) => (meetings[k] === m ? "read" : meetings[k].start < m.start ? "done" : "dim")),
                chips("active end times", active, "active"),
                chips("peak", [peak], "result"),
              ],
              counters: [count("rooms", active.length), count("peak", peak)],
              legend: LEG,
              happened: freed != null ? `A meeting ended by ${freed}, so its room is reusable.` : "No room is free, so a new one is opened.",
              why: "The heap of end times always exposes the room that frees up soonest.",
              codeLine: 8,
            });
          }
          steps.push({
            title: `Answer: ${peak} room${peak === 1 ? "" : "s"}`,
            tracks: [chips("peak rooms", [peak], "result")],
            counters: [count("meetings", meetings.length), count("answer", peak)],
            legend: LEG,
            happened: `At most ${peak} meetings ran at the same time.`,
            why: "The maximum simultaneous count is exactly the number of rooms required.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "minimum-number-of-arrows",
    title: "Minimum Number of Arrows",
    category: "Sorting & Intervals",
    difficulty: "Intermediate",
    description:
      "Burst all balloons with the fewest arrows by always shooting at the right edge of the current balloon.",
    input: { label: "start,end pairs", default: "10,16 2,8 1,6 7,12", parse: "pairs" },
    approaches: [
      {
        name: "Sort by End, Shoot at the Edge",
        complexity: "O(n log n) time, O(1) extra space",
        idea: [
          "An arrow at position x bursts every balloon whose range contains x. To share an arrow, aim as far right as possible.",
          "Sort by end time and shoot at the first balloon's end; skip every later balloon that already contains that point.",
        ],
        problem: [
          "Sorting by start does not work: the greedy choice depends on the earliest finishing balloon.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

typedef struct { int start, end; } Balloon;
static int by_end(const void *a, const void *b) {
    return ((const Balloon *)a)->end - ((const Balloon *)b)->end;
}

int min_arrows(Balloon *b, int n) {
    qsort(b, n, sizeof(Balloon), by_end);
    int arrows = 0, at = -1;

    for (int i = 0; i < n; i++)
        if (at < b[i].start) {          /* this balloon is not burst yet */
            arrows++;
            at = b[i].end;
        }
    return arrows;
}

int main(void) {
    Balloon b[] = {{10,16},{2,8},{1,6},{7,12}};
    printf("%d\\n", min_arrows(b, 4)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int findMinArrowShots(vector<vector<int>> balloons) {
    sort(balloons.begin(), balloons.end(), [](auto& a, auto& b) { return a[1] < b[1]; });

    int arrows = 0;
    long long at = LLONG_MIN;
    for (auto& b : balloons) {
        if (at < b[0]) { arrows++; at = b[1]; }
    }
    return arrows;
}

int main() {
    cout << findMinArrowShots({{10,16},{2,8},{1,6},{7,12}}) << '\\n'; // 2
}`,
        },
        steps(pairs) {
          const balloons = pairs.slice().sort((a, b) => a.end - b.end);
          const steps = [];
          if (!balloons.length) {
            return [{
              title: "No balloons need no arrows",
              tracks: [chips("balloons", ["—"], "idle")],
              counters: [count("arrows", 0)],
              legend: ["idle", "result"],
              happened: "An empty set is already burst.",
              why: "The sweep would never fire an arrow.",
            }];
          }
          let arrows = 0, at = -Infinity;
          steps.push({
            title: `Sort by right edge: ${balloons.map(span).join(", ")}`,
            tracks: [chips("balloons", balloons.map(span), "dim")],
            counters: [count("arrows", 0), count("position", "—")],
            legend: LEG,
            happened: "Aiming at a right edge maximises the chance of sharing the arrow.",
            why: "Every balloon ending earlier limits where the arrow can go.",
            codeLine: 7,
          });
          for (const b of balloons) {
            const hit = at >= b.start && at <= b.end;
            if (!hit) {
              arrows++;
              at = b.end;
            }
            steps.push({
              title: hit ? `${span(b)} already burst by the arrow at ${at}` : `Shoot at ${at}: bursts ${span(b)}`,
              tracks: [
                chips("balloons", balloons.map(span), (k) => (balloons[k] === b ? (hit ? "done" : "result") : balloons[k].end <= b.end ? "dim" : "idle")),
                chips("arrow", [at], "active"),
              ],
              counters: [count("arrows", arrows), count("position", at)],
              legend: LEG,
              happened: hit ? "This balloon contains the last arrow position." : `No arrow so far covers ${span(b)}, so another one is needed.`,
              why: "The earliest end is the last possible place an arrow can still hit this balloon.",
              codeLine: hit ? 10 : 9,
            });
          }
          steps.push({
            title: `Answer: ${arrows} arrow${arrows === 1 ? "" : "s"}`,
            tracks: [chips("arrows", [arrows], "result")],
            counters: [count("balloons", balloons.length), count("answer", arrows)],
            legend: LEG,
            happened: `${arrows} arrows cover every balloon.`,
            why: "Each arrow is placed only when an uncovered balloon first appears.",
            codeLine: 13,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "count-inversions",
    title: "Count Inversions",
    category: "Sorting Algorithms",
    difficulty: "Advanced",
    description:
      "Count pairs that are out of order using a merge sort that tallies cross-pairs while merging.",
    input: { label: "numbers", default: "2, 4, 1, 3, 5", parse: "ints" },
    approaches: [
      {
        name: "Merge and Count",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Split the row in half, count inversions inside each half, then count cross inversions while merging the two sorted halves.",
          "When the right half contributes a value smaller than the left head, every remaining left element forms an inversion with it.",
        ],
        problem: [
          "The count can reach n(n−1)/2, which overflows a 32-bit integer for large inputs.",
        ],
        code: {
          c: `#include <stdio.h>

long long merge_count(int *a, int *tmp, int lo, int hi) {
    if (hi - lo < 2) return 0;
    int mid = (lo + hi) / 2;
    long long total = merge_count(a, tmp, lo, mid) + merge_count(a, tmp, mid, hi);

    int i = lo, j = mid, k = lo;
    while (i < mid && j < hi) {
        if (a[i] <= a[j]) tmp[k++] = a[i++];
        else {
            tmp[k++] = a[j++];
            total += mid - i;          /* all remaining left values are larger */
        }
    }
    while (i < mid) tmp[k++] = a[i++];
    while (j < hi) tmp[k++] = a[j++];
    for (int t = lo; t < hi; t++) a[t] = tmp[t];
    return total;
}

int main(void) {
    int a[] = {2, 4, 1, 3, 5}, tmp[5];
    printf("%lld\\n", merge_count(a, tmp, 0, 5)); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

long long mergeCount(vector<int>& a, vector<int>& tmp, int lo, int hi) {
    if (hi - lo < 2) return 0;
    int mid = (lo + hi) / 2;
    long long total = mergeCount(a, tmp, lo, mid) + mergeCount(a, tmp, mid, hi);

    int i = lo, j = mid, k = lo;
    while (i < mid && j < hi) {
        if (a[i] <= a[j]) tmp[k++] = a[i++];
        else { tmp[k++] = a[j++]; total += mid - i; }
    }
    while (i < mid) tmp[k++] = a[i++];
    while (j < hi) tmp[k++] = a[j++];
    for (int t = lo; t < hi; t++) a[t] = tmp[t];
    return total;
}

int main() {
    vector<int> a{2, 4, 1, 3, 5}, tmp(a.size());
    cout << mergeCount(a, tmp, 0, a.size()) << '\\n'; // 3
}`,
        },
        steps(values) {
          const a = values.slice();
          const n = a.length;
          if (n < 2) {
            return [{
              title: "Inversions need at least two values",
              tracks: [track("numbers", a.length ? a : ["—"], fill(Math.max(1, n), "idle"))],
              counters: [count("inversions", 0)],
              legend: ["idle", "result"],
              happened: "A single value is never out of order.",
              why: "An inversion is a pair i < j with a[i] > a[j].",
            }];
          }
          const steps = [];
          let total = 0;
          steps.push({
            title: `${n} values: split until single items, counting on the way back`,
            tracks: [track("numbers", a, fill(n, "idle"))],
            counters: [count("inversions", 0, n * (n - 1) / 2), count("depth", 0)],
            legend: LEG,
            happened: `The row is ${show(a)}.`,
            why: "Each inversion is counted exactly once, in the merge where its halves meet.",
            codeLine: 3,
          });
          const sortCount = (lo, hi, depth) => {
            if (hi - lo < 2) return;
            const mid = Math.floor((lo + hi) / 2);
            sortCount(lo, mid, depth + 1);
            sortCount(mid, hi, depth + 1);
            const left = a.slice(lo, mid);
            const right = a.slice(mid, hi);
            const merged = [];
            let i = 0, j = 0, added = 0;
            while (i < left.length && j < right.length) {
              if (left[i] <= right[j]) merged.push(left[i++]);
              else {
                merged.push(right[j++]);
                added += left.length - i;
              }
            }
            while (i < left.length) merged.push(left[i++]);
            while (j < right.length) merged.push(right[j++]);
            total += added;
            for (let k = 0; k < merged.length; k++) a[lo + k] = merged[k];
            steps.push({
              title: `Merge ${show(left)} + ${show(right)}: +${added} inversion${added === 1 ? "" : "s"}`,
              tracks: [
                track("numbers", a, (k) => (k >= lo && k < hi ? "active" : "dim")),
                chips("left half", left, "done"),
                chips("right half", right, "compare"),
              ],
              counters: [count("inversions", total, Math.floor(n * (n - 1) / 2)), count("merge width", hi - lo)],
              legend: LEG,
              happened: added
                ? `Every remaining left value is larger than a right value taken here, adding ${added}.`
                : "The halves were already in order, so this merge added nothing.",
              why: "Both halves are sorted, so one comparison rules out a whole prefix of the other side.",
              codeLine: 9,
            });
          };
          sortCount(0, n, 0);
          steps.push({
            title: `Answer: ${total} inversion${total === 1 ? "" : "s"}`,
            tracks: [track("numbers", a, fill(n, "done")), chips("answer", [total], "result")],
            counters: [count("inversions", total, Math.floor(n * (n - 1) / 2)), count("answer", total)],
            legend: LEG,
            happened: `The sorted row is ${show(a)} and ${total} pairs were out of order.`,
            why: "Merge sort counts while sorting, so no pair needs a separate comparison.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "reverse-pairs",
    title: "Reverse Pairs",
    category: "Sorting Algorithms",
    difficulty: "Advanced",
    description:
      "Count pairs where an earlier value is more than twice a later value, using merge sort.",
    input: { label: "numbers", default: "1,3,2,3,1", parse: "ints" },
    approaches: [
      {
        name: "Merge Sort With a Two-Pointer Count",
        complexity: "O(n log n) time, O(n) space",
        idea: [
          "Before merging two sorted halves, count cross pairs with a pointer over the right half that only moves forward.",
          "Because both halves are sorted, the pointer never needs to rewind, so each merge counts in linear time.",
        ],
        problem: [
          "The condition a[i] > 2 × a[j] overflows a 32-bit int for large values and must use a wider type.",
        ],
        code: {
          c: `#include <stdio.h>

long long count_pairs(int *a, int *tmp, int lo, int hi) {
    if (hi - lo < 2) return 0;
    int mid = (lo + hi) / 2;
    long long total = count_pairs(a, tmp, lo, mid) + count_pairs(a, tmp, mid, hi);

    int j = mid;
    for (int i = lo; i < mid; i++) {
        while (j < hi && (long long)a[i] > 2LL * a[j]) j++;
        total += j - mid;
    }

    int i = lo, k = lo;
    j = mid;
    while (i < mid && j < hi) {
        if (a[i] <= a[j]) tmp[k++] = a[i++];
        else tmp[k++] = a[j++];
    }
    while (i < mid) tmp[k++] = a[i++];
    while (j < hi) tmp[k++] = a[j++];
    for (int t = lo; t < hi; t++) a[t] = tmp[t];
    return total;
}

int main(void) {
    int a[] = {1,3,2,3,1}, tmp[5];
    printf("%lld\\n", count_pairs(a, tmp, 0, 5)); /* 2 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
using namespace std;

long long countPairs(vector<int>& a, vector<int>& tmp, int lo, int hi) {
    if (hi - lo < 2) return 0;
    int mid = (lo + hi) / 2;
    long long total = countPairs(a, tmp, lo, mid) + countPairs(a, tmp, mid, hi);

    int j = mid;
    for (int i = lo; i < mid; i++) {
        while (j < hi && (long long)a[i] > 2LL * a[j]) j++;
        total += j - mid;
    }

    int i = lo;
    j = mid;
    int k = lo;
    while (i < mid && j < hi) {
        if (a[i] <= a[j]) tmp[k++] = a[i++];
        else tmp[k++] = a[j++];
    }
    while (i < mid) tmp[k++] = a[i++];
    while (j < hi) tmp[k++] = a[j++];
    for (int t = lo; t < hi; t++) a[t] = tmp[t];
    return total;
}

int main() {
    vector<int> a{1,3,2,3,1}, tmp(a.size());
    cout << countPairs(a, tmp, 0, a.size()) << '\\n'; // 2
}`,
        },
        steps(values) {
          const a = values.slice();
          const n = a.length;
          if (n < 2) {
            return [{
              title: "At least two values are needed",
              tracks: [track("numbers", a.length ? a : ["—"], fill(Math.max(1, n), "idle"))],
              counters: [count("reverse pairs", 0)],
              legend: ["idle", "result"],
              happened: "A pair needs an earlier and a later value.",
              why: "The condition is a[i] > 2 × a[j] with i < j.",
            }];
          }
          const steps = [];
          let total = 0;
          steps.push({
            title: `${n} values; count pairs where the earlier is more than twice the later`,
            tracks: [track("numbers", a, fill(n, "idle"))],
            counters: [count("reverse pairs", 0), count("merge width", n)],
            legend: LEG,
            happened: `The row is ${show(a)}.`,
            why: "Sorting the halves first lets one forward pointer count all cross pairs.",
            codeLine: 3,
          });
          const sortCount = (lo, hi) => {
            if (hi - lo < 2) return;
            const mid = Math.floor((lo + hi) / 2);
            sortCount(lo, mid);
            sortCount(mid, hi);
            let j = mid;
            let added = 0;
            for (let i = lo; i < mid; i++) {
              while (j < hi && a[i] > 2 * a[j]) j++;
              added += j - mid;
            }
            total += added;
            const left = a.slice(lo, mid);
            const right = a.slice(mid, hi);
            const merged = [];
            let i = 0, jj = 0;
            while (i < left.length && jj < right.length) {
              if (left[i] <= right[jj]) merged.push(left[i++]);
              else merged.push(right[jj++]);
            }
            while (i < left.length) merged.push(left[i++]);
            while (jj < right.length) merged.push(right[jj++]);
            for (let k = 0; k < merged.length; k++) a[lo + k] = merged[k];
            steps.push({
              title: `Count ${show(left)} against ${show(right)}: +${added}`,
              tracks: [
                track("numbers", a, (k) => (k >= lo && k < hi ? "active" : "dim")),
                chips("left half", left, "done"),
                chips("right half", right, "compare"),
              ],
              counters: [count("reverse pairs", total), count("merge width", hi - lo)],
              legend: LEG,
              happened: added ? `${added} left value${added === 1 ? " is" : "s are"} more than twice some right value.` : "No left value is more than twice a right value in this merge.",
              why: "The pointer j only moves right, so counting takes linear time.",
              codeLine: 9,
            });
          };
          sortCount(0, n);
          steps.push({
            title: `Answer: ${total} reverse pair${total === 1 ? "" : "s"}`,
            tracks: [track("numbers", a, fill(n, "done")), chips("answer", [total], "result")],
            counters: [count("reverse pairs", total), count("answer", total)],
            legend: LEG,
            happened: `The sorted row is ${show(a)} after counting ${total} pairs.`,
            why: "Each pair is counted in the merge where the two indices first fall into different halves.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "maximum-gap",
    title: "Maximum Gap",
    category: "Sorting Algorithms",
    difficulty: "Advanced",
    description:
      "Find the largest difference between consecutive sorted values in linear time with pigeonhole buckets.",
    input: { label: "numbers", default: "3, 6, 9, 1", parse: "ints" },
    approaches: [
      {
        name: "Bucket the Range",
        complexity: "O(n) time, O(n) space",
        idea: [
          "With n values in a range of width w, the largest gap is at least ⌈w / (n − 1)⌉, so gaps smaller than that can be ignored.",
          "Place each value in a bucket of that width, keeping only each bucket's minimum and maximum. The answer is the largest gap between adjacent non-empty buckets.",
        ],
        problem: [
          "The bucket width must be computed with care; when all values are equal the range is zero and the answer is zero.",
        ],
        code: {
          c: `#include <stdio.h>
#include <limits.h>

int maximum_gap(int *a, int n) {
    if (n < 2) return 0;
    int lo = a[0], hi = a[0];
    for (int i = 1; i < n; i++) {
        if (a[i] < lo) lo = a[i];
        if (a[i] > hi) hi = a[i];
    }
    if (lo == hi) return 0;

    int width = (hi - lo + n - 2) / (n - 1);
    int buckets = (hi - lo) / width + 1;
    int mins[256], maxs[256], used[256] = {0};
    for (int i = 0; i < buckets; i++) { mins[i] = INT_MAX; maxs[i] = INT_MIN; }

    for (int i = 0; i < n; i++) {
        int b = (a[i] - lo) / width;
        used[b] = 1;
        if (a[i] < mins[b]) mins[b] = a[i];
        if (a[i] > maxs[b]) maxs[b] = a[i];
    }

    int best = 0, prev = lo;
    for (int b = 0; b < buckets; b++) {
        if (!used[b]) continue;
        if (mins[b] - prev > best) best = mins[b] - prev;
        prev = maxs[b];
    }
    return best;
}

int main(void) {
    int a[] = {3, 6, 9, 1};
    printf("%d\\n", maximum_gap(a, 4)); /* 3 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
using namespace std;

int maximumGap(vector<int> a) {
    int n = a.size();
    if (n < 2) return 0;
    int lo = *min_element(a.begin(), a.end());
    int hi = *max_element(a.begin(), a.end());
    if (lo == hi) return 0;

    int width = max(1, (hi - lo) / (n - 1));
    int buckets = (hi - lo) / width + 1;
    vector<int> mins(buckets, INT_MAX), maxs(buckets, INT_MIN);
    vector<bool> used(buckets, false);

    for (int v : a) {
        int b = (v - lo) / width;
        used[b] = true;
        mins[b] = min(mins[b], v);
        maxs[b] = max(maxs[b], v);
    }

    int best = 0, prev = lo;
    for (int b = 0; b < buckets; b++) {
        if (!used[b]) continue;
        best = max(best, mins[b] - prev);
        prev = maxs[b];
    }
    return best;
}

int main() {
    cout << maximumGap({3, 6, 9, 1}) << '\\n'; // 3
}`,
        },
        steps(values) {
          const a = values.slice();
          const n = a.length;
          if (n < 2) {
            return [{
              title: "At least two values are needed",
              tracks: [track("numbers", a.length ? a : ["—"], fill(Math.max(1, n), "idle"))],
              counters: [count("gap", 0)],
              legend: ["idle", "result"],
              happened: "A gap needs two values.",
              why: "The largest gap is between consecutive sorted values.",
            }];
          }
          const lo = Math.min(...a);
          const hi = Math.max(...a);
          if (lo === hi) {
            return [{
              title: "All values are equal, so the gap is zero",
              tracks: [track("numbers", a, fill(n, "dim")), chips("answer", [0], "result")],
              counters: [count("gap", 0), count("range", 0)],
              legend: LEG,
              happened: "There is no spread at all.",
              why: "Every consecutive difference is zero.",
            }];
          }
          const width = Math.max(1, Math.floor((hi - lo) / (n - 1)));
          const bucketCount = Math.floor((hi - lo) / width) + 1;
          const steps = [];
          steps.push({
            title: `Range ${lo}..${hi}, bucket width ${width}, ${bucketCount} buckets`,
            tracks: [track("numbers", a, fill(n, "idle")), chips("bucket width", [width], "read")],
            counters: [count("range", hi - lo), count("buckets", bucketCount)],
            legend: LEG,
            happened: `The lower bound on the largest gap is about ${width}.`,
            why: "Two values in the same narrow bucket cannot produce the largest gap.",
            codeLine: 9,
          });
          const mins = Array(bucketCount).fill(Infinity);
          const maxs = Array(bucketCount).fill(-Infinity);
          const used = Array(bucketCount).fill(false);
          for (const v of a) {
            const b = Math.floor((v - lo) / width);
            used[b] = true;
            mins[b] = Math.min(mins[b], v);
            maxs[b] = Math.max(maxs[b], v);
            steps.push({
              title: `Put ${v} in bucket ${b} (${lo + b * width}..${lo + (b + 1) * width - 1})`,
              tracks: [
                track("numbers", a, (k) => (a[k] === v ? "read" : "idle")),
                chips("bucket min", mins.map((x) => (x === Infinity ? "·" : x)), (i) => (i === b ? "active" : "dim")),
                chips("bucket max", maxs.map((x) => (x === -Infinity ? "·" : x)), (i) => (i === b ? "active" : "dim")),
              ],
              counters: [count("placed", a.indexOf(v) + 1, n), count("bucket", b)],
              legend: LEG,
              happened: `Bucket ${b} now spans ${mins[b]}..${maxs[b]}.`,
              why: "Only the extremes of each bucket matter for gaps between buckets.",
              codeLine: 15,
            });
          }
          let best = 0, prev = lo;
          for (let b = 0; b < bucketCount; b++) {
            if (!used[b]) continue;
            const gap = mins[b] - prev;
            if (gap > best) best = gap;
            steps.push({
              title: `Bucket ${b}: gap ${mins[b]} − ${prev} = ${gap}`,
              tracks: [
                chips("bucket min", mins.map((x) => (x === Infinity ? "·" : x)), (i) => (i === b ? "read" : used[i] ? "done" : "dim")),
                chips("gap", [gap], gap === 0 ? "dim" : "compare"),
              ],
              counters: [count("gap", gap), count("best", best)],
              legend: LEG,
              happened: gap > 0 ? `The empty space before this bucket is ${gap}.` : "This bucket touches the previous one.",
              why: "Gaps between buckets are exactly the differences between the bucket minimum and the previous bucket maximum.",
              codeLine: 23,
            });
            prev = maxs[b];
          }
          steps.push({
            title: `Answer: ${best}`,
            tracks: [track("numbers", a, fill(n, "done")), chips("answer", [best], "result")],
            counters: [count("buckets", bucketCount), count("answer", best)],
            legend: LEG,
            happened: `The largest gap between adjacent sorted values is ${best}.`,
            why: "The scan touches each bucket once, so the method is linear.",
            codeLine: 25,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "wiggle-sort-ii",
    title: "Wiggle Sort II",
    category: "Sorting Algorithms",
    difficulty: "Advanced",
    description:
      "Reorder so values alternate low-high-low-high, with strict inequalities, by splitting the sorted row at the median.",
    input: { label: "numbers", default: "1, 5, 1, 1, 6, 4", parse: "ints" },
    approaches: [
      {
        name: "Sorted Halves Interleaved",
        complexity: "O(n log n) time for the sort",
        idea: [
          "Sort the row. The lower half and upper half alternate, which guarantees each high value exceeds its neighbours.",
          "Fill the odd positions from the upper half and the even positions from the lower half, both from the middle outwards, so duplicates land far apart.",
        ],
        problem: [
          "Filling from the ends instead of the middles can place equal values next to each other when duplicates cross the median.",
        ],
        code: {
          c: `#include <stdio.h>
#include <stdlib.h>

static int cmp(const void *a, const void *b) { return *(const int *)a - *(const int *)b; }

void wiggle_sort(int *a, int n) {
    qsort(a, n, sizeof(int), cmp);
    int half = (n + 1) / 2;
    int *tmp = malloc(n * sizeof(int));
    int lo = half - 1, hi = n - 1;

    for (int i = 0; i < n; i += 2) tmp[i] = a[lo--];
    for (int i = 1; i < n; i += 2) tmp[i] = a[hi--];

    for (int i = 0; i < n; i++) a[i] = tmp[i];
    free(tmp);
}

int main(void) {
    int a[] = {1, 5, 1, 1, 6, 4};
    wiggle_sort(a, 6);
    for (int i = 0; i < 6; i++) printf("%d ", a[i]);

    printf("\\n"); /* 1 6 1 5 1 4 */
    return 0;
}`,
          cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void wiggleSort(vector<int>& a) {
    vector<int> sorted(a);
    sort(sorted.begin(), sorted.end());
    int n = a.size(), half = (n + 1) / 2;
    int lo = half - 1, hi = n - 1;

    for (int i = 0; i < n; i += 2) a[i] = sorted[lo--];
    for (int i = 1; i < n; i += 2) a[i] = sorted[hi--];
}

int main() {
    vector<int> a{1, 5, 1, 1, 6, 4};
    wiggleSort(a);
    for (int v : a) cout << v << ' '; // 1 6 1 5 1 4
    cout << '\\n';
}`,
        },
        steps(values) {
          const a = values.slice();
          const n = a.length;
          if (!n) {
            return [{
              title: "Give some numbers",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("length", 0)],
              legend: ["idle", "result"],
              happened: "There is nothing to reorder.",
              why: "The pattern needs at least one value.",
            }];
          }
          const sorted = a.slice().sort((x, y) => x - y);
          const half = Math.floor((n + 1) / 2);
          const steps = [];
          const out = Array(n).fill(null);
          steps.push({
            title: `Sort → ${show(sorted)}; lower half size ${half}`,
            tracks: [track("numbers", a, fill(n, "idle")), track("sorted", sorted, "dim")],
            counters: [count("length", n), count("lower half", half)],
            legend: LEG,
            happened: "Odd positions take the largest values, even positions the smallest.",
            why: "A high value between two lower ones satisfies both strict inequalities.",
            codeLine: 6,
          });
          let lo = half - 1, hi = n - 1;
          for (let i = 0; i < n; i++) {
            if (i % 2 === 0) {
              out[i] = sorted[lo--];
              steps.push({
                title: `Position ${i} (low slot) takes ${out[i]}`,
                tracks: [
                  track("sorted", sorted, (k) => (k <= lo ? "done" : k > hi ? "done" : "dim")),
                  track("result", out.map((v) => (v == null ? "·" : v)), (k) => (k === i ? "result" : out[k] != null ? "done" : "idle")),
                ],
                counters: [count("filled", i + 1, n), count("value", out[i])],
                legend: LEG,
                happened: `The lower half is consumed from its largest end.`,
                why: "Taking the lower values from the middle keeps them below the upper values.",
                codeLine: 9,
              });
            } else {
              out[i] = sorted[hi--];
              steps.push({
                title: `Position ${i} (high slot) takes ${out[i]}`,
                tracks: [
                  track("sorted", sorted, "dim"),
                  track("result", out.map((v) => (v == null ? "·" : v)), (k) => (k === i ? "result" : out[k] != null ? "done" : "idle")),
                ],
                counters: [count("filled", i + 1, n), count("value", out[i])],
                legend: LEG,
                happened: `The upper half is consumed from its largest end.`,
                why: "Each high slot should hold a value clearly above its lower neighbours.",
                codeLine: 10,
              });
            }
          }
          steps.push({
            title: `Answer: ${show(out)}`,
            tracks: [track("result", out, "result")],
            counters: [count("filled", n, n), count("answer", show(out))],
            legend: LEG,
            happened: `Every adjacent pair alternates low then high.`,
            why: "Interleaving sorted halves from the middle out prevents equal neighbours when a valid arrangement exists.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });
})();
