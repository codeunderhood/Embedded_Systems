/* ============================================================
   DSA Visuals — Backtracking I
   Choose, explore, undo. Every search keeps the partial choice
   visible so the undo is easy to follow.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const parts = (text) => String(text || "").split("|").map((p) => p.trim());
  const nums = (text) => String(text || "").split(/[\s,]+/).filter(Boolean).map(Number);
  const show = (a) => `[${a.join(", ")}]`;

  /* ---------------------------------------------------------- */
  V.register({
    id: "combination-sum-ii",
    title: "Combination Sum II",
    category: "Backtracking",
    difficulty: "Advanced",
    description:
      "Pick numbers that add to a target, using each array position at most once and skipping duplicate picks.",
    input: { label: "candidates | target", default: "10,1,2,7,6,1,5 | 8", parse: "string" },
    approaches: [
      {
        name: "Sort, Then Choose or Skip",
        complexity: "O(2ⁿ) worst case",
        idea: [
          "Sort the candidates so equal values sit together. At each position decide to take the value or skip it.",
          "Skipping a value also skips every later copy of that value at the same depth, which removes duplicate combinations.",
        ],
        problem: [
          "Without the duplicate skip, the same combination is found once per copy of a repeated value.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\nstatic int by_value(const void *a, const void *b) {\n    return *(const int *)a - *(const int *)b;\n}\n\nvoid search(int *a, int n, int start, int target, int *path, int depth) {\n    if (target == 0) {\n        for (int i = 0; i < depth; i++) printf("%d ", path[i]);\n        printf("\\\\n");\n        return;\n    }\n\n    for (int i = start; i < n; i++) {\n        if (i > start && a[i] == a[i - 1]) continue;   /* skip duplicates */\n        if (a[i] > target) break;                      /* sorted, so stop */\n        path[depth] = a[i];\n        search(a, n, i + 1, target - a[i], path, depth + 1);\n    }\n}\n\nint main(void) {\n    int a[] = {10, 1, 2, 7, 6, 1, 5};\n    int path[16];\n    qsort(a, 7, sizeof(int), by_value);\n    search(a, 7, 0, 8, path, 0);\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <algorithm>\nusing namespace std;\n\nvoid search(vector<int>& a, int start, int target, vector<int>& path) {\n    if (target == 0) {\n        for (int v : path) cout << v << ' ';\n        cout << '\\\\n';\n        return;\n    }\n\n    for (int i = start; i < (int)a.size(); i++) {\n        if (i > start && a[i] == a[i - 1]) continue;\n        if (a[i] > target) break;\n        path.push_back(a[i]);\n        search(a, i + 1, target - a[i], path);\n        path.pop_back();\n    }\n}\n\nint main() {\n    vector<int> a{10,1,2,7,6,1,5}, path;\n    sort(a.begin(), a.end());\n    search(a, 0, 8, path);\n}`,
        },
        steps(text) {
          const [candRaw, targetRaw] = parts(text);
          const a = nums(candRaw).sort((x, y) => x - y);
          const target = parseInt(targetRaw, 10) || 0;
          if (!a.length) {
            return [{
              title: "Give candidates and a target",
              tracks: [chips("candidates", ["—"], "idle")],
              counters: [count("target", target)],
              legend: ["idle", "result"],
              happened: "The left field holds the candidates, the right the target.",
              why: "Sorting makes duplicate skipping possible.",
            }];
          }
          const steps = [];
          const results = [];
          const path = [];
          let budget = 42;
          steps.push({
            title: `Sorted candidates ${show(a)}; target ${target}`,
            tracks: [chips("candidates", a, "idle"), chips("path", ["—"], "dim")],
            counters: [count("target left", target), count("combinations", 0)],
            legend: LEG,
            happened: "Equal values are adjacent, so repeated picks are easy to spot.",
            why: "Taking or skipping is decided once per position.",
            codeLine: 6,
          });
          const record = (step) => {
            if (budget > 0) { steps.push(step); budget--; }
          };
          const search = (start, remain) => {
            if (remain === 0) {
              results.push(path.slice());
              record({
                title: `Found ${show(path)}`,
                tracks: [
                  chips("candidates", a, (i) => (i < start ? "done" : "dim")),
                  chips("path", path, "result"),
                  chips("results", results.map((r) => r.join("+")), (i) => (i === results.length - 1 ? "good" : "dim")),
                ],
                counters: [count("target left", remain), count("combinations", results.length)],
                legend: LEG,
                happened: "The path adds exactly to the target.",
                why: "Every candidate was used at most once because the next search starts after it.",
                codeLine: 4,
              });
              return;
            }
            for (let i = start; i < a.length; i++) {
              if (i > start && a[i] === a[i - 1]) {
                record({
                  title: `Skip duplicate ${a[i]} at index ${i}`,
                  tracks: [chips("candidates", a, (j) => (j === i ? "bad" : j < start ? "done" : "dim")), chips("path", path.length ? path : ["—"], "active")],
                  counters: [count("target left", remain), count("combinations", results.length)],
                  legend: LEG,
                  happened: "The equal value at the previous index was already tried at this depth.",
                  why: "Skipping copies avoids identical combinations.",
                  codeLine: 12,
                });
                continue;
              }
              if (a[i] > remain) break;
              path.push(a[i]);
              record({
                title: `Take ${a[i]}; ${remain} − ${a[i]} = ${remain - a[i]} left`,
                tracks: [
                  chips("candidates", a, (j) => (j === i ? "read" : j < start ? "done" : "dim")),
                  chips("path", path, "active"),
                ],
                counters: [count("target left", remain - a[i]), count("depth", path.length)],
                legend: LEG,
                happened: `Index ${i} joins the path; the next search starts at ${i + 1}.`,
                why: "Sorted order means any later candidate that is too large can be skipped entirely.",
                codeLine: 14,
              });
              search(i + 1, remain - a[i]);
              path.pop();
              record({
                title: `Undo ${a[i]} and try the next candidate`,
                tracks: [chips("candidates", a, (j) => (j === i ? "bad" : j < start ? "done" : "dim")), chips("path", path.length ? path : ["—"], "dim")],
                counters: [count("target left", remain), count("combinations", results.length)],
                legend: LEG,
                happened: "The last pick is removed so a different branch can be explored.",
                why: "Backtracking restores the exact state before the choice.",
                codeLine: 16,
              });
            }
          };
          search(0, target);
          steps.push({
            title: `Answer: ${results.length} combination${results.length === 1 ? "" : "s"} ${show(results.map((r) => r.join("+")))}`,
            tracks: [chips("combinations", results.length ? results.map((r) => r.join("+")) : ["none"], "result")],
            counters: [count("combinations", results.length), count("candidates", a.length)],
            legend: LEG,
            happened: results.length ? "Each combination uses positions at most once." : "No subset adds to the target.",
            why: "The duplicate skip keeps the result set free of repeats.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "letter-combinations-of-a-phone-number",
    title: "Letter Combinations of a Phone Number",
    category: "Backtracking",
    difficulty: "Intermediate",
    description:
      "List every letter string that a sequence of phone digits could spell.",
    input: { label: "digits", default: "23", parse: "string" },
    approaches: [
      {
        name: "One Digit per Depth",
        complexity: "O(4ⁿ × n) time",
        idea: [
          "Each digit maps to at most four letters. The search builds one letter per digit.",
          "At every depth, try each letter of that digit, recurse, then remove the letter before trying the next.",
        ],
        problem: [
          "The output size is exponential in the number of digits, so the list itself is the bottleneck.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nconst char *pad[] = {"", "", "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz"};\n\nvoid build(const char *digits, int at, char *buf) {\n    if (digits[at] == 0) { printf("%s\\\\n", buf); return; }\n\n    int d = digits[at] - '0';\n    int len = strlen(buf);\n    for (int i = 0; pad[d][i]; i++) {\n        buf[len] = pad[d][i];\n        buf[len + 1] = 0;\n        build(digits, at + 1, buf);\n    }\n    buf[len] = 0;                          /* undo */\n}\n\nint main(void) {\n    char buf[16] = "";\n    build("23", 0, buf); /* ad ae af bd be bf cd ce cf */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <string>\nusing namespace std;\n\nvector<string> pad = {"", "", "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz"};\n\nvoid build(const string& digits, int at, string& buf, vector<string>& out) {\n    if (at == (int)digits.size()) { out.push_back(buf); return; }\n\n    for (char c : pad[digits[at] - '0']) {\n        buf.push_back(c);\n        build(digits, at + 1, buf, out);\n        buf.pop_back();\n    }\n}\n\nint main() {\n    vector<string> out;\n    string buf;\n    build("23", 0, buf, out);\n    for (auto& s : out) cout << s << ' '; // ad ae af bd be bf cd ce cf\n    cout << '\\\\n';\n}`,
        },
        steps(text) {
          const digits = Array.from(String(text || "").replace(/[^0-9]/g, ""));
          const map = { 2: "abc", 3: "def", 4: "ghi", 5: "jkl", 6: "mno", 7: "pqrs", 8: "tuv", 9: "wxyz" };
          const valid = digits.filter((d) => map[d]);
          if (!valid.length) {
            return [{
              title: "Give some digits from 2 to 9",
              tracks: [chips("digits", digits.length ? digits : ["—"], "idle")],
              counters: [count("digits", digits.length)],
              legend: ["idle", "result"],
              happened: "0 and 1 have no letters.",
              why: "Each digit contributes one letter per position.",
            }];
          }
          const steps = [];
          const out = [];
          const path = [];
          steps.push({
            title: `Digits ${valid.join("")} → ${valid.length} letter slots`,
            tracks: [chips("digits", valid, "idle"), chips("letters", valid.map((d) => `${d}:${map[d]}`), "dim")],
            counters: [count("slots", valid.length), count("strings", 0)],
            legend: LEG,
            happened: "The first digit chooses the first letter, and so on.",
            why: "Each combination takes exactly one letter from each slot.",
            codeLine: 3,
          });
          let budget = 40;
          const record = (s) => { if (budget > 0) { steps.push(s); budget--; } };
          const walk = (at) => {
            if (at === valid.length) {
              out.push(path.join(""));
              record({
                title: `Complete string ${path.join("")}`,
                tracks: [chips("path", path, "result"), chips("strings", out, (i) => (i === out.length - 1 ? "good" : "dim"))],
                counters: [count("depth", at), count("strings", out.length)],
                legend: LEG,
                happened: "Every slot has a letter, so the string is recorded.",
                why: "A string is complete only after the last digit is used.",
                codeLine: 4,
              });
              return;
            }
            for (const c of map[valid[at]]) {
              path.push(c);
              record({
                title: `Slot ${at + 1}: try '${c}'`,
                tracks: [
                  chips("digits", valid, (i) => (i === at ? "read" : i < at ? "done" : "dim")),
                  chips("path", path, "active"),
                  chips("letters of this digit", Array.from(map[valid[at]]), (i) => (map[valid[at]][i] === c ? "active" : "dim")),
                ],
                counters: [count("depth", at + 1), count("strings", out.length)],
                legend: LEG,
                happened: `'${c}' fills slot ${at + 1}.`,
                why: "Each letter of the current digit leads to its own subtree.",
                codeLine: 8,
              });
              walk(at + 1);
              path.pop();
              record({
                title: `Undo '${c}' and try the next letter`,
                tracks: [chips("path", path.length ? path : ["—"], "dim"), chips("strings", out.length ? out : ["—"], "dim")],
                counters: [count("depth", at + 1), count("strings", out.length)],
                legend: LEG,
                happened: "Removing the letter restores the prefix for the next branch.",
                why: "The same buffer is reused at every depth.",
                codeLine: 10,
              });
            }
          };
          walk(0);
          steps.push({
            title: `Answer: ${out.length} string${out.length === 1 ? "" : "s"} ${show(out)}`,
            tracks: [chips("strings", out, "result")],
            counters: [count("strings", out.length), count("digits", valid.length)],
            legend: LEG,
            happened: `Every slot contributed exactly one letter.`,
            why: "The count is the product of the digit group sizes.",
            codeLine: 12,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "generate-parentheses",
    title: "Generate Parentheses",
    category: "Backtracking",
    difficulty: "Intermediate",
    description:
      "Build every well-formed string of n pairs by opening and closing at the right moments.",
    input: { label: "pairs n", default: "3", parse: "int" },
    approaches: [
      {
        name: "Open While Allowed, Close When Safe",
        complexity: "O(Catalan(n) × n) time",
        idea: [
          "Add an opening bracket at every step until n are used.",
          "Close a bracket only when more opens than closes exist, which keeps every prefix valid.",
        ],
        problem: [
          "Allowing a close whenever any open exists but none are unmatched produces invalid prefixes that later need filtering.",
        ],
        code: {
          c: `#include <stdio.h>\n\nvoid build(char *buf, int open, int close, int n) {\n    if (open == n && close == n) { printf("%s\\\\n", buf); return; }\n\n    int len = open + close;\n    if (open < n) { buf[len] = '('; buf[len + 1] = 0; build(buf, open + 1, close, n); }\n    if (close < open) { buf[len] = ')'; buf[len + 1] = 0; build(buf, open, close + 1, n); }\n    buf[len] = 0;\n}\n\nint main(void) {\n    char buf[32] = "";\n    build(buf, 0, 0, 3); /* 5 strings */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <string>\nusing namespace std;\n\nvoid build(vector<string>& out, string& buf, int open, int close, int n) {\n    if ((int)buf.size() == 2 * n) { out.push_back(buf); return; }\n\n    if (open < n) {\n        buf.push_back('(');\n        build(out, buf, open + 1, close, n);\n        buf.pop_back();\n    }\n    if (close < open) {\n        buf.push_back(')');\n        build(out, buf, open, close + 1, n);\n        buf.pop_back();\n    }\n}\n\nint main() {\n    vector<string> out;\n    string buf;\n    build(out, buf, 0, 0, 3);\n    for (auto& s : out) cout << s << ' '; // ((())) (()()) (())() ()(()) ()()()\n    cout << '\\\\n';\n}`,
        },
        steps(nRaw) {
          const n = Math.max(1, Math.min(5, parseInt(nRaw, 10) || 1));
          const steps = [];
          const out = [];
          let open = 0, close = 0;
          const path = [];
          let budget = 44;
          steps.push({
            title: `${n} pairs; start with zero opens and zero closes`,
            tracks: [chips("path", ["—"], "dim")],
            counters: [count("open", 0, n), count("close", 0, n)],
            legend: LEG,
            happened: "A prefix is valid when closes never outnumber opens.",
            why: "The final string needs exactly n of each bracket type.",
            codeLine: 3,
          });
          const record = (s) => { if (budget > 0) { steps.push(s); budget--; } };
          const walk = () => {
            if (path.length === 2 * n) {
              out.push(path.join(""));
              record({
                title: `Complete ${path.join("")}`,
                tracks: [chips("path", path, "result"), chips("results", out, (i) => (i === out.length - 1 ? "good" : "dim"))],
                counters: [count("strings", out.length), count("pairs", n)],
                legend: LEG,
                happened: "Both counters reached n, so the string is balanced.",
                why: "Every added close matched an earlier open.",
                codeLine: 4,
              });
              return;
            }
            if (open < n) {
              open++;
              path.push("(");
              record({
                title: `Open: add '(' → ${path.join("")}`,
                tracks: [chips("path", path, "active"), chips("results", out.length ? out : ["—"], "dim")],
                counters: [count("open", open, n), count("close", close, n)],
                legend: LEG,
                happened: `${open} of ${n} opening brackets are used.`,
                why: "Opening is always safe while fewer than n opens exist.",
                codeLine: 6,
              });
              walk();
              path.pop();
              open--;
              record({
                title: `Undo '(' → ${path.length ? path.join("") : "empty"}`,
                tracks: [chips("path", path.length ? path : ["—"], "dim"), chips("results", out.length ? out : ["—"], "dim")],
                counters: [count("open", open, n), count("close", close, n)],
                legend: LEG,
                happened: "The open was removed to try closing instead.",
                why: "The other branch of this node is a close.",
                codeLine: 8,
              });
            }
            if (close < open) {
              close++;
              path.push(")");
              record({
                title: `Close: add ')' → ${path.join("")}`,
                tracks: [chips("path", path, "active"), chips("results", out.length ? out : ["—"], "dim")],
                counters: [count("open", open, n), count("close", close, n)],
                legend: LEG,
                happened: `${close} closes are matched so far.`,
                why: "A close is only safe while unmatched opens remain.",
                codeLine: 7,
              });
              walk();
              path.pop();
              close--;
              record({
                title: `Undo ')' → ${path.length ? path.join("") : "empty"}`,
                tracks: [chips("path", path.length ? path : ["—"], "dim"), chips("results", out.length ? out : ["—"], "dim")],
                counters: [count("open", open, n), count("close", close, n)],
                legend: LEG,
                happened: "Restored the state before the close.",
                why: "Backtracking keeps every branch independent.",
                codeLine: 9,
              });
            }
          };
          walk();
          steps.push({
            title: `Answer: ${out.length} string${out.length === 1 ? "" : "s"}`,
            tracks: [chips("results", out, "result")],
            counters: [count("strings", out.length), count("pairs", n)],
            legend: LEG,
            happened: `All strings have ${2 * n} brackets and every prefix is balanced.`,
            why: "The close rule prevents any invalid prefix from being built.",
            codeLine: 11,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "palindrome-partitioning",
    title: "Palindrome Partitioning",
    category: "Backtracking",
    difficulty: "Advanced",
    description:
      "Split a string into pieces that are all palindromes, listing every possible split.",
    input: { label: "text", default: "aab", parse: "string" },
    approaches: [
      {
        name: "Cut Only Palindromic Prefixes",
        complexity: "O(n × 2ⁿ) time",
        idea: [
          "At position i, try every prefix i..j. Take it only if it reads the same backwards.",
          "Recurse from j + 1 with the piece added to the path. When the end is reached, the path is a valid partition.",
        ],
        problem: [
          "Checking palindromes with two pointers at every node repeats work; a precomputed table removes that cost.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nint is_pal(const char *s, int i, int j) {\n    while (i < j) if (s[i++] != s[j--]) return 0;\n    return 1;\n}\n\nvoid split(const char *s, int at, char parts[][16], int depth) {\n    if (s[at] == 0) {\n        for (int i = 0; i < depth; i++) printf("%s ", parts[i]);\n        printf("\\\\n");\n        return;\n    }\n\n    for (int j = at; s[j]; j++) {\n        if (!is_pal(s, at, j)) continue;\n        int len = j - at + 1;\n        strncpy(parts[depth], s + at, len);\n        parts[depth][len] = 0;\n        split(s, j + 1, parts, depth + 1);\n    }\n}\n\nint main(void) {\n    char parts[16][16];\n    split("aab", 0, parts, 0); /* aa b / a a b */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <string>\nusing namespace std;\n\nbool isPal(const string& s, int i, int j) {\n    while (i < j) if (s[i++] != s[j--]) return false;\n    return true;\n}\n\nvoid split(const string& s, int at, vector<string>& path, vector<vector<string>>& out) {\n    if (at == (int)s.size()) { out.push_back(path); return; }\n\n    for (int j = at; j < (int)s.size(); j++) {\n        if (!isPal(s, at, j)) continue;\n        path.push_back(s.substr(at, j - at + 1));\n        split(s, j + 1, path, out);\n        path.pop_back();\n    }\n}\n\nint main() {\n    vector<vector<string>> out;\n    vector<string> path;\n    split("aab", 0, path, out);\n    for (auto& part : out) {\n        for (auto& p : part) cout << p << ' ';\n        cout << '\\\\n';\n    }\n}`,
        },
        steps(text) {
          const s = Array.from(String(text || ""));
          if (!s.length) {
            return [{
              title: "Give some text",
              tracks: [chips("text", ["—"], "idle")],
              counters: [count("partitions", 0)],
              legend: ["idle", "result"],
              happened: "There is nothing to partition.",
              why: "A partition must cover at least one character.",
            }];
          }
          const isPal = (lo, hi) => {
            let i = lo, j = hi;
            while (i < j) if (s[i++] !== s[j--]) return false;
            return true;
          };
          const steps = [];
          const out = [];
          const path = [];
          let budget = 44;
          steps.push({
            title: `Partition "${s.join("")}" into palindromic pieces`,
            tracks: [track("text", s, fill(s.length, "idle")), chips("path", ["—"], "dim")],
            counters: [count("position", 0), count("partitions", 0)],
            legend: LEG,
            happened: "A cut is allowed only when the piece reads the same both ways.",
            why: "Every character must belong to exactly one piece.",
            codeLine: 8,
          });
          const record = (st) => { if (budget > 0) { steps.push(st); budget--; } };
          const walk = (at) => {
            if (at === s.length) {
              out.push(path.slice());
              record({
                title: `Partition ${path.join(" | ")}`,
                tracks: [track("text", s, fill(s.length, "done")), chips("path", path, "result")],
                counters: [count("position", at), count("partitions", out.length)],
                legend: LEG,
                happened: "The cuts reach the end with every piece palindromic.",
                why: "A complete cover is exactly one valid partition.",
                codeLine: 10,
              });
              return;
            }
            for (let j = at; j < s.length; j++) {
              const piece = s.slice(at, j + 1).join("");
              const pal = isPal(at, j);
              record({
                title: `Try "${piece}" (${at}..${j}) → ${pal ? "palindrome" : "not a palindrome"}`,
                tracks: [
                  track("text", s, s.map((_, i) => (i >= at && i <= j ? (pal ? "result" : "bad") : i < at ? "done" : "dim"))),
                  chips("path", path.length ? path : ["—"], pal ? "active" : "dim"),
                ],
                counters: [count("start", at), count("end", j), count("partitions", out.length)],
                legend: LEG,
                happened: pal ? `"${piece}" reads the same backwards.` : `"${piece}" is rejected, so no cut is made here.`,
                why: "Only palindromic prefixes may be cut off.",
                codeLine: pal ? 14 : 12,
              });
              if (!pal) continue;
              path.push(piece);
              record({
                title: `Take "${piece}"; continue from ${j + 1}`,
                tracks: [track("text", s, s.map((_, i) => (i >= at && i <= j ? "done" : i < at ? "dim" : "idle"))), chips("path", path, "active")],
                counters: [count("position", j + 1), count("pieces", path.length)],
                legend: LEG,
                happened: `Remaining text is "${s.slice(j + 1).join("") || "empty"}".`,
                why: "The next piece must start immediately after this one.",
                codeLine: 16,
              });
              walk(j + 1);
              path.pop();
              record({
                title: `Undo "${piece}"`,
                tracks: [chips("path", path.length ? path : ["—"], "dim")],
                counters: [count("position", at), count("pieces", path.length)],
                legend: LEG,
                happened: "Restored the partition before this piece.",
                why: "A longer piece may still be possible from the same start.",
                codeLine: 18,
              });
            }
          };
          walk(0);
          steps.push({
            title: `Answer: ${out.length} partition${out.length === 1 ? "" : "s"}`,
            tracks: [chips("partitions", out.map((p) => p.join("|")), "result")],
            counters: [count("partitions", out.length), count("characters", s.length)],
            legend: LEG,
            happened: out.length ? `Every character appears in exactly one piece of each partition.` : "No palindromic partition exists.",
            why: "The search enumerates every valid set of cuts once.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "restore-ip-addresses",
    title: "Restore IP Addresses",
    category: "Backtracking",
    difficulty: "Advanced",
    description:
      "Insert three dots into a digit string so the four pieces are valid IP octets.",
    input: { label: "digit string", default: "25525511135", parse: "string" },
    approaches: [
      {
        name: "Four Pieces of One to Three Digits",
        complexity: "O(3⁴) time, constant space",
        idea: [
          "Build four pieces in order. Each piece is one to three digits and must be 0 to 255.",
          "A piece may not have a leading zero unless it is exactly \"0\". After four pieces the whole string must be consumed.",
        ],
        problem: [
          "Leading zeros and leftover digits are easy to miss; both checks must happen at the cut, not afterwards.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n#include <stdlib.h>\n\nvoid build(const char *s, int at, int part, char parts[][8]) {\n    if (part == 4) {\n        if (s[at] == 0) {\n            printf("%s.%s.%s.%s\\\\n", parts[0], parts[1], parts[2], parts[3]);\n        }\n        return;\n    }\n\n    for (int len = 1; len <= 3 && s[at + len - 1]; len++) {\n        if (len > 1 && s[at] == '0') break;              /* leading zero */\n        char piece[8];\n        strncpy(piece, s + at, len);\n        piece[len] = 0;\n        if (atoi(piece) > 255) break;\n        strcpy(parts[part], piece);\n        build(s, at + len, part + 1, parts);\n    }\n}\n\nint main(void) {\n    char parts[4][8];\n    build("25525511135", 0, 0, parts);\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <string>\n#include <vector>\nusing namespace std;\n\nvoid build(const string& s, int at, int part, vector<string>& path, vector<string>& out) {\n    if (part == 4) {\n        if (at == (int)s.size()) out.push_back(path[0] + "." + path[1] + "." + path[2] + "." + path[3]);\n        return;\n    }\n\n    for (int len = 1; len <= 3 && at + len <= (int)s.size(); len++) {\n        if (len > 1 && s[at] == '0') break;\n        string piece = s.substr(at, len);\n        if (stoi(piece) > 255) break;\n        path[part] = piece;\n        build(s, at + len, part + 1, path, out);\n    }\n}\n\nint main() {\n    vector<string> out;\n    vector<string> path(4);\n    build("25525511135", 0, 0, path, out);\n    for (auto& ip : out) cout << ip << '\\\\n';\n}`,
        },
        steps(text) {
          const s = Array.from(String(text || "").replace(/[^0-9]/g, ""));
          if (!s.length) {
            return [{
              title: "Give a digit string",
              tracks: [chips("digits", ["—"], "idle")],
              counters: [count("addresses", 0)],
              legend: ["idle", "result"],
              happened: "An IP address needs 4 to 12 digits.",
              why: "Each of the four pieces uses one to three digits.",
            }];
          }
          const steps = [];
          const out = [];
          const path = [];
          let budget = 42;
          steps.push({
            title: `${s.length} digits; build four octets`,
            tracks: [track("digits", s, fill(s.length, "idle")), chips("octets", ["—"], "dim")],
            counters: [count("parts", 0, 4), count("addresses", 0)],
            legend: LEG,
            happened: "A complete address uses every digit exactly once.",
            why: "Four pieces of at most three digits can cover at most twelve digits.",
            codeLine: 4,
          });
          const record = (st) => { if (budget > 0) { steps.push(st); budget--; } };
          const walk = (at, part) => {
            if (part === 4) {
              if (at === s.length) {
                const ip = path.join(".");
                out.push(ip);
                record({
                  title: `Valid address ${ip}`,
                  tracks: [chips("octets", path, "result"), chips("addresses", out, (i) => (i === out.length - 1 ? "good" : "dim"))],
                  counters: [count("addresses", out.length), count("digits used", at, s.length)],
                  legend: LEG,
                  happened: "All four octets are valid and the string is fully consumed.",
                  why: "Leftover digits would mean the pieces did not cover the input.",
                  codeLine: 5,
                });
              } else {
                record({
                  title: `Four octets used, but ${s.length - at} digit${s.length - at === 1 ? "" : "s"} remain → reject`,
                  tracks: [chips("octets", path, "bad"), chips("leftover", s.slice(at), "bad")],
                  counters: [count("addresses", out.length), count("leftover", s.length - at)],
                  legend: LEG,
                  happened: "A valid address cannot leave unused digits.",
                  why: "The dots only partition the existing digits.",
                  codeLine: 6,
                });
              }
              return;
            }
            for (let len = 1; len <= 3 && at + len <= s.length; len++) {
              const piece = s.slice(at, at + len).join("");
              if (len > 1 && piece[0] === "0") {
                record({
                  title: `"${piece}" has a leading zero → stop this length`,
                  tracks: [track("digits", s, s.map((_, i) => (i >= at && i < at + len ? "bad" : i < at ? "done" : "dim"))), chips("octets", path.length ? path : ["—"], "dim")],
                  counters: [count("part", part + 1, 4), count("value", piece)],
                  legend: LEG,
                  happened: "Only the single digit \"0\" may start with a zero.",
                  why: "Longer pieces with a leading zero would create an invalid octet.",
                  codeLine: 12,
                });
                break;
              }
              const value = parseInt(piece, 10);
              if (value > 255) {
                record({
                  title: `"${piece}" = ${value} > 255 → stop this length`,
                  tracks: [track("digits", s, s.map((_, i) => (i >= at && i < at + len ? "bad" : i < at ? "done" : "dim"))), chips("octets", path.length ? path : ["—"], "dim")],
                  counters: [count("part", part + 1, 4), count("value", value)],
                  legend: LEG,
                  happened: "An octet cannot exceed 255.",
                  why: "Longer pieces only grow, so the loop can stop.",
                  codeLine: 14,
                });
                break;
              }
              path.push(piece);
              record({
                title: `Part ${part + 1} = "${piece}" (${value})`,
                tracks: [
                  track("digits", s, s.map((_, i) => (i >= at && i < at + len ? "done" : i < at ? "dim" : "idle"))),
                  chips("octets", path, "active"),
                ],
                counters: [count("parts", path.length, 4), count("next index", at + len)],
                legend: LEG,
                happened: `"${piece}" is a valid octet; the next part starts at ${at + len}.`,
                why: "Each part consumes a contiguous block of digits.",
                codeLine: 17,
              });
              walk(at + len, part + 1);
              path.pop();
            }
          };
          walk(0, 0);
          steps.push({
            title: out.length ? `Answer: ${out.length} address${out.length === 1 ? "" : "es"}` : "Answer: no valid address",
            tracks: [chips("addresses", out.length ? out : ["none"], "result")],
            counters: [count("addresses", out.length), count("digits", s.length)],
            legend: LEG,
            happened: out.length ? "Each address has four octets within 0..255." : "No four valid pieces cover the string.",
            why: "The search tries every legal cut position once.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "word-search",
    title: "Word Search",
    category: "Backtracking",
    difficulty: "Advanced",
    description:
      "Find whether a word can be traced through adjacent grid cells without reusing any cell.",
    input: { label: "grid rows (letters, commas) | word", default: "A,B,C,E | S,F,C,S | A,D,E,E | ABCCED", parse: "string" },
    approaches: [
      {
        name: "Depth-First Search From Every Cell",
        complexity: "O(rows × cols × 4^L) time",
        idea: [
          "Start a search from every cell whose letter matches the word's first character.",
          "At each step move up, down, left or right to an unused matching neighbour. Mark the cell before recursing and unmark it after, so other paths can use it.",
        ],
        problem: [
          "Forgetting to unmark a cell makes later starting positions fail even when a valid path exists.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <string.h>\n\nchar board[3][4] = {{'A','B','C','E'}, {'S','F','C','S'}, {'A','D','E','E'}};\nint used[3][4];\n\nint walk(int r, int c, const char *word, int at) {\n    if (word[at] == 0) return 1;\n    if (r < 0 || r >= 3 || c < 0 || c >= 4) return 0;\n    if (used[r][c] || board[r][c] != word[at]) return 0;\n\n    used[r][c] = 1;\n    int found = walk(r+1, c, word, at+1) || walk(r-1, c, word, at+1)\n             || walk(r, c+1, word, at+1) || walk(r, c-1, word, at+1);\n    used[r][c] = 0;                      /* undo */\n    return found;\n}\n\nint main(void) {\n    printf("%d\\\\n", walk(0, 0, "ABCCED", 0)); /* 1 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <string>\nusing namespace std;\n\nint dr[] = {1, -1, 0, 0};\nint dc[] = {0, 0, 1, -1};\n\nbool walk(vector<vector<char>>& g, int r, int c, const string& word, int at, vector<vector<bool>>& used) {\n    if (at == (int)word.size()) return true;\n    if (r < 0 || r >= (int)g.size() || c < 0 || c >= (int)g[0].size()) return false;\n    if (used[r][c] || g[r][c] != word[at]) return false;\n\n    used[r][c] = true;\n    for (int d = 0; d < 4; d++)\n        if (walk(g, r + dr[d], c + dc[d], word, at + 1, used)) { used[r][c] = false; return true; }\n    used[r][c] = false;\n    return false;\n}\n\nint main() {\n    vector<vector<char>> g{{'A','B','C','E'},{'S','F','C','S'},{'A','D','E','E'}};\n    vector<vector<bool>> used(3, vector<bool>(4, false));\n    cout << walk(g, 0, 0, "ABCCED", 0, used) << '\\\\n'; // 1\n}`,
        },
        steps(text) {
          const segs = parts(text);
          const wordSeg = segs[segs.length - 1] || "";
          const rows = segs.slice(0, -1).map((r) => r.split(/[\s,]+/).filter(Boolean)).filter((r) => r.length);
          const word = Array.from(wordSeg.toUpperCase().replace(/[^A-Z]/g, ""));
          if (!rows.length || !word.length) {
            return [{
              title: "Give grid rows and a word",
              tracks: [chips("grid", ["—"], "idle"), chips("word", ["—"], "idle")],
              counters: [count("cells", 0)],
              legend: ["idle", "result"],
              happened: "Rows are separated by | and the last field is the word.",
              why: "The search moves only between adjacent cells.",
            }];
          }
          const R = rows.length, C = Math.max(...rows.map((r) => r.length));
          const g = Array.from({ length: R }, (_, r) => Array.from({ length: C }, (_, c) => (rows[r][c] || "").toUpperCase()));
          const steps = [];
          const used = Array.from({ length: R }, () => Array(C).fill(false));
          const path = [];
          let found = false;
          let budget = 48;
          const render = (active, bad) =>
            grid(R, C, (r, c) => {
              const inPath = used[r][c];
              const isActive = active && active[0] === r && active[1] === c;
              const isBad = bad && bad[0] === r && bad[1] === c;
              return { v: g[r][c], state: isBad ? "bad" : isActive ? "read" : inPath ? "done" : "dim" };
            });
          steps.push({
            title: `Search "${word.join("")}" in a ${R}×${C} grid`,
            kind: "grid", rows: R, cols: C,
            cells: render(),
            counters: [count("word length", word.length), count("cells", R * C)],
            legend: LEG,
            happened: "Cells may be used once per path; the mark is undone on backtrack.",
            why: "The word must follow a chain of touching cells.",
            codeLine: 6,
          });
          const record = (st) => { if (budget > 0) { steps.push(st); budget--; } };
          const walk = (r, c, at) => {
            if (at === word.length) return true;
            if (r < 0 || r >= R || c < 0 || c >= C) return false;
            if (used[r][c] || g[r][c] !== word[at]) return false;
            used[r][c] = true;
            path.push(`${g[r][c]}(${r},${c})`);
            record({
              title: `Match '${word[at]}' at (${r}, ${c})`,
              kind: "grid", rows: R, cols: C,
              cells: render([r, c]),
              counters: [count("matched", at + 1, word.length), count("path length", path.length)],
              legend: LEG,
              happened: `'${word[at]}' matches; the next letter must come from a neighbour.`,
              why: "Marking the cell prevents the path from crossing itself.",
              codeLine: 9,
            });
            const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
            for (const [dr, dc] of dirs) {
              if (walk(r + dr, c + dc, at + 1)) return true;
            }
            used[r][c] = false;
            path.pop();
            record({
              title: `Dead end at (${r}, ${c}); unmark it`,
              kind: "grid", rows: R, cols: C,
              cells: render(null, [r, c]),
              counters: [count("matched", at, word.length), count("path length", path.length)],
              legend: LEG,
              happened: "No neighbour continued the word, so this cell is released.",
              why: "Another route through the same cell may still succeed.",
              codeLine: 12,
            });
            return false;
          };
          for (let r = 0; r < R && !found; r++) {
            for (let c = 0; c < C && !found; c++) {
              if (g[r][c] !== word[0]) continue;
              record({
                title: `Start at (${r}, ${c}) with '${word[0]}'`,
                kind: "grid", rows: R, cols: C,
                cells: render([r, c]),
                counters: [count("matched", 0, word.length), count("starts", r * C + c + 1)],
                legend: LEG,
                happened: "Every matching cell is a possible start.",
                why: "The word may begin anywhere in the grid.",
                codeLine: 18,
              });
              if (walk(r, c, 0)) { found = true; break; }
            }
          }
          steps.push({
            title: found ? `Answer: found "${word.join("")}"` : `Answer: "${word.join("")}" is not present`,
            kind: "grid", rows: R, cols: C,
            cells: grid(R, C, (r, c) => ({ v: g[r][c], state: found && used[r][c] ? "result" : "dim" })),
            counters: [count("answer", found ? "yes" : "no"), count("word length", word.length)],
            legend: LEG,
            happened: found ? "The marked cells spell the word in order." : "No chain of adjacent cells matches every letter.",
            why: "All four directions were tried from every matching start.",
            codeLine: 20,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "n-queens",
    title: "N-Queens",
    category: "Backtracking",
    difficulty: "Advanced",
    description:
      "Place n queens so none share a row, column or diagonal, and show every valid board.",
    input: { label: "board size n", default: "4", parse: "int" },
    approaches: [
      {
        name: "One Queen per Row",
        complexity: "O(n!) search, O(n) space",
        idea: [
          "Place exactly one queen in each row. Only the column and the two diagonals need checking.",
          "If a safe column exists, place the queen, recurse to the next row, then remove it so other columns can be tried.",
        ],
        problem: [
          "Checking every earlier column and diagonal by rescanning the board is slower than keeping three sets.",
        ],
        code: {
          c: `#include <stdio.h>\n#include <stdlib.h>\n\nint cols[16], d1[32], d2[32], where[16], n, solutions = 0;\n\nvoid place(int row) {\n    if (row == n) { solutions++; return; }\n\n    for (int col = 0; col < n; col++) {\n        if (cols[col] || d1[row + col] || d2[row - col + n]) continue;\n        cols[col] = d1[row + col] = d2[row - col + n] = 1;\n        where[row] = col;\n        place(row + 1);\n        cols[col] = d1[row + col] = d2[row - col + n] = 0;   /* undo */\n    }\n}\n\nint main(void) {\n    n = 4;\n    place(0);\n    printf("%d\\\\n", solutions); /* 2 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <string>\nusing namespace std;\n\nint n;\nvector<int> cols, d1, d2, where_;\nvector<vector<string>> out;\n\nvoid place(int row) {\n    if (row == n) {\n        vector<string> board(n, string(n, '.'));\n        for (int r = 0; r < n; r++) board[r][where_[r]] = 'Q';\n        out.push_back(board);\n        return;\n    }\n\n    for (int col = 0; col < n; col++) {\n        if (cols[col] || d1[row + col] || d2[row - col + n]) continue;\n        cols[col] = d1[row + col] = d2[row - col + n] = 1;\n        where_[row] = col;\n        place(row + 1);\n        cols[col] = d1[row + col] = d2[row - col + n] = 0;\n    }\n}\n\nint main() {\n    n = 4;\n    cols.assign(n, 0); d1.assign(2*n, 0); d2.assign(2*n, 0); where_.assign(n, 0);\n    place(0);\n    cout << out.size() << '\\\\n'; // 2\n}`,
        },
        steps(nRaw) {
          const n = Math.max(1, Math.min(6, parseInt(nRaw, 10) || 1));
          const steps = [];
          const cols = new Set();
          const d1 = new Set();
          const d2 = new Set();
          const queens = [];
          const boards = [];
          let budget = 40;
          const render = (mark) =>
            grid(n, n, (r, c) => {
              const queen = queens[r] === c;
              const attacked = cols.has(c) || d1.has(r - c) || d2.has(r + c);
              const isMark = mark && mark[0] === r && mark[1] === c;
              return {
                v: queen ? "Q" : "·",
                state: isMark ? mark[2] : queen ? "good" : attacked ? "bad" : "dim",
              };
            });
          steps.push({
            title: `${n}×${n} board; nothing placed yet`,
            kind: "grid", rows: n, cols: n,
            cells: render(),
            rowHeads: Array.from({ length: n }, (_, i) => `r${i}`),
            colHeads: Array.from({ length: n }, (_, i) => `c${i}`),
            counters: [count("row", 0, n), count("solutions", 0)],
            legend: LEG,
            happened: "Exactly one queen goes in each row.",
            why: "Fixing one queen per row removes row conflicts automatically.",
            codeLine: 3,
          });
          const record = (st) => { if (budget > 0) { steps.push(st); budget--; } };
          const place = (row) => {
            if (row === n) {
              boards.push(queens.slice());
              record({
                title: `Solution ${boards.length}: columns ${show(queens)}`,
                kind: "grid", rows: n, cols: n,
                cells: grid(n, n, (r, c) => ({ v: queens[r] === c ? "Q" : "·", state: queens[r] === c ? "result" : "dim" })),
                rowHeads: Array.from({ length: n }, (_, i) => `r${i}`),
                colHeads: Array.from({ length: n }, (_, i) => `c${i}`),
                counters: [count("solutions", boards.length), count("queens", n)],
                legend: LEG,
                happened: `No two queens share a column or diagonal.`,
                why: "Each placement was checked against all earlier queens.",
                codeLine: 4,
              });
              return;
            }
            for (let col = 0; col < n; col++) {
              if (cols.has(col) || d1.has(row - col) || d2.has(row + col)) {
                record({
                  title: `Row ${row}, column ${col}: attacked → skip`,
                  kind: "grid", rows: n, cols: n,
                  cells: render([row, col, "bad"]),
                  rowHeads: Array.from({ length: n }, (_, i) => `r${i}`),
                  colHeads: Array.from({ length: n }, (_, i) => `c${i}`),
                  counters: [count("row", row, n), count("solutions", boards.length)],
                  legend: LEG,
                  happened: cols.has(col) ? "The column is already used." : "An earlier queen sees this diagonal.",
                  why: "Columns and both diagonals must stay free.",
                  codeLine: 8,
                });
                continue;
              }
              queens[row] = col;
              cols.add(col); d1.add(row - col); d2.add(row + col);
              record({
                title: `Place queen at (${row}, ${col})`,
                kind: "grid", rows: n, cols: n,
                cells: render([row, col, "good"]),
                rowHeads: Array.from({ length: n }, (_, i) => `r${i}`),
                colHeads: Array.from({ length: n }, (_, i) => `c${i}`),
                counters: [count("row", row + 1, n), count("solutions", boards.length)],
                legend: LEG,
                happened: `Column ${col} and both diagonals of row ${row} are now blocked.`,
                why: "A safe square is one that no earlier queen attacks.",
                codeLine: 11,
              });
              place(row + 1);
              queens[row] = -1;
              cols.delete(col); d1.delete(row - col); d2.delete(row + col);
            }
          };
          for (let r = 0; r < n; r++) queens[r] = -1;
          place(0);
          steps.push({
            title: `Answer: ${boards.length} solution${boards.length === 1 ? "" : "s"}`,
            tracks: [chips("solutions", boards.length ? boards.map((b) => b.join(",")) : ["none"], "result")],
            counters: [count("solutions", boards.length), count("size", n)],
            legend: LEG,
            happened: boards.length ? "Every solution places all n queens safely." : "No arrangement avoids every attack.",
            why: "The search tries every column in every row and backtracks on attacks.",
            codeLine: 16,
          });
          return steps;
        },
      },
    ],
  });
})();
