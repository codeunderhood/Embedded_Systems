/* ============================================================
   DSA Visuals — Binary Search Answers I
   Sorted matrices, peaks and the one unpaired value. The common
   thread: a comparison removes half of the candidates.
   ============================================================ */
(function () {
  "use strict";
  const { track, fill, count, grid } = window.H;
  const V = window.VIZ;

  const LEG = ["read", "done", "active", "compare", "result", "good", "bad", "dim", "idle"];
  const chips = (label, values, stateFor) => ({
    label,
    cells: values.map((v, i) => ({
      v: String(v),
      state: typeof stateFor === "function" ? stateFor(i) : stateFor || "idle",
    })),
  });
  const show = (a) => `[${a.join(", ")}]`;
  const block = (nums, cols) => {
    const width = Math.max(1, cols || 3);
    const rows = Math.max(1, Math.ceil(nums.length / width));
    const out = [];
    for (let r = 0; r < rows; r++) {
      const row = nums.slice(r * width, r * width + width);
      while (row.length < width) row.push("");
      out.push(row);
    }
    return out;
  };

  /* ---------------------------------------------------------- */
  V.register({
    id: "median-of-two-sorted-arrays",
    title: "Median of Two Sorted Arrays",
    category: "Binary Search",
    difficulty: "Advanced",
    description:
      "Find the median of two sorted rows in logarithmic time by binary searching the split point.",
    input: {
      label: "row 1 | row 2 (both sorted)",
      default: "1, 3, 8, 9 | 2, 4, 7, 10, 11",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Partition the Shorter Row",
        complexity: "O(log min(n, m)) time, O(1) space",
        idea: [
          "The median splits the combined data into a left half and a right half of known sizes. Guess how many values come from the first row.",
          "A correct split has the largest left value no greater than the smallest right value on both rows. Binary search moves the cut until that holds.",
        ],
        problem: [
          "The boundary checks use sentinels for empty sides, and off-by-one errors there are the classic failure of this method.",
        ],
        code: {
          c: `#include <stdio.h>\n\n#define MIN(a,b) ((a) < (b) ? (a) : (b))\n#define MAX(a,b) ((a) > (b) ? (a) : (b))\n\ndouble median(const int *a, int n, const int *b, int m) {\n    if (n > m) return median(b, m, a, n);   /* search the shorter row */\n    int half = (n + m + 1) / 2;\n    int lo = 0, hi = n;\n\n    while (lo <= hi) {\n        int cutA = (lo + hi) / 2;\n        int cutB = half - cutA;\n\n        int leftA  = cutA == 0 ? -1000000 : a[cutA - 1];\n        int rightA = cutA == n ?  1000000 : a[cutA];\n        int leftB  = cutB == 0 ? -1000000 : b[cutB - 1];\n        int rightB = cutB == m ?  1000000 : b[cutB];\n\n        if (leftA <= rightB && leftB <= rightA) {\n            if ((n + m) % 2) return MAX(leftA, leftB);\n            return (MAX(leftA, leftB) + MIN(rightA, rightB)) / 2.0;\n        }\n        if (leftA > rightB) hi = cutA - 1;\n        else lo = cutA + 1;\n    }\n    return 0.0;\n}\n\nint main(void) {\n    int a[] = {1, 3, 8, 9}, b[] = {2, 4, 7, 10, 11};\n    printf(\"%.1f\\\\n\", median(a, 4, b, 5)); /* 7.0 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\n#include <climits>\nusing namespace std;\n\ndouble findMedian(const vector<int>& a, const vector<int>& b) {\n    if (a.size() > b.size()) return findMedian(b, a);\n    int n = a.size(), m = b.size();\n    int half = (n + m + 1) / 2;\n    int lo = 0, hi = n;\n\n    while (lo <= hi) {\n        int cutA = (lo + hi) / 2;\n        int cutB = half - cutA;\n        int leftA  = cutA == 0 ? INT_MIN : a[cutA - 1];\n        int rightA = cutA == n ? INT_MAX : a[cutA];\n        int leftB  = cutB == 0 ? INT_MIN : b[cutB - 1];\n        int rightB = cutB == m ? INT_MAX : b[cutB];\n\n        if (leftA <= rightB && leftB <= rightA) {\n            if ((n + m) % 2) return max(leftA, leftB);\n            return (max(leftA, leftB) + min(rightA, rightB)) / 2.0;\n        }\n        if (leftA > rightB) hi = cutA - 1;\n        else lo = cutA + 1;\n    }\n    return 0.0;\n}\n\nint main() {\n    cout << findMedian({1, 3, 8, 9}, {2, 4, 7, 10, 11}) << '\\\\n'; // 7\n}`,
        },
        steps(rows) {
          let A = (rows[0] || []).slice().sort((x, y) => x - y);
          let B = (rows[1] || []).slice().sort((x, y) => x - y);
          if (!A.length && !B.length) {
            return [{
              title: "Give two sorted rows",
              tracks: [chips("row 1", ["—"], "idle"), chips("row 2", ["—"], "idle")],
              counters: [count("values", 0)],
              legend: ["idle", "result"],
              happened: "There is no data to take a median of.",
              why: "The partition method expects two rows, at least one of which is non-empty.",
            }];
          }
          if (A.length > B.length) { const t = A; A = B; B = t; }
          const n = A.length, m = B.length;
          const half = Math.floor((n + m + 1) / 2);
          const steps = [];
          steps.push({
            title: `Search the shorter row (${n} values); left half needs ${half}`,
            tracks: [
              track("row A (shorter)", A, fill(n, "idle")),
              track("row B", B, fill(m, "idle")),
            ],
            counters: [count("values", n + m), count("left half size", half)],
            legend: LEG,
            happened: `The combined data has ${n + m} values, so the left half must hold ${half}.`,
            why: "Cutting the shorter row means fewer binary-search steps and never a negative cut.",
            codeLine: 5,
          });
          let lo = 0, hi = n;
          let answer = 0, odd = (n + m) % 2 === 1;
          while (lo <= hi) {
            const cutA = Math.floor((lo + hi) / 2);
            const cutB = half - cutA;
            const leftA = cutA === 0 ? -Infinity : A[cutA - 1];
            const rightA = cutA === n ? Infinity : A[cutA];
            const leftB = cutB === 0 ? -Infinity : B[cutB - 1];
            const rightB = cutB === m ? Infinity : B[cutB];
            const ok = leftA <= rightB && leftB <= rightA;
            if (ok) {
              answer = odd ? Math.max(leftA, leftB) : (Math.max(leftA, leftB) + Math.min(rightA, rightB)) / 2;
            }
            steps.push({
              title: `Cut A after ${cutA}, B after ${cutB}${ok ? " ✓" : ""}`,
              tracks: [
                track("row A (shorter)", A, A.map((_, i) => (i < cutA ? "done" : i === cutA ? "read" : "dim"))),
                track("row B", B, B.map((_, i) => (i < cutB ? "done" : i === cutB ? "read" : "dim"))),
                chips("left edge", [leftA, leftB], ok ? "good" : "compare"),
                chips("right edge", [rightA, rightB], ok ? "good" : "compare"),
              ],
              counters: [count("cut in A", cutA, n), count("cut in B", cutB, m)],
              legend: LEG,
              happened: ok
                ? `The left values ${Math.max(leftA, leftB)} are no greater than the right values ${Math.min(rightA, rightB)}, so the split is valid.`
                : leftA > rightB
                  ? `A's left value ${leftA} is larger than B's right ${rightB}, so the cut in A moves left.`
                  : `B's left value ${leftB} is larger than A's right ${rightA}, so the cut in A moves right.`,
              why: "A valid split means every left value belongs before every right value.",
              codeLine: ok ? 18 : leftA > rightB ? 22 : 23,
            });
            if (ok) break;
            if (leftA > rightB) hi = cutA - 1;
            else lo = cutA + 1;
          }
          steps.push({
            title: `Answer: median ${answer}`,
            tracks: [
              track("row A", A, fill(n, "done")),
              track("row B", B, fill(m, "done")),
              chips("answer", [answer], "result"),
            ],
            counters: [count("values", n + m), count("answer", answer)],
            legend: LEG,
            happened: odd
              ? `With an odd total, the median is the largest value in the left half: ${answer}.`
              : `With an even total, the median averages the inner pair: ${answer}.`,
            why: "The binary search only moves the cut, so the cost is logarithmic in the shorter row.",
            codeLine: 19,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "search-a-2d-matrix",
    title: "Search a 2D Matrix",
    category: "Binary Search",
    difficulty: "Intermediate",
    description:
      "Search a matrix whose rows continue one after another as if it were one sorted row.",
    input: {
      label: "row 1 = matrix values, row 2 = target",
      default: "1,3,5,7,9,11,13,15,17 | 9",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Treat It as One Row",
        complexity: "O(log(rows × cols)) time, O(1) space",
        idea: [
          "Because each row starts above the previous row's last value, reading the matrix row by row gives one sorted sequence.",
          "Binary search that virtual sequence and convert the found index back into a row and column with division and remainder.",
        ],
        problem: [
          "The shortcut relies on the row-wrap ordering; a matrix sorted only by rows and columns separately needs a different walk.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint search(int a[3][3], int rows, int cols, int target) {\n    int lo = 0, hi = rows * cols - 1;\n    while (lo <= hi) {\n        int mid = lo + (hi - lo) / 2;\n        int value = a[mid / cols][mid % cols];\n        if (value == target) return mid;\n        if (value < target) lo = mid + 1;\n        else hi = mid - 1;\n    }\n    return -1;\n}\n\nint main(void) {\n    int a[3][3] = {{1,3,5},{7,9,11},{13,15,17}};\n    printf(\"%d\\\\n\", search(a, 3, 3, 9)); /* 4 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nbool searchMatrix(const vector<vector<int>>& a, int target) {\n    int rows = a.size(), cols = a[0].size();\n    int lo = 0, hi = rows * cols - 1;\n    while (lo <= hi) {\n        int mid = lo + (hi - lo) / 2;\n        int value = a[mid / cols][mid % cols];\n        if (value == target) return true;\n        if (value < target) lo = mid + 1;\n        else hi = mid - 1;\n    }\n    return false;\n}\n\nint main() {\n    vector<vector<int>> a{{1,3,5},{7,9,11},{13,15,17}};\n    cout << searchMatrix(a, 9) << '\\\\n'; // 1\n}`,
        },
        steps(rows) {
          const flat = (rows[0] || []).slice().sort((x, y) => x - y);
          const target = (rows[1] || [])[0];
          const cols = 3;
          const m = block(flat, cols);
          const R = m.length, C = cols;
          const steps = [];
          if (!flat.length) {
            return [{
              title: "Give a matrix and a target",
              kind: "grid", rows: 1, cols: 1,
              cells: grid(1, 1, () => ({ v: "—", state: "idle" })),
              counters: [count("values", 0)],
              legend: ["idle", "result"],
              happened: "The first row holds the matrix, the second row the target.",
              why: "A search needs data and something to look for.",
            }];
          }
          const at = (k) => [Math.floor(k / C), k % C];
          steps.push({
            title: `${R} × ${C} matrix read as ${flat.length} sorted slots`,
            kind: "grid", rows: R, cols: C,
            rowHeads: Array.from({ length: R }, (_, i) => `r${i}`),
            colHeads: Array.from({ length: C }, (_, i) => `c${i}`),
            cells: grid(R, C, (r, c) => ({ v: m[r][c], state: "idle" })),
            counters: [count("slots", flat.length), count("target", target)],
            legend: LEG,
            happened: `Index k maps to row k ÷ ${C} and column k mod ${C}.`,
            why: "One binary search over the virtual row avoids searching each row separately.",
            codeLine: 3,
          });
          let lo = 0, hi = flat.length - 1, found = -1;
          while (lo <= hi) {
            const mid = lo + Math.floor((hi - lo) / 2);
            const [r, c] = at(mid);
            const v = m[r][c];
            if (v === target) found = mid;
            steps.push({
              title: `Slot ${mid} → (${r},${c}) holds ${v}${v === target ? " ✓" : ""}`,
              kind: "grid", rows: R, cols: C,
              rowHeads: Array.from({ length: R }, (_, i) => `r${i}`),
              colHeads: Array.from({ length: C }, (_, i) => `c${i}`),
              cells: grid(R, C, (rr, cc) => ({
                v: m[rr][cc],
                state: rr === r && cc === c ? (v === target ? "good" : "read") : (rr * C + cc < lo || rr * C + cc > hi) ? "dim" : "idle",
              })),
              counters: [count("window", `${lo}..${hi}`), count("slot", mid)],
              legend: LEG,
              happened: `The middle slot ${mid} stores ${v}, which is ${v === target ? "the target" : v < target ? "too small, so the right half remains" : "too large, so the left half remains"}.`,
              why: "The virtual index keeps the search window contiguous even though it spans rows.",
              codeLine: 6,
            });
            if (v === target) break;
            if (v < target) lo = mid + 1;
            else hi = mid - 1;
          }
          const [fr, fc] = found >= 0 ? at(found) : [0, 0];
          steps.push({
            title: found >= 0 ? `Answer: found at (${fr},${fc})` : `Answer: ${target} is absent`,
            kind: "grid", rows: R, cols: C,
            cells: grid(R, C, (r, c) => ({
              v: m[r][c],
              state: found >= 0 && r === fr && c === fc ? "good" : "idle",
            })),
            counters: [count("slots", flat.length), count("answer", found >= 0 ? `(${fr},${fc})` : "absent")],
            legend: LEG,
            happened: found >= 0 ? `Slot ${found} translates to row ${fr}, column ${fc}.` : `The window emptied without meeting ${target}.`,
            why: "The division and remainder convert the flat answer back into coordinates.",
            codeLine: 8,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "search-a-2d-matrix-ii",
    title: "Search a 2D Matrix II",
    category: "Binary Search",
    difficulty: "Intermediate",
    description:
      "Rows are sorted left to right and columns top to bottom; search by walking from the top-right corner.",
    input: {
      label: "row 1 = matrix values, row 2 = target",
      default: "1,4,7,11, 2,5,8,12, 3,6,9,16 | 5",
      parse: "tworows",
    },
    approaches: [
      {
        name: "Walk Down and Left",
        complexity: "O(rows + cols) time, O(1) space",
        idea: [
          "Start at the top-right corner. Its value is the largest in its row and the smallest in its column.",
          "If the value is too large, the whole column can be discarded by moving left. If it is too small, the whole row can be discarded by moving down.",
        ],
        problem: [
          "The walk is not a binary search, so a huge square matrix costs O(n) rather than O(log n).",
        ],
        code: {
          c: `#include <stdio.h>\n\nint search(int a[3][4], int rows, int cols, int target) {\n    int r = 0, c = cols - 1;\n    while (r < rows && c >= 0) {\n        if (a[r][c] == target) return 1;\n        if (a[r][c] > target) c--;      /* drop this column */\n        else r++;                       /* drop this row */\n    }\n    return 0;\n}\n\nint main(void) {\n    int a[3][4] = {{1,4,7,11},{2,5,8,12},{3,6,9,16}};\n    printf(\"%d\\\\n\", search(a, 3, 4, 5)); /* 1 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nbool searchMatrix(const vector<vector<int>>& a, int target) {\n    int r = 0, c = (int)a[0].size() - 1;\n    while (r < (int)a.size() && c >= 0) {\n        if (a[r][c] == target) return true;\n        if (a[r][c] > target) c--;\n        else r++;\n    }\n    return false;\n}\n\nint main() {\n    vector<vector<int>> a{{1,4,7,11},{2,5,8,12},{3,6,9,16}};\n    cout << searchMatrix(a, 5) << '\\\\n'; // 1\n}`,
        },
        steps(rows) {
          const flat = (rows[0] || []).slice();
          const target = (rows[1] || [])[0];
          const C = 4;
          const m = block(flat, C);
          const R = m.length;
          const steps = [];
          if (!flat.length) {
            return [{
              title: "Give a matrix and a target",
              kind: "grid", rows: 1, cols: 1,
              cells: grid(1, 1, () => ({ v: "—", state: "idle" })),
              counters: [count("values", 0)],
              legend: ["idle", "result"],
              happened: "Nothing to search.",
              why: "The walk starts at the top-right corner.",
            }];
          }
          let r = 0, c = C - 1;
          steps.push({
            title: `Start at top-right (${r},${c}) = ${m[r][c]}`,
            kind: "grid", rows: R, cols: C,
            cells: grid(R, C, (rr, cc) => ({ v: m[rr][cc], state: rr === r && cc === c ? "read" : "idle" })),
            counters: [count("row", r), count("column", c)],
            legend: LEG,
            happened: `The corner value is the largest in row ${r} and the smallest in column ${c}.`,
            why: "That double property lets one comparison discard an entire line.",
            codeLine: 4,
          });
          let found = false;
          while (r < R && c >= 0) {
            const v = m[r][c];
            if (v === target) { found = true; }
            steps.push({
              title: v === target ? `(${r},${c}) = ${v} ✓` : `(${r},${c}) = ${v} → ${v > target ? "move left" : "move down"}`,
              kind: "grid", rows: R, cols: C,
              cells: grid(R, C, (rr, cc) => ({
                v: m[rr][cc],
                state: rr === r && cc === c ? (v === target ? "good" : "read") : (rr < r || cc > c) ? "dim" : "idle",
              })),
              counters: [count("row", r), count("column", c)],
              legend: LEG,
              happened: v === target
                ? "The target is at this corner."
                : v > target
                  ? `${v} is too large, and the rest of column ${c} is even larger, so the column is dropped.`
                  : `${v} is too small, and the rest of row ${r} is even smaller, so the row is dropped.`,
              why: "Every move removes one full row or column from consideration.",
              codeLine: v > target ? 7 : 8,
            });
            if (found) break;
            if (v > target) c--;
            else r++;
          }
          steps.push({
            title: found ? `Answer: found at (${r},${c})` : `Answer: ${target} is absent`,
            kind: "grid", rows: R, cols: C,
            cells: grid(R, C, (rr, cc) => ({ v: m[rr][cc], state: found && rr === r && cc === c ? "result" : "dim" })),
            counters: [count("rows dropped", r), count("columns dropped", C - 1 - c)],
            legend: LEG,
            happened: found ? `The walk stopped exactly on ${target}.` : `The corner left the matrix, so the value cannot be present.`,
            why: "At most rows + cols corners are visited before the walk falls off the grid.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "find-peak-element",
    title: "Find Peak Element",
    category: "Binary Search",
    difficulty: "Intermediate",
    description:
      "Find any position whose value is greater than both neighbours, in logarithmic time.",
    input: { label: "The numbers", default: "1, 2, 3, 1", parse: "ints" },
    approaches: [
      {
        name: "Follow the Slope",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "Compare the middle value with its right neighbour. If the row is rising there, a peak must exist somewhere to the right; if it is falling, a peak exists to the left.",
          "Treat the ends as −∞ so a rising edge is a peak in itself. This keeps the halving rule valid at the boundaries.",
        ],
        problem: [
          "The method returns some peak, not necessarily the highest one, so it cannot answer questions about the maximum value.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint find_peak(const int *a, int n) {\n    int lo = 0, hi = n - 1;\n    while (lo < hi) {\n        int mid = (lo + hi) / 2;\n        if (a[mid] < a[mid + 1]) lo = mid + 1;  /* rising: peak is right */\n        else hi = mid;                          /* falling: peak is here or left */\n    }\n    return lo;\n}\n\nint main(void) {\n    int a[] = {1, 2, 3, 1};\n    printf(\"%d\\\\n\", find_peak(a, 4)); /* 2 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint findPeakElement(const vector<int>& a) {\n    int lo = 0, hi = (int)a.size() - 1;\n    while (lo < hi) {\n        int mid = (lo + hi) / 2;\n        if (a[mid] < a[mid + 1]) lo = mid + 1;\n        else hi = mid;\n    }\n    return lo;\n}\n\nint main() {\n    vector<int> a{1, 2, 3, 1};\n    cout << findPeakElement(a) << '\\\\n'; // 2\n}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          if (!n) {
            return [{
              title: "Give at least one value",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("length", 0)],
              legend: ["idle", "result"],
              happened: "An empty row has no peak.",
              why: "A single value already counts as a peak by the edge rule.",
            }];
          }
          let lo = 0, hi = n - 1;
          steps.push({
            title: `${n} values: compare the middle with its right neighbour`,
            tracks: [track("numbers", nums, fill(n, "idle"))],
            counters: [count("window", `${lo}..${hi}`), count("comparisons", 0)],
            legend: LEG,
            happened: "Outside the row the values are treated as −∞, so the ends can be peaks.",
            why: "A rising slope guarantees a peak to the right; a falling slope guarantees one here or to the left.",
            codeLine: 3,
          });
          let cmp = 0;
          while (lo < hi) {
            const mid = Math.floor((lo + hi) / 2);
            cmp++;
            const a = nums[mid], b = nums[mid + 1];
            const rising = a < b;
            steps.push({
              title: `${a} ${rising ? "<" : "≥"} ${b} → keep ${rising ? "right" : "left"}`,
              tracks: [
                track("numbers", nums, nums.map((v, i) => {
                  if (i === mid || i === mid + 1) return "compare";
                  if (i < lo || i > hi) return "dim";
                  return "idle";
                })),
                chips("window", [`${lo}..${hi}`], "read"),
              ],
              counters: [count("window", `${lo}..${hi}`), count("comparisons", cmp)],
              legend: LEG,
              happened: rising
                ? `The slope rises at ${mid}, so a peak must exist in ${mid + 1}..${hi}.`
                : `The slope falls at ${mid}, so a peak must exist in ${lo}..${mid}.`,
              why: "Walking uphill must eventually reach a peak unless the edge is reached, and the edge counts.",
              codeLine: rising ? 5 : 6,
            });
            if (rising) lo = mid + 1;
            else hi = mid;
          }
          steps.push({
            title: `Answer: index ${lo} holds peak ${nums[lo]}`,
            tracks: [
              track("numbers", nums, nums.map((v, i) => (i === lo ? "result" : Math.abs(i - lo) === 1 ? "compare" : "dim"))),
              chips("answer", [`index ${lo}`], "result"),
            ],
            counters: [count("window", `${lo}..${lo}`), count("comparisons", cmp)],
            legend: LEG,
            happened: `${nums[lo]} is at least as large as its neighbours${lo > 0 ? ` (${nums[lo - 1]})` : ""}${lo + 1 < n ? ` (${nums[lo + 1]})` : ""}.`,
            why: "The search halved the window each time, so only log n comparisons were needed.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "peak-index-in-a-mountain-array",
    title: "Peak Index in a Mountain Array",
    category: "Binary Search",
    difficulty: "Intermediate",
    description:
      "The row rises then falls; find the summit with binary search.",
    input: { label: "The numbers", default: "0, 2, 5, 3, 1", parse: "ints" },
    approaches: [
      {
        name: "Binary Search the Summit",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "On the rising side the next value is larger; on the falling side it is smaller. So one comparison tells which side of the summit the middle sits on.",
          "Move the low or high boundary the same way as a normal binary search until both meet at the summit.",
        ],
        problem: [
          "If the row is not truly a mountain, the search lands on an arbitrary turning point instead of reporting bad input.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint peak_index(const int *a, int n) {\n    int lo = 0, hi = n - 1;\n    while (lo < hi) {\n        int mid = (lo + hi) / 2;\n        if (a[mid] < a[mid + 1]) lo = mid + 1;\n        else hi = mid;\n    }\n    return lo;\n}\n\nint main(void) {\n    int a[] = {0, 2, 5, 3, 1};\n    printf(\"%d\\\\n\", peak_index(a, 5)); /* 2 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint peakIndexInMountainArray(const vector<int>& a) {\n    int lo = 0, hi = (int)a.size() - 1;\n    while (lo < hi) {\n        int mid = (lo + hi) / 2;\n        if (a[mid] < a[mid + 1]) lo = mid + 1;\n        else hi = mid;\n    }\n    return lo;\n}\n\nint main() {\n    vector<int> a{0, 2, 5, 3, 1};\n    cout << peakIndexInMountainArray(a) << '\\\\n'; // 2\n}`,
        },
        steps(nums) {
          const n = nums.length;
          const steps = [];
          if (!n) {
            return [{
              title: "Give a mountain profile",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("length", 0)],
              legend: ["idle", "result"],
              happened: "No values, no summit.",
              why: "A mountain rises then falls, so it needs at least one value.",
            }];
          }
          let lo = 0, hi = n - 1;
          steps.push({
            title: "The summit is where the slope changes from up to down",
            tracks: [track("numbers", nums, fill(n, "idle"))],
            counters: [count("window", `${lo}..${hi}`), count("comparisons", 0)],
            legend: LEG,
            happened: `The row is ${show(nums)}.`,
            why: "While the slope is rising, the summit is to the right of the middle.",
            codeLine: 3,
          });
          let cmp = 0;
          while (lo < hi) {
            const mid = Math.floor((lo + hi) / 2);
            cmp++;
            const rising = nums[mid] < nums[mid + 1];
            steps.push({
              title: `${nums[mid]} ${rising ? "<" : ">"} ${nums[mid + 1]} → summit in ${rising ? `${mid + 1}..${hi}` : `${lo}..${mid}`}`,
              tracks: [
                track("numbers", nums, nums.map((v, i) => (i === mid || i === mid + 1 ? "compare" : i < lo || i > hi ? "dim" : "idle"))),
                chips("slope", [rising ? "rising ↑" : "falling ↓"], rising ? "active" : "done"),
              ],
              counters: [count("window", `${lo}..${hi}`), count("comparisons", cmp)],
              legend: LEG,
              happened: rising ? "Still climbing, so discard the left part." : "Now descending, so the summit is here or to the left.",
              why: "A mountain has exactly one change of slope, so the comparison cannot mislead.",
              codeLine: rising ? 5 : 6,
            });
            if (rising) lo = mid + 1;
            else hi = mid;
          }
          steps.push({
            title: `Answer: summit at index ${lo} (height ${nums[lo]})`,
            tracks: [
              track("numbers", nums, nums.map((v, i) => (i === lo ? "result" : "dim"))),
              chips("answer", [nums[lo]], "result"),
            ],
            counters: [count("window", `${lo}..${lo}`), count("comparisons", cmp)],
            legend: LEG,
            happened: `The boundaries met at ${lo}, where the rise turns into a fall.`,
            why: "Halving the window each step gives logarithmic time.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });

  /* ---------------------------------------------------------- */
  V.register({
    id: "single-element-in-a-sorted-array",
    title: "Single Element in a Sorted Array",
    category: "Binary Search",
    difficulty: "Intermediate",
    description:
      "Every value appears twice except one; locate the unpaired value in logarithmic time.",
    input: { label: "The numbers", default: "1, 1, 2, 2, 3, 3, 4, 8, 8", parse: "ints" },
    approaches: [
      {
        name: "Searching on Pair Starts",
        complexity: "O(log n) time, O(1) space",
        idea: [
          "Before the single value, pairs start at even indices; after it, the pairing shifts and pairs start at odd indices.",
          "Look at the middle pair. If it starts on an even index, the single value is to the right; otherwise it is to the left.",
        ],
        problem: [
          "The index arithmetic assumes the single value exists exactly once and all others appear exactly twice.",
        ],
        code: {
          c: `#include <stdio.h>\n\nint single_non_duplicate(const int *a, int n) {\n    int lo = 0, hi = n - 1;\n    while (lo < hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (mid % 2 == 1) mid--;              /* align to a pair start */\n        if (a[mid] == a[mid + 1]) lo = mid + 2; /* pair intact: go right */\n        else hi = mid;                        /* pair broken: go left */\n    }\n    return a[lo];\n}\n\nint main(void) {\n    int a[] = {1, 1, 2, 2, 3, 3, 4, 8, 8};\n    printf(\"%d\\\\n\", single_non_duplicate(a, 9)); /* 4 */\n    return 0;\n}`,
          cpp: `#include <iostream>\n#include <vector>\nusing namespace std;\n\nint singleNonDuplicate(const vector<int>& a) {\n    int lo = 0, hi = (int)a.size() - 1;\n    while (lo < hi) {\n        int mid = lo + (hi - lo) / 2;\n        if (mid % 2 == 1) mid--;\n        if (a[mid] == a[mid + 1]) lo = mid + 2;\n        else hi = mid;\n    }\n    return a[lo];\n}\n\nint main() {\n    vector<int> a{1, 1, 2, 2, 3, 3, 4, 8, 8};\n    cout << singleNonDuplicate(a) << '\\\\n'; // 4\n}`,
        },
        steps(nums) {
          const a = nums.slice().sort((x, y) => x - y);
          const n = a.length;
          const steps = [];
          if (!n) {
            return [{
              title: "Give a row with one unpaired value",
              tracks: [chips("numbers", ["—"], "idle")],
              counters: [count("length", 0)],
              legend: ["idle", "result"],
              happened: "No values to pair.",
              why: "The method searches for where the pairing pattern flips.",
            }];
          }
          let lo = 0, hi = n - 1;
          steps.push({
            title: `${n} values: pairs start at even indices until the single value`,
            tracks: [track("numbers", a, fill(n, "idle"))],
            counters: [count("window", `${lo}..${hi}`), count("comparisons", 0)],
            legend: LEG,
            happened: `Sorted, the row is ${show(a)}.`,
            why: "Before the single value each pair begins at an even index; afterwards the parity flips.",
            codeLine: 3,
          });
          let cmp = 0;
          while (lo < hi) {
            let mid = lo + Math.floor((hi - lo) / 2);
            if (mid % 2 === 1) mid--;
            cmp++;
            const intact = a[mid] === a[mid + 1];
            steps.push({
              title: `Pair at ${mid},${mid + 1}: ${a[mid]},${a[mid + 1]} — ${intact ? "intact, go right" : "broken, go left"}`,
              tracks: [
                track("numbers", a, a.map((v, i) => (i === mid || i === mid + 1 ? (intact ? "done" : "bad") : i < lo || i > hi ? "dim" : "idle"))),
                chips("pair start parity", [mid % 2 === 0 ? "even" : "odd"], "read"),
              ],
              counters: [count("window", `${lo}..${hi}`), count("comparisons", cmp)],
              legend: LEG,
              happened: intact
                ? "The pair is still together, so the single value has not shifted the pairing yet."
                : "The pair is broken, so the single value sits at or before this pair.",
              why: "Parity of the pair start is the signal that distinguishes the two sides of the single value.",
              codeLine: intact ? 6 : 7,
            });
            if (intact) lo = mid + 2;
            else hi = mid;
          }
          steps.push({
            title: `Answer: ${a[lo]} appears once`,
            tracks: [
              track("numbers", a, a.map((v, i) => (i === lo ? "result" : "dim"))),
              chips("answer", [a[lo]], "result"),
            ],
            counters: [count("window", `${lo}..${lo}`), count("comparisons", cmp)],
            legend: LEG,
            happened: `${a[lo]} has no partner, so it is the single value.`,
            why: "The window shrinks by half each time, so the parity check needs only log n steps.",
            codeLine: 9,
          });
          return steps;
        },
      },
    ],
  });
})();
