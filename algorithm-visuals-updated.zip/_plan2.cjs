﻿const fs=require("fs");
const rows=JSON.parse(fs.readFileSync("_remaining.json","utf8"));
const byCat={};
for(const r of rows){ (byCat[r.category] ||= []).push(r); }
const plan=[];
function add(file, items){ plan.push({file, items}); }
const C=byCat;
function split(cat, size, prefix){
  const arr=C[cat]||[];
  let i=0;
  while(i<arr.length){ add(prefix+"-"+(Math.floor(i/size)+1)+".js", arr.slice(i,i+size)); i+=size; }
}
split("Advanced Structures",8,"advanced-structures");
split("Bits & Bit Tricks",9,"bit-tricks");
add("sweep-and-geometry.js", [...C["Sweep Line"], ...C["Geometry"]]);
split("Complexity Lab",7,"complexity-lab");
split("Array Techniques",7,"array-techniques");
split("Binary Search",6,"binary-search-answers");
split("Strings & Text",7,"strings-advanced");
split("Heaps & Top-K",7,"heaps-topk");
add("sorting-advanced.js", [...C["Sorting & Intervals"], ...C["Sorting Algorithms"]]);
split("Linked Lists",6,"linked-lists-advanced");
split("Design & Hashing",8,"design-hashing");
add("windows-and-prefix.js", [...C["Sliding Window"], ...C["Prefix Sums"]]);
add("monotonic-stack.js", C["Monotonic Stack"]);
add("queues-and-deques.js", C["Queues & Deques"]);
split("Divide & Conquer",8,"divide-conquer");
split("Backtracking",7,"backtracking-advanced");
split("Trees",8,"trees-advanced");
add("tries-advanced.js", C["Tries"]);
split("Graphs",7,"graphs-advanced");
add("greedy-advanced.js", C["Greedy"]);
split("Dynamic Programming",7,"dp-more");
add("number-theory.js", C["Number Theory"]);
add("random-and-mixed.js", [...C["Randomization"], ...C["Mix & Match"]]);
let total=0;
for(const b of plan){ total+=b.items.length; }
fs.writeFileSync("_batches.json",JSON.stringify(plan,null,1));
console.log("batches",plan.length,"items",total);
for(const b of plan) console.log(b.file, b.items.length);
const covered=new Set(plan.flatMap(b=>b.items.map(i=>i.slug)));
const miss=rows.filter(r=>!covered.has(r.slug));
console.log("missing",miss.length);
