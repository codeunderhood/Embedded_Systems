﻿const fs=require("fs");const plan=JSON.parse(fs.readFileSync("_batches.json","utf8"));
const b=plan.find(x=>x.file==="bit-tricks-1.js");
console.log(b.items.map(i=>`- ${i.slug} | ${i.title} | ${i.category}`).join("\n"));
