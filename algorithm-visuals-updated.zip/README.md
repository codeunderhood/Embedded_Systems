# DSA Visuals

A local, dependency-free web app that walks through data-structure and algorithm
visualisations step by step — playback controls, a step timeline, live counters,
"What just happened / Why it matters" narration, and original C **and** C++ solutions
for every approach.

Open `index.html` in any browser (Chrome, Edge, Firefox, Safari). No build step,
no server, no internet connection required.

## Running it

* **Simplest:** double-click `index.html`.
* **Optional local server** (if your browser blocks something on `file://`):

  ```
  python -m http.server 8321
  ```

  then visit <http://localhost:8321/>.

Deep links work: `index.html#/p=sum-of-array-elements`.

## Using a visualisation

| Control | What it does |
|---|---|
| Approach tabs | Switch between alternative strategies (e.g. iterative vs recursive) |
| Input box + **Run** | Change the data — every visualisation recomputes its steps |
| ⏮ ◀ ▶ ▶▶ ⏭ ↺ | First / previous / play-pause / next / last / reset |
| Speed | Slow · Normal · Fast · Instant |
| Step timeline | Jump straight to any step |
| Idea / Problem / Code | Read the reasoning, the trade-off, and the C / C++ solutions |
| Keyboard | `←` `→` step, `Space` play/pause, `Home` / `End` jump |

Cell colours: green = current focus, solid green = handled, amber = result,
blue = in progress, violet = comparing, red = rejected, dashed = not looked at yet.
Each visualisation shows its own legend.

## Layout

```
index.html              app shell (loads everything)
css/styles.css          dark theme, cell-state palette, transitions
js/catalog-data.js      all 384 visualisation slugs, titles and categories
js/helpers.js           authoring helpers (tracks, trees, grids, counters)
js/engine.js            step player: routing, rendering, playback, code tabs
js/viz/*.js             one module per category; each self-registers
SPEC.md                 authoring contract for new visualisations
```

Every visualisation module is a plain IIFE that calls `window.VIZ.register({...})`
and turns an input into an array of steps — see `js/viz/array-foundations.js`
for the reference implementation and `SPEC.md` for the full contract.

## Adding a visualisation

1. Create `js/viz/<something>.js` following `SPEC.md`.
2. Add `<script src="js/viz/<something>.js"></script>` to `index.html`.
3. Reload; the entry appears in the sidebar automatically (all 384 slugs are
   already listed — written ones are clickable, the rest show "coming soon").

Validate everything with this in the browser console:

```js
__validateViz()
// → { total, ok, problems: [] }
```

## Content note

All animations, explanations, and C/C++ solutions in this project are original
educational material written for this app. The catalogue mirrors the topic list
the app aims to cover; no third-party site content is copied.
