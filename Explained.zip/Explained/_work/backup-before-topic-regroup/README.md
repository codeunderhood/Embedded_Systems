# DSA Code Explained

A local, dependency-free companion to **DSA Visuals**: every C program from the
original 452-question catalogue, explained **line by line in Hinglish** (Hindi in
Roman script + English technical terms), with the same visual shell — sidebar,
search, question badges, approach tabs and code pane.

Open `index.html` in any browser. No build step, no server, no internet needed.

```
Explained/
  index.html          app shell
  css/styles.css      original DSA Visuals theme (reused)
  css/explained.css   explanation table, summary card, home page
  js/questions.js     all 452 questions + C/C++ code + Hinglish notes
  js/app.js           sidebar, routing, line-by-line renderer
```

## What is inside

| | |
|---|---|
| Questions | **452** (properly numbered `Q001` … `Q452` in catalogue order) |
| Approaches | **508** C programs (multi-approach questions get tabs) |
| Explained lines | **11,408** C lines |
| NeetCode 250 | **250** marked with the `NC250` tag |

Each question page has:

* **Question number + title + difficulty + topic + description** in the top bar.
* **Approach tabs** when a question has more than one strategy.
* **"Is approach mein kya ho raha hai"** — a Hinglish summary plus complexity.
* **Line-by-line table** — C code on the left, Hinglish explanation on the right.
  Click any row to highlight it.
* **C++ version** toggle for reference (the line-by-line notes are for the C code).
* **Copy C** button.
* **Previous / Next** question links and arrow-key navigation.
* Collapsible original English *Idea* and *Trade-off* notes.

## Controls

| Control | What it does |
|---|---|
| Sidebar search | Filter by question number, title, slug, topic, level or NeetCode name |
| `Q001` badge | Current question number |
| Approach tabs | Switch between strategies |
| **Explanations: On/Off** | Show or hide the Hinglish column |
| **C++ version** | Show the C++ reference implementation |
| **Copy C** | Copy the current C program |
| `←` `→` | Previous / next question |
| `Home` / `End` | First / last question |

Deep links: `index.html#/q=42` or `index.html#/p=maximum-subarray`.

## Where the content came from

* The questions, C/C++ programs, titles, categories and original notes are taken
  from the sibling `../algorithm-visuals-updated` project (same catalogue order,
  so `Q001` here is the first catalogue entry there).
* The Hinglish line-by-line explanations were written for this app only. They
  follow the actual identifiers, values and printed output of each program, and
  call out real issues (missing headers, overflow, out-of-bounds, complexity
  mismatches) where they occur.

> Tip: this is a reading/study app. For the animated, step-by-step version of the
> same questions, open `../algorithm-visuals-updated/index.html`.
