#!/usr/bin/env python3
"""Validate the generated explanation batches before merging.

Compares every out_*.json against the batch files and reports:
missing approaches, line-count mismatches, empty/placeholder text,
suspiciously short lines, and repeated-line spam.

Usage: python3 _work/validate2.py
"""
import glob
import json
import os
import re

ROOT = "/home/nirmal/Desktop/Study/AI/DSA/Explained"
BATCH_GLOB = os.path.join(ROOT, "_work", "batches", "batch_*.json")
OUT_GLOBS = [
    os.path.join(ROOT, "_work", "out", "out_*.json"),
    "/tmp/opencode/explain2/out/out_*.json",
]
PLACEHOLDER = re.compile(
    r"(TODO|lorem ipsum|explanation not available|Yeh line program ke is step ko execute)", re.I
)

expected = {}
for path in sorted(glob.glob(BATCH_GLOB)):
    for q in json.load(open(path, encoding="utf-8")):
        for a in q["approaches"]:
            expected[(q["qno"], a["index"])] = (len(a["codeLines"]), q["title"], a["name"])

found = {}
bad_json = []
for pattern in OUT_GLOBS:
    for path in sorted(glob.glob(pattern)):
        base = os.path.basename(path)
        try:
            data = json.load(open(path, encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            bad_json.append((base, str(exc)))
            continue
        items = data.get("items") if isinstance(data, dict) else data
        if not isinstance(items, list):
            bad_json.append((base, "no items array"))
            continue
        for item in items:
            qno = item.get("qno")
            for ap in item.get("approaches", []):
                found[(qno, ap.get("index"))] = (base, ap)

missing = [k for k in expected if k not in found]
extra = [k for k in found if k not in expected]
bad = []
empty = []
short = []
long = []
placeholders = []
dup = []

for key, (src, ap) in found.items():
    if key not in expected:
        continue
    want, title, name = expected[key]
    lines = ap.get("lines")
    if not isinstance(lines, list):
        bad.append((key, "not a list", src))
        continue
    if len(lines) != want:
        bad.append((key, len(lines), want, src))
        continue
    counts = {}
    for i, text in enumerate(lines):
        if not isinstance(text, str) or not text.strip():
            empty.append((key, i, src))
            continue
        text = text.strip()
        if len(text) < 6:
            short.append((key, i, text, src))
        if len(text) > 400:
            long.append((key, i, len(text), src))
        if PLACEHOLDER.search(text):
            placeholders.append((key, i, text[:100], src))
        counts[text] = counts.get(text, 0) + 1
    if want >= 8:
        top = max(counts.values()) if counts else 0
        if top >= max(4, want // 3):
            dup.append((key, title, name, want, top, src))

print("expected approaches:", len(expected))
print("found approaches:   ", len(found))
print("missing:", len(missing), missing[:15])
print("extra:", len(extra), extra[:8])
print("bad json:", bad_json)
print("bad line counts:", bad[:10])
print("empty lines:", len(empty), empty[:8])
print("too short:", len(short), short[:8])
print("too long:", len(long), long[:5])
print("placeholder text:", len(placeholders), placeholders[:8])
print("high duplicate lines:", len(dup))
for row in sorted(dup, key=lambda r: -r[4])[:15]:
    print("  q%-3d %-40s want=%-3d dup=%-3d %s" % (row[0][0], row[1][:40], row[3], row[4], row[2][:40]))
