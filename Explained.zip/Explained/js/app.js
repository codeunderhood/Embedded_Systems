/* ============================================================
   DSA Code Explained — app shell
   Sidebar catalogue + question page + line-by-line Hinglish notes.
   ============================================================ */
(function () {
  "use strict";

  const QUESTIONS = (window.EXPLAINED_QUESTIONS || []).slice();
  const byNo = new Map(QUESTIONS.map((q) => [q.qno, q]));
  const bySlug = new Map(QUESTIONS.map((q) => [q.slug, q]));

  // One heading per subject, same order as the visuals catalogue.
  const TOPIC_ORDER = [
    "Arrays & Hashing",
    "Two Pointers",
    "Sliding Window",
    "Strings & Text",
    "Binary Search",
    "Sorting",
    "Intervals",
    "Linked List",
    "Stack",
    "Recursion",
    "Backtracking",
    "Trees",
    "Tries",
    "Heap / Priority Queue",
    "Graphs",
    "Advanced Graphs",
    "Dynamic Programming",
    "Greedy",
    "Bit Manipulation",
    "Math & Geometry",
    "Prefix Sums",
    "Design",
    "Advanced Structures",
    "Divide & Conquer",
    "Sweep Line",
    "Complexity Lab",
    "Randomization",
    "Mix & Match",
  ];
  const $ = (sel) => document.querySelector(sel);
  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  };
  const esc = (s) =>
    String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

  const state = {
    q: null,
    ai: 0,
    showEx: true,
    showCpp: false,
    query: "",
  };

  /* ---------------- C syntax highlighting ---------------- */
  const KW = new Set(
    "auto break case char const continue default do double else enum extern float for goto if inline int long register return short signed sizeof static struct switch typedef union unsigned void volatile while _Bool".split(" ")
  );

  function highlightC(line) {
    let out = "";
    let i = 0;
    while (i < line.length) {
      const c = line[i];
      if (c === "/" && line[i + 1] === "/") {
        out += '<span class="cm">' + esc(line.slice(i)) + "</span>";
        break;
      }
      if (c === "/" && line[i + 1] === "*") {
        const end = line.indexOf("*/", i + 2);
        const j = end < 0 ? line.length : end + 2;
        out += '<span class="cm">' + esc(line.slice(i, j)) + "</span>";
        i = j;
        continue;
      }
      if (c === '"' || c === "'") {
        const quote = c;
        let j = i + 1;
        while (j < line.length) {
          if (line[j] === "\\") j += 2;
          else if (line[j] === quote) { j++; break; }
          else j++;
        }
        out += '<span class="str">' + esc(line.slice(i, j)) + "</span>";
        i = j;
        continue;
      }
      if (/[A-Za-z_]/.test(c)) {
        let j = i + 1;
        while (j < line.length && /[A-Za-z0-9_]/.test(line[j])) j++;
        const word = line.slice(i, j);
        if (KW.has(word)) {
          out += '<span class="kw">' + word + "</span>";
        } else if (/^\s*\(/.test(line.slice(j))) {
          out += '<span class="fn">' + word + "</span>";
        } else {
          out += esc(word);
        }
        i = j;
        continue;
      }
      if (/[0-9]/.test(c)) {
        let j = i + 1;
        while (j < line.length && /[0-9a-fA-FxX.]/.test(line[j])) j++;
        out += '<span class="num">' + esc(line.slice(i, j)) + "</span>";
        i = j;
        continue;
      }
      out += esc(c);
      i++;
    }
    return out;
  }

  function inlineHi(text) {
    return esc(text)
      .replace(/`([^`]+)`/g, "<code>$1</code>")
      .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  }

  /* ---------------- Routing ---------------- */
  function route() {
    const h = location.hash.replace(/^#\/?/, "");
    if (!h) return { type: "home" };
    let m = h.match(/^q=(\d+)/i);
    if (m) {
      const q = byNo.get(parseInt(m[1], 10));
      return q ? { type: "question", q } : { type: "home" };
    }
    m = h.match(/^p=([a-z0-9-]+)/i);
    if (m) {
      const q = bySlug.get(m[1]);
      return q ? { type: "question", q } : { type: "home" };
    }
    return { type: "home" };
  }

  function goHome() { location.hash = "#/"; }
  function goQuestion(q) { location.hash = "#/q=" + q.qno; }

  /* ---------------- Sidebar ---------------- */
  function categoryOrder() {
    const present = new Set(QUESTIONS.map((q) => q.category));
    const order = TOPIC_ORDER.filter((c) => present.has(c));
    // Anything unexpected still gets a heading at the end.
    for (const q of QUESTIONS) {
      if (!order.includes(q.category)) order.push(q.category);
    }
    return order;
  }

  function matches(q) {
    const s = state.query;
    if (!s) return true;
    return (
      String(q.qno).includes(s) ||
      ("q" + String(q.qno).padStart(3, "0")).includes(s) ||
      q.title.toLowerCase().includes(s) ||
      q.slug.includes(s) ||
      (q.category || "").toLowerCase().includes(s) ||
      (q.difficulty || "").toLowerCase().includes(s) ||
      (q.ncName || "").toLowerCase().includes(s)
    );
  }

  function buildSidebar() {
    const nav = $("#nav");
    nav.innerHTML = "";
    const cats = categoryOrder();
    let shown = 0;

    for (const cat of cats) {
      const items = QUESTIONS.filter((q) => q.category === cat && matches(q)).sort(
        (a, b) => a.qno - b.qno
      );
      if (!items.length) continue;
      shown += items.length;

      const group = el("div", "nav-group");
      const title = el("div", "nav-group-title", cat);
      title.appendChild(el("span", "nav-group-count", items.length + " ques"));
      group.appendChild(title);

      for (const q of items) {
        const a = el("a", "nav-item" + (state.q && state.q.slug === q.slug ? " active" : ""));
        a.href = "#/q=" + q.qno;
        a.dataset.slug = q.slug;
        a.appendChild(el("span", "nav-qno", "Q" + String(q.qno).padStart(3, "0")));
        a.appendChild(el("span", "nav-label", q.title));
        if (q.nc) {
          const tag = el("span", "nc-tag", "NC250");
          tag.title = q.ncName ? q.ncName + " · NeetCode 250" : "NeetCode 250";
          a.appendChild(tag);
        }
        group.appendChild(a);
      }
      nav.appendChild(group);
    }

    if (!shown) nav.appendChild(el("div", "nav-group-title", "No matches"));
    $("#viz-count").textContent = QUESTIONS.length + " questions · " + shown + " shown";
    if (state.q) {
      const active = nav.querySelector(".nav-item.active");
      if (active) {
        const top = active.offsetTop;
        if (top < nav.scrollTop || top > nav.scrollTop + nav.clientHeight - 60) {
          nav.scrollTop = Math.max(0, top - nav.clientHeight / 2);
        }
      }
    }
  }

  /* ---------------- Home ---------------- */
  function renderHome() {
    state.q = null;
    document.title = "DSA Code Explained — Line-by-Line Hinglish";
    $("#home").hidden = false;
    $("#question-view").hidden = true;
    $("#main").classList.add("home");
    $("#viz-title").textContent = "DSA Code Explained";
    $("#q-badge").textContent = "";
    $("#viz-difficulty").textContent = "";
    $("#viz-source").textContent = "";
    $("#viz-desc").textContent =
      "Original C programs, har line ka Hinglish explanation, proper question number ke saath.";
    $("#all-link").style.visibility = "hidden";

    const stats = $("#home-stats");
    if (!stats.childElementCount) {
      const approaches = QUESTIONS.reduce((n, q) => n + q.approaches.length, 0);
      const lines = QUESTIONS.reduce(
        (n, q) => n + q.approaches.reduce((m, a) => m + a.lines.length, 0),
        0
      );
      [
        [QUESTIONS.length, "questions"],
        [approaches, "C programs"],
        [lines.toLocaleString("en-IN"), "explained lines"],
        [QUESTIONS.filter((q) => q.nc).length, "NeetCode 250"],
      ].forEach(([v, l]) => {
        const d = el("div", "home-stat");
        d.appendChild(el("b", null, String(v)));
        d.appendChild(el("span", null, l));
        stats.appendChild(d);
      });
    }

    const wrap = $("#home-cats");
    wrap.innerHTML = "";
    for (const cat of categoryOrder()) {
      const list = QUESTIONS.filter((q) => q.category === cat);
      const card = el("div", "home-cat");
      card.appendChild(el("h3", null, cat));
      card.appendChild(el("p", null, list.length + " questions"));
      const links = el("div", "home-cat-links");
      for (const q of list) {
        const a = el("a", null, "Q" + String(q.qno).padStart(3, "0"));
        a.href = "#/q=" + q.qno;
        a.title = q.title;
        links.appendChild(a);
      }
      card.appendChild(links);
      wrap.appendChild(card);
    }
    buildSidebar();
    window.scrollTo(0, 0);
  }

  /* ---------------- Question ---------------- */
  function renderQuestion(q, keepScroll) {
    const same = state.q && state.q.slug === q.slug;
    if (!same) state.ai = 0;
    state.q = q;
    state.showCpp = false;
    $("#home").hidden = true;
    $("#question-view").hidden = false;
    $("#main").classList.remove("home");
    $("#all-link").style.visibility = "visible";

    const code = "Q" + String(q.qno).padStart(3, "0");
    document.title = code + " · " + q.title + " — DSA Code Explained";
    $("#viz-title").textContent = q.title;
    $("#q-badge").textContent = code;
    $("#viz-difficulty").textContent = q.difficulty || "";
    $("#viz-source").textContent = q.nc ? "NC250" : "";
    $("#viz-source").className = "badge" + (q.nc ? " nc" : "");
    $("#viz-desc").textContent = (q.category ? q.category + " · " : "") + (q.description || "");

    renderApproaches();
    renderApproach();
    renderNav();
    buildSidebar();
    if (!keepScroll) window.scrollTo(0, 0);
  }

  function renderApproaches() {
    const row = $("#approaches");
    row.innerHTML = "";
    _currentApproaches().forEach((a, i) => {
      const b = el("button", "tab-btn" + (i === state.ai ? " active" : ""));
      b.type = "button";
      b.setAttribute("role", "tab");
      b.appendChild(el("span", "num", String(i + 1)));
      b.appendChild(el("span", null, a.name));
      b.addEventListener("click", () => {
        if (state.ai === i) return;
        state.ai = i;
        state.showCpp = false;
        renderApproaches();
        renderApproach();
      });
      row.appendChild(b);
    });
    row.hidden = _currentApproaches().length <= 1;
  }

  function _currentApproaches() {
    return (state.q && state.q.approaches) || [];
  }

  function currentApproach() {
    return _currentApproaches()[state.ai] || null;
  }

  function renderApproach() {
    const q = state.q;
    const a = currentApproach();
    if (!a) return;

    $("#summary-text").innerHTML = inlineHi(
      a.summary ||
        "Yeh approach \"" + a.name + "\" use karke problem solve karta hai. Neeche har C line ka matlab diya gaya hai."
    );
    $("#summary-name").textContent = a.name || "";
    $("#summary-complexity").textContent = a.complexity || "—";

    const notes = $("#notes-body");
    notes.innerHTML = "";
    if (a.idea && a.idea.length) {
      notes.appendChild(el("h4", null, "Idea"));
      const ul = el("ul");
      a.idea.forEach((t) => ul.appendChild(el("li", null, t)));
      notes.appendChild(ul);
    }
    if (a.problem && a.problem.length) {
      notes.appendChild(el("h4", null, "Trade-off / Problem"));
      const ul = el("ul");
      a.problem.forEach((t) => ul.appendChild(el("li", null, t)));
      notes.appendChild(ul);
    }
    if (!notes.childElementCount) notes.textContent = "No extra notes for this approach.";

    renderCode(a);
    renderCpp(a);
    $("#toggle-explain").textContent = "Explanations: " + (state.showEx ? "On" : "Off");
    $("#toggle-explain").classList.toggle("primary", state.showEx);
    $("#code-explain").classList.toggle("hide-ex", !state.showEx);
    $("#toggle-cpp").classList.toggle("primary", state.showCpp);
    $("#cpp-pane").hidden = !state.showCpp;
  }

  const KEY_LINE = /(^|\s)(for|while|if|else|return|switch|case|break|continue)\b|printf|scanf|qsort|malloc|free\s*\(/;

  function renderCode(a) {
    const box = $("#code-explain");
    box.innerHTML = "";
    const lines = a.codeC.split("\n");

    const head = el("div", "ex-head");
    head.appendChild(el("div", null, "Line"));
    head.appendChild(el("div", null, "C code"));
    const hWhy = el("div", "h-why", "Hinglish explanation");
    head.appendChild(hWhy);
    box.appendChild(head);

    lines.forEach((line, i) => {
      const row = el("div", "ex-row");
      if (KEY_LINE.test(line)) row.classList.add("key");
      row.dataset.line = i;

      const no = el("div", "ex-no", String(i + 1));
      const codeEl = el("pre", "ex-code");
      codeEl.innerHTML = highlightC(line) || " ";
      const why = el("div", "ex-why");
      const text = (a.lines && a.lines[i]) || "(explanation not available yet)";
      if (!line.trim()) why.classList.add("blank");
      why.innerHTML = inlineHi(text);

      row.appendChild(no);
      row.appendChild(codeEl);
      row.appendChild(why);
      row.addEventListener("click", () => {
        const was = row.classList.contains("selected");
        box.querySelectorAll(".ex-row.selected").forEach((r) => r.classList.remove("selected"));
        if (!was) row.classList.add("selected");
      });
      box.appendChild(row);
    });

    $("#line-count").textContent =
      lines.length + " lines · " + (a.lines ? a.lines.filter(Boolean).length : 0) + " explained";
    box.classList.toggle("hide-ex", !state.showEx);
  }

  function renderCpp(a) {
    const pre = $("#cpp-code");
    if (!a.codeCpp) {
      pre.textContent = "C++ version is not available for this approach.";
      return;
    }
    pre.innerHTML = a.codeCpp
      .split("\n")
      .map((line) => highlightC(line) || " ")
      .join("\n");
  }

  function renderNav() {
    const nav = $("#qnav");
    nav.innerHTML = "";
    const idx = QUESTIONS.findIndex((x) => x.slug === state.q.slug);
    const prev = idx > 0 ? QUESTIONS[idx - 1] : null;
    const next = idx >= 0 && idx < QUESTIONS.length - 1 ? QUESTIONS[idx + 1] : null;

    if (prev) {
      const a = el("a", "prev");
      a.href = "#/q=" + prev.qno;
      a.appendChild(el("span", "qn-dir", "← Previous · Q" + String(prev.qno).padStart(3, "0")));
      a.appendChild(el("span", "qn-title", prev.title));
      nav.appendChild(a);
    } else {
      nav.appendChild(el("span"));
    }
    if (next) {
      const a = el("a", "next");
      a.href = "#/q=" + next.qno;
      a.appendChild(el("span", "qn-dir", "Next · Q" + String(next.qno).padStart(3, "0") + " →"));
      a.appendChild(el("span", "qn-title", next.title));
      nav.appendChild(a);
    } else {
      nav.appendChild(el("span"));
    }
  }

  /* ---------------- Events ---------------- */
  function initEvents() {
    window.addEventListener("hashchange", () => {
      const r = route();
      if (r.type === "home") renderHome();
      else renderQuestion(r.q);
    });

    $("#search").addEventListener("input", (e) => {
      state.query = e.target.value.toLowerCase().trim();
      buildSidebar();
    });

    $("#search").addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        const first = QUESTIONS.find(matches);
        if (first) goQuestion(first);
      }
      if (e.key === "Escape") {
        e.target.value = "";
        state.query = "";
        buildSidebar();
      }
    });

    $("#sidebar-open").addEventListener("click", () => $("#sidebar").classList.add("open"));
    $("#sidebar-close").addEventListener("click", () => $("#sidebar").classList.remove("open"));
    $("#nav").addEventListener("click", (e) => {
      if (e.target.closest("a")) $("#sidebar").classList.remove("open");
    });

    $("#toggle-explain").addEventListener("click", () => {
      state.showEx = !state.showEx;
      $("#code-explain").classList.toggle("hide-ex", !state.showEx);
      $("#toggle-explain").textContent = "Explanations: " + (state.showEx ? "On" : "Off");
      $("#toggle-explain").classList.toggle("primary", state.showEx);
    });

    $("#toggle-cpp").addEventListener("click", () => {
      state.showCpp = !state.showCpp;
      $("#cpp-pane").hidden = !state.showCpp;
      $("#toggle-cpp").classList.toggle("primary", state.showCpp);
      if (state.showCpp) $("#cpp-pane").scrollIntoView({ behavior: "smooth", block: "nearest" });
    });

    $("#copy-code").addEventListener("click", async () => {
      const a = currentApproach();
      if (!a) return;
      const btn = $("#copy-code");
      try {
        await navigator.clipboard.writeText(a.codeC);
        btn.textContent = "Copied ✓";
      } catch (_) {
        const ta = document.createElement("textarea");
        ta.value = a.codeC;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        ta.remove();
        btn.textContent = "Copied ✓";
      }
      setTimeout(() => (btn.textContent = "Copy C"), 1200);
    });

    document.addEventListener("keydown", (e) => {
      if (e.target.matches("input, textarea, select")) return;
      if (!state.q) return;
      const idx = QUESTIONS.findIndex((x) => x.slug === state.q.slug);
      if (e.key === "ArrowLeft" && idx > 0) {
        e.preventDefault();
        goQuestion(QUESTIONS[idx - 1]);
      } else if (e.key === "ArrowRight" && idx < QUESTIONS.length - 1) {
        e.preventDefault();
        goQuestion(QUESTIONS[idx + 1]);
      } else if (e.key === "Home") {
        e.preventDefault();
        goQuestion(QUESTIONS[0]);
      } else if (e.key === "End") {
        e.preventDefault();
        goQuestion(QUESTIONS[QUESTIONS.length - 1]);
      }
    });
  }

  /* ---------------- Boot ---------------- */
  function boot() {
    if (!QUESTIONS.length) {
      $("#viz-title").textContent = "No question data found";
      $("#viz-desc").textContent = "js/questions.js load nahi hua.";
      return;
    }
    const approaches = QUESTIONS.reduce((n, q) => n + q.approaches.length, 0);
    const lines = QUESTIONS.reduce(
      (n, q) => n + q.approaches.reduce((m, a) => m + a.lines.length, 0),
      0
    );
    $("#foot-count").textContent =
      QUESTIONS.length + " questions · " + approaches + " C programs · " + lines.toLocaleString("en-IN") + " lines explained";

    initEvents();
    const r = route();
    if (r.type === "home") renderHome();
    else renderQuestion(r.q);
  }

  boot();
})();
